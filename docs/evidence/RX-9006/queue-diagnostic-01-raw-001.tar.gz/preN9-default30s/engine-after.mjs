import { captureConfiguration } from '../contracts/schema.js';
import { initializeParticipants } from '../capabilities/participants.js';
import { invalid, RaveldexError } from '../errors/error.js';
import { emptyDirectory } from '../index/staging.js';
import { MutationOwner } from '../mutations/owner.js';
import { WorkBudget } from '../limits/work.js';
import { captureSearch, executeOwnedSearch } from '../query/search.js';
import { directHost } from './host.js';
export function emptyRoot(configuration, states = Object.freeze(Object.create(null))) {
    const fields = Object.create(null);
    for (const name of Object.keys(configuration.schema.text))
        fields[name] = Object.freeze({ documents: 0, length: 0, terms: emptyDirectory() });
    return Object.freeze({ configuration, revision: 0, documents: emptyDirectory(), fields: Object.freeze(fields),
        counts: Object.freeze({ documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 }),
        participants: states });
}
/** Internal engine implementation. The factory exposes only bound ordinary methods. */
export class ExecutionOwner {
    #owner;
    #configuration;
    #host;
    #metrics;
    #queue = [];
    #active;
    #closing = false;
    #pumping = false;
    #disposal;
    #disposed;
    constructor(root, host, participants = [], metrics) {
        this.#owner = new MutationOwner(root, participants);
        this.#configuration = root.configuration;
        this.#metrics = metrics;
        // Trusted private host handles; caller changes cannot replace them later.
        this.#host = Object.freeze({ now: host.now.bind(host), schedule: host.schedule.bind(host) });
    }
    get root() { return this.#owner?.root; }
    adapterOperation(capture, control) {
        return this.admit(() => {
            const request = capture(this.#configuration);
            return { options: request.options, start: check => {
                    const owner = this.#owner, previous = owner.root;
                    return request.start(previous, check, root => owner.publishPrepared(root, previous));
                } };
        }, control);
    }
    adapterReplace(capture) {
        return this.admit(() => {
            const request = capture(this.#configuration);
            return { options: request.options, start: check => {
                    const owner = this.#owner, maximum = this.#configuration.limits.maxMutationWorkUnits;
                    return (function* () {
                        const budget = new WorkBudget(maximum);
                        function* metered(cursor) {
                            let finished = false;
                            try {
                                for (;;) {
                                    check('patch');
                                    const step = cursor.next();
                                    // A completed mutation has committed. No callback, stop check,
                                    // charge or yield may turn that successful commit into failure.
                                    if (step.done) {
                                        finished = true;
                                        return step.value;
                                    }
                                    check('patch');
                                    budget.charge(step.value.workUnits);
                                    yield step.value;
                                }
                            }
                            finally {
                                if (!finished) {
                                    try {
                                        cursor.return(undefined);
                                    }
                                    catch { /* Preserve the first failure. */ }
                                }
                            }
                        }
                        const record = yield* metered(request.start(owner.root, check));
                        check('patch.replace');
                        const replacement = owner.capture('replace', record, request.options);
                        check('patch.replace');
                        return yield* metered(owner.execute(replacement, { checkStop: check }));
                    })();
                } };
        });
    }
    search(query, options) {
        return this.searchControlled(query, options);
    }
    searchControlled(query, options, control) {
        return this.admit(() => {
            const request = captureSearch(this.#configuration, query, options);
            return { options: request.options, start: (check) => executeOwnedSearch(this.#owner.root, request, { checkStop: check }) };
        }, control);
    }
    add(record, options) { return this.mutate('add', record, options); }
    addMany(records, options) { return this.mutate('addMany', records, options); }
    replace(record, options) { return this.mutate('replace', record, options); }
    remove(ids, options) { return this.mutate('remove', ids, options); }
    clear(options) { return this.mutate('clear', undefined, options); }
    mutate(kind, input, options) {
        return this.mutateControlled(kind, input, options);
    }
    mutateControlled(kind, input, options, control) {
        return this.admit(() => {
            const request = this.#owner.capture(kind, input, options);
            return { options: request.options, start: (check) => this.#owner.execute(request, { checkStop: check }) };
        }, control);
    }
    check(op, phase) {
        if (this.#metrics) {
            this.#metrics.checks++;
            if (phase)
                this.#metrics.phaseChecks[phase] = (this.#metrics.phaseChecks[phase] ?? 0) + 1;
        }
        if (this.#closing)
            invalid('DISPOSED', 'execution');
        const aborted = op.options?.signal?.aborted;
        const expired = this.#host.now() >= op.deadline;
        // Structural host handles may reenter; choose precedence after reading them.
        if (this.#closing)
            invalid('DISPOSED', 'execution');
        if (aborted || op.cancelled)
            invalid('CANCELLED', 'options.signal');
        if (expired)
            invalid('DEADLINE_EXCEEDED', 'options.deadlineMs');
    }
    admit(capture, control) {
        // Synchronous ownership capture, with every operational exception rejected.
        try {
            if (this.#closing)
                invalid('DISPOSED', 'execution');
            const admittedAt = this.#host.now();
            const request = capture();
            if (control) {
                if (!Number.isFinite(control.elapsedMs) || control.elapsedMs < 0)
                    invalid('INTERNAL_ERROR', 'execution.control');
                request.options = Object.freeze({ ...request.options, signal: control.signal });
            }
            if (this.#closing)
                invalid('DISPOSED', 'execution');
            if (request.options.signal?.aborted)
                invalid('CANCELLED', 'options.signal');
            if (control && control.elapsedMs >= request.options.deadlineMs)
                invalid('DEADLINE_EXCEEDED', 'options.deadlineMs');
            if (this.#active && this.#queue.length >= this.#configuration.limits.maxQueuedOperations)
                invalid('QUEUE_FULL', 'execution.queue');
            let resolve, reject;
            const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
            const op = { options: request.options, start: undefined, cursor: undefined, resolve, reject,
                deadline: admittedAt + request.options.deadlineMs - (control?.elapsedMs ?? 0), detach: undefined, timer: undefined, resume: undefined, settled: false, executing: false, cancelled: false };
            op.start = () => request.start(phase => this.check(op, phase));
            if (this.#active)
                this.#queue.push(op);
            else
                this.#active = op;
            const n10q=globalThis[Symbol.for('raveldex.rx9006.queue')];
            if(n10q){const entry={label:n10q.label,admittedAt,enqueuedAt:this.#host.now(),wasQueued:this.#queue.includes(op),queueLengthAfterEnqueue:this.#queue.length,deadline:op.deadline,capturedDeadlineMs:request.options.deadlineMs,startedAt:null,terminalAt:null,terminalCode:null,cleanup:null};n10q.operations.set(op,entry);n10q.events.push(entry);}
            try {
                const signal = op.options.signal;
                if (signal) {
                    const stop = () => { op.cancelled = true; this.stop(op); };
                    op.detach = () => signal.removeEventListener('abort', stop);
                    signal.addEventListener('abort', stop, { once: true });
                    if (op.settled) {
                        try {
                            signal.removeEventListener('abort', stop);
                        }
                        catch { /* Reentrant registration cleanup. */ }
                    }
                }
                if (!op.settled) {
                    this.check(op);
                    op.timer = this.#host.schedule(() => { op.timer = undefined; this.stop(op); }, Math.max(0, op.deadline - this.#host.now()));
                }
            }
            catch (error) {
                this.finish(op, undefined, this.error(error));
            }
            this.pump();
            return promise;
        }
        catch (error) {
            return Promise.reject(this.error(error));
        }
    }
    /** Event/timer stop while suspended closes staging immediately; running code checks cooperatively. */
    stop(op) {
        if (op.settled || op.executing)
            return;
        try {
            this.check(op);
            // A timer may fire slightly early on a host; preserve its absolute deadline.
            op.timer?.();
            op.timer = this.#host.schedule(() => { op.timer = undefined; this.stop(op); }, Math.max(0, op.deadline - this.#host.now()));
        }
        catch (error) {
            this.finish(op, undefined, this.error(error));
            this.pump();
        }
    }
    pump() {
        if (this.#pumping)
            return;
        this.#pumping = true;
        // A host task may finish several small FIFO calls; meter that whole burst.
        let consumed = 0;
        try {
            for (;;) {
                if (!this.#active)
                    this.#active = this.#queue.shift();
                const op = this.#active;
                if (!op || op.resume)
                    break;
                op.executing = true;
                try {
                    this.check(op);
                    if(!op.cursor){const n10q=globalThis[Symbol.for('raveldex.rx9006.queue')],entry=n10q?.operations.get(op);if(entry)entry.startedAt=this.#host.now();}
                    op.cursor ??= op.start();
                    op.start = undefined;
                    for (;;) {
                        this.check(op);
                        const step = op.cursor.next();
                        // A mutation may have just committed. Never check stops after done.
                        if (step.done) {
                            this.finish(op, step.value);
                            break;
                        }
                        consumed += step.value.workUnits;
                        if (this.#metrics) {
                            this.#metrics.workUnits += step.value.workUnits;
                            this.#metrics.steps++;
                            this.#metrics.maxStepWorkUnits = Math.max(this.#metrics.maxStepWorkUnits, step.value.workUnits);
                            this.#metrics.maxTaskWorkUnits = Math.max(this.#metrics.maxTaskWorkUnits, consumed);
                        }
                        if (consumed >= this.#configuration.limits.checkpointWorkUnits) {
                            this.check(op);
                            op.resume = this.#host.schedule(() => { op.resume = undefined; this.pump(); }, 0);
                            if (this.#metrics)
                                this.#metrics.hostYields++;
                            break;
                        }
                    }
                }
                catch (error) {
                    this.finish(op, undefined, this.error(error));
                }
                finally {
                    op.executing = false;
                }
                if (this.#active === op)
                    break;
            }
        }
        finally {
            this.#pumping = false;
            this.release();
        }
    }
    error(error) { return error instanceof RaveldexError ? error : new RaveldexError('INTERNAL_ERROR'); }
    finish(op, result, failure) {
        if (op.settled)
            return;
        const n10q=globalThis[Symbol.for('raveldex.rx9006.queue')],n10entry=n10q?.operations.get(op);if(n10entry){n10entry.terminalAt=this.#host.now();n10entry.terminalCode=failure===undefined?'Pass':failure?.code??'UNTYPED_ERROR';n10entry.cursorPresentAtTerminal=Boolean(op.cursor);}
        op.settled = true;
        const resolve = op.resolve, reject = op.reject;
        const cursor = op.cursor;
        // Detach admission/root closures before any trusted host cleanup can reenter.
        op.options = undefined;
        op.start = undefined;
        op.cursor = undefined;
        op.resolve = undefined;
        op.reject = undefined;
        if (failure !== undefined) {
            try {
                cursor?.return(undefined);
            }
            catch { /* Best-effort participant cleanup. */ }
        }
        for (const cleanup of [op.resume, op.timer, op.detach]) {
            try {
                cleanup?.();
            }
            catch { /* Preserve the operation's first outcome. */ }
        }
        op.resume = undefined;
        op.timer = undefined;
        op.detach = undefined;
        if (this.#active === op)
            this.#active = undefined;
        else
            this.#queue = this.#queue.filter(item => item !== op);
        if(n10entry)n10entry.cleanup={activeIsOperation:this.#active===op,queued:this.#queue.includes(op),resumeLive:Boolean(op.resume),timerLive:Boolean(op.timer),detachLive:Boolean(op.detach),optionsLive:Boolean(op.options),startLive:Boolean(op.start),cursorLive:Boolean(op.cursor),resolveLive:Boolean(op.resolve),rejectLive:Boolean(op.reject)};
        if (failure !== undefined)
            reject(this.error(failure));
        else
            resolve(result);
        this.release();
    }
    dispose() {
        if (this.#disposal)
            return this.#disposal;
        this.#closing = true;
        this.#disposal = new Promise(resolve => { this.#disposed = resolve; });
        for (const op of [...this.#queue])
            this.finish(op, undefined, new RaveldexError('DISPOSED'));
        if (this.#active && !this.#active.executing)
            this.finish(this.#active, undefined, new RaveldexError('DISPOSED'));
        this.release();
        return this.#disposal;
    }
    release() {
        if (this.#closing && !this.#active && this.#queue.length === 0) {
            this.#owner = undefined;
            const resolve = this.#disposed;
            this.#disposed = undefined;
            resolve?.();
        }
    }
}
const executionOwners = new WeakMap();
/** Private identity lookup; optional adapters cannot attach to foreign facades. */
export function getExecutionOwner(engine) { return executionOwners.get(engine); }
/** Trusted owned factory, excluded from the public root package exports. */
export function createOwnedRaveldex(captured, host = directHost(), metrics) {
    let owner;
    try {
        const installed = initializeParticipants(captured);
        owner = new ExecutionOwner(emptyRoot(captured, installed.states), host, installed.participants, metrics);
    }
    catch (error) {
        throw error instanceof RaveldexError ? error : new RaveldexError('INTERNAL_ERROR');
    }
    return facadeFromExecutionOwner(owner);
}
/** The single trusted owner-to-facade binding path. Kept outside public exports;
 * internal controlled owners use the same identity and ordinary method surface. */
export function facadeFromExecutionOwner(owner) {
    // A public data facade prevents JavaScript callers reaching private test roots
    // or TypeScript-private execution callbacks through the owner's prototype.
    const facade = Object.freeze({
        search: owner.search.bind(owner), add: owner.add.bind(owner),
        addMany: owner.addMany.bind(owner), replace: owner.replace.bind(owner),
        remove: owner.remove.bind(owner), clear: owner.clear.bind(owner),
        dispose: owner.dispose.bind(owner),
    });
    executionOwners.set(facade, owner);
    return facade;
}
export function createRaveldex(configuration) {
    try {
        return createOwnedRaveldex(captureConfiguration(configuration));
    }
    catch (error) {
        throw error instanceof RaveldexError ? error : new RaveldexError('INTERNAL_ERROR');
    }
}
