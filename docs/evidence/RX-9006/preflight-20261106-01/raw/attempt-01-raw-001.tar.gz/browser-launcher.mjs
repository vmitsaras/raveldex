#!/opt/homebrew/Cellar/node@24/24.21.0/bin/node
import {runSupervisedExecutable} from "file:///Users/vasilis/Documents/GitHub/raveldex/bench/n10/host-recovery-supervisor.mjs";
await runSupervisedExecutable({"executablePath":"/Users/vasilis/Library/Caches/ms-playwright/chromium-1228/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing","executableSha256":"b1b9e2dd063115031f08eadc10ed381ca0fa05b2284baff8f721d87f5f0f61b7","moduleSha256":"b36dd7e25ad3d53bb01917d621eb9292da87130f0395d3521cf7b1a490dda5b0"});
