// dist/core/errors/error.js
var ERROR_CODES = Object.freeze([
  "INVALID_SCHEMA",
  "INVALID_RECORD",
  "INVALID_QUERY",
  "INVALID_OPTIONS",
  "ID_EXISTS",
  "ID_NOT_FOUND",
  "LIMIT_EXCEEDED",
  "QUEUE_FULL",
  "WORK_LIMIT_EXCEEDED",
  "DEADLINE_EXCEEDED",
  "CANCELLED",
  "DISPOSED",
  "MISSING_CAPABILITY",
  "INCOMPATIBLE_CAPABILITY",
  "REVISION_MISMATCH",
  "REVISION_EXHAUSTED",
  "RESOURCE_EXHAUSTED",
  "UNSUPPORTED_ENVIRONMENT",
  "INTERNAL_ERROR"
]);
var RaveldexError = class extends Error {
  code;
  details;
  constructor(code, details = {}) {
    super(`Raveldex: ${code}`);
    this.name = "RaveldexError";
    this.code = code;
    this.details = Object.freeze({
      ...details.path === void 0 ? {} : { path: details.path.slice(0, 256) },
      ...details.limit === void 0 ? {} : { limit: details.limit },
      ...details.actual === void 0 ? {} : { actual: details.actual }
    });
  }
};
function invalid(code, path) {
  throw new RaveldexError(code, { path });
}
function bound(actual, limit, path) {
  if (!Number.isSafeInteger(actual) || actual > limit) {
    throw new RaveldexError("LIMIT_EXCEEDED", { path, limit, actual });
  }
}

// dist/core/contracts/data.js
var Admission = class {
  maximum;
  entries = 0;
  constructor(maximum) {
    this.maximum = maximum;
  }
  get count() {
    return this.entries;
  }
  charge(count, path) {
    this.entries += count;
    bound(this.entries, this.maximum, path);
  }
};
function ownObject(input, code, path, admission) {
  if (typeof input !== "object" || input === null)
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Object.prototype)
    invalid(code, path);
  const keys = Reflect.ownKeys(input);
  admission.charge(keys.length, path);
  const copy = /* @__PURE__ */ Object.create(null);
  for (const key of keys) {
    if (typeof key !== "string")
      invalid(code, path);
    const descriptor = Object.getOwnPropertyDescriptor(input, key);
    if (!descriptor || !("value" in descriptor))
      invalid(code, path);
    copy[key] = descriptor.value;
  }
  return copy;
}
function ownArray(input, maximum, code, path, admission) {
  if (!Array.isArray(input))
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Array.prototype)
    invalid(code, path);
  bound(input.length, maximum, path);
  const keys = Reflect.ownKeys(input);
  admission.charge(keys.length, path);
  if (keys.length !== input.length + 1)
    invalid(code, path);
  for (const key of keys) {
    if (key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= input.length)) {
      invalid(code, path);
    }
  }
  const copy = [];
  for (let i = 0; i < input.length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(input, String(i));
    if (!descriptor || !("value" in descriptor))
      invalid(code, `${path}[${i}]`);
    copy.push(descriptor.value);
  }
  return copy;
}
function keysOnly(data, allowed, code, path) {
  for (const key of Object.keys(data))
    if (!allowed.includes(key))
      invalid(code, path);
}
function has(data, key) {
  return Object.prototype.hasOwnProperty.call(data, key);
}
function stringValue(input, maximum, code, path) {
  if (typeof input !== "string")
    invalid(code, path);
  bound(input.length, maximum, path);
  return input;
}
function* scanUnicode(value, code, path) {
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, path);
    i += width;
    yield { workUnits: 1 };
  }
}
function codePointWidth(value, index, code, path) {
  const first = value.charCodeAt(index);
  if (first >= 55296 && first <= 56319) {
    const second = value.charCodeAt(index + 1);
    if (!(second >= 56320 && second <= 57343))
      invalid(code, path);
    return 2;
  }
  if (first >= 56320 && first <= 57343)
    invalid(code, path);
  return 1;
}

// dist/core/limits/limits.js
var DEFAULT_LIMITS = Object.freeze({
  maxDocuments: 1e4,
  maxTextFields: 32,
  maxMetadataFields: 32,
  maxFieldNameCodeUnits: 64,
  maxIdCodeUnits: 256,
  maxTextValuesPerField: 64,
  maxMetadataValuesPerField: 128,
  maxMetadataStringCodeUnits: 1024,
  maxMetadataCodeUnitsPerRecord: 32768,
  maxTextCodeUnitsPerValue: 65536,
  maxTextCodeUnitsPerRecord: 262144,
  maxCorpusTextCodeUnits: 67108864,
  maxRawTokenCodeUnits: 256,
  maxTermCodeUnits: 256,
  maxTokensPerRecord: 32768,
  maxCorpusTokens: 4e6,
  maxDictionaryEntries: 25e4,
  maxPostingEntries: 2e6,
  maxMutationBatch: 256,
  maxAdmissionEntries: 16384,
  maxQueryNodes: 128,
  maxQueryDepth: 16,
  maxQueryLexicalCodeUnits: 2048,
  maxQueryCodeUnits: 16384,
  maxQueryTokens: 64,
  maxQueryGroups: 64,
  maxVariantsPerGroup: 16,
  maxExpansionsPerGroup: 256,
  maxQueryExpansions: 1024,
  minPrefixCodePoints: 2,
  maxHits: 100,
  maxQueuedOperations: 32,
  maxSearchWorkUnits: 1e7,
  maxMutationWorkUnits: 5e7,
  checkpointWorkUnits: 2048,
  maxDeadlineMs: 6e4
});
function resolveLimits(input = {}, admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries)) {
  const data = ownObject(input, "INVALID_OPTIONS", "limits", admission);
  const result = { ...DEFAULT_LIMITS };
  for (const key of Object.keys(data)) {
    if (!has(DEFAULT_LIMITS, key))
      invalid("INVALID_OPTIONS", "limits");
    const name = key;
    const value = data[key];
    const minimum = name === "maxMetadataFields" || name === "maxQueuedOperations" ? 0 : name === "minPrefixCodePoints" ? 2 : 1;
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid("INVALID_OPTIONS", `limits.${name}`);
    if (name !== "minPrefixCodePoints")
      bound(value, DEFAULT_LIMITS[name], `limits.${name}`);
    result[name] = value;
  }
  if (result.checkpointWorkUnits > Math.min(result.maxSearchWorkUnits, result.maxMutationWorkUnits)) {
    invalid("INVALID_OPTIONS", "limits.checkpointWorkUnits");
  }
  return Object.freeze(result);
}
function validateStateCounts(counts, limits) {
  const pairs = [
    ["documents", "maxDocuments"],
    ["textCodeUnits", "maxCorpusTextCodeUnits"],
    ["tokens", "maxCorpusTokens"],
    ["dictionaryEntries", "maxDictionaryEntries"],
    ["postingEntries", "maxPostingEntries"]
  ];
  for (const [count, limit] of pairs) {
    if (!Number.isSafeInteger(counts[count]) || counts[count] < 0)
      invalid("INTERNAL_ERROR", `state.${count}`);
    bound(counts[count], limits[limit], `state.${count}`);
  }
}

// dist/core/analyzer/basic.js
var BASIC_ANALYZER = Object.freeze({ id: "basic-v1", environmentProfile: "unqualified" });
var START = /[\p{L}\p{N}]/u;
var CONTINUE = /[\p{L}\p{N}\p{M}]/u;
function* analyzeValue(value, valueIndex = 0, limits = DEFAULT_LIMITS, code = "INVALID_RECORD") {
  bound(value.length, limits.maxTextCodeUnitsPerValue, "analysis.value");
  let start = -1;
  let position = 0;
  function emit(end) {
    const raw = value.slice(start, end);
    const term = raw.normalize("NFKC").toLowerCase();
    bound(term.length, limits.maxTermCodeUnits, "analysis.term");
    const token = Object.freeze({ term, valueIndex, position: position++, start, end });
    start = -1;
    return { workUnits: raw.length + term.length, token };
  }
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, "analysis.value");
    const point = value.slice(i, i + width);
    if (start >= 0 && !CONTINUE.test(point))
      yield emit(i);
    if (start < 0 && START.test(point))
      start = i;
    i += width;
    if (start >= 0)
      bound(i - start, limits.maxRawTokenCodeUnits, "analysis.rawToken");
    yield { workUnits: 1 };
  }
  if (start >= 0)
    yield emit(value.length);
}

// dist/core/capabilities/registration.js
function captureRegistrations(input, context) {
  const { schema, limits, admission } = context, code = "INCOMPATIBLE_CAPABILITY";
  const entries = ownArray(input, 32, code, "addons", admission);
  const registrations = /* @__PURE__ */ new Map();
  const providers = /* @__PURE__ */ Object.create(null);
  const object = (value, path, keys) => {
    const data = ownObject(value, code, path, admission);
    keysOnly(data, keys, code, path);
    return data;
  };
  const string2 = (value, path, maximum = 128) => {
    const result = stringValue(value, maximum, code, path);
    if (!result.length)
      invalid(code, path);
    for (const step of scanUnicode(result, code, path)) {
      void step;
    }
    return result;
  };
  const id = (value, path) => {
    const result = string2(value, path);
    if (!/^[A-Za-z][A-Za-z0-9:._-]*$/.test(result))
      invalid(code, path);
    return result;
  };
  const integer3 = (value, path, minimum = 0) => {
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid(code, path);
    return value;
  };
  const flag = (value, path) => {
    if (typeof value !== "boolean")
      invalid(code, path);
    return value;
  };
  const references = (value, path) => {
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(ownArray(value, 64, code, path, admission).map((value2) => {
      const ref = object(value2, path, ["id", "contractVersion"]), name = id(ref.id, path);
      if (ref.contractVersion !== 1 || seen.has(name))
        invalid(code, path);
      seen.add(name);
      return Object.freeze({ id: name, contractVersion: 1 });
    }));
  };
  for (const entry of entries) {
    const data = object(entry, "addons.registration", ["manifest", "participant", "refinement", "predicate", "sourcePredicate", "aggregation", "evidence", "expansion", "dictionary", "analyzer"]);
    const raw = object(data.manifest, "addons.manifest", ["id", "version", "contractVersion", "roles", "provides", "requires", "dataRequirements", "indexEffect", "rebuildPolicy", "execution", "limits", "costs", "codec"]);
    const name = id(raw.id, "addons.id"), version = string2(raw.version, "addons.version");
    const semanticVersion = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/;
    if (!semanticVersion.test(version) || raw.contractVersion !== 1 || registrations.has(name))
      invalid(code, "addons.identity");
    const roles = ownArray(raw.roles, 7, code, "addons.roles", admission);
    if (!roles.length || new Set(roles).size !== roles.length || roles.some((role) => role !== "leaf-refinement" && role !== "transaction-participant" && role !== "aggregation" && role !== "evidence" && role !== "term-expansion" && role !== "dictionary-output" && role !== "analyzer"))
      invalid(code, "addons.roles");
    const requirements = object(raw.dataRequirements, "addons.dataRequirements", ["fields", "source", "positions", "offsets", "metadata"]);
    const metadata = flag(requirements.metadata, "addons.metadata");
    const fields = ownArray(requirements.fields, metadata ? limits.maxMetadataFields : limits.maxTextFields, code, "addons.fields", admission).map((field2) => {
      const name2 = id(field2, "addons.fields");
      if (!has(metadata ? schema.metadata : schema.text, name2))
        invalid(code, "addons.fields");
      return name2;
    });
    if (new Set(fields).size !== fields.length)
      invalid(code, "addons.fields");
    const execution = object(raw.execution, "addons.execution", ["direct", "worker", "workerRegistration"]);
    if (execution.direct !== true || typeof execution.worker !== "boolean" || execution.worker !== has(execution, "workerRegistration"))
      invalid(code, "addons.execution");
    const workerRegistration = execution.worker ? string2(execution.workerRegistration, "addons.workerRegistration", 8192) : void 0;
    const caps = object(raw.limits, "addons.limits", ["maxPayloadCodeUnits", "maxWorkUnits", "maxRetainedEntries", "maxOutputEntries"]);
    const ownedLimits = Object.freeze({ maxPayloadCodeUnits: integer3(caps.maxPayloadCodeUnits, "addons.limits", 1), maxWorkUnits: integer3(caps.maxWorkUnits, "addons.limits", 1), maxRetainedEntries: integer3(caps.maxRetainedEntries, "addons.limits"), maxOutputEntries: integer3(caps.maxOutputEntries, "addons.limits") });
    if (ownedLimits.maxPayloadCodeUnits > DEFAULT_LIMITS.maxQueryCodeUnits || ownedLimits.maxWorkUnits > Math.max(DEFAULT_LIMITS.maxSearchWorkUnits, DEFAULT_LIMITS.maxMutationWorkUnits))
      invalid(code, "addons.limits");
    const costs = object(raw.costs, "addons.costs", ["importedCode", "retainedRepresentation", "transientWork", "externalResources"]);
    if (costs.externalResources !== "none" || raw.rebuildPolicy !== "new-index")
      invalid(code, "addons.costs");
    const participantRole = roles.includes("transaction-participant"), refinementRole = roles.includes("leaf-refinement"), aggregationRole = roles.includes("aggregation"), evidenceRole = roles.includes("evidence");
    const expansionRole = roles.includes("term-expansion");
    const dictionaryRole = roles.includes("dictionary-output");
    const analyzerRole = roles.includes("analyzer");
    if (analyzerRole !== has(data, "analyzer") || analyzerRole && (roles.length !== 1 || fields.length !== 0 || metadata || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false || has(raw, "codec")))
      invalid(code, "addons.analyzer");
    if (dictionaryRole !== has(data, "dictionary") || dictionaryRole && (roles.length !== 1 || metadata || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.dictionary");
    if (expansionRole !== has(data, "expansion") || expansionRole && (roles.length !== 1 || metadata || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.expansion");
    const leafHandles = ["refinement", "predicate", "sourcePredicate"].filter((key) => has(data, key)).length;
    if (participantRole !== has(data, "participant") || refinementRole !== (leafHandles === 1) || leafHandles > 1 || aggregationRole !== has(data, "aggregation") || evidenceRole !== has(data, "evidence") || raw.indexEffect !== (participantRole ? "transactional" : analyzerRole ? "analysis" : "none"))
      invalid(code, "addons.roles");
    if ((has(data, "predicate") || aggregationRole) && (!metadata || participantRole || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.dataRequirements");
    if (has(data, "sourcePredicate") && (metadata || participantRole || requirements.source !== true || requirements.positions !== false || requirements.offsets !== false || !fields.length || has(raw, "codec")))
      invalid(code, "addons.dataRequirements");
    if (evidenceRole && (participantRole || metadata || requirements.offsets === true && requirements.positions !== true))
      invalid(code, "addons.dataRequirements");
    const implementations = {};
    for (const key of ["participant", "refinement", "predicate", "sourcePredicate", "aggregation", "evidence", "expansion", "dictionary", "analyzer"]) {
      if (!has(data, key))
        continue;
      let methods = key === "participant" ? ["initialize", "prepare"] : key === "refinement" ? ["prepare"] : key === "evidence" ? ["capture", "select", "prepare"] : key === "expansion" ? ["expand"] : key === "analyzer" ? ["transform", "analyze"] : ["capture", "prepare"];
      const attributes = key === "refinement" ? ["kind", "maxTokens"] : key === "sourcePredicate" ? ["kind"] : key === "aggregation" ? ["fieldType"] : key === "expansion" ? ["kind", "maxTokens", "policy"] : key === "analyzer" ? ["kind", "id"] : [];
      const handles = object(data[key], `addons.${key}`, [...methods, ...attributes]);
      if (key === "analyzer") {
        methods = handles.kind === "single-token-transform" ? ["transform"] : handles.kind === "identifier-tokenizer" ? ["analyze"] : [];
        if (!methods.length)
          invalid(code, "addons.analyzer");
        keysOnly(handles, [...methods, ...attributes], code, "addons.analyzer");
      }
      for (const method of methods) {
        const callback = handles[method];
        if (typeof callback !== "function")
          invalid(code, `addons.${key}`);
        handles[method] = callback.bind(data[key]);
      }
      if (key === "refinement" && (handles.kind !== "exact-token-sequence" && handles.kind !== "ordered-token-groups" || integer3(handles.maxTokens, "addons.maxTokens", 1) > DEFAULT_LIMITS.maxQueryTokens))
        invalid(code, "addons.refinement");
      if (key === "sourcePredicate" && handles.kind !== "source-substring")
        invalid(code, "addons.sourcePredicate");
      if (key === "expansion") {
        if (handles.kind !== "weighted-token-alternatives" || integer3(handles.maxTokens, "addons.maxTokens", 1) > DEFAULT_LIMITS.maxQueryTokens)
          invalid(code, "addons.expansion");
        handles.policy = id(handles.policy, "addons.expansion.policy");
      }
      if (key === "analyzer") {
        handles.id = id(handles.id, "addons.analyzer.id");
        if (handles.id === "basic-v1")
          invalid(code, "addons.analyzer.id");
        if (handles.kind === "identifier-tokenizer" !== (handles.id === "code-identifiers-v1"))
          invalid(code, "addons.analyzer.id");
      }
      if (key === "aggregation" && (handles.fieldType !== "string" || fields.some((field2) => schema.metadata[field2]?.type !== handles.fieldType)))
        invalid(code, "addons.aggregation");
      implementations[key] = Object.freeze(handles);
    }
    let codec;
    if (has(raw, "codec")) {
      const value = object(raw.codec, "addons.codec", ["id", "version"]);
      codec = Object.freeze({ id: id(value.id, "addons.codec"), version: integer3(value.version, "addons.codec", 1) });
    }
    const manifest = Object.freeze({
      id: name,
      version,
      contractVersion: 1,
      roles: Object.freeze(roles),
      provides: references(raw.provides, "addons.provides"),
      requires: references(raw.requires, "addons.requires"),
      dataRequirements: Object.freeze({ fields: Object.freeze(fields.sort()), source: flag(requirements.source, "addons.source"), positions: flag(requirements.positions, "addons.positions"), offsets: flag(requirements.offsets, "addons.offsets"), metadata }),
      indexEffect: participantRole ? "transactional" : analyzerRole ? "analysis" : "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: execution.worker, ...workerRegistration ? { workerRegistration } : {} }),
      limits: ownedLimits,
      costs: Object.freeze({ importedCode: string2(costs.importedCode, "addons.costs", 1024), retainedRepresentation: string2(costs.retainedRepresentation, "addons.costs", 1024), transientWork: string2(costs.transientWork, "addons.costs", 1024), externalResources: "none" }),
      ...codec ? { codec } : {}
    });
    const captured = Object.freeze({ manifest, ...implementations });
    if (captured.analyzer && (manifest.provides.length !== 1 || manifest.provides[0].id !== `analyzer:${captured.analyzer.id}` || manifest.requires.length !== 0))
      invalid(code, "addons.analyzer");
    registrations.set(name, captured);
    if (!manifest.provides.length)
      invalid(code, "addons.provides");
    for (const provided of manifest.provides) {
      if (has(providers, provided.id))
        invalid(code, "addons.providers");
      providers[provided.id] = captured;
    }
  }
  const ordered = [], visited = /* @__PURE__ */ new Set(), active = /* @__PURE__ */ new Set();
  function visit(registration) {
    const { manifest } = registration;
    if (visited.has(manifest.id))
      return;
    if (active.has(manifest.id))
      invalid(code, "addons.cycle");
    active.add(manifest.id);
    for (const requirement of [...manifest.requires].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0)) {
      const provider = providers[requirement.id];
      if (!provider)
        invalid("MISSING_CAPABILITY", "addons.requires");
      visit(provider);
    }
    const data = manifest.dataRequirements;
    if (registration.refinement?.kind === "ordered-token-groups") {
      if (!data.positions || data.source || data.offsets || data.metadata || !data.fields.length || registration.participant || manifest.codec || manifest.requires.some((ref) => !data.fields.some((field2) => ref.id === `positions:${field2}`)))
        invalid(code, "addons.ordered.data");
      for (const field2 of data.fields)
        if (!manifest.requires.some((ref) => ref.id === `positions:${field2}`) || !providers[`positions:${field2}`]?.participant)
          invalid("MISSING_CAPABILITY", "addons.ordered.positions");
    }
    if ((data.source || data.positions) && registration.refinement)
      for (const field2 of data.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field2}`) && !!providers[`${kind}:${field2}`]?.participant;
        if (!(data.source && present("source") || data.positions && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    if (registration.sourcePredicate) {
      if (manifest.requires.some((ref) => !data.fields.some((field2) => ref.id === `source:${field2}`)))
        invalid("INCOMPATIBLE_CAPABILITY", "addons.sourcePredicate.requires");
      for (const field2 of data.fields) {
        if (!manifest.requires.some((ref) => ref.id === `source:${field2}`) || !providers[`source:${field2}`]?.participant)
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    }
    if (registration.evidence && (data.source || data.positions || data.offsets))
      for (const field2 of data.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field2}`) && !!providers[`${kind}:${field2}`]?.participant;
        if (!(data.source && present("source") || data.offsets && present("offsets") || data.positions && !data.offsets && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    active.delete(manifest.id);
    visited.add(manifest.id);
    ordered.push(registration);
  }
  for (const name of [...registrations.keys()].sort())
    visit(registrations.get(name));
  return Object.freeze({ ordered: Object.freeze(ordered), providers: Object.freeze(providers) });
}

// dist/core/contracts/schema.js
function captureSchema(input, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const schema = ownObject(input, "INVALID_SCHEMA", "schema", admission);
  keysOnly(schema, ["text", "metadata"], "INVALID_SCHEMA", "schema");
  const text = ownObject(schema.text, "INVALID_SCHEMA", "schema.text", admission);
  const metadata = has(schema, "metadata") ? ownObject(schema.metadata, "INVALID_SCHEMA", "schema.metadata", admission) : /* @__PURE__ */ Object.create(null);
  const textNames = Object.keys(text);
  const metadataNames = Object.keys(metadata);
  if (textNames.length === 0)
    invalid("INVALID_SCHEMA", "schema.text");
  bound(textNames.length, limits.maxTextFields, "schema.text");
  bound(metadataNames.length, limits.maxMetadataFields, "schema.metadata");
  const ownedText = /* @__PURE__ */ Object.create(null);
  const ownedMetadata = /* @__PURE__ */ Object.create(null);
  for (const [group, names] of [[text, textNames], [metadata, metadataNames]]) {
    for (const name of names) {
      if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(name) || name === "constructor" || name === "prototype")
        invalid("INVALID_SCHEMA", "schema.fields");
      bound(name.length, limits.maxFieldNameCodeUnits, "schema.fields");
      if (has(text, name) && has(metadata, name))
        invalid("INVALID_SCHEMA", "schema.fields");
      const path = `schema.${group === text ? "text" : "metadata"}.${name}`;
      const field2 = ownObject(group[name], "INVALID_SCHEMA", path, admission);
      if (group === text) {
        keysOnly(field2, ["boost"], "INVALID_SCHEMA", path);
        const boost = has(field2, "boost") ? field2.boost : 1;
        if (typeof boost !== "number" || !Number.isFinite(boost) || boost <= 0 || boost > 16)
          invalid("INVALID_SCHEMA", `${path}.boost`);
        ownedText[name] = Object.freeze({ boost });
      } else {
        keysOnly(field2, ["type", "multi", "nullable"], "INVALID_SCHEMA", path);
        if (field2.type !== "string" && field2.type !== "number" && field2.type !== "boolean")
          invalid("INVALID_SCHEMA", `${path}.type`);
        const multi = has(field2, "multi") ? field2.multi : false;
        const nullable = has(field2, "nullable") ? field2.nullable : false;
        if (typeof multi !== "boolean" || typeof nullable !== "boolean")
          invalid("INVALID_SCHEMA", path);
        ownedMetadata[name] = Object.freeze({ type: field2.type, multi, nullable });
      }
    }
  }
  return Object.freeze({ text: Object.freeze(ownedText), metadata: Object.freeze(ownedMetadata) });
}
function captureConfiguration(input) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const config = ownObject(input, "INVALID_OPTIONS", "config", admission);
  keysOnly(config, ["schema", "limits", "analyzer", "addons"], "INVALID_OPTIONS", "config");
  if (has(config, "limits") && config.limits === void 0)
    invalid("INVALID_OPTIONS", "config.limits");
  const limits = has(config, "limits") ? resolveLimits(config.limits, admission) : DEFAULT_LIMITS;
  const schema = captureSchema(config.schema, limits, admission);
  let selected = BASIC_ANALYZER.id;
  if (has(config, "analyzer")) {
    const analyzer = ownObject(config.analyzer, "INVALID_OPTIONS", "config.analyzer", admission);
    keysOnly(analyzer, ["id", "environmentProfile"], "INVALID_OPTIONS", "config.analyzer");
    if (typeof analyzer.id !== "string" || typeof analyzer.environmentProfile !== "string")
      invalid("INVALID_OPTIONS", "config.analyzer");
    if (!/^[A-Za-z][A-Za-z0-9:._-]{0,127}$/.test(analyzer.id))
      invalid("INVALID_OPTIONS", "config.analyzer");
    selected = analyzer.id;
    if (analyzer.environmentProfile !== BASIC_ANALYZER.environmentProfile)
      invalid("INCOMPATIBLE_CAPABILITY", "config.analyzer");
  }
  const capabilities = has(config, "addons") ? captureRegistrations(config.addons, { schema, limits, admission }) : void 0;
  const provider = capabilities?.providers[`analyzer:${selected}`];
  if (selected !== BASIC_ANALYZER.id && (!provider?.analyzer || provider.analyzer.id !== selected))
    invalid("MISSING_CAPABILITY", "config.analyzer");
  bound(admission.count, limits.maxAdmissionEntries, "config");
  return Object.freeze({ schema, limits, analyzer: selected === BASIC_ANALYZER.id ? BASIC_ANALYZER : Object.freeze({ id: selected, environmentProfile: "unqualified" }), ...capabilities?.ordered.length ? { capabilities } : {} });
}

// dist/core/capabilities/participants.js
function initializeParticipants(configuration) {
  const states = /* @__PURE__ */ Object.create(null);
  const participants = [];
  for (const registration of configuration.capabilities?.ordered ?? []) {
    const handle = registration.participant;
    if (!handle)
      continue;
    const id = registration.manifest.id;
    states[id] = handle.initialize(configuration);
    participants.push(Object.freeze({ id, maxWorkUnits: Math.min(registration.manifest.limits.maxWorkUnits, configuration.limits.maxMutationWorkUnits), *prepare(previous, context) {
      const removedIds = [];
      for (const change of context.changes)
        if (change.previous && !change.next) {
          yield { workUnits: change.previous.id.length + 1 };
          removedIds.push(change.previous.id);
        }
      const request = Object.freeze({ ...context.analyze ? { analyze: context.analyze } : {}, kind: context.kind, previousRevision: context.previous.revision, revision: context.core.revision, analyzer: configuration.analyzer, records: context.records, removedIds: Object.freeze(removedIds) });
      const cursor = handle.prepare(previous, request);
      try {
        for (; ; ) {
          const step = cursor.next();
          if (step.done)
            return step.value;
          yield step.value;
        }
      } finally {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    } }));
  }
  return Object.freeze({ states: Object.freeze(states), participants: Object.freeze(participants) });
}

// dist/core/index/directory.js
var DIRECTORY_SLOTS = 256;
function bucketOf(key) {
  let hash = 2166136261;
  for (let i = 0; i < key.length; i++)
    hash = Math.imul(hash ^ key.charCodeAt(i), 16777619);
  return String((hash >>> 0) % DIRECTORY_SLOTS);
}
function directoryGet(directory, key) {
  return directory.buckets[bucketOf(key)]?.[key];
}
function* directoryEntries(directory) {
  for (const bucket of Object.values(directory.buckets)) {
    for (const key of Object.keys(bucket))
      yield [key, bucket[key]];
  }
}

// dist/core/index/staging.js
function emptyDirectory() {
  return Object.freeze({ size: 0, buckets: Object.freeze(/* @__PURE__ */ Object.create(null)) });
}
var DirectoryStage = class {
  original;
  charge;
  counts;
  pointers;
  touched = /* @__PURE__ */ new Map();
  count;
  sealed = false;
  constructor(original, charge, counts) {
    this.original = original;
    this.charge = charge;
    this.counts = counts;
    this.count = original.size;
  }
  get size() {
    return this.count;
  }
  get(key) {
    return (this.pointers ?? this.original.buckets)[bucketOf(key)]?.[key];
  }
  *bucket(slot) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    if (!this.pointers) {
      const pointers = /* @__PURE__ */ Object.create(null);
      if (this.counts)
        this.counts.directories++;
      for (const slot2 of Object.keys(this.original.buckets)) {
        yield this.charge(1);
        pointers[slot2] = this.original.buckets[slot2];
        if (this.counts)
          this.counts.directoryPointers++;
      }
      this.pointers = pointers;
    }
    const cached = this.touched.get(slot);
    if (cached)
      return cached;
    const bucket = /* @__PURE__ */ Object.create(null);
    if (this.counts)
      this.counts.buckets++;
    const previous = this.original.buckets[slot];
    for (const entry of Object.keys(previous ?? {})) {
      yield this.charge(entry.length + 1);
      bucket[entry] = previous[entry];
      if (this.counts)
        this.counts.bucketEntries++;
    }
    this.touched.set(slot, bucket);
    this.pointers[slot] = bucket;
    return bucket;
  }
  *set(key, value) {
    yield this.charge(key.length + 1);
    const bucket = yield* this.bucket(bucketOf(key));
    if (!Object.hasOwn(bucket, key)) {
      this.count++;
      if (this.counts)
        this.counts.insertions++;
    }
    bucket[key] = value;
    if (this.counts)
      this.counts.writes++;
  }
  *delete(key) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    yield this.charge(key.length + 1);
    const slot = bucketOf(key);
    if ((this.pointers ?? this.original.buckets)[slot]?.[key] === void 0)
      return;
    const bucket = yield* this.bucket(slot);
    delete bucket[key];
    this.count--;
    if (this.counts)
      this.counts.deletes++;
  }
  *finish() {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    this.sealed = true;
    if (!this.pointers)
      return this.original;
    for (const [slot, bucket] of this.touched) {
      const keys = Object.keys(bucket);
      for (const key of keys)
        yield this.charge(key.length + 1);
      if (keys.length)
        Object.freeze(bucket);
      else
        delete this.pointers[slot];
    }
    for (const slot of Object.keys(this.pointers)) {
      void slot;
      yield this.charge(1);
    }
    return Object.freeze({ size: this.count, buckets: Object.freeze(this.pointers) });
  }
};

// dist/core/limits/work.js
var WorkBudget = class {
  maximum;
  policy = "work-v1";
  used = 0;
  constructor(maximum) {
    this.maximum = maximum;
  }
  get consumed() {
    return this.used;
  }
  charge(units) {
    if (!Number.isSafeInteger(units) || units < 0)
      invalid("INTERNAL_ERROR", "work.units");
    this.used += units;
    if (!Number.isSafeInteger(this.used) || this.used > this.maximum)
      invalid("WORK_LIMIT_EXCEEDED", "work");
  }
};
function validateExpansionCounts(perGroup, wholeQuery, limits) {
  for (const count of [perGroup, wholeQuery])
    if (!Number.isSafeInteger(count) || count < 0)
      invalid("INTERNAL_ERROR", "expansions");
  bound(perGroup, limits.maxExpansionsPerGroup, "expansions.group");
  bound(wholeQuery, limits.maxQueryExpansions, "expansions.query");
}

// dist/core/analyzer/identifier.js
function* runIdentifierAnalysis(handle, budget, value, valueIndex, limits, code, mode, check) {
  bound(value.length, limits.maxTextCodeUnitsPerValue, "analysis.value");
  const charge = (workUnits) => {
    check?.();
    budget.charge(workUnits);
    return { workUnits };
  };
  for (const step of scanUnicode(value, code, "analysis.value"))
    yield charge(step.workUnits);
  const cursor = handle.analyze(value, valueIndex, limits, code, mode);
  let original, position = 0, previousEnd = 0, componentEnd = 0, occurrences = 0;
  const terms = /* @__PURE__ */ new Set();
  const data = (input, keys) => {
    if (typeof input !== "object" || input === null || Array.isArray(input) || ![Object.prototype, null].includes(Object.getPrototypeOf(input)))
      invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
    const names = Reflect.ownKeys(input);
    if (names.length > keys.length)
      invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
    const result = /* @__PURE__ */ Object.create(null);
    for (const key of names) {
      if (typeof key !== "string" || !keys.includes(key))
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
      const property = Object.getOwnPropertyDescriptor(input, key);
      if (!property || !("value" in property))
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
      result[key] = property.value;
    }
    return result;
  };
  const boundary = (offset) => Number.isSafeInteger(offset) && offset >= 0 && offset <= value.length && !(offset > 0 && offset < value.length && value.charCodeAt(offset) >= 56320 && value.charCodeAt(offset) <= 57343);
  try {
    for (; ; ) {
      const next = cursor.next();
      check?.();
      if (next.done)
        break;
      const step = data(next.value, ["workUnits", "token"]);
      if (!Number.isSafeInteger(step.workUnits) || step.workUnits < 1)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.work");
      yield charge(step.workUnits);
      if (!Object.hasOwn(step, "token"))
        continue;
      const owned = data(step.token, ["term", "valueIndex", "position", "start", "end", "kind", "original"]);
      if (Object.hasOwn(owned, "original"))
        owned.original = Object.freeze(data(owned.original, ["term", "start", "end"]));
      const token = Object.freeze(owned);
      if (token.valueIndex !== valueIndex || !boundary(token.start) || !boundary(token.end) || token.end <= token.start || token.kind !== "original" && token.kind !== "component" || typeof token.term !== "string" || !token.term.length)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
      bound(token.end - token.start, limits.maxRawTokenCodeUnits, "analysis.rawToken");
      bound(token.term.length, limits.maxTermCodeUnits, "analysis.term");
      bound(++occurrences, limits.maxTokensPerRecord, "analysis.tokens");
      for (const scan of scanUnicode(token.term, "INCOMPATIBLE_CAPABILITY", "analysis.term"))
        yield charge(scan.workUnits);
      yield charge(token.end - token.start + token.term.length + 1);
      if (value.slice(token.start, token.end).normalize("NFKC").toLowerCase() !== token.term)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.term");
      if (token.kind === "original") {
        if (token.original !== void 0 || token.position !== position++ || token.start < previousEnd)
          invalid("INCOMPATIBLE_CAPABILITY", "analysis.original");
        previousEnd = token.end;
        componentEnd = token.start;
        original = token;
        terms.clear();
        terms.add(token.term);
      } else {
        const origin = token.original;
        if (mode !== "index" || !original || !origin || !Object.isFrozen(origin) || Object.keys(origin).length !== 3 || !Object.keys(origin).every((key) => ["term", "start", "end"].includes(key)) || origin.term !== original.term || origin.start !== original.start || origin.end !== original.end || token.position !== original.position || token.start < componentEnd || token.end > original.end || terms.has(token.term))
          invalid("INCOMPATIBLE_CAPABILITY", "analysis.component");
        componentEnd = token.end;
        terms.add(token.term);
      }
      yield charge(1);
      yield { workUnits: 1, token };
    }
  } finally {
    try {
      cursor.return(void 0);
    } catch {
    }
  }
}

// dist/core/analyzer/selected.js
function createAnalysis(configuration, check) {
  if (configuration.analyzer.id === BASIC_ANALYZER.id)
    return analyzeValue;
  const registration = configuration.capabilities?.providers[`analyzer:${configuration.analyzer.id}`];
  if (!registration?.analyzer || registration.analyzer.id !== configuration.analyzer.id)
    invalid("MISSING_CAPABILITY", "analysis.analyzer");
  const handle = registration.analyzer, budget = new WorkBudget(registration.manifest.limits.maxWorkUnits);
  if (handle.kind === "identifier-tokenizer")
    return (value, valueIndex, limits, code = "INVALID_RECORD", mode = "index") => runIdentifierAnalysis(handle, budget, value, valueIndex, limits, code, mode, check);
  return function* (value, valueIndex, limits, code = "INVALID_RECORD") {
    for (const step of analyzeValue(value, valueIndex, limits, code)) {
      if (!step.token) {
        yield step;
        continue;
      }
      yield { workUnits: step.workUnits };
      const cursor = handle.transform(step.token.term);
      let term;
      try {
        for (; ; ) {
          const transformed = cursor.next();
          check?.();
          if (transformed.done) {
            term = transformed.value;
            break;
          }
          budget.charge(transformed.value.workUnits);
          yield transformed.value;
        }
      } finally {
        try {
          cursor.return("");
        } catch {
        }
      }
      if (typeof term !== "string" || !term.length)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.term");
      bound(term.length, limits.maxTermCodeUnits, "analysis.term");
      for (const scan of scanUnicode(term, "INCOMPATIBLE_CAPABILITY", "analysis.term")) {
        budget.charge(scan.workUnits);
        yield scan;
      }
      const units = term.length * 2 + 1;
      budget.charge(units);
      yield { workUnits: units };
      if (term.normalize("NFKC").toLowerCase() !== term)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.term");
      yield { workUnits: 1, token: Object.freeze({ ...step.token, term }) };
    }
  };
}

// dist/core/contracts/record.js
function captureId(input, limits, code, path) {
  const id = stringValue(input, limits.maxIdCodeUnits, code, path);
  if (!id.length)
    invalid(code, path);
  return id;
}
function captureScalar(input, field2, limits, code, path) {
  if (input === null && field2.nullable)
    return null;
  if (typeof input !== field2.type)
    invalid(code, path);
  if (typeof input === "number") {
    if (!Number.isFinite(input))
      invalid(code, path);
    return input === 0 ? 0 : input;
  }
  if (typeof input === "string")
    return stringValue(input, limits.maxMetadataStringCodeUnits, code, path);
  if (typeof input === "boolean")
    return input;
  return invalid(code, path);
}
function captureRecord(input, schema, limits, admission = new Admission(limits.maxAdmissionEntries), path = "record") {
  const record2 = ownObject(input, "INVALID_RECORD", path, admission);
  keysOnly(record2, ["id", "text", "metadata"], "INVALID_RECORD", path);
  const id = captureId(record2.id, limits, "INVALID_RECORD", `${path}.id`);
  const textInput = ownObject(record2.text, "INVALID_RECORD", `${path}.text`, admission);
  const metadataInput = has(record2, "metadata") ? ownObject(record2.metadata, "INVALID_RECORD", `${path}.metadata`, admission) : /* @__PURE__ */ Object.create(null);
  const text = /* @__PURE__ */ Object.create(null);
  const metadata = /* @__PURE__ */ Object.create(null);
  let textCodeUnits = 0;
  let metadataCodeUnits = 0;
  for (const name of Object.keys(textInput)) {
    if (!has(schema.text, name))
      invalid("INVALID_RECORD", `${path}.text`);
    const fieldPath = `${path}.text.${name}`;
    const raw = textInput[name];
    const values = typeof raw === "string" ? [raw] : ownArray(raw, limits.maxTextValuesPerField, "INVALID_RECORD", fieldPath, admission);
    text[name] = Object.freeze(values.map((value, i) => {
      const string2 = stringValue(value, limits.maxTextCodeUnitsPerValue, "INVALID_RECORD", `${fieldPath}[${i}]`);
      textCodeUnits += string2.length;
      bound(textCodeUnits, limits.maxTextCodeUnitsPerRecord, `${path}.text`);
      return string2;
    }));
  }
  for (const name of Object.keys(metadataInput)) {
    const field2 = schema.metadata[name];
    if (!field2)
      invalid("INVALID_RECORD", `${path}.metadata`);
    const fieldPath = `${path}.metadata.${name}`;
    const value = metadataInput[name];
    const values = field2.multi ? ownArray(value, limits.maxMetadataValuesPerField, "INVALID_RECORD", fieldPath, admission) : [value];
    const owned = values.map((item, i) => {
      const scalar = captureScalar(item, field2, limits, "INVALID_RECORD", `${fieldPath}[${i}]`);
      if (typeof scalar === "string")
        metadataCodeUnits += scalar.length;
      bound(metadataCodeUnits, limits.maxMetadataCodeUnitsPerRecord, `${path}.metadata`);
      return scalar;
    });
    metadata[name] = field2.multi ? Object.freeze(owned) : owned[0];
  }
  return Object.freeze({ id, text: Object.freeze(text), metadata: Object.freeze(metadata), textCodeUnits });
}
function captureBatch(input, schema, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const values = ownArray(input, limits.maxMutationBatch, "INVALID_RECORD", "records", admission);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const record2 = captureRecord(value, schema, limits, admission, `records[${i}]`);
    if (ids.has(record2.id))
      invalid("INVALID_RECORD", `records[${i}].id`);
    ids.add(record2.id);
    return record2;
  }));
}
function captureRemoveIds(input, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const values = typeof input === "string" ? [input] : ownArray(input, limits.maxMutationBatch, "INVALID_OPTIONS", "ids", admission);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const id = captureId(value, limits, "INVALID_OPTIONS", `ids[${i}]`);
    if (ids.has(id))
      invalid("INVALID_OPTIONS", `ids[${i}]`);
    ids.add(id);
    return id;
  }));
}
function* analyzeRecord(record2, limits, counts, analyze = analyzeValue) {
  if (counts)
    counts.records++;
  yield* scanUnicode(record2.id, "INVALID_RECORD", "record.id");
  for (const [field2, value] of Object.entries(record2.metadata)) {
    for (const item of Array.isArray(value) ? value : [value]) {
      if (typeof item === "string")
        yield* scanUnicode(item, "INVALID_RECORD", `record.metadata.${field2}`);
    }
  }
  let tokens = 0;
  for (const [field2, values] of Object.entries(record2.text)) {
    for (let i = 0; i < values.length; i++) {
      if (counts) {
        counts.values++;
        counts.textCodeUnits += values[i].length;
      }
      for (const step of analyze(values[i], i, limits)) {
        if (step.token) {
          bound(++tokens, limits.maxTokensPerRecord, "record.tokens");
          yield { ...step, field: field2 };
        } else
          yield step;
      }
    }
  }
}
function canonicalMetadata(record2) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const [name, value] of Object.entries(record2.metadata)) {
    result[name] = Array.isArray(value) ? Object.freeze([...new Set(value)]) : value;
  }
  return Object.freeze(result);
}

// dist/core/capabilities/capture.js
function captureExtension(capture, input, admission, limits, maximum) {
  const maxCodeUnits = Math.min(maximum, limits.maxQueryCodeUnits);
  const captured = capture(input, Object.freeze({ admission, limits, maxCodeUnits }));
  if (!captured || !Number.isSafeInteger(captured.codeUnits) || captured.codeUnits < 0 || captured.value !== null && typeof captured.value === "object" && !Object.isFrozen(captured.value))
    invalid("INCOMPATIBLE_CAPABILITY", "extensions.capture");
  bound(captured.codeUnits, maxCodeUnits, "extensions.payload");
  return captured;
}

// dist/core/contracts/options.js
function integer(value, minimum, maximum, path) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
    invalid("INVALID_OPTIONS", path);
  bound(value, maximum, path);
  return value;
}
function captureOptions(input = {}, limits, search, admission = new Admission(limits.maxAdmissionEntries), capabilities) {
  const data = ownObject(input, "INVALID_OPTIONS", "options", admission);
  keysOnly(data, search ? ["signal", "deadlineMs", "limit", "offset", "extensions"] : ["signal", "deadlineMs"], "INVALID_OPTIONS", "options");
  const deadlineMs = has(data, "deadlineMs") ? integer(data.deadlineMs, 1, limits.maxDeadlineMs, "options.deadlineMs") : Math.min(3e4, limits.maxDeadlineMs);
  let signal;
  if (has(data, "signal")) {
    const candidate = data.signal;
    if (typeof candidate !== "object" || candidate === null || typeof candidate.aborted !== "boolean" || typeof candidate.addEventListener !== "function" || typeof candidate.removeEventListener !== "function")
      invalid("INVALID_OPTIONS", "options.signal");
    signal = candidate;
  }
  const base = { deadlineMs, ...signal ? { signal } : {} };
  if (!search)
    return Object.freeze(base);
  const offset = has(data, "offset") ? integer(data.offset, 0, limits.maxDocuments, "options.offset") : 0;
  const limit = has(data, "limit") ? integer(data.limit, 0, limits.maxHits, "options.limit") : Math.min(20, limits.maxHits, limits.maxDocuments - offset);
  bound(offset + limit, limits.maxDocuments, "options.page");
  let extensions;
  if (has(data, "extensions")) {
    const captured = ownObject(data.extensions, "INVALID_OPTIONS", "options.extensions", admission);
    let units = 0;
    for (const capability of Object.keys(captured)) {
      const registration = capabilities?.providers[capability];
      const handler = registration?.evidence ?? registration?.aggregation ?? registration?.dictionary;
      if (!registration || !handler)
        invalid("MISSING_CAPABILITY", "options.extensions");
      const payload = captureExtension(handler.capture, captured[capability], admission, limits, registration.manifest.limits.maxPayloadCodeUnits);
      units += capability.length + payload.codeUnits;
      bound(units, limits.maxQueryCodeUnits, "options.extensions");
      captured[capability] = payload.value;
    }
    if (Object.keys(captured).length)
      extensions = Object.freeze(captured);
  }
  return Object.freeze({ ...base, offset, limit, ...extensions ? { extensions } : {} });
}

// dist/core/mutations/capture.js
function captureMutation(configuration, kind, input, options) {
  const { schema, limits } = configuration, admission = new Admission(limits.maxAdmissionEntries);
  const capturedOptions = captureOptions(options, limits, false, admission);
  if (capturedOptions.signal?.aborted)
    invalid("CANCELLED", "options.signal");
  let records = [], ids = [];
  switch (kind) {
    case "add":
    case "replace":
      records = Object.freeze([captureRecord(input, schema, limits, admission)]);
      break;
    case "addMany":
      records = captureBatch(input, schema, limits, admission);
      break;
    case "remove":
      ids = captureRemoveIds(input, limits, admission);
      break;
    case "clear":
      if (input !== void 0)
        invalid("INVALID_OPTIONS", "clear");
      break;
    default:
      invalid("INVALID_OPTIONS", "mutation.kind");
  }
  return Object.freeze({ kind, records: Object.freeze(records), ids: Object.freeze(ids), options: capturedOptions });
}

// dist/core/mutations/delta.js
function nonnegative(value, path) {
  if (!Number.isSafeInteger(value) || value < 0)
    invalid("INTERNAL_ERROR", path);
}
var CoreDelta = class {
  old;
  charge;
  diagnostics;
  documents;
  fields = /* @__PURE__ */ new Map();
  counts;
  constructor(old, charge, diagnostics) {
    this.old = old;
    this.charge = charge;
    this.diagnostics = diagnostics;
    validateStateCounts(old.counts, old.configuration.limits);
    if (old.documents.size !== old.counts.documents)
      invalid("INTERNAL_ERROR", "state.documents");
    this.counts = { ...old.counts };
    this.documents = new DirectoryStage(old.documents, charge, diagnostics?.documents);
  }
  field(name) {
    let field2 = this.fields.get(name);
    if (!field2) {
      const original = this.old.fields[name];
      if (!original)
        invalid("INTERNAL_ERROR", "reverse.field");
      nonnegative(original.documents, "field.documents");
      nonnegative(original.length, "field.length");
      if (original.documents > this.old.documents.size || original.length < original.documents)
        invalid("INTERNAL_ERROR", "field.statistics");
      field2 = { documents: original.documents, length: original.length, terms: new DirectoryStage(original.terms, this.charge, this.diagnostics?.dictionary), cache: /* @__PURE__ */ new Map() };
      this.fields.set(name, field2);
    }
    return field2;
  }
  term(field2, term) {
    let staged = field2.cache.get(term);
    if (!staged) {
      const original = field2.terms.get(term);
      if (original) {
        nonnegative(original.df, "term.df");
        nonnegative(original.frequency, "term.frequency");
        if (!original.df || original.df !== original.postings.size || original.frequency < original.df)
          invalid("INTERNAL_ERROR", "term.statistics");
      }
      staged = { ...original ? { original } : {}, df: original?.df ?? 0, frequency: original?.frequency ?? 0, postings: new DirectoryStage(original?.postings ?? emptyDirectory(), this.charge, this.diagnostics?.postings) };
      field2.cache.set(term, staged);
    }
    return staged;
  }
  *contribute(document2, sign) {
    nonnegative(document2.textCodeUnits, "reverse.textCodeUnits");
    this.counts.textCodeUnits += sign * document2.textCodeUnits;
    for (const [name, reverse] of Object.entries(document2.fields)) {
      yield this.charge(name.length + 2);
      const field2 = this.field(name);
      nonnegative(reverse.length, "reverse.length");
      if (!reverse.length)
        invalid("INTERNAL_ERROR", "reverse.length");
      field2.documents += sign;
      field2.length += sign * reverse.length;
      this.counts.tokens += sign * reverse.length;
      if (this.diagnostics)
        this.diagnostics.fieldUpdates++;
      let length = 0;
      for (const [key, tf] of Object.entries(reverse.terms)) {
        yield this.charge(key.length + document2.id.length + 4);
        nonnegative(tf, "reverse.tf");
        if (!tf)
          invalid("INTERNAL_ERROR", "reverse.tf");
        length += tf;
        const term = this.term(field2, key), current = term.postings.get(document2.id);
        if (sign < 0) {
          if (current !== tf)
            invalid("INTERNAL_ERROR", "reverse.posting");
          yield* term.postings.delete(document2.id);
        } else {
          if (current !== void 0)
            invalid("INTERNAL_ERROR", "posting.duplicate");
          yield* term.postings.set(document2.id, tf);
        }
        term.df += sign;
        term.frequency += sign * tf;
        this.counts.postingEntries += sign;
        if (this.diagnostics)
          this.diagnostics.termUpdates++;
      }
      if (length !== reverse.length)
        invalid("INTERNAL_ERROR", "reverse.length");
    }
  }
  *apply(delta) {
    if (delta.previous) {
      yield* this.contribute(delta.previous, -1);
      yield* this.documents.delete(delta.previous.id);
      this.counts.documents--;
    }
    if (delta.next) {
      yield* this.contribute(delta.next, 1);
      yield* this.documents.set(delta.next.id, delta.next);
      this.counts.documents++;
    }
  }
  *finish() {
    const fields = /* @__PURE__ */ Object.create(null);
    for (const name of Object.keys(this.old.fields)) {
      yield this.charge(1);
      const field2 = this.fields.get(name);
      if (!field2) {
        fields[name] = this.old.fields[name];
        continue;
      }
      for (const [key, term] of field2.cache) {
        yield this.charge(key.length + 3);
        nonnegative(term.df, "term.df");
        nonnegative(term.frequency, "term.frequency");
        if (term.df !== term.postings.size || term.df > field2.documents || term.frequency < term.df || term.frequency > field2.length || !term.df && term.frequency !== 0)
          invalid("INTERNAL_ERROR", "term.statistics");
        if (!term.df) {
          if (term.original) {
            yield* field2.terms.delete(key);
            this.counts.dictionaryEntries--;
          }
        } else {
          const postings = yield* term.postings.finish();
          yield* field2.terms.set(key, Object.freeze({ df: term.df, frequency: term.frequency, postings }));
          if (!term.original)
            this.counts.dictionaryEntries++;
        }
      }
      nonnegative(field2.documents, "field.documents");
      nonnegative(field2.length, "field.length");
      if (field2.documents > this.counts.documents || field2.length < field2.documents || !field2.documents && field2.length !== 0)
        invalid("INTERNAL_ERROR", "field.statistics");
      const terms = yield* field2.terms.finish();
      if (field2.documents === 0 !== (terms.size === 0))
        invalid("INTERNAL_ERROR", "field.terms");
      fields[name] = Object.freeze({ documents: field2.documents, length: field2.length, terms });
    }
    const documents = yield* this.documents.finish();
    yield this.charge(5);
    validateStateCounts(this.counts, this.old.configuration.limits);
    if (documents.size !== this.counts.documents)
      invalid("INTERNAL_ERROR", "state.documents");
    return { documents, fields: Object.freeze(fields), counts: Object.freeze(this.counts) };
  }
};
function* clearedCore(old, charge) {
  const fields = /* @__PURE__ */ Object.create(null);
  for (const name of Object.keys(old.fields)) {
    yield charge(1);
    fields[name] = Object.freeze({ documents: 0, length: 0, terms: emptyDirectory() });
  }
  yield charge(5);
  return { documents: emptyDirectory(), fields: Object.freeze(fields), counts: Object.freeze({ documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 }) };
}

// dist/core/mutations/document.js
function* prepareDocument(record2, limits, charge, counts, analyze = analyzeValue) {
  for (const values of Object.values(record2.text)) {
    yield charge(1);
    for (let i = 0; i < values.length; i++)
      yield charge(1);
  }
  const fields = /* @__PURE__ */ Object.create(null);
  for (const step of analyzeRecord(record2, limits, counts, analyze)) {
    yield charge(step.workUnits);
    if (step.token) {
      yield charge(step.token.term.length + 2);
      const field2 = fields[step.field] ??= { length: 0, terms: /* @__PURE__ */ Object.create(null) };
      field2.length++;
      field2.terms[step.token.term] = (field2.terms[step.token.term] ?? 0) + 1;
    }
  }
  const frozen = /* @__PURE__ */ Object.create(null);
  for (const [name, field2] of Object.entries(fields)) {
    for (const term of Object.keys(field2.terms))
      yield charge(term.length + 1);
    yield charge(1);
    frozen[name] = Object.freeze({ length: field2.length, terms: Object.freeze(field2.terms) });
  }
  for (const value of Object.values(record2.metadata)) {
    yield charge(1);
    for (const item of Array.isArray(value) ? value : [value])
      yield charge(typeof item === "string" ? item.length + 1 : 1);
  }
  const metadata = canonicalMetadata(record2);
  for (const value of Object.values(metadata))
    yield charge(Array.isArray(value) ? value.length + 1 : 1);
  return Object.freeze({ id: record2.id, textCodeUnits: record2.textCodeUnits, metadata, fields: Object.freeze(frozen) });
}

// dist/core/mutations/owner.js
var MutationOwner = class {
  #root;
  #active = false;
  participants;
  admitted = /* @__PURE__ */ new WeakSet();
  constructor(root, participants = []) {
    if (!Number.isSafeInteger(root.revision) || root.revision < 0 || !Object.isFrozen(root))
      invalid("INTERNAL_ERROR", "revision.root");
    const ids = /* @__PURE__ */ new Set();
    for (const participant of participants) {
      if (!participant.id || ids.has(participant.id) || typeof participant.prepare !== "function" || !Object.hasOwn(root.participants, participant.id))
        invalid("INCOMPATIBLE_CAPABILITY", "participants");
      ids.add(participant.id);
    }
    if (Object.keys(root.participants).length !== ids.size)
      invalid("INCOMPATIBLE_CAPABILITY", "participants");
    this.#root = root;
    this.participants = Object.freeze(participants.map((p) => {
      if (p.maxWorkUnits !== void 0 && (!Number.isSafeInteger(p.maxWorkUnits) || p.maxWorkUnits < 1))
        invalid("INCOMPATIBLE_CAPABILITY", "participants.limits");
      return Object.freeze({ id: p.id, prepare: p.prepare.bind(p), ...p.maxWorkUnits !== void 0 ? { maxWorkUnits: p.maxWorkUnits } : {} });
    }));
  }
  get root() {
    return this.#root;
  }
  /** Trusted optional adapter publication after complete bounded preparation.
   * It runs in ExecutionOwner's FIFO, with no callbacks at the commit point. */
  publishPrepared(root, previous) {
    if (this.#active || this.#root !== previous || root.configuration !== previous.configuration || !Object.isFrozen(root) || previous.revision === Number.MAX_SAFE_INTEGER || root.revision !== previous.revision + 1 || Object.keys(root.participants).length !== this.participants.length || this.participants.some((participant) => !Object.hasOwn(root.participants, participant.id)))
      invalid("INTERNAL_ERROR", "adapter.publication");
    this.#root = root;
  }
  capture(kind, input, options) {
    const request = captureMutation(this.#root.configuration, kind, input, options);
    this.admitted.add(request);
    return request;
  }
  mutate(kind, input, options) {
    return this.execute(this.capture(kind, input, options));
  }
  execute(request, control = {}) {
    if (!this.admitted.delete(request))
      invalid("INTERNAL_ERROR", "mutation.admission");
    return this.consume(request, control);
  }
  *consume(request, control) {
    if (this.#active)
      invalid("INTERNAL_ERROR", "mutation.active");
    this.#active = true;
    const old = this.#root, budget = new WorkBudget(old.configuration.limits.maxMutationWorkUnits);
    const analyze = control.analyze ?? createAnalysis(old.configuration, () => check());
    let phase = "start";
    const check = () => {
      control.checkpoint?.(phase);
      if (control.checkStop)
        control.checkStop(phase);
      else if (request.options.signal?.aborted)
        invalid("CANCELLED", "options.signal");
    };
    const charge = (workUnits) => {
      check();
      budget.charge(workUnits);
      if (control.diagnostics)
        control.diagnostics.workUnits = budget.consumed;
      return { workUnits };
    };
    const boundary = (next) => {
      phase = next;
      check();
    };
    try {
      check();
      const changes = [];
      let added = 0, replaced = 0, removed = 0;
      boundary("validation");
      if (request.kind === "remove") {
        for (const id of request.ids) {
          for (const step of scanUnicode(id, "INVALID_OPTIONS", "ids"))
            yield charge(step.workUnits);
          yield charge(id.length + 1);
          const previous = directoryGet(old.documents, id);
          if (previous) {
            changes.push(Object.freeze({ previous }));
            removed++;
          }
        }
      } else if (request.kind === "clear") {
        removed = old.documents.size;
      } else {
        for (const record2 of request.records) {
          yield charge(record2.id.length + 1);
          const previous = directoryGet(old.documents, record2.id);
          if (request.kind === "replace") {
            if (!previous)
              invalid("ID_NOT_FOUND", "record.id");
          } else if (previous)
            invalid("ID_EXISTS", "record.id");
          boundary("analysis");
          const next = yield* prepareDocument(record2, old.configuration.limits, charge, control.diagnostics?.analysis, analyze);
          changes.push(Object.freeze({ ...previous ? { previous } : {}, next }));
          if (previous)
            replaced++;
          else
            added++;
          boundary("validation");
        }
      }
      const changed = added + replaced + removed > 0;
      if (!changed) {
        const result2 = Object.freeze({ revision: old.revision, changed: false, added, replaced, removed });
        boundary("precommit");
        yield charge(1);
        check();
        return result2;
      }
      if (old.revision === Number.MAX_SAFE_INTEGER)
        invalid("REVISION_EXHAUSTED", "revision");
      boundary("staging");
      let coreData;
      if (request.kind === "clear")
        coreData = yield* clearedCore(old, charge);
      else {
        const delta = new CoreDelta(old, charge, control.diagnostics?.copies);
        for (const change of changes)
          yield* delta.apply(change);
        boundary("core");
        coreData = yield* delta.finish();
      }
      const core = Object.freeze({ ...coreData, revision: old.revision + 1, configuration: old.configuration, participants: old.participants });
      const context = Object.freeze({ analyze, kind: request.kind, previous: old, core, changes: Object.freeze(changes), records: request.records });
      const participants = /* @__PURE__ */ Object.create(null);
      for (const participant of this.participants) {
        boundary("participant");
        yield charge(participant.id.length + 1);
        const participantBudget = participant.maxWorkUnits === void 0 ? void 0 : new WorkBudget(participant.maxWorkUnits);
        const iterator = participant.prepare(old.participants[participant.id], context);
        let finished = false;
        try {
          for (; ; ) {
            const step = iterator.next();
            if (step.done) {
              participants[participant.id] = step.value;
              finished = true;
              break;
            }
            const charged = charge(step.value.workUnits);
            participantBudget?.charge(step.value.workUnits);
            yield charged;
          }
        } finally {
          if (!finished) {
            try {
              iterator.return(void 0);
            } catch {
            }
          }
        }
      }
      boundary("prepared");
      const root = Object.freeze({ ...core, participants: Object.freeze(participants) });
      const result = Object.freeze({ revision: root.revision, changed: true, added, replaced, removed });
      boundary("precommit");
      yield charge(1);
      check();
      this.#root = root;
      return result;
    } finally {
      this.#active = false;
    }
  }
};

// dist/core/contracts/query.js
function captureQuery(input, schema, limits, admission = new Admission(limits.maxAdmissionEntries), capabilities) {
  let nodes = 0;
  let lexicalUnits = 0;
  let stringUnits = 0;
  const ancestors = /* @__PURE__ */ new Set();
  function string2(value, lexical, path) {
    const text = stringValue(value, limits.maxQueryCodeUnits, "INVALID_QUERY", path);
    stringUnits += text.length;
    bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
    if (lexical) {
      lexicalUnits += text.length;
      bound(lexicalUnits, limits.maxQueryLexicalCodeUnits, "query.lexical");
    }
    return text;
  }
  function fields(value, path) {
    const names = ownArray(value, limits.maxTextFields, "INVALID_QUERY", path, admission);
    if (!names.length)
      invalid("INVALID_QUERY", path);
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(names.map((name) => {
      const selected = string2(name, false, path);
      if (!has(schema.text, selected) || seen.has(selected))
        invalid("INVALID_QUERY", path);
      seen.add(selected);
      return selected;
    }));
  }
  function node(value, depth, path) {
    bound(++nodes, limits.maxQueryNodes, "query.nodes");
    bound(depth, limits.maxQueryDepth, "query.depth");
    const data = ownObject(value, "INVALID_QUERY", path, admission);
    if (ancestors.has(value))
      invalid("INVALID_QUERY", path);
    ancestors.add(value);
    const kind = string2(data.kind, false, `${path}.kind`);
    let result;
    switch (kind) {
      case "text": {
        keysOnly(data, ["kind", "text", "operator", "fields"], "INVALID_QUERY", path);
        const operator = has(data, "operator") ? string2(data.operator, false, `${path}.operator`) : "and";
        if (operator !== "and" && operator !== "or")
          invalid("INVALID_QUERY", `${path}.operator`);
        result = {
          kind,
          text: string2(data.text, true, `${path}.text`),
          operator,
          ...has(data, "fields") ? { fields: fields(data.fields, `${path}.fields`) } : {}
        };
        break;
      }
      case "group": {
        keysOnly(data, ["kind", "variants", "fields"], "INVALID_QUERY", path);
        const variants = ownArray(data.variants, limits.maxVariantsPerGroup, "INVALID_QUERY", `${path}.variants`, admission);
        if (!variants.length)
          invalid("INVALID_QUERY", `${path}.variants`);
        const owned = variants.map((variant, i) => {
          const variantPath = `${path}.variants[${i}]`;
          const item = ownObject(variant, "INVALID_QUERY", variantPath, admission);
          keysOnly(item, ["text", "match", "weight"], "INVALID_QUERY", variantPath);
          const match = string2(item.match, false, `${variantPath}.match`);
          if (match !== "exact" && match !== "prefix")
            invalid("INVALID_QUERY", `${variantPath}.match`);
          const weight = has(item, "weight") ? item.weight : 1;
          if (typeof weight !== "number" || !Number.isFinite(weight) || weight <= 0 || weight > 1)
            invalid("INVALID_QUERY", `${variantPath}.weight`);
          return Object.freeze({ text: string2(item.text, true, `${variantPath}.text`), match, weight });
        });
        result = { kind, variants: Object.freeze(owned), ...has(data, "fields") ? { fields: fields(data.fields, `${path}.fields`) } : {} };
        break;
      }
      case "and":
      case "or": {
        keysOnly(data, ["kind", "children"], "INVALID_QUERY", path);
        const children = ownArray(data.children, limits.maxQueryNodes, "INVALID_QUERY", `${path}.children`, admission);
        if (!children.length)
          invalid("INVALID_QUERY", `${path}.children`);
        result = { kind, children: Object.freeze(children.map((child, i) => node(child, depth + 1, `${path}.children[${i}]`))) };
        break;
      }
      case "not":
        keysOnly(data, ["kind", "child"], "INVALID_QUERY", path);
        result = { kind, child: node(data.child, depth + 1, `${path}.child`) };
        break;
      case "eq": {
        keysOnly(data, ["kind", "field", "value"], "INVALID_QUERY", path);
        const name = string2(data.field, false, `${path}.field`);
        const field2 = schema.metadata[name];
        if (!field2)
          invalid("INVALID_QUERY", `${path}.field`);
        const scalar = captureScalar(data.value, field2, limits, "INVALID_QUERY", `${path}.value`);
        if (typeof scalar === "string")
          string2(scalar, false, `${path}.value`);
        result = { kind, field: name, value: scalar };
        break;
      }
      case "all":
      case "none":
        keysOnly(data, ["kind"], "INVALID_QUERY", path);
        result = { kind };
        break;
      case "extension": {
        keysOnly(data, ["kind", "capability", "version", "payload"], "INVALID_QUERY", path);
        if (typeof data.capability !== "string" || !data.capability.length || !Number.isSafeInteger(data.version) || data.version < 1 || !has(data, "payload"))
          invalid("INVALID_QUERY", path);
        const capability = string2(data.capability, false, `${path}.capability`);
        const registration = capabilities?.providers[capability];
        if (!registration?.refinement && !registration?.predicate && !registration?.sourcePredicate && !registration?.expansion)
          invalid("MISSING_CAPABILITY", path);
        if (data.version !== 1)
          invalid("INCOMPATIBLE_CAPABILITY", `${path}.version`);
        if (registration.predicate || registration.sourcePredicate) {
          const captured = captureExtension((registration.predicate ?? registration.sourcePredicate).capture, data.payload, admission, limits, registration.manifest.limits.maxPayloadCodeUnits);
          if (registration.sourcePredicate) {
            lexicalUnits += captured.codeUnits;
            bound(lexicalUnits, limits.maxQueryLexicalCodeUnits, "query.lexical");
          }
          stringUnits += captured.codeUnits;
          bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
          result = { kind: "predicate", capability, payload: captured.value };
          break;
        }
        const payload = ownObject(data.payload, "INVALID_QUERY", `${path}.payload`, admission);
        if (registration.refinement?.kind === "ordered-token-groups") {
          keysOnly(payload, ["groups", "maxGap", "fields"], "INVALID_QUERY", `${path}.payload`);
          const maxGap = payload.maxGap;
          if (typeof maxGap !== "number" || !Number.isSafeInteger(maxGap) || maxGap < 0)
            invalid("INVALID_QUERY", `${path}.payload.maxGap`);
          bound(maxGap, 32, `${path}.payload.maxGap`);
          const rawGroups = ownArray(payload.groups, Math.min(32, registration.refinement.maxTokens), "INVALID_QUERY", `${path}.payload.groups`, admission);
          if (!rawGroups.length)
            invalid("INVALID_QUERY", `${path}.payload.groups`);
          const groups = Object.freeze(rawGroups.map((rawGroup) => {
            const alternatives = ownArray(rawGroup, Math.min(16, limits.maxVariantsPerGroup), "INVALID_QUERY", `${path}.payload.group`, admission);
            if (!alternatives.length)
              invalid("INVALID_QUERY", `${path}.payload.group`);
            return Object.freeze(alternatives.map((value2) => string2(value2, true, `${path}.payload.alternative`)));
          }));
          const selected2 = has(payload, "fields") ? fields(payload.fields, `${path}.payload.fields`) : registration.manifest.dataRequirements.fields;
          bound(groups.reduce((sum, group) => sum + group.reduce((n, text2) => n + text2.length, 0), 0) + selected2.reduce((sum, field2) => sum + field2.length, 0), registration.manifest.limits.maxPayloadCodeUnits, `${path}.payload`);
          result = { kind: "ordered", capability, fields: selected2, groups, maxGap };
          break;
        }
        keysOnly(payload, ["text", "fields"], "INVALID_QUERY", `${path}.payload`);
        const text = string2(payload.text, true, `${path}.payload.text`);
        const selected = has(payload, "fields") ? fields(payload.fields, `${path}.payload.fields`) : void 0;
        bound(text.length + (selected?.reduce((sum, field2) => sum + field2.length, 0) ?? 0), registration.manifest.limits.maxPayloadCodeUnits, `${path}.payload`);
        result = { kind, capability, version: 1, payload: Object.freeze({ text, ...selected ? { fields: selected } : {} }) };
        break;
      }
      default:
        return invalid("INVALID_QUERY", path);
    }
    ancestors.delete(value);
    return Object.freeze(result);
  }
  if (typeof input === "string") {
    bound(1, limits.maxQueryNodes, "query.nodes");
    bound(1, limits.maxQueryDepth, "query.depth");
    return Object.freeze({ kind: "text", text: string2(input, true, "query"), operator: "and" });
  }
  return node(input, 1, "query");
}
function* analyzeQuery(query, schema, limits, capabilities, analyze = analyzeValue) {
  let tokens = 0;
  const groups = /* @__PURE__ */ new Set();
  const queryLimits = { ...limits, maxTextCodeUnitsPerValue: limits.maxQueryLexicalCodeUnits };
  function groupKey(fields, variants) {
    const names = [...fields ?? Object.keys(schema.text)].sort();
    const alternatives = [...new Set(variants.map((variant) => JSON.stringify(variant)))].sort();
    return JSON.stringify([names, alternatives]);
  }
  function addGroup(key) {
    groups.add(key);
    bound(groups.size, limits.maxQueryGroups, "query.groups");
  }
  function* walk(leaf) {
    switch (leaf.kind) {
      case "ordered": {
        const handler = capabilities?.providers[leaf.capability]?.refinement;
        if (handler?.kind !== "ordered-token-groups")
          invalid("MISSING_CAPABILITY", "query.capability");
        let count = 0;
        for (let groupIndex = 0; groupIndex < leaf.groups.length; groupIndex++) {
          const variants = [];
          for (const text of leaf.groups[groupIndex]) {
            let emitted = 0;
            for (const step of analyze(text, 0, queryLimits, "INVALID_QUERY", "phrase")) {
              if (step.token) {
                if (++emitted > 1)
                  invalid("INVALID_QUERY", "query.proximity.alternative");
                bound(++count, handler.maxTokens, "query.proximity.tokens");
                bound(++tokens, limits.maxQueryTokens, "query.tokens");
                variants.push([step.token.term, "exact", 1]);
              }
              yield { ...step, leaf, groupIndex };
            }
            if (emitted !== 1)
              invalid("INVALID_QUERY", "query.proximity.alternative");
          }
          addGroup(groupKey(leaf.fields, variants));
        }
        break;
      }
      case "text":
        for (const step of analyze(leaf.text, 0, queryLimits, "INVALID_QUERY", "query")) {
          if (step.token) {
            bound(++tokens, limits.maxQueryTokens, "query.tokens");
            addGroup(groupKey(leaf.fields, [[step.token.term, "exact", 1]]));
          }
          yield { ...step, leaf };
        }
        break;
      case "extension": {
        const registration = capabilities?.providers[leaf.capability];
        const handler = registration?.refinement ?? registration?.expansion;
        if (!handler)
          invalid("MISSING_CAPABILITY", "query.capability");
        let count = 0;
        for (const step of analyze(leaf.payload.text, 0, queryLimits, "INVALID_QUERY", registration?.refinement ? "phrase" : "query")) {
          if (step.token) {
            bound(++count, handler.maxTokens, registration?.refinement ? "query.phraseTokens" : "query.expansionTokens");
            bound(++tokens, limits.maxQueryTokens, "query.tokens");
            addGroup(groupKey(leaf.payload.fields, [[step.token.term, "exact", 1]]));
          }
          yield { ...step, leaf };
        }
        break;
      }
      case "group": {
        const variants = [];
        for (let i = 0; i < leaf.variants.length; i++) {
          const variant = leaf.variants[i];
          let count = 0;
          for (const step of analyze(variant.text, 0, queryLimits, "INVALID_QUERY", "query")) {
            if (step.token) {
              bound(++tokens, limits.maxQueryTokens, "query.tokens");
              if (++count > 1)
                invalid("INVALID_QUERY", "query.variants");
              if (variant.match === "prefix" && [...step.token.term].length < limits.minPrefixCodePoints)
                invalid("INVALID_QUERY", "query.prefix");
              variants.push([step.token.term, variant.match, variant.weight ?? 1]);
            }
            yield { ...step, leaf, variantIndex: i };
          }
          if (count !== 1)
            invalid("INVALID_QUERY", "query.variants");
        }
        addGroup(groupKey(leaf.fields, variants));
        break;
      }
      case "and":
      case "or":
        for (const child of leaf.children)
          yield* walk(child);
        break;
      case "not":
        yield* walk(leaf.child);
        break;
      case "eq":
        if (typeof leaf.value === "string")
          yield* scanUnicode(leaf.value, "INVALID_QUERY", "query.value");
        break;
      case "predicate":
      case "all":
      case "none":
        break;
    }
  }
  yield* walk(query);
}

// dist/core/query/work.js
function* compareStrings(a, b, charge) {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    yield charge(1);
    const difference = a.charCodeAt(i) - b.charCodeAt(i);
    if (difference)
      return difference;
  }
  yield charge(1);
  return a.length - b.length;
}
function* sortedStrings(input, charge) {
  const output = [];
  for (const value of input) {
    yield charge(value.length + 1);
    let i = output.length;
    while (i > 0 && (yield* compareStrings(value, output[i - 1], charge)) < 0) {
      yield charge(1);
      output[i] = output[i - 1];
      i--;
    }
    output[i] = value;
  }
  return output;
}

// dist/core/ranking/bm25.js
var positiveInteger = (value) => Number.isSafeInteger(value) && value > 0;
function* scoreDocument(root, doc, participating, expansions, charge, facts) {
  let score = 0;
  for (const key of yield* sortedStrings(participating, charge)) {
    const expanded = expansions.get(key);
    let groupScore = 0;
    for (const field2 of expanded.group.fields) {
      let best = 0;
      let found = false;
      let selected;
      for (const alternative of expanded.fields.get(field2)) {
        yield charge(doc.id.length + field2.length + alternative.term.length + 3);
        const tf = directoryGet(alternative.entry.postings, doc.id);
        if (tf === void 0)
          continue;
        yield charge(1);
        const statistics = root.fields[field2];
        const length = doc.fields[field2]?.length ?? 0;
        const N = statistics.documents;
        const totalLength = statistics.length;
        const df = alternative.entry.df;
        const boost = root.configuration.schema.text[field2].boost;
        if (!positiveInteger(tf) || !positiveInteger(df) || !positiveInteger(N) || !positiveInteger(totalLength) || !positiveInteger(length) || tf > length || df > N || N > root.documents.size || totalLength < N || length > totalLength || !Number.isFinite(boost) || boost <= 0 || boost > 16)
          invalid("INTERNAL_ERROR", "ranking.statistics");
        const avgLength = totalLength / N;
        const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
        const normalizer = 1.2 * (1 - 0.75 + 0.75 * length / avgLength);
        const tfPart = tf * (1.2 + 1) / (tf + normalizer);
        const base = boost * idf * tfPart;
        const weighted = alternative.weight * base;
        if (!Number.isFinite(weighted) || weighted < 0)
          invalid("INTERNAL_ERROR", "ranking.score");
        if (!found || weighted > best) {
          found = true;
          best = weighted;
          if (facts)
            selected = { kind: "field", id: doc.id, group: key, field: field2, term: alternative.term, variant: alternative.variantKey, weight: alternative.weight, boost, tf, df, N, length, totalLength, avgLength, k1: 1.2, b: 0.75, idf, normalizer, tfPart, base, selected: weighted };
        }
      }
      groupScore += best;
      if (facts && selected) {
        yield charge(1);
        facts.record(selected);
      }
    }
    score += groupScore;
    if (facts) {
      yield charge(1);
      facts.record({ kind: "group", id: doc.id, group: key, score: groupScore });
    }
  }
  if (!Number.isFinite(score) || score < 0)
    invalid("INTERNAL_ERROR", "ranking.score");
  return score;
}

// dist/core/ranking/page.js
var PageSelection = class {
  capacity;
  charge;
  heap = [];
  constructor(capacity, charge) {
    this.capacity = capacity;
    this.charge = charge;
  }
  *compare(a, b) {
    yield this.charge(1);
    return a.score === b.score ? yield* compareStrings(a.id, b.id, this.charge) : b.score - a.score;
  }
  *add(hit) {
    if (!this.capacity)
      return;
    if (this.heap.length === this.capacity) {
      if ((yield* this.compare(hit, this.heap[0])) >= 0)
        return;
      this.heap[0] = hit;
      yield* this.down();
    } else {
      let i = this.heap.length;
      this.heap.push(hit);
      yield this.charge(1);
      while (i > 0) {
        const parent = Math.floor((i - 1) / 2);
        if ((yield* this.compare(this.heap[i], this.heap[parent])) <= 0)
          break;
        yield this.charge(1);
        [this.heap[parent], this.heap[i]] = [this.heap[i], this.heap[parent]];
        i = parent;
      }
    }
  }
  *down() {
    let i = 0;
    while (i * 2 + 1 < this.heap.length) {
      let child = i * 2 + 1;
      if (child + 1 < this.heap.length && (yield* this.compare(this.heap[child + 1], this.heap[child])) > 0)
        child++;
      if ((yield* this.compare(this.heap[i], this.heap[child])) >= 0)
        break;
      yield this.charge(1);
      [this.heap[i], this.heap[child]] = [this.heap[child], this.heap[i]];
      i = child;
    }
  }
  *finish(offset, limit) {
    const reversed = [];
    while (this.heap.length) {
      const rank = this.heap.length - 1;
      const hit = this.heap[0];
      const last = this.heap.pop();
      yield this.charge(1);
      if (this.heap.length) {
        this.heap[0] = last;
        yield* this.down();
      }
      if (rank >= offset && rank < offset + limit) {
        yield this.charge(1);
        reversed.push(Object.freeze(hit));
      }
    }
    return Object.freeze(reversed.reverse());
  }
};

// dist/core/retrieval/expand.js
function* expandGroups(root, groups, charge, checkpoint) {
  const queryPairs = /* @__PURE__ */ new Set();
  const result = /* @__PURE__ */ new Map();
  for (const key of yield* sortedStrings(groups.keys(), charge)) {
    const group = groups.get(key);
    let perGroup = 0;
    const fields = /* @__PURE__ */ new Map();
    const ids = /* @__PURE__ */ new Set();
    for (const name of group.fields) {
      const field2 = root.fields[name];
      if (!field2)
        invalid("INTERNAL_ERROR", "index.fields");
      const terms = /* @__PURE__ */ new Map();
      function* add(term, entry, weight, variantKey) {
        yield charge(term.length + 1);
        const old = terms.get(term);
        if (!old) {
          yield charge(name.length + term.length + 1);
          queryPairs.add(JSON.stringify([name, term]));
          validateExpansionCounts(++perGroup, queryPairs.size, root.configuration.limits);
        }
        if (!old || weight > old.weight || weight === old.weight && (yield* compareStrings(variantKey, old.variantKey, charge)) < 0) {
          terms.set(term, Object.freeze({ term, entry, weight, variantKey }));
        }
      }
      for (const variant of group.variants) {
        if (variant.match === "exact") {
          checkpoint?.("dictionary");
          yield charge(variant.term.length + 1);
          const entry = directoryGet(field2.terms, variant.term);
          if (entry)
            yield* add(variant.term, entry, variant.weight, variant.key);
        } else {
          for (const [term, entry] of directoryEntries(field2.terms)) {
            checkpoint?.("dictionary");
            yield charge(1);
            let matches = term.length >= variant.term.length;
            for (let i = 0; matches && i < variant.term.length; i++) {
              yield charge(1);
              matches = term.charCodeAt(i) === variant.term.charCodeAt(i);
            }
            if (matches)
              yield* add(term, entry, variant.weight, variant.key);
          }
        }
      }
      const alternatives = [];
      for (const term of yield* sortedStrings(terms.keys(), charge)) {
        const expansion = terms.get(term);
        const entry = expansion.entry;
        if (!Number.isSafeInteger(entry.df) || entry.df < 1 || entry.df > field2.documents || entry.df !== entry.postings.size)
          invalid("INTERNAL_ERROR", "index.df");
        alternatives.push(expansion);
        for (const [id, tf] of directoryEntries(entry.postings)) {
          checkpoint?.("postings");
          yield charge(id.length + name.length + term.length + 3);
          const doc = directoryGet(root.documents, id);
          if (!doc || !Number.isSafeInteger(tf) || tf <= 0 || doc.fields[name]?.terms[term] !== tf)
            invalid("INTERNAL_ERROR", "index.postings");
          yield charge(id.length + 1);
          ids.add(id);
        }
      }
      fields.set(name, Object.freeze(alternatives));
    }
    result.set(key, { group, fields, ids });
  }
  return result;
}

// dist/core/trace/facts.js
function captureTrace(input, limits, admission) {
  const data = ownObject(input, "INVALID_OPTIONS", "trace", admission);
  keysOnly(data, ["ids", "maxFacts", "expectedRevision"], "INVALID_OPTIONS", "trace");
  const ids = ownArray(data.ids, limits.maxDocuments, "INVALID_OPTIONS", "trace.ids", admission).map((id) => {
    const value = stringValue(id, limits.maxIdCodeUnits, "INVALID_OPTIONS", "trace.ids");
    if (!value.length)
      invalid("INVALID_OPTIONS", "trace.ids");
    return value;
  });
  if (new Set(ids).size !== ids.length)
    invalid("INVALID_OPTIONS", "trace.ids");
  const maxFacts = has(data, "maxFacts") ? data.maxFacts : 4096;
  if (typeof maxFacts !== "number" || !Number.isSafeInteger(maxFacts) || maxFacts < 1)
    invalid("INVALID_OPTIONS", "trace.maxFacts");
  bound(maxFacts, 4096, "trace.maxFacts");
  const revision = data.expectedRevision;
  if (has(data, "expectedRevision") && (typeof revision !== "number" || !Number.isSafeInteger(revision) || revision < 0))
    invalid("INVALID_OPTIONS", "trace.expectedRevision");
  return Object.freeze({ ids: Object.freeze(ids), maxFacts, ...typeof revision === "number" ? { expectedRevision: revision } : {} });
}
var FactCollector = class {
  maximum;
  facts = [];
  constructor(maximum) {
    this.maximum = maximum;
    bound(1, maximum, "trace.facts");
  }
  record(fact) {
    bound(this.facts.length + 2, this.maximum, "trace.facts");
    this.facts.push(Object.freeze(fact));
  }
  finish(revision, analyzer, query) {
    return Object.freeze({ revision, model: "raveldex-bm25-v1", analyzer, query, tieBreaker: "utf16-id-ascending", facts: Object.freeze(this.facts) });
  }
};

// dist/core/query/compile.js
function* compileQuery(query, configuration, charge, expansion, analyze = createAnalysis(configuration)) {
  const tokens = /* @__PURE__ */ new Map();
  const orderedTokens = /* @__PURE__ */ new Map();
  for (const step of analyzeQuery(query, configuration.schema, configuration.limits, configuration.capabilities, analyze)) {
    yield charge(step.workUnits);
    if (step.token && step.leaf) {
      yield charge(1);
      if (step.groupIndex !== void 0) {
        let groups2 = orderedTokens.get(step.leaf);
        if (!groups2) {
          groups2 = [];
          orderedTokens.set(step.leaf, groups2);
        }
        const list2 = groups2[step.groupIndex] ?? [];
        list2.push(step.token.term);
        groups2[step.groupIndex] = list2;
        continue;
      }
      let list = tokens.get(step.leaf);
      if (!list) {
        list = [];
        tokens.set(step.leaf, list);
      }
      list.push(step.token.term);
    }
  }
  const groups = /* @__PURE__ */ new Map();
  function* group(fields, variants) {
    const names = yield* sortedStrings(fields ?? Object.keys(configuration.schema.text), charge);
    const entries = /* @__PURE__ */ new Map();
    for (const variant of variants) {
      yield charge(variant.term.length + 1);
      const key3 = JSON.stringify([variant.term, variant.match, variant.weight]);
      yield charge(key3.length + 1);
      entries.set(key3, Object.freeze({ ...variant, key: key3 }));
    }
    const keys = yield* sortedStrings(entries.keys(), charge);
    yield charge(names.reduce((n, field2) => n + field2.length, 1) + keys.reduce((n, key3) => n + key3.length, 1));
    const key2 = JSON.stringify([names, keys]);
    yield charge(key2.length + 1);
    let canonical = groups.get(key2);
    if (!canonical) {
      canonical = Object.freeze({ key: key2, fields: Object.freeze(names), variants: Object.freeze(keys.map((entry) => entries.get(entry))) });
      groups.set(key2, canonical);
      bound(groups.size, configuration.limits.maxQueryGroups, "query.groups");
    }
    return Object.freeze({ kind: "group", group: canonical });
  }
  function* walk(raw) {
    yield charge(1);
    switch (raw.kind) {
      case "ordered": {
        const lexical = [], termGroups = [];
        for (const terms of orderedTokens.get(raw) ?? []) {
          const node2 = yield* group(raw.fields, terms.map((term) => ({ term, match: "exact", weight: 1 })));
          if (node2.kind !== "group")
            invalid("INTERNAL_ERROR", "query.proximity.group");
          lexical.push(node2.group);
          termGroups.push(Object.freeze(node2.group.variants.map((variant) => variant.term)));
        }
        return Object.freeze({ kind: "extension", capability: raw.capability, fields: Object.freeze(yield* sortedStrings(raw.fields, charge)), terms: Object.freeze(termGroups.flat()), groups: Object.freeze(lexical), termGroups: Object.freeze(termGroups), maxGap: raw.maxGap });
      }
      case "text": {
        const children = [];
        for (const term of tokens.get(raw) ?? [])
          children.push(yield* group(raw.fields, [{ term, match: "exact", weight: 1 }]));
        return children.length ? Object.freeze({ kind: raw.operator ?? "and", children: Object.freeze(children) }) : Object.freeze({ kind: "none" });
      }
      case "group":
        return yield* group(raw.fields, raw.variants.map((variant, i) => ({ term: tokens.get(raw)[i], match: variant.match, weight: variant.weight ?? 1 })));
      case "extension": {
        if (configuration.capabilities?.providers[raw.capability]?.expansion) {
          if (!expansion)
            invalid("MISSING_CAPABILITY", "query.expansion");
          const selected = Object.freeze(yield* sortedStrings(raw.payload.fields ?? Object.keys(configuration.schema.text), charge));
          const terms2 = tokens.get(raw) ?? [];
          const alternatives = yield* expansion.resolve(raw.capability, selected, terms2);
          const children = [];
          for (let i = 0; i < alternatives.length; i++) {
            const term = terms2[i];
            const variants = [{ term, match: "exact", weight: 1 }, ...alternatives[i].filter((variant) => variant.term !== term)];
            bound(variants.length, configuration.limits.maxVariantsPerGroup, "query.expansion.variants");
            children.push(yield* group(selected, variants));
          }
          return children.length ? Object.freeze({ kind: "and", children: Object.freeze(children) }) : Object.freeze({ kind: "none" });
        }
        const lexical = [], terms = Object.freeze(tokens.get(raw) ?? []);
        for (const term of terms) {
          const node2 = yield* group(raw.payload.fields, [{ term, match: "exact", weight: 1 }]);
          if (node2.kind === "group")
            lexical.push(node2.group);
        }
        return Object.freeze({
          kind: "extension",
          capability: raw.capability,
          fields: Object.freeze(yield* sortedStrings(raw.payload.fields ?? Object.keys(configuration.schema.text), charge)),
          terms,
          groups: Object.freeze(lexical)
        });
      }
      case "and":
      case "or": {
        const children = [];
        for (const child of raw.children)
          children.push(yield* walk(child));
        return Object.freeze({ kind: raw.kind, children: Object.freeze(children) });
      }
      case "not":
        return Object.freeze({ kind: "not", child: yield* walk(raw.child) });
      case "predicate":
        return Object.freeze({ kind: "predicate", capability: raw.capability, payload: raw.payload });
      case "eq":
        return Object.freeze({ kind: "eq", field: raw.field, value: raw.value });
      case "all":
      case "none":
        return Object.freeze({ kind: raw.kind });
    }
  }
  const node = yield* walk(query);
  const key = JSON.stringify(node);
  yield charge(key.length + 1);
  return { node, groups, key };
}

// dist/core/query/evaluate.js
function* evaluate(node, doc, expansions, charge, facts, path = "query", refinements) {
  yield charge(1);
  let matched = false;
  let groups = /* @__PURE__ */ new Set();
  switch (node.kind) {
    case "group":
      yield charge(doc.id.length + node.group.key.length + 1);
      matched = expansions.get(node.group.key).ids.has(doc.id);
      if (matched) {
        yield charge(node.group.key.length + 1);
        groups.add(node.group.key);
      }
      break;
    case "extension": {
      matched = node.terms.length > 0;
      for (const group of node.groups) {
        yield charge(doc.id.length + group.key.length + 1);
        if (!expansions.get(group.key).ids.has(doc.id))
          matched = false;
      }
      if (matched) {
        const verifier = refinements?.get(node);
        if (!verifier)
          invalid("MISSING_CAPABILITY", "query.refinement");
        const cursor = verifier.test(doc.id, doc.metadata);
        try {
          for (; ; ) {
            const step = cursor.next();
            if (step.done) {
              matched = step.value;
              break;
            }
            yield step.value;
          }
        } finally {
          try {
            cursor.return(false);
          } catch {
          }
        }
      }
      if (matched)
        for (const group of node.groups) {
          yield charge(group.key.length + 1);
          groups.add(group.key);
        }
      break;
    }
    case "predicate": {
      const predicate = refinements?.get(node);
      if (!predicate)
        invalid("MISSING_CAPABILITY", "query.predicate");
      matched = yield* predicate.test(doc.id, doc.metadata);
      break;
    }
    case "all":
      matched = true;
      break;
    case "none":
      break;
    case "eq": {
      yield charge(node.field.length + 1);
      if (Object.hasOwn(doc.metadata, node.field)) {
        const value = doc.metadata[node.field];
        const values = Array.isArray(value) ? value : [value];
        for (const scalar of values) {
          yield charge(typeof scalar === "string" && typeof node.value === "string" ? Math.max(scalar.length, node.value.length) + 1 : 1);
          if (scalar === node.value) {
            matched = true;
            break;
          }
        }
      }
      break;
    }
    case "not":
      matched = !(yield* evaluate(node.child, doc, expansions, charge, facts, facts ? `${path}.child` : "", refinements)).matched;
      break;
    case "and":
    case "or": {
      matched = node.kind === "and";
      for (let i = 0; i < node.children.length; i++) {
        const child = yield* evaluate(node.children[i], doc, expansions, charge, facts, facts ? `${path}.children[${i}]` : "", refinements);
        matched = node.kind === "and" ? matched && child.matched : matched || child.matched;
        if (child.matched)
          for (const key of child.groups) {
            yield charge(key.length + 1);
            groups.add(key);
          }
      }
      if (!matched)
        groups = /* @__PURE__ */ new Set();
      break;
    }
  }
  if (facts) {
    const keys = Object.freeze(yield* sortedStrings(groups, charge));
    yield charge(1);
    facts.record({
      kind: "node",
      id: doc.id,
      path,
      node: node.kind,
      matched,
      groups: keys,
      ...node.kind === "predicate" || node.kind === "extension" ? { capability: node.capability } : {},
      ...node.kind === "eq" ? { field: node.field } : {}
    });
  }
  return { matched, groups };
}

// dist/core/capabilities/refinement.js
function* prepareRefinements(node, root, charge, options, analyze = createAnalysis(root.configuration)) {
  const leaves = /* @__PURE__ */ new Map();
  const aggregations = [], budgets = /* @__PURE__ */ new Map();
  const outputs = [];
  let evidence;
  function setup(capability) {
    const set = root.configuration.capabilities, registration = set?.providers[capability];
    if (!registration)
      invalid("MISSING_CAPABILITY", "query.capability");
    let budget = budgets.get(registration.manifest.id);
    if (!budget) {
      budget = new WorkBudget(Math.min(registration.manifest.limits.maxWorkUnits, root.configuration.limits.maxSearchWorkUnits));
      budgets.set(registration.manifest.id, budget);
    }
    const shared = budget;
    return { registration, *run(cursor) {
      try {
        for (; ; ) {
          const step = cursor.next();
          charge(0);
          if (step.done)
            return step.value;
          const charged = charge(step.value.workUnits);
          shared.charge(step.value.workUnits);
          yield charged;
        }
      } finally {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    } };
  }
  const metadataContext = (capability, payload) => Object.freeze({ revision: root.revision, schema: root.configuration.schema, limits: root.configuration.limits, capability, payload });
  function state(capability, consumer) {
    const registration = root.configuration.capabilities.providers[consumer];
    if (!registration.manifest.requires.some((ref) => ref.id === capability))
      invalid("MISSING_CAPABILITY", "query.provider");
    const provider = root.configuration.capabilities.providers[capability];
    if (!provider?.participant || !Object.hasOwn(root.participants, provider.manifest.id))
      invalid("MISSING_CAPABILITY", "query.provider");
    return root.participants[provider.manifest.id];
  }
  function output(capability, result) {
    if (!result || !Number.isSafeInteger(result.entries) || result.entries < 0 || result.value !== null && typeof result.value === "object" && !Object.isFrozen(result.value))
      invalid("INCOMPATIBLE_CAPABILITY", "extensions.output");
    bound(result.entries, Math.min(root.configuration.capabilities.providers[capability].manifest.limits.maxOutputEntries, root.configuration.limits.maxAdmissionEntries), "extensions.output");
    return result.value;
  }
  function* walk(node2) {
    if (node2.kind === "extension" || node2.kind === "predicate") {
      const { registration, run } = setup(node2.capability);
      let test;
      if (node2.kind === "extension") {
        if (!registration.refinement)
          invalid("MISSING_CAPABILITY", "query.refinement");
        if (registration.refinement.kind === "ordered-token-groups" !== (node2.termGroups !== void 0))
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement.kind");
        const context = Object.freeze({
          analyze,
          revision: root.revision,
          analyzer: root.configuration.analyzer,
          limits: root.configuration.limits,
          fields: node2.fields,
          terms: node2.terms,
          ...node2.termGroups ? { groups: node2.termGroups, maxGap: node2.maxGap } : {},
          state(capability) {
            return state(capability, node2.capability);
          }
        });
        const prepared = yield* run(registration.refinement.prepare(context));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement");
        test = prepared.test.bind(prepared);
      } else if (registration.sourcePredicate) {
        const prepared = yield* run(registration.sourcePredicate.prepare(Object.freeze({
          ...metadataContext(node2.capability, node2.payload),
          analyzer: root.configuration.analyzer,
          state: (requested) => state(requested, node2.capability)
        })));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.sourcePredicate");
        const predicate = prepared.test.bind(prepared);
        test = (id) => predicate(id);
      } else {
        if (!registration.predicate)
          invalid("MISSING_CAPABILITY", "query.predicate");
        const prepared = yield* run(registration.predicate.prepare(metadataContext(node2.capability, node2.payload)));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.predicate");
        const predicate = prepared.test.bind(prepared);
        test = (_id, metadata) => predicate(metadata);
      }
      leaves.set(node2, Object.freeze({ *test(id, metadata) {
        const matched = yield* run(test(id, metadata));
        if (typeof matched !== "boolean")
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement");
        return matched;
      } }));
    } else if (node2.kind === "and" || node2.kind === "or")
      for (const child of node2.children)
        yield* walk(child);
    else if (node2.kind === "not")
      yield* walk(node2.child);
  }
  yield* walk(node);
  for (const capability of Object.keys(options.extensions ?? {}).sort()) {
    yield charge(capability.length + 1);
    const { registration, run } = setup(capability);
    if (registration.dictionary) {
      const prepared2 = yield* run(registration.dictionary.prepare(Object.freeze({
        ...metadataContext(capability, options.extensions[capability]),
        analyzer: root.configuration.analyzer,
        *dictionary(fields) {
          if (!Array.isArray(fields) || !fields.length)
            invalid("INCOMPATIBLE_CAPABILITY", "extensions.dictionary.fields");
          bound(fields.length, root.configuration.limits.maxTextFields, "extensions.dictionary.fields");
          const selected = /* @__PURE__ */ new Set();
          for (const field2 of fields) {
            if (typeof field2 !== "string" || !registration.manifest.dataRequirements.fields.includes(field2) || selected.has(field2))
              invalid("MISSING_CAPABILITY", "extensions.dictionary.fields");
            selected.add(field2);
          }
          for (const field2 of selected)
            for (const [term, entry] of directoryEntries(root.fields[field2].terms)) {
              yield Object.freeze({ workUnits: field2.length + term.length + 1, field: field2, term, documentFrequency: entry.df });
            }
        }
      })));
      if (!prepared2 || typeof prepared2.finish !== "function")
        invalid("INCOMPATIBLE_CAPABILITY", "extensions.dictionary");
      const finish2 = prepared2.finish.bind(prepared2);
      outputs.push(Object.freeze({ capability, *finish() {
        return output(capability, yield* run(finish2()));
      } }));
      continue;
    }
    if (registration.evidence) {
      if (evidence)
        invalid("INVALID_OPTIONS", "options.extensions.evidence");
      const prepared2 = yield* run(registration.evidence.prepare(Object.freeze({
        ...metadataContext(capability, options.extensions[capability]),
        analyzer: root.configuration.analyzer,
        analyze,
        state: (requested) => state(requested, capability)
      })));
      if (!prepared2 || typeof prepared2.finish !== "function")
        invalid("INCOMPATIBLE_CAPABILITY", "extensions.evidence");
      const finish2 = prepared2.finish.bind(prepared2);
      evidence = Object.freeze({ capability, *finish(context) {
        return output(capability, yield* run(finish2(context)));
      } });
      continue;
    }
    if (!registration.aggregation)
      invalid("MISSING_CAPABILITY", "options.extensions");
    const prepared = yield* run(registration.aggregation.prepare(metadataContext(capability, options.extensions[capability])));
    if (!prepared || typeof prepared.add !== "function" || typeof prepared.finish !== "function")
      invalid("INCOMPATIBLE_CAPABILITY", "extensions.aggregation");
    const add = prepared.add.bind(prepared), finish = prepared.finish.bind(prepared);
    aggregations.push(Object.freeze({
      capability,
      *add(metadata) {
        if ((yield* run(add(metadata))) !== void 0)
          invalid("INCOMPATIBLE_CAPABILITY", "extensions.aggregation");
      },
      *finish() {
        return output(capability, yield* run(finish()));
      }
    }));
  }
  return { leaves, aggregations, outputs, ...evidence ? { evidence } : {} };
}

// dist/core/capabilities/expansion.js
function createExpansionResolver(root, charge) {
  const budgets = /* @__PURE__ */ new Map(), outputs = /* @__PURE__ */ new Map();
  const observations = /* @__PURE__ */ new Map(), cache = /* @__PURE__ */ new Map();
  let outputEntries = 0;
  return {
    *resolve(capability, fields, terms) {
      if (root.configuration.analyzer.id !== "basic-v1")
        invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.analyzer");
      const registration = root.configuration.capabilities?.providers[capability];
      if (!registration?.expansion)
        invalid("MISSING_CAPABILITY", "query.expansion");
      for (const field2 of fields) {
        yield charge(field2.length + 1);
        if (!registration.manifest.dataRequirements.fields.includes(field2))
          invalid("MISSING_CAPABILITY", "query.expansion.fields");
      }
      const output = (count) => {
        const entries = (outputs.get(registration.manifest.id) ?? 0) + count;
        bound(entries, registration.manifest.limits.maxOutputEntries, "query.expansion.output");
        bound(outputEntries + count, root.configuration.limits.maxAdmissionEntries, "query.expansion.output");
        outputs.set(registration.manifest.id, entries);
        outputEntries += count;
      };
      if (!observations.has(capability)) {
        output(3);
        yield charge(3);
        observations.set(capability, []);
      }
      let budget = budgets.get(registration.manifest.id);
      if (!budget) {
        budget = new WorkBudget(Math.min(registration.manifest.limits.maxWorkUnits, root.configuration.limits.maxSearchWorkUnits));
        budgets.set(registration.manifest.id, budget);
      }
      const result = [];
      for (const term of terms) {
        const key = JSON.stringify([capability, fields, term]);
        yield charge(key.length + 1);
        const reused = cache.get(key);
        if (reused) {
          result.push(reused);
          continue;
        }
        const before = budget.consumed;
        let exact = false, visited = 0;
        for (const field2 of fields) {
          yield charge(field2.length + term.length + 1);
          if (directoryGet(root.fields[field2].terms, term))
            exact = true;
        }
        const context = Object.freeze({
          revision: root.revision,
          analyzer: root.configuration.analyzer,
          limits: root.configuration.limits,
          fields,
          term,
          exact,
          *dictionary() {
            for (const field2 of fields)
              for (const [candidate] of directoryEntries(root.fields[field2].terms)) {
                visited++;
                yield { workUnits: field2.length + candidate.length + 1, term: candidate };
              }
          }
        });
        const cursor = registration.expansion.expand(context);
        let alternatives;
        try {
          for (; ; ) {
            const step = cursor.next();
            if (step.done) {
              alternatives = step.value;
              break;
            }
            const charged = charge(step.value.workUnits);
            budget.charge(step.value.workUnits);
            yield charged;
          }
        } finally {
          try {
            cursor.return([]);
          } catch {
          }
        }
        if (!Array.isArray(alternatives) || !Object.isFrozen(alternatives))
          invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.output");
        bound(alternatives.length, root.configuration.limits.maxVariantsPerGroup, "query.expansion.alternatives");
        const byTerm = /* @__PURE__ */ new Map();
        for (const alternative of alternatives) {
          if (!alternative || typeof alternative.term !== "string" || !alternative.term.length || alternative.term.length > root.configuration.limits.maxTermCodeUnits || !Number.isFinite(alternative.weight) || alternative.weight <= 0 || alternative.weight > 1 || byTerm.has(alternative.term))
            invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.output");
          yield charge(alternative.term.length + 1);
          let live = false;
          for (const field2 of fields) {
            yield charge(field2.length + alternative.term.length + 1);
            if (directoryGet(root.fields[field2].terms, alternative.term))
              live = true;
          }
          if (!live)
            invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.dictionary");
          byTerm.set(alternative.term, Object.freeze({ term: alternative.term, match: "exact", weight: alternative.weight }));
        }
        const variants = [];
        for (const name of yield* sortedStrings(byTerm.keys(), charge))
          variants.push(byTerm.get(name));
        const owned = Object.freeze(variants);
        const entries = 8 + fields.length + 4 * variants.length;
        output(entries);
        yield charge(entries);
        const list = observations.get(capability) ?? [];
        list.push(Object.freeze({ term, fields, alternatives: owned, dictionaryEntriesVisited: visited, workUnits: budget.consumed - before }));
        observations.set(capability, list);
        cache.set(key, owned);
        result.push(owned);
      }
      return result;
    },
    finish() {
      if (!observations.size)
        return void 0;
      const result = /* @__PURE__ */ Object.create(null);
      for (const [capability, groups] of observations)
        result[capability] = Object.freeze({
          policy: root.configuration.capabilities.providers[capability].expansion.policy,
          groups: Object.freeze(groups)
        });
      return Object.freeze(result);
    }
  };
}

// dist/core/query/search.js
function captureSearch(configuration, input, options, trace) {
  const { schema, limits } = configuration;
  const admission = new Admission(limits.maxAdmissionEntries);
  const page = captureOptions(options, limits, true, admission, configuration.capabilities);
  if (page.signal?.aborted)
    invalid("CANCELLED", "options.signal");
  const query = captureQuery(input, schema, limits, admission, configuration.capabilities);
  let request = trace === void 0 ? void 0 : captureTrace(trace, limits, admission);
  let evidence;
  for (const capability of Object.keys(page.extensions ?? {})) {
    const handler = configuration.capabilities?.providers[capability]?.evidence;
    if (!handler)
      continue;
    if (request || evidence)
      invalid("INVALID_OPTIONS", "options.extensions.evidence");
    request = captureTrace(handler.select(page.extensions[capability]), limits, admission);
    evidence = capability;
  }
  return Object.freeze({ query, options: page, ...request ? { trace: request } : {}, ...evidence ? { evidence } : {} });
}
function* executeOwnedSearch(root, request, control = {}) {
  const { query, options, trace } = request;
  const budget = new WorkBudget(root.configuration.limits.maxSearchWorkUnits);
  let phase = "start";
  const check = () => {
    control.checkpoint?.(phase);
    if (control.checkStop)
      control.checkStop(phase);
    else if (options.signal?.aborted)
      invalid("CANCELLED", "options.signal");
  };
  const boundary = (next) => {
    phase = next;
    check();
  };
  const charge = (workUnits) => {
    check();
    budget.charge(workUnits);
    return { workUnits };
  };
  check();
  if (trace?.expectedRevision !== void 0 && trace.expectedRevision !== root.revision)
    invalid("REVISION_MISMATCH", "trace.expectedRevision");
  const selected = /* @__PURE__ */ new Set();
  if (trace)
    for (const id of trace.ids) {
      for (const step of scanUnicode(id, "INVALID_OPTIONS", "trace.ids"))
        yield charge(step.workUnits);
      yield charge(id.length + 1);
      selected.add(id);
    }
  const collector = trace ? new FactCollector(trace.maxFacts) : void 0;
  boundary("analysis");
  const expansion = root.configuration.capabilities?.ordered.some((registration) => registration.expansion) ? createExpansionResolver(root, charge) : void 0;
  const analyze = createAnalysis(root.configuration, check);
  const compiled = yield* compileQuery(query, root.configuration, charge, expansion, analyze);
  boundary("expansion");
  const expansions = yield* expandGroups(root, compiled.groups, charge, boundary);
  const extensions = root.configuration.capabilities ? yield* prepareRefinements(compiled.node, root, charge, options, analyze) : void 0;
  const page = new PageSelection(options.limit ? options.offset + options.limit : 0, charge);
  let total = 0;
  for (const [id, doc] of directoryEntries(root.documents)) {
    boundary("evaluation");
    yield charge(id.length + 1);
    if (doc.id !== id)
      invalid("INTERNAL_ERROR", "index.documents");
    const facts = selected.has(id) ? collector : void 0;
    const qualified = yield* evaluate(compiled.node, doc, expansions, charge, facts, "query", extensions?.leaves);
    boundary("scoring");
    const score = qualified.matched ? yield* scoreDocument(root, doc, qualified.groups, expansions, charge, facts) : 0;
    if (qualified.matched) {
      total++;
      if (extensions?.aggregations.length) {
        boundary("aggregation");
        for (const aggregation of extensions.aggregations)
          yield* aggregation.add(doc.metadata);
      }
      boundary("selection");
      yield* page.add({ id, score });
    }
    if (facts) {
      const groups = Object.freeze(yield* sortedStrings(qualified.groups, charge));
      yield charge(1);
      facts.record({ kind: "document", id, exists: true, matched: qualified.matched, groups, score });
    }
  }
  if (collector)
    for (const id of selected) {
      yield charge(id.length + 1);
      if (!directoryGet(root.documents, id))
        collector.record({ kind: "document", id, exists: false, matched: false, groups: Object.freeze([]), score: 0 });
    }
  boundary("selection");
  const hits = yield* page.finish(options.offset, options.limit);
  let additional = expansion?.finish();
  if (extensions?.aggregations.length) {
    boundary("aggregation");
    const result2 = /* @__PURE__ */ Object.create(null);
    for (const aggregation of extensions.aggregations)
      result2[aggregation.capability] = yield* aggregation.finish();
    additional = Object.freeze({ ...additional, ...result2 });
  }
  const scoreTrace = collector?.finish(root.revision, root.configuration.analyzer, compiled.key);
  if (extensions?.outputs.length) {
    boundary("aggregation");
    const result2 = /* @__PURE__ */ Object.create(null);
    for (const output of extensions.outputs)
      result2[output.capability] = yield* output.finish();
    additional = Object.freeze({ ...additional, ...result2 });
  }
  if (extensions?.evidence) {
    boundary("aggregation");
    if (!scoreTrace)
      invalid("INTERNAL_ERROR", "extensions.evidence");
    const publicResult = Object.freeze({ revision: root.revision, model: "raveldex-bm25-v1", completeness: "complete", total, hits, ...additional ? { extensions: additional } : {} });
    const value = yield* extensions.evidence.finish(Object.freeze({
      query: compiled.node,
      trace: scoreTrace,
      result: publicResult,
      counts: root.counts,
      searchWorkUnits: budget.consumed,
      maxSearchWorkUnits: root.configuration.limits.maxSearchWorkUnits,
      capabilities: Object.freeze(root.configuration.capabilities.ordered.map((registration) => registration.manifest))
    }));
    additional = Object.freeze({ ...additional, [extensions.evidence.capability]: value });
  }
  boundary("result");
  yield charge(1);
  const result = Object.freeze({
    revision: root.revision,
    model: "raveldex-bm25-v1",
    completeness: "complete",
    total,
    hits,
    ...scoreTrace && !request.evidence ? { trace: scoreTrace } : {},
    ...additional ? { extensions: additional } : {}
  });
  check();
  return result;
}

// dist/core/execution/host.js
function directHost() {
  const host = globalThis;
  if (typeof host.performance?.now !== "function" || typeof host.setTimeout !== "function" || typeof host.clearTimeout !== "function")
    invalid("INTERNAL_ERROR", "execution.host");
  const now = host.performance.now.bind(host.performance);
  const schedule = host.setTimeout.bind(host), cancel = host.clearTimeout.bind(host);
  return Object.freeze({ now, schedule(callback, delayMs) {
    const handle = schedule(callback, delayMs);
    return () => cancel(handle);
  } });
}

// dist/core/execution/engine.js
function emptyRoot(configuration, states = Object.freeze(/* @__PURE__ */ Object.create(null))) {
  const fields = /* @__PURE__ */ Object.create(null);
  for (const name of Object.keys(configuration.schema.text))
    fields[name] = Object.freeze({ documents: 0, length: 0, terms: emptyDirectory() });
  return Object.freeze({
    configuration,
    revision: 0,
    documents: emptyDirectory(),
    fields: Object.freeze(fields),
    counts: Object.freeze({ documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 }),
    participants: states
  });
}
var ExecutionOwner = class {
  #owner;
  #configuration;
  #host;
  #metrics;
  #queue = [];
  #active;
  #closing = false;
  #pumping = false;
  #disposal;
  #disposed;
  constructor(root, host, participants = [], metrics) {
    this.#owner = new MutationOwner(root, participants);
    this.#configuration = root.configuration;
    this.#metrics = metrics;
    this.#host = Object.freeze({ now: host.now.bind(host), schedule: host.schedule.bind(host) });
  }
  get root() {
    return this.#owner?.root;
  }
  adapterOperation(capture, control) {
    return this.admit(() => {
      const request = capture(this.#configuration);
      return { options: request.options, start: (check) => {
        const owner2 = this.#owner, previous = owner2.root;
        return request.start(previous, check, (root) => owner2.publishPrepared(root, previous));
      } };
    }, control);
  }
  adapterReplace(capture) {
    return this.admit(() => {
      const request = capture(this.#configuration);
      return { options: request.options, start: (check) => {
        const owner2 = this.#owner, maximum = this.#configuration.limits.maxMutationWorkUnits;
        return (function* () {
          const budget = new WorkBudget(maximum);
          function* metered(cursor) {
            let finished = false;
            try {
              for (; ; ) {
                check("patch");
                const step = cursor.next();
                if (step.done) {
                  finished = true;
                  return step.value;
                }
                check("patch");
                budget.charge(step.value.workUnits);
                yield step.value;
              }
            } finally {
              if (!finished) {
                try {
                  cursor.return(void 0);
                } catch {
                }
              }
            }
          }
          const record2 = yield* metered(request.start(owner2.root, check));
          check("patch.replace");
          const replacement = owner2.capture("replace", record2, request.options);
          check("patch.replace");
          return yield* metered(owner2.execute(replacement, { checkStop: check }));
        })();
      } };
    });
  }
  search(query, options) {
    return this.searchControlled(query, options);
  }
  searchControlled(query, options, control) {
    return this.admit(() => {
      const request = captureSearch(this.#configuration, query, options);
      return { options: request.options, start: (check) => executeOwnedSearch(this.#owner.root, request, { checkStop: check }) };
    }, control);
  }
  add(record2, options) {
    return this.mutate("add", record2, options);
  }
  addMany(records, options) {
    return this.mutate("addMany", records, options);
  }
  replace(record2, options) {
    return this.mutate("replace", record2, options);
  }
  remove(ids, options) {
    return this.mutate("remove", ids, options);
  }
  clear(options) {
    return this.mutate("clear", void 0, options);
  }
  mutate(kind, input, options) {
    return this.mutateControlled(kind, input, options);
  }
  mutateControlled(kind, input, options, control) {
    return this.admit(() => {
      const request = this.#owner.capture(kind, input, options);
      return { options: request.options, start: (check) => this.#owner.execute(request, { checkStop: check }) };
    }, control);
  }
  check(op, phase) {
    if (this.#metrics) {
      this.#metrics.checks++;
      if (phase)
        this.#metrics.phaseChecks[phase] = (this.#metrics.phaseChecks[phase] ?? 0) + 1;
    }
    if (this.#closing)
      invalid("DISPOSED", "execution");
    const aborted = op.options?.signal?.aborted;
    const expired = this.#host.now() >= op.deadline;
    if (this.#closing)
      invalid("DISPOSED", "execution");
    if (aborted || op.cancelled)
      invalid("CANCELLED", "options.signal");
    if (expired)
      invalid("DEADLINE_EXCEEDED", "options.deadlineMs");
  }
  admit(capture, control) {
    try {
      if (this.#closing)
        invalid("DISPOSED", "execution");
      const admittedAt = this.#host.now();
      const request = capture();
      if (control) {
        if (!Number.isFinite(control.elapsedMs) || control.elapsedMs < 0)
          invalid("INTERNAL_ERROR", "execution.control");
        request.options = Object.freeze({ ...request.options, signal: control.signal });
      }
      if (this.#closing)
        invalid("DISPOSED", "execution");
      if (request.options.signal?.aborted)
        invalid("CANCELLED", "options.signal");
      if (control && control.elapsedMs >= request.options.deadlineMs)
        invalid("DEADLINE_EXCEEDED", "options.deadlineMs");
      if (this.#active && this.#queue.length >= this.#configuration.limits.maxQueuedOperations)
        invalid("QUEUE_FULL", "execution.queue");
      let resolve, reject;
      const promise = new Promise((yes, no) => {
        resolve = yes;
        reject = no;
      });
      const op = {
        options: request.options,
        start: void 0,
        cursor: void 0,
        resolve,
        reject,
        deadline: admittedAt + request.options.deadlineMs - (control?.elapsedMs ?? 0),
        detach: void 0,
        timer: void 0,
        resume: void 0,
        settled: false,
        executing: false,
        cancelled: false
      };
      op.start = () => request.start((phase) => this.check(op, phase));
      if (this.#active)
        this.#queue.push(op);
      else
        this.#active = op;
      try {
        const signal = op.options.signal;
        if (signal) {
          const stop = () => {
            op.cancelled = true;
            this.stop(op);
          };
          op.detach = () => signal.removeEventListener("abort", stop);
          signal.addEventListener("abort", stop, { once: true });
          if (op.settled) {
            try {
              signal.removeEventListener("abort", stop);
            } catch {
            }
          }
        }
        if (!op.settled) {
          this.check(op);
          op.timer = this.#host.schedule(() => {
            op.timer = void 0;
            this.stop(op);
          }, Math.max(0, op.deadline - this.#host.now()));
        }
      } catch (error) {
        this.finish(op, void 0, this.error(error));
      }
      this.pump();
      return promise;
    } catch (error) {
      return Promise.reject(this.error(error));
    }
  }
  /** Event/timer stop while suspended closes staging immediately; running code checks cooperatively. */
  stop(op) {
    if (op.settled || op.executing)
      return;
    try {
      this.check(op);
      op.timer?.();
      op.timer = this.#host.schedule(() => {
        op.timer = void 0;
        this.stop(op);
      }, Math.max(0, op.deadline - this.#host.now()));
    } catch (error) {
      this.finish(op, void 0, this.error(error));
      this.pump();
    }
  }
  pump() {
    if (this.#pumping)
      return;
    this.#pumping = true;
    let consumed = 0;
    try {
      for (; ; ) {
        if (!this.#active)
          this.#active = this.#queue.shift();
        const op = this.#active;
        if (!op || op.resume)
          break;
        op.executing = true;
        try {
          this.check(op);
          op.cursor ??= op.start();
          op.start = void 0;
          for (; ; ) {
            this.check(op);
            const step = op.cursor.next();
            if (step.done) {
              this.finish(op, step.value);
              break;
            }
            consumed += step.value.workUnits;
            if (this.#metrics) {
              this.#metrics.workUnits += step.value.workUnits;
              this.#metrics.steps++;
              this.#metrics.maxStepWorkUnits = Math.max(this.#metrics.maxStepWorkUnits, step.value.workUnits);
              this.#metrics.maxTaskWorkUnits = Math.max(this.#metrics.maxTaskWorkUnits, consumed);
            }
            if (consumed >= this.#configuration.limits.checkpointWorkUnits) {
              this.check(op);
              op.resume = this.#host.schedule(() => {
                op.resume = void 0;
                this.pump();
              }, 0);
              if (this.#metrics)
                this.#metrics.hostYields++;
              break;
            }
          }
        } catch (error) {
          this.finish(op, void 0, this.error(error));
        } finally {
          op.executing = false;
        }
        if (this.#active === op)
          break;
      }
    } finally {
      this.#pumping = false;
      this.release();
    }
  }
  error(error) {
    return error instanceof RaveldexError ? error : new RaveldexError("INTERNAL_ERROR");
  }
  finish(op, result, failure) {
    if (op.settled)
      return;
    op.settled = true;
    const resolve = op.resolve, reject = op.reject;
    const cursor = op.cursor;
    op.options = void 0;
    op.start = void 0;
    op.cursor = void 0;
    op.resolve = void 0;
    op.reject = void 0;
    if (failure !== void 0) {
      try {
        cursor?.return(void 0);
      } catch {
      }
    }
    for (const cleanup of [op.resume, op.timer, op.detach]) {
      try {
        cleanup?.();
      } catch {
      }
    }
    op.resume = void 0;
    op.timer = void 0;
    op.detach = void 0;
    if (this.#active === op)
      this.#active = void 0;
    else
      this.#queue = this.#queue.filter((item) => item !== op);
    if (failure !== void 0)
      reject(this.error(failure));
    else
      resolve(result);
    this.release();
  }
  dispose() {
    if (this.#disposal)
      return this.#disposal;
    this.#closing = true;
    this.#disposal = new Promise((resolve) => {
      this.#disposed = resolve;
    });
    for (const op of [...this.#queue])
      this.finish(op, void 0, new RaveldexError("DISPOSED"));
    if (this.#active && !this.#active.executing)
      this.finish(this.#active, void 0, new RaveldexError("DISPOSED"));
    this.release();
    return this.#disposal;
  }
  release() {
    if (this.#closing && !this.#active && this.#queue.length === 0) {
      this.#owner = void 0;
      const resolve = this.#disposed;
      this.#disposed = void 0;
      resolve?.();
    }
  }
};
var executionOwners = /* @__PURE__ */ new WeakMap();
function createOwnedRaveldex(captured, host = directHost(), metrics) {
  let owner2;
  try {
    const installed = initializeParticipants(captured);
    owner2 = new ExecutionOwner(emptyRoot(captured, installed.states), host, installed.participants, metrics);
  } catch (error) {
    throw error instanceof RaveldexError ? error : new RaveldexError("INTERNAL_ERROR");
  }
  return facadeFromExecutionOwner(owner2);
}
function facadeFromExecutionOwner(owner2) {
  const facade = Object.freeze({
    search: owner2.search.bind(owner2),
    add: owner2.add.bind(owner2),
    addMany: owner2.addMany.bind(owner2),
    replace: owner2.replace.bind(owner2),
    remove: owner2.remove.bind(owner2),
    clear: owner2.clear.bind(owner2),
    dispose: owner2.dispose.bind(owner2)
  });
  executionOwners.set(facade, owner2);
  return facade;
}
function createRaveldex(configuration) {
  try {
    return createOwnedRaveldex(captureConfiguration(configuration));
  } catch (error) {
    throw error instanceof RaveldexError ? error : new RaveldexError("INTERNAL_ERROR");
  }
}

// src/core/errors/error.ts
var ERROR_CODES2 = Object.freeze([
  "INVALID_SCHEMA",
  "INVALID_RECORD",
  "INVALID_QUERY",
  "INVALID_OPTIONS",
  "ID_EXISTS",
  "ID_NOT_FOUND",
  "LIMIT_EXCEEDED",
  "QUEUE_FULL",
  "WORK_LIMIT_EXCEEDED",
  "DEADLINE_EXCEEDED",
  "CANCELLED",
  "DISPOSED",
  "MISSING_CAPABILITY",
  "INCOMPATIBLE_CAPABILITY",
  "REVISION_MISMATCH",
  "REVISION_EXHAUSTED",
  "RESOURCE_EXHAUSTED",
  "UNSUPPORTED_ENVIRONMENT",
  "INTERNAL_ERROR"
]);
var RaveldexError2 = class extends Error {
  code;
  details;
  constructor(code, details = {}) {
    super(`Raveldex: ${code}`);
    this.name = "RaveldexError";
    this.code = code;
    this.details = Object.freeze({
      ...details.path === void 0 ? {} : { path: details.path.slice(0, 256) },
      ...details.limit === void 0 ? {} : { limit: details.limit },
      ...details.actual === void 0 ? {} : { actual: details.actual }
    });
  }
};

// src/addons/ui/options.ts
function fail(code, path) {
  throw new RaveldexError2(code, { path: `ui.${path}` });
}
function record(value, allowed, path) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) fail("INVALID_OPTIONS", path);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) fail("INVALID_OPTIONS", path);
  const owned = /* @__PURE__ */ Object.create(null);
  for (const key of Reflect.ownKeys(value)) {
    if (typeof key !== "string" || !allowed.includes(key)) fail("INVALID_OPTIONS", path);
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !("value" in descriptor)) fail("INVALID_OPTIONS", path);
    owned[key] = descriptor.value;
  }
  return owned;
}
function array(value, cap, path) {
  if (!Array.isArray(value) || value.length > cap) fail("INVALID_OPTIONS", path);
  const out = [];
  for (const key of Reflect.ownKeys(value)) {
    if (key === "length") continue;
    if (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length) fail("INVALID_OPTIONS", path);
  }
  for (let i = 0; i < value.length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
    if (!descriptor || !("value" in descriptor)) fail("INVALID_OPTIONS", path);
    out.push(descriptor.value);
  }
  return out;
}
function string(value, cap, path, empty = false) {
  if (typeof value !== "string" || value.length > cap || !empty && !value.length) fail("INVALID_OPTIONS", path);
  for (let i = 0; i < value.length; i++) {
    const c = value.charCodeAt(i);
    if (c >= 55296 && c <= 56319) {
      const next = value.charCodeAt(++i);
      if (!(next >= 56320 && next <= 57343)) fail("INVALID_OPTIONS", path);
    } else if (c >= 56320 && c <= 57343) fail("INVALID_OPTIONS", path);
  }
  return value;
}
function field(value, path) {
  const name = string(value, 64, path);
  if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(name) || name === "constructor" || name === "prototype") fail("INVALID_OPTIONS", path);
  return name;
}
function displayName(value, cap, path) {
  const name = string(value, cap, path);
  if (!name.trim().length) fail("INVALID_OPTIONS", path);
  return name;
}
function integer2(value, fallback, minimum, maximum, path) {
  const n = value === void 0 ? fallback : value;
  if (typeof n !== "number" || !Number.isSafeInteger(n) || n < minimum || n > maximum) fail("INVALID_OPTIONS", path);
  return n;
}
function captureOptions2(input) {
  const o = record(input, ["root", "engine", "documents", "facets", "snippetFields", "pageSize", "debounceMs", "mode", "label"], "options");
  const root = o.root;
  if (!root || root.nodeType !== 1 || !root.ownerDocument || typeof root.replaceChildren !== "function") fail("INVALID_OPTIONS", "root");
  const engine = o.engine;
  if (!engine || typeof engine.search !== "function") fail("INVALID_OPTIONS", "engine");
  const documents = /* @__PURE__ */ new Map();
  let units = 0;
  for (const value of array(o.documents, 1e4, "documents")) {
    const d = record(value, ["id", "title", "url"], "documents");
    const id = string(d.id, 256, "documents.id", true), title = displayName(d.title, 1024, "documents.title");
    const raw = string(d.url, 2048, "documents.url");
    if (documents.has(id)) fail("INVALID_OPTIONS", "documents.id");
    let parsed;
    try {
      parsed = new URL(raw, root.ownerDocument.baseURI);
    } catch {
      fail("INVALID_OPTIONS", "documents.url");
    }
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:" || parsed.username || parsed.password) fail("INVALID_OPTIONS", "documents.url");
    units += id.length + title.length + raw.length;
    if (units > 4e6) fail("LIMIT_EXCEEDED", "documents");
    documents.set(id, Object.freeze({ id, title, url: parsed.href }));
  }
  const facetFields = /* @__PURE__ */ new Set();
  const facets = array(o.facets ?? [], 8, "facets").map((value) => {
    const f = record(value, ["field", "label"], "facets");
    const name = field(f.field, "facets.field");
    if (facetFields.has(name)) fail("INVALID_OPTIONS", "facets.field");
    facetFields.add(name);
    return Object.freeze({ field: name, label: displayName(f.label, 256, "facets.label") });
  });
  const sourceFields = /* @__PURE__ */ new Set();
  const snippetFields = array(o.snippetFields ?? [], 32, "snippetFields").map((value) => {
    const name = field(value, "snippetFields");
    if (sourceFields.has(name)) fail("INVALID_OPTIONS", "snippetFields");
    sourceFields.add(name);
    return name;
  });
  const mode = o.mode ?? "text";
  if (mode !== "text" && mode !== "prefix" && mode !== "phrase") fail("INVALID_OPTIONS", "mode");
  return Object.freeze({
    root,
    engine,
    documents,
    facets: Object.freeze(facets),
    snippetFields: Object.freeze(snippetFields),
    pageSize: integer2(o.pageSize, 5, 1, 100, "pageSize"),
    debounceMs: integer2(o.debounceMs, 150, 0, 2e3, "debounceMs"),
    mode,
    label: o.label === void 0 ? "Search documentation" : displayName(o.label, 256, "label")
  });
}

// src/addons/ui/render.ts
function assertResult(result, captured) {
  if (!result || result.completeness !== "complete" || result.model !== "raveldex-bm25-v1" || !Number.isSafeInteger(result.revision) || result.revision < 0 || !Number.isSafeInteger(result.total) || result.total < 0 || result.total > 1e4 || !Array.isArray(result.hits) || result.hits.length > captured.pageSize || result.hits.length > result.total) fail("INCOMPATIBLE_CAPABILITY", "result");
  const seen = /* @__PURE__ */ new Set();
  for (const hit of result.hits) {
    if (!hit || typeof hit.id !== "string" || !captured.documents.has(hit.id) || seen.has(hit.id) || typeof hit.score !== "number" || !Number.isFinite(hit.score)) fail("INCOMPATIBLE_CAPABILITY", "result.hits");
    seen.add(hit.id);
  }
}

// src/addons/ui/query.ts
function queryFromText(text, mode) {
  if (!text) return { kind: "all" };
  if (mode === "phrase") return { kind: "extension", capability: "phrases", version: 1, payload: { text } };
  if (mode !== "prefix" || text.length > 2048) return { kind: "text", text };
  const words = text.matchAll(/[\p{L}\p{N}][\p{L}\p{N}\p{M}]*/gu);
  let last;
  let count = 0;
  for (const word of words) {
    last = word;
    count++;
  }
  if (!last || [...last[0].normalize("NFKC").toLowerCase()].length < 2) return { kind: "text", text };
  const ending = { kind: "group", variants: [{ text: count === 1 ? text : text.slice(last.index), match: "prefix" }] };
  const earlier = text.slice(0, last.index);
  return count > 1 ? { kind: "and", children: [{ kind: "text", text: earlier }, ending] } : ending;
}

// src/addons/ui/mounts.ts
var mounted = /* @__PURE__ */ new WeakMap();

// src/addons/ui/modal-shortcuts.ts
var coordinators = /* @__PURE__ */ new WeakMap();
function editable(event) {
  return event.composedPath().some((target) => {
    const element = target;
    return element?.nodeType === 1 && (element.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(element.tagName));
  });
}
function registerModalShortcut(doc, registration) {
  let coordinator = coordinators.get(doc);
  if (!coordinator) {
    const registrations = [];
    const listener = (event) => {
      if (event.defaultPrevented || event.repeat || event.isComposing || event.keyCode === 229 || event.altKey || event.shiftKey || event.ctrlKey === event.metaKey || event.key.toLowerCase() !== "k" || editable(event)) return;
      const opened2 = registrations.find((entry) => entry.isOpen());
      const target = opened2 ? opened2.eligible() ? opened2 : void 0 : registrations.find((entry) => entry.eligible());
      if (target?.open()) event.preventDefault();
    };
    coordinator = { registrations, listener };
    coordinators.set(doc, coordinator);
    doc.addEventListener("keydown", listener);
  }
  const owned = coordinator;
  owned.registrations.push(registration);
  return () => {
    const index = owned.registrations.indexOf(registration);
    if (index !== -1) owned.registrations.splice(index, 1);
    if (!owned.registrations.length && coordinators.get(doc) === owned) {
      doc.removeEventListener("keydown", owned.listener);
      coordinators.delete(doc);
    }
  };
}

// src/addons/ui/dropdown.ts
var defaults = Object.freeze({
  label: "Search this site",
  placeholder: "Search",
  submit: "Search",
  clear: "Clear",
  idle: "Enter a search term.",
  composing: "Finish composing to search.",
  searching: "Searching\u2026",
  noResults: "No results.",
  resultsLabel: "Search results",
  resultsOne: "{total} result. Showing {count}.",
  resultsMany: "{total} results. Showing {count}.",
  error: "Search could not complete ({code}). Try again.",
  retry: "Retry search",
  fullResults: "See all results",
  closed: "Search dismissed. Edit the query or use Search to reopen.",
  noSpace: "Not enough space for this result list. Open the full-results page."
});
var opened = /* @__PURE__ */ new WeakMap();
var mountNumber = 0;
var format = (text, values) => text.replace(/\{([A-Za-z]+)\}/g, (token, name) => Object.hasOwn(values, name) ? String(values[name]) : token);
function validText(text) {
  if (text.length > 2048 || /[\r\n]/.test(text)) return false;
  for (let i = 0; i < text.length; i++) {
    const unit = text.charCodeAt(i);
    if (unit >= 55296 && unit <= 56319) {
      const next = text.charCodeAt(++i);
      if (!(next >= 56320 && next <= 57343)) return false;
    } else if (unit >= 56320 && unit <= 57343) return false;
  }
  return true;
}
function mountRaveldexDropdown(options) {
  const descriptor = options && typeof options === "object" ? Object.getOwnPropertyDescriptor(options, "root") : void 0;
  if (!descriptor || !("value" in descriptor)) fail("INVALID_OPTIONS", "root");
  const existing = mounted.get(descriptor.value);
  if (existing) {
    if (existing.kind !== "dropdown") fail("INVALID_OPTIONS", "root");
    return existing.handle;
  }
  const o = record(options, ["root", "engine", "documents", "fullResults", "maxResults", "debounceMs", "mode", "shortcut", "messages"], "dropdown.options");
  const maximum = o.maxResults === void 0 ? 5 : o.maxResults;
  if (typeof maximum !== "number" || !Number.isSafeInteger(maximum) || maximum < 1 || maximum > 20) fail("INVALID_OPTIONS", "dropdown.maxResults");
  const mode = o.mode === void 0 ? "prefix" : o.mode;
  if (mode !== "prefix" && mode !== "text") fail("INVALID_OPTIONS", "dropdown.mode");
  const shortcut = o.shortcut === void 0 ? false : o.shortcut;
  if (typeof shortcut !== "boolean") fail("INVALID_OPTIONS", "dropdown.shortcut");
  const captured = captureOptions2({
    root: o.root,
    engine: o.engine,
    documents: o.documents,
    pageSize: maximum,
    mode,
    ...o.debounceMs === void 0 ? {} : { debounceMs: o.debounceMs }
  });
  const route = record(o.fullResults, ["url", "queryParameter"], "dropdown.fullResults");
  const rawURL = displayName(route.url, 2048, "dropdown.fullResults.url");
  const queryParameter = route.queryParameter === void 0 ? "q" : displayName(route.queryParameter, 64, "dropdown.fullResults.queryParameter");
  if (!/^[A-Za-z][A-Za-z0-9_-]{0,63}$/.test(queryParameter)) fail("INVALID_OPTIONS", "dropdown.fullResults.queryParameter");
  let destination;
  try {
    destination = new URL(rawURL, captured.root.ownerDocument.baseURI);
  } catch {
    fail("INVALID_OPTIONS", "dropdown.fullResults.url");
  }
  if (!["http:", "https:"].includes(destination.protocol) || destination.username || destination.password) fail("INVALID_OPTIONS", "dropdown.fullResults.url");
  const overrides = record(o.messages ?? {}, Object.keys(defaults), "dropdown.messages");
  const messages = { ...defaults };
  for (const key of Object.keys(overrides)) {
    Object.defineProperty(messages, key, { value: displayName(overrides[key], 512, `dropdown.messages.${key}`), enumerable: true });
  }
  Object.freeze(messages);
  const doc = captured.root.ownerDocument, win = doc.defaultView;
  if (!win || typeof win.AbortController !== "function" || typeof win.setTimeout !== "function") fail("UNSUPPORTED_ENVIRONMENT", "host");
  const popup = doc.createElement("div");
  if (typeof popup.showPopover !== "function" || typeof popup.hidePopover !== "function") fail("UNSUPPORTED_ENVIRONMENT", "dropdown.popover");
  const knownRoots = [];
  let tree = captured.root.getRootNode();
  while (tree instanceof win.ShadowRoot) {
    knownRoots.push(tree);
    tree = tree.host.getRootNode();
  }
  const node = (tag, part, text) => {
    const value = doc.createElement(tag);
    value.className = `raveldex-dropdown__${part}`;
    value.setAttribute(`data-raveldex-dropdown-${part}`, "");
    if (text !== void 0) value.textContent = text;
    return value;
  };
  const id = `raveldex-dropdown-${++mountNumber}`;
  const indices = new Map([...captured.documents.keys()].map((key, index) => [key, index]));
  const shell = node("div", "root");
  shell.className = "raveldex-dropdown";
  shell.dataset.state = "idle";
  shell.setAttribute("aria-busy", "false");
  const form = node("form", "form");
  form.setAttribute("role", "search");
  form.setAttribute("aria-label", messages.label);
  const label = node("label", "label", messages.label);
  label.htmlFor = `${id}-query`;
  const input = node("input", "input");
  input.id = label.htmlFor;
  input.type = "text";
  input.maxLength = 2048;
  input.autocomplete = "off";
  input.placeholder = messages.placeholder;
  input.setAttribute("role", "combobox");
  input.setAttribute("aria-haspopup", "grid");
  input.setAttribute("aria-autocomplete", "list");
  input.setAttribute("aria-expanded", "false");
  const submit = node("button", "submit", messages.submit);
  submit.type = "submit";
  const clear = node("button", "clear", messages.clear);
  clear.type = "button";
  form.append(label, input, submit, clear);
  const status = node("p", "status", messages.idle);
  status.setAttribute("role", "status");
  status.setAttribute("aria-atomic", "true");
  const retry = node("button", "retry", messages.retry);
  retry.type = "button";
  retry.hidden = true;
  const full = node("a", "full-results", messages.fullResults);
  full.hidden = true;
  popup.className = "raveldex-dropdown__popup";
  popup.setAttribute("data-raveldex-dropdown-popup", "");
  popup.id = `${id}-popup`;
  popup.setAttribute("popover", "manual");
  popup.setAttribute("role", "grid");
  popup.setAttribute("aria-label", messages.resultsLabel);
  input.setAttribute("aria-controls", popup.id);
  if (shortcut) input.setAttribute("aria-keyshortcuts", "Control+K Meta+K");
  form.append(full);
  shell.append(form, status, retry, popup);
  const originalNodes = [...captured.root.childNodes], listeners = [];
  let destroyed = false, wanted = false, composing = false, suppressedComposition = false, imeSubmit = false;
  let compositionValue, timer, sequence = 0, controller;
  let flight, rows = [], activeIndex = -1, presented, snapshotRaw;
  let nativeTotal, geometryFailure, nativeClosing = false;
  const listen = (target, type, callback, capture = false) => {
    target.addEventListener(type, callback, capture);
    listeners.push(() => target.removeEventListener(type, callback, capture));
  };
  const focused = () => {
    let element = doc.activeElement;
    while (element) {
      const shadow = element.shadowRoot ?? knownRoots.find((root) => root.host === element);
      if (!shadow?.activeElement) break;
      element = shadow.activeElement;
    }
    return element;
  };
  const ancestor = (outer, inner) => {
    let element = inner;
    while (element) {
      if (element === outer) return true;
      element = element.parentElement ?? element.getRootNode().host ?? null;
    }
    return false;
  };
  const foreignModal = () => {
    if ([...doc.querySelectorAll("dialog:modal")].some((dialog) => !ancestor(dialog, captured.root))) return true;
    let element = focused();
    if (element && !element.shadowRoot && !knownRoots.some((root) => root.host === element) && (element.localName.includes("-") || [
      "article",
      "aside",
      "blockquote",
      "div",
      "footer",
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "header",
      "main",
      "nav",
      "p",
      "section",
      "span"
    ].includes(element.localName))) return true;
    while (element) {
      if (element.matches("dialog:modal") && !ancestor(element, captured.root)) return true;
      element = element.parentElement ?? element.getRootNode().host ?? null;
    }
    return false;
  };
  const usable = () => !destroyed && mounted.get(captured.root)?.handle === handle && captured.root.ownerDocument === doc && captured.root.isConnected && shell.parentNode === captured.root && input.isConnected && !input.matches(":disabled");
  const live = (ticket) => usable() && sequence === ticket && !foreignModal();
  const visible = () => popup.isConnected && popup.matches(":popover-open");
  const announce = (text) => {
    if (status.textContent !== text) status.textContent = text;
  };
  const clearActive = (resetIntent = true) => {
    input.removeAttribute("aria-activedescendant");
    activeIndex = -1;
    if (resetIntent && flight) flight.intent = void 0;
    for (const row of rows) {
      row.cell.setAttribute("aria-selected", "false");
      row.cell.classList.remove("is-active");
    }
  };
  const cancelTimer = () => {
    if (timer !== void 0) {
      win.clearTimeout(timer);
      timer = void 0;
    }
  };
  const invalidate = () => {
    const ticket = ++sequence;
    cancelTimer();
    const old = controller;
    controller = void 0;
    flight = void 0;
    clearActive();
    rows = [];
    snapshotRaw = void 0;
    presented = void 0;
    nativeTotal = void 0;
    try {
      popup.replaceChildren();
      if (sequence !== ticket || destroyed) return ticket;
      if (visible() && !nativeClosing) popup.hidePopover();
      if (sequence !== ticket || destroyed) return ticket;
      input.setAttribute("aria-expanded", "false");
      shell.setAttribute("aria-busy", "false");
      retry.hidden = true;
      if (opened.get(doc) === registration) opened.delete(doc);
    } finally {
      old?.abort();
    }
    return ticket;
  };
  const handoff = () => {
    const raw = input.value;
    full.hidden = composing || suppressedComposition || !raw.trim().length || !validText(raw);
    if (!full.hidden) {
      const url = new URL(destination.href);
      url.searchParams.set(queryParameter, raw);
      full.href = url.href;
    } else full.removeAttribute("href");
  };
  const close = () => {
    if (destroyed) return;
    wanted = false;
    if (composing) suppressedComposition = true;
    composing = false;
    compositionValue = void 0;
    const ticket = invalidate();
    if (!usable() || sequence !== ticket) return;
    handoff();
    shell.dataset.state = "closed";
    announce(messages.closed);
  };
  const registration = { close };
  const reconcile = () => {
    if (presented === sequence && !visible()) close();
  };
  const canNavigate = () => wanted && !composing && presented === sequence && visible() && snapshotRaw === input.value && live(sequence);
  const revealActive = () => {
    const row = rows[activeIndex];
    if (!row || !visible()) return;
    const bounds = popup.getBoundingClientRect(), cell = row.cell.getBoundingClientRect();
    const top = bounds.top + popup.clientTop, bottom = top + popup.clientHeight;
    if (cell.top < top || cell.height > popup.clientHeight) popup.scrollTop -= top - cell.top;
    else if (cell.bottom > bottom) popup.scrollTop += cell.bottom - bottom;
  };
  const setActive = (index) => {
    if (!canNavigate() || !rows.length) return;
    clearActive(false);
    activeIndex = Math.max(0, Math.min(index, rows.length - 1));
    const row = rows[activeIndex];
    row.cell.setAttribute("aria-selected", "true");
    row.cell.classList.add("is-active");
    input.setAttribute("aria-activedescendant", row.cell.id);
    revealActive();
  };
  const position = () => {
    geometryFailure = void 0;
    if (!usable()) {
      geometryFailure = "anchor";
      return false;
    }
    const view = win.visualViewport, leftEdge = view?.offsetLeft ?? 0, topEdge = view?.offsetTop ?? 0;
    const width = view?.width ?? win.innerWidth, height = view?.height ?? win.innerHeight;
    const anchor = input.getBoundingClientRect(), panel = shell.getBoundingClientRect(), gutter = 8;
    if (width <= gutter * 2 || height <= gutter * 2 || !anchor.width || !anchor.height || anchor.bottom <= topEdge || anchor.top >= topEdge + height || anchor.right <= leftEdge || anchor.left >= leftEdge + width) {
      geometryFailure = "anchor";
      return false;
    }
    const availableBelow = Math.max(0, topEdge + height - gutter - panel.bottom), availableAbove = Math.max(0, panel.top - topEdge - gutter);
    const need = Math.min(popup.scrollHeight || 160, 160), above = availableBelow < need && availableAbove > availableBelow;
    const available = above ? availableAbove : availableBelow;
    const style = win.getComputedStyle(popup), borders = (parseFloat(style.borderTopWidth) || 0) + (parseFloat(style.borderBottomWidth) || 0);
    if (available < 44 + borders) {
      geometryFailure = "space";
      return false;
    }
    const inlineSize = Math.min(anchor.width, width - gutter * 2), left = Math.max(leftEdge + gutter, Math.min(anchor.left, leftEdge + width - gutter - inlineSize));
    popup.style.setProperty("--_left", `${left}px`);
    popup.style.setProperty("--_width", `${inlineSize}px`);
    popup.style.setProperty("--_max-height", `${available}px`);
    const blockSize = visible() ? popup.getBoundingClientRect().height : Math.min(available, popup.scrollHeight || 160);
    popup.style.setProperty("--_top", `${above ? Math.max(topEdge + gutter, panel.top - blockSize) : panel.bottom}px`);
    return true;
  };
  const collapseForSpace = (ticket, total) => {
    if (!live(ticket)) return;
    wanted = false;
    clearActive();
    rows = [];
    snapshotRaw = void 0;
    presented = void 0;
    if (visible()) popup.hidePopover();
    if (!live(ticket)) return;
    input.setAttribute("aria-expanded", "false");
    popup.replaceChildren();
    if (!live(ticket)) return;
    if (opened.get(doc) === registration) opened.delete(doc);
    shell.dataset.state = "results";
    shell.setAttribute("aria-busy", "false");
    handoff();
    announce(format(total === 1 ? messages.resultsOne : messages.resultsMany, { total, count: 0 }) + " " + messages.noSpace);
  };
  const show = (ticket) => {
    if (!live(ticket) || !wanted || !rows.length || !position()) return false;
    const previous = opened.get(doc);
    opened.set(doc, registration);
    if (previous && previous !== registration) previous.close();
    if (!live(ticket) || !wanted || opened.get(doc) !== registration) return false;
    if (!visible()) popup.showPopover();
    if (!live(ticket) || !wanted || opened.get(doc) !== registration || !visible()) {
      if (visible() && presented !== sequence) popup.hidePopover();
      return false;
    }
    if (!position()) return false;
    presented = ticket;
    input.setAttribute("aria-expanded", "true");
    return true;
  };
  const setComposing = () => {
    const ticket = invalidate();
    if (!live(ticket)) return;
    wanted = true;
    handoff();
    shell.dataset.state = "composing";
    announce(messages.composing);
  };
  const execute = (intent) => {
    if (!usable() || foreignModal()) return Promise.resolve();
    reconcile();
    if (!usable() || foreignModal()) return Promise.resolve();
    if (composing) {
      setComposing();
      return Promise.resolve();
    }
    const raw = input.value;
    if (flight?.raw === raw && live(flight.ticket)) {
      if (intent) flight.intent = intent;
      return flight.promise;
    }
    const ticket = invalidate();
    if (!live(ticket)) return Promise.resolve();
    wanted = true;
    handoff();
    if (raw.length <= 2048 && !raw.trim().length) {
      shell.dataset.state = "idle";
      announce(messages.idle);
      return Promise.resolve();
    }
    const active = new win.AbortController();
    controller = active;
    let finish;
    const promise = new Promise((resolve) => {
      finish = resolve;
    });
    const job = { ticket, raw, promise, intent };
    flight = job;
    const current = () => wanted && live(ticket) && controller === active && !active.signal.aborted && (presented === void 0 || visible());
    shell.dataset.state = "loading";
    shell.setAttribute("aria-busy", "true");
    announce(messages.searching);
    void Promise.resolve().then(async () => {
      try {
        if (!current()) return;
        const found = await captured.engine.search(queryFromText(raw, captured.mode), { limit: maximum, offset: 0, signal: active.signal });
        if (!current()) return;
        assertResult(found, captured);
        if (found.hits.length !== Math.min(maximum, found.total)) fail("INCOMPATIBLE_CAPABILITY", "dropdown.result.hits");
        const fragment = doc.createDocumentFragment(), nextRows = [];
        for (const hit of found.hits) {
          const display = captured.documents.get(hit.id);
          const row = node("div", "row");
          row.setAttribute("role", "row");
          const cell = node("div", "cell");
          cell.setAttribute("role", "gridcell");
          cell.id = `${id}-result-${indices.get(hit.id)}`;
          cell.setAttribute("aria-selected", "false");
          cell.setAttribute("data-raveldex-dropdown-result", hit.id);
          const link = node("a", "link", display.title);
          link.href = display.url;
          link.tabIndex = -1;
          cell.append(link);
          row.append(cell);
          fragment.append(row);
          nextRows.push({ cell, link });
        }
        if (!current()) return;
        clearActive(false);
        popup.replaceChildren(fragment);
        if (!current()) return;
        rows = nextRows;
        snapshotRaw = raw;
        nativeTotal = found.total;
        if (rows.length && !show(ticket)) {
          if (live(ticket)) {
            if (geometryFailure === "space") collapseForSpace(ticket, found.total);
            else close();
          }
          return;
        }
        if (!current()) return;
        shell.dataset.state = found.total ? "results" : "empty";
        announce(found.total ? format(found.total === 1 ? messages.resultsOne : messages.resultsMany, { total: found.total, count: rows.length }) : messages.noResults);
        if (!current()) return;
        if (rows.length && !position()) {
          if (geometryFailure === "space") collapseForSpace(ticket, found.total);
          else close();
          return;
        }
        if (job.intent && rows.length) setActive(job.intent === "first" ? 0 : rows.length - 1);
      } catch (reason) {
        if (!current()) return;
        const value = typeof reason === "object" && reason !== null ? Object.getOwnPropertyDescriptor(reason, "code") : void 0;
        const code = value && "value" in value && ERROR_CODES2.includes(value.value) ? String(value.value) : "INTERNAL_ERROR";
        clearActive();
        rows = [];
        snapshotRaw = void 0;
        presented = void 0;
        popup.replaceChildren();
        if (!current()) return;
        if (visible()) popup.hidePopover();
        if (!current()) return;
        input.setAttribute("aria-expanded", "false");
        shell.dataset.state = "error";
        announce(format(messages.error, { code }));
        if (current()) {
          retry.hidden = false;
          wanted = false;
          if (opened.get(doc) === registration) opened.delete(doc);
        }
      } finally {
        if (controller === active) {
          controller = void 0;
          if (flight === job) flight = void 0;
        }
        if (live(ticket)) shell.setAttribute("aria-busy", "false");
        finish();
      }
    });
    return promise;
  };
  const schedule = () => {
    if (!usable() || foreignModal()) return;
    if (composing) {
      setComposing();
      return;
    }
    const ticket = invalidate();
    if (!live(ticket)) return;
    wanted = true;
    handoff();
    if (input.value.length <= 2048 && !input.value.trim().length) {
      shell.dataset.state = "idle";
      announce(messages.idle);
      return;
    }
    shell.dataset.state = "waiting";
    announce("");
    if (live(ticket)) timer = win.setTimeout(() => {
      timer = void 0;
      void execute();
    }, captured.debounceMs);
  };
  const focusAndSearch = () => {
    if (!usable() || foreignModal()) return;
    const ticket = sequence;
    input.focus();
    if (live(ticket) && focused() === input) void execute();
  };
  const clearInput = () => {
    if (!usable()) return;
    const before = sequence, active = focused();
    if (active === retry || active === full || active && popup.contains(active)) {
      input.focus();
      if (!usable() || sequence !== before || focused() !== input) return;
    }
    input.value = "";
    suppressedComposition = composing || suppressedComposition;
    composing = false;
    compositionValue = void 0;
    wanted = false;
    const ticket = invalidate();
    if (usable() && sequence === ticket) {
      handoff();
      shell.dataset.state = "idle";
      announce(messages.idle);
    }
  };
  const handle = Object.freeze({
    search: (text) => {
      if (!usable()) return Promise.resolve();
      if (text !== void 0) {
        if (typeof text !== "string" || /[\r\n]/.test(text)) fail("INVALID_OPTIONS", "dropdown.search");
        input.value = text;
      }
      return execute();
    },
    open: focusAndSearch,
    close,
    clear: clearInput,
    destroy: () => {
      if (destroyed) return;
      destroyed = true;
      wanted = false;
      sequence++;
      cancelTimer();
      clearActive();
      rows = [];
      presented = void 0;
      snapshotRaw = void 0;
      for (const remove of listeners) remove();
      const old = controller;
      controller = void 0;
      flight = void 0;
      old?.abort();
      if (visible()) popup.hidePopover();
      if (opened.get(doc) === registration) opened.delete(doc);
      if (mounted.get(captured.root)?.handle !== handle) return;
      mounted.delete(captured.root);
      captured.root.replaceChildren(...originalNodes);
    }
  });
  listen(form, "submit", (event) => {
    event.preventDefault();
    if (!imeSubmit) void execute();
  });
  listen(input, "input", (event) => {
    if (suppressedComposition) return;
    if (event.isComposing) composing = true;
    if (!composing && compositionValue === input.value) {
      compositionValue = void 0;
      return;
    }
    compositionValue = void 0;
    schedule();
  });
  listen(input, "compositionstart", () => {
    composing = true;
    suppressedComposition = false;
    compositionValue = void 0;
    setComposing();
  });
  listen(input, "compositionend", () => {
    if (suppressedComposition) {
      suppressedComposition = false;
      composing = false;
      compositionValue = input.value;
      if (usable()) handoff();
      return;
    }
    if (!composing) return;
    composing = false;
    compositionValue = input.value;
    schedule();
  });
  listen(input, "keydown", (event) => {
    const key = event;
    if (key.defaultPrevented) return;
    if (key.key === "Tab" && !key.altKey && !key.ctrlKey && !key.metaKey) {
      if (visible() || ["waiting", "loading", "composing"].includes(shell.dataset.state ?? "")) close();
      return;
    }
    if (composing || key.isComposing || key.keyCode === 229) {
      clearActive();
      imeSubmit = true;
      void Promise.resolve().then(() => {
        imeSubmit = false;
      });
      return;
    }
    reconcile();
    const modified = key.altKey || key.ctrlKey || key.metaKey || key.shiftKey;
    if (!modified && (key.key === "ArrowDown" || key.key === "ArrowUp")) {
      key.preventDefault();
      if (canNavigate() && rows.length) setActive(activeIndex < 0 ? key.key === "ArrowDown" ? 0 : rows.length - 1 : activeIndex + (key.key === "ArrowDown" ? 1 : -1));
      else void execute(key.key === "ArrowDown" ? "first" : "last");
    } else if (!modified && key.key === "Enter" && canNavigate() && activeIndex >= 0) {
      key.preventDefault();
      rows[activeIndex].link.click();
    } else if (!modified && key.key === "Escape" && (wanted || timer !== void 0 || controller !== void 0 || visible())) {
      key.preventDefault();
      close();
    } else if (["ArrowLeft", "ArrowRight", "Home", "End", "Backspace", "Delete"].includes(key.key) || key.key.length === 1 || modified) clearActive();
  });
  listen(shell, "keydown", (event) => {
    const key = event;
    if (key.defaultPrevented || key.altKey || key.ctrlKey || key.metaKey) return;
    const tab = key.key === "Tab" && (visible() || ["waiting", "loading", "composing"].includes(shell.dataset.state ?? ""));
    const escape = key.key === "Escape" && !key.shiftKey && !composing && !key.isComposing && key.keyCode !== 229 && (wanted || timer !== void 0 || controller !== void 0 || visible());
    if (!tab && !escape) return;
    if (escape) key.preventDefault();
    const ticket = sequence, active = focused();
    if (escape && active && popup.contains(active)) {
      input.focus();
      if (!usable() || sequence !== ticket || focused() !== input) return;
    }
    close();
  });
  listen(input, "blur", (event) => {
    const next = event.relatedTarget;
    if (next instanceof win.Node && captured.root.contains(next)) return;
    const ticket = sequence;
    void Promise.resolve().then(() => {
      const active = focused();
      if (wanted && sequence === ticket && (!active || !captured.root.contains(active))) close();
    });
  });
  listen(clear, "click", clearInput);
  listen(retry, "click", focusAndSearch);
  listen(popup, "beforetoggle", (event) => {
    const state = event.newState;
    if (state === "open") {
      if (!wanted || !rows.length || !live(sequence)) event.preventDefault();
    } else if (state === "closed" && presented === sequence) {
      nativeClosing = true;
      void Promise.resolve().then(() => {
        nativeClosing = false;
      });
      close();
    }
  });
  listen(popup, "toggle", () => {
    if (destroyed) return;
    if (presented === sequence && !visible()) close();
    else if (visible() && (presented !== sequence || !wanted)) popup.hidePopover();
  });
  const resolvedInside = /* @__PURE__ */ new WeakMap();
  const outside = (event) => {
    if (!wanted || destroyed) return;
    const path = event.composedPath();
    if (path.includes(captured.root) || path.includes(shell) || path.includes(popup)) {
      resolvedInside.set(event, true);
      return;
    }
    if (knownRoots.some((root) => path.includes(root.host))) {
      const ticket = sequence;
      void Promise.resolve().then(() => {
        if (wanted && sequence === ticket && !resolvedInside.get(event)) close();
      });
    } else {
      resolvedInside.set(event, false);
      close();
    }
  };
  for (const target of [doc, ...knownRoots]) {
    listen(target, "pointerdown", outside, true);
    listen(target, "focusin", outside, true);
  }
  const reposition = (event) => {
    if (!visible()) return;
    if (event.target instanceof win.Node && popup.contains(event.target)) return;
    if (!position()) {
      if (geometryFailure === "space" && nativeTotal !== void 0) collapseForSpace(sequence, nativeTotal);
      else close();
    } else revealActive();
  };
  listen(win, "resize", reposition);
  listen(win, "scroll", reposition, true);
  if (win.visualViewport) {
    listen(win.visualViewport, "resize", reposition);
    listen(win.visualViewport, "scroll", reposition);
  }
  listen(win, "blur", () => {
    if (wanted) close();
  });
  if (shortcut) listeners.push(registerModalShortcut(doc, {
    eligible: () => {
      const active = focused();
      return usable() && !foreignModal() && !(active && (active.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(active.tagName)));
    },
    isOpen: visible,
    open: () => {
      focusAndSearch();
      return focused() === input;
    }
  }));
  mounted.set(captured.root, { kind: "dropdown", handle });
  try {
    captured.root.replaceChildren(shell);
  } catch (reason) {
    if (mounted.get(captured.root)?.handle === handle) {
      try {
        handle.destroy();
      } catch {
      }
    }
    throw reason;
  }
  return handle;
}

// <stdin>
var owner = createRaveldex({ schema: { text: { body: {} } } });
await owner.addMany([{ id: "a", text: { body: "alpha" } }]);
window.owner = owner;
window.handle = mountRaveldexDropdown({ root: document.querySelector("#root"), engine: owner, documents: [{ id: "a", title: "Alpha", url: "/a/" }], fullResults: { url: "/search/" } });
await window.handle.search("alpha");
window.ready = true;
