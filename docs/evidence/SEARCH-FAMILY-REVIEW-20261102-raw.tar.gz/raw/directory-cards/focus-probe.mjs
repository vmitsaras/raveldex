import { readFile,writeFile,copyFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { build } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/esbuild/lib/main.js';
import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
const repo='/Users/vasilis/Documents/GitHub/raveldex',dir='/private/tmp/raveldex-family-review-xzxx5var/directory-cards';
await copyFile(repo+'/test/ui/directory-view-fixture.mjs',dir+'/probe-entry.mjs');await copyFile(repo+'/test/fixtures/directory.mjs',dir+'/directory-data.mjs');
await build({entryPoints:[dir+'/probe-entry.mjs'],outfile:dir+'/probe-bundle.mjs',bundle:true,platform:'browser',format:'esm',target:'es2022',alias:{'@vmitsaras/raveldex':repo+'/dist/index.js','@vmitsaras/raveldex/addons/filters':repo+'/dist/addons/filters/index.js','@vmitsaras/raveldex/addons/facets':repo+'/dist/addons/facets/index.js','@vmitsaras/raveldex/addons/ui/directory':repo+'/dist/addons/ui/directory.js','@vmitsaras/raveldex/addons/ui/directory/view':repo+'/dist/addons/ui/directory-view.js'},logLevel:'silent'});
const server=createServer(async(req,res)=>{res.setHeader('content-type',req.url==='/probe.mjs'?'text/javascript':'text/html');res.end(req.url==='/probe.mjs'?await readFile(dir+'/probe-bundle.mjs'):'<!doctype html><html lang=en><title>Focus probe</title><main><h1>Directory</h1><section id=directory><p>Authored</p></section></main><script type=module src=/probe.mjs></script></html>');});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({channel:'chrome',headless:true}),page=await browser.newPage(),origin=`http://127.0.0.1:${server.address().port}`;page.setDefaultTimeout(10000);const observations=[];
try{
 await page.goto(origin);await page.waitForFunction(()=>window.directoryReady);
 for(const method of ['page','refresh']){
  if(method==='refresh'){
   await page.evaluate(async()=>{const f=window.directoryView;await f.remount();await f.controller().setPage(2);await f.mutate();await f.controller().setPage(3);});
  }
  const selector=method==='page'?'[data-raveldex-directory-next]':'[data-raveldex-directory-retry]';
  await page.evaluate(()=>window.directoryView.hold());await page.locator(selector).focus();await page.locator(selector).press('Enter');await page.waitForFunction(()=>window.directoryHeld);await page.waitForTimeout(60);
  observations.push({method,phase:'held',...await page.evaluate(s=>({active:document.activeElement.outerHTML,hidden:document.querySelector(s).closest('nav')?.hidden??document.querySelector(s).hidden,status:window.directoryView.controller().getSnapshot().status}),selector)});
  await page.evaluate(()=>window.directoryView.release());await page.waitForFunction(()=>window.directoryView.controller().getSnapshot().status==='ready');
  observations.push({method,phase:'complete',...await page.evaluate(s=>({active:document.activeElement.outerHTML,hidden:document.querySelector(s).closest('nav')?.hidden??document.querySelector(s).hidden,status:window.directoryView.controller().getSnapshot().status}),selector)});
 }
 await writeFile(dir+'/focus-probe.json',JSON.stringify({browser:browser.version(),observations},null,2)+'\n');console.log(JSON.stringify({browser:browser.version(),observations},null,2));
}finally{await page.evaluate(()=>window.directoryView?.cleanup());await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
