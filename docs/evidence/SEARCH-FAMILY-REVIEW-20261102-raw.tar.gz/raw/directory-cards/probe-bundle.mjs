// dist/core/errors/error.js
var ERROR_CODES = Object.freeze([
  "INVALID_SCHEMA",
  "INVALID_RECORD",
  "INVALID_QUERY",
  "INVALID_OPTIONS",
  "ID_EXISTS",
  "ID_NOT_FOUND",
  "LIMIT_EXCEEDED",
  "QUEUE_FULL",
  "WORK_LIMIT_EXCEEDED",
  "DEADLINE_EXCEEDED",
  "CANCELLED",
  "DISPOSED",
  "MISSING_CAPABILITY",
  "INCOMPATIBLE_CAPABILITY",
  "REVISION_MISMATCH",
  "REVISION_EXHAUSTED",
  "RESOURCE_EXHAUSTED",
  "UNSUPPORTED_ENVIRONMENT",
  "INTERNAL_ERROR"
]);
var RaveldexError = class extends Error {
  code;
  details;
  constructor(code, details = {}) {
    super(`Raveldex: ${code}`);
    this.name = "RaveldexError";
    this.code = code;
    this.details = Object.freeze({
      ...details.path === void 0 ? {} : { path: details.path.slice(0, 256) },
      ...details.limit === void 0 ? {} : { limit: details.limit },
      ...details.actual === void 0 ? {} : { actual: details.actual }
    });
  }
};
function invalid(code, path) {
  throw new RaveldexError(code, { path });
}
function bound(actual, limit, path) {
  if (!Number.isSafeInteger(actual) || actual > limit) {
    throw new RaveldexError("LIMIT_EXCEEDED", { path, limit, actual });
  }
}

// dist/core/contracts/data.js
var Admission = class {
  maximum;
  entries = 0;
  constructor(maximum) {
    this.maximum = maximum;
  }
  get count() {
    return this.entries;
  }
  charge(count, path) {
    this.entries += count;
    bound(this.entries, this.maximum, path);
  }
};
function ownObject(input, code, path, admission2) {
  if (typeof input !== "object" || input === null)
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Object.prototype)
    invalid(code, path);
  const keys = Reflect.ownKeys(input);
  admission2.charge(keys.length, path);
  const copy = /* @__PURE__ */ Object.create(null);
  for (const key of keys) {
    if (typeof key !== "string")
      invalid(code, path);
    const descriptor = Object.getOwnPropertyDescriptor(input, key);
    if (!descriptor || !("value" in descriptor))
      invalid(code, path);
    copy[key] = descriptor.value;
  }
  return copy;
}
function ownArray(input, maximum, code, path, admission2) {
  if (!Array.isArray(input))
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Array.prototype)
    invalid(code, path);
  bound(input.length, maximum, path);
  const keys = Reflect.ownKeys(input);
  admission2.charge(keys.length, path);
  if (keys.length !== input.length + 1)
    invalid(code, path);
  for (const key of keys) {
    if (key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= input.length)) {
      invalid(code, path);
    }
  }
  const copy = [];
  for (let i = 0; i < input.length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(input, String(i));
    if (!descriptor || !("value" in descriptor))
      invalid(code, `${path}[${i}]`);
    copy.push(descriptor.value);
  }
  return copy;
}
function keysOnly(data, allowed, code, path) {
  for (const key of Object.keys(data))
    if (!allowed.includes(key))
      invalid(code, path);
}
function has(data, key) {
  return Object.prototype.hasOwnProperty.call(data, key);
}
function stringValue(input, maximum, code, path) {
  if (typeof input !== "string")
    invalid(code, path);
  bound(input.length, maximum, path);
  return input;
}
function* scanUnicode(value, code, path) {
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, path);
    i += width;
    yield { workUnits: 1 };
  }
}
function codePointWidth(value, index, code, path) {
  const first = value.charCodeAt(index);
  if (first >= 55296 && first <= 56319) {
    const second = value.charCodeAt(index + 1);
    if (!(second >= 56320 && second <= 57343))
      invalid(code, path);
    return 2;
  }
  if (first >= 56320 && first <= 57343)
    invalid(code, path);
  return 1;
}

// dist/addons/ui/query.js
function queryFromText(text2, mode) {
  if (!text2)
    return { kind: "all" };
  if (mode === "phrase")
    return { kind: "extension", capability: "phrases", version: 1, payload: { text: text2 } };
  if (mode !== "prefix" || text2.length > 2048)
    return { kind: "text", text: text2 };
  const words = text2.matchAll(/[\p{L}\p{N}][\p{L}\p{N}\p{M}]*/gu);
  let last;
  let count = 0;
  for (const word of words) {
    last = word;
    count++;
  }
  if (!last || [...last[0].normalize("NFKC").toLowerCase()].length < 2)
    return { kind: "text", text: text2 };
  const ending = { kind: "group", variants: [{ text: count === 1 ? text2 : text2.slice(last.index), match: "prefix" }] };
  const earlier = text2.slice(0, last.index);
  return count > 1 ? { kind: "and", children: [{ kind: "text", text: earlier }, ending] } : ending;
}

// dist/addons/ui/directory-state.js
var directoryConfigurations = /* @__PURE__ */ new WeakMap();
var order = (a, b) => a < b ? -1 : a > b ? 1 : 0;
function failDirectory(path, code = "INVALID_OPTIONS") {
  throw new RaveldexError(code, { path: `ui.directory.${path}` });
}
var admission = () => new Admission(16384);
function object(input, allowed, path, budget = admission()) {
  const result = ownObject(input, "INVALID_OPTIONS", `ui.directory.${path}`, budget);
  keysOnly(result, allowed, "INVALID_OPTIONS", `ui.directory.${path}`);
  return result;
}
function text(input, maximum, path) {
  if (typeof input !== "string" || input.length > maximum)
    failDirectory(path);
  for (let i = 0; i < input.length; )
    i += codePointWidth(input, i, "INVALID_OPTIONS", `ui.directory.${path}`);
  return input;
}
function queryText(input) {
  const value = text(input, 2048, "text");
  if (/[\r\n]/.test(value))
    failDirectory("text");
  return value;
}
function integer(input, minimum, maximum, path) {
  if (typeof input !== "number" || !Number.isSafeInteger(input) || input < minimum || input > maximum)
    failDirectory(path);
  return input;
}
function captureDirectory(input) {
  const budget = admission(), o = object(input, ["engine", "groups", "pageSize", "mode"], "options", budget);
  const engine2 = o.engine;
  if (!engine2 || typeof engine2.search !== "function")
    failDirectory("engine");
  const pageSize = integer(o.pageSize === void 0 ? 20 : o.pageSize, 1, 100, "pageSize");
  const mode = o.mode === void 0 ? "prefix" : o.mode;
  if (mode !== "prefix" && mode !== "text")
    failDirectory("mode");
  const fields = /* @__PURE__ */ new Set();
  let units = 0;
  const groups2 = ownArray(o.groups === void 0 ? [] : o.groups, 8, "INVALID_OPTIONS", "ui.directory.groups", budget).map((raw) => {
    const item = object(raw, ["field", "values", "limit"], "group", budget), field = text(item.field, 64, "field");
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) || ["constructor", "prototype"].includes(field) || fields.has(field))
      failDirectory("field");
    fields.add(field);
    units += field.length;
    if (units > 65536)
      failDirectory("configuration", "LIMIT_EXCEEDED");
    const seen = /* @__PURE__ */ new Set(), values = ownArray(item.values, 128, "INVALID_OPTIONS", "ui.directory.values", budget).map((rawValue) => {
      const value = text(rawValue, 1024, "value");
      if (seen.has(value))
        failDirectory("values");
      seen.add(value);
      units += value.length;
      if (units > 65536)
        failDirectory("configuration", "LIMIT_EXCEEDED");
      return value;
    }).sort(order);
    return Object.freeze({ field, values: Object.freeze(values), limit: integer(item.limit === void 0 ? 20 : item.limit, 0, 100, "limit") });
  });
  return { config: Object.freeze({ groups: Object.freeze(groups2), pageSize, maxPage: Math.ceil(1e4 / pageSize), mode }), search: engine2.search.bind(engine2) };
}
function captureState(config, input) {
  const budget = admission(), o = object(input, ["text", "filters", "page"], "state", budget);
  const raw = queryText(o.text), page = integer(o.page, 1, config.maxPage, "page");
  const fields = config.groups.map((g) => g.field), selected = object(o.filters, fields, "filters", budget);
  const filters = /* @__PURE__ */ Object.create(null);
  let units = 0;
  for (const group of config.groups) {
    const seen = /* @__PURE__ */ new Set();
    filters[group.field] = Object.freeze(ownArray(Object.hasOwn(selected, group.field) ? selected[group.field] : [], 16, "INVALID_OPTIONS", "ui.directory.selected", budget).map((rawValue) => {
      const value = text(rawValue, 1024, "selected");
      if (seen.has(value) || !group.values.includes(value))
        failDirectory("selected");
      seen.add(value);
      units += value.length;
      if (units > 8192)
        failDirectory("selected", "LIMIT_EXCEEDED");
      return value;
    }).sort(order));
  }
  return Object.freeze({ text: raw, filters: Object.freeze(filters), page });
}
var queryKey = (state) => JSON.stringify([state.text, state.filters]);
var stateKey = (state) => JSON.stringify([state.text, state.filters, state.page]);
function directoryQuery(config, state) {
  const children = [state.text.trim().length ? queryFromText(state.text, config.mode) : { kind: "all" }];
  for (const group of config.groups) {
    const values = state.filters[group.field];
    if (values.length)
      children.push({ kind: "extension", capability: "set-membership", version: 1, payload: { field: group.field, values } });
  }
  return children.length === 1 ? children[0] : { kind: "and", children };
}
function capturePageValue(config, state, input, limit, offset) {
  const budget = admission(), o = object(input, ["revision", "total", "hits", "extensions", "model", "completeness"], "result", budget);
  if (o.model !== "raveldex-bm25-v1" || o.completeness !== "complete")
    failDirectory("result");
  const revision = integer(o.revision, 0, Number.MAX_SAFE_INTEGER, "revision"), total = integer(o.total, 0, 1e4, "total");
  const ids = /* @__PURE__ */ new Set();
  const hits = ownArray(o.hits, limit, "INVALID_OPTIONS", "ui.directory.hits", budget).map((raw) => {
    const hit = object(raw, ["id", "score"], "hit", budget), id = text(hit.id, 256, "hit.id");
    if (ids.has(id) || typeof hit.score !== "number" || !Number.isFinite(hit.score))
      failDirectory("hit");
    ids.add(id);
    return Object.freeze({ id, score: hit.score });
  });
  if (hits.length !== Math.min(limit, Math.max(0, total - offset)))
    failDirectory("hits");
  const facets = [], selected = /* @__PURE__ */ Object.create(null);
  if (config.groups.length) {
    const extensions = ownObject(o.extensions, "INVALID_OPTIONS", "ui.directory.extensions", budget);
    const facet = object(extensions.facets, ["fields"], "facets", budget);
    const fields = ownArray(facet.fields, config.groups.length, "INVALID_OPTIONS", "ui.directory.facets", budget);
    if (fields.length !== config.groups.length)
      failDirectory("facets");
    for (let index = 0; index < fields.length; index++) {
      const group = config.groups[index], f = object(fields[index], ["field", "buckets", "distinctValueTotal", "omittedBucketCount"], "facet", budget);
      if (f.field !== group.field)
        failDirectory("facet.field");
      const seen = /* @__PURE__ */ new Set();
      const buckets = ownArray(f.buckets, group.limit, "INVALID_OPTIONS", "ui.directory.buckets", budget).map((raw) => {
        const b = object(raw, ["kind", "value", "count"], "bucket", budget), count = integer(b.count, 0, total, "bucket.count");
        if (b.kind === "missing") {
          if (Object.hasOwn(b, "value") || seen.has("missing"))
            failDirectory("bucket");
          seen.add("missing");
          return Object.freeze({ kind: "missing", count });
        }
        if (b.kind !== "value")
          failDirectory("bucket");
        const value = b.value === null ? null : text(b.value, 1024, "bucket.value"), key = value === null ? "null" : "string:" + value;
        if (seen.has(key))
          failDirectory("bucket");
        seen.add(key);
        return Object.freeze({ kind: "value", value, count });
      });
      const distinctValueTotal = integer(f.distinctValueTotal, buckets.length, 1e4, "facet.total");
      const omittedBucketCount = integer(f.omittedBucketCount, 0, 1e4, "facet.omitted");
      if (omittedBucketCount !== distinctValueTotal - buckets.length)
        failDirectory("facet.omitted");
      facets.push(Object.freeze({ field: group.field, buckets: Object.freeze(buckets), distinctValueTotal, omittedBucketCount }));
      selected[group.field] = Object.freeze(state.filters[group.field].map((value) => {
        const bucket = buckets.find((b) => b.kind === "value" && b.value === value);
        return Object.freeze({ value, count: bucket ? bucket.count : omittedBucketCount ? null : 0 });
      }));
    }
  }
  return Object.freeze({ revision, total, hits: Object.freeze(hits), facets: Object.freeze(facets), selected: Object.freeze(selected) });
}
function capturePage(config, state, input, limit, offset) {
  try {
    return capturePageValue(config, state, input, limit, offset);
  } catch {
    return failDirectory("result", "INCOMPATIBLE_CAPABILITY");
  }
}

// dist/addons/ui/directory-view-options.js
var defaults = Object.freeze({
  label: "Search resources",
  placeholder: "Enter a word",
  submit: "Search",
  clear: "Clear all",
  filters: "Filter resources",
  closeFilters: "Close filters",
  countHint: "Counts include every active filter. Choices in one group combine with OR; different groups combine with AND.",
  selectedFilters: "Selected filters",
  remove: "Remove {group}: {value}",
  unknownCount: "count unavailable",
  emptyValue: "(Empty)",
  omittedCounts: "Counts shown for {shown} of {total} values. Other counts are unavailable.",
  resultsLabel: "Results",
  idle: "Search or browse all resources.",
  waiting: "Waiting for your search.",
  composing: "Finish entering text to search.",
  searching: "Searching.",
  noResults: "No results. Remove a filter or clear all to browse resources.",
  resultOne: "1 result. Showing {start}\u2013{end}.",
  results: "{total} results. Showing {start}\u2013{end}.",
  previous: "Previous page",
  next: "Next page",
  page: "Page {page} of {pages}.",
  error: "Search is unavailable ({code}). Try again.",
  stale: "The collection changed. Refresh results to continue.",
  retry: "Refresh results",
  invalid: "This search or selection exceeds the directory limits. Remove a choice or shorten the search."
});
var directoryMessage = (source, values) => source.replace(/\{([A-Za-z]+)\}/g, (token, key) => Object.hasOwn(values, key) ? String(values[key]) : token);
function captureDirectoryView(input) {
  const budget = new Admission(1e5), o = object(input, ["root", "controller", "documents", "groups", "debounceMs", "filtersOpen", "messages"], "view", budget);
  const root2 = o.root, controller2 = o.controller;
  const config = directoryConfigurations.get(controller2);
  if (!config || !root2 || root2.nodeType !== 1 || root2.namespaceURI !== "http://www.w3.org/1999/xhtml" || !root2.ownerDocument?.defaultView || typeof root2.replaceChildren !== "function")
    failDirectory("view.host");
  const label = (value, maximum = 512) => {
    const captured = text(value, maximum, "view.label");
    if (/^[\s\p{C}]*$/u.test(captured))
      failDirectory("view.label");
    return captured;
  };
  const overrides = object(o.messages === void 0 ? {} : o.messages, Object.keys(defaults), "view.messages", budget);
  const messages = Object.freeze(Object.fromEntries(Object.entries(defaults).map(([key, value]) => [key, Object.hasOwn(overrides, key) ? label(overrides[key]) : value])));
  let units = 0;
  const documents2 = /* @__PURE__ */ new Map();
  for (const raw of ownArray(o.documents, 1e4, "INVALID_OPTIONS", "ui.directory.view.documents", budget)) {
    const d = object(raw, ["id", "title", "url"], "view.document", budget), id = text(d.id, 256, "view.id"), title = label(d.title, 1024), url2 = text(d.url, 2048, "view.url");
    if (documents2.has(id))
      failDirectory("view.id");
    let parsed;
    try {
      parsed = new URL(url2, root2.ownerDocument.baseURI);
    } catch {
      failDirectory("view.url");
    }
    if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password)
      failDirectory("view.url");
    units += id.length + title.length + url2.length;
    if (units > 4e6)
      failDirectory("view.documents", "LIMIT_EXCEEDED");
    documents2.set(id, Object.freeze({ id, title, url: parsed.href }));
  }
  const supplied = /* @__PURE__ */ new Map();
  for (const raw of ownArray(o.groups, 8, "INVALID_OPTIONS", "ui.directory.view.groups", budget)) {
    const group = object(raw, ["field", "label", "values"], "view.group", budget), field = text(group.field, 64, "view.field");
    if (supplied.has(field) || !config.groups.some((g) => g.field === field))
      failDirectory("view.field");
    supplied.set(field, group);
  }
  if (supplied.size !== config.groups.length)
    failDirectory("view.groups");
  const groups2 = config.groups.map((group) => {
    const raw = supplied.get(group.field), labels2 = /* @__PURE__ */ new Map();
    for (const item of ownArray(raw.values === void 0 ? [] : raw.values, 128, "INVALID_OPTIONS", "ui.directory.view.values", budget)) {
      const entry = object(item, ["value", "label"], "view.value", budget), value = text(entry.value, 1024, "view.value");
      if (labels2.has(value) || !group.values.includes(value))
        failDirectory("view.value");
      labels2.set(value, label(entry.label));
    }
    const name = label(raw.label, 256);
    const values = group.values.map((value) => {
      if (value && !labels2.has(value) && /^[\s\p{C}]*$/u.test(value))
        failDirectory("view.value.label");
      return Object.freeze({ value, label: labels2.get(value) ?? (value || messages.emptyValue) });
    });
    units += name.length + values.reduce((sum, v) => sum + v.label.length, 0);
    if (units > 4e6)
      failDirectory("view.labels", "LIMIT_EXCEEDED");
    return Object.freeze({ field: group.field, label: name, values: Object.freeze(values) });
  });
  if (o.filtersOpen !== void 0 && typeof o.filtersOpen !== "boolean")
    failDirectory("view.filtersOpen");
  if (directoryConfigurations.get(controller2) !== config)
    failDirectory("view.controller");
  return Object.freeze({
    root: root2,
    controller: controller2,
    config,
    documents: documents2,
    groups: Object.freeze(groups2),
    messages,
    debounceMs: integer(o.debounceMs === void 0 ? 150 : o.debounceMs, 0, 2e3, "view.debounceMs"),
    filtersOpen: o.filtersOpen === true
  });
}

// dist/addons/ui/directory-cards-options.js
var defaults2 = Object.freeze({ layout: "list", density: "comfortable", images: false });
function captureCardPresentation(input, previous = defaults2) {
  const value = object(input, ["layout", "density", "images"], "cards.presentation");
  const layout = Object.hasOwn(value, "layout") ? value.layout : previous.layout;
  const density = Object.hasOwn(value, "density") ? value.density : previous.density;
  const images = Object.hasOwn(value, "images") ? value.images : previous.images;
  if (layout !== "list" && layout !== "cards" && layout !== "grid")
    failDirectory("cards.layout");
  if (density !== "compact" && density !== "comfortable")
    failDirectory("cards.density");
  if (typeof images !== "boolean")
    failDirectory("cards.images");
  return Object.freeze({ layout, density, images });
}
function captureDirectoryCards(input) {
  const budget = new Admission(3e5);
  const value = object(input, ["root", "controller", "documents", "groups", "debounceMs", "filtersOpen", "messages", "presentation", "imageUnavailable"], "cards", budget);
  let units = 0;
  const label = (raw, maximum, path, empty = false) => {
    const captured = text(raw, maximum, path);
    if ((!empty || captured.length > 0) && /^[\s\p{C}]*$/u.test(captured))
      failDirectory(path);
    units += captured.length;
    if (units > 4e6)
      failDirectory("cards.documents", "LIMIT_EXCEEDED");
    return captured;
  };
  const documents2 = /* @__PURE__ */ new Map();
  const basic = [];
  for (const raw of ownArray(value.documents, 1e4, "INVALID_OPTIONS", "ui.directory.cards.documents", budget)) {
    const item = object(raw, ["id", "title", "url", "excerpt", "category", "breadcrumb", "date", "fields", "image"], "cards.document", budget);
    const id = text(item.id, 256, "cards.id"), title = text(item.title, 1024, "cards.title"), url2 = text(item.url, 2048, "cards.url");
    units += id.length + title.length + url2.length;
    if (units > 4e6)
      failDirectory("cards.documents", "LIMIT_EXCEEDED");
    const optional = (key, maximum) => {
      if (!Object.hasOwn(item, key))
        return void 0;
      return label(item[key], maximum, "cards." + key, true) || void 0;
    };
    const excerpt = optional("excerpt", 4096), category = optional("category", 256), date = optional("date", 256);
    const breadcrumb = item.breadcrumb === void 0 ? void 0 : Object.freeze(ownArray(item.breadcrumb, 8, "INVALID_OPTIONS", "ui.directory.cards.breadcrumb", budget).map((part) => label(part, 256, "cards.breadcrumb")));
    const names = /* @__PURE__ */ new Set();
    const fields = item.fields === void 0 ? void 0 : Object.freeze(ownArray(item.fields, 4, "INVALID_OPTIONS", "ui.directory.cards.fields", budget).map((rawField) => {
      const field = object(rawField, ["name", "value"], "cards.field", budget), name = label(field.name, 128, "cards.field.name"), content = label(field.value, 1024, "cards.field.value");
      if (names.has(name))
        failDirectory("cards.field.name");
      names.add(name);
      return Object.freeze({ name, value: content });
    }));
    let image;
    if (item.image !== void 0) {
      const rawImage = object(item.image, ["src", "alt", "width", "height"], "cards.image", budget);
      const src = label(rawImage.src, 2048, "cards.image.src"), alt = label(rawImage.alt, 1024, "cards.image.alt", true);
      image = Object.freeze({ src, alt, width: integer(rawImage.width, 1, 4096, "cards.image.width"), height: integer(rawImage.height, 1, 4096, "cards.image.height") });
    }
    basic.push(Object.freeze({ id, title, url: url2 }));
    documents2.set(id, Object.freeze({
      id,
      title,
      url: url2,
      ...excerpt === void 0 ? {} : { excerpt },
      ...category === void 0 ? {} : { category },
      ...date === void 0 ? {} : { date },
      ...breadcrumb === void 0 ? {} : { breadcrumb },
      ...fields === void 0 ? {} : { fields },
      ...image === void 0 ? {} : { image }
    }));
  }
  const base = { root: value.root, controller: value.controller, documents: basic, groups: value.groups };
  for (const key of ["debounceMs", "filtersOpen", "messages"])
    if (Object.hasOwn(value, key))
      base[key] = value[key];
  const view2 = captureDirectoryView(base);
  for (const [id, item] of documents2) {
    const original2 = view2.documents.get(id);
    let image = item.image;
    if (image) {
      let resolved;
      try {
        resolved = new URL(image.src, view2.root.ownerDocument.baseURI);
      } catch {
        failDirectory("cards.image.src");
      }
      if (!["http:", "https:"].includes(resolved.protocol) || resolved.username || resolved.password)
        failDirectory("cards.image.src");
      image = Object.freeze({ ...image, src: resolved.href });
    }
    documents2.set(id, Object.freeze({ ...item, ...original2, ...image ? { image } : {} }));
  }
  const imageUnavailable = value.imageUnavailable === void 0 ? "Image unavailable" : label(value.imageUnavailable, 512, "cards.imageUnavailable");
  const presentation = captureCardPresentation(value.presentation === void 0 ? {} : value.presentation);
  return Object.freeze({ view: view2, documents: documents2, presentation, imageUnavailable });
}

// dist/addons/ui/mounts.js
var mounted = /* @__PURE__ */ new WeakMap();

// dist/addons/ui/directory-view-mount.js
function mountDirectoryView(captured, extension) {
  const { root: root2, controller: controller2, config, messages } = captured;
  const existing = mounted.get(root2);
  if (existing) {
    if (existing.kind !== (extension?.kind ?? "directory"))
      failDirectory("view.root");
    return existing.handle;
  }
  const doc = root2.ownerDocument, win = doc.defaultView;
  const node = (tag, name, content) => {
    const element = doc.createElement(tag);
    if (name) {
      element.className = `raveldex-directory__${name}`;
      element.setAttribute(`data-raveldex-directory-${name}`, "");
    }
    if (content !== void 0)
      element.textContent = content;
    return element;
  };
  const button = (name, label) => {
    const b = node("button", name, label);
    b.type = "button";
    return b;
  };
  const shell = node("div");
  shell.className = "raveldex-directory";
  const form = node("form", "form");
  form.setAttribute("role", "search");
  form.setAttribute("aria-label", messages.label);
  const inputLabel = node("label", "search-label", messages.label), input = node("input", "input");
  input.type = "search";
  input.maxLength = 2048;
  input.placeholder = messages.placeholder;
  inputLabel.append(input);
  const submit = button("submit", messages.submit);
  submit.type = "submit";
  const clear = button("clear", messages.clear);
  form.append(inputLabel, submit, clear);
  const details = node("details", "filters"), summary = node("summary", "filters-summary", messages.filters);
  details.open = captured.filtersOpen;
  details.append(summary, node("p", "hint", messages.countHint));
  const grid = node("div", "filter-groups");
  details.append(grid);
  const checks = captured.groups.map((group) => {
    const fieldset = node("fieldset", "group");
    fieldset.append(node("legend", "legend", group.label));
    const choices = group.values.map((value) => {
      const label = node("label", "choice"), input2 = node("input", "checkbox"), name = node("span", "choice-label", value.label), count = node("span", "count");
      input2.type = "checkbox";
      input2.value = value.value;
      input2.setAttribute("data-field", group.field);
      label.append(input2, name, count);
      fieldset.append(label);
      return { ...value, input: input2, count };
    });
    const omitted = node("p", "omitted");
    omitted.hidden = true;
    fieldset.append(omitted);
    grid.append(fieldset);
    return { ...group, choices, omitted };
  });
  const closeFilters = button("close-filters", messages.closeFilters);
  details.append(closeFilters);
  details.hidden = !checks.length;
  const chips = node("ul", "chips");
  chips.setAttribute("aria-label", messages.selectedFilters);
  const status = node("p", "status");
  status.setAttribute("role", "status");
  status.setAttribute("aria-atomic", "true");
  const retry = button("retry", messages.retry);
  retry.hidden = true;
  const region = node("section", "results-region");
  region.setAttribute("aria-label", messages.resultsLabel);
  const heading = node("h2", "heading", messages.resultsLabel), results = node("ol", "results");
  const navigation = node("nav", "navigation");
  navigation.setAttribute("aria-label", messages.resultsLabel);
  navigation.hidden = true;
  const previous = button("previous", messages.previous), pageSummary = node("p", "page"), next = button("next", messages.next);
  navigation.append(previous, pageSummary, next);
  region.append(heading, results, navigation);
  shell.append(form, details, chips, status, retry, region);
  const original2 = Array.from(root2.childNodes), removers = [], chipNodes = /* @__PURE__ */ new Map();
  const chipDetails = /* @__PURE__ */ new WeakMap();
  let chipOrder = [];
  let ended = false, local = false, dirty = false, composing = false, discardComposition = false, serial = 0;
  let activatedChip;
  let timer, observed = controller2.getSnapshot(), unsubscribe = () => {
  };
  const activeElement = () => {
    const scope = root2.getRootNode();
    return scope.activeElement ?? doc.activeElement;
  };
  const live = () => !ended && mounted.get(root2)?.handle === handle && root2.ownerDocument === doc && shell.parentNode === root2;
  const listen = (target, type, callback) => {
    target.addEventListener(type, callback);
    removers.push(() => target.removeEventListener(type, callback));
  };
  const unavailable = (element, value) => {
    element.setAttribute("aria-disabled", String(value));
  };
  const announce = (text2) => {
    if (status.textContent !== text2)
      status.textContent = text2;
  };
  const cancelTimer = () => {
    if (timer !== void 0) {
      win.clearTimeout(timer);
      timer = void 0;
    }
  };
  const recoverResults = (ticket) => {
    if (results.contains(activeElement()))
      input.focus({ preventScroll: true });
    return live() && serial === ticket;
  };
  function render(value) {
    if (!live())
      return;
    const ticket = ++serial;
    if (!recoverResults(ticket) || controller2.getSnapshot() !== value)
      return;
    const pending = dirty || composing, found = !pending && value.status === "ready" ? value.result : void 0;
    if (!pending)
      input.value = value.state.text;
    const desired = checks.flatMap((group) => group.choices.filter((choice) => value.state.filters[group.field].includes(choice.value)).map((choice) => ({
      key: JSON.stringify([group.field, choice.value]),
      group,
      choice
    })));
    const desiredKeys = new Set(desired.map((item) => item.key)), oldKeys = chipOrder, activated = activatedChip;
    activatedChip = void 0;
    const removed = oldKeys.find((key) => !desiredKeys.has(key) && (chipNodes.get(key)?.button === activeElement() || key === activated));
    if (removed !== void 0) {
      const index = oldKeys.indexOf(removed), target = oldKeys.slice(index + 1).find((key) => desiredKeys.has(key)) ?? oldKeys.slice(0, index).reverse().find((key) => desiredKeys.has(key));
      (target ? chipNodes.get(target).button : input).focus({ preventScroll: true });
      if (!live() || serial !== ticket || controller2.getSnapshot() !== value)
        return;
    }
    for (const [key, item] of chipNodes)
      if (!desiredKeys.has(key)) {
        item.li.remove();
        chipNodes.delete(key);
      }
    let anchor = chips.firstChild;
    for (const item of desired) {
      let chip = chipNodes.get(item.key);
      if (!chip) {
        const li = node("li", "chip"), b = button("remove", directoryMessage(messages.remove, { group: item.group.label, value: item.choice.label }));
        li.append(b);
        chip = { li, button: b };
        chipNodes.set(item.key, chip);
        chipDetails.set(b, { field: item.group.field, value: item.choice.value });
      }
      if (chip.li !== anchor)
        chips.insertBefore(chip.li, anchor);
      else
        anchor = anchor.nextSibling;
    }
    chipOrder = desired.map((item) => item.key);
    chips.hidden = !desired.length;
    for (const group of checks) {
      const facet = found?.facets.find((f) => f.field === group.field);
      for (const choice of group.choices) {
        if (!pending)
          choice.input.checked = value.state.filters[group.field].includes(choice.value);
        const bucket = facet?.buckets.find((b) => b.kind === "value" && b.value === choice.value);
        const count = bucket?.count ?? (facet && !facet.omittedBucketCount ? 0 : null);
        choice.count.textContent = ` (${count === null ? messages.unknownCount : count})`;
      }
      group.omitted.hidden = !facet?.omittedBucketCount;
      if (facet?.omittedBucketCount)
        group.omitted.textContent = directoryMessage(messages.omittedCounts, { shown: facet.buckets.length, total: facet.distinctValueTotal });
    }
    extension?.clear();
    results.replaceChildren();
    pageSummary.textContent = "";
    heading.hidden = true;
    unavailable(previous, true);
    unavailable(next, true);
    unavailable(retry, true);
    unavailable(clear, !input.value && !desired.length);
    region.setAttribute("aria-busy", String(pending || value.status === "loading"));
    shell.dataset.state = pending ? composing ? "composing" : "waiting" : value.status;
    if (pending) {
      announce(composing ? messages.composing : messages.waiting);
      return;
    }
    if (found) {
      if (found.total > captured.documents.size || found.hits.some((hit) => !captured.documents.has(hit.id))) {
        shell.dataset.state = "error";
        announce(directoryMessage(messages.error, { code: "INCOMPATIBLE_CAPABILITY" }));
        retry.hidden = false;
        unavailable(retry, false);
        return;
      }
      const offset = (value.state.page - 1) * config.pageSize, pages = Math.max(1, Math.ceil(found.total / config.pageSize));
      const fragment = doc.createDocumentFragment();
      for (const hit of found.hits) {
        const display = captured.documents.get(hit.id), li = node("li", "result"), link = node("a", "result-link", display.title);
        link.href = display.url;
        li.setAttribute("data-raveldex-directory-result", hit.id);
        li.append(link);
        extension?.render(li, link, display);
        fragment.append(li);
      }
      results.start = offset + 1;
      results.append(fragment);
      heading.hidden = false;
      navigation.hidden = false;
      unavailable(previous, value.state.page === 1);
      unavailable(next, value.state.page >= pages);
      pageSummary.textContent = directoryMessage(messages.page, { page: value.state.page, pages });
      announce(found.total ? directoryMessage(found.total === 1 ? messages.resultOne : messages.results, { total: found.total, start: offset + 1, end: offset + found.hits.length }) : messages.noResults);
    } else if (value.status === "error" || value.status === "stale") {
      announce(value.status === "stale" ? messages.stale : directoryMessage(messages.error, { code: value.error ?? "INTERNAL_ERROR" }));
      retry.hidden = false;
      unavailable(retry, false);
    } else
      announce(value.status === "loading" ? messages.searching : messages.idle);
  }
  function cancelDraft() {
    cancelTimer();
    serial++;
    dirty = false;
    activatedChip = void 0;
    if (composing)
      discardComposition = true;
    composing = false;
  }
  function request(patch) {
    if (!live())
      return Promise.resolve();
    cancelTimer();
    dirty = false;
    local = true;
    try {
      const work = controller2.update(patch);
      render(controller2.getSnapshot());
      return work;
    } catch {
      render(controller2.getSnapshot());
      if (live()) {
        shell.dataset.state = "invalid";
        announce(messages.invalid);
      }
      return Promise.resolve();
    } finally {
      local = false;
      activatedChip = void 0;
    }
  }
  function execute() {
    if (!live())
      return Promise.resolve();
    cancelTimer();
    if (composing || discardComposition)
      return Promise.resolve();
    const filters = /* @__PURE__ */ Object.create(null);
    for (const group of checks)
      filters[group.field] = group.choices.filter((c) => c.input.checked).map((c) => c.value);
    return request({ text: input.value, filters });
  }
  function schedule() {
    if (!live())
      return;
    if (discardComposition) {
      input.value = controller2.getSnapshot().state.text;
      return;
    }
    cancelTimer();
    dirty = true;
    render(controller2.getSnapshot());
    if (!live() || composing)
      return;
    timer = win.setTimeout(() => {
      timer = void 0;
      void execute();
    }, captured.debounceMs);
  }
  function closeDisclosure() {
    if (!live() || !details.open)
      return;
    summary.focus({ preventScroll: true });
    if (live())
      details.open = false;
  }
  const baseHandle = Object.freeze({
    search: (raw) => {
      if (!live())
        return Promise.resolve();
      if (raw !== void 0) {
        const value = queryText(raw);
        cancelDraft();
        input.value = value;
        return request({ text: value, filters: controller2.getSnapshot().state.filters });
      }
      return execute();
    },
    clear: () => {
      if (!live())
        return Promise.resolve();
      cancelDraft();
      return request({ text: "", filters: {} });
    },
    destroy: () => {
      if (ended)
        return;
      ended = true;
      serial++;
      cancelTimer();
      unsubscribe();
      extension?.destroy();
      for (const remove of removers)
        remove();
      chipNodes.clear();
      chipOrder = [];
      if (mounted.get(root2)?.handle !== handle)
        return;
      mounted.delete(root2);
      if (shell.parentNode === root2)
        root2.replaceChildren(...original2);
    }
  });
  const handle = extension ? extension.extend(baseHandle) : baseHandle;
  extension?.initialize(shell, live);
  listen(form, "submit", (event) => {
    event.preventDefault();
    void execute();
  });
  listen(input, "input", schedule);
  listen(input, "compositionstart", () => {
    if (!live())
      return;
    discardComposition = false;
    composing = true;
    schedule();
  });
  listen(input, "compositionend", () => {
    if (!live())
      return;
    if (discardComposition) {
      discardComposition = false;
      composing = false;
      dirty = false;
      input.value = controller2.getSnapshot().state.text;
      render(controller2.getSnapshot());
      return;
    }
    composing = false;
    schedule();
  });
  listen(clear, "click", () => {
    if (clear.getAttribute("aria-disabled") !== "true")
      void handle.clear();
  });
  listen(chips, "click", (event) => {
    if (!live())
      return;
    const target = event.target;
    if (!target || target.nodeType !== 1)
      return;
    const element = target.closest("button"), selected = element ? chipDetails.get(element) : void 0;
    if (!selected)
      return;
    cancelDraft();
    activatedChip = JSON.stringify([selected.field, selected.value]);
    const state = controller2.getSnapshot().state, filters = { ...state.filters, [selected.field]: state.filters[selected.field].filter((v) => v !== selected.value) };
    void request({ text: state.text, filters });
  });
  for (const group of checks)
    for (const choice of group.choices)
      listen(choice.input, "change", () => {
        if (composing)
          schedule();
        else
          void execute();
      });
  listen(previous, "click", () => {
    if (live() && previous.getAttribute("aria-disabled") !== "true") {
      cancelDraft();
      void controller2.setPage(controller2.getSnapshot().state.page - 1);
    }
  });
  listen(next, "click", () => {
    if (live() && next.getAttribute("aria-disabled") !== "true") {
      cancelDraft();
      void controller2.setPage(controller2.getSnapshot().state.page + 1);
    }
  });
  listen(retry, "click", () => {
    if (live() && retry.getAttribute("aria-disabled") !== "true") {
      cancelDraft();
      void controller2.refresh();
    }
  });
  listen(closeFilters, "click", closeDisclosure);
  listen(details, "keydown", (event) => {
    const key = event;
    if (key.key === "Escape" && details.open && !key.isComposing) {
      key.preventDefault();
      closeDisclosure();
    }
  });
  listen(details, "toggle", () => {
    if (live() && !details.open && details.contains(activeElement()) && activeElement() !== summary)
      summary.focus({ preventScroll: true });
  });
  mounted.set(root2, { kind: extension?.kind ?? "directory", handle });
  try {
    unsubscribe = controller2.subscribe((value) => {
      if (ended)
        return;
      if (value.status === "destroyed") {
        handle.destroy();
        return;
      }
      if (!local && value.change !== "recovery" && (stateKey(value.state) !== stateKey(observed.state) || value.status === "loading" && (value.change === "refresh" || value.change === "restore")))
        cancelDraft();
      observed = value;
      render(value);
    });
    root2.replaceChildren(shell);
    if (live())
      render(controller2.getSnapshot());
  } catch (reason) {
    handle.destroy();
    throw reason;
  }
  return handle;
}

// dist/addons/ui/directory-cards.js
function mountRaveldexDirectoryCards(options) {
  const captured = captureDirectoryCards(options), doc = captured.view.root.ownerDocument;
  let presentation = captured.presentation, shell, live = () => false;
  const rendered = [];
  const node = (tag, suffix, text2) => {
    const element = doc.createElement(tag);
    element.className = `raveldex-directory-cards__${suffix}`;
    element.setAttribute(`data-raveldex-directory-card-${suffix}`, "");
    if (text2 !== void 0)
      element.textContent = text2;
    return element;
  };
  const removeImage = (card) => {
    card.image?.dispose();
    card.image?.frame.remove();
    delete card.image;
  };
  function addImage(card) {
    const data = card.display.image;
    if (!data || card.image || !presentation.images)
      return;
    const frame = node("div", "image-frame"), image = node("img", "image");
    frame.style.aspectRatio = `${data.width} / ${data.height}`;
    image.alt = data.alt;
    image.width = data.width;
    image.height = data.height;
    image.loading = "lazy";
    image.decoding = "async";
    image.referrerPolicy = "no-referrer";
    if (!data.alt)
      frame.setAttribute("aria-hidden", "true");
    const failed = () => {
      if (!live() || card.image?.frame !== frame || frame.parentNode !== card.item)
        return;
      image.removeEventListener("error", failed);
      image.removeAttribute("src");
      image.remove();
      if (data.alt) {
        frame.style.removeProperty("aspect-ratio");
        frame.classList.add("is-unavailable");
        frame.append(node("span", "image-unavailable", `${captured.imageUnavailable}: ${data.alt}`));
      } else
        frame.remove();
    };
    image.addEventListener("error", failed);
    card.image = { frame, dispose: () => {
      image.removeEventListener("error", failed);
      image.removeAttribute("src");
    } };
    frame.append(image);
    card.item.prepend(frame);
    image.src = data.src;
  }
  const applyPresentation = () => {
    if (!shell)
      return;
    shell.dataset.layout = presentation.layout;
    shell.dataset.density = presentation.density;
    shell.dataset.images = String(presentation.images);
  };
  const clear = () => {
    for (const card of rendered)
      removeImage(card);
    rendered.length = 0;
  };
  const extension = {
    kind: "directory-cards",
    initialize: (element, isLive) => {
      shell = element;
      live = isLive;
      shell.classList.add("raveldex-directory-cards");
      applyPresentation();
    },
    render: (item, link, basic) => {
      const display = captured.documents.get(basic.id), card = { item, display };
      const title = node("h3", "title");
      title.append(link);
      item.append(title);
      if (display.category)
        item.append(node("p", "category", display.category));
      if (display.breadcrumb?.length)
        item.append(node("p", "breadcrumb", display.breadcrumb.join(" \u203A ")));
      if (display.excerpt)
        item.append(node("p", "excerpt", display.excerpt));
      if (display.date)
        item.append(node("p", "date", display.date));
      if (display.fields?.length) {
        const fields = node("dl", "fields");
        for (const field of display.fields) {
          const row = node("div", "field");
          row.append(node("dt", "field-name", field.name), node("dd", "field-value", field.value));
          fields.append(row);
        }
        item.append(fields);
      }
      rendered.push(card);
      addImage(card);
    },
    clear,
    destroy: () => {
      clear();
      shell = void 0;
      live = () => false;
    },
    extend: (base) => Object.freeze({
      ...base,
      getPresentation: () => presentation,
      setPresentation: (input) => {
        if (!live())
          return;
        const previous = presentation, next = captureCardPresentation(input, previous);
        if (!live() || presentation !== previous)
          return;
        const imagesChanged = next.images !== previous.images;
        presentation = next;
        applyPresentation();
        if (imagesChanged)
          for (const card of rendered)
            if (presentation.images)
              addImage(card);
            else
              removeImage(card);
      }
    })
  };
  return mountDirectoryView(captured.view, extension);
}

// dist/core/limits/limits.js
var DEFAULT_LIMITS = Object.freeze({
  maxDocuments: 1e4,
  maxTextFields: 32,
  maxMetadataFields: 32,
  maxFieldNameCodeUnits: 64,
  maxIdCodeUnits: 256,
  maxTextValuesPerField: 64,
  maxMetadataValuesPerField: 128,
  maxMetadataStringCodeUnits: 1024,
  maxMetadataCodeUnitsPerRecord: 32768,
  maxTextCodeUnitsPerValue: 65536,
  maxTextCodeUnitsPerRecord: 262144,
  maxCorpusTextCodeUnits: 67108864,
  maxRawTokenCodeUnits: 256,
  maxTermCodeUnits: 256,
  maxTokensPerRecord: 32768,
  maxCorpusTokens: 4e6,
  maxDictionaryEntries: 25e4,
  maxPostingEntries: 2e6,
  maxMutationBatch: 256,
  maxAdmissionEntries: 16384,
  maxQueryNodes: 128,
  maxQueryDepth: 16,
  maxQueryLexicalCodeUnits: 2048,
  maxQueryCodeUnits: 16384,
  maxQueryTokens: 64,
  maxQueryGroups: 64,
  maxVariantsPerGroup: 16,
  maxExpansionsPerGroup: 256,
  maxQueryExpansions: 1024,
  minPrefixCodePoints: 2,
  maxHits: 100,
  maxQueuedOperations: 32,
  maxSearchWorkUnits: 1e7,
  maxMutationWorkUnits: 5e7,
  checkpointWorkUnits: 2048,
  maxDeadlineMs: 6e4
});
function resolveLimits(input = {}, admission2 = new Admission(DEFAULT_LIMITS.maxAdmissionEntries)) {
  const data = ownObject(input, "INVALID_OPTIONS", "limits", admission2);
  const result = { ...DEFAULT_LIMITS };
  for (const key of Object.keys(data)) {
    if (!has(DEFAULT_LIMITS, key))
      invalid("INVALID_OPTIONS", "limits");
    const name = key;
    const value = data[key];
    const minimum = name === "maxMetadataFields" || name === "maxQueuedOperations" ? 0 : name === "minPrefixCodePoints" ? 2 : 1;
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid("INVALID_OPTIONS", `limits.${name}`);
    if (name !== "minPrefixCodePoints")
      bound(value, DEFAULT_LIMITS[name], `limits.${name}`);
    result[name] = value;
  }
  if (result.checkpointWorkUnits > Math.min(result.maxSearchWorkUnits, result.maxMutationWorkUnits)) {
    invalid("INVALID_OPTIONS", "limits.checkpointWorkUnits");
  }
  return Object.freeze(result);
}
function validateStateCounts(counts, limits) {
  const pairs = [
    ["documents", "maxDocuments"],
    ["textCodeUnits", "maxCorpusTextCodeUnits"],
    ["tokens", "maxCorpusTokens"],
    ["dictionaryEntries", "maxDictionaryEntries"],
    ["postingEntries", "maxPostingEntries"]
  ];
  for (const [count, limit] of pairs) {
    if (!Number.isSafeInteger(counts[count]) || counts[count] < 0)
      invalid("INTERNAL_ERROR", `state.${count}`);
    bound(counts[count], limits[limit], `state.${count}`);
  }
}

// dist/core/analyzer/basic.js
var BASIC_ANALYZER = Object.freeze({ id: "basic-v1", environmentProfile: "unqualified" });
var START = /[\p{L}\p{N}]/u;
var CONTINUE = /[\p{L}\p{N}\p{M}]/u;
function* analyzeValue(value, valueIndex = 0, limits = DEFAULT_LIMITS, code = "INVALID_RECORD") {
  bound(value.length, limits.maxTextCodeUnitsPerValue, "analysis.value");
  let start = -1;
  let position = 0;
  function emit(end) {
    const raw = value.slice(start, end);
    const term = raw.normalize("NFKC").toLowerCase();
    bound(term.length, limits.maxTermCodeUnits, "analysis.term");
    const token = Object.freeze({ term, valueIndex, position: position++, start, end });
    start = -1;
    return { workUnits: raw.length + term.length, token };
  }
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, "analysis.value");
    const point = value.slice(i, i + width);
    if (start >= 0 && !CONTINUE.test(point))
      yield emit(i);
    if (start < 0 && START.test(point))
      start = i;
    i += width;
    if (start >= 0)
      bound(i - start, limits.maxRawTokenCodeUnits, "analysis.rawToken");
    yield { workUnits: 1 };
  }
  if (start >= 0)
    yield emit(value.length);
}

// dist/core/capabilities/registration.js
function captureRegistrations(input, context) {
  const { schema: schema2, limits, admission: admission2 } = context, code = "INCOMPATIBLE_CAPABILITY";
  const entries = ownArray(input, 32, code, "addons", admission2);
  const registrations = /* @__PURE__ */ new Map();
  const providers = /* @__PURE__ */ Object.create(null);
  const object2 = (value, path, keys) => {
    const data = ownObject(value, code, path, admission2);
    keysOnly(data, keys, code, path);
    return data;
  };
  const string = (value, path, maximum = 128) => {
    const result = stringValue(value, maximum, code, path);
    if (!result.length)
      invalid(code, path);
    for (const step of scanUnicode(result, code, path)) {
      void step;
    }
    return result;
  };
  const id = (value, path) => {
    const result = string(value, path);
    if (!/^[A-Za-z][A-Za-z0-9:._-]*$/.test(result))
      invalid(code, path);
    return result;
  };
  const integer3 = (value, path, minimum = 0) => {
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid(code, path);
    return value;
  };
  const flag = (value, path) => {
    if (typeof value !== "boolean")
      invalid(code, path);
    return value;
  };
  const references = (value, path) => {
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(ownArray(value, 64, code, path, admission2).map((value2) => {
      const ref = object2(value2, path, ["id", "contractVersion"]), name = id(ref.id, path);
      if (ref.contractVersion !== 1 || seen.has(name))
        invalid(code, path);
      seen.add(name);
      return Object.freeze({ id: name, contractVersion: 1 });
    }));
  };
  for (const entry of entries) {
    const data = object2(entry, "addons.registration", ["manifest", "participant", "refinement", "predicate", "sourcePredicate", "aggregation", "evidence", "expansion", "dictionary", "analyzer"]);
    const raw = object2(data.manifest, "addons.manifest", ["id", "version", "contractVersion", "roles", "provides", "requires", "dataRequirements", "indexEffect", "rebuildPolicy", "execution", "limits", "costs", "codec"]);
    const name = id(raw.id, "addons.id"), version = string(raw.version, "addons.version");
    const semanticVersion = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/;
    if (!semanticVersion.test(version) || raw.contractVersion !== 1 || registrations.has(name))
      invalid(code, "addons.identity");
    const roles = ownArray(raw.roles, 7, code, "addons.roles", admission2);
    if (!roles.length || new Set(roles).size !== roles.length || roles.some((role) => role !== "leaf-refinement" && role !== "transaction-participant" && role !== "aggregation" && role !== "evidence" && role !== "term-expansion" && role !== "dictionary-output" && role !== "analyzer"))
      invalid(code, "addons.roles");
    const requirements = object2(raw.dataRequirements, "addons.dataRequirements", ["fields", "source", "positions", "offsets", "metadata"]);
    const metadata = flag(requirements.metadata, "addons.metadata");
    const fields = ownArray(requirements.fields, metadata ? limits.maxMetadataFields : limits.maxTextFields, code, "addons.fields", admission2).map((field) => {
      const name2 = id(field, "addons.fields");
      if (!has(metadata ? schema2.metadata : schema2.text, name2))
        invalid(code, "addons.fields");
      return name2;
    });
    if (new Set(fields).size !== fields.length)
      invalid(code, "addons.fields");
    const execution = object2(raw.execution, "addons.execution", ["direct", "worker", "workerRegistration"]);
    if (execution.direct !== true || typeof execution.worker !== "boolean" || execution.worker !== has(execution, "workerRegistration"))
      invalid(code, "addons.execution");
    const workerRegistration = execution.worker ? string(execution.workerRegistration, "addons.workerRegistration", 8192) : void 0;
    const caps = object2(raw.limits, "addons.limits", ["maxPayloadCodeUnits", "maxWorkUnits", "maxRetainedEntries", "maxOutputEntries"]);
    const ownedLimits = Object.freeze({ maxPayloadCodeUnits: integer3(caps.maxPayloadCodeUnits, "addons.limits", 1), maxWorkUnits: integer3(caps.maxWorkUnits, "addons.limits", 1), maxRetainedEntries: integer3(caps.maxRetainedEntries, "addons.limits"), maxOutputEntries: integer3(caps.maxOutputEntries, "addons.limits") });
    if (ownedLimits.maxPayloadCodeUnits > DEFAULT_LIMITS.maxQueryCodeUnits || ownedLimits.maxWorkUnits > Math.max(DEFAULT_LIMITS.maxSearchWorkUnits, DEFAULT_LIMITS.maxMutationWorkUnits))
      invalid(code, "addons.limits");
    const costs = object2(raw.costs, "addons.costs", ["importedCode", "retainedRepresentation", "transientWork", "externalResources"]);
    if (costs.externalResources !== "none" || raw.rebuildPolicy !== "new-index")
      invalid(code, "addons.costs");
    const participantRole = roles.includes("transaction-participant"), refinementRole = roles.includes("leaf-refinement"), aggregationRole = roles.includes("aggregation"), evidenceRole = roles.includes("evidence");
    const expansionRole = roles.includes("term-expansion");
    const dictionaryRole = roles.includes("dictionary-output");
    const analyzerRole = roles.includes("analyzer");
    if (analyzerRole !== has(data, "analyzer") || analyzerRole && (roles.length !== 1 || fields.length !== 0 || metadata || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false || has(raw, "codec")))
      invalid(code, "addons.analyzer");
    if (dictionaryRole !== has(data, "dictionary") || dictionaryRole && (roles.length !== 1 || metadata || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.dictionary");
    if (expansionRole !== has(data, "expansion") || expansionRole && (roles.length !== 1 || metadata || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.expansion");
    const leafHandles = ["refinement", "predicate", "sourcePredicate"].filter((key) => has(data, key)).length;
    if (participantRole !== has(data, "participant") || refinementRole !== (leafHandles === 1) || leafHandles > 1 || aggregationRole !== has(data, "aggregation") || evidenceRole !== has(data, "evidence") || raw.indexEffect !== (participantRole ? "transactional" : analyzerRole ? "analysis" : "none"))
      invalid(code, "addons.roles");
    if ((has(data, "predicate") || aggregationRole) && (!metadata || participantRole || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.dataRequirements");
    if (has(data, "sourcePredicate") && (metadata || participantRole || requirements.source !== true || requirements.positions !== false || requirements.offsets !== false || !fields.length || has(raw, "codec")))
      invalid(code, "addons.dataRequirements");
    if (evidenceRole && (participantRole || metadata || requirements.offsets === true && requirements.positions !== true))
      invalid(code, "addons.dataRequirements");
    const implementations = {};
    for (const key of ["participant", "refinement", "predicate", "sourcePredicate", "aggregation", "evidence", "expansion", "dictionary", "analyzer"]) {
      if (!has(data, key))
        continue;
      let methods = key === "participant" ? ["initialize", "prepare"] : key === "refinement" ? ["prepare"] : key === "evidence" ? ["capture", "select", "prepare"] : key === "expansion" ? ["expand"] : key === "analyzer" ? ["transform", "analyze"] : ["capture", "prepare"];
      const attributes = key === "refinement" ? ["kind", "maxTokens"] : key === "sourcePredicate" ? ["kind"] : key === "aggregation" ? ["fieldType"] : key === "expansion" ? ["kind", "maxTokens", "policy"] : key === "analyzer" ? ["kind", "id"] : [];
      const handles = object2(data[key], `addons.${key}`, [...methods, ...attributes]);
      if (key === "analyzer") {
        methods = handles.kind === "single-token-transform" ? ["transform"] : handles.kind === "identifier-tokenizer" ? ["analyze"] : [];
        if (!methods.length)
          invalid(code, "addons.analyzer");
        keysOnly(handles, [...methods, ...attributes], code, "addons.analyzer");
      }
      for (const method of methods) {
        const callback = handles[method];
        if (typeof callback !== "function")
          invalid(code, `addons.${key}`);
        handles[method] = callback.bind(data[key]);
      }
      if (key === "refinement" && (handles.kind !== "exact-token-sequence" && handles.kind !== "ordered-token-groups" || integer3(handles.maxTokens, "addons.maxTokens", 1) > DEFAULT_LIMITS.maxQueryTokens))
        invalid(code, "addons.refinement");
      if (key === "sourcePredicate" && handles.kind !== "source-substring")
        invalid(code, "addons.sourcePredicate");
      if (key === "expansion") {
        if (handles.kind !== "weighted-token-alternatives" || integer3(handles.maxTokens, "addons.maxTokens", 1) > DEFAULT_LIMITS.maxQueryTokens)
          invalid(code, "addons.expansion");
        handles.policy = id(handles.policy, "addons.expansion.policy");
      }
      if (key === "analyzer") {
        handles.id = id(handles.id, "addons.analyzer.id");
        if (handles.id === "basic-v1")
          invalid(code, "addons.analyzer.id");
        if (handles.kind === "identifier-tokenizer" !== (handles.id === "code-identifiers-v1"))
          invalid(code, "addons.analyzer.id");
      }
      if (key === "aggregation" && (handles.fieldType !== "string" || fields.some((field) => schema2.metadata[field]?.type !== handles.fieldType)))
        invalid(code, "addons.aggregation");
      implementations[key] = Object.freeze(handles);
    }
    let codec;
    if (has(raw, "codec")) {
      const value = object2(raw.codec, "addons.codec", ["id", "version"]);
      codec = Object.freeze({ id: id(value.id, "addons.codec"), version: integer3(value.version, "addons.codec", 1) });
    }
    const manifest = Object.freeze({
      id: name,
      version,
      contractVersion: 1,
      roles: Object.freeze(roles),
      provides: references(raw.provides, "addons.provides"),
      requires: references(raw.requires, "addons.requires"),
      dataRequirements: Object.freeze({ fields: Object.freeze(fields.sort()), source: flag(requirements.source, "addons.source"), positions: flag(requirements.positions, "addons.positions"), offsets: flag(requirements.offsets, "addons.offsets"), metadata }),
      indexEffect: participantRole ? "transactional" : analyzerRole ? "analysis" : "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: execution.worker, ...workerRegistration ? { workerRegistration } : {} }),
      limits: ownedLimits,
      costs: Object.freeze({ importedCode: string(costs.importedCode, "addons.costs", 1024), retainedRepresentation: string(costs.retainedRepresentation, "addons.costs", 1024), transientWork: string(costs.transientWork, "addons.costs", 1024), externalResources: "none" }),
      ...codec ? { codec } : {}
    });
    const captured = Object.freeze({ manifest, ...implementations });
    if (captured.analyzer && (manifest.provides.length !== 1 || manifest.provides[0].id !== `analyzer:${captured.analyzer.id}` || manifest.requires.length !== 0))
      invalid(code, "addons.analyzer");
    registrations.set(name, captured);
    if (!manifest.provides.length)
      invalid(code, "addons.provides");
    for (const provided of manifest.provides) {
      if (has(providers, provided.id))
        invalid(code, "addons.providers");
      providers[provided.id] = captured;
    }
  }
  const ordered = [], visited = /* @__PURE__ */ new Set(), active = /* @__PURE__ */ new Set();
  function visit(registration) {
    const { manifest } = registration;
    if (visited.has(manifest.id))
      return;
    if (active.has(manifest.id))
      invalid(code, "addons.cycle");
    active.add(manifest.id);
    for (const requirement of [...manifest.requires].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0)) {
      const provider = providers[requirement.id];
      if (!provider)
        invalid("MISSING_CAPABILITY", "addons.requires");
      visit(provider);
    }
    const data = manifest.dataRequirements;
    if (registration.refinement?.kind === "ordered-token-groups") {
      if (!data.positions || data.source || data.offsets || data.metadata || !data.fields.length || registration.participant || manifest.codec || manifest.requires.some((ref) => !data.fields.some((field) => ref.id === `positions:${field}`)))
        invalid(code, "addons.ordered.data");
      for (const field of data.fields)
        if (!manifest.requires.some((ref) => ref.id === `positions:${field}`) || !providers[`positions:${field}`]?.participant)
          invalid("MISSING_CAPABILITY", "addons.ordered.positions");
    }
    if ((data.source || data.positions) && registration.refinement)
      for (const field of data.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field}`) && !!providers[`${kind}:${field}`]?.participant;
        if (!(data.source && present("source") || data.positions && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    if (registration.sourcePredicate) {
      if (manifest.requires.some((ref) => !data.fields.some((field) => ref.id === `source:${field}`)))
        invalid("INCOMPATIBLE_CAPABILITY", "addons.sourcePredicate.requires");
      for (const field of data.fields) {
        if (!manifest.requires.some((ref) => ref.id === `source:${field}`) || !providers[`source:${field}`]?.participant)
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    }
    if (registration.evidence && (data.source || data.positions || data.offsets))
      for (const field of data.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field}`) && !!providers[`${kind}:${field}`]?.participant;
        if (!(data.source && present("source") || data.offsets && present("offsets") || data.positions && !data.offsets && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    active.delete(manifest.id);
    visited.add(manifest.id);
    ordered.push(registration);
  }
  for (const name of [...registrations.keys()].sort())
    visit(registrations.get(name));
  return Object.freeze({ ordered: Object.freeze(ordered), providers: Object.freeze(providers) });
}

// dist/core/contracts/schema.js
function captureSchema(input, limits, admission2 = new Admission(limits.maxAdmissionEntries)) {
  const schema2 = ownObject(input, "INVALID_SCHEMA", "schema", admission2);
  keysOnly(schema2, ["text", "metadata"], "INVALID_SCHEMA", "schema");
  const text2 = ownObject(schema2.text, "INVALID_SCHEMA", "schema.text", admission2);
  const metadata = has(schema2, "metadata") ? ownObject(schema2.metadata, "INVALID_SCHEMA", "schema.metadata", admission2) : /* @__PURE__ */ Object.create(null);
  const textNames = Object.keys(text2);
  const metadataNames = Object.keys(metadata);
  if (textNames.length === 0)
    invalid("INVALID_SCHEMA", "schema.text");
  bound(textNames.length, limits.maxTextFields, "schema.text");
  bound(metadataNames.length, limits.maxMetadataFields, "schema.metadata");
  const ownedText = /* @__PURE__ */ Object.create(null);
  const ownedMetadata = /* @__PURE__ */ Object.create(null);
  for (const [group, names] of [[text2, textNames], [metadata, metadataNames]]) {
    for (const name of names) {
      if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(name) || name === "constructor" || name === "prototype")
        invalid("INVALID_SCHEMA", "schema.fields");
      bound(name.length, limits.maxFieldNameCodeUnits, "schema.fields");
      if (has(text2, name) && has(metadata, name))
        invalid("INVALID_SCHEMA", "schema.fields");
      const path = `schema.${group === text2 ? "text" : "metadata"}.${name}`;
      const field = ownObject(group[name], "INVALID_SCHEMA", path, admission2);
      if (group === text2) {
        keysOnly(field, ["boost"], "INVALID_SCHEMA", path);
        const boost = has(field, "boost") ? field.boost : 1;
        if (typeof boost !== "number" || !Number.isFinite(boost) || boost <= 0 || boost > 16)
          invalid("INVALID_SCHEMA", `${path}.boost`);
        ownedText[name] = Object.freeze({ boost });
      } else {
        keysOnly(field, ["type", "multi", "nullable"], "INVALID_SCHEMA", path);
        if (field.type !== "string" && field.type !== "number" && field.type !== "boolean")
          invalid("INVALID_SCHEMA", `${path}.type`);
        const multi = has(field, "multi") ? field.multi : false;
        const nullable = has(field, "nullable") ? field.nullable : false;
        if (typeof multi !== "boolean" || typeof nullable !== "boolean")
          invalid("INVALID_SCHEMA", path);
        ownedMetadata[name] = Object.freeze({ type: field.type, multi, nullable });
      }
    }
  }
  return Object.freeze({ text: Object.freeze(ownedText), metadata: Object.freeze(ownedMetadata) });
}
function captureConfiguration(input) {
  const admission2 = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const config = ownObject(input, "INVALID_OPTIONS", "config", admission2);
  keysOnly(config, ["schema", "limits", "analyzer", "addons"], "INVALID_OPTIONS", "config");
  if (has(config, "limits") && config.limits === void 0)
    invalid("INVALID_OPTIONS", "config.limits");
  const limits = has(config, "limits") ? resolveLimits(config.limits, admission2) : DEFAULT_LIMITS;
  const schema2 = captureSchema(config.schema, limits, admission2);
  let selected = BASIC_ANALYZER.id;
  if (has(config, "analyzer")) {
    const analyzer = ownObject(config.analyzer, "INVALID_OPTIONS", "config.analyzer", admission2);
    keysOnly(analyzer, ["id", "environmentProfile"], "INVALID_OPTIONS", "config.analyzer");
    if (typeof analyzer.id !== "string" || typeof analyzer.environmentProfile !== "string")
      invalid("INVALID_OPTIONS", "config.analyzer");
    if (!/^[A-Za-z][A-Za-z0-9:._-]{0,127}$/.test(analyzer.id))
      invalid("INVALID_OPTIONS", "config.analyzer");
    selected = analyzer.id;
    if (analyzer.environmentProfile !== BASIC_ANALYZER.environmentProfile)
      invalid("INCOMPATIBLE_CAPABILITY", "config.analyzer");
  }
  const capabilities = has(config, "addons") ? captureRegistrations(config.addons, { schema: schema2, limits, admission: admission2 }) : void 0;
  const provider = capabilities?.providers[`analyzer:${selected}`];
  if (selected !== BASIC_ANALYZER.id && (!provider?.analyzer || provider.analyzer.id !== selected))
    invalid("MISSING_CAPABILITY", "config.analyzer");
  bound(admission2.count, limits.maxAdmissionEntries, "config");
  return Object.freeze({ schema: schema2, limits, analyzer: selected === BASIC_ANALYZER.id ? BASIC_ANALYZER : Object.freeze({ id: selected, environmentProfile: "unqualified" }), ...capabilities?.ordered.length ? { capabilities } : {} });
}

// dist/core/capabilities/participants.js
function initializeParticipants(configuration) {
  const states = /* @__PURE__ */ Object.create(null);
  const participants = [];
  for (const registration of configuration.capabilities?.ordered ?? []) {
    const handle = registration.participant;
    if (!handle)
      continue;
    const id = registration.manifest.id;
    states[id] = handle.initialize(configuration);
    participants.push(Object.freeze({ id, maxWorkUnits: Math.min(registration.manifest.limits.maxWorkUnits, configuration.limits.maxMutationWorkUnits), *prepare(previous, context) {
      const removedIds = [];
      for (const change of context.changes)
        if (change.previous && !change.next) {
          yield { workUnits: change.previous.id.length + 1 };
          removedIds.push(change.previous.id);
        }
      const request = Object.freeze({ ...context.analyze ? { analyze: context.analyze } : {}, kind: context.kind, previousRevision: context.previous.revision, revision: context.core.revision, analyzer: configuration.analyzer, records: context.records, removedIds: Object.freeze(removedIds) });
      const cursor = handle.prepare(previous, request);
      try {
        for (; ; ) {
          const step = cursor.next();
          if (step.done)
            return step.value;
          yield step.value;
        }
      } finally {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    } }));
  }
  return Object.freeze({ states: Object.freeze(states), participants: Object.freeze(participants) });
}

// dist/core/index/directory.js
var DIRECTORY_SLOTS = 256;
function bucketOf(key) {
  let hash = 2166136261;
  for (let i = 0; i < key.length; i++)
    hash = Math.imul(hash ^ key.charCodeAt(i), 16777619);
  return String((hash >>> 0) % DIRECTORY_SLOTS);
}
function directoryGet(directory, key) {
  return directory.buckets[bucketOf(key)]?.[key];
}
function* directoryEntries(directory) {
  for (const bucket of Object.values(directory.buckets)) {
    for (const key of Object.keys(bucket))
      yield [key, bucket[key]];
  }
}

// dist/core/index/staging.js
function emptyDirectory() {
  return Object.freeze({ size: 0, buckets: Object.freeze(/* @__PURE__ */ Object.create(null)) });
}
var DirectoryStage = class {
  original;
  charge;
  counts;
  pointers;
  touched = /* @__PURE__ */ new Map();
  count;
  sealed = false;
  constructor(original2, charge3, counts) {
    this.original = original2;
    this.charge = charge3;
    this.counts = counts;
    this.count = original2.size;
  }
  get size() {
    return this.count;
  }
  get(key) {
    return (this.pointers ?? this.original.buckets)[bucketOf(key)]?.[key];
  }
  *bucket(slot) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    if (!this.pointers) {
      const pointers = /* @__PURE__ */ Object.create(null);
      if (this.counts)
        this.counts.directories++;
      for (const slot2 of Object.keys(this.original.buckets)) {
        yield this.charge(1);
        pointers[slot2] = this.original.buckets[slot2];
        if (this.counts)
          this.counts.directoryPointers++;
      }
      this.pointers = pointers;
    }
    const cached = this.touched.get(slot);
    if (cached)
      return cached;
    const bucket = /* @__PURE__ */ Object.create(null);
    if (this.counts)
      this.counts.buckets++;
    const previous = this.original.buckets[slot];
    for (const entry of Object.keys(previous ?? {})) {
      yield this.charge(entry.length + 1);
      bucket[entry] = previous[entry];
      if (this.counts)
        this.counts.bucketEntries++;
    }
    this.touched.set(slot, bucket);
    this.pointers[slot] = bucket;
    return bucket;
  }
  *set(key, value) {
    yield this.charge(key.length + 1);
    const bucket = yield* this.bucket(bucketOf(key));
    if (!Object.hasOwn(bucket, key)) {
      this.count++;
      if (this.counts)
        this.counts.insertions++;
    }
    bucket[key] = value;
    if (this.counts)
      this.counts.writes++;
  }
  *delete(key) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    yield this.charge(key.length + 1);
    const slot = bucketOf(key);
    if ((this.pointers ?? this.original.buckets)[slot]?.[key] === void 0)
      return;
    const bucket = yield* this.bucket(slot);
    delete bucket[key];
    this.count--;
    if (this.counts)
      this.counts.deletes++;
  }
  *finish() {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    this.sealed = true;
    if (!this.pointers)
      return this.original;
    for (const [slot, bucket] of this.touched) {
      const keys = Object.keys(bucket);
      for (const key of keys)
        yield this.charge(key.length + 1);
      if (keys.length)
        Object.freeze(bucket);
      else
        delete this.pointers[slot];
    }
    for (const slot of Object.keys(this.pointers)) {
      void slot;
      yield this.charge(1);
    }
    return Object.freeze({ size: this.count, buckets: Object.freeze(this.pointers) });
  }
};

// dist/core/limits/work.js
var WorkBudget = class {
  maximum;
  policy = "work-v1";
  used = 0;
  constructor(maximum) {
    this.maximum = maximum;
  }
  get consumed() {
    return this.used;
  }
  charge(units) {
    if (!Number.isSafeInteger(units) || units < 0)
      invalid("INTERNAL_ERROR", "work.units");
    this.used += units;
    if (!Number.isSafeInteger(this.used) || this.used > this.maximum)
      invalid("WORK_LIMIT_EXCEEDED", "work");
  }
};
function validateExpansionCounts(perGroup, wholeQuery, limits) {
  for (const count of [perGroup, wholeQuery])
    if (!Number.isSafeInteger(count) || count < 0)
      invalid("INTERNAL_ERROR", "expansions");
  bound(perGroup, limits.maxExpansionsPerGroup, "expansions.group");
  bound(wholeQuery, limits.maxQueryExpansions, "expansions.query");
}

// dist/core/analyzer/identifier.js
function* runIdentifierAnalysis(handle, budget, value, valueIndex, limits, code, mode, check) {
  bound(value.length, limits.maxTextCodeUnitsPerValue, "analysis.value");
  const charge3 = (workUnits) => {
    check?.();
    budget.charge(workUnits);
    return { workUnits };
  };
  for (const step of scanUnicode(value, code, "analysis.value"))
    yield charge3(step.workUnits);
  const cursor = handle.analyze(value, valueIndex, limits, code, mode);
  let original2, position = 0, previousEnd = 0, componentEnd = 0, occurrences = 0;
  const terms = /* @__PURE__ */ new Set();
  const data = (input, keys) => {
    if (typeof input !== "object" || input === null || Array.isArray(input) || ![Object.prototype, null].includes(Object.getPrototypeOf(input)))
      invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
    const names = Reflect.ownKeys(input);
    if (names.length > keys.length)
      invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
    const result = /* @__PURE__ */ Object.create(null);
    for (const key of names) {
      if (typeof key !== "string" || !keys.includes(key))
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
      const property = Object.getOwnPropertyDescriptor(input, key);
      if (!property || !("value" in property))
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
      result[key] = property.value;
    }
    return result;
  };
  const boundary = (offset) => Number.isSafeInteger(offset) && offset >= 0 && offset <= value.length && !(offset > 0 && offset < value.length && value.charCodeAt(offset) >= 56320 && value.charCodeAt(offset) <= 57343);
  try {
    for (; ; ) {
      const next = cursor.next();
      check?.();
      if (next.done)
        break;
      const step = data(next.value, ["workUnits", "token"]);
      if (!Number.isSafeInteger(step.workUnits) || step.workUnits < 1)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.work");
      yield charge3(step.workUnits);
      if (!Object.hasOwn(step, "token"))
        continue;
      const owned = data(step.token, ["term", "valueIndex", "position", "start", "end", "kind", "original"]);
      if (Object.hasOwn(owned, "original"))
        owned.original = Object.freeze(data(owned.original, ["term", "start", "end"]));
      const token = Object.freeze(owned);
      if (token.valueIndex !== valueIndex || !boundary(token.start) || !boundary(token.end) || token.end <= token.start || token.kind !== "original" && token.kind !== "component" || typeof token.term !== "string" || !token.term.length)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
      bound(token.end - token.start, limits.maxRawTokenCodeUnits, "analysis.rawToken");
      bound(token.term.length, limits.maxTermCodeUnits, "analysis.term");
      bound(++occurrences, limits.maxTokensPerRecord, "analysis.tokens");
      for (const scan of scanUnicode(token.term, "INCOMPATIBLE_CAPABILITY", "analysis.term"))
        yield charge3(scan.workUnits);
      yield charge3(token.end - token.start + token.term.length + 1);
      if (value.slice(token.start, token.end).normalize("NFKC").toLowerCase() !== token.term)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.term");
      if (token.kind === "original") {
        if (token.original !== void 0 || token.position !== position++ || token.start < previousEnd)
          invalid("INCOMPATIBLE_CAPABILITY", "analysis.original");
        previousEnd = token.end;
        componentEnd = token.start;
        original2 = token;
        terms.clear();
        terms.add(token.term);
      } else {
        const origin = token.original;
        if (mode !== "index" || !original2 || !origin || !Object.isFrozen(origin) || Object.keys(origin).length !== 3 || !Object.keys(origin).every((key) => ["term", "start", "end"].includes(key)) || origin.term !== original2.term || origin.start !== original2.start || origin.end !== original2.end || token.position !== original2.position || token.start < componentEnd || token.end > original2.end || terms.has(token.term))
          invalid("INCOMPATIBLE_CAPABILITY", "analysis.component");
        componentEnd = token.end;
        terms.add(token.term);
      }
      yield charge3(1);
      yield { workUnits: 1, token };
    }
  } finally {
    try {
      cursor.return(void 0);
    } catch {
    }
  }
}

// dist/core/analyzer/selected.js
function createAnalysis(configuration, check) {
  if (configuration.analyzer.id === BASIC_ANALYZER.id)
    return analyzeValue;
  const registration = configuration.capabilities?.providers[`analyzer:${configuration.analyzer.id}`];
  if (!registration?.analyzer || registration.analyzer.id !== configuration.analyzer.id)
    invalid("MISSING_CAPABILITY", "analysis.analyzer");
  const handle = registration.analyzer, budget = new WorkBudget(registration.manifest.limits.maxWorkUnits);
  if (handle.kind === "identifier-tokenizer")
    return (value, valueIndex, limits, code = "INVALID_RECORD", mode = "index") => runIdentifierAnalysis(handle, budget, value, valueIndex, limits, code, mode, check);
  return function* (value, valueIndex, limits, code = "INVALID_RECORD") {
    for (const step of analyzeValue(value, valueIndex, limits, code)) {
      if (!step.token) {
        yield step;
        continue;
      }
      yield { workUnits: step.workUnits };
      const cursor = handle.transform(step.token.term);
      let term;
      try {
        for (; ; ) {
          const transformed = cursor.next();
          check?.();
          if (transformed.done) {
            term = transformed.value;
            break;
          }
          budget.charge(transformed.value.workUnits);
          yield transformed.value;
        }
      } finally {
        try {
          cursor.return("");
        } catch {
        }
      }
      if (typeof term !== "string" || !term.length)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.term");
      bound(term.length, limits.maxTermCodeUnits, "analysis.term");
      for (const scan of scanUnicode(term, "INCOMPATIBLE_CAPABILITY", "analysis.term")) {
        budget.charge(scan.workUnits);
        yield scan;
      }
      const units = term.length * 2 + 1;
      budget.charge(units);
      yield { workUnits: units };
      if (term.normalize("NFKC").toLowerCase() !== term)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.term");
      yield { workUnits: 1, token: Object.freeze({ ...step.token, term }) };
    }
  };
}

// dist/core/contracts/record.js
function captureId(input, limits, code, path) {
  const id = stringValue(input, limits.maxIdCodeUnits, code, path);
  if (!id.length)
    invalid(code, path);
  return id;
}
function captureScalar(input, field, limits, code, path) {
  if (input === null && field.nullable)
    return null;
  if (typeof input !== field.type)
    invalid(code, path);
  if (typeof input === "number") {
    if (!Number.isFinite(input))
      invalid(code, path);
    return input === 0 ? 0 : input;
  }
  if (typeof input === "string")
    return stringValue(input, limits.maxMetadataStringCodeUnits, code, path);
  if (typeof input === "boolean")
    return input;
  return invalid(code, path);
}
function captureRecord(input, schema2, limits, admission2 = new Admission(limits.maxAdmissionEntries), path = "record") {
  const record = ownObject(input, "INVALID_RECORD", path, admission2);
  keysOnly(record, ["id", "text", "metadata"], "INVALID_RECORD", path);
  const id = captureId(record.id, limits, "INVALID_RECORD", `${path}.id`);
  const textInput = ownObject(record.text, "INVALID_RECORD", `${path}.text`, admission2);
  const metadataInput = has(record, "metadata") ? ownObject(record.metadata, "INVALID_RECORD", `${path}.metadata`, admission2) : /* @__PURE__ */ Object.create(null);
  const text2 = /* @__PURE__ */ Object.create(null);
  const metadata = /* @__PURE__ */ Object.create(null);
  let textCodeUnits = 0;
  let metadataCodeUnits = 0;
  for (const name of Object.keys(textInput)) {
    if (!has(schema2.text, name))
      invalid("INVALID_RECORD", `${path}.text`);
    const fieldPath = `${path}.text.${name}`;
    const raw = textInput[name];
    const values = typeof raw === "string" ? [raw] : ownArray(raw, limits.maxTextValuesPerField, "INVALID_RECORD", fieldPath, admission2);
    text2[name] = Object.freeze(values.map((value, i) => {
      const string = stringValue(value, limits.maxTextCodeUnitsPerValue, "INVALID_RECORD", `${fieldPath}[${i}]`);
      textCodeUnits += string.length;
      bound(textCodeUnits, limits.maxTextCodeUnitsPerRecord, `${path}.text`);
      return string;
    }));
  }
  for (const name of Object.keys(metadataInput)) {
    const field = schema2.metadata[name];
    if (!field)
      invalid("INVALID_RECORD", `${path}.metadata`);
    const fieldPath = `${path}.metadata.${name}`;
    const value = metadataInput[name];
    const values = field.multi ? ownArray(value, limits.maxMetadataValuesPerField, "INVALID_RECORD", fieldPath, admission2) : [value];
    const owned = values.map((item, i) => {
      const scalar = captureScalar(item, field, limits, "INVALID_RECORD", `${fieldPath}[${i}]`);
      if (typeof scalar === "string")
        metadataCodeUnits += scalar.length;
      bound(metadataCodeUnits, limits.maxMetadataCodeUnitsPerRecord, `${path}.metadata`);
      return scalar;
    });
    metadata[name] = field.multi ? Object.freeze(owned) : owned[0];
  }
  return Object.freeze({ id, text: Object.freeze(text2), metadata: Object.freeze(metadata), textCodeUnits });
}
function captureBatch(input, schema2, limits, admission2 = new Admission(limits.maxAdmissionEntries)) {
  const values = ownArray(input, limits.maxMutationBatch, "INVALID_RECORD", "records", admission2);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const record = captureRecord(value, schema2, limits, admission2, `records[${i}]`);
    if (ids.has(record.id))
      invalid("INVALID_RECORD", `records[${i}].id`);
    ids.add(record.id);
    return record;
  }));
}
function captureRemoveIds(input, limits, admission2 = new Admission(limits.maxAdmissionEntries)) {
  const values = typeof input === "string" ? [input] : ownArray(input, limits.maxMutationBatch, "INVALID_OPTIONS", "ids", admission2);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const id = captureId(value, limits, "INVALID_OPTIONS", `ids[${i}]`);
    if (ids.has(id))
      invalid("INVALID_OPTIONS", `ids[${i}]`);
    ids.add(id);
    return id;
  }));
}
function* analyzeRecord(record, limits, counts, analyze = analyzeValue) {
  if (counts)
    counts.records++;
  yield* scanUnicode(record.id, "INVALID_RECORD", "record.id");
  for (const [field, value] of Object.entries(record.metadata)) {
    for (const item of Array.isArray(value) ? value : [value]) {
      if (typeof item === "string")
        yield* scanUnicode(item, "INVALID_RECORD", `record.metadata.${field}`);
    }
  }
  let tokens = 0;
  for (const [field, values] of Object.entries(record.text)) {
    for (let i = 0; i < values.length; i++) {
      if (counts) {
        counts.values++;
        counts.textCodeUnits += values[i].length;
      }
      for (const step of analyze(values[i], i, limits)) {
        if (step.token) {
          bound(++tokens, limits.maxTokensPerRecord, "record.tokens");
          yield { ...step, field };
        } else
          yield step;
      }
    }
  }
}
function canonicalMetadata(record) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const [name, value] of Object.entries(record.metadata)) {
    result[name] = Array.isArray(value) ? Object.freeze([...new Set(value)]) : value;
  }
  return Object.freeze(result);
}

// dist/core/capabilities/capture.js
function captureExtension(capture, input, admission2, limits, maximum) {
  const maxCodeUnits = Math.min(maximum, limits.maxQueryCodeUnits);
  const captured = capture(input, Object.freeze({ admission: admission2, limits, maxCodeUnits }));
  if (!captured || !Number.isSafeInteger(captured.codeUnits) || captured.codeUnits < 0 || captured.value !== null && typeof captured.value === "object" && !Object.isFrozen(captured.value))
    invalid("INCOMPATIBLE_CAPABILITY", "extensions.capture");
  bound(captured.codeUnits, maxCodeUnits, "extensions.payload");
  return captured;
}

// dist/core/contracts/options.js
function integer2(value, minimum, maximum, path) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
    invalid("INVALID_OPTIONS", path);
  bound(value, maximum, path);
  return value;
}
function captureOptions(input = {}, limits, search, admission2 = new Admission(limits.maxAdmissionEntries), capabilities) {
  const data = ownObject(input, "INVALID_OPTIONS", "options", admission2);
  keysOnly(data, search ? ["signal", "deadlineMs", "limit", "offset", "extensions"] : ["signal", "deadlineMs"], "INVALID_OPTIONS", "options");
  const deadlineMs = has(data, "deadlineMs") ? integer2(data.deadlineMs, 1, limits.maxDeadlineMs, "options.deadlineMs") : Math.min(3e4, limits.maxDeadlineMs);
  let signal;
  if (has(data, "signal")) {
    const candidate = data.signal;
    if (typeof candidate !== "object" || candidate === null || typeof candidate.aborted !== "boolean" || typeof candidate.addEventListener !== "function" || typeof candidate.removeEventListener !== "function")
      invalid("INVALID_OPTIONS", "options.signal");
    signal = candidate;
  }
  const base = { deadlineMs, ...signal ? { signal } : {} };
  if (!search)
    return Object.freeze(base);
  const offset = has(data, "offset") ? integer2(data.offset, 0, limits.maxDocuments, "options.offset") : 0;
  const limit = has(data, "limit") ? integer2(data.limit, 0, limits.maxHits, "options.limit") : Math.min(20, limits.maxHits, limits.maxDocuments - offset);
  bound(offset + limit, limits.maxDocuments, "options.page");
  let extensions;
  if (has(data, "extensions")) {
    const captured = ownObject(data.extensions, "INVALID_OPTIONS", "options.extensions", admission2);
    let units = 0;
    for (const capability of Object.keys(captured)) {
      const registration = capabilities?.providers[capability];
      const handler = registration?.evidence ?? registration?.aggregation ?? registration?.dictionary;
      if (!registration || !handler)
        invalid("MISSING_CAPABILITY", "options.extensions");
      const payload = captureExtension(handler.capture, captured[capability], admission2, limits, registration.manifest.limits.maxPayloadCodeUnits);
      units += capability.length + payload.codeUnits;
      bound(units, limits.maxQueryCodeUnits, "options.extensions");
      captured[capability] = payload.value;
    }
    if (Object.keys(captured).length)
      extensions = Object.freeze(captured);
  }
  return Object.freeze({ ...base, offset, limit, ...extensions ? { extensions } : {} });
}

// dist/core/mutations/capture.js
function captureMutation(configuration, kind, input, options) {
  const { schema: schema2, limits } = configuration, admission2 = new Admission(limits.maxAdmissionEntries);
  const capturedOptions = captureOptions(options, limits, false, admission2);
  if (capturedOptions.signal?.aborted)
    invalid("CANCELLED", "options.signal");
  let records2 = [], ids = [];
  switch (kind) {
    case "add":
    case "replace":
      records2 = Object.freeze([captureRecord(input, schema2, limits, admission2)]);
      break;
    case "addMany":
      records2 = captureBatch(input, schema2, limits, admission2);
      break;
    case "remove":
      ids = captureRemoveIds(input, limits, admission2);
      break;
    case "clear":
      if (input !== void 0)
        invalid("INVALID_OPTIONS", "clear");
      break;
    default:
      invalid("INVALID_OPTIONS", "mutation.kind");
  }
  return Object.freeze({ kind, records: Object.freeze(records2), ids: Object.freeze(ids), options: capturedOptions });
}

// dist/core/mutations/delta.js
function nonnegative(value, path) {
  if (!Number.isSafeInteger(value) || value < 0)
    invalid("INTERNAL_ERROR", path);
}
var CoreDelta = class {
  old;
  charge;
  diagnostics;
  documents;
  fields = /* @__PURE__ */ new Map();
  counts;
  constructor(old, charge3, diagnostics) {
    this.old = old;
    this.charge = charge3;
    this.diagnostics = diagnostics;
    validateStateCounts(old.counts, old.configuration.limits);
    if (old.documents.size !== old.counts.documents)
      invalid("INTERNAL_ERROR", "state.documents");
    this.counts = { ...old.counts };
    this.documents = new DirectoryStage(old.documents, charge3, diagnostics?.documents);
  }
  field(name) {
    let field = this.fields.get(name);
    if (!field) {
      const original2 = this.old.fields[name];
      if (!original2)
        invalid("INTERNAL_ERROR", "reverse.field");
      nonnegative(original2.documents, "field.documents");
      nonnegative(original2.length, "field.length");
      if (original2.documents > this.old.documents.size || original2.length < original2.documents)
        invalid("INTERNAL_ERROR", "field.statistics");
      field = { documents: original2.documents, length: original2.length, terms: new DirectoryStage(original2.terms, this.charge, this.diagnostics?.dictionary), cache: /* @__PURE__ */ new Map() };
      this.fields.set(name, field);
    }
    return field;
  }
  term(field, term) {
    let staged = field.cache.get(term);
    if (!staged) {
      const original2 = field.terms.get(term);
      if (original2) {
        nonnegative(original2.df, "term.df");
        nonnegative(original2.frequency, "term.frequency");
        if (!original2.df || original2.df !== original2.postings.size || original2.frequency < original2.df)
          invalid("INTERNAL_ERROR", "term.statistics");
      }
      staged = { ...original2 ? { original: original2 } : {}, df: original2?.df ?? 0, frequency: original2?.frequency ?? 0, postings: new DirectoryStage(original2?.postings ?? emptyDirectory(), this.charge, this.diagnostics?.postings) };
      field.cache.set(term, staged);
    }
    return staged;
  }
  *contribute(document2, sign) {
    nonnegative(document2.textCodeUnits, "reverse.textCodeUnits");
    this.counts.textCodeUnits += sign * document2.textCodeUnits;
    for (const [name, reverse] of Object.entries(document2.fields)) {
      yield this.charge(name.length + 2);
      const field = this.field(name);
      nonnegative(reverse.length, "reverse.length");
      if (!reverse.length)
        invalid("INTERNAL_ERROR", "reverse.length");
      field.documents += sign;
      field.length += sign * reverse.length;
      this.counts.tokens += sign * reverse.length;
      if (this.diagnostics)
        this.diagnostics.fieldUpdates++;
      let length = 0;
      for (const [key, tf] of Object.entries(reverse.terms)) {
        yield this.charge(key.length + document2.id.length + 4);
        nonnegative(tf, "reverse.tf");
        if (!tf)
          invalid("INTERNAL_ERROR", "reverse.tf");
        length += tf;
        const term = this.term(field, key), current = term.postings.get(document2.id);
        if (sign < 0) {
          if (current !== tf)
            invalid("INTERNAL_ERROR", "reverse.posting");
          yield* term.postings.delete(document2.id);
        } else {
          if (current !== void 0)
            invalid("INTERNAL_ERROR", "posting.duplicate");
          yield* term.postings.set(document2.id, tf);
        }
        term.df += sign;
        term.frequency += sign * tf;
        this.counts.postingEntries += sign;
        if (this.diagnostics)
          this.diagnostics.termUpdates++;
      }
      if (length !== reverse.length)
        invalid("INTERNAL_ERROR", "reverse.length");
    }
  }
  *apply(delta) {
    if (delta.previous) {
      yield* this.contribute(delta.previous, -1);
      yield* this.documents.delete(delta.previous.id);
      this.counts.documents--;
    }
    if (delta.next) {
      yield* this.contribute(delta.next, 1);
      yield* this.documents.set(delta.next.id, delta.next);
      this.counts.documents++;
    }
  }
  *finish() {
    const fields = /* @__PURE__ */ Object.create(null);
    for (const name of Object.keys(this.old.fields)) {
      yield this.charge(1);
      const field = this.fields.get(name);
      if (!field) {
        fields[name] = this.old.fields[name];
        continue;
      }
      for (const [key, term] of field.cache) {
        yield this.charge(key.length + 3);
        nonnegative(term.df, "term.df");
        nonnegative(term.frequency, "term.frequency");
        if (term.df !== term.postings.size || term.df > field.documents || term.frequency < term.df || term.frequency > field.length || !term.df && term.frequency !== 0)
          invalid("INTERNAL_ERROR", "term.statistics");
        if (!term.df) {
          if (term.original) {
            yield* field.terms.delete(key);
            this.counts.dictionaryEntries--;
          }
        } else {
          const postings = yield* term.postings.finish();
          yield* field.terms.set(key, Object.freeze({ df: term.df, frequency: term.frequency, postings }));
          if (!term.original)
            this.counts.dictionaryEntries++;
        }
      }
      nonnegative(field.documents, "field.documents");
      nonnegative(field.length, "field.length");
      if (field.documents > this.counts.documents || field.length < field.documents || !field.documents && field.length !== 0)
        invalid("INTERNAL_ERROR", "field.statistics");
      const terms = yield* field.terms.finish();
      if (field.documents === 0 !== (terms.size === 0))
        invalid("INTERNAL_ERROR", "field.terms");
      fields[name] = Object.freeze({ documents: field.documents, length: field.length, terms });
    }
    const documents2 = yield* this.documents.finish();
    yield this.charge(5);
    validateStateCounts(this.counts, this.old.configuration.limits);
    if (documents2.size !== this.counts.documents)
      invalid("INTERNAL_ERROR", "state.documents");
    return { documents: documents2, fields: Object.freeze(fields), counts: Object.freeze(this.counts) };
  }
};
function* clearedCore(old, charge3) {
  const fields = /* @__PURE__ */ Object.create(null);
  for (const name of Object.keys(old.fields)) {
    yield charge3(1);
    fields[name] = Object.freeze({ documents: 0, length: 0, terms: emptyDirectory() });
  }
  yield charge3(5);
  return { documents: emptyDirectory(), fields: Object.freeze(fields), counts: Object.freeze({ documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 }) };
}

// dist/core/mutations/document.js
function* prepareDocument(record, limits, charge3, counts, analyze = analyzeValue) {
  for (const values of Object.values(record.text)) {
    yield charge3(1);
    for (let i = 0; i < values.length; i++)
      yield charge3(1);
  }
  const fields = /* @__PURE__ */ Object.create(null);
  for (const step of analyzeRecord(record, limits, counts, analyze)) {
    yield charge3(step.workUnits);
    if (step.token) {
      yield charge3(step.token.term.length + 2);
      const field = fields[step.field] ??= { length: 0, terms: /* @__PURE__ */ Object.create(null) };
      field.length++;
      field.terms[step.token.term] = (field.terms[step.token.term] ?? 0) + 1;
    }
  }
  const frozen = /* @__PURE__ */ Object.create(null);
  for (const [name, field] of Object.entries(fields)) {
    for (const term of Object.keys(field.terms))
      yield charge3(term.length + 1);
    yield charge3(1);
    frozen[name] = Object.freeze({ length: field.length, terms: Object.freeze(field.terms) });
  }
  for (const value of Object.values(record.metadata)) {
    yield charge3(1);
    for (const item of Array.isArray(value) ? value : [value])
      yield charge3(typeof item === "string" ? item.length + 1 : 1);
  }
  const metadata = canonicalMetadata(record);
  for (const value of Object.values(metadata))
    yield charge3(Array.isArray(value) ? value.length + 1 : 1);
  return Object.freeze({ id: record.id, textCodeUnits: record.textCodeUnits, metadata, fields: Object.freeze(frozen) });
}

// dist/core/mutations/owner.js
var MutationOwner = class {
  #root;
  #active = false;
  participants;
  admitted = /* @__PURE__ */ new WeakSet();
  constructor(root2, participants = []) {
    if (!Number.isSafeInteger(root2.revision) || root2.revision < 0 || !Object.isFrozen(root2))
      invalid("INTERNAL_ERROR", "revision.root");
    const ids = /* @__PURE__ */ new Set();
    for (const participant of participants) {
      if (!participant.id || ids.has(participant.id) || typeof participant.prepare !== "function" || !Object.hasOwn(root2.participants, participant.id))
        invalid("INCOMPATIBLE_CAPABILITY", "participants");
      ids.add(participant.id);
    }
    if (Object.keys(root2.participants).length !== ids.size)
      invalid("INCOMPATIBLE_CAPABILITY", "participants");
    this.#root = root2;
    this.participants = Object.freeze(participants.map((p) => {
      if (p.maxWorkUnits !== void 0 && (!Number.isSafeInteger(p.maxWorkUnits) || p.maxWorkUnits < 1))
        invalid("INCOMPATIBLE_CAPABILITY", "participants.limits");
      return Object.freeze({ id: p.id, prepare: p.prepare.bind(p), ...p.maxWorkUnits !== void 0 ? { maxWorkUnits: p.maxWorkUnits } : {} });
    }));
  }
  get root() {
    return this.#root;
  }
  /** Trusted optional adapter publication after complete bounded preparation.
   * It runs in ExecutionOwner's FIFO, with no callbacks at the commit point. */
  publishPrepared(root2, previous) {
    if (this.#active || this.#root !== previous || root2.configuration !== previous.configuration || !Object.isFrozen(root2) || previous.revision === Number.MAX_SAFE_INTEGER || root2.revision !== previous.revision + 1 || Object.keys(root2.participants).length !== this.participants.length || this.participants.some((participant) => !Object.hasOwn(root2.participants, participant.id)))
      invalid("INTERNAL_ERROR", "adapter.publication");
    this.#root = root2;
  }
  capture(kind, input, options) {
    const request = captureMutation(this.#root.configuration, kind, input, options);
    this.admitted.add(request);
    return request;
  }
  mutate(kind, input, options) {
    return this.execute(this.capture(kind, input, options));
  }
  execute(request, control = {}) {
    if (!this.admitted.delete(request))
      invalid("INTERNAL_ERROR", "mutation.admission");
    return this.consume(request, control);
  }
  *consume(request, control) {
    if (this.#active)
      invalid("INTERNAL_ERROR", "mutation.active");
    this.#active = true;
    const old = this.#root, budget = new WorkBudget(old.configuration.limits.maxMutationWorkUnits);
    const analyze = control.analyze ?? createAnalysis(old.configuration, () => check());
    let phase = "start";
    const check = () => {
      control.checkpoint?.(phase);
      if (control.checkStop)
        control.checkStop(phase);
      else if (request.options.signal?.aborted)
        invalid("CANCELLED", "options.signal");
    };
    const charge3 = (workUnits) => {
      check();
      budget.charge(workUnits);
      if (control.diagnostics)
        control.diagnostics.workUnits = budget.consumed;
      return { workUnits };
    };
    const boundary = (next) => {
      phase = next;
      check();
    };
    try {
      check();
      const changes = [];
      let added = 0, replaced = 0, removed = 0;
      boundary("validation");
      if (request.kind === "remove") {
        for (const id of request.ids) {
          for (const step of scanUnicode(id, "INVALID_OPTIONS", "ids"))
            yield charge3(step.workUnits);
          yield charge3(id.length + 1);
          const previous = directoryGet(old.documents, id);
          if (previous) {
            changes.push(Object.freeze({ previous }));
            removed++;
          }
        }
      } else if (request.kind === "clear") {
        removed = old.documents.size;
      } else {
        for (const record of request.records) {
          yield charge3(record.id.length + 1);
          const previous = directoryGet(old.documents, record.id);
          if (request.kind === "replace") {
            if (!previous)
              invalid("ID_NOT_FOUND", "record.id");
          } else if (previous)
            invalid("ID_EXISTS", "record.id");
          boundary("analysis");
          const next = yield* prepareDocument(record, old.configuration.limits, charge3, control.diagnostics?.analysis, analyze);
          changes.push(Object.freeze({ ...previous ? { previous } : {}, next }));
          if (previous)
            replaced++;
          else
            added++;
          boundary("validation");
        }
      }
      const changed = added + replaced + removed > 0;
      if (!changed) {
        const result2 = Object.freeze({ revision: old.revision, changed: false, added, replaced, removed });
        boundary("precommit");
        yield charge3(1);
        check();
        return result2;
      }
      if (old.revision === Number.MAX_SAFE_INTEGER)
        invalid("REVISION_EXHAUSTED", "revision");
      boundary("staging");
      let coreData;
      if (request.kind === "clear")
        coreData = yield* clearedCore(old, charge3);
      else {
        const delta = new CoreDelta(old, charge3, control.diagnostics?.copies);
        for (const change of changes)
          yield* delta.apply(change);
        boundary("core");
        coreData = yield* delta.finish();
      }
      const core = Object.freeze({ ...coreData, revision: old.revision + 1, configuration: old.configuration, participants: old.participants });
      const context = Object.freeze({ analyze, kind: request.kind, previous: old, core, changes: Object.freeze(changes), records: request.records });
      const participants = /* @__PURE__ */ Object.create(null);
      for (const participant of this.participants) {
        boundary("participant");
        yield charge3(participant.id.length + 1);
        const participantBudget = participant.maxWorkUnits === void 0 ? void 0 : new WorkBudget(participant.maxWorkUnits);
        const iterator = participant.prepare(old.participants[participant.id], context);
        let finished = false;
        try {
          for (; ; ) {
            const step = iterator.next();
            if (step.done) {
              participants[participant.id] = step.value;
              finished = true;
              break;
            }
            const charged = charge3(step.value.workUnits);
            participantBudget?.charge(step.value.workUnits);
            yield charged;
          }
        } finally {
          if (!finished) {
            try {
              iterator.return(void 0);
            } catch {
            }
          }
        }
      }
      boundary("prepared");
      const root2 = Object.freeze({ ...core, participants: Object.freeze(participants) });
      const result = Object.freeze({ revision: root2.revision, changed: true, added, replaced, removed });
      boundary("precommit");
      yield charge3(1);
      check();
      this.#root = root2;
      return result;
    } finally {
      this.#active = false;
    }
  }
};

// dist/core/contracts/query.js
function captureQuery(input, schema2, limits, admission2 = new Admission(limits.maxAdmissionEntries), capabilities) {
  let nodes = 0;
  let lexicalUnits = 0;
  let stringUnits = 0;
  const ancestors = /* @__PURE__ */ new Set();
  function string(value, lexical, path) {
    const text2 = stringValue(value, limits.maxQueryCodeUnits, "INVALID_QUERY", path);
    stringUnits += text2.length;
    bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
    if (lexical) {
      lexicalUnits += text2.length;
      bound(lexicalUnits, limits.maxQueryLexicalCodeUnits, "query.lexical");
    }
    return text2;
  }
  function fields(value, path) {
    const names = ownArray(value, limits.maxTextFields, "INVALID_QUERY", path, admission2);
    if (!names.length)
      invalid("INVALID_QUERY", path);
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(names.map((name) => {
      const selected = string(name, false, path);
      if (!has(schema2.text, selected) || seen.has(selected))
        invalid("INVALID_QUERY", path);
      seen.add(selected);
      return selected;
    }));
  }
  function node(value, depth, path) {
    bound(++nodes, limits.maxQueryNodes, "query.nodes");
    bound(depth, limits.maxQueryDepth, "query.depth");
    const data = ownObject(value, "INVALID_QUERY", path, admission2);
    if (ancestors.has(value))
      invalid("INVALID_QUERY", path);
    ancestors.add(value);
    const kind = string(data.kind, false, `${path}.kind`);
    let result;
    switch (kind) {
      case "text": {
        keysOnly(data, ["kind", "text", "operator", "fields"], "INVALID_QUERY", path);
        const operator = has(data, "operator") ? string(data.operator, false, `${path}.operator`) : "and";
        if (operator !== "and" && operator !== "or")
          invalid("INVALID_QUERY", `${path}.operator`);
        result = {
          kind,
          text: string(data.text, true, `${path}.text`),
          operator,
          ...has(data, "fields") ? { fields: fields(data.fields, `${path}.fields`) } : {}
        };
        break;
      }
      case "group": {
        keysOnly(data, ["kind", "variants", "fields"], "INVALID_QUERY", path);
        const variants = ownArray(data.variants, limits.maxVariantsPerGroup, "INVALID_QUERY", `${path}.variants`, admission2);
        if (!variants.length)
          invalid("INVALID_QUERY", `${path}.variants`);
        const owned = variants.map((variant, i) => {
          const variantPath = `${path}.variants[${i}]`;
          const item = ownObject(variant, "INVALID_QUERY", variantPath, admission2);
          keysOnly(item, ["text", "match", "weight"], "INVALID_QUERY", variantPath);
          const match = string(item.match, false, `${variantPath}.match`);
          if (match !== "exact" && match !== "prefix")
            invalid("INVALID_QUERY", `${variantPath}.match`);
          const weight = has(item, "weight") ? item.weight : 1;
          if (typeof weight !== "number" || !Number.isFinite(weight) || weight <= 0 || weight > 1)
            invalid("INVALID_QUERY", `${variantPath}.weight`);
          return Object.freeze({ text: string(item.text, true, `${variantPath}.text`), match, weight });
        });
        result = { kind, variants: Object.freeze(owned), ...has(data, "fields") ? { fields: fields(data.fields, `${path}.fields`) } : {} };
        break;
      }
      case "and":
      case "or": {
        keysOnly(data, ["kind", "children"], "INVALID_QUERY", path);
        const children = ownArray(data.children, limits.maxQueryNodes, "INVALID_QUERY", `${path}.children`, admission2);
        if (!children.length)
          invalid("INVALID_QUERY", `${path}.children`);
        result = { kind, children: Object.freeze(children.map((child, i) => node(child, depth + 1, `${path}.children[${i}]`))) };
        break;
      }
      case "not":
        keysOnly(data, ["kind", "child"], "INVALID_QUERY", path);
        result = { kind, child: node(data.child, depth + 1, `${path}.child`) };
        break;
      case "eq": {
        keysOnly(data, ["kind", "field", "value"], "INVALID_QUERY", path);
        const name = string(data.field, false, `${path}.field`);
        const field = schema2.metadata[name];
        if (!field)
          invalid("INVALID_QUERY", `${path}.field`);
        const scalar = captureScalar(data.value, field, limits, "INVALID_QUERY", `${path}.value`);
        if (typeof scalar === "string")
          string(scalar, false, `${path}.value`);
        result = { kind, field: name, value: scalar };
        break;
      }
      case "all":
      case "none":
        keysOnly(data, ["kind"], "INVALID_QUERY", path);
        result = { kind };
        break;
      case "extension": {
        keysOnly(data, ["kind", "capability", "version", "payload"], "INVALID_QUERY", path);
        if (typeof data.capability !== "string" || !data.capability.length || !Number.isSafeInteger(data.version) || data.version < 1 || !has(data, "payload"))
          invalid("INVALID_QUERY", path);
        const capability = string(data.capability, false, `${path}.capability`);
        const registration = capabilities?.providers[capability];
        if (!registration?.refinement && !registration?.predicate && !registration?.sourcePredicate && !registration?.expansion)
          invalid("MISSING_CAPABILITY", path);
        if (data.version !== 1)
          invalid("INCOMPATIBLE_CAPABILITY", `${path}.version`);
        if (registration.predicate || registration.sourcePredicate) {
          const captured = captureExtension((registration.predicate ?? registration.sourcePredicate).capture, data.payload, admission2, limits, registration.manifest.limits.maxPayloadCodeUnits);
          if (registration.sourcePredicate) {
            lexicalUnits += captured.codeUnits;
            bound(lexicalUnits, limits.maxQueryLexicalCodeUnits, "query.lexical");
          }
          stringUnits += captured.codeUnits;
          bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
          result = { kind: "predicate", capability, payload: captured.value };
          break;
        }
        const payload = ownObject(data.payload, "INVALID_QUERY", `${path}.payload`, admission2);
        if (registration.refinement?.kind === "ordered-token-groups") {
          keysOnly(payload, ["groups", "maxGap", "fields"], "INVALID_QUERY", `${path}.payload`);
          const maxGap = payload.maxGap;
          if (typeof maxGap !== "number" || !Number.isSafeInteger(maxGap) || maxGap < 0)
            invalid("INVALID_QUERY", `${path}.payload.maxGap`);
          bound(maxGap, 32, `${path}.payload.maxGap`);
          const rawGroups = ownArray(payload.groups, Math.min(32, registration.refinement.maxTokens), "INVALID_QUERY", `${path}.payload.groups`, admission2);
          if (!rawGroups.length)
            invalid("INVALID_QUERY", `${path}.payload.groups`);
          const groups2 = Object.freeze(rawGroups.map((rawGroup) => {
            const alternatives = ownArray(rawGroup, Math.min(16, limits.maxVariantsPerGroup), "INVALID_QUERY", `${path}.payload.group`, admission2);
            if (!alternatives.length)
              invalid("INVALID_QUERY", `${path}.payload.group`);
            return Object.freeze(alternatives.map((value2) => string(value2, true, `${path}.payload.alternative`)));
          }));
          const selected2 = has(payload, "fields") ? fields(payload.fields, `${path}.payload.fields`) : registration.manifest.dataRequirements.fields;
          bound(groups2.reduce((sum, group) => sum + group.reduce((n, text3) => n + text3.length, 0), 0) + selected2.reduce((sum, field) => sum + field.length, 0), registration.manifest.limits.maxPayloadCodeUnits, `${path}.payload`);
          result = { kind: "ordered", capability, fields: selected2, groups: groups2, maxGap };
          break;
        }
        keysOnly(payload, ["text", "fields"], "INVALID_QUERY", `${path}.payload`);
        const text2 = string(payload.text, true, `${path}.payload.text`);
        const selected = has(payload, "fields") ? fields(payload.fields, `${path}.payload.fields`) : void 0;
        bound(text2.length + (selected?.reduce((sum, field) => sum + field.length, 0) ?? 0), registration.manifest.limits.maxPayloadCodeUnits, `${path}.payload`);
        result = { kind, capability, version: 1, payload: Object.freeze({ text: text2, ...selected ? { fields: selected } : {} }) };
        break;
      }
      default:
        return invalid("INVALID_QUERY", path);
    }
    ancestors.delete(value);
    return Object.freeze(result);
  }
  if (typeof input === "string") {
    bound(1, limits.maxQueryNodes, "query.nodes");
    bound(1, limits.maxQueryDepth, "query.depth");
    return Object.freeze({ kind: "text", text: string(input, true, "query"), operator: "and" });
  }
  return node(input, 1, "query");
}
function* analyzeQuery(query, schema2, limits, capabilities, analyze = analyzeValue) {
  let tokens = 0;
  const groups2 = /* @__PURE__ */ new Set();
  const queryLimits = { ...limits, maxTextCodeUnitsPerValue: limits.maxQueryLexicalCodeUnits };
  function groupKey(fields, variants) {
    const names = [...fields ?? Object.keys(schema2.text)].sort();
    const alternatives = [...new Set(variants.map((variant) => JSON.stringify(variant)))].sort();
    return JSON.stringify([names, alternatives]);
  }
  function addGroup(key) {
    groups2.add(key);
    bound(groups2.size, limits.maxQueryGroups, "query.groups");
  }
  function* walk(leaf) {
    switch (leaf.kind) {
      case "ordered": {
        const handler = capabilities?.providers[leaf.capability]?.refinement;
        if (handler?.kind !== "ordered-token-groups")
          invalid("MISSING_CAPABILITY", "query.capability");
        let count = 0;
        for (let groupIndex = 0; groupIndex < leaf.groups.length; groupIndex++) {
          const variants = [];
          for (const text2 of leaf.groups[groupIndex]) {
            let emitted = 0;
            for (const step of analyze(text2, 0, queryLimits, "INVALID_QUERY", "phrase")) {
              if (step.token) {
                if (++emitted > 1)
                  invalid("INVALID_QUERY", "query.proximity.alternative");
                bound(++count, handler.maxTokens, "query.proximity.tokens");
                bound(++tokens, limits.maxQueryTokens, "query.tokens");
                variants.push([step.token.term, "exact", 1]);
              }
              yield { ...step, leaf, groupIndex };
            }
            if (emitted !== 1)
              invalid("INVALID_QUERY", "query.proximity.alternative");
          }
          addGroup(groupKey(leaf.fields, variants));
        }
        break;
      }
      case "text":
        for (const step of analyze(leaf.text, 0, queryLimits, "INVALID_QUERY", "query")) {
          if (step.token) {
            bound(++tokens, limits.maxQueryTokens, "query.tokens");
            addGroup(groupKey(leaf.fields, [[step.token.term, "exact", 1]]));
          }
          yield { ...step, leaf };
        }
        break;
      case "extension": {
        const registration = capabilities?.providers[leaf.capability];
        const handler = registration?.refinement ?? registration?.expansion;
        if (!handler)
          invalid("MISSING_CAPABILITY", "query.capability");
        let count = 0;
        for (const step of analyze(leaf.payload.text, 0, queryLimits, "INVALID_QUERY", registration?.refinement ? "phrase" : "query")) {
          if (step.token) {
            bound(++count, handler.maxTokens, registration?.refinement ? "query.phraseTokens" : "query.expansionTokens");
            bound(++tokens, limits.maxQueryTokens, "query.tokens");
            addGroup(groupKey(leaf.payload.fields, [[step.token.term, "exact", 1]]));
          }
          yield { ...step, leaf };
        }
        break;
      }
      case "group": {
        const variants = [];
        for (let i = 0; i < leaf.variants.length; i++) {
          const variant = leaf.variants[i];
          let count = 0;
          for (const step of analyze(variant.text, 0, queryLimits, "INVALID_QUERY", "query")) {
            if (step.token) {
              bound(++tokens, limits.maxQueryTokens, "query.tokens");
              if (++count > 1)
                invalid("INVALID_QUERY", "query.variants");
              if (variant.match === "prefix" && [...step.token.term].length < limits.minPrefixCodePoints)
                invalid("INVALID_QUERY", "query.prefix");
              variants.push([step.token.term, variant.match, variant.weight ?? 1]);
            }
            yield { ...step, leaf, variantIndex: i };
          }
          if (count !== 1)
            invalid("INVALID_QUERY", "query.variants");
        }
        addGroup(groupKey(leaf.fields, variants));
        break;
      }
      case "and":
      case "or":
        for (const child of leaf.children)
          yield* walk(child);
        break;
      case "not":
        yield* walk(leaf.child);
        break;
      case "eq":
        if (typeof leaf.value === "string")
          yield* scanUnicode(leaf.value, "INVALID_QUERY", "query.value");
        break;
      case "predicate":
      case "all":
      case "none":
        break;
    }
  }
  yield* walk(query);
}

// dist/core/query/work.js
function* compareStrings(a, b, charge3) {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    yield charge3(1);
    const difference = a.charCodeAt(i) - b.charCodeAt(i);
    if (difference)
      return difference;
  }
  yield charge3(1);
  return a.length - b.length;
}
function* sortedStrings(input, charge3) {
  const output = [];
  for (const value of input) {
    yield charge3(value.length + 1);
    let i = output.length;
    while (i > 0 && (yield* compareStrings(value, output[i - 1], charge3)) < 0) {
      yield charge3(1);
      output[i] = output[i - 1];
      i--;
    }
    output[i] = value;
  }
  return output;
}

// dist/core/ranking/bm25.js
var positiveInteger = (value) => Number.isSafeInteger(value) && value > 0;
function* scoreDocument(root2, doc, participating, expansions, charge3, facts) {
  let score = 0;
  for (const key of yield* sortedStrings(participating, charge3)) {
    const expanded = expansions.get(key);
    let groupScore = 0;
    for (const field of expanded.group.fields) {
      let best = 0;
      let found = false;
      let selected;
      for (const alternative of expanded.fields.get(field)) {
        yield charge3(doc.id.length + field.length + alternative.term.length + 3);
        const tf = directoryGet(alternative.entry.postings, doc.id);
        if (tf === void 0)
          continue;
        yield charge3(1);
        const statistics = root2.fields[field];
        const length = doc.fields[field]?.length ?? 0;
        const N = statistics.documents;
        const totalLength = statistics.length;
        const df = alternative.entry.df;
        const boost = root2.configuration.schema.text[field].boost;
        if (!positiveInteger(tf) || !positiveInteger(df) || !positiveInteger(N) || !positiveInteger(totalLength) || !positiveInteger(length) || tf > length || df > N || N > root2.documents.size || totalLength < N || length > totalLength || !Number.isFinite(boost) || boost <= 0 || boost > 16)
          invalid("INTERNAL_ERROR", "ranking.statistics");
        const avgLength = totalLength / N;
        const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
        const normalizer = 1.2 * (1 - 0.75 + 0.75 * length / avgLength);
        const tfPart = tf * (1.2 + 1) / (tf + normalizer);
        const base = boost * idf * tfPart;
        const weighted = alternative.weight * base;
        if (!Number.isFinite(weighted) || weighted < 0)
          invalid("INTERNAL_ERROR", "ranking.score");
        if (!found || weighted > best) {
          found = true;
          best = weighted;
          if (facts)
            selected = { kind: "field", id: doc.id, group: key, field, term: alternative.term, variant: alternative.variantKey, weight: alternative.weight, boost, tf, df, N, length, totalLength, avgLength, k1: 1.2, b: 0.75, idf, normalizer, tfPart, base, selected: weighted };
        }
      }
      groupScore += best;
      if (facts && selected) {
        yield charge3(1);
        facts.record(selected);
      }
    }
    score += groupScore;
    if (facts) {
      yield charge3(1);
      facts.record({ kind: "group", id: doc.id, group: key, score: groupScore });
    }
  }
  if (!Number.isFinite(score) || score < 0)
    invalid("INTERNAL_ERROR", "ranking.score");
  return score;
}

// dist/core/ranking/page.js
var PageSelection = class {
  capacity;
  charge;
  heap = [];
  constructor(capacity, charge3) {
    this.capacity = capacity;
    this.charge = charge3;
  }
  *compare(a, b) {
    yield this.charge(1);
    return a.score === b.score ? yield* compareStrings(a.id, b.id, this.charge) : b.score - a.score;
  }
  *add(hit) {
    if (!this.capacity)
      return;
    if (this.heap.length === this.capacity) {
      if ((yield* this.compare(hit, this.heap[0])) >= 0)
        return;
      this.heap[0] = hit;
      yield* this.down();
    } else {
      let i = this.heap.length;
      this.heap.push(hit);
      yield this.charge(1);
      while (i > 0) {
        const parent = Math.floor((i - 1) / 2);
        if ((yield* this.compare(this.heap[i], this.heap[parent])) <= 0)
          break;
        yield this.charge(1);
        [this.heap[parent], this.heap[i]] = [this.heap[i], this.heap[parent]];
        i = parent;
      }
    }
  }
  *down() {
    let i = 0;
    while (i * 2 + 1 < this.heap.length) {
      let child = i * 2 + 1;
      if (child + 1 < this.heap.length && (yield* this.compare(this.heap[child + 1], this.heap[child])) > 0)
        child++;
      if ((yield* this.compare(this.heap[i], this.heap[child])) >= 0)
        break;
      yield this.charge(1);
      [this.heap[i], this.heap[child]] = [this.heap[child], this.heap[i]];
      i = child;
    }
  }
  *finish(offset, limit) {
    const reversed = [];
    while (this.heap.length) {
      const rank = this.heap.length - 1;
      const hit = this.heap[0];
      const last = this.heap.pop();
      yield this.charge(1);
      if (this.heap.length) {
        this.heap[0] = last;
        yield* this.down();
      }
      if (rank >= offset && rank < offset + limit) {
        yield this.charge(1);
        reversed.push(Object.freeze(hit));
      }
    }
    return Object.freeze(reversed.reverse());
  }
};

// dist/core/retrieval/expand.js
function* expandGroups(root2, groups2, charge3, checkpoint) {
  const queryPairs = /* @__PURE__ */ new Set();
  const result = /* @__PURE__ */ new Map();
  for (const key of yield* sortedStrings(groups2.keys(), charge3)) {
    const group = groups2.get(key);
    let perGroup = 0;
    const fields = /* @__PURE__ */ new Map();
    const ids = /* @__PURE__ */ new Set();
    for (const name of group.fields) {
      const field = root2.fields[name];
      if (!field)
        invalid("INTERNAL_ERROR", "index.fields");
      const terms = /* @__PURE__ */ new Map();
      function* add(term, entry, weight, variantKey) {
        yield charge3(term.length + 1);
        const old = terms.get(term);
        if (!old) {
          yield charge3(name.length + term.length + 1);
          queryPairs.add(JSON.stringify([name, term]));
          validateExpansionCounts(++perGroup, queryPairs.size, root2.configuration.limits);
        }
        if (!old || weight > old.weight || weight === old.weight && (yield* compareStrings(variantKey, old.variantKey, charge3)) < 0) {
          terms.set(term, Object.freeze({ term, entry, weight, variantKey }));
        }
      }
      for (const variant of group.variants) {
        if (variant.match === "exact") {
          checkpoint?.("dictionary");
          yield charge3(variant.term.length + 1);
          const entry = directoryGet(field.terms, variant.term);
          if (entry)
            yield* add(variant.term, entry, variant.weight, variant.key);
        } else {
          for (const [term, entry] of directoryEntries(field.terms)) {
            checkpoint?.("dictionary");
            yield charge3(1);
            let matches = term.length >= variant.term.length;
            for (let i = 0; matches && i < variant.term.length; i++) {
              yield charge3(1);
              matches = term.charCodeAt(i) === variant.term.charCodeAt(i);
            }
            if (matches)
              yield* add(term, entry, variant.weight, variant.key);
          }
        }
      }
      const alternatives = [];
      for (const term of yield* sortedStrings(terms.keys(), charge3)) {
        const expansion = terms.get(term);
        const entry = expansion.entry;
        if (!Number.isSafeInteger(entry.df) || entry.df < 1 || entry.df > field.documents || entry.df !== entry.postings.size)
          invalid("INTERNAL_ERROR", "index.df");
        alternatives.push(expansion);
        for (const [id, tf] of directoryEntries(entry.postings)) {
          checkpoint?.("postings");
          yield charge3(id.length + name.length + term.length + 3);
          const doc = directoryGet(root2.documents, id);
          if (!doc || !Number.isSafeInteger(tf) || tf <= 0 || doc.fields[name]?.terms[term] !== tf)
            invalid("INTERNAL_ERROR", "index.postings");
          yield charge3(id.length + 1);
          ids.add(id);
        }
      }
      fields.set(name, Object.freeze(alternatives));
    }
    result.set(key, { group, fields, ids });
  }
  return result;
}

// dist/core/trace/facts.js
function captureTrace(input, limits, admission2) {
  const data = ownObject(input, "INVALID_OPTIONS", "trace", admission2);
  keysOnly(data, ["ids", "maxFacts", "expectedRevision"], "INVALID_OPTIONS", "trace");
  const ids = ownArray(data.ids, limits.maxDocuments, "INVALID_OPTIONS", "trace.ids", admission2).map((id) => {
    const value = stringValue(id, limits.maxIdCodeUnits, "INVALID_OPTIONS", "trace.ids");
    if (!value.length)
      invalid("INVALID_OPTIONS", "trace.ids");
    return value;
  });
  if (new Set(ids).size !== ids.length)
    invalid("INVALID_OPTIONS", "trace.ids");
  const maxFacts = has(data, "maxFacts") ? data.maxFacts : 4096;
  if (typeof maxFacts !== "number" || !Number.isSafeInteger(maxFacts) || maxFacts < 1)
    invalid("INVALID_OPTIONS", "trace.maxFacts");
  bound(maxFacts, 4096, "trace.maxFacts");
  const revision = data.expectedRevision;
  if (has(data, "expectedRevision") && (typeof revision !== "number" || !Number.isSafeInteger(revision) || revision < 0))
    invalid("INVALID_OPTIONS", "trace.expectedRevision");
  return Object.freeze({ ids: Object.freeze(ids), maxFacts, ...typeof revision === "number" ? { expectedRevision: revision } : {} });
}
var FactCollector = class {
  maximum;
  facts = [];
  constructor(maximum) {
    this.maximum = maximum;
    bound(1, maximum, "trace.facts");
  }
  record(fact) {
    bound(this.facts.length + 2, this.maximum, "trace.facts");
    this.facts.push(Object.freeze(fact));
  }
  finish(revision, analyzer, query) {
    return Object.freeze({ revision, model: "raveldex-bm25-v1", analyzer, query, tieBreaker: "utf16-id-ascending", facts: Object.freeze(this.facts) });
  }
};

// dist/core/query/compile.js
function* compileQuery(query, configuration, charge3, expansion, analyze = createAnalysis(configuration)) {
  const tokens = /* @__PURE__ */ new Map();
  const orderedTokens = /* @__PURE__ */ new Map();
  for (const step of analyzeQuery(query, configuration.schema, configuration.limits, configuration.capabilities, analyze)) {
    yield charge3(step.workUnits);
    if (step.token && step.leaf) {
      yield charge3(1);
      if (step.groupIndex !== void 0) {
        let groups3 = orderedTokens.get(step.leaf);
        if (!groups3) {
          groups3 = [];
          orderedTokens.set(step.leaf, groups3);
        }
        const list2 = groups3[step.groupIndex] ?? [];
        list2.push(step.token.term);
        groups3[step.groupIndex] = list2;
        continue;
      }
      let list = tokens.get(step.leaf);
      if (!list) {
        list = [];
        tokens.set(step.leaf, list);
      }
      list.push(step.token.term);
    }
  }
  const groups2 = /* @__PURE__ */ new Map();
  function* group(fields, variants) {
    const names = yield* sortedStrings(fields ?? Object.keys(configuration.schema.text), charge3);
    const entries = /* @__PURE__ */ new Map();
    for (const variant of variants) {
      yield charge3(variant.term.length + 1);
      const key3 = JSON.stringify([variant.term, variant.match, variant.weight]);
      yield charge3(key3.length + 1);
      entries.set(key3, Object.freeze({ ...variant, key: key3 }));
    }
    const keys = yield* sortedStrings(entries.keys(), charge3);
    yield charge3(names.reduce((n, field) => n + field.length, 1) + keys.reduce((n, key3) => n + key3.length, 1));
    const key2 = JSON.stringify([names, keys]);
    yield charge3(key2.length + 1);
    let canonical = groups2.get(key2);
    if (!canonical) {
      canonical = Object.freeze({ key: key2, fields: Object.freeze(names), variants: Object.freeze(keys.map((entry) => entries.get(entry))) });
      groups2.set(key2, canonical);
      bound(groups2.size, configuration.limits.maxQueryGroups, "query.groups");
    }
    return Object.freeze({ kind: "group", group: canonical });
  }
  function* walk(raw) {
    yield charge3(1);
    switch (raw.kind) {
      case "ordered": {
        const lexical = [], termGroups = [];
        for (const terms of orderedTokens.get(raw) ?? []) {
          const node2 = yield* group(raw.fields, terms.map((term) => ({ term, match: "exact", weight: 1 })));
          if (node2.kind !== "group")
            invalid("INTERNAL_ERROR", "query.proximity.group");
          lexical.push(node2.group);
          termGroups.push(Object.freeze(node2.group.variants.map((variant) => variant.term)));
        }
        return Object.freeze({ kind: "extension", capability: raw.capability, fields: Object.freeze(yield* sortedStrings(raw.fields, charge3)), terms: Object.freeze(termGroups.flat()), groups: Object.freeze(lexical), termGroups: Object.freeze(termGroups), maxGap: raw.maxGap });
      }
      case "text": {
        const children = [];
        for (const term of tokens.get(raw) ?? [])
          children.push(yield* group(raw.fields, [{ term, match: "exact", weight: 1 }]));
        return children.length ? Object.freeze({ kind: raw.operator ?? "and", children: Object.freeze(children) }) : Object.freeze({ kind: "none" });
      }
      case "group":
        return yield* group(raw.fields, raw.variants.map((variant, i) => ({ term: tokens.get(raw)[i], match: variant.match, weight: variant.weight ?? 1 })));
      case "extension": {
        if (configuration.capabilities?.providers[raw.capability]?.expansion) {
          if (!expansion)
            invalid("MISSING_CAPABILITY", "query.expansion");
          const selected = Object.freeze(yield* sortedStrings(raw.payload.fields ?? Object.keys(configuration.schema.text), charge3));
          const terms2 = tokens.get(raw) ?? [];
          const alternatives = yield* expansion.resolve(raw.capability, selected, terms2);
          const children = [];
          for (let i = 0; i < alternatives.length; i++) {
            const term = terms2[i];
            const variants = [{ term, match: "exact", weight: 1 }, ...alternatives[i].filter((variant) => variant.term !== term)];
            bound(variants.length, configuration.limits.maxVariantsPerGroup, "query.expansion.variants");
            children.push(yield* group(selected, variants));
          }
          return children.length ? Object.freeze({ kind: "and", children: Object.freeze(children) }) : Object.freeze({ kind: "none" });
        }
        const lexical = [], terms = Object.freeze(tokens.get(raw) ?? []);
        for (const term of terms) {
          const node2 = yield* group(raw.payload.fields, [{ term, match: "exact", weight: 1 }]);
          if (node2.kind === "group")
            lexical.push(node2.group);
        }
        return Object.freeze({
          kind: "extension",
          capability: raw.capability,
          fields: Object.freeze(yield* sortedStrings(raw.payload.fields ?? Object.keys(configuration.schema.text), charge3)),
          terms,
          groups: Object.freeze(lexical)
        });
      }
      case "and":
      case "or": {
        const children = [];
        for (const child of raw.children)
          children.push(yield* walk(child));
        return Object.freeze({ kind: raw.kind, children: Object.freeze(children) });
      }
      case "not":
        return Object.freeze({ kind: "not", child: yield* walk(raw.child) });
      case "predicate":
        return Object.freeze({ kind: "predicate", capability: raw.capability, payload: raw.payload });
      case "eq":
        return Object.freeze({ kind: "eq", field: raw.field, value: raw.value });
      case "all":
      case "none":
        return Object.freeze({ kind: raw.kind });
    }
  }
  const node = yield* walk(query);
  const key = JSON.stringify(node);
  yield charge3(key.length + 1);
  return { node, groups: groups2, key };
}

// dist/core/query/evaluate.js
function* evaluate(node, doc, expansions, charge3, facts, path = "query", refinements) {
  yield charge3(1);
  let matched = false;
  let groups2 = /* @__PURE__ */ new Set();
  switch (node.kind) {
    case "group":
      yield charge3(doc.id.length + node.group.key.length + 1);
      matched = expansions.get(node.group.key).ids.has(doc.id);
      if (matched) {
        yield charge3(node.group.key.length + 1);
        groups2.add(node.group.key);
      }
      break;
    case "extension": {
      matched = node.terms.length > 0;
      for (const group of node.groups) {
        yield charge3(doc.id.length + group.key.length + 1);
        if (!expansions.get(group.key).ids.has(doc.id))
          matched = false;
      }
      if (matched) {
        const verifier = refinements?.get(node);
        if (!verifier)
          invalid("MISSING_CAPABILITY", "query.refinement");
        const cursor = verifier.test(doc.id, doc.metadata);
        try {
          for (; ; ) {
            const step = cursor.next();
            if (step.done) {
              matched = step.value;
              break;
            }
            yield step.value;
          }
        } finally {
          try {
            cursor.return(false);
          } catch {
          }
        }
      }
      if (matched)
        for (const group of node.groups) {
          yield charge3(group.key.length + 1);
          groups2.add(group.key);
        }
      break;
    }
    case "predicate": {
      const predicate = refinements?.get(node);
      if (!predicate)
        invalid("MISSING_CAPABILITY", "query.predicate");
      matched = yield* predicate.test(doc.id, doc.metadata);
      break;
    }
    case "all":
      matched = true;
      break;
    case "none":
      break;
    case "eq": {
      yield charge3(node.field.length + 1);
      if (Object.hasOwn(doc.metadata, node.field)) {
        const value = doc.metadata[node.field];
        const values = Array.isArray(value) ? value : [value];
        for (const scalar of values) {
          yield charge3(typeof scalar === "string" && typeof node.value === "string" ? Math.max(scalar.length, node.value.length) + 1 : 1);
          if (scalar === node.value) {
            matched = true;
            break;
          }
        }
      }
      break;
    }
    case "not":
      matched = !(yield* evaluate(node.child, doc, expansions, charge3, facts, facts ? `${path}.child` : "", refinements)).matched;
      break;
    case "and":
    case "or": {
      matched = node.kind === "and";
      for (let i = 0; i < node.children.length; i++) {
        const child = yield* evaluate(node.children[i], doc, expansions, charge3, facts, facts ? `${path}.children[${i}]` : "", refinements);
        matched = node.kind === "and" ? matched && child.matched : matched || child.matched;
        if (child.matched)
          for (const key of child.groups) {
            yield charge3(key.length + 1);
            groups2.add(key);
          }
      }
      if (!matched)
        groups2 = /* @__PURE__ */ new Set();
      break;
    }
  }
  if (facts) {
    const keys = Object.freeze(yield* sortedStrings(groups2, charge3));
    yield charge3(1);
    facts.record({
      kind: "node",
      id: doc.id,
      path,
      node: node.kind,
      matched,
      groups: keys,
      ...node.kind === "predicate" || node.kind === "extension" ? { capability: node.capability } : {},
      ...node.kind === "eq" ? { field: node.field } : {}
    });
  }
  return { matched, groups: groups2 };
}

// dist/core/capabilities/refinement.js
function* prepareRefinements(node, root2, charge3, options, analyze = createAnalysis(root2.configuration)) {
  const leaves = /* @__PURE__ */ new Map();
  const aggregations = [], budgets = /* @__PURE__ */ new Map();
  const outputs = [];
  let evidence;
  function setup(capability) {
    const set = root2.configuration.capabilities, registration = set?.providers[capability];
    if (!registration)
      invalid("MISSING_CAPABILITY", "query.capability");
    let budget = budgets.get(registration.manifest.id);
    if (!budget) {
      budget = new WorkBudget(Math.min(registration.manifest.limits.maxWorkUnits, root2.configuration.limits.maxSearchWorkUnits));
      budgets.set(registration.manifest.id, budget);
    }
    const shared = budget;
    return { registration, *run(cursor) {
      try {
        for (; ; ) {
          const step = cursor.next();
          charge3(0);
          if (step.done)
            return step.value;
          const charged = charge3(step.value.workUnits);
          shared.charge(step.value.workUnits);
          yield charged;
        }
      } finally {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    } };
  }
  const metadataContext = (capability, payload) => Object.freeze({ revision: root2.revision, schema: root2.configuration.schema, limits: root2.configuration.limits, capability, payload });
  function state(capability, consumer) {
    const registration = root2.configuration.capabilities.providers[consumer];
    if (!registration.manifest.requires.some((ref) => ref.id === capability))
      invalid("MISSING_CAPABILITY", "query.provider");
    const provider = root2.configuration.capabilities.providers[capability];
    if (!provider?.participant || !Object.hasOwn(root2.participants, provider.manifest.id))
      invalid("MISSING_CAPABILITY", "query.provider");
    return root2.participants[provider.manifest.id];
  }
  function output(capability, result) {
    if (!result || !Number.isSafeInteger(result.entries) || result.entries < 0 || result.value !== null && typeof result.value === "object" && !Object.isFrozen(result.value))
      invalid("INCOMPATIBLE_CAPABILITY", "extensions.output");
    bound(result.entries, Math.min(root2.configuration.capabilities.providers[capability].manifest.limits.maxOutputEntries, root2.configuration.limits.maxAdmissionEntries), "extensions.output");
    return result.value;
  }
  function* walk(node2) {
    if (node2.kind === "extension" || node2.kind === "predicate") {
      const { registration, run } = setup(node2.capability);
      let test;
      if (node2.kind === "extension") {
        if (!registration.refinement)
          invalid("MISSING_CAPABILITY", "query.refinement");
        if (registration.refinement.kind === "ordered-token-groups" !== (node2.termGroups !== void 0))
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement.kind");
        const context = Object.freeze({
          analyze,
          revision: root2.revision,
          analyzer: root2.configuration.analyzer,
          limits: root2.configuration.limits,
          fields: node2.fields,
          terms: node2.terms,
          ...node2.termGroups ? { groups: node2.termGroups, maxGap: node2.maxGap } : {},
          state(capability) {
            return state(capability, node2.capability);
          }
        });
        const prepared = yield* run(registration.refinement.prepare(context));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement");
        test = prepared.test.bind(prepared);
      } else if (registration.sourcePredicate) {
        const prepared = yield* run(registration.sourcePredicate.prepare(Object.freeze({
          ...metadataContext(node2.capability, node2.payload),
          analyzer: root2.configuration.analyzer,
          state: (requested) => state(requested, node2.capability)
        })));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.sourcePredicate");
        const predicate = prepared.test.bind(prepared);
        test = (id) => predicate(id);
      } else {
        if (!registration.predicate)
          invalid("MISSING_CAPABILITY", "query.predicate");
        const prepared = yield* run(registration.predicate.prepare(metadataContext(node2.capability, node2.payload)));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.predicate");
        const predicate = prepared.test.bind(prepared);
        test = (_id, metadata) => predicate(metadata);
      }
      leaves.set(node2, Object.freeze({ *test(id, metadata) {
        const matched = yield* run(test(id, metadata));
        if (typeof matched !== "boolean")
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement");
        return matched;
      } }));
    } else if (node2.kind === "and" || node2.kind === "or")
      for (const child of node2.children)
        yield* walk(child);
    else if (node2.kind === "not")
      yield* walk(node2.child);
  }
  yield* walk(node);
  for (const capability of Object.keys(options.extensions ?? {}).sort()) {
    yield charge3(capability.length + 1);
    const { registration, run } = setup(capability);
    if (registration.dictionary) {
      const prepared2 = yield* run(registration.dictionary.prepare(Object.freeze({
        ...metadataContext(capability, options.extensions[capability]),
        analyzer: root2.configuration.analyzer,
        *dictionary(fields) {
          if (!Array.isArray(fields) || !fields.length)
            invalid("INCOMPATIBLE_CAPABILITY", "extensions.dictionary.fields");
          bound(fields.length, root2.configuration.limits.maxTextFields, "extensions.dictionary.fields");
          const selected = /* @__PURE__ */ new Set();
          for (const field of fields) {
            if (typeof field !== "string" || !registration.manifest.dataRequirements.fields.includes(field) || selected.has(field))
              invalid("MISSING_CAPABILITY", "extensions.dictionary.fields");
            selected.add(field);
          }
          for (const field of selected)
            for (const [term, entry] of directoryEntries(root2.fields[field].terms)) {
              yield Object.freeze({ workUnits: field.length + term.length + 1, field, term, documentFrequency: entry.df });
            }
        }
      })));
      if (!prepared2 || typeof prepared2.finish !== "function")
        invalid("INCOMPATIBLE_CAPABILITY", "extensions.dictionary");
      const finish2 = prepared2.finish.bind(prepared2);
      outputs.push(Object.freeze({ capability, *finish() {
        return output(capability, yield* run(finish2()));
      } }));
      continue;
    }
    if (registration.evidence) {
      if (evidence)
        invalid("INVALID_OPTIONS", "options.extensions.evidence");
      const prepared2 = yield* run(registration.evidence.prepare(Object.freeze({
        ...metadataContext(capability, options.extensions[capability]),
        analyzer: root2.configuration.analyzer,
        analyze,
        state: (requested) => state(requested, capability)
      })));
      if (!prepared2 || typeof prepared2.finish !== "function")
        invalid("INCOMPATIBLE_CAPABILITY", "extensions.evidence");
      const finish2 = prepared2.finish.bind(prepared2);
      evidence = Object.freeze({ capability, *finish(context) {
        return output(capability, yield* run(finish2(context)));
      } });
      continue;
    }
    if (!registration.aggregation)
      invalid("MISSING_CAPABILITY", "options.extensions");
    const prepared = yield* run(registration.aggregation.prepare(metadataContext(capability, options.extensions[capability])));
    if (!prepared || typeof prepared.add !== "function" || typeof prepared.finish !== "function")
      invalid("INCOMPATIBLE_CAPABILITY", "extensions.aggregation");
    const add = prepared.add.bind(prepared), finish = prepared.finish.bind(prepared);
    aggregations.push(Object.freeze({
      capability,
      *add(metadata) {
        if ((yield* run(add(metadata))) !== void 0)
          invalid("INCOMPATIBLE_CAPABILITY", "extensions.aggregation");
      },
      *finish() {
        return output(capability, yield* run(finish()));
      }
    }));
  }
  return { leaves, aggregations, outputs, ...evidence ? { evidence } : {} };
}

// dist/core/capabilities/expansion.js
function createExpansionResolver(root2, charge3) {
  const budgets = /* @__PURE__ */ new Map(), outputs = /* @__PURE__ */ new Map();
  const observations = /* @__PURE__ */ new Map(), cache = /* @__PURE__ */ new Map();
  let outputEntries = 0;
  return {
    *resolve(capability, fields, terms) {
      if (root2.configuration.analyzer.id !== "basic-v1")
        invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.analyzer");
      const registration = root2.configuration.capabilities?.providers[capability];
      if (!registration?.expansion)
        invalid("MISSING_CAPABILITY", "query.expansion");
      for (const field of fields) {
        yield charge3(field.length + 1);
        if (!registration.manifest.dataRequirements.fields.includes(field))
          invalid("MISSING_CAPABILITY", "query.expansion.fields");
      }
      const output = (count) => {
        const entries = (outputs.get(registration.manifest.id) ?? 0) + count;
        bound(entries, registration.manifest.limits.maxOutputEntries, "query.expansion.output");
        bound(outputEntries + count, root2.configuration.limits.maxAdmissionEntries, "query.expansion.output");
        outputs.set(registration.manifest.id, entries);
        outputEntries += count;
      };
      if (!observations.has(capability)) {
        output(3);
        yield charge3(3);
        observations.set(capability, []);
      }
      let budget = budgets.get(registration.manifest.id);
      if (!budget) {
        budget = new WorkBudget(Math.min(registration.manifest.limits.maxWorkUnits, root2.configuration.limits.maxSearchWorkUnits));
        budgets.set(registration.manifest.id, budget);
      }
      const result = [];
      for (const term of terms) {
        const key = JSON.stringify([capability, fields, term]);
        yield charge3(key.length + 1);
        const reused = cache.get(key);
        if (reused) {
          result.push(reused);
          continue;
        }
        const before = budget.consumed;
        let exact = false, visited = 0;
        for (const field of fields) {
          yield charge3(field.length + term.length + 1);
          if (directoryGet(root2.fields[field].terms, term))
            exact = true;
        }
        const context = Object.freeze({
          revision: root2.revision,
          analyzer: root2.configuration.analyzer,
          limits: root2.configuration.limits,
          fields,
          term,
          exact,
          *dictionary() {
            for (const field of fields)
              for (const [candidate] of directoryEntries(root2.fields[field].terms)) {
                visited++;
                yield { workUnits: field.length + candidate.length + 1, term: candidate };
              }
          }
        });
        const cursor = registration.expansion.expand(context);
        let alternatives;
        try {
          for (; ; ) {
            const step = cursor.next();
            if (step.done) {
              alternatives = step.value;
              break;
            }
            const charged = charge3(step.value.workUnits);
            budget.charge(step.value.workUnits);
            yield charged;
          }
        } finally {
          try {
            cursor.return([]);
          } catch {
          }
        }
        if (!Array.isArray(alternatives) || !Object.isFrozen(alternatives))
          invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.output");
        bound(alternatives.length, root2.configuration.limits.maxVariantsPerGroup, "query.expansion.alternatives");
        const byTerm = /* @__PURE__ */ new Map();
        for (const alternative of alternatives) {
          if (!alternative || typeof alternative.term !== "string" || !alternative.term.length || alternative.term.length > root2.configuration.limits.maxTermCodeUnits || !Number.isFinite(alternative.weight) || alternative.weight <= 0 || alternative.weight > 1 || byTerm.has(alternative.term))
            invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.output");
          yield charge3(alternative.term.length + 1);
          let live = false;
          for (const field of fields) {
            yield charge3(field.length + alternative.term.length + 1);
            if (directoryGet(root2.fields[field].terms, alternative.term))
              live = true;
          }
          if (!live)
            invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.dictionary");
          byTerm.set(alternative.term, Object.freeze({ term: alternative.term, match: "exact", weight: alternative.weight }));
        }
        const variants = [];
        for (const name of yield* sortedStrings(byTerm.keys(), charge3))
          variants.push(byTerm.get(name));
        const owned = Object.freeze(variants);
        const entries = 8 + fields.length + 4 * variants.length;
        output(entries);
        yield charge3(entries);
        const list = observations.get(capability) ?? [];
        list.push(Object.freeze({ term, fields, alternatives: owned, dictionaryEntriesVisited: visited, workUnits: budget.consumed - before }));
        observations.set(capability, list);
        cache.set(key, owned);
        result.push(owned);
      }
      return result;
    },
    finish() {
      if (!observations.size)
        return void 0;
      const result = /* @__PURE__ */ Object.create(null);
      for (const [capability, groups2] of observations)
        result[capability] = Object.freeze({
          policy: root2.configuration.capabilities.providers[capability].expansion.policy,
          groups: Object.freeze(groups2)
        });
      return Object.freeze(result);
    }
  };
}

// dist/core/query/search.js
function captureSearch(configuration, input, options, trace) {
  const { schema: schema2, limits } = configuration;
  const admission2 = new Admission(limits.maxAdmissionEntries);
  const page = captureOptions(options, limits, true, admission2, configuration.capabilities);
  if (page.signal?.aborted)
    invalid("CANCELLED", "options.signal");
  const query = captureQuery(input, schema2, limits, admission2, configuration.capabilities);
  let request = trace === void 0 ? void 0 : captureTrace(trace, limits, admission2);
  let evidence;
  for (const capability of Object.keys(page.extensions ?? {})) {
    const handler = configuration.capabilities?.providers[capability]?.evidence;
    if (!handler)
      continue;
    if (request || evidence)
      invalid("INVALID_OPTIONS", "options.extensions.evidence");
    request = captureTrace(handler.select(page.extensions[capability]), limits, admission2);
    evidence = capability;
  }
  return Object.freeze({ query, options: page, ...request ? { trace: request } : {}, ...evidence ? { evidence } : {} });
}
function* executeOwnedSearch(root2, request, control = {}) {
  const { query, options, trace } = request;
  const budget = new WorkBudget(root2.configuration.limits.maxSearchWorkUnits);
  let phase = "start";
  const check = () => {
    control.checkpoint?.(phase);
    if (control.checkStop)
      control.checkStop(phase);
    else if (options.signal?.aborted)
      invalid("CANCELLED", "options.signal");
  };
  const boundary = (next) => {
    phase = next;
    check();
  };
  const charge3 = (workUnits) => {
    check();
    budget.charge(workUnits);
    return { workUnits };
  };
  check();
  if (trace?.expectedRevision !== void 0 && trace.expectedRevision !== root2.revision)
    invalid("REVISION_MISMATCH", "trace.expectedRevision");
  const selected = /* @__PURE__ */ new Set();
  if (trace)
    for (const id of trace.ids) {
      for (const step of scanUnicode(id, "INVALID_OPTIONS", "trace.ids"))
        yield charge3(step.workUnits);
      yield charge3(id.length + 1);
      selected.add(id);
    }
  const collector = trace ? new FactCollector(trace.maxFacts) : void 0;
  boundary("analysis");
  const expansion = root2.configuration.capabilities?.ordered.some((registration) => registration.expansion) ? createExpansionResolver(root2, charge3) : void 0;
  const analyze = createAnalysis(root2.configuration, check);
  const compiled = yield* compileQuery(query, root2.configuration, charge3, expansion, analyze);
  boundary("expansion");
  const expansions = yield* expandGroups(root2, compiled.groups, charge3, boundary);
  const extensions = root2.configuration.capabilities ? yield* prepareRefinements(compiled.node, root2, charge3, options, analyze) : void 0;
  const page = new PageSelection(options.limit ? options.offset + options.limit : 0, charge3);
  let total = 0;
  for (const [id, doc] of directoryEntries(root2.documents)) {
    boundary("evaluation");
    yield charge3(id.length + 1);
    if (doc.id !== id)
      invalid("INTERNAL_ERROR", "index.documents");
    const facts = selected.has(id) ? collector : void 0;
    const qualified = yield* evaluate(compiled.node, doc, expansions, charge3, facts, "query", extensions?.leaves);
    boundary("scoring");
    const score = qualified.matched ? yield* scoreDocument(root2, doc, qualified.groups, expansions, charge3, facts) : 0;
    if (qualified.matched) {
      total++;
      if (extensions?.aggregations.length) {
        boundary("aggregation");
        for (const aggregation of extensions.aggregations)
          yield* aggregation.add(doc.metadata);
      }
      boundary("selection");
      yield* page.add({ id, score });
    }
    if (facts) {
      const groups2 = Object.freeze(yield* sortedStrings(qualified.groups, charge3));
      yield charge3(1);
      facts.record({ kind: "document", id, exists: true, matched: qualified.matched, groups: groups2, score });
    }
  }
  if (collector)
    for (const id of selected) {
      yield charge3(id.length + 1);
      if (!directoryGet(root2.documents, id))
        collector.record({ kind: "document", id, exists: false, matched: false, groups: Object.freeze([]), score: 0 });
    }
  boundary("selection");
  const hits = yield* page.finish(options.offset, options.limit);
  let additional = expansion?.finish();
  if (extensions?.aggregations.length) {
    boundary("aggregation");
    const result2 = /* @__PURE__ */ Object.create(null);
    for (const aggregation of extensions.aggregations)
      result2[aggregation.capability] = yield* aggregation.finish();
    additional = Object.freeze({ ...additional, ...result2 });
  }
  const scoreTrace = collector?.finish(root2.revision, root2.configuration.analyzer, compiled.key);
  if (extensions?.outputs.length) {
    boundary("aggregation");
    const result2 = /* @__PURE__ */ Object.create(null);
    for (const output of extensions.outputs)
      result2[output.capability] = yield* output.finish();
    additional = Object.freeze({ ...additional, ...result2 });
  }
  if (extensions?.evidence) {
    boundary("aggregation");
    if (!scoreTrace)
      invalid("INTERNAL_ERROR", "extensions.evidence");
    const publicResult = Object.freeze({ revision: root2.revision, model: "raveldex-bm25-v1", completeness: "complete", total, hits, ...additional ? { extensions: additional } : {} });
    const value = yield* extensions.evidence.finish(Object.freeze({
      query: compiled.node,
      trace: scoreTrace,
      result: publicResult,
      counts: root2.counts,
      searchWorkUnits: budget.consumed,
      maxSearchWorkUnits: root2.configuration.limits.maxSearchWorkUnits,
      capabilities: Object.freeze(root2.configuration.capabilities.ordered.map((registration) => registration.manifest))
    }));
    additional = Object.freeze({ ...additional, [extensions.evidence.capability]: value });
  }
  boundary("result");
  yield charge3(1);
  const result = Object.freeze({
    revision: root2.revision,
    model: "raveldex-bm25-v1",
    completeness: "complete",
    total,
    hits,
    ...scoreTrace && !request.evidence ? { trace: scoreTrace } : {},
    ...additional ? { extensions: additional } : {}
  });
  check();
  return result;
}

// dist/core/execution/host.js
function directHost() {
  const host = globalThis;
  if (typeof host.performance?.now !== "function" || typeof host.setTimeout !== "function" || typeof host.clearTimeout !== "function")
    invalid("INTERNAL_ERROR", "execution.host");
  const now = host.performance.now.bind(host.performance);
  const schedule = host.setTimeout.bind(host), cancel = host.clearTimeout.bind(host);
  return Object.freeze({ now, schedule(callback, delayMs) {
    const handle = schedule(callback, delayMs);
    return () => cancel(handle);
  } });
}

// dist/core/execution/engine.js
function emptyRoot(configuration, states = Object.freeze(/* @__PURE__ */ Object.create(null))) {
  const fields = /* @__PURE__ */ Object.create(null);
  for (const name of Object.keys(configuration.schema.text))
    fields[name] = Object.freeze({ documents: 0, length: 0, terms: emptyDirectory() });
  return Object.freeze({
    configuration,
    revision: 0,
    documents: emptyDirectory(),
    fields: Object.freeze(fields),
    counts: Object.freeze({ documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 }),
    participants: states
  });
}
var ExecutionOwner = class {
  #owner;
  #configuration;
  #host;
  #metrics;
  #queue = [];
  #active;
  #closing = false;
  #pumping = false;
  #disposal;
  #disposed;
  constructor(root2, host, participants = [], metrics) {
    this.#owner = new MutationOwner(root2, participants);
    this.#configuration = root2.configuration;
    this.#metrics = metrics;
    this.#host = Object.freeze({ now: host.now.bind(host), schedule: host.schedule.bind(host) });
  }
  get root() {
    return this.#owner?.root;
  }
  adapterOperation(capture, control) {
    return this.admit(() => {
      const request = capture(this.#configuration);
      return { options: request.options, start: (check) => {
        const owner = this.#owner, previous = owner.root;
        return request.start(previous, check, (root2) => owner.publishPrepared(root2, previous));
      } };
    }, control);
  }
  adapterReplace(capture) {
    return this.admit(() => {
      const request = capture(this.#configuration);
      return { options: request.options, start: (check) => {
        const owner = this.#owner, maximum = this.#configuration.limits.maxMutationWorkUnits;
        return (function* () {
          const budget = new WorkBudget(maximum);
          function* metered(cursor) {
            let finished = false;
            try {
              for (; ; ) {
                check("patch");
                const step = cursor.next();
                if (step.done) {
                  finished = true;
                  return step.value;
                }
                check("patch");
                budget.charge(step.value.workUnits);
                yield step.value;
              }
            } finally {
              if (!finished) {
                try {
                  cursor.return(void 0);
                } catch {
                }
              }
            }
          }
          const record = yield* metered(request.start(owner.root, check));
          check("patch.replace");
          const replacement = owner.capture("replace", record, request.options);
          check("patch.replace");
          return yield* metered(owner.execute(replacement, { checkStop: check }));
        })();
      } };
    });
  }
  search(query, options) {
    return this.searchControlled(query, options);
  }
  searchControlled(query, options, control) {
    return this.admit(() => {
      const request = captureSearch(this.#configuration, query, options);
      return { options: request.options, start: (check) => executeOwnedSearch(this.#owner.root, request, { checkStop: check }) };
    }, control);
  }
  add(record, options) {
    return this.mutate("add", record, options);
  }
  addMany(records2, options) {
    return this.mutate("addMany", records2, options);
  }
  replace(record, options) {
    return this.mutate("replace", record, options);
  }
  remove(ids, options) {
    return this.mutate("remove", ids, options);
  }
  clear(options) {
    return this.mutate("clear", void 0, options);
  }
  mutate(kind, input, options) {
    return this.mutateControlled(kind, input, options);
  }
  mutateControlled(kind, input, options, control) {
    return this.admit(() => {
      const request = this.#owner.capture(kind, input, options);
      return { options: request.options, start: (check) => this.#owner.execute(request, { checkStop: check }) };
    }, control);
  }
  check(op, phase) {
    if (this.#metrics) {
      this.#metrics.checks++;
      if (phase)
        this.#metrics.phaseChecks[phase] = (this.#metrics.phaseChecks[phase] ?? 0) + 1;
    }
    if (this.#closing)
      invalid("DISPOSED", "execution");
    const aborted = op.options?.signal?.aborted;
    const expired = this.#host.now() >= op.deadline;
    if (this.#closing)
      invalid("DISPOSED", "execution");
    if (aborted || op.cancelled)
      invalid("CANCELLED", "options.signal");
    if (expired)
      invalid("DEADLINE_EXCEEDED", "options.deadlineMs");
  }
  admit(capture, control) {
    try {
      if (this.#closing)
        invalid("DISPOSED", "execution");
      const admittedAt = this.#host.now();
      const request = capture();
      if (control) {
        if (!Number.isFinite(control.elapsedMs) || control.elapsedMs < 0)
          invalid("INTERNAL_ERROR", "execution.control");
        request.options = Object.freeze({ ...request.options, signal: control.signal });
      }
      if (this.#closing)
        invalid("DISPOSED", "execution");
      if (request.options.signal?.aborted)
        invalid("CANCELLED", "options.signal");
      if (control && control.elapsedMs >= request.options.deadlineMs)
        invalid("DEADLINE_EXCEEDED", "options.deadlineMs");
      if (this.#active && this.#queue.length >= this.#configuration.limits.maxQueuedOperations)
        invalid("QUEUE_FULL", "execution.queue");
      let resolve, reject;
      const promise = new Promise((yes, no) => {
        resolve = yes;
        reject = no;
      });
      const op = {
        options: request.options,
        start: void 0,
        cursor: void 0,
        resolve,
        reject,
        deadline: admittedAt + request.options.deadlineMs - (control?.elapsedMs ?? 0),
        detach: void 0,
        timer: void 0,
        resume: void 0,
        settled: false,
        executing: false,
        cancelled: false
      };
      op.start = () => request.start((phase) => this.check(op, phase));
      if (this.#active)
        this.#queue.push(op);
      else
        this.#active = op;
      try {
        const signal = op.options.signal;
        if (signal) {
          const stop = () => {
            op.cancelled = true;
            this.stop(op);
          };
          op.detach = () => signal.removeEventListener("abort", stop);
          signal.addEventListener("abort", stop, { once: true });
          if (op.settled) {
            try {
              signal.removeEventListener("abort", stop);
            } catch {
            }
          }
        }
        if (!op.settled) {
          this.check(op);
          op.timer = this.#host.schedule(() => {
            op.timer = void 0;
            this.stop(op);
          }, Math.max(0, op.deadline - this.#host.now()));
        }
      } catch (error) {
        this.finish(op, void 0, this.error(error));
      }
      this.pump();
      return promise;
    } catch (error) {
      return Promise.reject(this.error(error));
    }
  }
  /** Event/timer stop while suspended closes staging immediately; running code checks cooperatively. */
  stop(op) {
    if (op.settled || op.executing)
      return;
    try {
      this.check(op);
      op.timer?.();
      op.timer = this.#host.schedule(() => {
        op.timer = void 0;
        this.stop(op);
      }, Math.max(0, op.deadline - this.#host.now()));
    } catch (error) {
      this.finish(op, void 0, this.error(error));
      this.pump();
    }
  }
  pump() {
    if (this.#pumping)
      return;
    this.#pumping = true;
    let consumed = 0;
    try {
      for (; ; ) {
        if (!this.#active)
          this.#active = this.#queue.shift();
        const op = this.#active;
        if (!op || op.resume)
          break;
        op.executing = true;
        try {
          this.check(op);
          op.cursor ??= op.start();
          op.start = void 0;
          for (; ; ) {
            this.check(op);
            const step = op.cursor.next();
            if (step.done) {
              this.finish(op, step.value);
              break;
            }
            consumed += step.value.workUnits;
            if (this.#metrics) {
              this.#metrics.workUnits += step.value.workUnits;
              this.#metrics.steps++;
              this.#metrics.maxStepWorkUnits = Math.max(this.#metrics.maxStepWorkUnits, step.value.workUnits);
              this.#metrics.maxTaskWorkUnits = Math.max(this.#metrics.maxTaskWorkUnits, consumed);
            }
            if (consumed >= this.#configuration.limits.checkpointWorkUnits) {
              this.check(op);
              op.resume = this.#host.schedule(() => {
                op.resume = void 0;
                this.pump();
              }, 0);
              if (this.#metrics)
                this.#metrics.hostYields++;
              break;
            }
          }
        } catch (error) {
          this.finish(op, void 0, this.error(error));
        } finally {
          op.executing = false;
        }
        if (this.#active === op)
          break;
      }
    } finally {
      this.#pumping = false;
      this.release();
    }
  }
  error(error) {
    return error instanceof RaveldexError ? error : new RaveldexError("INTERNAL_ERROR");
  }
  finish(op, result, failure) {
    if (op.settled)
      return;
    op.settled = true;
    const resolve = op.resolve, reject = op.reject;
    const cursor = op.cursor;
    op.options = void 0;
    op.start = void 0;
    op.cursor = void 0;
    op.resolve = void 0;
    op.reject = void 0;
    if (failure !== void 0) {
      try {
        cursor?.return(void 0);
      } catch {
      }
    }
    for (const cleanup of [op.resume, op.timer, op.detach]) {
      try {
        cleanup?.();
      } catch {
      }
    }
    op.resume = void 0;
    op.timer = void 0;
    op.detach = void 0;
    if (this.#active === op)
      this.#active = void 0;
    else
      this.#queue = this.#queue.filter((item) => item !== op);
    if (failure !== void 0)
      reject(this.error(failure));
    else
      resolve(result);
    this.release();
  }
  dispose() {
    if (this.#disposal)
      return this.#disposal;
    this.#closing = true;
    this.#disposal = new Promise((resolve) => {
      this.#disposed = resolve;
    });
    for (const op of [...this.#queue])
      this.finish(op, void 0, new RaveldexError("DISPOSED"));
    if (this.#active && !this.#active.executing)
      this.finish(this.#active, void 0, new RaveldexError("DISPOSED"));
    this.release();
    return this.#disposal;
  }
  release() {
    if (this.#closing && !this.#active && this.#queue.length === 0) {
      this.#owner = void 0;
      const resolve = this.#disposed;
      this.#disposed = void 0;
      resolve?.();
    }
  }
};
var executionOwners = /* @__PURE__ */ new WeakMap();
function createOwnedRaveldex(captured, host = directHost(), metrics) {
  let owner;
  try {
    const installed = initializeParticipants(captured);
    owner = new ExecutionOwner(emptyRoot(captured, installed.states), host, installed.participants, metrics);
  } catch (error) {
    throw error instanceof RaveldexError ? error : new RaveldexError("INTERNAL_ERROR");
  }
  return facadeFromExecutionOwner(owner);
}
function facadeFromExecutionOwner(owner) {
  const facade = Object.freeze({
    search: owner.search.bind(owner),
    add: owner.add.bind(owner),
    addMany: owner.addMany.bind(owner),
    replace: owner.replace.bind(owner),
    remove: owner.remove.bind(owner),
    clear: owner.clear.bind(owner),
    dispose: owner.dispose.bind(owner)
  });
  executionOwners.set(facade, owner);
  return facade;
}
function createRaveldex(configuration) {
  try {
    return createOwnedRaveldex(captureConfiguration(configuration));
  } catch (error) {
    throw error instanceof RaveldexError ? error : new RaveldexError("INTERNAL_ERROR");
  }
}

// dist/core/capabilities/worker-identity.js
function workerIdentity(family, options) {
  function canonical(value) {
    if (value === null || typeof value !== "object")
      return JSON.stringify(value);
    if (Array.isArray(value))
      return `[${value.map(canonical).join(",")}]`;
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
  }
  return `raveldex:${family}:1:${canonical(options)}`;
}

// dist/addons/metadata/payload.js
function copyPayload(input, admission2, code, maximum) {
  let codeUnits = 0;
  const path = "extensions.payload", ancestors = /* @__PURE__ */ new Set();
  const text2 = (value) => {
    codeUnits += value.length;
    bound(codeUnits, maximum, path);
    return value;
  };
  function copy(value, depth) {
    bound(depth, 16, path);
    if (typeof value === "string")
      return text2(value);
    if (value === null || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value))
      return value;
    if (typeof value !== "object" || value === null || ancestors.has(value))
      invalid(code, path);
    ancestors.add(value);
    let owned;
    if (Array.isArray(value))
      owned = Object.freeze(ownArray(value, admission2.maximum, code, path, admission2).map((item) => copy(item, depth + 1)));
    else {
      const data = ownObject(value, code, path, admission2);
      for (const key of Object.keys(data)) {
        text2(key);
        data[key] = copy(data[key], depth + 1);
      }
      owned = Object.freeze(data);
    }
    ancestors.delete(value);
    return owned;
  }
  return Object.freeze({ value: copy(input, 1), codeUnits });
}
function captureMetadataPayload(input, context, code) {
  return copyPayload(input, context.admission, code, context.maxCodeUnits);
}
function* validatePayload(value, code) {
  yield { workUnits: 1 };
  if (typeof value === "string")
    yield* scanUnicode(value, code, "extensions.payload");
  else if (Array.isArray(value))
    for (const item of value)
      yield* validatePayload(item, code);
  else if (value !== null && typeof value === "object")
    for (const [key, item] of Object.entries(value)) {
      yield* scanUnicode(key, code, "extensions.payload");
      yield* validatePayload(item, code);
    }
}
function* captureMetadataOutput(input, limits) {
  const admission2 = new Admission(limits.maxAdmissionEntries);
  const captured = copyPayload(input, admission2, "INCOMPATIBLE_CAPABILITY", limits.maxAdmissionEntries * limits.maxMetadataStringCodeUnits);
  yield { workUnits: admission2.count + captured.codeUnits };
  yield* validatePayload(captured.value, "INCOMPATIBLE_CAPABILITY");
  return Object.freeze({ value: captured.value, entries: admission2.count });
}

// dist/addons/filters/options.js
function captureFilterOptions(input) {
  const admission2 = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const options = ownObject(input, "INVALID_OPTIONS", "filters.options", admission2);
  keysOnly(options, ["fields", "id", "maxWorkUnits"], "INVALID_OPTIONS", "filters.options");
  const inputs = ownArray(options.fields, DEFAULT_LIMITS.maxMetadataFields, "INVALID_OPTIONS", "filters.fields", admission2);
  if (inputs.length === 0)
    invalid("INVALID_OPTIONS", "filters.fields");
  const seen = /* @__PURE__ */ new Set();
  const fields = Object.freeze(inputs.map((inputField) => {
    const field = stringValue(inputField, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", "filters.fields");
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) || field === "constructor" || field === "prototype" || seen.has(field))
      invalid("INVALID_OPTIONS", "filters.fields");
    seen.add(field);
    return field;
  }));
  const id = has(options, "id") ? stringValue(options.id, 64, "INVALID_OPTIONS", "filters.id") : "filters";
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "filters.id");
  const maxWorkUnits = has(options, "maxWorkUnits") ? options.maxWorkUnits : DEFAULT_LIMITS.maxSearchWorkUnits;
  if (typeof maxWorkUnits !== "number" || !Number.isSafeInteger(maxWorkUnits) || maxWorkUnits < 1)
    invalid("INVALID_OPTIONS", "filters.maxWorkUnits");
  bound(maxWorkUnits, DEFAULT_LIMITS.maxSearchWorkUnits, "filters.maxWorkUnits");
  return Object.freeze({ fields, id, maxWorkUnits });
}

// dist/addons/filters/index.js
var charge = (workUnits) => ({ workUnits });
function* prepareFilter(context, enabled) {
  yield* validatePayload(context.payload, "INVALID_QUERY");
  const admission2 = new Admission(context.limits.maxAdmissionEntries);
  const payload = ownObject(context.payload, "INVALID_QUERY", "filters.payload", admission2);
  yield charge(admission2.count + 1);
  const range = context.capability === "numeric-range";
  if (!range && context.capability !== "set-membership")
    invalid("INCOMPATIBLE_CAPABILITY", "filters.capability");
  keysOnly(payload, range ? ["field", "gt", "gte", "lt", "lte"] : ["field", "values"], "INVALID_QUERY", "filters.payload");
  yield charge(Object.keys(payload).length + 1);
  const field = stringValue(payload.field, context.limits.maxFieldNameCodeUnits, "INVALID_QUERY", "filters.field");
  yield charge(field.length + 1);
  const descriptor = context.schema.metadata[field];
  if (!descriptor)
    invalid("INVALID_QUERY", "filters.field");
  let selected = false;
  for (const allowed of enabled) {
    yield charge(allowed.length + field.length + 1);
    if (allowed === field) {
      selected = true;
      break;
    }
  }
  if (!selected)
    invalid("MISSING_CAPABILITY", "filters.field");
  if (range) {
    if (descriptor.type !== "number")
      invalid("INVALID_QUERY", "filters.field.type");
    const lowerName = has(payload, "gt") ? "gt" : has(payload, "gte") ? "gte" : void 0;
    const upperName = has(payload, "lt") ? "lt" : has(payload, "lte") ? "lte" : void 0;
    yield charge(6);
    if (has(payload, "gt") && has(payload, "gte") || has(payload, "lt") && has(payload, "lte") || !lowerName && !upperName)
      invalid("INVALID_QUERY", "filters.bounds");
    const lower = lowerName ? payload[lowerName] : void 0;
    const upper = upperName ? payload[upperName] : void 0;
    for (const endpoint of [lower, upper]) {
      yield charge(1);
      if (endpoint !== void 0 && (typeof endpoint !== "number" || !Number.isFinite(endpoint)))
        invalid("INVALID_QUERY", "filters.bounds");
    }
    if (lowerName && lower === void 0 || upperName && upper === void 0)
      invalid("INVALID_QUERY", "filters.bounds");
    yield charge(1);
    if (typeof lower === "number" && typeof upper === "number" && lower > upper)
      invalid("INVALID_QUERY", "filters.bounds");
    const lowerBound = lower, upperBound = upper;
    return Object.freeze({
      *test(metadata) {
        yield charge(field.length + 1);
        if (!has(metadata, field))
          return false;
        const value = metadata[field];
        const values2 = Array.isArray(value) ? value : [value];
        for (const item of values2) {
          yield charge(1);
          if (typeof item !== "number")
            continue;
          let matches = true;
          if (lowerBound !== void 0) {
            yield charge(1);
            matches = lowerName === "gt" ? item > lowerBound : item >= lowerBound;
          }
          if (upperBound !== void 0) {
            yield charge(1);
            matches = matches && (upperName === "lt" ? item < upperBound : item <= upperBound);
          }
          if (matches)
            return true;
        }
        return false;
      }
    });
  }
  const values = ownArray(payload.values, Math.min(128, context.limits.maxMetadataValuesPerField), "INVALID_QUERY", "filters.values", admission2);
  yield charge(values.length + 1);
  if (values.length === 0)
    invalid("INVALID_QUERY", "filters.values");
  for (const value of values) {
    yield charge(typeof value === "string" ? value.length + 1 : 1);
    if (value === null) {
      if (!descriptor.nullable)
        invalid("INVALID_QUERY", "filters.values");
    } else if (typeof value !== descriptor.type)
      invalid("INVALID_QUERY", "filters.values");
    else if (typeof value === "number" && !Number.isFinite(value))
      invalid("INVALID_QUERY", "filters.values");
    else if (typeof value === "string")
      bound(value.length, context.limits.maxMetadataStringCodeUnits, "filters.values");
  }
  const requested = Object.freeze(values);
  return Object.freeze({
    *test(metadata) {
      yield charge(field.length + 1);
      if (!has(metadata, field))
        return false;
      const value = metadata[field];
      const actual = Array.isArray(value) ? value : [value];
      for (const item of actual) {
        yield charge(1);
        for (const candidate of requested) {
          yield charge(typeof item === "string" && typeof candidate === "string" ? item.length + candidate.length + 1 : 1);
          if (item === candidate)
            return true;
        }
      }
      return false;
    }
  });
}
function createFilters(options) {
  const captured = captureFilterOptions(options);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["leaf-refinement"]),
      provides: Object.freeze(["numeric-range", "set-membership"].map((id) => Object.freeze({ id, contractVersion: 1 }))),
      requires: Object.freeze([]),
      dataRequirements: Object.freeze({ fields: captured.fields, source: false, positions: false, offsets: false, metadata: true }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("filters", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Typed numeric-range and set-membership metadata predicates.", retainedRepresentation: "No side index or copied metadata; reads the immutable core revision.", transientWork: "Bounded owned payload and complete candidate evaluation under the shared search budget.", externalResources: "none" })
    }),
    predicate: Object.freeze({
      capture: (input, context) => captureMetadataPayload(input, context, "INVALID_QUERY"),
      prepare: (context) => prepareFilter(context, captured.fields)
    })
  });
}

// dist/addons/facets/options.js
function captureFacetOptions(input) {
  const admission2 = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const options = ownObject(input, "INVALID_OPTIONS", "facets.options", admission2);
  keysOnly(options, ["fields", "id", "maxWorkUnits", "maxDistinctValuesPerField", "maxBucketsPerField"], "INVALID_OPTIONS", "facets.options");
  const seen = /* @__PURE__ */ new Set();
  const fields = Object.freeze(ownArray(options.fields, DEFAULT_LIMITS.maxMetadataFields, "INVALID_OPTIONS", "facets.fields", admission2).map((value) => {
    const field = stringValue(value, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", "facets.fields");
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) || field === "constructor" || field === "prototype" || seen.has(field))
      invalid("INVALID_OPTIONS", "facets.fields");
    seen.add(field);
    return field;
  }));
  if (!fields.length)
    invalid("INVALID_OPTIONS", "facets.fields");
  const id = has(options, "id") ? stringValue(options.id, 64, "INVALID_OPTIONS", "facets.id") : "facets";
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "facets.id");
  const integer3 = (key, fallback, maximum, minimum) => {
    const value = has(options, key) ? options[key] : fallback;
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid("INVALID_OPTIONS", `facets.${key}`);
    bound(value, maximum, `facets.${key}`);
    return value;
  };
  return Object.freeze({
    fields,
    id,
    maxWorkUnits: integer3("maxWorkUnits", DEFAULT_LIMITS.maxSearchWorkUnits, DEFAULT_LIMITS.maxSearchWorkUnits, 1),
    maxDistinctValuesPerField: integer3("maxDistinctValuesPerField", 1e4, 1e4, 1),
    maxBucketsPerField: integer3("maxBucketsPerField", 100, 100, 0)
  });
}

// dist/addons/facets/facets.js
var charge2 = (workUnits = 1) => ({ workUnits });
function* compare(a, b) {
  yield charge2();
  if (a.count !== b.count)
    return b.count - a.count;
  if (a.missing !== b.missing)
    return a.missing ? 1 : -1;
  if (a.missing)
    return 0;
  if (a.value === null || b.value === null)
    return a.value === b.value ? 0 : a.value === null ? -1 : 1;
  const left = a.value, right = b.value;
  for (let index = 0; index < Math.min(left.length, right.length); index++) {
    yield charge2();
    const delta = left.charCodeAt(index) - right.charCodeAt(index);
    if (delta)
      return delta;
  }
  yield charge2();
  return left.length - right.length;
}
function* select(heap, bucket, maximum) {
  yield charge2();
  if (!maximum)
    return;
  if (heap.length < maximum) {
    let index = heap.length;
    heap.push(bucket);
    while (index) {
      const parent = Math.floor((index - 1) / 2);
      if ((yield* compare(heap[index], heap[parent])) <= 0)
        break;
      yield charge2();
      [heap[index], heap[parent]] = [heap[parent], heap[index]];
      index = parent;
    }
    return;
  }
  if ((yield* compare(bucket, heap[0])) >= 0)
    return;
  heap[0] = bucket;
  yield charge2();
  for (let index = 0; ; ) {
    const left = index * 2 + 1;
    if (left >= heap.length)
      break;
    const right = left + 1;
    const worst = right < heap.length && (yield* compare(heap[right], heap[left])) > 0 ? right : left;
    if ((yield* compare(heap[index], heap[worst])) >= 0)
      break;
    yield charge2();
    [heap[index], heap[worst]] = [heap[worst], heap[index]];
    index = worst;
  }
}
function* prepare(context, options) {
  yield* validatePayload(context.payload, "INVALID_OPTIONS");
  const admission2 = new Admission(context.limits.maxAdmissionEntries);
  const payload = ownObject(context.payload, "INVALID_OPTIONS", "facets.payload", admission2);
  keysOnly(payload, ["fields"], "INVALID_OPTIONS", "facets.payload");
  const requests = ownArray(payload.fields, 8, "INVALID_OPTIONS", "facets.fields", admission2);
  if (!requests.length)
    invalid("INVALID_OPTIONS", "facets.fields");
  const selected = /* @__PURE__ */ new Set(), counters = [];
  for (const raw of requests) {
    const request = ownObject(raw, "INVALID_OPTIONS", "facets.field", admission2);
    keysOnly(request, ["field", "limit", "missing"], "INVALID_OPTIONS", "facets.field");
    const field = stringValue(request.field, context.limits.maxFieldNameCodeUnits, "INVALID_OPTIONS", "facets.field");
    yield charge2((field.length + 1) * (options.fields.length + 1));
    const declared = context.schema.metadata[field];
    if (!declared || declared.type !== "string")
      invalid("INVALID_OPTIONS", "facets.field");
    if (!options.fields.includes(field))
      invalid("MISSING_CAPABILITY", "facets.field");
    if (selected.has(field))
      invalid("INVALID_OPTIONS", "facets.fields");
    selected.add(field);
    const limit = has(request, "limit") ? request.limit : Math.min(20, options.maxBucketsPerField);
    if (typeof limit !== "number" || !Number.isSafeInteger(limit) || limit < 0)
      invalid("INVALID_OPTIONS", "facets.limit");
    bound(limit, options.maxBucketsPerField, "facets.limit");
    const missing2 = has(request, "missing") ? request.missing : false;
    if (typeof missing2 !== "boolean")
      invalid("INVALID_OPTIONS", "facets.missing");
    counters.push({
      field,
      limit,
      missing: missing2,
      cap: Math.min(options.maxDistinctValuesPerField, context.limits.maxDocuments * (declared.multi ? context.limits.maxMetadataValuesPerField : 1)),
      values: /* @__PURE__ */ new Map()
    });
  }
  return Object.freeze({
    *add(metadata) {
      for (const counter of counters) {
        yield charge2(counter.field.length + 1);
        if (!has(metadata, counter.field)) {
          if (counter.missing) {
            if (!counter.missingBucket) {
              bound(counter.values.size + 1, counter.cap, "facets.distinctValues");
              counter.missingBucket = { missing: true, count: 0 };
            }
            counter.missingBucket.count++;
            yield charge2();
          }
          continue;
        }
        const input = metadata[counter.field], values = Array.isArray(input) ? input : [input];
        const seen = /* @__PURE__ */ new Set();
        for (const raw of values) {
          if (raw !== null && typeof raw !== "string")
            invalid("INCOMPATIBLE_CAPABILITY", "facets.metadata");
          if (raw === null && !context.schema.metadata[counter.field].nullable)
            invalid("INCOMPATIBLE_CAPABILITY", "facets.metadata");
          const value = raw;
          yield charge2((value?.length ?? 0) + 1);
          if (seen.has(value))
            continue;
          seen.add(value);
          yield charge2((value?.length ?? 0) + 1);
          let bucket = counter.values.get(value);
          if (!bucket) {
            bound(counter.values.size + (counter.missingBucket ? 1 : 0) + 1, counter.cap, "facets.distinctValues");
            bucket = { missing: false, value, count: 0 };
            counter.values.set(value, bucket);
          }
          bucket.count++;
          yield charge2();
        }
      }
    },
    *finish() {
      const fields = [];
      for (const counter of counters) {
        const heap = [];
        for (const bucket of counter.values.values())
          yield* select(heap, bucket, counter.limit);
        if (counter.missingBucket)
          yield* select(heap, counter.missingBucket, counter.limit);
        for (let index = 1; index < heap.length; index++) {
          const value = heap[index];
          let target = index;
          while (target && (yield* compare(value, heap[target - 1])) < 0) {
            heap[target] = heap[target - 1];
            target--;
            yield charge2();
          }
          heap[target] = value;
          yield charge2();
        }
        const buckets = [];
        for (const bucket of heap) {
          yield charge2((bucket.value?.length ?? 0) + 4);
          buckets.push(Object.freeze(bucket.missing ? { kind: "missing", count: bucket.count } : { kind: "value", value: bucket.value, count: bucket.count }));
        }
        const total = counter.values.size + (counter.missingBucket ? 1 : 0);
        fields.push(Object.freeze({ field: counter.field, buckets: Object.freeze(buckets), distinctValueTotal: total, omittedBucketCount: total - buckets.length }));
        yield charge2(4);
      }
      return yield* captureMetadataOutput(Object.freeze({ fields: Object.freeze(fields) }), context.limits);
    }
  });
}
function createFacets(options) {
  const captured = captureFacetOptions(options);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["aggregation"]),
      provides: Object.freeze([Object.freeze({ id: "facets", contractVersion: 1 })]),
      requires: Object.freeze([]),
      dataRequirements: Object.freeze({ fields: captured.fields, source: false, positions: false, offsets: false, metadata: true }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("facets", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: 8192 }),
      costs: Object.freeze({
        importedCode: "Typed metadata aggregation, per-document distinct counting and bounded output heap.",
        retainedRepresentation: "No side index or corpus metadata copy; counters exist only during requested aggregation.",
        transientWork: "Complete qualifying documents counted under distinct/work ceilings; at most eight fields and 100 returned buckets per field; comparisons and output projection are resumable.",
        externalResources: "none"
      })
    }),
    aggregation: Object.freeze({
      fieldType: "string",
      capture: (input, context) => captureMetadataPayload(input, context, "INVALID_OPTIONS"),
      prepare: (context) => prepare(context, captured)
    })
  });
}

// dist/addons/ui/directory-controller.js
function createDirectory(options) {
  const captured = captureDirectory(options), config = captured.config;
  if (typeof AbortController !== "function")
    failDirectory("abort", "UNSUPPORTED_ENVIRONMENT");
  let search = captured.search;
  let snapshot = Object.freeze({ status: "idle", change: "initial", state: captureState(config, { text: "", filters: {}, page: 1 }) });
  let ended = false, sequence = 0, active;
  let pending;
  let baseline;
  const listeners = /* @__PURE__ */ new Set();
  const notify = () => {
    const value = snapshot;
    for (const listener of [...listeners]) {
      if (snapshot !== value)
        break;
      if (!listeners.has(listener))
        continue;
      try {
        listener(value);
      } catch {
      }
    }
  };
  function execute(state, change, force = false) {
    if (ended)
      return Promise.resolve();
    const key = stateKey(state);
    if (!force && snapshot.status === "loading" && pending?.key === key)
      return pending.promise;
    if (!force && snapshot.status === "ready" && stateKey(snapshot.state) === key)
      return Promise.resolve();
    const expected = (change === "page" || change === "restore") && baseline?.query === queryKey(state) ? baseline.revision : void 0;
    const old = active, controller2 = new AbortController(), ticket = ++sequence;
    let finish;
    const promise = new Promise((resolve) => {
      finish = resolve;
    });
    const job = { key, promise };
    pending = job;
    active = controller2;
    snapshot = Object.freeze({ status: "loading", state, change });
    const current = () => !ended && sequence === ticket && active === controller2 && !controller2.signal.aborted;
    const stale = (state2) => {
      baseline = void 0;
      job.key = stateKey(state2);
      snapshot = Object.freeze({ status: "stale", state: state2, change: "recovery", error: "REVISION_MISMATCH" });
      notify();
    };
    void Promise.resolve().then(async () => {
      try {
        if (!current() || !search)
          return;
        let selected = state, revision = expected;
        for (let attempt = 0; attempt < 2; attempt++) {
          const offset = (selected.page - 1) * config.pageSize, limit = Math.min(config.pageSize, 1e4 - offset);
          const extensions = config.groups.length ? { facets: { fields: config.groups.map((group) => ({ field: group.field, limit: group.limit, missing: true })) } } : void 0;
          const raw = await search(directoryQuery(config, selected), { offset, limit, signal: controller2.signal, ...extensions ? { extensions } : {} });
          if (!current())
            return;
          const result = capturePage(config, selected, raw, limit, offset);
          if (!current())
            return;
          if (revision !== void 0 && result.revision !== revision) {
            stale(Object.freeze({ ...selected, page: 1 }));
            return;
          }
          if (selected.page > 1 && offset >= result.total) {
            selected = Object.freeze({ ...selected, page: 1 });
            revision = result.revision;
            job.key = stateKey(selected);
            snapshot = Object.freeze({ status: "loading", state: selected, change: "recovery" });
            notify();
            if (!current())
              return;
            continue;
          }
          baseline = { query: queryKey(selected), revision: result.revision };
          snapshot = Object.freeze({ status: "ready", state: selected, change: attempt ? "recovery" : change, result });
          notify();
          return;
        }
      } catch (reason) {
        if (!current())
          return;
        let code = "INTERNAL_ERROR";
        try {
          const descriptor = typeof reason === "object" && reason !== null ? Object.getOwnPropertyDescriptor(reason, "code") : void 0;
          if (descriptor && "value" in descriptor && ERROR_CODES.includes(descriptor.value))
            code = descriptor.value;
        } catch {
        }
        if (!current())
          return;
        baseline = void 0;
        snapshot = Object.freeze({ status: "error", state: snapshot.state, change: snapshot.change, error: code });
        notify();
      } finally {
        if (pending === job)
          pending = void 0;
        if (active === controller2)
          active = void 0;
        finish();
      }
    });
    old?.abort();
    if (current())
      notify();
    return promise;
  }
  const handle = Object.freeze({
    getSnapshot: () => snapshot,
    subscribe: (listener) => {
      if (ended)
        return () => {
        };
      if (typeof listener !== "function")
        failDirectory("listener");
      if (!listeners.has(listener) && listeners.size >= 64)
        failDirectory("listeners", "LIMIT_EXCEEDED");
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    update: (patch) => {
      if (ended)
        return Promise.resolve();
      const data = object(patch, ["text", "filters"], "update");
      const next = captureState(config, {
        text: Object.hasOwn(data, "text") ? data.text : snapshot.state.text,
        filters: Object.hasOwn(data, "filters") ? data.filters : snapshot.state.filters,
        page: 1
      });
      return execute(queryKey(next) === queryKey(snapshot.state) ? snapshot.state : next, "update");
    },
    setPage: (page) => {
      if (ended)
        return Promise.resolve();
      return execute(captureState(config, { ...snapshot.state, page }), "page");
    },
    restore: (state) => ended ? Promise.resolve() : execute(captureState(config, state), "restore"),
    refresh: () => ended ? Promise.resolve() : execute(Object.freeze({ ...snapshot.state, page: 1 }), "refresh", true),
    destroy: () => {
      if (ended)
        return;
      ended = true;
      sequence++;
      search = void 0;
      baseline = void 0;
      pending = void 0;
      const previous = active;
      active = void 0;
      snapshot = Object.freeze({ status: "destroyed", state: snapshot.state, change: "destroy" });
      directoryConfigurations.delete(handle);
      previous?.abort();
      notify();
      listeners.clear();
    }
  });
  directoryConfigurations.set(handle, config);
  return handle;
}

// dist/addons/ui/directory-url.js
var owners = /* @__PURE__ */ new WeakMap();
var connections = /* @__PURE__ */ new WeakMap();
var URLRefusal = class extends Error {
  reason;
  constructor(reason) {
    super("Directory URL refused");
    this.reason = reason;
  }
};
var decode = (value) => decodeURIComponent(value.replaceAll("+", " "));
function location(host) {
  const href = host.location.href;
  if (typeof href !== "string" || href.length > 65536)
    throw new URLRefusal("url-limit");
  const parsed = new URL(href);
  if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password)
    throw new URLRefusal("location-refused");
  const hashIndex = href.indexOf("#"), hash = hashIndex < 0 ? "" : href.slice(hashIndex), main = hashIndex < 0 ? href : href.slice(0, hashIndex);
  const queryIndex = main.indexOf("?"), base = queryIndex < 0 ? main : main.slice(0, queryIndex);
  const raw = queryIndex < 0 ? "" : main.slice(queryIndex + 1);
  const segments = raw ? raw.split("&").map((value) => {
    const at = value.indexOf("="), key = at < 0 ? value : value.slice(0, at);
    let name;
    try {
      name = decode(key);
    } catch {
    }
    return { raw: value, name, encoded: at < 0 ? "" : value.slice(at + 1) };
  }) : [];
  return { href, base, hash, segments };
}
function parameters(input, config) {
  const p = object(input, ["query", "page", "filters"], "url.parameters");
  const source = object(p.filters, config.groups.map((g) => g.field), "url.parameters.filters");
  const names = /* @__PURE__ */ new Set();
  const name = (input2) => {
    const value = text(input2, 64, "url.parameter");
    if (!/^[A-Za-z][A-Za-z0-9_.-]*$/.test(value) || names.has(value))
      failDirectory("url.parameter");
    names.add(value);
    return value;
  };
  const query = name(p.query), page = name(p.page), filters = /* @__PURE__ */ Object.create(null);
  for (const group of config.groups)
    filters[group.field] = name(source[group.field]);
  return Object.freeze({ query, page, filters: Object.freeze(filters) });
}
function readState(parts, config, p, names) {
  const issues = [], issued = /* @__PURE__ */ new Set();
  const issue = (parameter, reason) => {
    const key = parameter + ":" + reason;
    if (!issued.has(key)) {
      issued.add(key);
      issues.push(Object.freeze({ parameter, reason }));
    }
  };
  const entries = parts.segments.filter((s) => s.name !== void 0 && names.has(s.name));
  if (entries.reduce((sum, s) => sum + s.raw.length, 0) > 16384) {
    return { state: captureState(config, { text: "", filters: {}, page: 1 }), issues: Object.freeze([{ parameter: p.query, reason: "limit" }]) };
  }
  const values = (parameter) => entries.filter((s) => s.name === parameter).map((s) => s.encoded);
  let raw = "", page = 1;
  const queries = values(p.query);
  if (queries.length > 1)
    issue(p.query, "duplicate");
  else if (queries.length) {
    try {
      raw = queryText(decode(queries[0]));
    } catch {
      issue(p.query, "invalid");
    }
  }
  const pages = values(p.page);
  if (pages.length > 1)
    issue(p.page, "duplicate");
  else if (pages.length) {
    try {
      const value = decode(pages[0]);
      if (!/^[1-9][0-9]*$/.test(value) || !Number.isSafeInteger(Number(value)) || Number(value) > config.maxPage)
        issue(p.page, "invalid");
      else
        page = Number(value);
    } catch {
      issue(p.page, "invalid");
    }
  }
  const filters = /* @__PURE__ */ Object.create(null);
  for (const group of config.groups) {
    const parameter = p.filters[group.field], selected = /* @__PURE__ */ new Set();
    for (const encoded of values(parameter)) {
      try {
        const value = text(decode(encoded), 1024, "url.value");
        if (!group.values.includes(value)) {
          issue(parameter, "unknown");
          continue;
        }
        if (selected.has(value))
          issue(parameter, "duplicate");
        selected.add(value);
      } catch {
        issue(parameter, "invalid");
      }
    }
    if (selected.size > 16) {
      issue(parameter, "limit");
      selected.clear();
    }
    filters[group.field] = [...selected];
  }
  let state;
  try {
    state = captureState(config, { text: raw, filters, page: issues.length ? 1 : page });
  } catch {
    issue(config.groups.length ? p.filters[config.groups[0].field] : p.query, "limit");
    state = captureState(config, { text: raw, filters: {}, page: 1 });
  }
  return { state, issues: Object.freeze(issues) };
}
function serialize(parts, state, config, p, names) {
  const owned = [];
  const add = (name, value) => {
    owned.push(encodeURIComponent(name) + "=" + encodeURIComponent(value));
  };
  if (state.text.length)
    add(p.query, state.text);
  if (state.page !== 1)
    add(p.page, String(state.page));
  for (const group of config.groups)
    for (const value of state.filters[group.field])
      add(p.filters[group.field], value);
  if (owned.join("&").length > 16384)
    throw new URLRefusal("url-limit");
  const segments = parts.segments.filter((s) => s.name === void 0 || !names.has(s.name)).map((s) => s.raw).concat(owned);
  const result = parts.base + (segments.length ? "?" + segments.join("&") : "") + parts.hash;
  if (result.length > 65536)
    throw new URLRefusal("url-limit");
  return result;
}
function connectDirectoryURL(options) {
  const o = object(options, ["controller", "host", "parameters", "history"], "url.options");
  const controller2 = o.controller, config = directoryConfigurations.get(controller2);
  if (!config || connections.has(controller2))
    failDirectory("url.controller");
  const host = o.host;
  try {
    if (!host || typeof host !== "object" || typeof host.addEventListener !== "function" || typeof host.removeEventListener !== "function" || !host.history || typeof host.history.pushState !== "function" || typeof host.history.replaceState !== "function")
      failDirectory("url.host");
  } catch {
    failDirectory("url.host", "UNSUPPORTED_ENVIRONMENT");
  }
  const p = parameters(o.parameters, config), names = /* @__PURE__ */ new Set([p.query, p.page, ...Object.values(p.filters)]);
  const policy = o.history === void 0 ? "replace" : o.history;
  if (policy !== "push" && policy !== "replace")
    failDirectory("url.history");
  if (directoryConfigurations.get(controller2) !== config || connections.has(controller2))
    failDirectory("url.controller");
  const claimed = owners.get(host) ?? /* @__PURE__ */ new Map();
  if ([...names].some((name) => claimed.has(name)))
    failDirectory("url.ownership");
  let ended = false, epoch = 0, unsubscribe = () => {
  };
  let snapshot = Object.freeze({ status: "connected", issues: Object.freeze([]) });
  let lastState = stateKey(controller2.getSnapshot().state);
  const live = (ticket) => !ended && epoch === ticket && controller2.getSnapshot().status !== "destroyed";
  const error = (ticket, reason, issues = snapshot.issues) => {
    if (live(ticket))
      snapshot = Object.freeze({ status: "error", error: reason, issues });
  };
  function mutate(next, mode, ticket, eligible) {
    const history = host.history, action = history[mode === "push" ? "pushState" : "replaceState"], state = history.state;
    if (live(ticket) && eligible())
      Reflect.apply(action, history, [state, "", next]);
  }
  function writeState(state, mode, keepIssues = false) {
    if (ended || controller2.getSnapshot().status === "destroyed")
      return;
    const ticket = ++epoch, issues = keepIssues ? snapshot.issues : Object.freeze([]);
    let parts, next;
    try {
      parts = location(host);
      next = serialize(parts, state, config, p, names);
    } catch (reason) {
      error(ticket, reason instanceof URLRefusal ? reason.reason : "location-refused", issues);
      return;
    }
    if (!live(ticket))
      return;
    try {
      if (next !== parts.href)
        mutate(next, mode, ticket, () => stateKey(controller2.getSnapshot().state) === stateKey(state));
      if (live(ticket))
        snapshot = Object.freeze({ status: "connected", issues });
    } catch {
      error(ticket, "write-refused", issues);
    }
  }
  const binding = Object.freeze({
    getSnapshot: () => snapshot,
    read: async () => {
      if (ended || controller2.getSnapshot().status === "destroyed")
        return;
      const ticket = ++epoch, before = controller2.getSnapshot();
      let parsed, parts;
      try {
        parts = location(host);
        parsed = readState(parts, config, p, names);
      } catch (reason) {
        error(ticket, reason instanceof URLRefusal ? reason.reason : "location-refused");
        if (live(ticket) && before.status === "idle")
          await controller2.refresh();
        return;
      }
      if (!live(ticket))
        return;
      snapshot = Object.freeze({ status: "connected", issues: parsed.issues });
      try {
        const next = serialize(parts, parsed.state, config, p, names);
        if (live(ticket) && next !== parts.href)
          mutate(next, "replace", ticket, () => controller2.getSnapshot() === before);
      } catch (reason) {
        error(ticket, reason instanceof URLRefusal ? reason.reason : "write-refused", parsed.issues);
      }
      if (!live(ticket) || controller2.getSnapshot() !== before)
        return;
      await controller2.restore(parsed.state);
    },
    write: () => {
      writeState(controller2.getSnapshot().state, "replace");
    },
    destroy: () => {
      if (ended)
        return;
      ended = true;
      epoch++;
      unsubscribe();
      try {
        host.removeEventListener("popstate", onPop);
      } catch {
      }
      for (const name of names)
        if (claimed.get(name) === binding)
          claimed.delete(name);
      if (!claimed.size && owners.get(host) === claimed)
        owners.delete(host);
      if (connections.get(controller2) === binding)
        connections.delete(controller2);
      snapshot = Object.freeze({ status: "destroyed", issues: snapshot.issues });
    }
  });
  const onPop = () => {
    void binding.read();
  };
  for (const name of names)
    claimed.set(name, binding);
  owners.set(host, claimed);
  connections.set(controller2, binding);
  try {
    unsubscribe = controller2.subscribe((value) => {
      if (value.status === "destroyed") {
        binding.destroy();
        return;
      }
      const key = stateKey(value.state);
      if (key === lastState)
        return;
      lastState = key;
      if (value.change !== "restore")
        writeState(value.state, value.change === "update" || value.change === "page" ? policy : "replace", value.change === "recovery");
    });
    host.addEventListener("popstate", onPop);
    if (ended)
      host.removeEventListener("popstate", onPop);
  } catch (reason) {
    binding.destroy();
    if (reason instanceof RaveldexError)
      throw reason;
    failDirectory("url.host", "UNSUPPORTED_ENVIRONMENT");
  }
  return binding;
}

// dist/addons/ui/directory-view.js
function mountRaveldexDirectory(options) {
  return mountDirectoryView(captureDirectoryView(options));
}

// ../../../../../private/tmp/raveldex-family-review-xzxx5var/directory-cards/directory-data.mjs
var schema = { text: { title: {}, body: {} }, metadata: {
  kind: { type: "string", nullable: true },
  tags: { type: "string", multi: true, nullable: true }
} };
var groups = [
  { field: "kind", values: ["guide", "manual", "map", "absent"] },
  { field: "tags", values: ["red", "blue", "green", "", "ghost", "\xE9", "e\u0301"] }
];
var records = [
  { id: "a", text: { title: "Alpha guide", body: "shared trail" }, metadata: { kind: "guide", tags: ["red", "blue"] } },
  { id: "b", text: { title: "Beta manual", body: "shared route" }, metadata: { kind: "manual", tags: ["red"] } },
  { id: "c", text: { title: "Gamma guide", body: "shared trail" }, metadata: { kind: "guide", tags: ["green"] } },
  { id: "d", text: { title: "Delta map", body: "quiet route" }, metadata: { kind: "map", tags: ["blue", "blue"] } },
  { id: "e", text: { title: "Echo guide", body: "shared trail" }, metadata: { kind: "guide", tags: [] } },
  { id: "f", text: { title: "Zeta manual", body: "shared route" }, metadata: { kind: "manual", tags: [null] } },
  { id: "g", text: { title: "Eta", body: "shared" }, metadata: { tags: [""] } },
  { id: "h", text: { title: "Theta", body: "quiet" }, metadata: { kind: null } }
];

// ../../../../../private/tmp/raveldex-family-review-xzxx5var/directory-cards/probe-entry.mjs
window.mountCards = mountRaveldexDirectoryCards;
var root = document.getElementById("directory");
var original = root.firstChild;
var engine = createRaveldex({ schema, addons: [createFilters({ fields: ["kind", "tags"] }), createFacets({ fields: ["kind", "tags"] })] });
await engine.addMany(records);
var labels = [{ field: "kind", label: "Type", values: [{ value: "guide", label: "Guide" }, { value: "manual", label: "Manual" }] }, { field: "tags", label: "Tags" }];
var documents = records.map((r) => ({ id: r.id, title: r.text.title || "Resource " + r.id, url: "/resource/" + r.id + "/" }));
var controller;
var view;
var url;
var held;
var release;
var holdNext = false;
var disposed = 0;
var calls = [];
var snapshots = [];
var borrowed = { ...engine, dispose() {
  disposed++;
  return engine.dispose();
}, search: async (query, options) => {
  calls.push({ query, offset: options.offset, limit: options.limit });
  if (holdNext) {
    holdNext = false;
    const { signal, ...rest } = options;
    const found = await engine.search(query, rest);
    window.directoryHeld = true;
    await held;
    return found;
  }
  return engine.search(query, options);
} };
async function remount(options = {}) {
  url?.destroy();
  view?.destroy();
  controller?.destroy();
  controller = createDirectory({
    engine: options.missing ? { ...borrowed, search: (q, o) => missing.search(q, o) } : borrowed,
    groups: (options.groups ?? groups).map((g) => ({ ...g, ...options.limit !== void 0 ? { limit: options.limit } : {} })),
    pageSize: 2
  });
  controller.subscribe((snapshot) => snapshots.push({ status: snapshot.status, state: snapshot.state }));
  view = mountRaveldexDirectory({ root, controller, documents, groups: labels, debounceMs: 15, ...options.view });
  if (options.url) {
    url = connectDirectoryURL({ controller, host: window, parameters: { query: "q", page: "page", filters: { kind: "kind", tags: "tag" } }, history: "push" });
    await url.read();
  } else await controller.refresh();
}
var missing = createRaveldex({ schema });
await missing.addMany(records);
window.directoryView = {
  engine,
  root,
  original,
  documents,
  labels,
  calls,
  snapshots,
  mountRaveldexDirectory,
  createDirectory,
  controller: () => controller,
  view: () => view,
  url: () => url,
  remount,
  disposed: () => disposed,
  hold() {
    holdNext = true;
    window.directoryHeld = false;
    held = new Promise((resolve) => {
      release = resolve;
    });
  },
  release() {
    release?.();
  },
  mutate() {
    return engine.replace({ ...records[0], text: { title: "shared revised trail", body: "shared trail" } });
  },
  async cleanup() {
    release?.();
    url?.destroy();
    view?.destroy();
    controller?.destroy();
    await missing.dispose();
    await engine.dispose();
  }
};
await remount();
window.directoryReady = true;
