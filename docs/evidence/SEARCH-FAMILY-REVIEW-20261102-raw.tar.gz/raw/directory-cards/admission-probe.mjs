import { readFile,writeFile,copyFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { build } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/esbuild/lib/main.js';
import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
const repo='/Users/vasilis/Documents/GitHub/raveldex',dir='/private/tmp/raveldex-family-review-xzxx5var/directory-cards';
await writeFile(dir+'/probe-entry.mjs',`import { mountRaveldexDirectoryCards } from '@vmitsaras/raveldex/addons/ui/directory/cards'; window.mountCards = mountRaveldexDirectoryCards;
`+await readFile(repo+'/test/ui/directory-view-fixture.mjs','utf8'));await copyFile(repo+'/test/fixtures/directory.mjs',dir+'/directory-data.mjs');
await build({entryPoints:[dir+'/probe-entry.mjs'],outfile:dir+'/probe-bundle.mjs',bundle:true,platform:'browser',format:'esm',target:'es2022',alias:{'@vmitsaras/raveldex':repo+'/dist/index.js','@vmitsaras/raveldex/addons/filters':repo+'/dist/addons/filters/index.js','@vmitsaras/raveldex/addons/facets':repo+'/dist/addons/facets/index.js','@vmitsaras/raveldex/addons/ui/directory':repo+'/dist/addons/ui/directory.js','@vmitsaras/raveldex/addons/ui/directory/view':repo+'/dist/addons/ui/directory-view.js','@vmitsaras/raveldex/addons/ui/directory/cards':repo+'/dist/addons/ui/directory-cards.js'},logLevel:'silent'});
const server=createServer(async(req,res)=>{res.setHeader('content-type',req.url==='/probe.mjs'?'text/javascript':'text/html');res.end(req.url==='/probe.mjs'?await readFile(dir+'/probe-bundle.mjs'):'<!doctype html><html lang=en><title>Focus probe</title><main><h1>Directory</h1><section id=directory><p>Authored</p></section></main><script type=module src=/probe.mjs></script></html>');});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({channel:'chrome',headless:true}),page=await browser.newPage(),origin=`http://127.0.0.1:${server.address().port}`;page.setDefaultTimeout(10000);const observations=[];
try{
 await page.goto(origin);await page.waitForFunction(()=>window.directoryReady);
 const result=await page.evaluate(()=>{
  const f=window.directoryView,root=document.createElement('section'),original=document.createElement('p');original.textContent='Authored fallback';root.append(original);document.body.append(root);
  const controller=f.createDirectory({engine:f.engine});let handle,error;
  try{handle=window.mountCards({root,controller,documents:f.documents,groups:[],presentation:new Proxy({images:false},{ownKeys(target){controller.destroy();return Reflect.ownKeys(target);}})});}catch(reason){error=reason.code;}
  const result={error:error??null,controller:controller.getSnapshot().status,authoredPreserved:root.firstChild===original,mounted:!!root.querySelector('.raveldex-directory'),presentation:root.querySelector('.raveldex-directory')?.dataset.state};handle?.destroy();root.remove();return result;
 }); observations.push(result);
 await writeFile(dir+'/admission-probe.json',JSON.stringify({browser:browser.version(),observations},null,2)+'\n');console.log(JSON.stringify({browser:browser.version(),observations},null,2));
}finally{await page.evaluate(()=>window.directoryView?.cleanup());await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));}
