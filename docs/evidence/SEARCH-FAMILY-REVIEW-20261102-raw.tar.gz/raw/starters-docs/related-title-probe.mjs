import { cp,mkdir,symlink,readFile,writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
const root='/Users/vasilis/Documents/GitHub/raveldex', base='/private/tmp/raveldex-family-review-xzxx5var/starters-docs', results=[];
for(const name of ['dropdown-browser','modal-browser']) {
 const dir=base+'/'+name+'-blank-title';await mkdir(dir,{recursive:true});await cp(root+'/examples/'+name,dir,{recursive:true});await symlink('/private/var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-Pdxp0x/browser-root/node_modules',dir+'/node_modules').catch(e=>{if(e.code!=='EEXIST')throw e;});
 const entries=JSON.parse(await readFile(dir+'/content.json','utf8'));entries[0].title=' \t ';await writeFile(dir+'/content.json',JSON.stringify(entries));
 const built=spawnSync(process.execPath,['build.mjs'],{cwd:dir,encoding:'utf8'});const html=built.status===0?await readFile(dir+'/dist/index.html','utf8'):'';
 const emptyLink=[...html.matchAll(/<a\b[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g)].filter(x=>!x[2].trim()).map(x=>({href:x[1],text:x[2]}));
 results.push({name,buildExitCode:built.status,stdout:built.stdout,stderr:built.stderr,emptyLink,scope:'copied current starter source, reused retained installed runtime/tooling symlink for focused build-only probe; not fresh install qualification'});
}
await writeFile(base+'/related-title-before.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));
