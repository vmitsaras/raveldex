import pathlib,json,tarfile,gzip,io,hashlib
root=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex');task=pathlib.Path('/private/tmp/raveldex-family-review-xzxx5var');e=root/'docs/evidence';v=json.loads((task/'verification.json').read_text());assert v['finalPublicProjection']['status']=='Pass';assert v['fullCheck']['status']=='Pass'
files={};allowed={'.json','.log','.mjs','.ts','.txt','.py','.png'}
for p in task.rglob('*'):
 parts=p.relative_to(task).parts
 if p.is_file() and not p.is_symlink() and len(parts)<=3 and p.suffix in allowed and not any(x in {'node_modules','dist','jekyll-output'} or x.startswith('raveldex-') for x in parts[:-1]):files['raw/'+str(p.relative_to(task))]=p
for name in v['sourceSHA256']:files['qualified-source/'+name]=root/name
for name in ['PROJECT_CONTEXT.md','CODEX_HANDOFF.md','docs/specs/SEARCH_SOLUTIONS.md','docs/specs/DROPDOWN.md','docs/specs/DIRECTORY_VIEW.md','docs/evidence/SEARCH-FAMILY-REVIEW-20261102.md','docs/_pages-manifest.json']:
 files['qualified-source/'+name]=root/name
packages={}
for candidatePath in [pathlib.Path(v['finalCandidate']['report']),pathlib.Path(json.loads((root/'docs/evidence/RX-7006-verification.json').read_text())['candidate']['candidateReport'])]:
 if candidatePath.exists():
  c=json.loads(candidatePath.read_text());p=pathlib.Path(c['package']['tarball']);h=hashlib.sha256(p.read_bytes()).hexdigest();assert h==c['package']['sha256'];packages[h]=p
for h,p in packages.items():files['private-packages/'+h+'-'+p.name]=p
manifest={'scope':'Curated original/fixed/final review logs, reports, scripts, screenshots, task-start hashes and qualified source. Full suite precedes late static fixes, which have focused final checks. No dependency trees, caches or Git data.','files':{name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(files.items())}}
mb=(json.dumps(manifest,indent=2)+'\n').encode();outpath=e/'SEARCH-FAMILY-REVIEW-20261102-raw.tar.gz'
with outpath.open('wb') as stream:
 with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,p in sorted(files.items()):
    meta=tar.gettarinfo(str(p),arcname=name);meta.uid=meta.gid=0;meta.uname=meta.gname=''
    with p.open('rb') as f:tar.addfile(meta,f)
   meta=tarfile.TarInfo('manifest.json');meta.size=len(mb);tar.addfile(meta,io.BytesIO(mb))
with tarfile.open(outpath,'r:gz') as tar:
 assert json.loads(tar.extractfile('manifest.json').read())==manifest
 for name,meta in manifest['files'].items():
  data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256'],name
v['rawArchive']={'path':str(outpath.relative_to(root)),'bytes':outpath.stat().st_size,'sha256':hashlib.sha256(outpath.read_bytes()).hexdigest(),'members':len(files)+1,'payloadHashesAndManifestReadback':'Pass','privatePackageSHA256':sorted(packages)};(task/'verification.json').write_text(json.dumps(v,indent=2)+'\n');(e/'SEARCH-FAMILY-REVIEW-20261102.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v['rawArchive']))
