import pathlib,json,hashlib,tarfile,re
root=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex');task=pathlib.Path('/private/tmp/raveldex-family-review-xzxx5var');sha=lambda b:hashlib.sha256(b).hexdigest(); d=json.loads((task/'verification.json').read_text())
m=json.loads((root/'docs/_pages-manifest.json').read_text());expected={x['path']:x for x in m['files'] if x['path']!='_config.yml'};actual={str(p.relative_to(task/'jekyll-output')):p for p in (task/'jekyll-output').rglob('*') if p.is_file()};assert actual.keys()==expected.keys(),(actual.keys()-expected.keys(),expected.keys()-actual.keys())
for n,p in actual.items():assert p.stat().st_size==expected[n]['bytes'] and sha(p.read_bytes())==expected[n]['sha256'],n
d['finalPublicProjection']={'status':'Pass','command':'npm run pages:generate','exitCode':0,'pages':88,'links':979,'publicFiles':len(expected),'publicBytes':sum(x['bytes'] for x in expected.values()),'managedFiles':len(m['files']),'managedBytes':sum(x['bytes'] for x in m['files']),'manifestSHA256':sha((root/'docs/_pages-manifest.json').read_bytes()),'packageSHA256':'b20d93f91641a9d3c54eda10477cbc93f97fa9156ad03ee7198e67ba55b8e7cc','safeJekyll':{'status':'Pass','files':len(actual),'comparison':'Exact path/size/SHA256 equality; no extra/missing public output.'},'focusedGallery':{'status':'Pass','tests':1,'pass':1,'fail':0,'scope':'All five named focusable code regions, exact eight project inventories and native result/CSS/route/image behavior.'}}
for engine in ['chrome','webkit']:
 x=json.loads((task/f'gallery-audit-{engine}.json').read_text());assert x['status']=='Pass';assert len(x['observations'])==26;assert all(not o['violations'] and o['width']['scroll']<=o['width']['viewport'] for o in x['observations'])
 d.setdefault('finalAutomatedAccessibility',{})[engine]={'status':'Pass','browser':x['browser'],'observations':26,'violations':0,'horizontalOverflow':0,'incompleteRules':sorted(set(v['id'] for o in x['observations'] for v in o['incomplete'])),'scope':x['scope']}
reports=sorted(pathlib.Path('/private/var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T').glob('raveldex-candidate-*/candidate-report.json'),key=lambda p:p.stat().st_mtime);c=json.loads(reports[-1].read_text());assert c['status']=='Pass';assert c['package']['sha256']==d['finalPublicProjection']['packageSHA256'];count=0
with tarfile.open(c['package']['tarball'],'r:gz') as tar:
 for item in tar.getmembers():
  if item.isfile() and item.name.startswith('package/dist/'):
   assert tar.extractfile(item).read()==(root/item.name.removeprefix('package/')).read_bytes(),item.name;count+=1
assert count==337,count
d['finalCandidate']={'status':'Pass','report':str(reports[-1]),'packageSHA256':c['package']['sha256'],'compiledPackageFilesByteEqualToCurrentDist':count,'scope':'Private candidate from passing full check; same exact core package used by final Pages generation. Later gallery/skip changes are outside the core package.'};(task/'candidate-report.json').write_bytes(reports[-1].read_bytes())
before=json.loads((task/'baseline-hashes.json').read_text());changed=[]
for n,h in before.items():
 p=root/n;assert p.is_file(),n
 if sha(p.read_bytes())!=h:changed.append(n)
assert (root/'docs/planning/roadmap.json').read_bytes()==(task/'roadmap-before.json').read_bytes()
assert not any(n.startswith(('src/core/','src/adapters/','src/integrations/','integrations/','docs/evidence/')) or n in ['package.json','package-lock.json'] for n in changed)
assert set(n for n in changed if n.startswith('src/'))=={'src/addons/ui/inline.ts','src/addons/ui/dropdown.ts','src/addons/ui/directory-view-mount.ts','src/addons/ui/directory-cards-options.ts'}
d['scopeAudit']={'status':'Pass','baselinePaths':len(before),'unchanged':len(before)-len(changed),'changed':changed,'missing':[],'canonicalRoadmapByteIdentical':True,'allPriorEvidenceByteIdentical':True,'coreProvidersAdaptersIntegrationsPackageLockByteIdentical':True,'productionChanges':['src/addons/ui/inline.ts','src/addons/ui/dropdown.ts','src/addons/ui/directory-view-mount.ts','src/addons/ui/directory-cards-options.ts']}
names=[n for n in changed if n.startswith(('src/','examples/','test/','site/'))]+['test/ui/inline-shadow-focus.test.mjs','test/ui/directory-focus.test.mjs','test/ui/directory-focus-fixture.mjs'];d['sourceSHA256']={n:sha((root/n).read_bytes()) for n in names};(task/'verification.json').write_text(json.dumps(d,indent=2)+'\n'); print(json.dumps({'Jekyll':len(actual),'compiledPackageFiles':count,'baselinePreserved':len(before),'baselineChanged':len(changed),'manifestSHA256':d['finalPublicProjection']['manifestSHA256']}))
