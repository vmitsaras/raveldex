from pathlib import Path
import hashlib,json,re,tarfile

root=Path('/Users/vasilis/Documents/GitHub/raveldex');stage=Path('/tmp/raveldex-natural-docs-20261030')
baseline=json.loads((stage/'before.json').read_text())
digest=lambda data:hashlib.sha256(data).hexdigest()
blocks=[];changed=[]
for name,meta in baseline['public'].items():
    text=(root/name).read_text()
    fences=re.findall(r'^```[^\n]*\n.*?^```[ \t]*$',text,re.M|re.S)
    assert fences==meta['fences'],name
    assert all(h in re.findall(r'^#{1,6} .+$',text,re.M) for h in meta['headings']),name
    if digest(text.encode())!=meta['sha256']:changed.append(name)
    for i,match in enumerate(re.finditer(r'^```[^\n]*\n.*?^```[ \t]*$',text,re.M|re.S)):
        blocks.append({'path':name,'block':i+1,'sha256':digest(match[0].encode()),
          'before':text[:match.start()].strip().split('\n\n')[-1],
          'after':text[match.end():].strip().split('\n\n')[0]})
for name,meta in baseline['protected'].items():
    p=root/name;stat=p.stat()
    assert stat.st_size==meta['size'] and stat.st_mtime_ns==meta['mtime_ns'],name
    if 'sha256' in meta: assert digest(p.read_bytes())==meta['sha256'],name
for name,expected in baseline['fixed'].items():
    if name in ['integrations/astro/README.md','integrations/languages/english/README.md']:continue
    assert digest((root/name).read_bytes())==expected,name
with tarfile.open(stage/'before-public.tar.gz') as archive:
    before=archive.extractfile('examples/docs-search/index.html').read().decode()
    after=(root/'examples/docs-search/index.html').read_text()
    assert re.findall(r'<pre>[\s\S]*?</pre>',before)==re.findall(r'<pre>[\s\S]*?</pre>',after)
    old_manifest=json.loads(archive.extractfile('generated-docs/_pages-manifest.json').read())
    for item in old_manifest['inputs']:
        if item['path'] in baseline['public']:continue
        assert digest((root/item['path']).read_bytes())==item['sha256'],item['path']
manifest=json.loads((root/'docs/_pages-manifest.json').read_text())
assert {x['path'] for x in manifest['files']}=={x['path'] for x in old_manifest['files']}
assert (root/'docs/_pages-manifest.json').read_bytes()==(stage/'first-manifest.json').read_bytes()
public={x['path']:x for x in manifest['files'] if x['path']!='_config.yml'}
jekyll={p.relative_to(stage/'jekyll-output').as_posix():p for p in (stage/'jekyll-output').rglob('*') if p.is_file()}
assert set(public)==set(jekyll)
for name,p in jekyll.items():assert digest(p.read_bytes())==public[name]['sha256'],name
packages=[]
for label,new,old in [
 ('core',stage/'candidate-local/vmitsaras-raveldex-0.1.0-rc.0.tgz',Path('/tmp/raveldex-usage-docs-20261030/closed-core/vmitsaras-raveldex-0.1.0-rc.0.tgz')),
 ('english',stage/'source-artifacts/english/vmitsaras-raveldex-english-0.1.0-rc.0.tgz',Path('/tmp/raveldex-usage-docs-20261030/source-artifacts/english/vmitsaras-raveldex-english-0.1.0-rc.0.tgz')),
 ('astro',stage/'source-artifacts/astro/vmitsaras-raveldex-astro-0.1.0-rc.0.tgz',Path('/tmp/raveldex-usage-docs-20261030/source-artifacts/astro/vmitsaras-raveldex-astro-0.1.0-rc.0.tgz'))]:
    with tarfile.open(new) as a,tarfile.open(old) as b:
        aa={x.name:a.extractfile(x).read() for x in a if x.isfile()};bb={x.name:b.extractfile(x).read() for x in b if x.isfile()}
        assert set(aa)==set(bb),label
        production={k:v for k,v in aa.items() if k.startswith('package/dist/')}
        assert production=={k:v for k,v in bb.items() if k.startswith('package/dist/')},label
        assert aa['package/package.json']==bb['package/package.json'],label
        for name,contents in aa.items():
            if name.endswith('.mjs'):assert contents==bb[name],name
            if name.endswith('.md'):
                source=root/name.removeprefix('package/') if label=='core' else root/('integrations/astro/README.md' if label=='astro' else 'integrations/languages/english/README.md')
                assert source.read_bytes()==contents,(label,name)
        meta=json.loads(aa['package/package.json']);assert meta['version']=='0.1.0-rc.0' and meta['private']
        packages.append({'name':label,'private':True,'version':meta['version'],'members':len(aa),
          'productionMembersUnchanged':len(production),'bytes':new.stat().st_size,'sha256':digest(new.read_bytes())})
report={'status':'Pass','publicSourcesChanged':changed,'existingHeadingsPreserved':True,
 'markdownCodeBlocksUnchanged':len(blocks),'demoCodeBlocksUnchanged':2,
 'protectedRecordsUnchanged':len(baseline['protected']),'fixedSourceMetadataAndTestsUnchanged':True,
 'sourceSnapshotsMatchCurrentPackages':True,'packageComparisons':packages,
 'htmlPages':sum(name.endswith('.html') for name in public),'publicFiles':len(public),
 'publicBytes':sum(p.stat().st_size for p in jekyll.values()),'deterministicOutput':True,
 'jekyllExactInventoryAndBytes':True,'routeInventoryUnchanged':True,
 'manifestSha256':digest((root/'docs/_pages-manifest.json').read_bytes()),
 'usageCorpus':json.loads((root/'docs/demo/corpus.json').read_text())['hash'],
 'codeContextReview':blocks}
(stage/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['codeContextReview','publicSourcesChanged']}))
