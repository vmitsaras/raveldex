import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const [repo, stage] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(repo, 'node_modules/playwright-core/index.mjs')));
const url = /Open (http:\/\/[^ ]+)/.exec(await fs.readFile(path.join(stage, 'preview.log'), 'utf8'))[1];
const report = { status: 'Fail', observations: [], errors: [], scope: 'Automated viewport and DOM scroll/focus checks, not physical browser zoom or human AT.' };
let browser;
try {
  browser = await chromium.launch({ channel: 'chrome', headless: true });
  report.browser = browser.version();
  const page = await browser.newPage();
  for (const width of [320, 390, 768, 1024, 1280]) {
    await page.setViewportSize({ width, height: 900 });
    for (const [route, selector] of [['guide/overview/', 'pre'], ['reference/', 'table']]) {
      await page.goto(new URL(route, url).href);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true);
      const element = page.locator(selector).first();
      await element.scrollIntoViewIfNeeded();
      const observed = await element.evaluate(node => {
        const before = node.scrollLeft;
        node.scrollLeft = node.scrollWidth;
        return { width: node.clientWidth, scrollWidth: node.scrollWidth, before, after: node.scrollLeft,
          overflowX: getComputedStyle(node).overflowX, pageScrollX: window.scrollX };
      });
      if (observed.scrollWidth > observed.width) {
        assert.ok(observed.after > 0);
        assert.ok(['auto', 'scroll'].includes(observed.overflowX));
      }
      assert.equal(observed.pageScrollX, 0);
      report.observations.push({ width, route, selector, status: 'Pass', ...observed });
      if (width === 320) await page.screenshot({ path: path.join(stage, selector === 'pre' ? 'code-320.png' : 'table-320.png') });
    }
  }
  await page.setViewportSize({ width: 390, height: 900 });
  await page.goto(new URL('demo/', url).href);
  await page.waitForFunction(() => document.querySelector('[data-pilot-search]')?.dataset.pilotState === 'ready');
  await page.locator('[data-raveldex-input]').fill('module worker');
  await page.locator('[data-raveldex-input]').press('Enter');
  await page.waitForFunction(() => document.querySelector('[data-raveldex-status]')?.textContent === '1 results. Showing 1–1.');
  assert.equal(await page.locator('[data-raveldex-input]').evaluate(node => node === document.activeElement), true);
  const focus = await page.locator('[data-raveldex-input]').evaluate(node => {
    const css = getComputedStyle(node); return { outlineStyle: css.outlineStyle, outlineWidth: css.outlineWidth };
  });
  assert.notEqual(focus.outlineStyle, 'none'); assert.ok(parseFloat(focus.outlineWidth) > 0);
  await page.locator('[data-raveldex-input]').scrollIntoViewIfNeeded();
  await page.screenshot({ path: path.join(stage, 'demo-390.png') });
  report.observations.push({ name: '390px sample search, retained input focus and visible outline', status: 'Pass', focus });
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto(url);
  await page.screenshot({ path: path.join(stage, 'home-1280.png') });
  report.status = 'Pass';
} catch (error) { report.errors.push({ message: error.message, stack: error.stack }); throw error; }
finally {
  await browser?.close();
  await fs.writeFile(path.join(stage, 'layout.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ status: report.status, observations: report.observations.length, errors: report.errors }));
}
