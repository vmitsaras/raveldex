from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
root=Path('/Users/vasilis/Documents/GitHub/raveldex');stage=Path('/tmp/raveldex-natural-docs-20261030')
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda name:json.loads((stage/name).read_text())
audit=read('audit.json');assert audit['status']=='Pass'
preparation=read('candidate-local/preparation.json');assert preparation['status']=='Pass'
project=(stage/'candidate-local/verification.log').read_text()
counts=[int(x) for x in re.findall(r'(?:ℹ|#) tests (\d+)',project)]
assert sum(counts)==868 and re.findall(r'(?:ℹ|#) fail (\d+)',project)==['0']*6
for name in ['follow','blocks','astro-snippets','pages-browser','layout','safari']:
    assert read(name+'.json')['status']=='Pass',name
assert read('qualification-corpus.json')['hash']=='267ec0eeb44c09bb3e24cf8a8e71cd90a73441d16f406a891c73f8f8603fdded'
summary={'kind':'raveldex-natural-docs-verification-v1','date':'2026-10-30','status':'Pass',
 'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'workingTree':'Uncommitted documentation changes over pre-existing uncommitted documentation and site work.',
 'publicContractsChanged':False,'publicationPerformed':False,'remoteWritesPerformed':False,
 'projectTests':{'passed':sum(counts),'batches':counts,'failures':0,'cancelled':0,'skipped':0,'todo':0},
 'siteBrowserTests':{'passed':2,'failures':0},
 'commands':[
  'npm ci --offline --cache /tmp/raveldex-docs-npm-cache',
  'npm run candidate:prepare -- --output /tmp/raveldex-natural-docs-20261030/candidate-local',
  'node /tmp/raveldex-natural-docs-20261030/follow.mjs REPOSITORY STAGE',
  'node /tmp/raveldex-natural-docs-20261030/blocks.mjs REPOSITORY STAGE',
  'node /tmp/raveldex-natural-docs-20261030/astro-snippets.mjs REPOSITORY STAGE',
  'npm run pages:generate (twice)',
  'npm run pages:check',
  'RAVELDEX_PAGES_REPORT=STAGE/pages-browser.json node --test --test-concurrency=1 test/pages/browser.test.mjs test/pages/ui-example.test.mjs',
  'GEM_HOME=/tmp/raveldex-pages-20261030/gems GEM_PATH=/tmp/raveldex-pages-20261030/gems GEM_SPEC_CACHE=/tmp/raveldex-pages-20261030/gem-spec-cache ruby /tmp/raveldex-pages-20261030/gems/bin/jekyll build --safe --source REPOSITORY/docs --destination STAGE/jekyll-output',
  'node /tmp/raveldex-natural-docs-20261030/layout.mjs REPOSITORY STAGE',
  'python3 /tmp/raveldex-natural-docs-20261030/audit.py'],
 'audit':{k:v for k,v in audit.items() if k!='codeContextReview'},
 'environmentFailures':[
  {'action':'Initial npm ci with an empty task cache','category':'Environment','result':'ENOTFOUND registry.npmjs.org','resolution':'Locked offline cache; dependency installation passed.'},
  {'action':'Initial candidate preparation in sandbox','category':'Environment','result':'Two browser servers could not bind 127.0.0.1: EPERM. No candidate packed.','resolution':'Complete unchanged suite passed with loopback permission.'}],
 'limitations':['Local verification only; no hosted Pages or remote CI for the uncommitted bytes.',
  'Viewport emulation, native browser zoom and human AT remain separate scopes.',
  'Native Safari was agent-operated; no new human screen-reader or physical-input observations.',
  'Offline audit metadata is not a current registry security assessment.']}
entries={}
def add(name,p):
    assert name not in entries,name
    entries[name]=p.read_bytes()
for p in stage.iterdir():
    if p.is_file() and (p.suffix in ['.json','.log','.mjs','.py','.patch','.txt','.png'] or p.name=='before-public.tar.gz'):
        add('verification/'+p.name,p)
for directory in ['candidate','candidate-local','source-artifacts/english','source-artifacts/astro']:
    for p in (stage/directory).iterdir():
        if p.is_file():add('verification/'+directory+'/'+p.name,p)
for name in read('before.json')['public']:
    add('source-current/'+name,root/name)
for p in (root/'docs/api/examples').glob('*.mjs'):add('source-current/docs/api/examples/'+p.name,p)
add('source-current/docs/_pages-manifest.json',root/'docs/_pages-manifest.json')
for p in (stage/'jekyll-output').rglob('*'):
    if p.is_file():add('jekyll-output/'+p.relative_to(stage/'jekyll-output').as_posix(),p)
for label,p in [
 ('core',Path('/tmp/raveldex-usage-docs-20261030/closed-core/vmitsaras-raveldex-0.1.0-rc.0.tgz')),
 ('english',Path('/tmp/raveldex-usage-docs-20261030/source-artifacts/english/vmitsaras-raveldex-english-0.1.0-rc.0.tgz')),
 ('astro',Path('/tmp/raveldex-usage-docs-20261030/source-artifacts/astro/vmitsaras-raveldex-astro-0.1.0-rc.0.tgz'))]:add('comparison-baseline/'+label+'.tgz',p)
entries['SUMMARY.json']=(json.dumps(summary,indent=2)+'\n').encode()
inventory=[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]
entries['INVENTORY.json']=(json.dumps(inventory,indent=2)+'\n').encode()
destination=root/'docs/evidence/NATURAL-DOCS-20261030-raw.tar.gz'
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
    for name,data in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        archive.addfile(info,io.BytesIO(data))
data=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
    assert len(archive.getmembers())==len(entries)
    for member in archive:assert archive.extractfile(member).read()==entries[member.name],member.name
with destination.open('xb') as f:f.write(data)
summary['archive']={'path':str(destination.relative_to(root)),'bytes':len(data),'members':len(entries),'sha256':sha(data),'memberIntegrity':'Pass'}
summary['codeContextReview']={'markdownBlocks':43,'htmlBlocks':2,'unchanged':True,'details':'verification/audit.json inside the raw archive.'}
with (root/'docs/evidence/NATURAL-DOCS-20261030.json').open('x') as f:f.write(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
