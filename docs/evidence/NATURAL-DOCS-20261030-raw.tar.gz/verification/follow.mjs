import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { pathToFileURL } from 'node:url';
const exec = promisify(execFile), [repo, stage] = process.argv.slice(2);
const env = { ...process.env, npm_config_cache: '/tmp/raveldex-docs-npm-cache', npm_config_offline: 'true', ASTRO_TELEMETRY_DISABLED: '1' };
const read = name => fs.readFile(path.join(repo, name), 'utf8');
const fences = (text, language) => [...text.matchAll(new RegExp('```' + language + '\\n([\\s\\S]*?)\\n```', 'g'))].map(item => item[1]);
const commands = [], observations = [], errors = [];
async function run(command, cwd = repo) {
  const row = { command, cwd }; commands.push(row);
  try { const result = await exec('/bin/bash', ['-c', command], { cwd, env, timeout: 180_000, maxBuffer: 8 * 1024 * 1024 }); Object.assign(row, { exitCode: 0, ...result }); return result; }
  catch (error) { Object.assign(row, { exitCode: error.code, stdout: error.stdout, stderr: error.stderr }); throw error; }
}
let browser;
try {
  const guide = await read('docs/api/GETTING_STARTED.md');
  const build = fences(guide, 'sh')[1];
  const result = await run(build + '\nprintf "\\nARTIFACTS_RESULT=%s\\n" "$RAVELDEX_ARTIFACTS"');
  env.RAVELDEX_REPOSITORY = repo;
  env.RAVELDEX_ARTIFACTS = /ARTIFACTS_RESULT=(.+)/.exec(result.stdout)[1];
  observations.push({ name: 'Exact source-checkout build/pack commands', artifacts: env.RAVELDEX_ARTIFACTS });
  const app = await fs.mkdtemp(path.join(stage, 'app-'));
  const install = fences(guide, 'sh')[0].replace('/absolute/artifacts', env.RAVELDEX_ARTIFACTS);
  await run(install, app);
  await fs.writeFile(path.join(app, 'first.mjs'), fences(guide, 'js')[0]);
  assert.match((await run('node first.mjs', app)).stdout, /1\s+guide:updates/);
  const root = await read('README.md');
  const exactRoot = /<!-- candidate-example: quick-start -->\n```js\n([\s\S]*?)\n```/.exec(root)[1];
  await fs.writeFile(path.join(app, 'quick.mjs'), exactRoot);
  assert.match((await run('node quick.mjs', app)).stdout, /guide:updates/);
  observations.push({ name: 'Exact getting-started and README examples from fresh core install', status: 'Pass' });
  const english = await read('integrations/languages/english/README.md');
  await run(fences(english, 'sh')[0].replaceAll('/absolute/artifacts', env.RAVELDEX_ARTIFACTS), app);
  await fs.writeFile(path.join(app, 'english.mjs'), fences(english, 'js')[0]);
  assert.match((await run('node english.mjs', app)).stdout, /guide/);
  observations.push({ name: 'Exact separate English example', status: 'Pass' });
  const astro = fences(await read('examples/astro/README.md'), 'sh'); assert.equal(astro.length, 4);
  const setup = await run(astro[0] + '\nprintf "\\nEXAMPLE_RESULT=%s\\n" "$RAVELDEX_EXAMPLE"');
  env.RAVELDEX_EXAMPLE = /EXAMPLE_RESULT=(.+)/.exec(setup.stdout)[1];
  const { chromium } = await import(pathToFileURL(path.join(repo, 'node_modules/playwright-core/index.mjs')));
  browser = await chromium.launch({ channel: 'chrome', headless: true });
  for (const [index, base] of [[1, '/'], [3, '/docs/']]) {
    const lines = astro[index].split('\n'); assert.equal(lines.length, 2);
    await run(lines[0]);
    try {
      const preview = await run(lines[1]);
      const port = /http:\/\/127\.0\.0\.1:(\d+)/.exec(preview.stdout + preview.stderr)[1];
      const url = `http://127.0.0.1:${port}${base}`;
      const manifest = await (await fetch(url + 'raveldex/manifest.json')).json();
      assert.equal(manifest.base, base); assert.equal(manifest.recordCount, 3);
      const page = await browser.newPage(), failures = [];
      page.on('pageerror', error => failures.push(String(error)));
      await page.goto(url);
      await page.getByRole('button', { name: 'Load search data', exact: true }).click();
      await page.locator('body[data-search-state="ready"]').waitFor();
      await page.getByRole('button', { name: 'Open search', exact: true }).click();
      await page.locator('body[data-search-state="open"]').waitFor();
      const search = async query => { await page.getByRole('searchbox').fill(query); await page.getByRole('button', { name: 'Search', exact: true }).click(); };
      await search('atomic');
      await page.waitForFunction(() => document.querySelector('[data-raveldex-status]')?.textContent === '1 results. Showing 1–1.');
      await page.getByRole('button', { name: 'Inject next search error', exact: true }).click();
      await page.getByRole('button', { name: 'Search', exact: true }).click();
      await page.waitForFunction(() => document.querySelector('[data-raveldex-status]')?.textContent === 'Search failed. Retry is available.');
      await page.getByRole('button', { name: 'Retry search', exact: true }).click();
      await page.waitForFunction(() => document.querySelector('[data-raveldex-status]')?.textContent === '1 results. Showing 1–1.');
      await search('marzipanprivate');
      await page.waitForFunction(() => document.querySelector('[data-raveldex-status]')?.textContent === 'No results.');
      await page.getByRole('button', { name: 'Close search', exact: true }).click();
      assert.equal(await page.locator('[data-authored-fallback]').count(), 1);
      await page.getByRole('button', { name: 'Unload search data', exact: true }).click();
      await page.locator('body[data-search-state="unloaded"]').waitFor();
      await page.getByRole('link', { name: 'Atomic publication', exact: true }).click();
      assert.equal(new URL(page.url()).pathname, base + 'guide/atomic/');
      assert.deepEqual(failures, []);
      observations.push({ name: 'Exact Astro copy/install/build/preview and stop', base, status: 'Pass',
        recordCount: 3, atomicTotal: 1, excludedDraft: 0, errorRetry: true, fallbackAndUnload: true, navigation: new URL(page.url()).pathname });
      await page.close();
    } finally { await run(astro[2]); }
  }
} catch (error) { errors.push({ message: error.message, stack: error.stack }); throw error; }
finally {
  await browser?.close();
  const report = { status: errors.length ? 'Fail' : 'Pass', node: process.version, commands, observations, errors,
    scope: 'Exact current documented commands/code with real local tarballs and Chrome automation; not human AT or physical-input evidence.' };
  await fs.writeFile(path.join(stage, 'follow.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ status: report.status, observations: observations.length, errors }));
}
