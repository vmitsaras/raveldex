import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const [repo, stage] = process.argv.slice(2), exec = promisify(execFile);
const report = { status: 'Fail', observations: [], errors: [] };
const fences = text => [...text.matchAll(/```js\n([\s\S]*?)\n```/g)].map(x => x[1]);
try {
  const followed = JSON.parse(await fs.readFile(path.join(stage, 'follow.json')));
  assert.equal(followed.status, 'Pass');
  const app = followed.commands.find(row => row.command.includes('npm init -y')).cwd;
  const checks = [
    ['TYPO', values => { assert.equal(values[0][0], 1); assert.ok(values[0][1].groups.some(group => group.alternatives.some(item => item.term === 'source'))); }],
    ['SUGGESTIONS', values => { const item = values[0][0].items.find(item => item.term === 'source'); assert.equal(item.fieldDocumentFrequency, 2); }],
    ['SYNONYMS', values => assert.deepEqual(values, [['directional-one-step-v1:docs-v1']])],
    ['ENGLISH', values => assert.deepEqual(values, [['english-porter1980-v1']])],
    ['IDENTIFIERS', values => assert.deepEqual(values, [[1, 1]])],
    ['LITERAL', values => assert.deepEqual(values, [[1, 0]])],
    ['PROXIMITY', values => assert.deepEqual(values, [[1, 'guide']])],
    ['QUERY_SYNTAX', values => assert.deepEqual(values, [[1, 'guide']])],
    ['RECORD_PATCH', values => assert.deepEqual(values, [[2, 1, 'guide']])],
  ];
  const rows = [];
  for (const [name] of checks) {
    const source = `docs/api/${name}.md`, file = `exact-${name.toLowerCase()}.mjs`;
    await fs.writeFile(path.join(app, file), fences(await fs.readFile(path.join(repo, source), 'utf8'))[0]);
    rows.push({ name, source, file });
  }
  await fs.writeFile(path.join(app, 'observe-exact.mjs'), `
    const observations = [];
    for (const row of ${JSON.stringify(rows)}) {
      const values = [], original = console.log;
      console.log = (...args) => values.push(args);
      try { await import('./' + row.file); } finally { console.log = original; }
      observations.push({ ...row, values });
    }
    console.log(JSON.stringify(observations));
  `);
  const observed = JSON.parse((await exec(process.execPath, ['observe-exact.mjs'], { cwd: app, timeout: 60_000 })).stdout);
  for (const row of observed) {
    checks.find(([name]) => name === row.name)[1](row.values);
    report.observations.push({ name: `${row.source}: exact code and described output`, status: 'Pass', values: row.values });
  }
  const coreFragment = fences(await fs.readFile(path.join(repo, 'docs/api/CORE.md'), 'utf8'))[0];
  const addonFragments = fences(await fs.readFile(path.join(repo, 'docs/api/ADDONS.md'), 'utf8'));
  await fs.writeFile(path.join(app, 'prefix-fragment.mjs'), coreFragment + '\nexport { query };');
  for (const [index, symbol] of ['phraseQuery', 'options', 'options'].entries()) {
    await fs.writeFile(path.join(app, `addon-fragment-${index}.mjs`), addonFragments[index] + `\nexport { ${symbol} };`);
  }
  const fragmentRunner = `
    import assert from 'node:assert/strict';
    import { createRaveldex } from '@vmitsaras/raveldex';
    import { createSourceProvider, createSourcePhrases } from '@vmitsaras/raveldex/addons/phrases';
    import { createFacets } from '@vmitsaras/raveldex/addons/facets';
    import { createInspector } from '@vmitsaras/raveldex/addons/inspector';
    import { query } from './prefix-fragment.mjs';
    import { phraseQuery } from './addon-fragment-0.mjs';
    import { options as facetOptions } from './addon-fragment-1.mjs';
    import { options as inspectorOptions } from './addon-fragment-2.mjs';
    const prefix = createRaveldex({ schema: { text: { title: {} } } });
    try {
      await prefix.add({ id: 'guide:updates', text: { title: 'Atomic updates' } });
      const page = await prefix.search(query);
      assert.equal(page.total, 1); assert.equal(page.hits[0].id, 'guide:updates');
    } finally { await prefix.dispose(); }
    const engine = createRaveldex({
      schema: { text: { title: {}, body: {} }, metadata: { kind: { type: 'string' } } },
      addons: [createSourceProvider({ fields: ['title', 'body'] }), createSourcePhrases({ fields: ['title', 'body'] }),
        createFacets({ fields: ['kind'] }), createInspector({ sourceFields: ['title'] })],
    });
    try {
      await engine.addMany([
        { id: 'guide:updates', text: { title: 'red car', body: 'car' }, metadata: { kind: 'guide' } },
        { id: 'gap', text: { title: 'red fast car', body: 'car' }, metadata: { kind: 'guide' } },
        { id: 'missing', text: { title: 'blue', body: 'car' } },
      ]);
      const phrase = await engine.search(phraseQuery);
      assert.deepEqual(phrase.hits.map(hit => hit.id), ['guide:updates']);
      const facets = await engine.search({ kind: 'all' }, facetOptions);
      const buckets = facets.extensions.facets.fields[0].buckets;
      assert.equal(buckets.find(bucket => bucket.kind === 'value').count, 2);
      assert.equal(buckets.find(bucket => bucket.kind === 'missing').count, 1);
      const inspected = await engine.search('red', inspectorOptions);
      assert.equal(inspected.extensions.inspector.revision, 1);
      assert.ok(JSON.stringify(inspected.extensions.inspector).includes('red car'));
      console.log(JSON.stringify({ prefixTotal: 1, phraseTotal: phrase.total, buckets,
        inspectorKind: inspected.extensions.inspector.kind, inspectorRevision: 1 }));
    } finally { await engine.dispose(); }
  `;
  await fs.writeFile(path.join(app, 'check-fragments.mjs'), fragmentRunner);
  const fragments = await exec(process.execPath, ['check-fragments.mjs'], { cwd: app, timeout: 60_000 });
  report.observations.push({ name: 'Four unchanged query/options fragments with their documented prerequisite setup', status: 'Pass', values: JSON.parse(fragments.stdout) });
  const example = /EXAMPLE_RESULT=(.+)/.exec(followed.commands.find(row => row.stdout?.includes('EXAMPLE_RESULT=')).stdout)[1];
  const packageCode = fences(await fs.readFile(path.join(repo, 'integrations/astro/README.md'), 'utf8'))[0];
  await fs.writeFile(path.join(example, 'package-readme-build.mjs'), packageCode);
  const built = await exec(process.execPath, ['package-readme-build.mjs'], { cwd: example, timeout: 60_000 });
  assert.match(built.stdout, /1 \/docs\//);
  report.observations.push({ name: 'Separate Astro package README: exact static builder code', status: 'Pass', stdout: built.stdout });
  report.status = 'Pass';
} catch (error) { report.errors.push({ message: error.message, stack: error.stack }); throw error; }
finally {
  await fs.writeFile(path.join(stage, 'blocks.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ status: report.status, observations: report.observations.length, errors: report.errors }));
}
