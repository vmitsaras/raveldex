# UI, workers, snapshots, storage and migration

Use these integrations to add a browser interface, move work to a module worker or save and restore an index. You decide when each integration starts and when to clean it up. Importing a module does not start a worker, mount controls, open a database or restore data. The [example modules](examples/README.md) show complete small setups.

## Native DOM UI and CSS

Use `mountRaveldexUI(options: UIOptions): UIHandle` from `/addons/ui` to put search controls into an element on your page. You supply the engine and keep responsibility for disposing it. Import the UI and its stylesheet through a bundler that handles CSS:

```js
import { mountRaveldexUI } from '@vmitsaras/raveldex/addons/ui';
import '@vmitsaras/raveldex/addons/ui/styles.css';
```

These imports make the function and styles available; they do not mount anything yet.

### Mount a minimal search form

Add this element to your page where you want the search controls to appear:

```html
<section id="search" aria-label="Documentation search"></section>
```

The element starts empty. Copy [ui.mjs](examples/ui.mjs) into your application, then put the following in a browser module processed by your bundler. Run it after the element exists:

```js
import { createSearchUI } from './ui.mjs';
import '@vmitsaras/raveldex/addons/ui/styles.css';

const search = await createSearchUI(document.querySelector('#search'));
// Call this when your application removes the search component:
// await search.dispose();
```

You should now see a search field and results. Type `atomic` to get one result, **Atomic updates**, linked to `/guide/updates/`. The example supplies that URL; your application needs to provide the destination page.

The recipe creates one title/body record and a matching display entry. To use real documents, replace both entries and keep their IDs equal. It keeps data in memory and opens no database. Call the returned `dispose()` when removing the component; it destroys the UI first, then disposes the engine.

| `UIOptions` | Contract |
| --- | --- |
| `root`, `engine`, `documents` | Provide a root element, your engine and a readonly list of `{ id, title, url }` display documents. IDs connect results to this list, which is copied at mount. URLs must resolve to HTTP(S) without credentials. |
| `facets?` | Up to eight `UIFacet` selections `{ field, label }`; requires installed exact string facets. |
| `snippetFields?` | Explicit fields for installed snippets and source providers. |
| `mode?` | `'text'` (default) or `'phrase'` (requires phrase capability for selected fields). |
| `pageSize?`, `debounceMs?`, `label?` | Defaults 5, 150 ms and `Search documentation`; page size 1–100 and debounce 0–2,000 ms. Core's configured page bounds still apply. |

The returned handle gives you two methods:

- `search(): Promise<void>` runs the current controls immediately instead of waiting for the debounce timer. It resolves after the result is presented.
- `destroy(): void` cancels UI work, removes its listeners and restores the original DOM nodes. You can call it more than once. It does not dispose your engine.

Mounting on an already mounted root returns the existing handle. Always destroy the UI before separately disposing its engine.

The UI renders text safely, marks highlights explicitly and supplies visible focus and reduced-motion styles. It shows exact totals, pagination, empty results, errors and retry controls. An empty search browses all documents; entered text uses the selected text or phrase mode.

While you compose text with an input method, pending searches wait until composition ends. Outdated requests are cancelled and stale replies are ignored. The display list is copied when you mount, so destroy and remount the UI when replacing that list. The [browser example](examples/browser.mjs) also shows explicit search calls, cleanup and source persistence.

### Keyboard, focus and status

You provide the root element, engine and display list; the UI creates its own labeled controls, ordered results and named native modal `dialog`. You do not need to author its internal markup.

- Typing schedules a search after the configured delay.
- Return in the search field or the **Search** button submits immediately.
- Selects and result links use the browser's normal keyboard behavior.
- Search, filter and page updates do not deliberately move focus.

Opening Inspector puts keyboard focus on **Close Inspector**. Use that button or Escape to close it and return focus to **Inspect results**, provided the opener is still on the page. Tab navigation follows the browser's native dialog behavior; the UI adds neither a custom Tab loop nor a focusable heading.

Status messages use `role="status"` and `aria-atomic="true"`. The search section is `aria-busy` during a search, and Inspector is busy while facts load. Unavailable page, retry and Inspector buttons use `aria-disabled="true"`: they remain in the tab order, but activation is guarded.

Typing feedback can interrupt spoken status messages. Check important flows with your target browser and screen reader, without requiring users to change their settings. The UI does not change those settings and exposes no public custom-event API.

### CSS customization

Import `@vmitsaras/raveldex/addons/ui/styles.css` separately, then use the five public properties below to adjust the generated `.raveldex-ui` block. The `data-raveldex-*` attributes identify internal elements; do not use them as an alternative application markup API.

| Property | Default | Purpose |
| --- | --- | --- |
| `--raveldex-ui-accent` | `#174ea6` | Link color |
| `--raveldex-ui-background` | `#fff` | Surface background |
| `--raveldex-ui-color` | `#17212b` | Text color |
| `--raveldex-ui-border` | `#596b7d` | Control and structural borders |
| `--raveldex-ui-focus` | `#7a2600` | Visible focus outline |

Set overrides on `.raveldex-ui` itself, where the defaults are declared. For example, `.my-search .raveldex-ui { --raveldex-ui-accent: #174ea6; }` sets the link color inside your `.my-search` container. It leaves the current default unchanged; choose a different accessible color to see a difference. Properties beginning with `--_` are private.

Keep the stylesheet's visible focus, disabled-state borders, scrolling dialog and narrow-screen wrapping usable when customizing it. Reduced-motion rules disable animation, transitions and smooth scrolling. Forced-colors rules use system colors for focus, borders and highlights. Check contrast after changing colors. There is no separate theme or variant registration API.

## One-owner module worker

Use a module worker to run a complete engine off the main thread. Create the `Worker` yourself, then pass it to `createWorkerRaveldex` from `/adapters/worker`. The [worker example](examples/worker.mjs) and [host module](examples/worker-host.mjs) show both sides.

`createWorkerRaveldex(options: WorkerOptions): Promise<WorkerRaveldex>` takes `{ worker, configuration, ownership: 'owned' | 'external', sameHost: true, maxMessageBytes?, responseTimeoutMs? }`. The initial handshake checks the implementation, analyzer, ranking model and selected registrations. `sameHost: true` describes your browser and its own worker; it does not qualify other environments, and the default analyzer profile stays unqualified.

In the worker module, call `serveRaveldexWorker(scope, options?)` from `/adapters/worker/host`. Its options are `{ addons?, maxMessageBytes? }`. Install matching add-ons in the client configuration and worker host: functions and live registration handles cannot be sent as cloneable data.

`WorkerScope` needs `postMessage`, `addEventListener` and `removeEventListener`; `WorkerEndpoint` also needs `terminate`. The host returns a `WorkerHostHandle` with an asynchronous `dispose()` method.

`WorkerRaveldex` has ordinary methods plus `reconcile(operationId)` and `destroy()` (the disposal alias). Mutation methods return `MutationPromise`, a Promise with a captured `operationId`. `MutationReceipt` is `{ operationId, status: 'pending' | 'expired' }`, `{ operationId, status: 'committed', result }` or `{ operationId, status: 'rejected', error: WireError }`. Reconciliation uses the same owner/session and a bounded 256-receipt window. It is not durable deduplication across worker loss.

Messages default to a maximum of 8 MiB, which you can lower to 1 KiB. Message structure is bounded too, and at most 64 requests can be pending. The default response timeout is 65,000 ms, configurable from 1 to 120,000 ms. Engine deadlines and work limits apply separately.

If a reply is lost or late, an update may already have committed. Check its receipt while the worker survives. If the owner is gone or the receipt has expired, rebuild a new engine from your authoritative source instead of blindly repeating an add, replace or remove. An expired receipt proves neither success nor failure.

`WorkerAdapterError` has `code`, sanitized `details` and optional `operationId`; `WORKER_ERROR_CODES` includes `INVALID_TRANSPORT`, `TRANSPORT_LIMIT`, `INCOMPATIBLE_WORKER`, `TIMEOUT`, `TERMINATED`, `STARTUP_FAILED`, `OUTCOME_UNKNOWN` and `DISPOSED`. Authoritative native errors remain `RaveldexError`; snapshot errors carry their reason. `WireError` preserves the declared category/code rather than serializing an arbitrary Error/cause. `WorkerErrorCode` and `WorkerErrorDetails` are exported types.

Call `destroy()` or `dispose()` when you are done. The adapter asks the owner to acknowledge cleanup, releases client listeners and settles pending work. It terminates an `owned` endpoint; you remain responsible for an `external` one. An acknowledgement timeout still reports an error after local cleanup. Searches never silently fall back to the main thread.

## Source and native snapshots

Use snapshots to export an engine's state and restore it later. Call `createSnapshots(engine, options?)` from `/adapters/snapshots` with a supported direct engine. The helper uses your engine without owning it or adding methods to it.

Its methods are `exportSource(options?)`, `exportNative(options?)` and `restore(encoded: string, options?)`. Each returns a promise and accepts core mutation signal/deadline options. `SnapshotOptions` lets you set `maxEncodedBytes`, from 1 KiB to the default and maximum 64 MiB.

| Format | Requirements / meaning |
| --- | --- |
| `raveldex-source` | Selected originals for every schema text field; exports owned source/configuration and rebuilds under the receiving analyzer. Does not promise prior membership, rank or score equivalence across environments. |
| `raveldex-native` | Explicit exact-Node-runtime qualification from owner creation; validates compatible native index/statistics/provider structures, configuration, analyzer/model, codecs and limits. It is not an arbitrary engine dump or a browser portability promise. |

Both formats export versioned JSON strings with size, structure and corruption checks. Checksums detect changed bytes; they do not authenticate who sent them.

A successful restore replaces the receiving engine's state in one atomic update at its next local revision. It returns `{ format, originRevision, revision, reindexed, receivingAnalyzer }`. `originRevision` records where the snapshot came from; it does not become the local revision. `reindexed` is `true` for a source rebuild and `false` for native state.

Cancellation or a validation, compatibility, work or deadline failure before commit leaves the previous state intact. A complete source rebuild can exceed a single operation's budget even if the original data was added successfully in smaller batches.

For source snapshots, use ordinary `createRaveldex`, source providers for every text field and `createSnapshots`. Choose this path unless you have an exact-runtime native qualification for your application.

For native snapshots, create the engine with `createSnapshotRaveldex(configuration, { nativeQualification })`. You cannot add native qualification to an ordinary engine afterward. The declaration is `NativeSnapshotQualification`: `{ profileId, scope: 'exact-node-runtime', environment, evidence: string[] }`. Its environment includes `{ runtime: 'node', version, v8, icu, unicode, platform, arch }`.

`currentNodeSnapshotEnvironment()` reads the current runtime identity, but detecting versions does not qualify it. The evidence references are declarations supplied and trusted by your application, not proofs executed by the library.

[snapshots.mjs](examples/snapshots.mjs) takes the application's declaration as an argument and exercises source and native round trips. The receiving native owner must match the exact declared profile/environment/evidence and compatible configuration. Use source snapshots when your application does not supply an exact-runtime native declaration.

`SnapshotAdapterError extends RaveldexError` adds `reason: SnapshotReason`. `SNAPSHOT_REASONS` is `MALFORMED_SNAPSHOT`, `ENCODED_LIMIT_EXCEEDED`, `INTEGRITY_MISMATCH`, `UNSUPPORTED_FORMAT`, `UNSUPPORTED_CODEC`, `SCHEMA_MISMATCH`, `ANALYZER_MISMATCH`, `RANKING_MISMATCH`, `CAPABILITY_MISMATCH`, `INDEX_DETAIL_MISMATCH`, `LIMITS_MISMATCH`, `SOURCE_UNAVAILABLE`, `UNQUALIFIED_PROFILE`, `PROFILE_MISMATCH`, `INVALID_NATIVE_STATE`, `UNSUPPORTED_ENGINE`. Reasons distinguish compatibility from the ordinary error code.

Browser workers use the separate source-only bridge: `createWorkerSnapshots(engine)` from `/adapters/worker/snapshots` and `serveSnapshotRaveldexWorker(scope, options?)` from `/adapters/worker/snapshots/host`. [worker.mjs](examples/worker.mjs) and [worker-host.mjs](examples/worker-host.mjs) show a matched pair. `WorkerSnapshots` exposes `exportSource`, `restore` and its own `reconcile`. Restore returns `SnapshotRestorePromise` with `operationId`; its `SnapshotRestoreReceipt` is `pending`, `expired`, `committed` with a restore result, or `rejected` with a wire error. Pending/expired cannot resolve an unknown outcome. Ordinary mutation reconciliation is separate. Browser/worker native export and restore remain unavailable.

The snapshot entry also exports `SnapshotEngineOptions`, `SnapshotOptions`, `SnapshotFormat`, `SnapshotRestoreResult` and `Snapshots` types. Worker snapshot/client/host types are available from their corresponding subpaths; no private control-channel import is supported.

## IndexedDB persistence and recovery

Use `createIndexedDBPersistence(snapshots, options)` from `/adapters/indexeddb` to save and load snapshots explicitly. It manages its own database connections while borrowing the snapshot export/restore handles. Disposing storage does not dispose your engine.

Supply `{ databaseName, namespace }` for a database owned by this adapter, not an unrelated application database. Optional settings are `{ indexedDB?, format?: 'source' | 'native', openTimeoutMs?, operationTimeoutMs? }`. The factory can be supplied directly or found when needed, and the default format is source. Native format requires the qualified direct-engine path; workers support source only.

| Method | Required options / result |
| --- | --- |
| `save(options: PersistenceWriteOptions)` | `{ expectedGeneration: string | null, signal?, deadlineMs? }`; returns `PersistenceSaveResult` `{ generation, format, encodedBytes, durable: true }`. Null explicitly expects an empty namespace. |
| `load(options?: PersistenceOptions)` | `{ signal?, deadlineMs? }`; returns `PersistenceLoadResult` `{ status: 'missing', generation: null }` or `{ status: 'restored', generation, restore }`. |
| `erase(options: PersistenceWriteOptions)` | Same expected-generation requirement; returns `PersistenceEraseResult` `{ erased, generation: null, durable: true }` after deleting the namespace's snapshot and metadata rows. |
| `dispose()` | Releases connections/actions without erasing storage or disposing the borrowed engine. |

Keep the generation returned by a save or load and supply it on your next save or erase. This prevents one writer from silently overwriting another. `GENERATION_CONFLICT` means you need to read the current generation and decide how to resolve the change. A loaded generation describes the snapshot you read, not a lock on later writes.

`durable: true` means the strict-hint IndexedDB transaction completed. It does not guarantee survival of power loss or browser eviction. Saving bytes and later restoring an engine are separate operations.

Open timeout defaults to 5,000 ms (maximum 30,000); action timeout defaults to 30,000 ms (maximum 60,000), with at most 64 pending actions and a 64 MiB encoded ceiling. Actions include queue time, encoding and restore. A timeout during an uncertain restore can return `OUTCOME_UNKNOWN`, including selected generation and operation identity when available. Do not automatically repeat that restore or call it rolled back. Use worker snapshot receipts when available, inspect the surviving owner separately, or explicitly recover into a new owner from authoritative data.

`IndexedDBAdapterError` is separate from core/snapshot errors, with `code` and frozen `details: IndexedDBErrorDetails` (`phase?`, generation fields, `operationId?`, `snapshotReason?`, `selectedGeneration?`). `INDEXEDDB_ERROR_CODES` is `INVALID_OPTIONS`, `UNAVAILABLE`, `QUOTA_EXCEEDED`, `INCOMPATIBLE_DATABASE`, `BLOCKED`, `VERSION_CHANGED`, `GENERATION_CONFLICT`, `CORRUPT_DATA`, `INCOMPATIBLE_SNAPSHOT`, `TRANSACTION_FAILED`, `CANCELLED`, `TIMEOUT`, `DISPOSED`, `OUTCOME_UNKNOWN`, `QUEUE_FULL`. `IndexedDBErrorCode` is exported with the option/result/interface types above. No automatic save, startup restore, retry or namespace deletion occurs on import.

## LocalSearch source migration

Use `convertLocalSearchSnapshot(bytes)` from `/integrations/localsearch` to convert a supported companion source export before rebuilding a separate Raveldex engine. It checks the snapshot, checksum and supported data mapping.

The supported input identity is companion-v1, format 1, MiniSearch 7.2.0. Arbitrary MiniSearch indexes, worker messages and storage rows are rejected. Conversion needs `crypto.subtle`, accepts at most 32 MiB and includes bounded synchronous work. It is not a queued, cancellable engine operation.

The returned plan contains `{ configuration, records, origin, sourceRevision, returnFields, identity, differences }`. Read `identity` and `differences` for changes in analysis and ranking. `origin` and `sourceRevision` describe the old collection; they do not become the new engine's revision or a storage generation.

The [migration recipe](examples/migration.mjs) rebuilds a separate engine with bounded `addMany` calls, inspects it and disposes it. In your application, switch to the new engine only after the whole rebuild succeeds. Each batch is atomic, but the entire migration is not one transaction.

`MigrationError` has sanitized `code` and `details: { reason, nativeCode? }`. `MIGRATION_ERROR_CODES` is `INVALID_BYTES`, `INVALID_SNAPSHOT`, `INCOMPATIBLE_SNAPSHOT`, `NONCANONICAL_SNAPSHOT`, `CHECKSUM_MISMATCH`, `NATIVE_INCOMPATIBLE`, `CAPABILITY_REQUIRED`. The entry exports `MigrationErrorCode`, `MigrationErrorDetails`, `MigrationReason`, `LocalSearchMigration`, `LocalSearchMigrationIdentity` and `LocalSearchMigrationOrigin`. Foreign indexes, scores, live handles and namespaces are never reused. The repository [migration guide](https://github.com/vmitsaras/raveldex/blob/main/docs/migration/LOCALSEARCH.md) gives mapping and provenance details.
