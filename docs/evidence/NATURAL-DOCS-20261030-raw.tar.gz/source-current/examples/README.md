# Examples

Want to try search before integrating it? Start with the browser demo. Choose a terminal example to inspect raw results, or the Astro walkthrough to add search to static pages.

| Example | Run it | What to try |
| --- | --- | --- |
| [Browser search](docs-search/README.md) | `npm run pilot:ui` | Search usage guides, filter results, inspect scores and compare direct/worker execution. |
| [Core terminal search](core-docs/README.md) | `npm run pilot:core -- 'atomic mutation'` | Index source records and read IDs, scores and exact totals. |
| [Astro static site](astro/README.md) | Follow the copy/install/build/preview steps | Load search on demand, follow a result and rebuild with a subdirectory base. |
| [Migration](migration/README.md) | Follow the converter example | Convert a companion source export and rebuild a native collection. |
| [API recipes](../docs/api/examples/README.md) | Copy a module into your installed ESM application | Core, a minimal browser UI, add-ons, snapshots, workers or storage. |

Repository commands need a source checkout, repository access, Node 24 and an initial `npm ci`. If you only have package tarballs, follow [installation](../docs/api/GETTING_STARTED.md) and use the copied API recipes instead.

Each walkthrough explains what you should see and how to clean up. Stop ordinary preview servers with Ctrl+C. The Astro example uses its documented project-scoped stop command.
