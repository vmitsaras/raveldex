# Independent LLDB observer pre-execution review

Reviewed 2026-10-28: `browser-lldb-control/lldb_native_tap.py`, lines 1–161, as read from the parent's task root. No hooks, attach, native execution, workload, build, repository edits or owner-app changes were performed by this reviewer. This is source review, not runtime calibration.

## Verified source properties

- Shared realloc, BufferAlloc, exact grow-copy and both free argument register choices agree with the supplied disassembly reviewed in `native-browser-static-review.md`.
- Runtime installation validates owned PID 54501, exact image path, UUID and code bytes before creating breakpoints. Extra prefixes cover BufferAlloc and internal free.
- Thread-local return stacks record entry SP and LR; copy return uses the exact post-BL address `BASE+0x17a1740`. The while loop can discharge stacked tail aliases sharing return PC/SP. End rejects pending frames.
- New destination capacity is introduced at observed exact-copy entry before old free. The realloc-return path then confirms/updates the live map, and fallback API-only retirement is explicitly named.
- Nested BufferAlloc returns are auxiliary records, avoiding duplicate births from tracking the same request at two call layers.
- Scope is explicitly selected grow-copy extents/API buffer requests, with debugger perturbation, right censoring, no OS-page peak, no complete V8/string-copy coverage and no latency claim.

## Actionable findings before controls

1. **Installation is not fail-closed after breakpoint creation starts.** `install()` catches errors but does not remove any breakpoints already created (lines 125–134); `begin()` does not require a successful install (136–141). A partially failed installation can therefore be followed by an apparently active run. Add an installed-success flag, roll back only observer-owned breakpoints on any installation failure, require success in begin, and mark failed configuration unusable until reinstalled successfully. A failure before breakpoints has no mutation, but the code also admits failures during breakpoint creation/output writing.
2. **Cleanup/reinstall retains stale breakpoint maps.** `cleanup()` deletes actual breakpoints but leaves BPS/ROLES populated (154–158). A later install skips these deleted breakpoints at line 42 and reports installation success. Clear BPS/ROLES and reset installation state during cleanup, or explicitly refuse all reuse of a cleaned observer instance.
3. **Lineage IDs do not identify allocation births.** `chain` persists across moved reallocations. `add()` silently accepts a pointer already live in the same chain and overwrites its capacity (29–35). This is correct only for explicit confirmation of the same frame's already-recorded provisional destination, or a verified in-place return. It otherwise masks duplicate/colliding destinations, including an impossible source==destination on the selected allocate-copy-free path. Require a nonzero distinct copy destination, reject preexisting destinations except a matching explicit provisional confirmation, record a monotonically increasing allocation birth ID separately from logical chain, and bind free retirement to birth. Nested wrapper/internal free frames can share a retirement witness; do not subtract two lifetimes from their two return rows.
4. **Record overflow grows INVALID without its own bound.** `event()` appends `record_limit` directly for every event after MAX_ROWS (23–25), bypassing `problem()`'s 128-reason bound. Use the bounded problem path and a numeric dropped-event counter, with any drop invalidating attribution. This preserves bounded observer storage after overload.

## Additional acceptance guards

- Use validated register reads: missing/unreadable critical registers should throw/reject rather than defaulting silently to zero from GetValueAsUnsigned. Validate target state/platform and successful installation at begin. Record source hash in the execution artifact, not merely manifest hash, to bind raw traces to exact callback code.
- At copy entry require nonzero destination, distinct source/destination and nonnegative finite extent within the new destination request. The copy length can exceed **old requested API capacity**, because the reviewed allocator chooses from old usable extent; preserve that fact rather than treating old API request as a complete slot boundary.
- Null selected allocation returns should receive a failure disposition. Realloc-to-zero must remain a real pending frame even though capacity is zero; this LLDB stack already avoids the earlier Frida capacity-sentinel issue.
- The source has no watchdog. A separately verified parent runner must enforce a finite wall/run limit, interrupt safely, end with unmatched-frame invalidation and detach/cleanup owned breakpoints, preserving timeout/crash output. Breakpoint/event/map limits alone do not stop a stalled browser.
- No selected event count is yet a calibration pass. Check fresh allocation, growth/copy return, old/final free, idle negative control and actual emitted event/frame matching before product messages. Expose API-only retirement count, unknown-old failures, remaining allocations and pending frames independently.

## Scope disposition

The earlier provisional-destination finding is addressed in source. Destination-copy coverage is deliberately narrower here: only `0x17a173c` grow-copy is observed. The demonstrated SSV create-from-span memmove destinations and other copy paths remain follow-up evidence; their absence must not be described as complete SSV/string transport-copy or peak coverage. Exact message/direction/phase/worker-thread correlation remains necessary for product attribution.

ABI/source approach: **Consistent**. Observer readiness: **Fix installation/reuse/duplicate-birth/overflow guards before calibration**. Runtime results and native message attribution: **Not established by this source review**.
