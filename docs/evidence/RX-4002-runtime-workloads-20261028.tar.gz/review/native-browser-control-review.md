# Independent native-browser control review

2026-10-28. Read-only offline parsing of four saved tap JSON files, installation/host logs and browser control report. No attach, workload, browser run, build or repository edit by reviewer. Exact observer SHA-256: `00356612131d50b53962baa5c1fc9b617e5d5a0454d975a2c7bf3359d404e917`.

Machine-readable results and individual input hashes: `native-browser-control-raw-audit.json` in this review directory. The reviewer used an independent Python parser via a shell here-document, not the observer module, to check sequence, thread-local entry/return kind order, matching native fields, old/source capacities, distinct copy destinations, destination-request bounds, live allocation births, pointer reuse generations, free-return generations, confirmation rows, final registry replay and source identity.

| Control | Rows | Selected growth-copy pairs | Selected growth-copy bytes | Disposition |
|---|---:|---:|---:|---|
| small | 22 | 2 | 144 | Raw-order/registry replay Pass |
| latin1 | 38 | 4 | 576 | Raw-order/registry replay Pass |
| two-byte | 38 | 4 | 576 | Raw-order/registry replay Pass |
| clone-refusal | 5 | 0 | 0 | Raw-order/registry replay Pass |

All 103 rows have contiguous sequence numbers, no declared invalid events or drops, no pending callback frames and the reviewed source hash. Every observed selected growth copy has matching destination return and subsequent internal free of the correct old allocation birth. Actual freed-pointer reuse occurs with a new birth ID. The three successful-message controls each contain events from thread IDs 10105742 and 10105780; assigning complete sender/receiver semantics requires the case/harness evidence in addition to those native thread IDs.

The supported local pair observations are `72 -> 216` with a 72-byte selected growth copy, `216 -> 327672` with a 216-byte selected growth copy for latin1, and `216 -> 655352` with a 216-byte selected growth copy for two-byte. Both distinct requested-capacity extents exist at the exact copy call, followed by observed copy return and old-buffer internal free. These are requested/API extents and executed selected copy lengths, not OS page bytes or full string-copy counts.

The clone-refusal control reports DataCloneError and records fresh 72-byte allocation followed by common root-free entry/return for the correct birth, with empty remaining registry. This calibrates that error-cleanup path. The successful controls leave two final buffers each in the observed registry, right-censored at cutoff. Their **normal final-free path is not calibrated**. Global/summed registry high-water remains **unqualified**: an unobserved normal free could retire an earlier buffer before a later chain. Earlier interim arithmetic from that registry is withdrawn as a qualified high-water claim.

The browser report records exact payload verification for the small 12-code-unit case and both 262144-code-unit cases. The host log records observer hook removal and renderer PID 54501 detachment. Host outcome is exit code 0, timedOut false, within its declared 300-second bound. These establish bounded control/cleanup observations, not latency evidence. Control report subsequently records release, worker termination and browser close; process teardown is not native final-free proof.

Limitations: entry/return SP/PC and frame IDs were used in callback logic but not emitted in the frozen raw rows. Their actual equality cannot be independently replayed from these files; the raw audit covers observable thread-local fields/order and the callback logic was separately source-reviewed. No idle negative control or in-place realloc was observed. Only the exact PA grow-copy site is covered; broader SSV create-from-span copies, inline copies, receiver string work and whole-message copy/peak accounting remain incomplete. No product transfer attribution or complete AC03 transport qualification follows from these controls.

Disposition: **Selected allocation/growth-copy/error-free control evidence is internally consistent and independently replayed within the stated raw-data limits. Complete transport backing lifetime and peak/copy coverage remain incomplete.**
