#!/usr/bin/env python3
"""Offline index/stream tests against literal expectations and frozen slow replay."""
import ast
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import runpy
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
FAST = runpy.run_path(str(ROOT / 'independent-managed-indexed-audit.py'))
SLOW = runpy.run_path(str(ROOT / 'slow-reference-audit.py'))

class IndexedReplayTests(unittest.TestCase):
    def validate_index(self, index, expected):
        seen = []
        def walk(node):
            if node is None:
                return 0, 0
            lh, lt = walk(node.left)
            seen.append((node.start, node.end, node.seq))
            rh, rt = walk(node.right)
            self.assertLessEqual(abs(lh-rh), 1)
            self.assertEqual(node.height, 1 + max(lh, rh))
            self.assertEqual(node.total, lt + rt + node.end - node.start)
            return node.height, node.total
        _, total = walk(index.root)
        self.assertEqual(seen, sorted((key, *value) for key, value in expected.items()))
        self.assertEqual(total, sum(end-key for key, (end, _) in expected.items()))
        self.assertEqual(index.total, total)

    def test_original_22_literal_tests_are_unchanged(self):
        def literal_class(path):
            return next(node for node in ast.parse(path.read_text()).body if isinstance(node, ast.ClassDef) and node.name == 'LiteralTests')
        self.assertEqual(ast.dump(literal_class(ROOT/'slow-reference-audit.py')), ast.dump(literal_class(ROOT/'independent-managed-indexed-audit.py')))
        self.assertEqual(len([n for n in literal_class(ROOT/'independent-managed-indexed-audit.py').body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]),22)

    def test_all_four_rotations_and_two_child_deletions(self):
        for order in [(30,20,10),(10,20,30),(30,10,20),(10,30,20)]:
            index, expected = FAST['IntervalIndex'](), {}
            for key in order:
                index.insert(key,key+4,key)
                expected[key]=(key+4,key)
                self.validate_index(index,expected)
            for key in [20,10,30]:
                index.remove(key)
                del expected[key]
                self.validate_index(index,expected)

    def test_fixed_seed_index_operations_against_sorted_dictionary(self):
        rng = random.Random(79019)
        index, expected = FAST['IntervalIndex'](), {}
        for _ in range(2000):
            key = rng.randrange(200)*16+1000
            if key in expected:
                index.remove(key)
                del expected[key]
            else:
                index.insert(key,key+8,key-1000)
                expected[key]=(key+8,key-1000)
            self.validate_index(index,expected)
            probe=rng.randrange(205)*16+993
            keys=sorted(expected)
            before=[key for key in keys if key<=probe]
            after=[key for key in keys if key>=probe]
            self.assertEqual(index.floor(probe), (before[-1],*expected[before[-1]]) if before else None)
            self.assertEqual(index.ceiling(probe), (after[0],*expected[after[0]]) if after else None)

    def test_adjoining_ranges_and_holes(self):
        index=FAST['IntervalIndex']()
        for lo,hi in [(1000,1040),(1080,1100),(1100,1120)]:
            index.insert(lo,hi)
        self.assertIsNone(index.first_overlap((1040,1080)))
        self.assertEqual(index.first_overlap((1079,1081)),(1080,1100,0))
        self.assertEqual(index.first_overlap((1099,1101)),(1080,1100,0))
        self.assertEqual(index.covering((1100,1120)),(1100,1120,0))
        self.assertIsNone(index.covering((1099,1101)))

    def test_literal_interior_split_then_left_trim(self):
        e=FAST['event']
        rows=FAST['fixture']([e('birth',1000,100),e('size_change',1020,20,old=60),e('move',1000,32,to=1008),e('inspect_object',1008,32)],100,52,100,48)
        self.assertEqual(FAST['audit_rows'](rows),SLOW['audit_rows'](rows))
        index=FAST['IntervalReplay']()
        for event in rows[1:-1]: index.event(event)
        self.validate_index(index.live,{1008:(1040,0),1080:(1100,0)})
        self.validate_index(index.births,{1000:(1100,1)})

    def test_fixed_seed_literal_replays_equal_slow_reference(self):
        rng=random.Random(4581)
        e=FAST['event']
        for _ in range(100):
            base=rng.randrange(1,500)*1000
            births=[e('birth',base,64),e('birth',base+128,32),e('birth',base+256,20)]
            rng.shuffle(births)
            rows=FAST['fixture'](births+[e('size_change',base,40,old=64),e('inspect_object',base+128,16)],116,92,116,24)
            self.assertEqual(FAST['audit_rows'](rows),SLOW['audit_rows'](rows))
            rows[-1]['monitored_non_filler_high_water_bytes'] += 1
            with self.assertRaises(FAST['AuditError']): FAST['audit_rows'](rows)
            with self.assertRaises(SLOW['AuditError']): SLOW['audit_rows'](rows)

    def test_streaming_bytes_hash_and_universal_line_endings(self):
        rows=FAST['fixture']([FAST['event']('birth',1000,32)],32,32,32)
        rows[0]['note']='café'
        expected=SLOW['audit_rows'](rows)
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            for name,newline in [('lf','\n'),('crlf','\r\n'),('cr','\r')]:
                path=Path(directory)/name
                raw=(newline.join(json.dumps(r,ensure_ascii=False) for r in rows)+newline).encode()
                path.write_bytes(raw)
                result,count,digest=FAST['parse_file'](path)
                self.assertEqual(result,expected)
                self.assertEqual(count,len(raw))
                self.assertEqual(digest,hashlib.sha256(raw).hexdigest())

    def test_streaming_guarded_prefix_discards_provisional_replay(self):
        e=FAST['event']
        rows=FAST['fixture']([e('birth',1000,32)],32,capacity=1,dropped=2)
        expected=SLOW['audit_rows'](rows)
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            path=Path(directory)/'drop.jsonl'
            path.write_text('\n'.join(json.dumps(r) for r in rows)+'\n')
            self.assertEqual(FAST['parse_file'](path)[0],expected)
        rows=FAST['fixture']([e('birth',1000,32),e('gc_prologue'),e('gc_epilogue')],32,gc=1)
        self.assertEqual(FAST['audit_rows'](rows),SLOW['audit_rows'](rows))

    def test_streaming_rejects_tail_and_duplicate_keys(self):
        rows=FAST['fixture']([])
        for suffix in ['\n{}','\n\n']:
            with tempfile.TemporaryDirectory(dir=ROOT) as directory:
                path=Path(directory)/'bad.jsonl'
                path.write_text('\n'.join(json.dumps(r) for r in rows)+suffix)
                with self.assertRaises(FAST['AuditError']): FAST['parse_file'](path)
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            path=Path(directory)/'duplicate.jsonl'
            path.write_text('{"record":"header","record":"summary"}\n')
            with self.assertRaises(FAST['AuditError']): FAST['parse_file'](path)

if __name__=='__main__': unittest.main(verbosity=2)
