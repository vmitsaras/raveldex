# Independent mutation cohort audit

All 36 guarded windows pass replay and provenance checks. Byte quantities below are separate observations; no baseline subtraction.

| Mode | Records | Operation | Gross min / median / max | High-water min / median / max | Stop min / median / max |
| --- | ---: | --- | ---: | ---: | ---: |
| core-only | 1,000 | empty-batch | 13,752 / 13,752 / 13,752 | 13,080 / 13,080 / 13,080 | 13,080 / 13,080 / 13,080 |
| core-only | 1,000 | replace-one | 594,752 / 594,800 / 594,800 | 579,520 / 579,568 / 579,568 | 579,448 / 579,496 / 579,496 |
| core-only | 10,000 | empty-batch | 12,488 / 12,488 / 12,488 | 11,816 / 11,816 / 11,816 | 11,816 / 11,816 / 11,816 |
| core-only | 10,000 | replace-one | 727,680 / 728,832 / 730,344 | 713,536 / 714,688 / 716,200 | 713,536 / 714,688 / 716,200 |
| positions-offsets | 1,000 | empty-batch | 15,984 / 15,984 / 15,984 | 15,312 / 15,312 / 15,312 | 15,312 / 15,312 / 15,312 |
| positions-offsets | 1,000 | replace-one | 773,536 / 774,632 / 774,632 | 757,344 / 758,440 / 758,440 | 757,344 / 758,440 / 758,440 |
| positions-offsets | 10,000 | empty-batch | 12,520 / 12,520 / 12,520 | 11,848 / 11,848 / 11,848 | 11,848 / 11,848 / 11,848 |
| positions-offsets | 10,000 | replace-one | 926,352 / 926,688 / 928,320 | 911,392 / 911,728 / 913,360 | 911,392 / 911,728 / 913,360 |
| source-phrase | 1,000 | empty-batch | 15,952 / 15,952 / 15,952 | 15,280 / 15,280 / 15,280 | 15,280 / 15,280 / 15,280 |
| source-phrase | 1,000 | replace-one | 736,600 / 749,880 / 749,944 | 720,408 / 733,688 / 733,752 | 720,408 / 733,688 / 733,752 |
| source-phrase | 10,000 | empty-batch | 12,520 / 12,520 / 12,520 | 11,848 / 11,848 / 11,848 | 11,848 / 11,848 / 11,848 |
| source-phrase | 10,000 | replace-one | 894,176 / 896,656 / 898,456 | 879,216 / 881,696 / 883,496 | 879,216 / 881,696 / 883,496 |

Scope: new monitored managed extents in the fixed calibrated allocation mode, including host/harness work. This is not exclusive staging, total process/physical memory, codec or browser-copy qualification.
