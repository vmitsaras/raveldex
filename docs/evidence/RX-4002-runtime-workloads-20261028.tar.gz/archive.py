import pathlib,hashlib,json,tarfile,gzip,io,stat
root=pathlib.Path('/tmp/raveldex-ac03-workloads-20261028.A7m1DC')
output=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex/docs/evidence/RX-4002-runtime-workloads-20261028.tar.gz')
names=[]
allowed={'.json','.jsonl','.log','.md','.py','.js','.mjs','.asm','.txt'}
for folder in ['discovery','mutations','review','executed-sources','browser-route','browser-control','browser-lldb-control','browser-close-smoke']:
    for path in (root/folder).rglob('*'):
        if path.is_file() and path.suffix in allowed and '__pycache__' not in path.parts and 'prior-archive-inputs' not in path.parts:names.append(path)
for path in root.iterdir():
    if path.is_file() and path.suffix in allowed:names.append(path)
records=[]
for path in sorted(set(names)):
    digest=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):digest.update(chunk)
    records.append({'name':str(path.relative_to(root)),'bytes':path.stat().st_size,'sha256':digest.hexdigest()})
manifest={'schema':'raveldex-ac03-workload-archive-v1','originalRoot':str(root),'scope':'Finite managed workload records and selected native browser calibration. Tool/runtime/browser binaries and install caches excluded; references and failures retained.','members':records}
raw=json.dumps(manifest,indent=2).encode()+b'\n'
with output.open('xb') as target:
    with gzip.GzipFile(filename='',mode='wb',fileobj=target,compresslevel=9,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as tar:
            info=tarfile.TarInfo('MANIFEST.json');info.size=len(raw);info.mode=0o600;tar.addfile(info,io.BytesIO(raw))
            for record in records:
                info=tarfile.TarInfo(record['name']);info.size=record['bytes'];info.mode=0o600
                with (root/record['name']).open('rb') as f:tar.addfile(info,f)
digest=hashlib.sha256()
with output.open('rb') as f:
    for chunk in iter(lambda:f.read(1024*1024),b''):digest.update(chunk)
summary={'path':str(output),'bytes':output.stat().st_size,'sha256':digest.hexdigest(),'members':len(records),'memberBytes':sum(r['bytes'] for r in records),'manifestSha256':hashlib.sha256(raw).hexdigest()}
with (root/'archive-summary.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary))
