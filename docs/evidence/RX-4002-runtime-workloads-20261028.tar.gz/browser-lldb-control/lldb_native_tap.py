# Task-owned LLDB observer: no target calls, payload reads or argument edits.
import lldb, json, pathlib, hashlib, time
ROOT=pathlib.Path('/tmp/raveldex-ac03-workloads-20261028.A7m1DC')
OUT=ROOT/'browser-lldb-control'
TARGET=None
BASE=0
BPS={}
ROLES={}
STATE={}
CALLS={}
LIVE={}
ACTIVE=False
LABEL=''
ROWS=[]
INVALID=[]
COUNTER=0
ALLOCATION=0
INSTALLED=False
RUN=0
DROPPED=0
MAX_ROWS=2048
MAX_BPS=192
TYPE=0

def reg(frame,name):
    value=frame.FindRegister(name)
    if not value.IsValid() or value.GetError().Fail():raise RuntimeError('register_unavailable:'+name)
    return value.GetValueAsUnsigned()
def event(kind,tid,**fields):
    global DROPPED
    if len(ROWS)>=MAX_ROWS:
        DROPPED+=1;problem('record_limit');return
    ROWS.append(dict(seq=len(ROWS)+1,kind=kind,tid=tid,wallNs=time.time_ns(),**fields))
def problem(reason):
    if len(INVALID)<128:INVALID.append(reason)
def add(ptr,cap,chain,origin,tid,confirmation=False):
    global ALLOCATION
    if not ptr:return
    if ptr in LIVE:
        old=LIVE[ptr]
        if not confirmation or old['chain']!=chain or old['origin']!='observed-copy-destination' or old['cap']!=cap:
            problem('live_pointer_collision');return
        event('buffer-confirmed',tid,ptr=ptr,cap=cap,chain=chain,allocation=old['allocation']);return
    if len(LIVE)>=256:problem('live_limit');return
    ALLOCATION+=1
    LIVE[ptr]=dict(cap=cap,chain=chain,origin=origin,allocation=ALLOCATION)
    event('buffer-live',tid,ptr=ptr,cap=cap,chain=chain,allocation=ALLOCATION,origin=origin)
def drop(ptr,allocation):
    if ptr in LIVE:
        if LIVE[ptr]['allocation']!=allocation:problem('free_birth_mismatch');return
        del LIVE[ptr]
def breakpoint(address,role=None):
    if role is not None:ROLES[address]=role
    if address in BPS:return
    if len(BPS)>=MAX_BPS:problem('breakpoint_limit');return
    bp=TARGET.BreakpointCreateByAddress(address);BPS[address]=bp
    if bp.GetNumLocations()!=1:raise RuntimeError('Unresolved breakpoint')
    error=bp.SetScriptCallbackFunction('lldb_native_tap.callback')
    if isinstance(error,lldb.SBError) and error.Fail():raise RuntimeError(error.GetCString())

def pending(frame,kind,fields,return_pc=None):
    tid=frame.GetThread().GetThreadID();pc=reg(frame,'lr') if return_pc is None else return_pc
    if not pc or pc>=2**53:problem('invalid_return_pc');return
    ctx=dict(kind=kind,sp=reg(frame,'sp'),returnPC=pc,**fields)
    CALLS.setdefault(tid,[]).append(ctx);breakpoint(pc)

def returned(frame,ctx):
    global COUNTER
    tid=frame.GetThread().GetThreadID();kind=ctx['kind']
    if kind=='realloc':
        dest=reg(frame,'x0');old=ctx['old'];cap=ctx['cap'];chain=ctx['chain']
        event('realloc-return',tid,old=old,dest=dest,cap=cap,chain=chain)
        if dest:
            if dest!=old and old in LIVE:
                event('api-only-retirement',tid,ptr=old,cap=LIVE[old]['cap'],chain=chain);drop(old,ctx['allocation'])
            if dest==old:
                data=LIVE.get(old)
                if not data or data['allocation']!=ctx['allocation']:problem('in_place_generation_mismatch')
                else:data['cap']=cap;event('buffer-resize',tid,ptr=dest,cap=cap,chain=chain,allocation=data['allocation'])
            else:add(dest,cap,chain,'realloc',tid,confirmation=dest in LIVE)
    elif kind in ('root-free','internal-free'):
        event(kind+'-return',tid,ptr=ctx['ptr'],cap=ctx['cap'],chain=ctx['chain'],allocation=ctx['allocation']);drop(ctx['ptr'],ctx['allocation'])
    elif kind=='alloc':
        ptr=reg(frame,'x0');event('buffer-alloc-return',tid,ptr=ptr,cap=ctx['cap'],chain=ctx['chain'],nested=ctx['nested'])
        if not ctx['nested']:add(ptr,ctx['cap'],ctx['chain'],'requested-buffer-alloc',tid)
    elif kind=='copy':
        event('copy-return',tid,src=ctx['src'],dest=ctx['dest'],length=ctx['length'],returned=reg(frame,'x0'),chain=ctx['chain'])
        if reg(frame,'x0')!=ctx['dest']:problem('copy_return_not_destination')

def callback(frame,bp_loc,internal_dict):
    global COUNTER
    if not ACTIVE:return False
    try:
        tid=frame.GetThread().GetThreadID();pc=frame.GetPC();sp=reg(frame,'sp');stack=CALLS.setdefault(tid,[])
        while stack and stack[-1]['returnPC']==pc and stack[-1]['sp']==sp:returned(frame,stack.pop())
        role=ROLES.get(pc)
        if role=='realloc' and reg(frame,'x3')==TYPE:
            old=reg(frame,'x1');cap=reg(frame,'x2');root=reg(frame,'x0')
            if cap>64*1024*1024:problem('capacity_limit');return False
            if any(c['kind']=='realloc' for c in stack):problem('nested_selected_realloc')
            if old and old not in LIVE:problem('unknown_old_buffer')
            COUNTER+=not bool(old)
            chain=LIVE.get(old,{}).get('chain',COUNTER)
            event('realloc-enter',tid,old=old,oldCap=LIVE.get(old,{}).get('cap',0),cap=cap,root=root,chain=chain)
            pending(frame,'realloc',dict(old=old,cap=cap,root=root,chain=chain,allocation=LIVE.get(old,{}).get('allocation',0)))
        elif role=='copy':
            owners=[c for c in stack if c['kind']=='realloc']
            if not owners:return False
            ctx=owners[-1];dest=reg(frame,'x0');src=reg(frame,'x1');length=reg(frame,'x2')
            if src!=ctx['old'] or src not in LIVE:problem('copy_without_selected_old');return False
            if not dest or dest==src or dest in LIVE:problem('copy_destination_collision');return False
            if length>ctx['cap']:problem('copy_length_exceeds_new_request');return False
            oldCap=LIVE[src]['cap'];event('copy-enter',tid,src=src,dest=dest,length=length,oldCap=oldCap,newCap=ctx['cap'],chain=ctx['chain'],site=0x17a173c)
            # The destination already exists at this executed native copy call.
            # Add it here, before old free, rather than only at API return.
            add(dest,ctx['cap'],ctx['chain'],'observed-copy-destination',tid)
            pending(frame,'copy',dict(src=src,dest=dest,length=length,chain=ctx['chain']),BASE+0x17a1740)
        elif role in ('root-free','internal-free'):
            ptr=reg(frame,'x1' if role=='root-free' else 'x0')
            if ptr not in LIVE:return False
            data=LIVE[ptr];event(role+'-enter',tid,ptr=ptr,cap=data['cap'],chain=data['chain'])
            pending(frame,role,dict(ptr=ptr,cap=data['cap'],chain=data['chain'],allocation=data['allocation']))
        elif role=='alloc' and reg(frame,'x2')==TYPE:
            cap=reg(frame,'x1');owners=[c for c in stack if c['kind']=='realloc'];nested=bool(owners)
            if cap>64*1024*1024:problem('capacity_limit');return False
            if nested:chain=owners[-1]['chain']
            else:COUNTER+=1;chain=COUNTER
            event('buffer-alloc-enter',tid,cap=cap,chain=chain,nested=nested)
            pending(frame,'alloc',dict(cap=cap,chain=chain,nested=nested))
    except Exception as error:problem(type(error).__name__+':'+str(error))
    return False

def install(debugger,command,result,internal_dict):
    global TARGET,BASE,TYPE,INSTALLED
    try:
        if INSTALLED or BPS:raise RuntimeError('Already installed')
        TARGET=debugger.GetSelectedTarget();process=TARGET.GetProcess()
        if process.GetProcessID()!=54501:raise RuntimeError('Wrong owned PID')
        manifest=json.loads((ROOT/'browser-route/headless-hook-candidates.json').read_text())
        modules=[m for m in TARGET.modules if str(m.file.fullpath)==manifest['binary']]
        if len(modules)!=1:raise RuntimeError('Wrong image')
        module=modules[0]
        if module.GetUUIDString().replace('-','').lower()!=manifest['uuid'].replace('-','').lower():raise RuntimeError('UUID mismatch')
        BASE=module.GetObjectFileHeaderAddress().GetLoadAddress(TARGET);TYPE=BASE+0x974695b
        for name in ['delegate_reallocate','pa_reallocate','pa_copy_call','buffer_free','root_free']:
            site=manifest['sites'][name];expected=bytes.fromhex(site['bytes_hex']);error=lldb.SBError();raw=process.ReadMemory(BASE+int(site['module_offset'],16),len(expected),error)
            if error.Fail() or raw!=expected:raise RuntimeError('Code bytes mismatch:'+name)
        for offset,expected_hex in [(0x1c36c,'ff8302d1fc6f04a9fa6705a9f85f06a9f65707a9f44f08a9fd7b09a9fd430291'),(0x17a244c,'fc6fbaa9fa6701a9f85f02a9f65703a9f44f04a9fd7b05a9fd430191f40300aa')]:
            expected=bytes.fromhex(expected_hex);error=lldb.SBError();raw=process.ReadMemory(BASE+offset,len(expected),error)
            if error.Fail() or raw!=expected:raise RuntimeError('Additional code bytes mismatch')
        for offset,role in [(0x17a1190,'realloc'),(0x17a173c,'copy'),(0x1d6d0,'root-free'),(0x17a244c,'internal-free'),(0x1c36c,'alloc')]:breakpoint(BASE+offset,role)
        (OUT/'lldb-install.json').write_text(json.dumps(dict(pid=process.GetProcessID(),base=BASE,uuid=module.GetUUIDString(),manifestSha256=hashlib.sha256((ROOT/'browser-route/headless-hook-candidates.json').read_bytes()).hexdigest(),roles=ROLES),indent=2)+'\n')
        INSTALLED=True
        result.PutCString('RX_NATIVE_INSTALLED '+str(BASE))
    except Exception as error:
        if TARGET is not None:
            for bp in list(BPS.values()):TARGET.BreakpointDelete(bp.GetID())
        BPS.clear();ROLES.clear();INSTALLED=False;TARGET=None;BASE=0;TYPE=0
        result.SetError(str(error))

def begin(debugger,command,result,internal_dict):
    global ACTIVE,LABEL,ROWS,INVALID,CALLS,LIVE,COUNTER,RUN,ALLOCATION,DROPPED
    if not INSTALLED:result.SetError('Observer not installed');return
    if ACTIVE:result.SetError('Already active');return
    if not command or len(command)>64 or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in command):result.SetError('Bad label');return
    LABEL=command;ROWS=[];INVALID=[];CALLS={};LIVE={};COUNTER=0;ALLOCATION=0;DROPPED=0;RUN+=1;ACTIVE=True
    result.PutCString('RX_NATIVE_BEGIN '+LABEL)

def end(debugger,command,result,internal_dict):
    global ACTIVE
    ACTIVE=False
    pending_calls={str(k):v for k,v in CALLS.items() if v}
    if pending_calls:problem('pending_native_calls')
    record=dict(schema='raveldex-lldb-buffer-observation-v1',pid=54501,label=LABEL,observerSha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),dropped=DROPPED,rows=ROWS,invalid=INVALID,remaining={str(k):v for k,v in LIVE.items()},pending=pending_calls,
      scopes=['API-reported/requested native buffer extents and executed selected grow-copy call; no OS physical pages or complete V8 string-copy coverage.','Native debugger stops perturb scheduling and time; no latency inference.','Buffers remaining at cutoff are right-censored; no fabricated final free.'])
    path=OUT/('tap-'+str(RUN)+'-'+LABEL+'.json')
    with path.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
    result.PutCString('RX_NATIVE_END '+str(path)+' rows='+str(len(ROWS))+' invalid='+str(len(INVALID)))

def cleanup(debugger,command,result,internal_dict):
    global ACTIVE,INSTALLED,TARGET,BASE,TYPE
    ACTIVE=False
    for bp in list(BPS.values()):TARGET.BreakpointDelete(bp.GetID())
    BPS.clear();ROLES.clear();CALLS.clear();LIVE.clear();INSTALLED=False;TARGET=None;BASE=0;TYPE=0
    result.PutCString('RX_NATIVE_HOOKS_REMOVED')

def __lldb_init_module(debugger,internal_dict):
    for name,fn in [('rx-install','install'),('rx-begin','begin'),('rx-end','end'),('rx-cleanup','cleanup')]:debugger.HandleCommand('command script add -f lldb_native_tap.'+fn+' '+name)
