import os,pty,subprocess,sys,select,signal,time,json,pathlib
root=pathlib.Path('/tmp/raveldex-ac03-workloads-20261028.A7m1DC/browser-lldb-control')
args=['/Library/Developer/CommandLineTools/usr/bin/lldb','--no-lldbinit','-p','54501','-o','command script import '+str(root/'lldb_native_tap.py'),'-o','rx-install']
master,slave=pty.openpty();started=time.monotonic();child=subprocess.Popen(args,stdin=slave,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
record={'schema':'raveldex-bounded-lldb-host-v1','ownedDebuggerPid':child.pid,'targetPid':54501,'command':args,'timeoutSeconds':300,'startedUnix':time.time()};timed=False;deadline=None
log=(root/'lldb-observer.log').open('xb')
def interrupt(signum,frame):
    try:os.killpg(child.pid,signal.SIGINT)
    except ProcessLookupError:pass
signal.signal(signal.SIGINT,interrupt)
try:
 while child.poll() is None:
    if not timed and time.monotonic()-started>300:
        timed=True;deadline=time.monotonic()+12;interrupt(None,None);time.sleep(.2);os.write(master,b'rx-end\nrx-cleanup\nprocess detach\nquit\n')
    if timed and time.monotonic()>deadline:
        os.killpg(child.pid,signal.SIGTERM);break
    ready,_,_=select.select([master,sys.stdin],[],[],.2)
    if master in ready:
        try:b=os.read(master,65536)
        except OSError:b=b''
        if b:log.write(b);log.flush();os.write(sys.stdout.fileno(),b)
    if sys.stdin in ready:
        b=os.read(sys.stdin.fileno(),4096)
        if not b:interrupt(None,None);os.write(master,b'rx-cleanup\nprocess detach\nquit\n');continue
        os.write(master,b)
 child.wait(timeout=8)
finally:
 if child.poll() is None:
    os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
 record.update(exitCode=child.returncode,timedOut=timed,finishedUnix=time.time());log.close();os.close(master)
 with (root/'lldb-observer-host.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
