
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010410f62c <__Z23_v8_internal_Node_PrintPv>:
107177f38: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
107177f3c: a9017bfd    	stp	x29, x30, [sp, #0x10]
107177f40: 910043fd    	add	x29, sp, #0x10
107177f44: aa0003f3    	mov	x19, x0
107177f48: f0018648    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
107177f4c: f946ed00    	ldr	x0, [x8, #0xdd8]
107177f50: f0012e62    	adrp	x2, 0x109746000 <dyld_stub_binder+0x109746000>
107177f54: 91256c42    	add	x2, x2, #0x95b
107177f58: aa1303e1    	mov	x1, x19
107177f5c: 963a9104    	bl	0x10001c36c <__text+0x1836c>
107177f60: b5000053    	cbnz	x19, 0x107177f68 <__Z23_v8_internal_Node_PrintPv+0x306893c>
107177f64: b50000a0    	cbnz	x0, 0x107177f78 <__Z23_v8_internal_Node_PrintPv+0x306894c>
107177f68: aa1303e1    	mov	x1, x19
107177f6c: a9417bfd    	ldp	x29, x30, [sp, #0x10]
107177f70: a8c24ff4    	ldp	x20, x19, [sp], #0x20
107177f74: d65f03c0    	ret
107177f78: d4200000    	brk	#0
107177f7c: d4400000    	hlt	#0
107177f80: d4200020    	brk	#0x1
