
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101733544 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action>:
1017a1140: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
1017a1144: a9014ff4    	stp	x20, x19, [sp, #0x10]
1017a1148: a9027bfd    	stp	x29, x30, [sp, #0x20]
1017a114c: 910083fd    	add	x29, sp, #0x20
1017a1150: aa0303f3    	mov	x19, x3
1017a1154: aa0103f4    	mov	x20, x1
1017a1158: b0045515    	adrp	x21, 0x10a242000 <dyld_stub_binder+0x10a242000>
1017a115c: f946eea0    	ldr	x0, [x21, #0xdd8]
1017a1160: aa0203e1    	mov	x1, x2
1017a1164: 97a3f974    	bl	0x10009f734 <_cxxbridge1$slice$new+0x59c58>
1017a1168: aa0003e2    	mov	x2, x0
1017a116c: f9000260    	str	x0, [x19]
1017a1170: f946eea0    	ldr	x0, [x21, #0xdd8]
1017a1174: b003fd23    	adrp	x3, 0x109746000 <dyld_stub_binder+0x109746000>
1017a1178: 91256c63    	add	x3, x3, #0x95b
1017a117c: aa1403e1    	mov	x1, x20
1017a1180: a9427bfd    	ldp	x29, x30, [sp, #0x20]
1017a1184: a9414ff4    	ldp	x20, x19, [sp, #0x10]
1017a1188: a8c357f6    	ldp	x22, x21, [sp], #0x30
1017a118c: 14000001    	b	0x1017a1190 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dc4c>
1017a1190: d10303ff    	sub	sp, sp, #0xc0
1017a1194: a9066ffc    	stp	x28, x27, [sp, #0x60]
1017a1198: a90767fa    	stp	x26, x25, [sp, #0x70]
1017a119c: a9085ff8    	stp	x24, x23, [sp, #0x80]
1017a11a0: a90957f6    	stp	x22, x21, [sp, #0x90]
1017a11a4: a90a4ff4    	stp	x20, x19, [sp, #0xa0]
1017a11a8: a90b7bfd    	stp	x29, x30, [sp, #0xb0]
1017a11ac: 9102c3fd    	add	x29, sp, #0xb0
1017a11b0: aa0203f5    	mov	x21, x2
1017a11b4: aa0003f3    	mov	x19, x0
1017a11b8: f0040c88    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
1017a11bc: f9401108    	ldr	x8, [x8, #0x20]
1017a11c0: f9400108    	ldr	x8, [x8]
1017a11c4: f9002fe8    	str	x8, [sp, #0x58]
1017a11c8: b5001341    	cbnz	x1, 0x1017a1430 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6deec>
1017a11cc: f10006bf    	cmp	x21, #0x1
1017a11d0: 9a9f86a8    	csinc	x8, x21, xzr, hi
1017a11d4: b9408269    	ldr	w9, [x19, #0x80]
1017a11d8: 8b090116    	add	x22, x8, x9
1017a11dc: eb1502df    	cmp	x22, x21
1017a11e0: 540042e3    	b.lo	0x1017a1a3c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e4f8>
1017a11e4: f0040c99    	adrp	x25, 0x109934000 <dyld_stub_binder+0x109934000>
1017a11e8: f9406339    	ldr	x25, [x25, #0xc0]
1017a11ec: b9400328    	ldr	w8, [x25]
1017a11f0: 39400269    	ldrb	w9, [x19]
1017a11f4: 350065a9    	cbnz	w9, 0x1017a1ea8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e964>
1017a11f8: 510006c9    	sub	w9, w22, #0x1
1017a11fc: 53047d29    	lsr	w9, w9, #4
1017a1200: dac012ca    	clz	x10, x22
1017a1204: 5280078b    	mov	w11, #0x3c              ; =60
1017a1208: 4b0a016b    	sub	w11, w11, w10
1017a120c: 9acb2ecb    	ror	x11, x22, x11
1017a1210: 9240096c    	and	x12, x11, #0x7
1017a1214: cb0a0d8a    	sub	x10, x12, x10, lsl #3
1017a1218: f1003d7f    	cmp	x11, #0xf
1017a121c: 9a8a954a    	cinc	x10, x10, hi
1017a1220: 91071d4a    	add	x10, x10, #0x1c7
1017a1224: 52800deb    	mov	w11, #0x6f              ; =111
1017a1228: f101bd5f    	cmp	x10, #0x6f
1017a122c: 9a8b314a    	csel	x10, x10, x11, lo
1017a1230: f10002df    	cmp	x22, #0x0
1017a1234: 1a8903e9    	csel	w9, wzr, w9, eq
1017a1238: f10406df    	cmp	x22, #0x101
1017a123c: 1a8a3129    	csel	w9, w9, w10, lo
1017a1240: 12003d2a    	and	w10, w9, #0xffff
1017a1244: f103fedf    	cmp	x22, #0xff
1017a1248: 52800dcb    	mov	w11, #0x6e              ; =110
1017a124c: 7a4b8142    	ccmp	w10, w11, #0x2, hi
1017a1250: 1a9f27ea    	cset	w10, lo
1017a1254: 2a090154    	orr	w20, w10, w9
1017a1258: 11000908    	add	w8, w8, #0x2
1017a125c: 52800029    	mov	w9, #0x1                ; =1
1017a1260: 1ac82128    	lsl	w8, w9, w8
1017a1264: 93407d17    	sxtw	x23, w8
1017a1268: 39009fff    	strb	wzr, [sp, #0x27]
1017a126c: 39400668    	ldrb	w8, [x19, #0x1]
1017a1270: 35003328    	cbnz	w8, 0x1017a18d4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e390>
1017a1274: d2800015    	mov	x21, #0x0               ; =0
1017a1278: 5280003a    	mov	w26, #0x1               ; =1
1017a127c: 12003e88    	and	w8, w20, #0xffff
1017a1280: 7101bd1f    	cmp	w8, #0x6f
1017a1284: 54004d48    	b.hi	0x1017a1c2c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6e8>
1017a1288: 92403e88    	and	x8, x20, #0xffff
1017a128c: 52800609    	mov	w9, #0x30               ; =48
1017a1290: 9ba94d08    	umaddl	x8, w8, w9, x19
1017a1294: 91042118    	add	x24, x8, #0x108
1017a1298: 91040260    	add	x0, x19, #0x100
1017a129c: 95d2dbcf    	bl	0x108c581d8 <dyld_stub_binder+0x108c581d8>
1017a12a0: 36003000    	tbz	w0, #0x0, 0x1017a18a0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e35c>
1017a12a4: f9400308    	ldr	x8, [x24]
1017a12a8: f90017e8    	str	x8, [sp, #0x28]
1017a12ac: b9400329    	ldr	w9, [x25]
1017a12b0: 11000929    	add	w9, w9, #0x2
1017a12b4: 5280002a    	mov	w10, #0x1               ; =1
1017a12b8: 1ac92149    	lsl	w9, w10, w9
1017a12bc: 6b0902ff    	cmp	w23, w9
1017a12c0: 54002b88    	b.hi	0x1017a1830 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e2ec>
1017a12c4: f9400114    	ldr	x20, [x8]
1017a12c8: b4002b54    	cbz	x20, 0x1017a1830 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e2ec>
1017a12cc: 39009fff    	strb	wzr, [sp, #0x27]
1017a12d0: f0040c8a    	adrp	x10, 0x109934000 <dyld_stub_binder+0x109934000>
1017a12d4: f940694a    	ldr	x10, [x10, #0xd0]
1017a12d8: f940014a    	ldr	x10, [x10]
1017a12dc: cb0a03ea    	neg	x10, x10
1017a12e0: 8a08014a    	and	x10, x10, x8
1017a12e4: f940014a    	ldr	x10, [x10]
1017a12e8: f95b5d4b    	ldr	x11, [x10, #0x36b8]
1017a12ec: ca0a016a    	eor	x10, x11, x10
1017a12f0: b100055f    	cmn	x10, #0x1
1017a12f4: 54004a61    	b.ne	0x1017a1c40 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6fc>
1017a12f8: b9401b16    	ldr	w22, [x24, #0x18]
1017a12fc: b940826a    	ldr	w10, [x19, #0x80]
1017a1300: f9400282    	ldr	x2, [x20]
1017a1304: b4000922    	cbz	x2, 0x1017a1428 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dee4>
1017a1308: 925e768b    	and	x11, x20, #0xfffffffc00000000
1017a130c: f0043d8c    	adrp	x12, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1310: f945c58c    	ldr	x12, [x12, #0xb88]
1017a1314: eb0c017f    	cmp	x11, x12
1017a1318: 54004c41    	b.ne	0x1017a1ca0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e75c>
1017a131c: b25e77ec    	mov	x12, #-0x400000000      ; =-17179869184
1017a1320: dac00c4d    	rev	x13, x2
1017a1324: ea0d019f    	tst	x12, x13
1017a1328: 540046e1    	b.ne	0x1017a1c04 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6c0>
1017a132c: aa0d016b    	orr	x11, x11, x13
1017a1330: f940068c    	ldr	x12, [x20, #0x8]
1017a1334: ca02018c    	eor	x12, x12, x2
1017a1338: 9240516d    	and	x13, x11, #0x1fffff
1017a133c: ca14016e    	eor	x14, x11, x20
1017a1340: eb29c1bf    	cmp	x13, w9, sxtw
1017a1344: d355fdc9    	lsr	x9, x14, #21
1017a1348: fa402920    	ccmp	x9, #0x0, #0x0, hs
1017a134c: ba410980    	ccmn	x12, #0x1, #0x0, eq
1017a1350: 540043c1    	b.ne	0x1017a1bc8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e684>
1017a1354: f9800160    	prfm	pldl1keep, [x11]
1017a1358: cb0a02d7    	sub	x23, x22, x10
1017a135c: f900010b    	str	x11, [x8]
1017a1360: b9401909    	ldr	w9, [x8, #0x18]
1017a1364: 1100052a    	add	w10, w9, #0x1
1017a1368: 33003949    	bfxil	w9, w10, #0, #15
1017a136c: b9001909    	str	w9, [x8, #0x18]
1017a1370: f9400908    	ldr	x8, [x8, #0x10]
1017a1374: b9401916    	ldr	w22, [x8, #0x18]
1017a1378: 91040260    	add	x0, x19, #0x100
1017a137c: 95d2db94    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a1380: b4000374    	cbz	x20, 0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a1384: 5282c608    	mov	w8, #0x1630             ; =5680
1017a1388: 8b080268    	add	x8, x19, x8
1017a138c: f8360108    	ldadd	x22, x8, [x8]
1017a1390: 8b160108    	add	x8, x8, x22
1017a1394: 5282c709    	mov	w9, #0x1638             ; =5688
1017a1398: 8b090269    	add	x9, x19, x9
1017a139c: f94b1e6a    	ldr	x10, [x19, #0x1638]
1017a13a0: eb08015f    	cmp	x10, x8
1017a13a4: 9a88814b    	csel	x11, x10, x8, hi
1017a13a8: aa0a03ec    	mov	x12, x10
1017a13ac: c8ac7d2b    	cas	x12, x11, [x9]
1017a13b0: eb0a019f    	cmp	x12, x10
1017a13b4: 54ffff41    	b.ne	0x1017a139c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6de58>
1017a13b8: 360030fa    	tbz	w26, #0x0, 0x1017a19d4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e490>
1017a13bc: 39404268    	ldrb	w8, [x19, #0x10]
1017a13c0: 34000168    	cbz	w8, 0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a13c4: f0040c88    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
1017a13c8: f9406908    	ldr	x8, [x8, #0xd0]
1017a13cc: f9400108    	ldr	x8, [x8]
1017a13d0: d1000509    	sub	x9, x8, #0x1
1017a13d4: ea14013f    	tst	x9, x20
1017a13d8: 540026a0    	b.eq	0x1017a18ac <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e368>
1017a13dc: 8b160288    	add	x8, x20, x22
1017a13e0: d1001108    	sub	x8, x8, #0x4
1017a13e4: 52800029    	mov	w9, #0x1                ; =1
1017a13e8: b9000109    	str	w9, [x8]
1017a13ec: f9402fe8    	ldr	x8, [sp, #0x58]
1017a13f0: f0040c89    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
1017a13f4: f9401129    	ldr	x9, [x9, #0x20]
1017a13f8: f9400129    	ldr	x9, [x9]
1017a13fc: eb08013f    	cmp	x9, x8
1017a1400: 540031c1    	b.ne	0x1017a1a38 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e4f4>
1017a1404: aa1403e0    	mov	x0, x20
1017a1408: a94b7bfd    	ldp	x29, x30, [sp, #0xb0]
1017a140c: a94a4ff4    	ldp	x20, x19, [sp, #0xa0]
1017a1410: a94957f6    	ldp	x22, x21, [sp, #0x90]
1017a1414: a9485ff8    	ldp	x24, x23, [sp, #0x80]
1017a1418: a94767fa    	ldp	x26, x25, [sp, #0x70]
1017a141c: a9466ffc    	ldp	x28, x27, [sp, #0x60]
1017a1420: 910303ff    	add	sp, sp, #0xc0
1017a1424: d65f03c0    	ret
1017a1428: d280000b    	mov	x11, #0x0               ; =0
1017a142c: 17ffffcb    	b	0x1017a1358 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6de14>
1017a1430: aa0103f4    	mov	x20, x1
1017a1434: b4003ff5    	cbz	x21, 0x1017a1c30 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6ec>
1017a1438: 52affc08    	mov	w8, #0x7fe00000         ; =2145386496
1017a143c: eb0802bf    	cmp	x21, x8
1017a1440: 54003fc8    	b.hi	0x1017a1c38 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6f4>
1017a1444: 925e7688    	and	x8, x20, #0xfffffffc00000000
1017a1448: f0043d9c    	adrp	x28, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a144c: f945c789    	ldr	x9, [x28, #0xb88]
1017a1450: eb09011f    	cmp	x8, x9
1017a1454: 54004141    	b.ne	0x1017a1c7c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e738>
1017a1458: 52800048    	mov	w8, #0x2                ; =2
1017a145c: f0043d9b    	adrp	x27, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1460: 912e037b    	add	x27, x27, #0xb80
1017a1464: 8b080f68    	add	x8, x27, x8, lsl #3
1017a1468: f9401108    	ldr	x8, [x8, #0x20]
1017a146c: 926baa89    	and	x9, x20, #0xffffffffffe00000
1017a1470: 9240528a    	and	x10, x20, #0x1fffff
1017a1474: f0040c98    	adrp	x24, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1478: f9406318    	ldr	x24, [x24, #0xc0]
1017a147c: b980030b    	ldrsw	x11, [x24]
1017a1480: 9100096b    	add	x11, x11, #0x2
1017a1484: 9acb254a    	lsr	x10, x10, x11
1017a1488: 8b090108    	add	x8, x8, x9
1017a148c: 8b0a1508    	add	x8, x8, x10, lsl #5
1017a1490: 39407909    	ldrb	w9, [x8, #0x1e]
1017a1494: 92401529    	and	x9, x9, #0x3f
1017a1498: cb091516    	sub	x22, x8, x9, lsl #5
1017a149c: f0040c99    	adrp	x25, 0x109934000 <dyld_stub_binder+0x109934000>
1017a14a0: f9406b39    	ldr	x25, [x25, #0xd0]
1017a14a4: f9400328    	ldr	x8, [x25]
1017a14a8: cb0803e8    	neg	x8, x8
1017a14ac: 8a0802c8    	and	x8, x22, x8
1017a14b0: f9400117    	ldr	x23, [x8]
1017a14b4: 910402e0    	add	x0, x23, #0x100
1017a14b8: 95d2db48    	bl	0x108c581d8 <dyld_stub_binder+0x108c581d8>
1017a14bc: 36003c80    	tbz	w0, #0x0, 0x1017a1c4c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e708>
1017a14c0: f9400328    	ldr	x8, [x25]
1017a14c4: cb0803e8    	neg	x8, x8
1017a14c8: 8a160108    	and	x8, x8, x22
1017a14cc: f9400108    	ldr	x8, [x8]
1017a14d0: f95b5d09    	ldr	x9, [x8, #0x36b8]
1017a14d4: ca080128    	eor	x8, x9, x8
1017a14d8: b100051f    	cmn	x8, #0x1
1017a14dc: 54003be1    	b.ne	0x1017a1c58 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e714>
1017a14e0: b9401ac8    	ldr	w8, [x22, #0x18]
1017a14e4: 37f83c08    	tbnz	w8, #0x1f, 0x1017a1c64 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e720>
1017a14e8: f9400ac8    	ldr	x8, [x22, #0x10]
1017a14ec: b9401919    	ldr	w25, [x8, #0x18]
1017a14f0: b94082e9    	ldr	w9, [x23, #0x80]
1017a14f4: f9000be9    	str	x9, [sp, #0x10]
1017a14f8: 39407108    	ldrb	w8, [x8, #0x1c]
1017a14fc: 34005088    	cbz	w8, 0x1017a1f0c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e9c8>
1017a1500: 910402e0    	add	x0, x23, #0x100
1017a1504: 95d2db32    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a1508: aa1703e0    	mov	x0, x23
1017a150c: aa1403e1    	mov	x1, x20
1017a1510: aa1603e2    	mov	x2, x22
1017a1514: aa1503e3    	mov	x3, x21
1017a1518: 94000376    	bl	0x1017a22f0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6edac>
1017a151c: 3707f680    	tbnz	w0, #0x0, 0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a1520: b9400308    	ldr	w8, [x24]
1017a1524: b9408269    	ldr	w9, [x19, #0x80]
1017a1528: 8b0902b8    	add	x24, x21, x9
1017a152c: 39400269    	ldrb	w9, [x19]
1017a1530: f9000ff9    	str	x25, [sp, #0x18]
1017a1534: 35005189    	cbnz	w9, 0x1017a1f64 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ea20>
1017a1538: 51000709    	sub	w9, w24, #0x1
1017a153c: 53047d29    	lsr	w9, w9, #4
1017a1540: dac0130a    	clz	x10, x24
1017a1544: 5280078b    	mov	w11, #0x3c              ; =60
1017a1548: 4b0a016b    	sub	w11, w11, w10
1017a154c: 9acb2f0b    	ror	x11, x24, x11
1017a1550: 9240096c    	and	x12, x11, #0x7
1017a1554: cb0a0d8a    	sub	x10, x12, x10, lsl #3
1017a1558: f1003d7f    	cmp	x11, #0xf
1017a155c: 9a8a954a    	cinc	x10, x10, hi
1017a1560: 91071d4a    	add	x10, x10, #0x1c7
1017a1564: 52800deb    	mov	w11, #0x6f              ; =111
1017a1568: f101bd5f    	cmp	x10, #0x6f
1017a156c: 9a8b314a    	csel	x10, x10, x11, lo
1017a1570: f104071f    	cmp	x24, #0x101
1017a1574: 1a8a3129    	csel	w9, w9, w10, lo
1017a1578: 12003d2a    	and	w10, w9, #0xffff
1017a157c: f103ff1f    	cmp	x24, #0xff
1017a1580: 52800dcb    	mov	w11, #0x6e              ; =110
1017a1584: 7a4b8142    	ccmp	w10, w11, #0x2, hi
1017a1588: 1a9f27ea    	cset	w10, lo
1017a158c: 2a090157    	orr	w23, w10, w9
1017a1590: 11000908    	add	w8, w8, #0x2
1017a1594: 52800029    	mov	w9, #0x1                ; =1
1017a1598: 1ac82128    	lsl	w8, w9, w8
1017a159c: 93407d19    	sxtw	x25, w8
1017a15a0: 39009fff    	strb	wzr, [sp, #0x27]
1017a15a4: 39400668    	ldrb	w8, [x19, #0x1]
1017a15a8: 35003968    	cbnz	w8, 0x1017a1cd4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e790>
1017a15ac: f90007ff    	str	xzr, [sp, #0x8]
1017a15b0: 52800036    	mov	w22, #0x1               ; =1
1017a15b4: 12003ee8    	and	w8, w23, #0xffff
1017a15b8: 7101bd1f    	cmp	w8, #0x6f
1017a15bc: 54003388    	b.hi	0x1017a1c2c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6e8>
1017a15c0: 92403ee8    	and	x8, x23, #0xffff
1017a15c4: 52800609    	mov	w9, #0x30               ; =48
1017a15c8: 9ba94d08    	umaddl	x8, w8, w9, x19
1017a15cc: 9104211b    	add	x27, x8, #0x108
1017a15d0: 9104027a    	add	x26, x19, #0x100
1017a15d4: 91040260    	add	x0, x19, #0x100
1017a15d8: 95d2db00    	bl	0x108c581d8 <dyld_stub_binder+0x108c581d8>
1017a15dc: 360034a0    	tbz	w0, #0x0, 0x1017a1c70 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e72c>
1017a15e0: f9400368    	ldr	x8, [x27]
1017a15e4: f90017e8    	str	x8, [sp, #0x28]
1017a15e8: f0040c89    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
1017a15ec: f9406129    	ldr	x9, [x9, #0xc0]
1017a15f0: b9400129    	ldr	w9, [x9]
1017a15f4: 11000929    	add	w9, w9, #0x2
1017a15f8: 5280002a    	mov	w10, #0x1               ; =1
1017a15fc: 1ac92149    	lsl	w9, w10, w9
1017a1600: 6b09033f    	cmp	w25, w9
1017a1604: 54000aa8    	b.hi	0x1017a1758 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e214>
1017a1608: f9400117    	ldr	x23, [x8]
1017a160c: b4000a77    	cbz	x23, 0x1017a1758 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e214>
1017a1610: 39009fff    	strb	wzr, [sp, #0x27]
1017a1614: f0040c9a    	adrp	x26, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1618: f9406b5a    	ldr	x26, [x26, #0xd0]
1017a161c: f940034a    	ldr	x10, [x26]
1017a1620: cb0a03ea    	neg	x10, x10
1017a1624: 8a08014a    	and	x10, x10, x8
1017a1628: f940014a    	ldr	x10, [x10]
1017a162c: f95b5d4b    	ldr	x11, [x10, #0x36b8]
1017a1630: ca0a016a    	eor	x10, x11, x10
1017a1634: b100055f    	cmn	x10, #0x1
1017a1638: 540032e1    	b.ne	0x1017a1c94 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e750>
1017a163c: b9401b78    	ldr	w24, [x27, #0x18]
1017a1640: b940826a    	ldr	w10, [x19, #0x80]
1017a1644: f94002e2    	ldr	x2, [x23]
1017a1648: b4000842    	cbz	x2, 0x1017a1750 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e20c>
1017a164c: 925e76eb    	and	x11, x23, #0xfffffffc00000000
1017a1650: f945c78c    	ldr	x12, [x28, #0xb88]
1017a1654: eb0c017f    	cmp	x11, x12
1017a1658: 540046c1    	b.ne	0x1017a1f30 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e9ec>
1017a165c: b25e77ec    	mov	x12, #-0x400000000      ; =-17179869184
1017a1660: dac00c4d    	rev	x13, x2
1017a1664: ea0d019f    	tst	x12, x13
1017a1668: 540041c1    	b.ne	0x1017a1ea0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e95c>
1017a166c: aa0d016b    	orr	x11, x11, x13
1017a1670: f94006ec    	ldr	x12, [x23, #0x8]
1017a1674: ca02018c    	eor	x12, x12, x2
1017a1678: 9240516d    	and	x13, x11, #0x1fffff
1017a167c: ca17016e    	eor	x14, x11, x23
1017a1680: eb29c1bf    	cmp	x13, w9, sxtw
1017a1684: d355fdc9    	lsr	x9, x14, #21
1017a1688: fa402920    	ccmp	x9, #0x0, #0x0, hs
1017a168c: ba410980    	ccmn	x12, #0x1, #0x0, eq
1017a1690: 54003ea1    	b.ne	0x1017a1e64 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e920>
1017a1694: f9800160    	prfm	pldl1keep, [x11]
1017a1698: cb0a0319    	sub	x25, x24, x10
1017a169c: f900010b    	str	x11, [x8]
1017a16a0: b9401909    	ldr	w9, [x8, #0x18]
1017a16a4: 1100052a    	add	w10, w9, #0x1
1017a16a8: 33003949    	bfxil	w9, w10, #0, #15
1017a16ac: b9001909    	str	w9, [x8, #0x18]
1017a16b0: f9400908    	ldr	x8, [x8, #0x10]
1017a16b4: b9401918    	ldr	w24, [x8, #0x18]
1017a16b8: 91040260    	add	x0, x19, #0x100
1017a16bc: 95d2dac4    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a16c0: b4002bd7    	cbz	x23, 0x1017a1c38 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6f4>
1017a16c4: 5282c608    	mov	w8, #0x1630             ; =5680
1017a16c8: 8b080268    	add	x8, x19, x8
1017a16cc: f8380108    	ldadd	x24, x8, [x8]
1017a16d0: 8b180108    	add	x8, x8, x24
1017a16d4: 5282c709    	mov	w9, #0x1638             ; =5688
1017a16d8: 8b090269    	add	x9, x19, x9
1017a16dc: f94b1e6a    	ldr	x10, [x19, #0x1638]
1017a16e0: eb08015f    	cmp	x10, x8
1017a16e4: 9a88814b    	csel	x11, x10, x8, hi
1017a16e8: aa0a03ec    	mov	x12, x10
1017a16ec: c8ac7d2b    	cas	x12, x11, [x9]
1017a16f0: eb0a019f    	cmp	x12, x10
1017a16f4: 54ffff41    	b.ne	0x1017a16dc <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e198>
1017a16f8: 36003996    	tbz	w22, #0x0, 0x1017a1e28 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e8e4>
1017a16fc: a94123e9    	ldp	x9, x8, [sp, #0x10]
1017a1700: cb090108    	sub	x8, x8, x9
1017a1704: 39404269    	ldrb	w9, [x19, #0x10]
1017a1708: 34000129    	cbz	w9, 0x1017a172c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e1e8>
1017a170c: f9400349    	ldr	x9, [x26]
1017a1710: d100052a    	sub	x10, x9, #0x1
1017a1714: ea17015f    	tst	x10, x23
1017a1718: 54000740    	b.eq	0x1017a1800 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e2bc>
1017a171c: 8b1802e9    	add	x9, x23, x24
1017a1720: d1001129    	sub	x9, x9, #0x4
1017a1724: 5280002a    	mov	w10, #0x1               ; =1
1017a1728: b900012a    	str	w10, [x9]
1017a172c: eb0802bf    	cmp	x21, x8
1017a1730: 9a8832a2    	csel	x2, x21, x8, lo
1017a1734: aa1703e0    	mov	x0, x23
1017a1738: aa1403e1    	mov	x1, x20
1017a173c: 95d2da9b    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
1017a1740: aa1403e0    	mov	x0, x20
1017a1744: 94000342    	bl	0x1017a244c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ef08>
1017a1748: aa1703f4    	mov	x20, x23
1017a174c: 17ffff28    	b	0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a1750: d280000b    	mov	x11, #0x0               ; =0
1017a1754: 17ffffd1    	b	0x1017a1698 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e154>
1017a1758: 9100a3e5    	add	x5, sp, #0x28
1017a175c: 91009fe6    	add	x6, sp, #0x27
1017a1760: aa1b03e0    	mov	x0, x27
1017a1764: aa1303e1    	mov	x1, x19
1017a1768: 52800022    	mov	w2, #0x1                ; =1
1017a176c: aa1803e3    	mov	x3, x24
1017a1770: aa1903e4    	mov	x4, x25
1017a1774: 97a2038c    	bl	0x1000225a4 <__text+0x1e5a4>
1017a1778: b40046c0    	cbz	x0, 0x1017a2050 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb0c>
1017a177c: f94017e8    	ldr	x8, [sp, #0x28]
1017a1780: f0040c9a    	adrp	x26, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1784: f9406b5a    	ldr	x26, [x26, #0xd0]
1017a1788: f9400349    	ldr	x9, [x26]
1017a178c: cb0903e9    	neg	x9, x9
1017a1790: 8a080129    	and	x9, x9, x8
1017a1794: f9400129    	ldr	x9, [x9]
1017a1798: f95b5d2a    	ldr	x10, [x9, #0x36b8]
1017a179c: ca090149    	eor	x9, x10, x9
1017a17a0: b100053f    	cmn	x9, #0x1
1017a17a4: 54004501    	b.ne	0x1017a2044 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb00>
1017a17a8: aa0003f7    	mov	x23, x0
1017a17ac: b9401909    	ldr	w9, [x8, #0x18]
1017a17b0: 37f84469    	tbnz	w9, #0x1f, 0x1017a203c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eaf8>
1017a17b4: f9400909    	ldr	x9, [x8, #0x10]
1017a17b8: b9401929    	ldr	w9, [x9, #0x18]
1017a17bc: b940826a    	ldr	w10, [x19, #0x80]
1017a17c0: cb0a0139    	sub	x25, x9, x10
1017a17c4: 17ffffbb    	b	0x1017a16b0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e16c>
1017a17c8: 5282c608    	mov	w8, #0x1630             ; =5680
1017a17cc: 8b080268    	add	x8, x19, x8
1017a17d0: f8360108    	ldadd	x22, x8, [x8]
1017a17d4: 8b160108    	add	x8, x8, x22
1017a17d8: 5282c709    	mov	w9, #0x1638             ; =5688
1017a17dc: 8b090269    	add	x9, x19, x9
1017a17e0: f94b1e6a    	ldr	x10, [x19, #0x1638]
1017a17e4: eb08015f    	cmp	x10, x8
1017a17e8: 9a88814b    	csel	x11, x10, x8, hi
1017a17ec: aa0a03ec    	mov	x12, x10
1017a17f0: c8ac7d2b    	cas	x12, x11, [x9]
1017a17f4: eb0a019f    	cmp	x12, x10
1017a17f8: 54ffff41    	b.ne	0x1017a17e0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e29c>
1017a17fc: 14000076    	b	0x1017a19d4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e490>
1017a1800: 926baaea    	and	x10, x23, #0xffffffffffe00000
1017a1804: 8b090549    	add	x9, x10, x9, lsl #1
1017a1808: 924052ea    	and	x10, x23, #0x1fffff
1017a180c: f0040c8b    	adrp	x11, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1810: f940616b    	ldr	x11, [x11, #0xc0]
1017a1814: b980016b    	ldrsw	x11, [x11]
1017a1818: 9acb254a    	lsr	x10, x10, x11
1017a181c: d37ff96b    	lsl	x11, x11, #1
1017a1820: d1005d6b    	sub	x11, x11, #0x17
1017a1824: 9acb214a    	lsl	x10, x10, x11
1017a1828: 8b0a0929    	add	x9, x9, x10, lsl #2
1017a182c: 17ffffbe    	b	0x1017a1724 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e1e0>
1017a1830: 9100a3e5    	add	x5, sp, #0x28
1017a1834: 91009fe6    	add	x6, sp, #0x27
1017a1838: aa1803e0    	mov	x0, x24
1017a183c: aa1303e1    	mov	x1, x19
1017a1840: 52800022    	mov	w2, #0x1                ; =1
1017a1844: aa1603e3    	mov	x3, x22
1017a1848: aa1703e4    	mov	x4, x23
1017a184c: 97a20356    	bl	0x1000225a4 <__text+0x1e5a4>
1017a1850: aa0003f4    	mov	x20, x0
1017a1854: b4003ee0    	cbz	x0, 0x1017a2030 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eaec>
1017a1858: f94017e8    	ldr	x8, [sp, #0x28]
1017a185c: f0040c89    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1860: f9406929    	ldr	x9, [x9, #0xd0]
1017a1864: f9400129    	ldr	x9, [x9]
1017a1868: cb0903e9    	neg	x9, x9
1017a186c: 8a080129    	and	x9, x9, x8
1017a1870: f9400129    	ldr	x9, [x9]
1017a1874: f95b5d2a    	ldr	x10, [x9, #0x36b8]
1017a1878: ca090149    	eor	x9, x10, x9
1017a187c: b100053f    	cmn	x9, #0x1
1017a1880: 54003f21    	b.ne	0x1017a2064 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb20>
1017a1884: b9401909    	ldr	w9, [x8, #0x18]
1017a1888: 37f83ea9    	tbnz	w9, #0x1f, 0x1017a205c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb18>
1017a188c: f9400909    	ldr	x9, [x8, #0x10]
1017a1890: b9401929    	ldr	w9, [x9, #0x18]
1017a1894: b940826a    	ldr	w10, [x19, #0x80]
1017a1898: cb0a0137    	sub	x23, x9, x10
1017a189c: 17fffeb5    	b	0x1017a1370 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6de2c>
1017a18a0: 91040260    	add	x0, x19, #0x100
1017a18a4: 97a20729    	bl	0x100023548 <__text+0x1f548>
1017a18a8: 17fffe7f    	b	0x1017a12a4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dd60>
1017a18ac: 926baa89    	and	x9, x20, #0xffffffffffe00000
1017a18b0: 8b080528    	add	x8, x9, x8, lsl #1
1017a18b4: 92405289    	and	x9, x20, #0x1fffff
1017a18b8: b980032a    	ldrsw	x10, [x25]
1017a18bc: 9aca2529    	lsr	x9, x9, x10
1017a18c0: d37ff94a    	lsl	x10, x10, #1
1017a18c4: d1005d4a    	sub	x10, x10, #0x17
1017a18c8: 9aca2129    	lsl	x9, x9, x10
1017a18cc: 8b090908    	add	x8, x8, x9, lsl #2
1017a18d0: 17fffec5    	b	0x1017a13e4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea0>
1017a18d4: f9400675    	ldr	x21, [x19, #0x8]
1017a18d8: 90045008    	adrp	x8, 0x10a1a1000 <dyld_stub_binder+0x10a1a1000>
1017a18dc: f9449500    	ldr	x0, [x8, #0x928]
1017a18e0: 95d2da41    	bl	0x108c581e4 <dyld_stub_binder+0x108c581e4>
1017a18e4: f100081f    	cmp	x0, #0x2
1017a18e8: 54001923    	b.lo	0x1017a1c0c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6c8>
1017a18ec: 5280bc08    	mov	w8, #0x5e0              ; =1504
1017a18f0: 9b0802b5    	madd	x21, x21, x8, x0
1017a18f4: b40018d5    	cbz	x21, 0x1017a1c0c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6c8>
1017a18f8: f94286a8    	ldr	x8, [x21, #0x508]
1017a18fc: b4001888    	cbz	x8, 0x1017a1c0c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6c8>
1017a1900: b9400328    	ldr	w8, [x25]
1017a1904: 11000908    	add	w8, w8, #0x2
1017a1908: 52800029    	mov	w9, #0x1                ; =1
1017a190c: 1ac82128    	lsl	w8, w9, w8
1017a1910: 6b0802ff    	cmp	w23, w8
1017a1914: 54001888    	b.hi	0x1017a1c24 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6e0>
1017a1918: 92403e98    	and	x24, x20, #0xffff
1017a191c: f9400ea8    	ldr	x8, [x21, #0x18]
1017a1920: 91000508    	add	x8, x8, #0x1
1017a1924: f9000ea8    	str	x8, [x21, #0x18]
1017a1928: f0043de8    	adrp	x8, 0x109f60000 <dyld_stub_binder+0x109f60000>
1017a192c: 79582108    	ldrh	w8, [x8, #0xc10]
1017a1930: 6b34211f    	cmp	w8, w20, uxth
1017a1934: 54000a03    	b.lo	0x1017a1a74 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e530>
1017a1938: 12003e88    	and	w8, w20, #0xffff
1017a193c: 7101211f    	cmp	w8, #0x48
1017a1940: 54000822    	b.hs	0x1017a1a44 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e500>
1017a1944: 8b1812ba    	add	x26, x21, x24, lsl #4
1017a1948: f8488f54    	ldr	x20, [x26, #0x88]!
1017a194c: b40007f4    	cbz	x20, 0x1017a1a48 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e504>
1017a1950: f94012a8    	ldr	x8, [x21, #0x20]
1017a1954: 91000508    	add	x8, x8, #0x1
1017a1958: f90012a8    	str	x8, [x21, #0x20]
1017a195c: 79401756    	ldrh	w22, [x26, #0xa]
1017a1960: f9400282    	ldr	x2, [x20]
1017a1964: b40004a2    	cbz	x2, 0x1017a19f8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e4b4>
1017a1968: dac00c48    	rev	x8, x2
1017a196c: f9400aa9    	ldr	x9, [x21, #0x10]
1017a1970: ea08013f    	tst	x9, x8
1017a1974: 54001481    	b.ne	0x1017a1c04 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6c0>
1017a1978: f94006a9    	ldr	x9, [x21, #0x8]
1017a197c: aa080128    	orr	x8, x9, x8
1017a1980: f9400689    	ldr	x9, [x20, #0x8]
1017a1984: ca020129    	eor	x9, x9, x2
1017a1988: 9240510a    	and	x10, x8, #0x1fffff
1017a198c: b940032b    	ldr	w11, [x25]
1017a1990: 1100096b    	add	w11, w11, #0x2
1017a1994: 5280002c    	mov	w12, #0x1               ; =1
1017a1998: 1acb218b    	lsl	w11, w12, w11
1017a199c: 93407d6b    	sxtw	x11, w11
1017a19a0: b100053f    	cmn	x9, #0x1
1017a19a4: fa4b0140    	ccmp	x10, x11, #0x0, eq
1017a19a8: 54001103    	b.lo	0x1017a1bc8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e684>
1017a19ac: f9800100    	prfm	pldl1keep, [x8]
1017a19b0: 39402349    	ldrb	w9, [x26, #0x8]
1017a19b4: 51000529    	sub	w9, w9, #0x1
1017a19b8: 39002349    	strb	w9, [x26, #0x8]
1017a19bc: f9000348    	str	x8, [x26]
1017a19c0: b94002a8    	ldr	w8, [x21]
1017a19c4: 4b160108    	sub	w8, w8, w22
1017a19c8: b90002a8    	str	w8, [x21]
1017a19cc: b9408268    	ldr	w8, [x19, #0x80]
1017a19d0: cb0802d7    	sub	x23, x22, x8
1017a19d4: f94286a8    	ldr	x8, [x21, #0x508]
1017a19d8: b4ffcf28    	cbz	x8, 0x1017a13bc <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6de78>
1017a19dc: 3cc682a0    	ldur	q0, [x21, #0x68]
1017a19e0: 52800028    	mov	w8, #0x1                ; =1
1017a19e4: 4e080d01    	dup.2d	v1, x8
1017a19e8: 4e181ee1    	mov.d	v1[1], x23
1017a19ec: 4ee18400    	add.2d	v0, v0, v1
1017a19f0: 3c8682a0    	stur	q0, [x21, #0x68]
1017a19f4: 17fffe72    	b	0x1017a13bc <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6de78>
1017a19f8: d2800008    	mov	x8, #0x0                ; =0
1017a19fc: 17ffffed    	b	0x1017a19b0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e46c>
1017a1a00: 5282c608    	mov	w8, #0x1630             ; =5680
1017a1a04: 8b080268    	add	x8, x19, x8
1017a1a08: f8380108    	ldadd	x24, x8, [x8]
1017a1a0c: 8b180108    	add	x8, x8, x24
1017a1a10: 5282c709    	mov	w9, #0x1638             ; =5688
1017a1a14: 8b090269    	add	x9, x19, x9
1017a1a18: f94b1e6a    	ldr	x10, [x19, #0x1638]
1017a1a1c: eb08015f    	cmp	x10, x8
1017a1a20: 9a88814b    	csel	x11, x10, x8, hi
1017a1a24: aa0a03ec    	mov	x12, x10
1017a1a28: c8ac7d2b    	cas	x12, x11, [x9]
1017a1a2c: eb0a019f    	cmp	x12, x10
1017a1a30: 54ffff41    	b.ne	0x1017a1a18 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e4d4>
1017a1a34: 140000fd    	b	0x1017a1e28 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e8e4>
1017a1a38: 95d2d9af    	bl	0x108c580f4 <dyld_stub_binder+0x108c580f4>
1017a1a3c: d4200000    	brk	#0
1017a1a40: d4400000    	hlt	#0
1017a1a44: d4200020    	brk	#0x1
1017a1a48: 3cc282a0    	ldur	q0, [x21, #0x28]
1017a1a4c: 52800028    	mov	w8, #0x1                ; =1
1017a1a50: 4e080d01    	dup.2d	v1, x8
1017a1a54: 4ee18400    	add.2d	v0, v0, v1
1017a1a58: 3c8282a0    	stur	q0, [x21, #0x28]
1017a1a5c: aa1503e0    	mov	x0, x21
1017a1a60: aa1803e1    	mov	x1, x24
1017a1a64: 97db2b09    	bl	0x100e6c688 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x12be0>
1017a1a68: f9400354    	ldr	x20, [x26]
1017a1a6c: b5fff794    	cbnz	x20, 0x1017a195c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e418>
1017a1a70: 1400000a    	b	0x1017a1a98 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e554>
1017a1a74: f9401ea8    	ldr	x8, [x21, #0x38]
1017a1a78: 91000508    	add	x8, x8, #0x1
1017a1a7c: f9001ea8    	str	x8, [x21, #0x38]
1017a1a80: f94016a8    	ldr	x8, [x21, #0x28]
1017a1a84: 91000508    	add	x8, x8, #0x1
1017a1a88: f90016a8    	str	x8, [x21, #0x28]
1017a1a8c: 12003e88    	and	w8, w20, #0xffff
1017a1a90: 7101c11f    	cmp	w8, #0x70
1017a1a94: 54000cc2    	b.hs	0x1017a1c2c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6e8>
1017a1a98: 52800608    	mov	w8, #0x30               ; =48
1017a1a9c: 9ba84f08    	umaddl	x8, w24, w8, x19
1017a1aa0: 91042118    	add	x24, x8, #0x108
1017a1aa4: 91040260    	add	x0, x19, #0x100
1017a1aa8: 95d2d9cc    	bl	0x108c581d8 <dyld_stub_binder+0x108c581d8>
1017a1aac: 37000060    	tbnz	w0, #0x0, 0x1017a1ab8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e574>
1017a1ab0: 91040260    	add	x0, x19, #0x100
1017a1ab4: 97a206a5    	bl	0x100023548 <__text+0x1f548>
1017a1ab8: f9400308    	ldr	x8, [x24]
1017a1abc: f90017e8    	str	x8, [sp, #0x28]
1017a1ac0: b9400329    	ldr	w9, [x25]
1017a1ac4: 11000929    	add	w9, w9, #0x2
1017a1ac8: 5280002a    	mov	w10, #0x1               ; =1
1017a1acc: 1ac92149    	lsl	w9, w10, w9
1017a1ad0: 6b0902ff    	cmp	w23, w9
1017a1ad4: 54002768    	b.hi	0x1017a1fc0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ea7c>
1017a1ad8: f9400114    	ldr	x20, [x8]
1017a1adc: b4002734    	cbz	x20, 0x1017a1fc0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ea7c>
1017a1ae0: 39009fff    	strb	wzr, [sp, #0x27]
1017a1ae4: f0040c8a    	adrp	x10, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1ae8: f940694a    	ldr	x10, [x10, #0xd0]
1017a1aec: f940014a    	ldr	x10, [x10]
1017a1af0: cb0a03ea    	neg	x10, x10
1017a1af4: 8a08014a    	and	x10, x10, x8
1017a1af8: f940014a    	ldr	x10, [x10]
1017a1afc: f95b5d4b    	ldr	x11, [x10, #0x36b8]
1017a1b00: ca0a016a    	eor	x10, x11, x10
1017a1b04: b100055f    	cmn	x10, #0x1
1017a1b08: 54003a01    	b.ne	0x1017a2248 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ed04>
1017a1b0c: b9401b16    	ldr	w22, [x24, #0x18]
1017a1b10: b940826a    	ldr	w10, [x19, #0x80]
1017a1b14: f9400282    	ldr	x2, [x20]
1017a1b18: b4000542    	cbz	x2, 0x1017a1bc0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e67c>
1017a1b1c: 925e768b    	and	x11, x20, #0xfffffffc00000000
1017a1b20: f0043d8c    	adrp	x12, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1b24: 912e018c    	add	x12, x12, #0xb80
1017a1b28: a940358c    	ldp	x12, x13, [x12]
1017a1b2c: eb0d017f    	cmp	x11, x13
1017a1b30: fa4c1164    	ccmp	x11, x12, #0x4, ne
1017a1b34: 54000100    	b.eq	0x1017a1b54 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e610>
1017a1b38: f0043d8b    	adrp	x11, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1b3c: 912e416b    	add	x11, x11, #0xb90
1017a1b40: a940316d    	ldp	x13, x12, [x11]
1017a1b44: 8a14018b    	and	x11, x12, x20
1017a1b48: eb0d017f    	cmp	x11, x13
1017a1b4c: 54003841    	b.ne	0x1017a2254 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ed10>
1017a1b50: 14000002    	b	0x1017a1b58 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e614>
1017a1b54: b25e77ec    	mov	x12, #-0x400000000      ; =-17179869184
1017a1b58: dac00c4d    	rev	x13, x2
1017a1b5c: ea0d019f    	tst	x12, x13
1017a1b60: 54000521    	b.ne	0x1017a1c04 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6c0>
1017a1b64: aa0d016b    	orr	x11, x11, x13
1017a1b68: f940068c    	ldr	x12, [x20, #0x8]
1017a1b6c: ca02018c    	eor	x12, x12, x2
1017a1b70: 9240516d    	and	x13, x11, #0x1fffff
1017a1b74: ca14016e    	eor	x14, x11, x20
1017a1b78: eb29c1bf    	cmp	x13, w9, sxtw
1017a1b7c: d355fdc9    	lsr	x9, x14, #21
1017a1b80: fa402920    	ccmp	x9, #0x0, #0x0, hs
1017a1b84: ba410980    	ccmn	x12, #0x1, #0x0, eq
1017a1b88: 54000201    	b.ne	0x1017a1bc8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e684>
1017a1b8c: f9800160    	prfm	pldl1keep, [x11]
1017a1b90: cb0a02d7    	sub	x23, x22, x10
1017a1b94: f900010b    	str	x11, [x8]
1017a1b98: b9401909    	ldr	w9, [x8, #0x18]
1017a1b9c: 1100052a    	add	w10, w9, #0x1
1017a1ba0: 33003949    	bfxil	w9, w10, #0, #15
1017a1ba4: b9001909    	str	w9, [x8, #0x18]
1017a1ba8: f9400908    	ldr	x8, [x8, #0x10]
1017a1bac: b9401916    	ldr	w22, [x8, #0x18]
1017a1bb0: 91040260    	add	x0, x19, #0x100
1017a1bb4: 95d2d986    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a1bb8: b4ffc1b4    	cbz	x20, 0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a1bbc: 17ffff03    	b	0x1017a17c8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e284>
1017a1bc0: d280000b    	mov	x11, #0x0               ; =0
1017a1bc4: 17fffff3    	b	0x1017a1b90 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e64c>
1017a1bc8: a9047fff    	stp	xzr, xzr, [sp, #0x40]
1017a1bcc: f003e4a1    	adrp	x1, 0x109438000 <dyld_stub_binder+0x109438000>
1017a1bd0: 9108d021    	add	x1, x1, #0x234
1017a1bd4: 910103e0    	add	x0, sp, #0x40
1017a1bd8: 950a3246    	bl	0x105a2e4f0 <__Z23_v8_internal_Node_PrintPv+0x191eec4>
1017a1bdc: 910103e0    	add	x0, sp, #0x40
1017a1be0: 97a1d4d8    	bl	0x100016f40 <__text+0x12f40>
1017a1be4: a9037fff    	stp	xzr, xzr, [sp, #0x30]
1017a1be8: f9400682    	ldr	x2, [x20, #0x8]
1017a1bec: d003e481    	adrp	x1, 0x109433000 <dyld_stub_binder+0x109433000>
1017a1bf0: 91099c21    	add	x1, x1, #0x267
1017a1bf4: 9100c3e0    	add	x0, sp, #0x30
1017a1bf8: 950a323e    	bl	0x105a2e4f0 <__Z23_v8_internal_Node_PrintPv+0x191eec4>
1017a1bfc: 9100c3e0    	add	x0, sp, #0x30
1017a1c00: 97a1d4d0    	bl	0x100016f40 <__text+0x12f40>
1017a1c04: aa1603e0    	mov	x0, x22
1017a1c08: 950a33e4    	bl	0x105a2eb98 <__Z23_v8_internal_Node_PrintPv+0x191f56c>
1017a1c0c: aa1303e0    	mov	x0, x19
1017a1c10: 97abd992    	bl	0x100298258 <_cxxbridge1$slice$new+0x25277c>
1017a1c14: aa0003f5    	mov	x21, x0
1017a1c18: b4ffb300    	cbz	x0, 0x1017a1278 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dd34>
1017a1c1c: f94286a8    	ldr	x8, [x21, #0x508]
1017a1c20: b5ffe708    	cbnz	x8, 0x1017a1900 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e3bc>
1017a1c24: 5280001a    	mov	w26, #0x0               ; =0
1017a1c28: 17fffd95    	b	0x1017a127c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dd38>
1017a1c2c: d42aa240    	brk	#0x5512
1017a1c30: aa1403e0    	mov	x0, x20
1017a1c34: 94000206    	bl	0x1017a244c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ef08>
1017a1c38: d2800014    	mov	x20, #0x0               ; =0
1017a1c3c: 17fffdec    	b	0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a1c40: d4200000    	brk	#0
1017a1c44: d4400000    	hlt	#0
1017a1c48: d4200020    	brk	#0x1
1017a1c4c: 910402e0    	add	x0, x23, #0x100
1017a1c50: 97a2063e    	bl	0x100023548 <__text+0x1f548>
1017a1c54: 17fffe1b    	b	0x1017a14c0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6df7c>
1017a1c58: d4200000    	brk	#0
1017a1c5c: d4400000    	hlt	#0
1017a1c60: d4200020    	brk	#0x1
1017a1c64: f94012d9    	ldr	x25, [x22, #0x20]
1017a1c68: f9400ac8    	ldr	x8, [x22, #0x10]
1017a1c6c: 17fffe21    	b	0x1017a14f0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dfac>
1017a1c70: 91040260    	add	x0, x19, #0x100
1017a1c74: 97a20635    	bl	0x100023548 <__text+0x1f548>
1017a1c78: 17fffe5a    	b	0x1017a15e0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e09c>
1017a1c7c: f0043d89    	adrp	x9, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1c80: f945c129    	ldr	x9, [x9, #0xb80]
1017a1c84: eb09011f    	cmp	x8, x9
1017a1c88: 54001fc1    	b.ne	0x1017a2080 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb3c>
1017a1c8c: 52800028    	mov	w8, #0x1                ; =1
1017a1c90: 17fffdf3    	b	0x1017a145c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6df18>
1017a1c94: d4200000    	brk	#0
1017a1c98: d4400000    	hlt	#0
1017a1c9c: d4200020    	brk	#0x1
1017a1ca0: f0043d8c    	adrp	x12, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1ca4: f945c18c    	ldr	x12, [x12, #0xb80]
1017a1ca8: eb0c017f    	cmp	x11, x12
1017a1cac: 54ffb380    	b.eq	0x1017a131c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ddd8>
1017a1cb0: f0043d8b    	adrp	x11, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1cb4: 912e416b    	add	x11, x11, #0xb90
1017a1cb8: a940316d    	ldp	x13, x12, [x11]
1017a1cbc: 8a14018b    	and	x11, x12, x20
1017a1cc0: eb0d017f    	cmp	x11, x13
1017a1cc4: 54ffb2e0    	b.eq	0x1017a1320 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dddc>
1017a1cc8: d4200000    	brk	#0
1017a1ccc: d4400000    	hlt	#0
1017a1cd0: d4200020    	brk	#0x1
1017a1cd4: f9400676    	ldr	x22, [x19, #0x8]
1017a1cd8: 90045008    	adrp	x8, 0x10a1a1000 <dyld_stub_binder+0x10a1a1000>
1017a1cdc: f9449500    	ldr	x0, [x8, #0x928]
1017a1ce0: 95d2d941    	bl	0x108c581e4 <dyld_stub_binder+0x108c581e4>
1017a1ce4: 5280bc08    	mov	w8, #0x5e0              ; =1504
1017a1ce8: 9b0802c8    	madd	x8, x22, x8, x0
1017a1cec: f90007e8    	str	x8, [sp, #0x8]
1017a1cf0: f100011f    	cmp	x8, #0x0
1017a1cf4: fa421800    	ccmp	x0, #0x2, #0x0, ne
1017a1cf8: 54000122    	b.hs	0x1017a1d1c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e7d8>
1017a1cfc: aa1303e0    	mov	x0, x19
1017a1d00: 97abd956    	bl	0x100298258 <_cxxbridge1$slice$new+0x25277c>
1017a1d04: f90007e0    	str	x0, [sp, #0x8]
1017a1d08: b4ffc520    	cbz	x0, 0x1017a15ac <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e068>
1017a1d0c: f94007e8    	ldr	x8, [sp, #0x8]
1017a1d10: f9428508    	ldr	x8, [x8, #0x508]
1017a1d14: b50000a8    	cbnz	x8, 0x1017a1d28 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e7e4>
1017a1d18: 140000d6    	b	0x1017a2070 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb2c>
1017a1d1c: f94007e8    	ldr	x8, [sp, #0x8]
1017a1d20: f9428508    	ldr	x8, [x8, #0x508]
1017a1d24: b4fffec8    	cbz	x8, 0x1017a1cfc <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e7b8>
1017a1d28: f0040c88    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1d2c: f9406108    	ldr	x8, [x8, #0xc0]
1017a1d30: b9400108    	ldr	w8, [x8]
1017a1d34: 11000908    	add	w8, w8, #0x2
1017a1d38: 52800029    	mov	w9, #0x1                ; =1
1017a1d3c: 1ac82128    	lsl	w8, w9, w8
1017a1d40: 6b08033f    	cmp	w25, w8
1017a1d44: 54001968    	b.hi	0x1017a2070 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb2c>
1017a1d48: 92403efa    	and	x26, x23, #0xffff
1017a1d4c: f94007e9    	ldr	x9, [sp, #0x8]
1017a1d50: f9400d28    	ldr	x8, [x9, #0x18]
1017a1d54: 91000508    	add	x8, x8, #0x1
1017a1d58: f9000d28    	str	x8, [x9, #0x18]
1017a1d5c: f0043de8    	adrp	x8, 0x109f60000 <dyld_stub_binder+0x109f60000>
1017a1d60: 79582108    	ldrh	w8, [x8, #0xc10]
1017a1d64: 6b37211f    	cmp	w8, w23, uxth
1017a1d68: 540019c3    	b.lo	0x1017a20a0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb5c>
1017a1d6c: 12003ee8    	and	w8, w23, #0xffff
1017a1d70: 7101211f    	cmp	w8, #0x48
1017a1d74: 54ffe682    	b.hs	0x1017a1a44 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e500>
1017a1d78: f94007e8    	ldr	x8, [sp, #0x8]
1017a1d7c: 8b1a1116    	add	x22, x8, x26, lsl #4
1017a1d80: f8488ed7    	ldr	x23, [x22, #0x88]!
1017a1d84: b40024d7    	cbz	x23, 0x1017a221c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ecd8>
1017a1d88: f94007e9    	ldr	x9, [sp, #0x8]
1017a1d8c: f9401128    	ldr	x8, [x9, #0x20]
1017a1d90: 91000508    	add	x8, x8, #0x1
1017a1d94: f9001128    	str	x8, [x9, #0x20]
1017a1d98: 794016d8    	ldrh	w24, [x22, #0xa]
1017a1d9c: f94002e2    	ldr	x2, [x23]
1017a1da0: b40005e2    	cbz	x2, 0x1017a1e5c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e918>
1017a1da4: dac00c48    	rev	x8, x2
1017a1da8: f94007e9    	ldr	x9, [sp, #0x8]
1017a1dac: f9400929    	ldr	x9, [x9, #0x10]
1017a1db0: ea08013f    	tst	x9, x8
1017a1db4: 54000761    	b.ne	0x1017a1ea0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e95c>
1017a1db8: f94006e9    	ldr	x9, [x23, #0x8]
1017a1dbc: ca020129    	eor	x9, x9, x2
1017a1dc0: b100053f    	cmn	x9, #0x1
1017a1dc4: 54000501    	b.ne	0x1017a1e64 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e920>
1017a1dc8: f94007e9    	ldr	x9, [sp, #0x8]
1017a1dcc: f9400529    	ldr	x9, [x9, #0x8]
1017a1dd0: aa080128    	orr	x8, x9, x8
1017a1dd4: 92405109    	and	x9, x8, #0x1fffff
1017a1dd8: f0040c8a    	adrp	x10, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1ddc: f940614a    	ldr	x10, [x10, #0xc0]
1017a1de0: b940014a    	ldr	w10, [x10]
1017a1de4: 1100094a    	add	w10, w10, #0x2
1017a1de8: 5280002b    	mov	w11, #0x1               ; =1
1017a1dec: 1aca216a    	lsl	w10, w11, w10
1017a1df0: 93407d4a    	sxtw	x10, w10
1017a1df4: eb0a013f    	cmp	x9, x10
1017a1df8: 54000363    	b.lo	0x1017a1e64 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e920>
1017a1dfc: f9800100    	prfm	pldl1keep, [x8]
1017a1e00: 394022c9    	ldrb	w9, [x22, #0x8]
1017a1e04: 51000529    	sub	w9, w9, #0x1
1017a1e08: 390022c9    	strb	w9, [x22, #0x8]
1017a1e0c: f90002c8    	str	x8, [x22]
1017a1e10: f94007e9    	ldr	x9, [sp, #0x8]
1017a1e14: b9400128    	ldr	w8, [x9]
1017a1e18: 4b180108    	sub	w8, w8, w24
1017a1e1c: b9000128    	str	w8, [x9]
1017a1e20: b9408268    	ldr	w8, [x19, #0x80]
1017a1e24: cb080319    	sub	x25, x24, x8
1017a1e28: f94007e8    	ldr	x8, [sp, #0x8]
1017a1e2c: f9428508    	ldr	x8, [x8, #0x508]
1017a1e30: b4000108    	cbz	x8, 0x1017a1e50 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e90c>
1017a1e34: f94007e9    	ldr	x9, [sp, #0x8]
1017a1e38: 3cc68120    	ldur	q0, [x9, #0x68]
1017a1e3c: 52800028    	mov	w8, #0x1                ; =1
1017a1e40: 4e080d01    	dup.2d	v1, x8
1017a1e44: 4e181f21    	mov.d	v1[1], x25
1017a1e48: 4ee18400    	add.2d	v0, v0, v1
1017a1e4c: 3c868120    	stur	q0, [x9, #0x68]
1017a1e50: f0040c9a    	adrp	x26, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1e54: f9406b5a    	ldr	x26, [x26, #0xd0]
1017a1e58: 17fffe29    	b	0x1017a16fc <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e1b8>
1017a1e5c: d2800008    	mov	x8, #0x0                ; =0
1017a1e60: 17ffffe8    	b	0x1017a1e00 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e8bc>
1017a1e64: a9047fff    	stp	xzr, xzr, [sp, #0x40]
1017a1e68: f003e4a1    	adrp	x1, 0x109438000 <dyld_stub_binder+0x109438000>
1017a1e6c: 9108d021    	add	x1, x1, #0x234
1017a1e70: 910103e0    	add	x0, sp, #0x40
1017a1e74: 950a319f    	bl	0x105a2e4f0 <__Z23_v8_internal_Node_PrintPv+0x191eec4>
1017a1e78: 910103e0    	add	x0, sp, #0x40
1017a1e7c: 97a1d431    	bl	0x100016f40 <__text+0x12f40>
1017a1e80: a9037fff    	stp	xzr, xzr, [sp, #0x30]
1017a1e84: f94006e2    	ldr	x2, [x23, #0x8]
1017a1e88: d003e481    	adrp	x1, 0x109433000 <dyld_stub_binder+0x109433000>
1017a1e8c: 91099c21    	add	x1, x1, #0x267
1017a1e90: 9100c3e0    	add	x0, sp, #0x30
1017a1e94: 950a3197    	bl	0x105a2e4f0 <__Z23_v8_internal_Node_PrintPv+0x191eec4>
1017a1e98: 9100c3e0    	add	x0, sp, #0x30
1017a1e9c: 97a1d429    	bl	0x100016f40 <__text+0x12f40>
1017a1ea0: aa1803e0    	mov	x0, x24
1017a1ea4: 950a333d    	bl	0x105a2eb98 <__Z23_v8_internal_Node_PrintPv+0x191f56c>
1017a1ea8: 7100053f    	cmp	w9, #0x1
1017a1eac: 54000080    	b.eq	0x1017a1ebc <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e978>
1017a1eb0: d4200000    	brk	#0
1017a1eb4: d4400000    	hlt	#0
1017a1eb8: d4200020    	brk	#0x1
1017a1ebc: 12bffe09    	mov	w9, #0xfffff            ; =1048575
1017a1ec0: 8b0902c9    	add	x9, x22, x9
1017a1ec4: d344fd29    	lsr	x9, x9, #4
1017a1ec8: dac012ca    	clz	x10, x22
1017a1ecc: 5280078b    	mov	w11, #0x3c              ; =60
1017a1ed0: 4b0a016b    	sub	w11, w11, w10
1017a1ed4: 9acb2ecb    	ror	x11, x22, x11
1017a1ed8: 9240096c    	and	x12, x11, #0x7
1017a1edc: cb0a0d8a    	sub	x10, x12, x10, lsl #3
1017a1ee0: f1003d7f    	cmp	x11, #0xf
1017a1ee4: 9a8a954a    	cinc	x10, x10, hi
1017a1ee8: 91071d4a    	add	x10, x10, #0x1c7
1017a1eec: 52800deb    	mov	w11, #0x6f              ; =111
1017a1ef0: f101bd5f    	cmp	x10, #0x6f
1017a1ef4: 9a8b314a    	csel	x10, x10, x11, lo
1017a1ef8: f10002df    	cmp	x22, #0x0
1017a1efc: 1a8903e9    	csel	w9, wzr, w9, eq
1017a1f00: f10406df    	cmp	x22, #0x101
1017a1f04: 1a8a3134    	csel	w20, w9, w10, lo
1017a1f08: 17fffcd4    	b	0x1017a1258 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dd14>
1017a1f0c: aa1703e0    	mov	x0, x23
1017a1f10: aa1603e1    	mov	x1, x22
1017a1f14: aa1503e2    	mov	x2, x21
1017a1f18: 950a4186    	bl	0x105a32530 <__Z23_v8_internal_Node_PrintPv+0x1922f04>
1017a1f1c: aa0003f6    	mov	x22, x0
1017a1f20: 910402e0    	add	x0, x23, #0x100
1017a1f24: 95d2d8aa    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a1f28: 3707a636    	tbnz	w22, #0x0, 0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a1f2c: 17fffd7d    	b	0x1017a1520 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dfdc>
1017a1f30: f0043d8c    	adrp	x12, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1f34: f945c18c    	ldr	x12, [x12, #0xb80]
1017a1f38: eb0c017f    	cmp	x11, x12
1017a1f3c: 54ffb900    	b.eq	0x1017a165c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e118>
1017a1f40: f0043d8b    	adrp	x11, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1f44: 912e416b    	add	x11, x11, #0xb90
1017a1f48: a940316d    	ldp	x13, x12, [x11]
1017a1f4c: 8a17018b    	and	x11, x12, x23
1017a1f50: eb0d017f    	cmp	x11, x13
1017a1f54: 54ffb860    	b.eq	0x1017a1660 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e11c>
1017a1f58: d4200000    	brk	#0
1017a1f5c: d4400000    	hlt	#0
1017a1f60: d4200020    	brk	#0x1
1017a1f64: 7100053f    	cmp	w9, #0x1
1017a1f68: 54000080    	b.eq	0x1017a1f78 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ea34>
1017a1f6c: d4200000    	brk	#0
1017a1f70: d4400000    	hlt	#0
1017a1f74: d4200020    	brk	#0x1
1017a1f78: 12bffe09    	mov	w9, #0xfffff            ; =1048575
1017a1f7c: 8b090309    	add	x9, x24, x9
1017a1f80: d344fd29    	lsr	x9, x9, #4
1017a1f84: dac0130a    	clz	x10, x24
1017a1f88: 5280078b    	mov	w11, #0x3c              ; =60
1017a1f8c: 4b0a016b    	sub	w11, w11, w10
1017a1f90: 9acb2f0b    	ror	x11, x24, x11
1017a1f94: 9240096c    	and	x12, x11, #0x7
1017a1f98: cb0a0d8a    	sub	x10, x12, x10, lsl #3
1017a1f9c: f1003d7f    	cmp	x11, #0xf
1017a1fa0: 9a8a954a    	cinc	x10, x10, hi
1017a1fa4: 91071d4a    	add	x10, x10, #0x1c7
1017a1fa8: 52800deb    	mov	w11, #0x6f              ; =111
1017a1fac: f101bd5f    	cmp	x10, #0x6f
1017a1fb0: 9a8b314a    	csel	x10, x10, x11, lo
1017a1fb4: f104071f    	cmp	x24, #0x101
1017a1fb8: 1a8a3137    	csel	w23, w9, w10, lo
1017a1fbc: 17fffd75    	b	0x1017a1590 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e04c>
1017a1fc0: 9100a3e5    	add	x5, sp, #0x28
1017a1fc4: 91009fe6    	add	x6, sp, #0x27
1017a1fc8: aa1803e0    	mov	x0, x24
1017a1fcc: aa1303e1    	mov	x1, x19
1017a1fd0: 52800022    	mov	w2, #0x1                ; =1
1017a1fd4: aa1603e3    	mov	x3, x22
1017a1fd8: aa1703e4    	mov	x4, x23
1017a1fdc: 97a20172    	bl	0x1000225a4 <__text+0x1e5a4>
1017a1fe0: aa0003f4    	mov	x20, x0
1017a1fe4: b4000260    	cbz	x0, 0x1017a2030 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eaec>
1017a1fe8: f94017e8    	ldr	x8, [sp, #0x28]
1017a1fec: f0040c89    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1ff0: f9406929    	ldr	x9, [x9, #0xd0]
1017a1ff4: f9400129    	ldr	x9, [x9]
1017a1ff8: cb0903e9    	neg	x9, x9
1017a1ffc: 8a080129    	and	x9, x9, x8
1017a2000: f9400129    	ldr	x9, [x9]
1017a2004: f95b5d2a    	ldr	x10, [x9, #0x36b8]
1017a2008: ca090149    	eor	x9, x10, x9
1017a200c: b100053f    	cmn	x9, #0x1
1017a2010: 54001281    	b.ne	0x1017a2260 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ed1c>
1017a2014: b9401909    	ldr	w9, [x8, #0x18]
1017a2018: 37f80309    	tbnz	w9, #0x1f, 0x1017a2078 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb34>
1017a201c: f9400909    	ldr	x9, [x8, #0x10]
1017a2020: b9401929    	ldr	w9, [x9, #0x18]
1017a2024: b940826a    	ldr	w10, [x19, #0x80]
1017a2028: cb0a0137    	sub	x23, x9, x10
1017a202c: 17fffedf    	b	0x1017a1ba8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e664>
1017a2030: 91040260    	add	x0, x19, #0x100
1017a2034: 95d2d866    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a2038: 17fffced    	b	0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a203c: f9401109    	ldr	x9, [x8, #0x20]
1017a2040: 17fffddf    	b	0x1017a17bc <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e278>
1017a2044: d4200000    	brk	#0
1017a2048: d4400000    	hlt	#0
1017a204c: d4200020    	brk	#0x1
1017a2050: aa1a03e0    	mov	x0, x26
1017a2054: 95d2d85e    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a2058: 17fffef8    	b	0x1017a1c38 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6f4>
1017a205c: f9401109    	ldr	x9, [x8, #0x20]
1017a2060: 17fffe0d    	b	0x1017a1894 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e350>
1017a2064: d4200000    	brk	#0
1017a2068: d4400000    	hlt	#0
1017a206c: d4200020    	brk	#0x1
1017a2070: 52800016    	mov	w22, #0x0               ; =0
1017a2074: 17fffd50    	b	0x1017a15b4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e070>
1017a2078: f9401109    	ldr	x9, [x8, #0x20]
1017a207c: 17ffffea    	b	0x1017a2024 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eae0>
1017a2080: d0043d88    	adrp	x8, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a2084: 912e4108    	add	x8, x8, #0xb90
1017a2088: a9402508    	ldp	x8, x9, [x8]
1017a208c: 8a140129    	and	x9, x9, x20
1017a2090: 5280006a    	mov	w10, #0x3               ; =3
1017a2094: eb08013f    	cmp	x9, x8
1017a2098: 9a9f0148    	csel	x8, x10, xzr, eq
1017a209c: 17fffcf0    	b	0x1017a145c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6df18>
1017a20a0: f94007e9    	ldr	x9, [sp, #0x8]
1017a20a4: f9401d28    	ldr	x8, [x9, #0x38]
1017a20a8: 91000508    	add	x8, x8, #0x1
1017a20ac: f9001d28    	str	x8, [x9, #0x38]
1017a20b0: f9401528    	ldr	x8, [x9, #0x28]
1017a20b4: 91000508    	add	x8, x8, #0x1
1017a20b8: f9001528    	str	x8, [x9, #0x28]
1017a20bc: 12003ee8    	and	w8, w23, #0xffff
1017a20c0: 7101c11f    	cmp	w8, #0x70
1017a20c4: 54ffdb42    	b.hs	0x1017a1c2c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6e8>
1017a20c8: 52800608    	mov	w8, #0x30               ; =48
1017a20cc: 9ba84f48    	umaddl	x8, w26, w8, x19
1017a20d0: 9104211c    	add	x28, x8, #0x108
1017a20d4: 9104027a    	add	x26, x19, #0x100
1017a20d8: 91040260    	add	x0, x19, #0x100
1017a20dc: 95d2d83f    	bl	0x108c581d8 <dyld_stub_binder+0x108c581d8>
1017a20e0: 37000060    	tbnz	w0, #0x0, 0x1017a20ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eba8>
1017a20e4: 91040260    	add	x0, x19, #0x100
1017a20e8: 97a20518    	bl	0x100023548 <__text+0x1f548>
1017a20ec: f9400388    	ldr	x8, [x28]
1017a20f0: f90017e8    	str	x8, [sp, #0x28]
1017a20f4: d0040c89    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
1017a20f8: f9406129    	ldr	x9, [x9, #0xc0]
1017a20fc: b9400129    	ldr	w9, [x9]
1017a2100: 11000929    	add	w9, w9, #0x2
1017a2104: 5280002a    	mov	w10, #0x1               ; =1
1017a2108: 1ac92149    	lsl	w9, w10, w9
1017a210c: 6b09033f    	cmp	w25, w9
1017a2110: 54000c28    	b.hi	0x1017a2294 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ed50>
1017a2114: f9400117    	ldr	x23, [x8]
1017a2118: b4000bf7    	cbz	x23, 0x1017a2294 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ed50>
1017a211c: 39009fff    	strb	wzr, [sp, #0x27]
1017a2120: d0040c8a    	adrp	x10, 0x109934000 <dyld_stub_binder+0x109934000>
1017a2124: f940694a    	ldr	x10, [x10, #0xd0]
1017a2128: f940014a    	ldr	x10, [x10]
1017a212c: cb0a03ea    	neg	x10, x10
1017a2130: 8a08014a    	and	x10, x10, x8
1017a2134: f940014a    	ldr	x10, [x10]
1017a2138: f95b5d4b    	ldr	x11, [x10, #0x36b8]
1017a213c: ca0a016a    	eor	x10, x11, x10
1017a2140: b100055f    	cmn	x10, #0x1
1017a2144: 540009c1    	b.ne	0x1017a227c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ed38>
1017a2148: b9401b98    	ldr	w24, [x28, #0x18]
1017a214c: b940826a    	ldr	w10, [x19, #0x80]
1017a2150: f94002e2    	ldr	x2, [x23]
1017a2154: b4000522    	cbz	x2, 0x1017a21f8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ecb4>
1017a2158: 925e76eb    	and	x11, x23, #0xfffffffc00000000
1017a215c: f940076d    	ldr	x13, [x27, #0x8]
1017a2160: b25e77ec    	mov	x12, #-0x400000000      ; =-17179869184
1017a2164: eb0d017f    	cmp	x11, x13
1017a2168: 54000140    	b.eq	0x1017a2190 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ec4c>
1017a216c: f940036d    	ldr	x13, [x27]
1017a2170: eb0d017f    	cmp	x11, x13
1017a2174: 540000e0    	b.eq	0x1017a2190 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ec4c>
1017a2178: d0043d8b    	adrp	x11, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a217c: 912e416b    	add	x11, x11, #0xb90
1017a2180: a940316d    	ldp	x13, x12, [x11]
1017a2184: 8a17018b    	and	x11, x12, x23
1017a2188: eb0d017f    	cmp	x11, x13
1017a218c: 540007e1    	b.ne	0x1017a2288 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ed44>
1017a2190: dac00c4d    	rev	x13, x2
1017a2194: ea0d019f    	tst	x12, x13
1017a2198: 54ffe841    	b.ne	0x1017a1ea0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e95c>
1017a219c: aa0d016b    	orr	x11, x11, x13
1017a21a0: f94006ec    	ldr	x12, [x23, #0x8]
1017a21a4: ca02018c    	eor	x12, x12, x2
1017a21a8: 9240516d    	and	x13, x11, #0x1fffff
1017a21ac: ca17016e    	eor	x14, x11, x23
1017a21b0: eb29c1bf    	cmp	x13, w9, sxtw
1017a21b4: d355fdc9    	lsr	x9, x14, #21
1017a21b8: fa402920    	ccmp	x9, #0x0, #0x0, hs
1017a21bc: ba410980    	ccmn	x12, #0x1, #0x0, eq
1017a21c0: 54ffe521    	b.ne	0x1017a1e64 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e920>
1017a21c4: f9800160    	prfm	pldl1keep, [x11]
1017a21c8: cb0a0319    	sub	x25, x24, x10
1017a21cc: f900010b    	str	x11, [x8]
1017a21d0: b9401909    	ldr	w9, [x8, #0x18]
1017a21d4: 1100052a    	add	w10, w9, #0x1
1017a21d8: 33003949    	bfxil	w9, w10, #0, #15
1017a21dc: b9001909    	str	w9, [x8, #0x18]
1017a21e0: f9400908    	ldr	x8, [x8, #0x10]
1017a21e4: b9401918    	ldr	w24, [x8, #0x18]
1017a21e8: 91040260    	add	x0, x19, #0x100
1017a21ec: 95d2d7f8    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a21f0: b4ffd257    	cbz	x23, 0x1017a1c38 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6f4>
1017a21f4: 17fffe03    	b	0x1017a1a00 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e4bc>
1017a21f8: d280000b    	mov	x11, #0x0               ; =0
1017a21fc: 17fffff3    	b	0x1017a21c8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ec84>
1017a2200: f9400909    	ldr	x9, [x8, #0x10]
1017a2204: b9401929    	ldr	w9, [x9, #0x18]
1017a2208: 14000002    	b	0x1017a2210 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eccc>
1017a220c: f9401109    	ldr	x9, [x8, #0x20]
1017a2210: b940826a    	ldr	w10, [x19, #0x80]
1017a2214: cb0a0139    	sub	x25, x9, x10
1017a2218: 17fffff2    	b	0x1017a21e0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ec9c>
1017a221c: f94007e0    	ldr	x0, [sp, #0x8]
1017a2220: 3cc28000    	ldur	q0, [x0, #0x28]
1017a2224: 52800028    	mov	w8, #0x1                ; =1
1017a2228: 4e080d01    	dup.2d	v1, x8
1017a222c: 4ee18400    	add.2d	v0, v0, v1
1017a2230: 3c828000    	stur	q0, [x0, #0x28]
1017a2234: aa1a03e1    	mov	x1, x26
1017a2238: 97db2914    	bl	0x100e6c688 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x12be0>
1017a223c: f94002d7    	ldr	x23, [x22]
1017a2240: b5ffdad7    	cbnz	x23, 0x1017a1d98 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e854>
1017a2244: 17ffffa1    	b	0x1017a20c8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb84>
1017a2248: d4200000    	brk	#0
1017a224c: d4400000    	hlt	#0
1017a2250: d4200020    	brk	#0x1
1017a2254: d4200000    	brk	#0
1017a2258: d4400000    	hlt	#0
1017a225c: d4200020    	brk	#0x1
1017a2260: d4200000    	brk	#0
1017a2264: d4400000    	hlt	#0
1017a2268: d4200020    	brk	#0x1
1017a226c: aa0003f7    	mov	x23, x0
1017a2270: b9401909    	ldr	w9, [x8, #0x18]
1017a2274: 37fffcc9    	tbnz	w9, #0x1f, 0x1017a220c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ecc8>
1017a2278: 17ffffe2    	b	0x1017a2200 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ecbc>
1017a227c: d4200000    	brk	#0
1017a2280: d4400000    	hlt	#0
1017a2284: d4200020    	brk	#0x1
1017a2288: d4200000    	brk	#0
1017a228c: d4400000    	hlt	#0
1017a2290: d4200020    	brk	#0x1
1017a2294: 9100a3e5    	add	x5, sp, #0x28
1017a2298: 91009fe6    	add	x6, sp, #0x27
1017a229c: aa1c03e0    	mov	x0, x28
1017a22a0: aa1303e1    	mov	x1, x19
1017a22a4: 52800022    	mov	w2, #0x1                ; =1
1017a22a8: aa1803e3    	mov	x3, x24
1017a22ac: aa1903e4    	mov	x4, x25
1017a22b0: 97a200bd    	bl	0x1000225a4 <__text+0x1e5a4>
1017a22b4: b4ffece0    	cbz	x0, 0x1017a2050 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eb0c>
1017a22b8: f94017e8    	ldr	x8, [sp, #0x28]
1017a22bc: d0040c89    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
1017a22c0: f9406929    	ldr	x9, [x9, #0xd0]
1017a22c4: f9400129    	ldr	x9, [x9]
1017a22c8: cb0903e9    	neg	x9, x9
1017a22cc: 8a080129    	and	x9, x9, x8
1017a22d0: f9400129    	ldr	x9, [x9]
1017a22d4: f95b5d2a    	ldr	x10, [x9, #0x36b8]
1017a22d8: ca090149    	eor	x9, x10, x9
1017a22dc: b100053f    	cmn	x9, #0x1
1017a22e0: 54fffc60    	b.eq	0x1017a226c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ed28>
1017a22e4: d4200000    	brk	#0
1017a22e8: d4400000    	hlt	#0
1017a22ec: d4200020    	brk	#0x1
