
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100004000 <__text>:
10001d6d0: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
10001d6d4: a9015ff8    	stp	x24, x23, [sp, #0x10]
10001d6d8: a90257f6    	stp	x22, x21, [sp, #0x20]
10001d6dc: a9034ff4    	stp	x20, x19, [sp, #0x30]
10001d6e0: a9047bfd    	stp	x29, x30, [sp, #0x40]
10001d6e4: 910103fd    	add	x29, sp, #0x40
10001d6e8: b4000da1    	cbz	x1, 0x10001d89c <__text+0x1989c>
10001d6ec: aa0103f4    	mov	x20, x1
10001d6f0: f9800030    	prfm	pstl1keep, [x1]
10001d6f4: 925d7028    	and	x8, x1, #0xfffffff800000000
10001d6f8: f004f9b7    	adrp	x23, 0x109f54000 <dyld_stub_binder+0x109f54000>
10001d6fc: 912e02f7    	add	x23, x23, #0xb80
10001d700: f94002e9    	ldr	x9, [x23]
10001d704: a9412aeb    	ldp	x11, x10, [x23, #0x10]
10001d708: 8a01014a    	and	x10, x10, x1
10001d70c: eb09011f    	cmp	x8, x9
10001d710: fa4b1144    	ccmp	x10, x11, #0x4, ne
10001d714: 540013a1    	b.ne	0x10001d988 <__text+0x19988>
10001d718: aa0003f3    	mov	x19, x0
10001d71c: f9404409    	ldr	x9, [x0, #0x88]
10001d720: 926baa8b    	and	x11, x20, #0xffffffffffe00000
10001d724: 9240528c    	and	x12, x20, #0x1fffff
10001d728: f004c8a8    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
10001d72c: f9406108    	ldr	x8, [x8, #0xc0]
10001d730: b980010d    	ldrsw	x13, [x8]
10001d734: 910009aa    	add	x10, x13, #0x2
10001d738: 9aca258a    	lsr	x10, x12, x10
10001d73c: 8b0b0129    	add	x9, x9, x11
10001d740: 8b0a1529    	add	x9, x9, x10, lsl #5
10001d744: 3940792a    	ldrb	w10, [x9, #0x1e]
10001d748: 9240154a    	and	x10, x10, #0x3f
10001d74c: cb0a1535    	sub	x21, x9, x10, lsl #5
10001d750: f98002a0    	prfm	pldl1keep, [x21]
10001d754: f9400ab9    	ldr	x25, [x21, #0x10]
10001d758: b9401b2a    	ldr	w10, [x25, #0x18]
10001d75c: 3940400e    	ldrb	w14, [x0, #0x10]
10001d760: 3400032e    	cbz	w14, 0x10001d7c4 <__text+0x197c4>
10001d764: f004c8ae    	adrp	x14, 0x109934000 <dyld_stub_binder+0x109934000>
10001d768: f94069ce    	ldr	x14, [x14, #0xd0]
10001d76c: f94001ce    	ldr	x14, [x14]
10001d770: d10005cf    	sub	x15, x14, #0x1
10001d774: 8b0e056b    	add	x11, x11, x14, lsl #1
10001d778: 9acd258c    	lsr	x12, x12, x13
10001d77c: d37ff9ad    	lsl	x13, x13, #1
10001d780: d1005dad    	sub	x13, x13, #0x17
10001d784: 9acd218c    	lsl	x12, x12, x13
10001d788: 8b0c096b    	add	x11, x11, x12, lsl #2
10001d78c: 8b0a028c    	add	x12, x20, x10
10001d790: d100118c    	sub	x12, x12, #0x4
10001d794: ea1401ff    	tst	x15, x20
10001d798: 9a8c0178    	csel	x24, x11, x12, eq
10001d79c: b8bfc30b    	ldapr	w11, [x24]
10001d7a0: 12007976    	and	w22, w11, #0x7fffffff
10001d7a4: 710006df    	cmp	w22, #0x1
10001d7a8: 540008c1    	b.ne	0x10001d8c0 <__text+0x198c0>
10001d7ac: 5280002b    	mov	w11, #0x1               ; =1
10001d7b0: b86b1300    	ldclrl	w11, w0, [x24]
10001d7b4: 36000f00    	tbz	w0, #0x0, 0x10001d994 <__text+0x19994>
10001d7b8: 721f741f    	tst	w0, #0x7ffffffe
10001d7bc: 54000941    	b.ne	0x10001d8e4 <__text+0x198e4>
10001d7c0: d50339bf    	dmb	ishld
10001d7c4: 9104226b    	add	x11, x19, #0x108
10001d7c8: 3940066c    	ldrb	w12, [x19, #0x1]
10001d7cc: 35000b4c    	cbnz	w12, 0x10001d934 <__text+0x19934>
10001d7d0: f900029f    	str	xzr, [x20]
10001d7d4: 3941026a    	ldrb	w10, [x19, #0x40]
10001d7d8: f9400aa9    	ldr	x9, [x21, #0x10]
10001d7dc: 3500100a    	cbnz	w10, 0x10001d9dc <__text+0x199dc>
10001d7e0: b9401928    	ldr	w8, [x9, #0x18]
10001d7e4: 5282c609    	mov	w9, #0x1630             ; =5680
10001d7e8: 8b090269    	add	x9, x19, x9
10001d7ec: cb0803e8    	neg	x8, x8
10001d7f0: f8280128    	ldadd	x8, x8, [x9]
10001d7f4: 91040260    	add	x0, x19, #0x100
10001d7f8: 95ffed37    	bl	0x108018cd4 <__Z23_v8_internal_Node_PrintPv+0x3f096a8>
10001d7fc: 360005c0    	tbz	w0, #0x0, 0x10001d8b4 <__text+0x198b4>
10001d800: f94002a8    	ldr	x8, [x21]
10001d804: eb14011f    	cmp	x8, x20
10001d808: 54000cc0    	b.eq	0x10001d9a0 <__text+0x199a0>
10001d80c: b4000128    	cbz	x8, 0x10001d830 <__text+0x19830>
10001d810: 925e7509    	and	x9, x8, #0xfffffffc00000000
10001d814: a9402aeb    	ldp	x11, x10, [x23]
10001d818: eb0a013f    	cmp	x9, x10
10001d81c: fa4b1124    	ccmp	x9, x11, #0x4, ne
10001d820: 54000cc1    	b.ne	0x10001d9b8 <__text+0x199b8>
10001d824: b25e77e9    	mov	x9, #-0x400000000       ; =-17179869184
10001d828: 8a290108    	bic	x8, x8, x9
10001d82c: dac00d08    	rev	x8, x8
10001d830: aa2803e9    	mvn	x9, x8
10001d834: a9002688    	stp	x8, x9, [x20]
10001d838: f90002b4    	str	x20, [x21]
10001d83c: 79403aa8    	ldrh	w8, [x21, #0x1c]
10001d840: 121f3908    	and	w8, w8, #0xfffe
10001d844: 79003aa8    	strh	w8, [x21, #0x1c]
10001d848: b9401aa8    	ldr	w8, [x21, #0x18]
10001d84c: 7200391f    	tst	w8, #0x7fff
10001d850: 54000ae0    	b.eq	0x10001d9ac <__text+0x199ac>
10001d854: 51000509    	sub	w9, w8, #0x1
10001d858: aa0803ea    	mov	x10, x8
10001d85c: 3300392a    	bfxil	w10, w9, #0, #15
10001d860: b9001aaa    	str	w10, [x21, #0x18]
10001d864: 37f00148    	tbnz	w8, #0x1e, 0x10001d88c <__text+0x1988c>
10001d868: 12003928    	and	w8, w9, #0x7fff
10001d86c: 34000108    	cbz	w8, 0x10001d88c <__text+0x1988c>
10001d870: 91040260    	add	x0, x19, #0x100
10001d874: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10001d878: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10001d87c: a94257f6    	ldp	x22, x21, [sp, #0x20]
10001d880: a9415ff8    	ldp	x24, x23, [sp, #0x10]
10001d884: a8c567fa    	ldp	x26, x25, [sp], #0x50
10001d888: 15ffed72    	b	0x108018e50 <__Z23_v8_internal_Node_PrintPv+0x3f09824>
10001d88c: aa1503e0    	mov	x0, x21
10001d890: 52800021    	mov	w1, #0x1                ; =1
10001d894: 94004415    	bl	0x10002e8e8 <__text+0x2a8e8>
10001d898: 17fffff6    	b	0x10001d870 <__text+0x19870>
10001d89c: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10001d8a0: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10001d8a4: a94257f6    	ldp	x22, x21, [sp, #0x20]
10001d8a8: a9415ff8    	ldp	x24, x23, [sp, #0x10]
10001d8ac: a8c567fa    	ldp	x26, x25, [sp], #0x50
10001d8b0: d65f03c0    	ret
10001d8b4: 91040260    	add	x0, x19, #0x100
10001d8b8: 94001724    	bl	0x100023548 <__text+0x1f548>
10001d8bc: 17ffffd1    	b	0x10001d800 <__text+0x19800>
10001d8c0: aa1303e0    	mov	x0, x19
10001d8c4: aa1503e1    	mov	x1, x21
10001d8c8: aa1403e2    	mov	x2, x20
10001d8cc: aa0a03fa    	mov	x26, x10
10001d8d0: 94004227    	bl	0x10002e16c <__text+0x2a16c>
10001d8d4: aa1a03ea    	mov	x10, x26
10001d8d8: f004c8a8    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
10001d8dc: f9406108    	ldr	x8, [x8, #0xc0]
10001d8e0: 17ffffb3    	b	0x10001d7ac <__text+0x197ac>
10001d8e4: 710006df    	cmp	w22, #0x1
10001d8e8: 54000a80    	b.eq	0x10001da38 <__text+0x19a38>
10001d8ec: 5282ca08    	mov	w8, #0x1650             ; =5712
10001d8f0: 8b080268    	add	x8, x19, x8
10001d8f4: f9400aa9    	ldr	x9, [x21, #0x10]
10001d8f8: b9401929    	ldr	w9, [x9, #0x18]
10001d8fc: f8290108    	ldadd	x9, x8, [x8]
10001d900: 5282cb08    	mov	w8, #0x1658             ; =5720
10001d904: 8b080268    	add	x8, x19, x8
10001d908: 52800029    	mov	w9, #0x1                ; =1
10001d90c: f8290108    	ldadd	x9, x8, [x8]
10001d910: 5282cc08    	mov	w8, #0x1660             ; =5728
10001d914: 8b080268    	add	x8, x19, x8
10001d918: f9400aaa    	ldr	x10, [x21, #0x10]
10001d91c: b940194a    	ldr	w10, [x10, #0x18]
10001d920: f82a0108    	ldadd	x10, x8, [x8]
10001d924: 5282cd08    	mov	w8, #0x1668             ; =5736
10001d928: 8b080268    	add	x8, x19, x8
10001d92c: f8290108    	ldadd	x9, x8, [x8]
10001d930: 17ffffdb    	b	0x10001d89c <__text+0x1989c>
10001d934: f940067a    	ldr	x26, [x19, #0x8]
10001d938: 90050c2b    	adrp	x11, 0x10a1a1000 <dyld_stub_binder+0x10a1a1000>
10001d93c: f9449560    	ldr	x0, [x11, #0x928]
10001d940: aa0803f6    	mov	x22, x8
10001d944: aa1903f8    	mov	x24, x25
10001d948: aa0a03f9    	mov	x25, x10
10001d94c: 95ffecb5    	bl	0x108018c20 <__Z23_v8_internal_Node_PrintPv+0x3f095f4>
10001d950: 9104226b    	add	x11, x19, #0x108
10001d954: aa1603e8    	mov	x8, x22
10001d958: f100081f    	cmp	x0, #0x2
10001d95c: 54fff3a3    	b.lo	0x10001d7d0 <__text+0x197d0>
10001d960: 5280bc09    	mov	w9, #0x5e0              ; =1504
10001d964: 9b09035a    	madd	x26, x26, x9, x0
10001d968: b4fff35a    	cbz	x26, 0x10001d7d0 <__text+0x197d0>
10001d96c: 91042268    	add	x8, x19, #0x108
10001d970: f9428749    	ldr	x9, [x26, #0x508]
10001d974: b50008c9    	cbnz	x9, 0x10001da8c <__text+0x19a8c>
10001d978: aa1603e8    	mov	x8, x22
10001d97c: 9104226b    	add	x11, x19, #0x108
10001d980: b4fff289    	cbz	x9, 0x10001d7d0 <__text+0x197d0>
10001d984: 14000033    	b	0x10001da50 <__text+0x19a50>
10001d988: d4200000    	brk	#0
10001d98c: d4400000    	hlt	#0
10001d990: d4200020    	brk	#0x1
10001d994: aa1403e1    	mov	x1, x20
10001d998: aa1503e2    	mov	x2, x21
10001d99c: 956842f9    	bl	0x105a2e580 <__Z23_v8_internal_Node_PrintPv+0x191ef54>
10001d9a0: d4200000    	brk	#0
10001d9a4: d4400000    	hlt	#0
10001d9a8: d4200020    	brk	#0x1
10001d9ac: d4200000    	brk	#0
10001d9b0: d4400000    	hlt	#0
10001d9b4: d4200020    	brk	#0x1
10001d9b8: f004f9aa    	adrp	x10, 0x109f54000 <dyld_stub_binder+0x109f54000>
10001d9bc: 912e414a    	add	x10, x10, #0xb90
10001d9c0: a940254a    	ldp	x10, x9, [x10]
10001d9c4: 8a08012b    	and	x11, x9, x8
10001d9c8: eb0a017f    	cmp	x11, x10
10001d9cc: 54fff2e0    	b.eq	0x10001d828 <__text+0x19828>
10001d9d0: d4200000    	brk	#0
10001d9d4: d4400000    	hlt	#0
10001d9d8: d4200020    	brk	#0x1
10001d9dc: 5282bb0a    	mov	w10, #0x15d8            ; =5592
10001d9e0: 8b0a026a    	add	x10, x19, x10
10001d9e4: eb0b013f    	cmp	x9, x11
10001d9e8: fa4a2122    	ccmp	x9, x10, #0x2, hs
10001d9ec: 54ffefa8    	b.hi	0x10001d7e0 <__text+0x197e0>
10001d9f0: 3940712a    	ldrb	w10, [x9, #0x1c]
10001d9f4: b9400108    	ldr	w8, [x8]
10001d9f8: 9ac82148    	lsl	x8, x10, x8
10001d9fc: f940112a    	ldr	x10, [x9, #0x20]
10001da00: 9b0a7d08    	mul	x8, x8, x10
10001da04: d36bfd08    	lsr	x8, x8, #43
10001da08: b4ffeec8    	cbz	x8, 0x10001d7e0 <__text+0x197e0>
10001da0c: b9401aa8    	ldr	w8, [x21, #0x18]
10001da10: 37f80108    	tbnz	w8, #0x1f, 0x10001da30 <__text+0x19a30>
10001da14: b9401928    	ldr	w8, [x9, #0x18]
10001da18: b9408269    	ldr	w9, [x19, #0x80]
10001da1c: cb090101    	sub	x1, x8, x9
10001da20: aa1403e0    	mov	x0, x20
10001da24: 95ffb764    	bl	0x10800b7b4 <__Z23_v8_internal_Node_PrintPv+0x3efc188>
10001da28: f9400aa9    	ldr	x9, [x21, #0x10]
10001da2c: 17ffff6d    	b	0x10001d7e0 <__text+0x197e0>
10001da30: f94012a8    	ldr	x8, [x21, #0x20]
10001da34: 17fffff9    	b	0x10001da18 <__text+0x19a18>
10001da38: d4200000    	brk	#0
10001da3c: d4400000    	hlt	#0
10001da40: d4200020    	brk	#0x1
10001da44: f9402b48    	ldr	x8, [x26, #0x50]
10001da48: 91000508    	add	x8, x8, #0x1
10001da4c: f9002b48    	str	x8, [x26, #0x50]
10001da50: b9401aa8    	ldr	w8, [x21, #0x18]
10001da54: 37f80088    	tbnz	w8, #0x1f, 0x10001da64 <__text+0x19a64>
10001da58: f9400aa8    	ldr	x8, [x21, #0x10]
10001da5c: b9401908    	ldr	w8, [x8, #0x18]
10001da60: 14000002    	b	0x10001da68 <__text+0x19a68>
10001da64: f94012a8    	ldr	x8, [x21, #0x20]
10001da68: b9408269    	ldr	w9, [x19, #0x80]
10001da6c: a947af4a    	ldp	x10, x11, [x26, #0x78]
10001da70: 9100054a    	add	x10, x10, #0x1
10001da74: cb090108    	sub	x8, x8, x9
10001da78: 8b0b0108    	add	x8, x8, x11
10001da7c: a907a34a    	stp	x10, x8, [x26, #0x78]
10001da80: aa1603e8    	mov	x8, x22
10001da84: 9104226b    	add	x11, x19, #0x108
10001da88: 17ffff52    	b	0x10001d7d0 <__text+0x197d0>
10001da8c: 7143c33f    	cmp	w25, #0xf0, lsl #12     ; =0xf0000
10001da90: 54fff748    	b.hi	0x10001d978 <__text+0x19978>
10001da94: cb080308    	sub	x8, x24, x8
10001da98: 9344fd08    	asr	x8, x8, #4
10001da9c: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
10001daa0: f2955569    	movk	x9, #0xaaab
10001daa4: 9b097d08    	mul	x8, x8, x9
10001daa8: 12003d09    	and	w9, w8, #0xffff
10001daac: f940234a    	ldr	x10, [x26, #0x40]
10001dab0: 9100054a    	add	x10, x10, #0x1
10001dab4: f900234a    	str	x10, [x26, #0x40]
10001dab8: f004fa0a    	adrp	x10, 0x109f60000 <dyld_stub_binder+0x109f60000>
10001dabc: 7958214a    	ldrh	w10, [x10, #0xc10]
10001dac0: 6b09015f    	cmp	w10, w9
10001dac4: 54fffc03    	b.lo	0x10001da44 <__text+0x19a44>
10001dac8: 7101213f    	cmp	w9, #0x48
10001dacc: 54fffba2    	b.hs	0x10001da40 <__text+0x19a40>
10001dad0: 92403d08    	and	x8, x8, #0xffff
10001dad4: 8b081355    	add	x21, x26, x8, lsl #4
10001dad8: f8488ea8    	ldr	x8, [x21, #0x88]!
10001dadc: f9400b49    	ldr	x9, [x26, #0x10]
10001dae0: 8a290109    	bic	x9, x8, x9
10001dae4: dac00d29    	rev	x9, x9
10001dae8: f100011f    	cmp	x8, #0x0
10001daec: 9a8903e8    	csel	x8, xzr, x9, eq
10001daf0: aa2803e9    	mvn	x9, x8
10001daf4: a9002688    	stp	x8, x9, [x20]
10001daf8: f90002b4    	str	x20, [x21]
10001dafc: 394022a8    	ldrb	w8, [x21, #0x8]
10001db00: 11000509    	add	w9, w8, #0x1
10001db04: 390022a9    	strb	w9, [x21, #0x8]
10001db08: 794016a8    	ldrh	w8, [x21, #0xa]
10001db0c: b940034a    	ldr	w10, [x26]
10001db10: 0b080148    	add	w8, w10, w8
10001db14: b9000348    	str	w8, [x26]
10001db18: f9402748    	ldr	x8, [x26, #0x48]
10001db1c: 91000508    	add	x8, x8, #0x1
10001db20: f9002748    	str	x8, [x26, #0x48]
10001db24: 394026a8    	ldrb	w8, [x21, #0x9]
10001db28: 6b29011f    	cmp	w8, w9, uxtb
10001db2c: 540000a2    	b.hs	0x10001db40 <__text+0x19b40>
10001db30: d341fd02    	lsr	x2, x8, #1
10001db34: aa1a03e0    	mov	x0, x26
10001db38: aa1503e1    	mov	x1, x21
10001db3c: 9400419e    	bl	0x10002e1b4 <__text+0x2a1b4>
10001db40: 39401348    	ldrb	w8, [x26, #0x4]
10001db44: 34000068    	cbz	w8, 0x10001db50 <__text+0x19b50>
10001db48: aa1a03e0    	mov	x0, x26
10001db4c: 97fff58a    	bl	0x10001b174 <__text+0x17174>
