
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010410f62c <__Z23_v8_internal_Node_PrintPv>:
10717086c: aa0103e0    	mov	x0, x1
107170870: 163ab394    	b	0x10001d6c0 <__text+0x196c0>
