#!/usr/bin/env python3
"""Static inventory only: never launch or attach a browser; task-owned outputs."""
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import select
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "inventory-raw"
RAW.mkdir(exist_ok=False)
MAX_OUTPUT = 2 * 1024 * 1024
TARGETS = {
    "headless-1243": Path("/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell"),
    "cft-framework-1243": Path("/Users/vasilis/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/Frameworks/Google Chrome for Testing Framework.framework/Versions/153.0.8010.12/Google Chrome for Testing Framework"),
    "chrome-framework-156-49": Path("/Applications/Google Chrome.app/Contents/Frameworks/Google Chrome Framework.framework/Versions/156.0.8078.49/Google Chrome Framework"),
}


def command(label, argv):
    started = time.monotonic()
    proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = bytearray()
    limit = None
    while True:
        if time.monotonic() - started >= 15:
            limit = "15_second_timeout"
            break
        ready, _, _ = select.select([proc.stdout], [], [], 0.1)
        if ready:
            chunk = os.read(proc.stdout.fileno(), min(65536, MAX_OUTPUT + 1 - len(output)))
            if not chunk:
                break
            output.extend(chunk)
            if len(output) > MAX_OUTPUT:
                output = output[:MAX_OUTPUT]
                limit = "2_MiB_output_cap"
                break
        elif proc.poll() is not None:
            # Continue until the pipe's EOF is consumed.
            continue
    if limit:
        proc.kill()
    proc.wait(timeout=3)
    data = bytes(output)
    dest = RAW / (label + ".txt")
    dest.write_bytes(data)
    return {"argv": argv, "exit_code": proc.returncode, "elapsed_seconds": round(time.monotonic() - started, 6),
            "limit": limit, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "raw_path": str(dest)}, data.decode("utf-8", "replace")


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            result.update(chunk)
    return result.hexdigest()


report = {"scope": "static file/tool inspection; no browser execution, attachment, install, or security change", "targets": {}, "tools": {}}
for label, path in TARGETS.items():
    item = {"path": str(path), "size_bytes": path.stat().st_size, "sha256": digest(path)}
    item["codesign"], _ = command(label + "-codesign", ["/usr/bin/codesign", "-dvv", str(path)])
    item["macho"], header = command(label + "-macho", ["/Library/Developer/CommandLineTools/usr/bin/llvm-objdump", "--macho", "--private-headers", str(path)])
    item["defined_exports"], exports = command(label + "-exports", ["/usr/bin/nm", "-gU", str(path)])
    item["internal_hook_named_export_matches"] = [line for line in exports.splitlines() if re.search(r"V8ScriptValue|SerializedScriptValue|PartitionAllocHooks|PartitionRoot|BufferTryRealloc|BufferPotentialCapacity|BufferFree|PostMessageToWorker", line)]
    item["macho_uuid_lines"] = re.findall(r"^.*uuid.*$", header, re.MULTILINE)
    item["macho_symbol_count_lines"] = re.findall(r"^.*(?:nlocalsym|nextdefsym|nsyms).*$", header, re.MULTILINE)
    report["targets"][label] = item

for label, path in {
    "chrome-launcher": "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "cft-launcher": "/Users/vasilis/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing",
}.items():
    report["tools"][label + "-codesign"], _ = command(label + "-codesign", ["/usr/bin/codesign", "-dvv", path])

for label, plist_path in {
    "installed-chrome": "/Applications/Google Chrome.app/Contents/Info.plist",
    "cached-cft": "/Users/vasilis/Library/Caches/ms-playwright/chromium-1243/chrome-mac-arm64/Google Chrome for Testing.app/Contents/Info.plist",
}.items():
    with open(plist_path, "rb") as stream:
        plist = plistlib.load(stream)
    report[label] = {key: plist.get(key) for key in ["CFBundleIdentifier", "CFBundleShortVersionString", "CFBundleVersion", "CFBundleExecutable"]}

for label, argv in {
    "lldb": ["/Library/Developer/CommandLineTools/usr/bin/lldb", "--version"],
    "developer-directory": ["/usr/bin/xcode-select", "-p"],
    "xcode": ["/usr/bin/xcodebuild", "-version"],
}.items():
    report["tools"][label], _ = command(label, argv)
report["path_availability"] = {name: shutil.which(name) for name in ["lldb", "llvm-objdump", "dwarfdump", "dsymutil", "atos", "dtrace", "frida", "frida-trace", "rizin", "gn", "autoninja", "fetch", "gclient"]}
with (ROOT / "inventory.json").open("x") as stream:
    json.dump(report, stream, indent=2)
    stream.write("\n")
print(json.dumps({"output": str(ROOT / "inventory.json"), "browser_executed": False, "targets": {label: {"sha256": item["sha256"], "hook_named_export_matches": len(item["internal_hook_named_export_matches"]), "uuid": item["macho_uuid_lines"], "symbols": item["macho_symbol_count_lines"]} for label, item in report["targets"].items()}}))
