/* Static-reviewed candidate; NOT RUN. Load only into the parent-validated owned
 * headless-1243 renderer. No payload reads, calls into V8, target argument edits,
 * return edits, file I/O, network I/O, or replacement allocator policy.
 * The observer uses Frida's separate JS VM; its overhead is not a memory result.
 */
'use strict';
const EXPECTED_PATH = '/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell';
const EXPECTED_UUID = '4c4c44c155553144a1ed87c8cc00f9e6';
const WINDOW_MS = 15000, RECORD_CAP = 2048, WIDTH = 10, LIVE_CAP = 256, THREAD_CAP = 64;
const rows = new Float64Array(RECORD_CAP * WIDTH);
const livePtr = new Float64Array(LIVE_CAP), liveCap = new Float64Array(LIVE_CAP);
const liveBirth = new Float64Array(LIVE_CAP), liveOrigin = new Float64Array(LIVE_CAP);
const tids = new Float64Array(THREAD_CAP), oldByTid = new Float64Array(THREAD_CAP), capByTid = new Float64Array(THREAD_CAP);
const pendingDst = new Float64Array(THREAD_CAP), pendingSrc = new Float64Array(THREAD_CAP), pendingN = new Float64Array(THREAD_CAP);
const listeners = [];
let used = 0, dropped = 0, invalid = 0, birth = 0, active = false, stopped = false, timer = null, label = '';
// Row: [sequence, kind, tid, wall_ms, a, b, n, capacity_a, capacity_b, aux].
// Kinds: 1 PA realloc enter, 2 leave, 3 exact PA copy call, 4 copy return,
// 5 root-free enter, 6 root-free return, 7 internal-free enter, 8 return,
// 9 exported memcpy/memmove, 10 BufferAlloc enter, 11 return,
// 12 delegate realloc enter, 13 leave, 14 delegate free enter,
// 15 API-only old-buffer retirement (no matching internal-free witness).
function num(p) {
  const value = p.toUInt32() + p.shr(32).toUInt32() * 4294967296;
  if (!Number.isSafeInteger(value)) { invalid++; return 0; }
  return value;
}
function record(kind, tid, a, b, n, ca, cb, aux) {
  if (!active) return;
  if (used === RECORD_CAP) { dropped++; return; }
  const i = used++ * WIDTH;
  rows[i] = used; rows[i+1] = kind; rows[i+2] = tid; rows[i+3] = Date.now();
  rows[i+4] = a; rows[i+5] = b; rows[i+6] = n; rows[i+7] = ca; rows[i+8] = cb; rows[i+9] = aux;
}
function slot(p) { for (let i = 0; i < LIVE_CAP; i++) if (livePtr[i] === p && p !== 0) return i; return -1; }
function capacity(p) { const i = slot(p); return i < 0 ? 0 : liveCap[i]; }
function add(p, size, origin, allowExisting) {
  if (p === 0) return;
  let i = slot(p);
  if (i >= 0 && !allowExisting) { invalid++; return; }
  if (i < 0) { for (let j = 0; j < LIVE_CAP; j++) if (livePtr[j] === 0) { i = j; liveBirth[i] = ++birth; break; } }
  if (i < 0) { invalid++; return; }
  livePtr[i] = p; liveCap[i] = size; liveOrigin[i] = origin;
}
function remove(p, expectedBirth) { const i = slot(p); if (i >= 0) { if (expectedBirth && liveBirth[i] !== expectedBirth) { invalid++; return; } livePtr[i] = 0; liveCap[i] = 0; liveOrigin[i] = 0; } }
function thread(tid) {
  for (let i = 0; i < THREAD_CAP; i++) if (tids[i] === tid) return i;
  for (let i = 0; i < THREAD_CAP; i++) if (tids[i] === 0) { tids[i] = tid; return i; }
  invalid++; return -1;
}
function intersect(p, size) {
  if (p === 0 || size === 0 || !Number.isSafeInteger(p + size)) return -1;
  for (let i = 0; i < LIVE_CAP; i++) if (livePtr[i] !== 0 && p < livePtr[i] + liveCap[i] && livePtr[i] < p + size) return i;
  return -1;
}
function hex(bytes) { return Array.from(new Uint8Array(bytes), x => x.toString(16).padStart(2, '0')).join(''); }
function uuid(base) {
  let cursor = 32;
  const count = base.add(16).readU32();
  if (count > 256) throw new Error('unbounded_load_commands');
  for (let i = 0; i < count; i++) {
    const command = base.add(cursor).readU32(), size = base.add(cursor + 4).readU32();
    if (size < 8 || size > 65536) throw new Error('malformed_load_command');
    if (command === 0x1b) return hex(base.add(cursor + 8).readByteArray(16));
    cursor += size;
  }
  throw new Error('uuid_missing');
}
const checks = [
  [0x17a1140, 'f657bda9f44f01a9fd7b02a9fd830091f30303aaf40301aa155504b0a0ee46f9e10302aa74f9a397e20300aa600200f9a0ee46f923fd03b0636c2591e10314aafd7b42a9f44f41a9f657c3a801000014'],
  [0x17a1190, 'ff0303d1fc6f06a9fa6707a9f85f08a9f65709a9f44f0aa9fd7b0ba9fdc30291'],
  [0x17a172c, 'bf0208eba232889ae00317aae10314aa9bdad295e00314aa42030094f40317aa'],
  [0x1d6c0, 'e10300aa281105b000ed46f901000014'],
  [0x1d6d0, 'fa67bba9f85f01a9f65702a9f44f03a9fd7b04a9fd030191a10d00b4f40301aa'],
  [0x717086c, 'e00301aa94b33a16'],
  [0x1c36c, 'ff8302d1fc6f04a9fa6705a9f85f06a9f65707a9f44f08a9fd7b09a9fd430291'],
  [0x17a244c, 'fc6fbaa9fa6701a9f85f02a9f65703a9f44f04a9fd7b05a9fd430191f40300aa']
];
function snapshot() {
  const remaining = [];
  for (let i = 0; i < LIVE_CAP; i++) if (livePtr[i]) remaining.push([livePtr[i], liveCap[i], liveOrigin[i]]);
  return {kind:'snapshot', label, active, record_count:used, dropped, invalid, remaining, window_ms:WINDOW_MS,
    limits:{records:RECORD_CAP, live_buffers:LIVE_CAP, threads:THREAD_CAP},
    numeric_rows:Array.from(rows.subarray(0, used * WIDTH)),
    limitations:['Remaining buffers are right-censored; process exit is not an observed final free.',
      'API capacities and executed copy extents are not OS resident or committed pages.',
      'Generic memcpy/memmove hooks do not cover compiler-inlined copies.',
      'Frida VM memory/timing overhead is separate and unmeasured.',
      'BufferAlloc rows record requested extents; no usable-slot-capacity getter is called.',
      'Per-message binding must be independently reconciled with one-at-a-time transport phases.']};
}
function end() {
  active = false;
  if (timer !== null) { clearTimeout(timer); timer = null; }
  for (let i = 0; i < THREAD_CAP; i++) if (capByTid[i]) invalid++;
  return snapshot();
}
function stop() {
  const result = end();
  for (const listener of listeners) listener.detach();
  stopped = true;
  return result;
}
try {
  if (Process.arch !== 'arm64' || Process.platform !== 'darwin' || Process.pointerSize !== 8) throw new Error('wrong_platform');
  const image = Process.mainModule, base = image.base;
  if (image.path !== EXPECTED_PATH || uuid(base) !== EXPECTED_UUID) throw new Error('binary_identity_mismatch');
  for (const [offset, bytes] of checks) if (hex(base.add(offset).readByteArray(bytes.length / 2)) !== bytes) throw new Error('fingerprint_mismatch_at_' + offset.toString(16));
  const typeName = base.add(0x974695b);
  function attach(offset, callbacks) { listeners.push(Interceptor.attach(base.add(offset), callbacks)); }
  attach(0x17a1190, {
    onEnter(args) {
      this.selected = active && args[3].equals(typeName);
      if (!this.selected) return;
      this.old = num(args[1]); this.cap = num(args[2]); this.t = thread(this.threadId);
      if (this.t < 0) { this.selected = false; return; }
      if (capByTid[this.t] !== 0) invalid++; // Unexpected nested selected realloc.
      if (this.old !== 0 && capacity(this.old) === 0) invalid++;
      oldByTid[this.t] = this.old; capByTid[this.t] = this.cap;
      record(1, this.threadId, this.old, num(args[0]), this.cap, capacity(this.old), 0, 0);
    },
    onLeave(ret) {
      if (!this.selected || !active) return;
      const dest = num(ret), oldCap = capacity(this.old);
      record(2, this.threadId, this.old, dest, this.cap, oldCap, dest ? this.cap : 0, 0);
      if (dest) {
        if (dest !== this.old && oldCap) { record(15, this.threadId, this.old, dest, 0, oldCap, this.cap, 0); remove(this.old); }
        add(dest, this.cap, 1, dest === this.old);
      }
      oldByTid[this.t] = 0; capByTid[this.t] = 0;
    }
  });
  attach(0x17a173c, {onEnter() {
    if (!active) return;
    const t = thread(this.threadId);
    if (t < 0 || !capByTid[t]) return;
    const dst = num(this.context.x0), src = num(this.context.x1), size = num(this.context.x2);
    if (src !== oldByTid[t]) { invalid++; return; }
    pendingDst[t] = dst; pendingSrc[t] = src; pendingN[t] = size;
    record(3, this.threadId, src, dst, size, capacity(src), capByTid[t], 0x17a173c);
  }});
  // Do not install a second instruction hook four bytes after the copy hook:
  // overlapping arm64 Interceptor patch regions are not assumed safe.
  // Executed memcpy return is witnessed through the export hook below.
  attach(0x1d6d0, {
    onEnter(args) { this.p = active ? num(args[1]) : 0; this.c = capacity(this.p); const i = slot(this.p); this.birth = i < 0 ? 0 : liveBirth[i]; if (this.c) record(5, this.threadId, this.p, 0, 0, this.c, 0, 0); },
    onLeave() { if (this.c && active) { record(6, this.threadId, this.p, 0, 0, this.c, 0, 0); remove(this.p, this.birth); } }
  });
  attach(0x17a244c, {
    onEnter(args) {
      this.p = active ? num(args[0]) : 0; const t = thread(this.threadId);
      this.selected = t >= 0 && capByTid[t] !== 0 && oldByTid[t] === this.p;
      this.c = this.selected ? capacity(this.p) : 0;
      const i = slot(this.p); this.birth = i < 0 ? 0 : liveBirth[i];
      if (this.selected) record(7, this.threadId, this.p, 0, 0, this.c, 0, 0);
    },
    onLeave() { if (this.selected && active) { record(8, this.threadId, this.p, 0, 0, this.c, 0, 0); remove(this.p, this.birth); } }
  });
  attach(0x1c36c, {
    onEnter(args) { this.selected = active && args[2].equals(typeName); if (this.selected) { this.c = num(args[1]); record(10, this.threadId, 0, num(args[0]), this.c, 0, 0, 0); } },
    onLeave(ret) { if (this.selected && active) { const p = num(ret); record(11, this.threadId, 0, p, this.c, 0, 0, 2); add(p, this.c, 2, false); } }
  });
  attach(0x17a1140, {
    onEnter(args) { this.selected = active; if (this.selected) { this.old = num(args[1]); this.n = num(args[2]); this.actual = args[3]; this.delegate = num(args[0]); record(12, this.threadId, this.old, this.delegate, this.n, capacity(this.old), 0, 0); } },
    onLeave(ret) { if (this.selected && active) { let cap = 0; try { cap = this.actual.readU64().toNumber(); } catch (_) { invalid++; } record(13, this.threadId, this.old, num(ret), this.n, 0, cap, this.delegate); } }
  });
  // The neighboring free delegate tailcalls BufferFree. Final normal SSV frees
  // are observed separately through the common root-free entry above.
  // Do not attach the eight-byte leaf thunk: its adjacent code may be relocated.
  const copies = [];
  for (const name of ['memcpy', 'memmove']) {
    const address = Module.getGlobalExportByName(name);
    if (copies.some(p => p.equals(address))) continue;
    copies.push(address);
    listeners.push(Interceptor.attach(address, {
      onEnter(args) {
        this.selected = false;
        if (!active) return;
        const src = num(args[1]), size = num(args[2]), index = intersect(src, size);
        if (index < 0) return;
        this.selected = true; this.src = src; this.dst = num(args[0]); this.n = size;
        this.ca = liveCap[index]; this.t = thread(this.threadId);
        // Interceptor may relocate the original BL into a trampoline, changing
        // LR. Correlate exact native arguments with the same-thread call-site
        // record instead of assuming an unmodified return address.
        this.fromPa = this.t >= 0 && capByTid[this.t] !== 0 &&
          pendingSrc[this.t] === src && pendingDst[this.t] === this.dst && pendingN[this.t] === size;
        record(9, this.threadId, src, this.dst, size, this.ca, 0, num(this.returnAddress));
      },
      onLeave(ret) {
        if (!this.selected || !active || !this.fromPa) return;
        const t = this.t;
        if (t < 0 || pendingSrc[t] !== this.src || pendingDst[t] !== this.dst || pendingN[t] !== this.n) { invalid++; return; }
        if (num(ret) !== this.dst) invalid++;
        record(4, this.threadId, this.src, this.dst, this.n, this.ca, capByTid[t], num(ret));
        pendingDst[t] = 0; pendingSrc[t] = 0; pendingN[t] = 0;
      }
    }));
  }
  rpc.exports = {
    begin(value) {
      if (active || stopped) throw new Error('observer_already_active_or_stopped');
      for (let i = 0; i < THREAD_CAP; i++) if (capByTid[i]) throw new Error('native_realloc_still_active');
      label = String(value).slice(0, 128); used = 0; dropped = 0; invalid = 0; birth = 0;
      livePtr.fill(0); liveCap.fill(0); liveBirth.fill(0); liveOrigin.fill(0); pendingDst.fill(0); pendingSrc.fill(0); pendingN.fill(0);
      active = true;
      timer = setTimeout(() => { if (active) send({kind:'watchdog_end', result:end()}); }, WINDOW_MS);
      return {label, active:true, pid:Process.id, wall_ms:Date.now(), max_window_ms:WINDOW_MS};
    },
    snapshot, end, stop
  };
  send({kind:'ready', pid:Process.id, frida_version:Frida.version, runtime:Script.runtime,
    module_base:base.toString(), uuid:EXPECTED_UUID, window_ms:WINDOW_MS, record_cap:RECORD_CAP,
    observer:'native function and instruction hooks; fixed numeric Frida-VM storage; no payload reads',
    note:'Realloc delegate may be inlined. The shared PA realloc is the allocation event source.'});
} catch (error) {
  active = false;
  for (const listener of listeners) listener.detach();
  send({kind:'failed_closed', reason:String(error), no_measurement:true});
}
