'use strict';
// No hooks, target calls, payload reads, writes, or target-side file I/O.
const EXPECTED_PATH = '/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell';
const EXPECTED_UUID = '4c4c44c155553144a1ed87c8cc00f9e6';
function hex(bytes) { return Array.from(new Uint8Array(bytes), x => x.toString(16).padStart(2, '0')).join(''); }
function uuid(base) {
 let p=32, n=base.add(16).readU32();
 if(n>256) throw new Error('load_command_count');
 for(let i=0;i<n;i++) { const cmd=base.add(p).readU32(), size=base.add(p+4).readU32(); if(size<8||size>65536) throw new Error('load_command_size'); if(cmd===0x1b)return hex(base.add(p+8).readByteArray(16)); p+=size; }
 throw new Error('uuid_missing');
}
const checks = [
  [0x17a1140, 'f657bda9f44f01a9fd7b02a9fd830091f30303aaf40301aa155504b0a0ee46f9e10302aa74f9a397e20300aa600200f9a0ee46f923fd03b0636c2591e10314aafd7b42a9f44f41a9f657c3a801000014'],
  [0x17a1190, 'ff0303d1fc6f06a9fa6707a9f85f08a9f65709a9f44f0aa9fd7b0ba9fdc30291'],
  [0x17a172c, 'bf0208eba232889ae00317aae10314aa9bdad295e00314aa42030094f40317aa'],
  [0x1d6c0, 'e10300aa281105b000ed46f901000014'],
  [0x1d6d0, 'fa67bba9f85f01a9f65702a9f44f03a9fd7b04a9fd030191a10d00b4f40301aa'],
  [0x717086c, 'e00301aa94b33a16'],
  [0x1c36c, 'ff8302d1fc6f04a9fa6705a9f85f06a9f65707a9f44f08a9fd7b09a9fd430291'],
  [0x17a244c, 'fc6fbaa9fa6701a9f85f02a9f65703a9f44f04a9fd7b05a9fd430191f40300aa']
];
rpc.exports = { inspect() {
 if(Process.arch!=='arm64'||Process.platform!=='darwin'||Process.pointerSize!==8)throw new Error('wrong_platform');
 const m=Process.mainModule, u=uuid(m.base);
 if(m.path!==EXPECTED_PATH||u!==EXPECTED_UUID)throw new Error('binary_identity_mismatch');
 const results=[];
 for(const [offset,bytes]of checks){const actual=hex(m.base.add(offset).readByteArray(bytes.length/2)); results.push({offset,expected:bytes,actual,match:actual===bytes});}
 return {pid:Process.id,path:m.path,base:m.base.toString(),uuid:u,frida_version:Frida.version,runtime:Script.runtime,code_signing_policy:Process.codeSigningPolicy,checks:results,all_match:results.every(x=>x.match),hooks_installed:false};
}};
