
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100e59aa8 <_fontations_ffi$cxxbridge1$199$num_color_stops>:
1014e36d8: d10103ff    	sub	sp, sp, #0x40
1014e36dc: a90157f6    	stp	x22, x21, [sp, #0x10]
1014e36e0: a9024ff4    	stp	x20, x19, [sp, #0x20]
1014e36e4: a9037bfd    	stp	x29, x30, [sp, #0x30]
1014e36e8: 9100c3fd    	add	x29, sp, #0x30
1014e36ec: b4000661    	cbz	x1, 0x1014e37b8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689d10>
1014e36f0: aa0103f3    	mov	x19, x1
1014e36f4: aa0003f4    	mov	x20, x0
1014e36f8: f0046af5    	adrp	x21, 0x10a242000 <dyld_stub_binder+0x10a242000>
1014e36fc: f946eea0    	ldr	x0, [x21, #0xdd8]
1014e3700: f0041302    	adrp	x2, 0x109746000 <dyld_stub_binder+0x109746000>
1014e3704: 91256c42    	add	x2, x2, #0x95b
1014e3708: 97ace319    	bl	0x10001c36c <__text+0x1836c>
1014e370c: a9004fe0    	stp	x0, x19, [sp]
1014e3710: aa1403e1    	mov	x1, x20
1014e3714: aa1303e2    	mov	x2, x19
1014e3718: eb00029f    	cmp	x20, x0
1014e371c: 54000282    	b.hs	0x1014e376c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689cc4>
1014e3720: 95ddd2a5    	bl	0x108c581b4 <dyld_stub_binder+0x108c581b4>
1014e3724: b7f80393    	tbnz	x19, #0x3f, 0x1014e3794 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689cec>
1014e3728: cb1303e8    	neg	x8, x19
1014e372c: f100051f    	cmp	x8, #0x1
1014e3730: 5400038a    	b.ge	0x1014e37a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689cf8>
1014e3734: cb1303e9    	neg	x9, x19
1014e3738: eb08013f    	cmp	x9, x8
1014e373c: 5400038c    	b.gt	0x1014e37ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689d04>
1014e3740: 910003e0    	mov	x0, sp
1014e3744: 94261702    	bl	0x101e6934c <_cxxbridge1$string$new+0xa0884>
1014e3748: aa0003f3    	mov	x19, x0
1014e374c: f94003e1    	ldr	x1, [sp]
1014e3750: b50001c1    	cbnz	x1, 0x1014e3788 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689ce0>
1014e3754: aa1303e0    	mov	x0, x19
1014e3758: a9437bfd    	ldp	x29, x30, [sp, #0x30]
1014e375c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
1014e3760: a94157f6    	ldp	x22, x21, [sp, #0x10]
1014e3764: 910103ff    	add	sp, sp, #0x40
1014e3768: d65f03c0    	ret
1014e376c: 95ddd292    	bl	0x108c581b4 <dyld_stub_binder+0x108c581b4>
1014e3770: b7f802f3    	tbnz	x19, #0x3f, 0x1014e37cc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689d24>
1014e3774: eb13027f    	cmp	x19, x19
1014e3778: 54fffe4d    	b.le	0x1014e3740 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689c98>
1014e377c: d4200000    	brk	#0
1014e3780: d4400000    	hlt	#0
1014e3784: d4200020    	brk	#0x1
1014e3788: f946eea0    	ldr	x0, [x21, #0xdd8]
1014e378c: 97ace7d1    	bl	0x10001d6d0 <__text+0x196d0>
1014e3790: 17fffff1    	b	0x1014e3754 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689cac>
1014e3794: d4200000    	brk	#0
1014e3798: d4400000    	hlt	#0
1014e379c: d4200020    	brk	#0x1
1014e37a0: d4200000    	brk	#0
1014e37a4: d4400000    	hlt	#0
1014e37a8: d4200020    	brk	#0x1
1014e37ac: d4200000    	brk	#0
1014e37b0: d4400000    	hlt	#0
1014e37b4: d4200020    	brk	#0x1
1014e37b8: 52802f00    	mov	w0, #0x178              ; =376
1014e37bc: 95ddd260    	bl	0x108c5813c <dyld_stub_binder+0x108c5813c>
1014e37c0: aa0003f3    	mov	x19, x0
1014e37c4: 947f0207    	bl	0x1034a3fe0 <_media$cxxbridge1$199$init_symphonia_decoder+0x8ad590>
1014e37c8: 17ffffe3    	b	0x1014e3754 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x689cac>
1014e37cc: d4200000    	brk	#0
1014e37d0: d4400000    	hlt	#0
1014e37d4: d4200020    	brk	#0x1
