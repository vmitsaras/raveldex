#!/usr/bin/env python3
"""Bounded static candidate finder, not a semantic disassembler or runtime hook.

Admits thin little-endian ARM64 Mach-O only. Finds exact NUL-terminated literal
bytes, maps segments explicitly, decodes ADR/ADRP+ADD candidates, and uses the
linker's LC_FUNCTION_STARTS. Candidate register flows require disassembly review.
No browser execution and no automatic promotion of candidates to hook sites.
"""
import bisect
import hashlib
import json
import mmap
from pathlib import Path
import signal
import struct
import sys
import time

signal.alarm(55)
started = time.monotonic()
path = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
literal = b"SerializedScriptValue buffer\x00"
with path.open("rb") as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
    magic, cputype, _, _, ncmds, _, _, _ = struct.unpack_from("<8I", data, 0)
    assert magic == 0xfeedfacf and cputype == 0x100000c, "requires thin ARM64 Mach-O"
    sections, segments, function_data, uuid = [], [], None, None
    cursor = 32
    for _ in range(ncmds):
        command, size = struct.unpack_from("<II", data, cursor)
        if command == 0x19:
            _, _, rawname, vmaddr, vmsize, fileoff, filesize, _, _, count, _ = struct.unpack_from("<II16s4Q4I", data, cursor)
            name = rawname.split(b"\0")[0].decode()
            segments.append({"name": name, "vmaddr": vmaddr, "vmsize": vmsize, "fileoff": fileoff, "filesize": filesize})
            for index in range(count):
                s = struct.unpack_from("<16s16sQQ8I", data, cursor + 72 + index * 80)
                sections.append({"name": s[0].split(b"\0")[0].decode(), "segment": s[1].split(b"\0")[0].decode(), "address": s[2], "size": s[3], "offset": s[4]})
        elif command == 0x26:
            function_data = struct.unpack_from("<II", data, cursor + 8)
        elif command == 0x1b:
            uuid = data[cursor + 8:cursor + 24].hex()
        cursor += size
    base = next(s["vmaddr"] for s in segments if s["name"] == "__TEXT")
    text = next(s for s in sections if s["name"] == "__text" and s["segment"] == "__TEXT")
    strings = []
    cursor = 0
    while (cursor := data.find(literal, cursor)) >= 0:
        section = next((s for s in sections if s["offset"] <= cursor < s["offset"] + s["size"]), None)
        if section:
            strings.append({"file_offset": cursor, "address": section["address"] + cursor - section["offset"], "section": section["name"]})
        cursor += len(literal)
    addresses = {s["address"] for s in strings}
    pages = {a & ~4095 for a in addresses}
    functions = []
    boundary_provenance = "LC_FUNCTION_STARTS"
    if function_data:
        cursor, size = function_data
        end, address = cursor + size, base
        while cursor < end:
            value, shift = 0, 0
            while cursor < end:
                byte = data[cursor]
                cursor += 1
                value |= (byte & 127) << shift
                shift += 7
                if not byte & 128:
                    break
            if value == 0:
                break
            address += value
            functions.append(address)
    if not functions:
        boundary_provenance = "__unwind_info compact-unwind entries; leaf gaps possible"
        unwind = next(s for s in sections if s["name"] == "__unwind_info")
        ubase = unwind["offset"]
        version, _, _, _, _, index_offset, index_count = struct.unpack_from("<7I", data, ubase)
        assert version == 1
        for index in range(index_count - 1):
            first_function, page_offset, _ = struct.unpack_from("<III", data, ubase + index_offset + index * 12)
            page = ubase + page_offset
            kind, entry_offset, entry_count = struct.unpack_from("<IHH", data, page)
            assert kind in (2, 3), "unknown compact-unwind page format"
            for entry_index in range(entry_count):
                if kind == 2:
                    function_offset, _ = struct.unpack_from("<II", data, page + entry_offset + entry_index * 8)
                else:
                    encoded, = struct.unpack_from("<I", data, page + entry_offset + entry_index * 4)
                    function_offset = first_function + (encoded & 0xffffff)
                functions.append(base + function_offset)
        functions = sorted(set(functions))
    assert functions, "no linker function starts or compact-unwind entries available"

    def bounds(address):
        index = bisect.bisect_right(functions, address) - 1
        assert index >= 0
        start = functions[index]
        end = functions[index + 1] if index + 1 < len(functions) else text["address"] + text["size"]
        return start, end

    def signed(value, bits):
        return value - (1 << bits) if value & (1 << (bits - 1)) else value

    candidates = []
    view = memoryview(data)[text["offset"]:text["offset"] + text["size"]]
    for index, (instruction,) in enumerate(struct.iter_unpack("<I", view)):
        pc = text["address"] + index * 4
        if instruction & 0x9f000000 == 0x90000000:
            imm = ((instruction >> 5 & 0x7ffff) << 2) | (instruction >> 29 & 3)
            page = (pc & ~4095) + (signed(imm, 21) << 12)
            if page not in pages:
                continue
            register = instruction & 31
            for distance in range(1, 17):
                offset = index * 4 + distance * 4
                if offset + 4 > len(view):
                    break
                add, = struct.unpack_from("<I", view, offset)
                if add & 0xff000000 != 0x91000000 or (add >> 5 & 31) != register:
                    continue
                resolved = page + ((add >> 10 & 4095) << (12 if add >> 22 & 1 else 0))
                if resolved in addresses:
                    start, end = bounds(pc)
                    candidates.append({"kind": "ADRP_ADD", "reference_pc": pc, "add_pc": pc + distance * 4, "literal_address": resolved, "adrp_register": register, "distance_instructions": distance, "function_start": start, "function_end_exclusive": end})
        elif instruction & 0x9f000000 == 0x10000000:
            imm = ((instruction >> 5 & 0x7ffff) << 2) | (instruction >> 29 & 3)
            resolved = pc + signed(imm, 21)
            if resolved in addresses:
                start, end = bounds(pc)
                candidates.append({"kind": "ADR", "reference_pc": pc, "literal_address": resolved, "function_start": start, "function_end_exclusive": end})
    del view
    dossiers = []
    for start in sorted({item["function_start"] for item in candidates}):
        _, end = bounds(start)
        offset = text["offset"] + start - text["address"]
        size = end - start
        assert size <= 65536, "candidate function exceeds bounded review size"
        payload = data[offset:offset + size]
        calls = []
        for index, (instruction,) in enumerate(struct.iter_unpack("<I", payload)):
            if instruction & 0xfc000000 == 0x94000000:
                pc = start + index * 4
                calls.append({"pc": pc, "target": pc + (signed(instruction & 0x3ffffff, 26) << 2)})
        dossiers.append({"address": start, "module_offset": start - base, "file_offset": offset, "end_exclusive": end, "size_bytes": size, "sha256": hashlib.sha256(payload).hexdigest(), "first_32_bytes_hex": payload[:32].hex(), "direct_bl_calls": calls})
    result = {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "uuid_hex": uuid, "image_vmaddr": base,
              "text": text, "literal": literal[:-1].decode(), "literal_occurrences": strings, "function_count": len(functions), "boundary_provenance": boundary_provenance,
              "candidates": candidates, "candidate_functions": dossiers, "elapsed_seconds": round(time.monotonic() - started, 6),
              "limitations": ["ADRP+ADD pairs are candidate register flows until manually reviewed; no write/clobber analysis is performed.", "Only ADR and ADRP+ADD encodings and the exact NUL-terminated literal are searched.", "Function ranges come from linker starts or compact-unwind entries; compact unwind may omit leaf functions, so ranges are review windows until instruction review.", "Static identity does not establish safe attachment or executed-path coverage."]}
    with output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
print(json.dumps({"output": str(output), "literal_occurrences": strings, "candidate_functions": [{"address": hex(d["address"]), "offset": hex(d["module_offset"]), "size": d["size_bytes"], "calls": [{"pc": hex(c["pc"]), "target": hex(c["target"])} for c in d["direct_bl_calls"]]} for d in dossiers], "elapsed_seconds": result["elapsed_seconds"]}))
