import sys, json, pathlib, hashlib, time, subprocess
root=pathlib.Path('/tmp/raveldex-ac03-workloads-20261028.A7m1DC')
sys.path.insert(0,str(root/'frida-python'))
import frida
pid=53079
record={'schema':'raveldex-owned-frida-access-v1','pid':pid,'frida':frida.__version__,'startedUnix':time.time(),'hooksInstalled':False}
session=None
try:
    owner=json.loads((root/'browser-control/report.json').read_text())
    assert owner['rendererPid']==pid and owner['browserPid']==53075
    image=pathlib.Path(owner['executable'])
    digest=hashlib.sha256(image.read_bytes()).hexdigest()
    assert digest==owner['binarySha256']=='a0bfe7b4da4787b66058477d696cd1d09065d25f06a548947722b9af77ee8282'
    ps=subprocess.run(['/bin/ps','-p',str(pid),'-o','pid=,ppid=,command='],capture_output=True,text=True,timeout=5)
    record['ps']={'exitCode':ps.returncode,'stdout':ps.stdout,'stderr':ps.stderr}
    assert ps.returncode==0 and '--type=renderer' in ps.stdout and str(owner['browserPid']) in ps.stdout
    session=frida.get_local_device().attach(pid)
    code="""rpc.exports={probe(){const m=Process.enumerateModules().find(m=>m.name==='chrome-headless-shell');if(!m)throw Error('Expected image missing');return {pid:Process.id,arch:Process.arch,frida:Frida.version,runtime:Script.runtime,module:{name:m.name,path:m.path,base:m.base.toString(),size:m.size},reallocPrefix:Array.from(new Uint8Array(m.base.add(0x17a1140).readByteArray(80))).map(x=>x.toString(16).padStart(2,'0')).join('')};}};"""
    script=session.create_script(code,runtime='qjs');script.load();record['probe']=script.exports_sync.probe()
    expected=json.loads((root/'browser-route/headless-hook-candidates.json').read_text())
    assert record['probe']['pid']==pid and record['probe']['arch']=='arm64'
    assert record['probe']['reallocPrefix']==expected['sites']['delegate_reallocate']['bytes_hex']
    script.unload();record['outcome']='Pass: task-owned native access and exact in-memory bytes; no hooks installed'
except Exception as error:
    record['outcome']='Fail';record['error']={'name':type(error).__name__,'message':str(error)}
finally:
    if session is not None:
        try: session.detach();record['detached']=True
        except Exception as error:record['detachError']=str(error)
    record['finishedUnix']=time.time()
    with (root/'browser-control/frida-access.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
sys.exit(0 if record['outcome'].startswith('Pass') else 1)
