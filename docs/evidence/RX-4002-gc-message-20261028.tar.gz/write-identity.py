from pathlib import Path
import hashlib,json
repo=Path('/Users/vasilis/Documents/GitHub/raveldex');r=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e')
def read(p):return json.loads((r/p).read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def ref(p):return {'member':p,'sha256':sha(r/p)}
accepted=[]
for label,path in [('source-export-1000','review/gc-codec-pilot-audit-final.json'),('source-restore-1000-512mib','review/gc-codec-receiver-512-audit.json')]:
 x=read(path)[0];assert x['valid'] and x['independentReplay']=='Pass' and x['prefixFailure'] is None
 accepted.append({'label':label,**x,'auditMember':path})
native=read('browser/calibration-summary.json')
j={'schema':'raveldex-gc-message-evidence-v1','localDate':'2026-10-28','task':'RX-4002','status':'blocked','baseCommit':'8933191','productionChanged':False,'publicContractsChanged':False,'acceptanceCriteriaChanged':False,'runtimeDependenciesChanged':False,'archive':read('archive-summary.json'),
'runtime':{'path':str(r/'gc/node-gc-v3'),'sha256':sha(r/'gc/node-gc-v3'),'priorPreservedRuntimeSha256':'28d5845f1e59182b5c8d81403836500728972b9816a7195f49e3442fcb9b5e67','compiledSource':ref('gc/source-identity-v3-final.json'),'patch':ref('gc/gc-extension-v3.patch'),'reapplication':ref('gc/patch-reapplication-control.log'),'sourceIsolation':ref('gc/source-isolation-status.json'),'flags':['--expose-internals','--expose-gc','--no-inline-new','--no-turbo-allocation-folding','--single-threaded','--no-incremental-marking'],'pilotSemiSpaceFlags':['--min-semi-space-size=16','--max-semi-space-size=16']},
'package':{'tarballSha256':'6ff6e90128f60af39bb8f47800c61ed83d85d4ded7a8e3c96d2bd34467f9c437','productionFiles':208,'publicPilotHosts':[ref(p) for p in ['codec-pilot/host.json','codec-receiver/host.json','codec-receiver-512/host.json']]},
'managedMetric':'New monitored managed occupied extents at mutator frontiers/completed-GC checkpoints, includes managed host/harness, excludes preexisting state, collector overlap, native observer storage, external backing and OS/process physical memory; no baseline subtraction.',
'nativeRecorderBounds':{'maps':5,'activeExtentsPerMapOnPilots':1000000,'stdioBufferBytes':65536,'streamCapsMiB':[128,512],'mapNativeAllocatorBytesNotMeasured':True},
'acceptedSourcePilots':accepted,'invalidReceiver128MiB':read('review/gc-codec-receiver-audit.json'),'managedControls':[ref(p) for p in ['gc/controls-v3-report.json','review/gc-independent-replay.json','review/gc-other-controls-replay.json','review/gc-calibration-review.json','review/gc-literal-tests.log','gc/overhead-v3-report.json']],
'browser':{'summary':native,'raw':ref('browser/native-run-1/tap-5-export-gc-drain.json'),'controller':ref('browser/controller-run-1/report.json'),'install':ref('browser/native-run-1/lldb-install.json'),'replay':ref('browser/replay-final.json'),'independentReview':ref('review/native-protocol-raw-review.json'),'cleanup':ref('browser-cleanup.json'),'scope':'Four-record actual public worker/source-snapshot session;16protocol-boundmessage buffers freed after explicit debugger GC drains;selected growth copies only, no global/physical/fullpayloadcopy peak or product-size matrix.'},
'independentReviews':[ref(p) for p in ['review/harness-review.json','review/native-preflight-review.json','review/gc-source-review.json','review/gc-calibration-review.json','review/gc-public-pilot-review.json']],
'checks':{'npmCi':'Pass','baselineNpmCheck':{'tests':616,'pass':616,'fail':0},'messageObserverTests':{'tests':2,'pass':2},'gcLiteralTests':{'tests':4,'pass':4},'nativeObserverTests':{'tests':16,'pass':16},'archiveNegativeChecks':ref('review/archive-negative-checks.json'),'finalNpmCheck':'pending','archiveCheck':'pending'},
'remaining':['Remaining relevant source/native/positions codec configurations at 1,000/10,000 records, with any concrete unsupported event/cap extension separately calibrated.','Native full payload-copy routes, actual in-place calibration and 1,000/10,000 real browser message matrix.'],'humanATRepeatPending':False,'next':'Continue RX-4002 AC03; RX-4003 waits; N5 remains deferred. No publication/remote write.'}
j['sourceTools']={str(p.relative_to(repo)):sha(p) for p in sorted((repo/'bench/memory').glob('*')) if p.name in ['gc-codec-pilot.mjs','gc-codec-receiver.mjs','gc-runtime-audit.py','gc-runtime-audit.test.py','browser-message-control.mjs','message-observer.mjs','message-observer.test.mjs','message-worker.mjs','message-fixture.mjs','runtime-archive.py']}
(repo/'docs/evidence/RX-4002-gc-message-identity-20261028.json').write_text(json.dumps(j,indent=2)+'\n')
print('identity written; final check intentionally pending')
