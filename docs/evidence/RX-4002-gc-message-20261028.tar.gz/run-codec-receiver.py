import pathlib,hashlib,json,subprocess,tempfile,shutil,os,time
root=pathlib.Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e'); repo=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex'); consumer=pathlib.Path('/private/var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz'); runtime=root/'gc/node-gc-v3'; out=root/'codec-receiver'; out.mkdir()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert sha(runtime)=='ad443b2a6fc8092abeeb3ae8c6405e101cf15fc531f05eb769da4707d5154ae0'
assert sha(consumer/'vmitsaras-raveldex-0.0.0.tgz')=='6ff6e90128f60af39bb8f47800c61ed83d85d4ded7a8e3c96d2bd34467f9c437'
installed=consumer/'node_modules/@vmitsaras/raveldex'; files=[]
for p in sorted((installed/'dist').rglob('*')):
 if p.is_file():
  rel=p.relative_to(installed); digest=sha(p); assert digest==sha(repo/rel); files.append({'path':str(rel),'sha256':digest})
assert len(files)==208
staged=pathlib.Path(tempfile.mkdtemp(prefix='gc-codec-',dir=consumer)); sources=[]
for source,name in [('bench/memory/gc-codec-receiver.mjs','gc-codec-receiver.mjs'),('bench/cost-common.mjs','cost-fixture.mjs')]:
 target=staged/name;shutil.copyfile(repo/source,target);sources.append({'path':source,'target':str(target),'sha256':sha(target)})
flags=['--expose-internals','--expose-gc','--no-inline-new','--no-turbo-allocation-folding','--single-threaded','--no-incremental-marking','--min-semi-space-size=16','--max-semi-space-size=16']
argv=[str(runtime),*flags,str(staged/'gc-codec-receiver.mjs'),str(out),str(root/'codec-pilot/encoded-source.json')]
record={'schema':'raveldex-bounded-codec-receiver-host-v1','argv':argv,'runtimeSha256':sha(runtime),'files':files,'sources':sources,'timeoutSeconds':180,'started':time.time()}
try:
 p=subprocess.run(argv,cwd=consumer,env={k:os.environ[k] for k in ['PATH','TMPDIR','LANG','LC_ALL'] if k in os.environ},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (out/'stdout.log').write_bytes(p.stdout);(out/'stderr.log').write_bytes(p.stderr);record['exitCode']=p.returncode
except subprocess.TimeoutExpired as e:
 (out/'stdout.log').write_bytes(e.stdout or b'');(out/'stderr.log').write_bytes(e.stderr or b'');record['timedOut']=True
finally:
 record['finished']=time.time();record['runtimeUnchanged']=sha(runtime)==record['runtimeSha256'];record['productionUnchanged']=all(sha(installed/x['path'])==x['sha256'] and sha(repo/x['path'])==x['sha256'] for x in files);record['sourcesUnchanged']=all(sha(repo/x['path'])==x['sha256'] and sha(pathlib.Path(x['target']))==x['sha256'] for x in sources);(out/'host.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['files','sources','argv']}))
