import pathlib,hashlib,json,tarfile,gzip,io
root=pathlib.Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e')
output=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex/docs/evidence/RX-4002-gc-message-20261028.tar.gz')
allowed={'.json','.jsonl','.log','.md','.py','.mjs','.js','.cjs','.asm','.txt','.patch','.inc','.h','.cc','.cpp','.rdxgc','.html'}
paths=[]
for folder in ['gc','browser','review','codec-pilot','codec-receiver','codec-receiver-512','controller-smoke','executed-sources']:
 for p in (root/folder).rglob('*'):
  if 'node-v24.21.0' in p.relative_to(root).parts or '__pycache__' in p.parts or 'pycache' in p.parts:continue
  if p.is_file() and not p.is_symlink() and p.suffix in allowed:paths.append(p)
for p in root.iterdir():
 if p.is_file() and p.suffix in allowed and p.name not in ['archive-summary.json']:paths.append(p)
records=[]
for p in sorted(set(paths)):
 size=p.stat().st_size
 assert size>0 or p.suffix=='.log',str(p)+' unexpected empty artifact'
 assert size<=256*1024*1024
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 records.append({'name':str(p.relative_to(root)),'bytes':size,'sha256':h.hexdigest()})
assert sum(x['bytes'] for x in records)<1024*1024*1024
manifest={'schema':'raveldex-ac03-workload-archive-v1','originalRoot':str(root),'scope':'GC-aware runtime source/calibration, raw public source-codec pilots and actual protocol-bound native browser buffer lifetimes; binaries/build tree/caches excluded. Numerical scope separate from bytes.','members':records}
raw=json.dumps(manifest,indent=2).encode()+b'\n'
with output.open('xb') as target:
 with gzip.GzipFile(filename='',mode='wb',fileobj=target,compresslevel=9,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w|') as tar:
   info=tarfile.TarInfo('MANIFEST.json');info.size=len(raw);info.mode=0o600;tar.addfile(info,io.BytesIO(raw))
   for r in records:
    info=tarfile.TarInfo(r['name']);info.size=r['bytes'];info.mode=0o600
    with (root/r['name']).open('rb') as f:tar.addfile(info,f)
h=hashlib.sha256()
with output.open('rb') as f:
 for b in iter(lambda:f.read(1048576),b''):h.update(b)
summary={'path':str(output),'bytes':output.stat().st_size,'sha256':h.hexdigest(),'members':len(records),'memberBytes':sum(x['bytes'] for x in records),'manifestSha256':hashlib.sha256(raw).hexdigest()}
(root/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
