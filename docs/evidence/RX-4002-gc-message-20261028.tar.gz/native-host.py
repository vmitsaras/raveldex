import os,pty,subprocess,sys,select,signal,time,json,pathlib
root=pathlib.Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser')
config=json.loads((root/'observer-config.json').read_text()); pid=config['pid']
assert isinstance(pid,int) and pid>0
out=pathlib.Path(config['output']).resolve();assert out.is_relative_to(root);out.mkdir(exist_ok=True)
args=['/Library/Developer/CommandLineTools/usr/bin/lldb','--no-lldbinit','-p',str(pid),'-o','command script import '+str(root/'lldb_native_tap.py'),'-o','rx-install '+str(root/'observer-config.json')]
master,slave=pty.openpty(); started=time.monotonic(); child=subprocess.Popen(args,stdin=slave,stdout=slave,stderr=slave,start_new_session=True);os.close(slave)
record={'schema':'raveldex-bounded-native-host-v2','ownedDebuggerPid':child.pid,'targetPid':pid,'command':args,'timeoutSeconds':420,'startedUnix':time.time()};timed=False;deadline=None
log=(out/'observer.log').open('xb');total=0

def interrupt(signum,frame):
 try:os.killpg(child.pid,signal.SIGINT)
 except ProcessLookupError:pass
signal.signal(signal.SIGINT,interrupt)
try:
 while child.poll() is None:
  if not timed and time.monotonic()-started>420:
   timed=True;deadline=time.monotonic()+12;interrupt(None,None);os.write(master,b'rx-end\nrx-cleanup\nprocess detach\nquit\n')
  if timed and time.monotonic()>deadline:
   os.killpg(child.pid,signal.SIGTERM);break
  ready,_,_=select.select([master,sys.stdin],[],[],.2)
  if master in ready:
   try:b=os.read(master,65536)
   except OSError:b=b''
   if b:
    total+=len(b)
    if total>16*1024*1024:raise RuntimeError('Owned debugger output limit')
    log.write(b);log.flush();os.write(sys.stdout.fileno(),b)
  if sys.stdin in ready:
   b=os.read(sys.stdin.fileno(),4096)
   if not b:interrupt(None,None);os.write(master,b'rx-cleanup\nprocess detach\nquit\n');continue
   os.write(master,b)
 child.wait(timeout=8)
finally:
 if child.poll() is None:
  interrupt(None,None)
  try:os.write(master,b'rx-end\nrx-cleanup\nprocess detach\nquit\n');child.wait(timeout=8)
  except Exception:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
 record.update(exitCode=child.returncode,timedOut=timed,finishedUnix=time.time(),logBytes=total);log.close();os.close(master)
 with (out/'observer-host.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
