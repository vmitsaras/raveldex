"""Static byte identity only. Does not launch or attach any process."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path('/tmp/raveldex-ac03-workloads-20261028.A7m1DC/browser-route/headless-hook-candidates.json')
manifest = json.loads(OLD.read_text())
digest = hashlib.sha256()
with Path(manifest['binary']).open('rb') as source:
    for chunk in iter(lambda: source.read(1024 * 1024), b''):
        digest.update(chunk)
assert digest.hexdigest() == manifest['sha256']
with Path(manifest['binary']).open('rb') as source:
    for name, offset, length in [
        ('typed_buffer_alloc', 0x1c36c, 32),
        ('internal_realloc_free', 0x17a244c, 32),
        ('ssv_destructor', 0x19ca0c8, 32),
        ('ssv_final_free_call', 0x19ca1fc, 44),
        ('ssv_consume_take_buffer', 0x7177fc0, 92),
    ]:
        source.seek(offset)
        raw = source.read(length)
        assert len(raw) == length
        manifest['sites'][name] = dict(module_offset=hex(offset), file_offset=hex(offset),
                                      bytes_hex=raw.hex(), size=length,
                                      sha256=hashlib.sha256(raw).hexdigest(),
                                      status='static_bytes_verified_runtime_calibration_pending')
manifest['sourceFiles'] = {str(path.relative_to(ROOT)): dict(bytes=path.stat().st_size,
    sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in sorted((ROOT/'sources').iterdir()) if path.is_file()}
manifest['decoderPolicy'] = 'Blink21/V8-16 exact plain-object prefix; stop before payload/value; 256 byte limit'
manifest['priorManifestSha256'] = hashlib.sha256(OLD.read_bytes()).hexdigest()
(ROOT/'hook-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(binarySha256=digest.hexdigest(), sites=len(manifest['sites']), sources=len(manifest['sourceFiles']))))
