import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest

from wire_metadata import decode, PrefixError

# Hand-stated metadata prefix: Blink21, 12 zero trailer bytes, V8-16 object.
HEADER = bytes.fromhex('ff15fe000000000000000000000000ff106f')
SESSION = '01234567-89ab-cdef-0123-456789abcdef'
REQUEST = HEADER + b'"\x08protocolI\x02"\x07session"\x24' + SESSION.encode() + b'"\x02idI\x0e"\x09operation"\x06search"\x07payload'
RESPONSE = REQUEST[:-9] + b'"\x04kind"\x06result"\x05value'


class PrefixTests(unittest.TestCase):
    def parse(self, data, prefix):
        reads = []
        def read(offset, count):
            reads.append((offset, count))
            self.assertLessEqual(offset+count, len(prefix))
            return data[offset:offset+count]
        result = decode(read, len(data))
        self.assertEqual(result['prefixHex'], prefix.hex())
        self.assertEqual(result['prefixBytes'], len(prefix))
        self.assertEqual(result['session'], SESSION)
        self.assertEqual(result['id'], 7)
        self.assertEqual(result['operation'], 'search')
        return result

    def test_request_never_reads_payload(self):
        self.assertEqual(self.parse(REQUEST+b'payload must not be read', REQUEST)['direction'], 'main-to-worker')

    def test_response_never_reads_value(self):
        result = self.parse(RESPONSE+b'value must not be read', RESPONSE)
        self.assertEqual(result['direction'], 'worker-to-main')
        self.assertEqual(result['kind'], 'result')

    def test_all_truncated_prefixes_reject(self):
        for end in range(len(REQUEST)):
            with self.subTest(end=end), self.assertRaises(PrefixError):
                decode(lambda offset,count:REQUEST[offset:offset+count],end)

    def test_wrong_version_rejects(self):
        for location in (1,16):
            wrong=bytearray(REQUEST);wrong[location]=0
            with self.assertRaises(PrefixError):
                decode(lambda offset,count:wrong[offset:offset+count],len(wrong))

    def test_large_string_length_refuses_before_content(self):
        wrong=REQUEST.replace(b'"\x24',b'"\x7f')
        with self.assertRaises(PrefixError):
            decode(lambda offset,count:wrong[offset:offset+count],len(wrong))

    def test_wrong_protocol(self):
        wrong=REQUEST.replace(b'protocolI\x02',b'protocolI\x04')
        with self.assertRaises(PrefixError):
            decode(lambda offset,count:wrong[offset:offset+count],len(wrong))


class Error:
    def Fail(self): return False

class Register:
    def __init__(self,value): self.value=value
    def IsValid(self): return True
    def GetError(self): return Error()
    def GetValueAsUnsigned(self): return self.value

class Frame:
    def __init__(self,pc,sp,lr,**registers): self.values=dict(pc=pc,sp=sp,lr=lr,fp=sp+32,**registers)
    def FindRegister(self,name): return Register(self.values.get(name,0))
    def GetThread(self): return self
    def GetThreadID(self): return 91
    def GetPC(self): return self.values['pc']


class ObserverTests(unittest.TestCase):
    def setUp(self):
        sys.modules['lldb']=types.SimpleNamespace(SBError=Error)
        path=Path(__file__).with_name('lldb_native_tap.py')
        spec=importlib.util.spec_from_file_location('tested_tap',path)
        self.tap=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.tap)
        self.tap.CONFIG=dict(pid=1234,peer='task-worker',mainTid=91,workerTid=92)
        self.tap.INSTALLED=True
        self.tap.breakpoint=lambda *args,**kwargs:None
        self.results=types.SimpleNamespace(PutCString=lambda _:None,SetError=lambda message:self.fail(message))

    def test_window_switch_preserves_registry_and_births(self):
        tap=self.tap;tap.begin(None,'first',self.results,None);tap.add(1000,216,1,'realloc',91)
        tap.begin(None,'drain',self.results,None)
        self.assertEqual(tap.LIVE[1000]['allocation'],1)
        self.assertEqual(tap.LIVE[1000]['birthWindow'],'first')
        self.assertEqual(tap.ROWS[0]['seq'],1)
        self.assertEqual(len(tap.WINDOWS),2)

    def test_same_return_pc_wrong_sp_does_not_pop(self):
        tap=self.tap;tap.ACTIVE=True;tap.pending(Frame(100,8000,200),'copy',dict(src=1,dest=2,length=3,chain=1))
        tap.callback(Frame(200,7000,300,x0=2),None,None)
        self.assertEqual(len(tap.CALLS[91]),1)
        tap.callback(Frame(200,8000,300,x0=2),None,None)
        self.assertEqual(tap.CALLS[91],[])
        matched=[r for r in tap.ROWS if r['kind']=='native-call-return'][0]
        self.assertEqual(matched['matchedSP'],8000)
        self.assertEqual(matched['matchedLR'],200)

    def test_final_free_only_retires_at_matching_return(self):
        tap=self.tap;tap.ACTIVE=True;tap.BASE=0x100000000
        tap.add(1000,216,1,'realloc',91)
        site=tap.BASE+0x19ca210;tap.ROLES[site]='final-free';tap.ROLES[tap.BASE+0x1d6d0]='root-free'
        tap.pending(Frame(tap.BASE+0x19ca0c8,9000,444),'destructor',dict(ptr=1000,owner=5000,allocation=1))
        tap.callback(Frame(site,8000,333,x1=1000,x19=5000),None,None)
        tap.callback(Frame(tap.BASE+0x1d6d0,8000,site+4,x1=1000),None,None)
        self.assertIn(1000,tap.LIVE)
        tap.callback(Frame(site+4,8000,site+4),None,None)
        self.assertNotIn(1000,tap.LIVE)
        self.assertEqual(tap.INVALID,[])
        self.assertEqual(sum(r['kind']=='final-free-return' for r in tap.ROWS),1)
        self.assertEqual(sum(r['kind']=='final-free-root-enter' for r in tap.ROWS),1)

    def test_final_free_without_destructor_refuses_qualification(self):
        tap=self.tap;tap.ACTIVE=True;tap.BASE=0x100000000;tap.add(1000,216,1,'realloc',91)
        site=tap.BASE+0x19ca210;tap.ROLES[site]='final-free'
        tap.callback(Frame(site,8000,333,x1=1000,x19=5000),None,None)
        self.assertIn('final_free_without_matching_destructor',tap.INVALID)
        self.assertIn(1000,tap.LIVE)
        self.assertFalse(any(r['kind']=='final-free-enter' for r in tap.ROWS))

    def test_wrong_destructor_owner_refuses_qualification(self):
        tap=self.tap;tap.ACTIVE=True;tap.BASE=0x100000000;tap.add(1000,216,1,'realloc',91)
        tap.pending(Frame(tap.BASE+0x19ca0c8,9000,444),'destructor',dict(ptr=1000,owner=5001,allocation=1))
        site=tap.BASE+0x19ca210;tap.ROLES[site]='final-free'
        tap.callback(Frame(site,8000,333,x1=1000,x19=5000),None,None)
        self.assertIn('final_free_without_matching_destructor',tap.INVALID)

    def test_record_limit_disarms_observation(self):
        tap=self.tap;tap.ACTIVE=True;tap.MAX_ROWS=1
        tap.event('one',0);tap.event('two',0)
        self.assertFalse(tap.ACTIVE)
        self.assertEqual(len(tap.ROWS),1)
        self.assertEqual(tap.DROPPED,1)

    def test_binding_limit_disarms_without_unbounded_map(self):
        tap=self.tap;tap.ACTIVE=True;tap.MAX_BINDINGS=0;tap.add(1000,len(REQUEST),1,'realloc',91)
        class Process:
            def ReadMemory(self,address,count,error):return REQUEST[address-1000:address-1000+count]
        tap.TARGET=types.SimpleNamespace(GetProcess=lambda:Process())
        tap.metadata(Frame(10,8000,20),1000,len(REQUEST))
        self.assertFalse(tap.ACTIVE)
        self.assertEqual(tap.BINDINGS,{})
        self.assertIn('binding_limit',tap.INVALID)

    def test_window_limit_disarms_without_new_window(self):
        tap=self.tap;tap.ACTIVE=True;tap.MAX_WINDOWS=0
        errors=[];result=types.SimpleNamespace(SetError=errors.append)
        tap.begin(None,'excess',result,None)
        self.assertFalse(tap.ACTIVE)
        self.assertEqual(tap.WINDOWS,[])
        self.assertEqual(errors,['Window limit'])

    def test_generation_mismatch_retains_new_birth(self):
        tap=self.tap;tap.add(1000,216,1,'realloc',91);tap.drop(1000,1)
        tap.add(1000,216,2,'realloc',91);tap.drop(1000,1)
        self.assertIn(1000,tap.LIVE)
        self.assertIn('free_birth_mismatch',tap.INVALID)


class RawReplayTests(unittest.TestCase):
    def test_literal_tampering_refusals(self):
        from audit_tap import audit
        root=Path(__file__).parent
        path=root/'native-run-1/tap-5-export-gc-drain.json'
        original=json.loads(path.read_text())
        cases=[]
        wrong=json.loads(json.dumps(original));next(row for row in wrong['rows'] if row['kind']=='native-call-return')['matchedSP']+=16;cases.append(wrong)
        wrong=json.loads(json.dumps(original));next(row for row in wrong['rows'] if row['kind']=='final-free-root-enter')['nativeFrame']['moduleOffset']+=4;cases.append(wrong)
        wrong=json.loads(json.dumps(original));next(row for row in wrong['rows'] if row['kind']=='final-free-return')['allocation']+=1;cases.append(wrong)
        wrong=json.loads(json.dumps(original));next(row for row in wrong['rows'] if row['kind']=='message-bound')['metadata']['id']+=1;cases.append(wrong)
        wrong=json.loads(json.dumps(original));wrong['bindings'][next(iter(wrong['bindings']))]['peer']='spoofed';cases.append(wrong)
        with tempfile.TemporaryDirectory(dir=root) as directory:
            for index,wrong in enumerate(cases):
                trial=Path(directory)/str(index);trial.write_text(json.dumps(wrong))
                with self.subTest(case=index),self.assertRaises(AssertionError):audit(trial)


if __name__=='__main__':unittest.main(verbosity=2)
