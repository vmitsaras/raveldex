"""Offline assertions over cumulative native rows. No browser/LLDB imports."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

from wire_metadata import decode


def audit(path):
    record=json.loads(Path(path).read_text())
    assert record['schema']=='raveldex-lldb-buffer-observation-v2'
    assert record['dropped']==0 and record['invalid']==[] and record['pending']=={}
    rows=record['rows'];live={};calls={};births={};bound={};free_calls={};closed=[];api_retirements=[]
    counts=Counter()
    for expected_seq,row in enumerate(rows,1):
        assert row['seq']==expected_seq and row['pid']==record['pid']
        kind=row['kind'];counts[kind]+=1;tid=row['tid'];frame=row['nativeFrame']
        if tid:
            assert isinstance(frame,dict) and all(isinstance(frame[key],int) and frame[key]>=0 for key in ('pc','sp','lr','fp','moduleOffset'))
        if kind=='native-call-begin':
            ctx=row['call'];stack=calls.setdefault(tid,[])
            assert ctx['entryPC']==frame['pc'] and ctx['sp']==frame['sp'] and ctx['lr']==frame['lr']
            assert ctx['parentCallId']==(stack[-1]['callId'] if stack else None)
            assert ctx['callId'] not in {entry['callId'] for entries in calls.values() for entry in entries}
            stack.append(ctx)
        elif kind=='native-call-return':
            ctx=calls[tid].pop()
            assert ctx['callId']==row['callId']
            assert ctx['sp']==frame['sp']==row['matchedSP']
            assert ctx['returnPC']==frame['pc']==row['matchedReturnPC']
            assert ctx['lr']==row['matchedLR'] and ctx['entryPC']==row['matchedEntryPC']
            if ctx['kind']=='final-free':
                assert free_calls[ctx['callId']]['rootSeen']
        elif kind=='buffer-live':
            ptr=row['ptr'];allocation=row['allocation']
            assert ptr not in live and allocation not in births and ptr>0 and row['cap']>=0
            live[ptr]=dict(allocation=allocation,cap=row['cap'],chain=row['chain'],tid=tid)
            births[allocation]=dict(ptr=ptr,chain=row['chain'],tid=tid)
        elif kind=='buffer-confirmed':
            assert live[row['ptr']]==dict(allocation=row['allocation'],cap=row['cap'],chain=row['chain'],tid=tid)
        elif kind=='buffer-resize':
            assert live[row['ptr']]['allocation']==row['allocation']
            live[row['ptr']]['cap']=row['cap']
        elif kind=='api-only-retirement':
            assert row['ptr'] in live
            api_retirements.append(live.pop(row['ptr']))
        elif kind=='copy-enter':
            assert row['src'] in live and row['dest'] not in live and row['src']!=row['dest']
            assert row['oldCap']==live[row['src']]['cap'] and row['length']<=min(row['oldCap'],row['newCap'])
        elif kind=='final-free-enter':
            assert row['ptr'] in live
            # The next native-call-begin exposes the exact fixed call-site context.
        elif kind=='final-free-root-enter':
            ctx=calls[tid][-1]
            assert ctx['kind']=='final-free' and ctx['callId']==row['callId'] and ctx['ptr']==row['ptr']
            free_calls[row['callId']]=dict(rootSeen=True)
        elif kind in ('root-free-return','internal-free-return','final-free-return'):
            data=live.pop(row['ptr'])
            assert data['allocation']==row['allocation'] and data['cap']==row['cap'] and data['chain']==row['chain']
            closed.append(dict(allocation=data['allocation'],chain=data['chain'],kind=kind,seq=row['seq']))
        elif kind=='message-bound':
            data=live[row['ptr']];metadata=row['metadata'];prefix=bytes.fromhex(metadata['prefixHex'])
            assert data['allocation']==row['allocation'] and data['chain']==row['chain']
            assert len(prefix)==metadata['prefixBytes']<=min(data['cap'],metadata['wireBytes'],256)
            parsed=decode(lambda offset,count:prefix[offset:offset+count],len(prefix))
            assert all(parsed[key]==metadata[key] for key in parsed)
            assert metadata['senderTid']==data['tid'] and metadata['processId']==record['pid']
            if row['chain'] in bound:
                assert all(bound[row['chain']][key]==metadata[key] for key in ('session','id','operation','kind','direction'))
            bound[row['chain']]=metadata
    assert not any(calls.values())
    assert {str(ptr):(data['allocation'],data['cap'],data['chain']) for ptr,data in live.items()}=={
        ptr:(data['allocation'],data['cap'],data['chain']) for ptr,data in record['remaining'].items()}
    qualified=[]
    for freed in closed:
        if freed['kind']=='final-free-return' and freed['chain'] in bound:
            qualified.append(dict(**freed,metadata=bound[freed['chain']]))
    return dict(schema='raveldex-native-buffer-replay-v2',source=str(Path(path).resolve()),sourceSha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                rows=len(rows),counts=dict(counts),births=len(births),remaining=len(live),boundChains=len(bound),
                observedBoundFinalFrees=qualified,apiOnlyRetirements=api_retirements,
                limits=['No full-payload copy total, global high-water, or physical memory claim.',
                        'Qualification requires external controller metadata/process/thread/peer parity; replay only verifies internal row consistency.',
                        'No free is inferred for remaining buffers; explicit GC controls retain their separate scope.'])


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('path');args=parser.parse_args()
    print(json.dumps(audit(args.path),indent=2))
