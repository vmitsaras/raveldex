"""Literal checks for the executed four-record native calibration cohort."""
import hashlib
import json
from pathlib import Path

from audit_tap import audit

ROOT=Path(__file__).resolve().parent
TAP=ROOT/'native-run-1/tap-5-export-gc-drain.json'
CONTROLLER=ROOT/'controller-run-1/report.json'
INSTALL=ROOT/'native-run-1/lldb-install.json'
replay=audit(TAP,CONTROLLER,INSTALL)
tap=json.loads(TAP.read_text());controller=json.loads(CONTROLLER.read_text())
assert replay['rows']==558 and replay['births']==38 and replay['boundChains']==16 and replay['remaining']==0
assert replay['counts']['native-call-begin']==replay['counts']['native-call-return']==114
assert replay['counts']['copy-enter']==replay['counts']['copy-return']==22
assert replay['counts']['internal-free-return']==22 and replay['counts']['final-free-return']==16
assert replay['apiOnlyRetirements']==[]
assert len(replay['controllerParity']['matched'])==16
assert controller['commandFailures']==0 and controller['preservation']=='Pass' and controller['ownedBrowserClosed']
assert len(controller['productionFiles'])==208
commands=controller['commands']
assert [x['command'] for x in commands]==[
    {'cmd':'build','size':4},{'cmd':'gc'},{'cmd':'case','kind':'empty'},{'cmd':'gc'},
    {'cmd':'case','kind':'export'},{'cmd':'gc'},{'cmd':'case','kind':'prior'},
    {'cmd':'case','kind':'restore'},{'cmd':'case','kind':'search'},{'cmd':'case','kind':'dispose'},
    {'cmd':'gc'},{'cmd':'close'}]
assert commands[0]['result']=={'size':4,'revision':1}
assert commands[2]['result']=={'revision':1,'changed':False,'added':0,'replaced':0,'removed':0}
assert commands[4]['result']=={'codeUnits':3993,'encodedLengthIsNotMemory':True}
assert commands[6]['result']['revision']==3 and commands[6]['result']['total']==1 and commands[6]['result']['hits']==[{'id':'prior','score':0}]
restore=commands[7]['result']
assert (restore['format'],restore['originRevision'],restore['revision'],restore['reindexed'])==('raveldex-source',1,4,True)
search=commands[8]['result']
assert search['revision']==4 and search['total']==4 and search['completeness']=='complete'
assert len(search['hits'])==4 and set(x['id'] for x in search['hits'])=={'item:00000','item:00001','item:00002','item:00003'}
assert commands[9]['result']=={'disposed':True}

chains={}
for row in tap['rows']:
    chain=row.get('chain')
    if chain is None:continue
    item=chains.setdefault(chain,dict(chain=chain,births=[],copies=[],frees=[]))
    if row['kind']=='buffer-live':item['births'].append({key:row[key] for key in ('allocation','ptr','cap','tid','window')})
    elif row['kind']=='copy-enter':item['copies'].append({key:row[key] for key in ('src','dest','length','oldCap','newCap')})
    elif row['kind'].endswith('free-return'):item['frees'].append({key:row[key] for key in ('kind','ptr','cap','allocation','seq')})
    elif row['kind']=='message-bound':item['metadata']=row['metadata']

# Literal expected per-direction wire bytes/capacities and selected growth copies.
expected=[
    (3,'addMany',178,216,183,216,144),
    (4,'snapshotExportSource',179,216,4135,5112,360),
    (5,'clear',164,216,181,216,144),
    (6,'add',238,504,179,216,360),
    (7,'search',186,216,234,504,360),
    (8,'snapshotRestore',4177,5112,273,504,576),
    (9,'search',186,216,357,504,360),
    (10,'dispose',117,216,127,216,144),
]
table=[]
for identifier,operation,request_wire,request_cap,response_wire,response_cap,copied in expected:
    pair=[item for item in chains.values() if item['metadata']['id']==identifier]
    assert len(pair)==2
    req=next(item for item in pair if item['metadata']['direction']=='main-to-worker')
    res=next(item for item in pair if item['metadata']['direction']=='worker-to-main')
    assert all(item['metadata']['operation']==operation for item in pair)
    assert (req['metadata']['wireBytes'],req['births'][-1]['cap'],res['metadata']['wireBytes'],res['births'][-1]['cap'])==(request_wire,request_cap,response_wire,response_cap)
    assert sum(copy['length'] for item in pair for copy in item['copies'])==copied
    assert all(item['frees'][-1]['kind']=='final-free-return' and len(item['births'])==len(item['frees']) for item in pair)
    assert all(item['frees'][-1]['allocation']==item['births'][-1]['allocation'] for item in pair)
    table.append(dict(id=identifier,operation=operation,chains=[req['chain'],res['chain']],
                      requestWireBytes=request_wire,requestRequestedCapacity=request_cap,responseWireBytes=response_wire,
                      responseRequestedCapacity=response_cap,selectedGrowthCopyBytes=copied,
                      copyCalls=sum(len(item['copies']) for item in pair),finalFrees=2))
assert sum(row['selectedGrowthCopyBytes'] for row in table)==2448
assert max(copy['oldCap']+copy['newCap'] for item in chains.values() for copy in item['copies'])==5328
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
result=dict(schema='raveldex-four-record-native-buffer-calibration-v1',outcome='Pass for bounded declared control scope',
            table=table,rows=558,births=38,matchedCalls=114,selectedGrowthCopyCalls=22,selectedGrowthCopyBytes=2448,
            internalFrees=22,successfulBoundFinalFrees=16,remaining=0,dropped=0,invalid=0,pending=0,
            largestObservedGrowthPairRequestedOverlapBytes=5328,
            sources={str(path.relative_to(ROOT)):sha(path) for path in [TAP,CONTROLLER,INSTALL,ROOT/'lldb_native_tap.py',ROOT/'wire_metadata.py',ROOT/'audit_tap.py',ROOT/'hook-manifest.json']},
            limits=['Only four-record source-worker control; 1000/10000 product matrix unrun.',
                    'Late frees under explicitly forced main/worker/main GC; no ordinary deletion timing claim.',
                    'Window export-gc-drain encompasses multiple later operations; protocol identities define operation attribution.',
                    'Capacities are requested serializer-buffer extents. Copy bytes cover selected executed growth calls only.',
                    'No full payload-copy total, global registry peak, physical/process memory, or latency claim.',
                    'In-place resize remains a mock-tested branch with no native in-place observation.'])
(ROOT/'calibration-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ('outcome','rows','births','matchedCalls','selectedGrowthCopyBytes','successfulBoundFinalFrees','remaining')}))
