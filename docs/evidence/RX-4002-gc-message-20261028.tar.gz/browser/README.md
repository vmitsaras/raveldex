# Native buffer lifetime and actual message binding — 2026-10-28

**Pass for this four-record installed-package calibration only.** Parent execution observed 16 actual request/response buffers through successful final native frees. Offline replay verifies all 558 cumulative rows, 114 native entry/return pairs, 38 allocation births, 22 internal growth frees and 16 successful final frees. Remaining buffers, pending calls, invalid rows, drops and API-only retirements are all zero. No 1,000/10,000 browser product matrix was run.

`calibration-summary.json` contains literal numerical assertions and critical hashes. `replay-final.json` contains complete frame, generation, lifetime and external-controller parity results. `summarize_calibration.py` reconstructs the table and asserts the actual public outcomes. The executed observer is SHA-256 `8b707d03ca3baff251d12638b6689540c5db916904fcdd1c1c4537a0d605c659`; `wire_metadata.py` is `1c20a8c6d195afc0099314d2b9136af20a108d6ebec75b4455bd80f805ec3558`.

## Actual workload and attribution

The parent's controller uses unchanged installed public `createWorkerRaveldex`, source provider/phrases and worker source-snapshot entries. Its existing tarball hash is `6ff6e90128f60af39bb8f47800c61ed83d85d4ded7a8e3c96d2bd34467f9c437`; 208 installed production files are matched and preserved. Initialization and a four-record build precede observation. Eight later operations, IDs 3–10, are observed serially. Public outcomes include an empty batch preserving revision 1; source export of 3,993 code units; a one-record prior state at revision 3; restore of origin revision 1 into new local revision 4; the four expected unique IDs and exact total 4 after restore; and disposal. These literal checks are separate from any full ranking oracle or memory claim.

The renderer PID is 13011, with actual trace-bound main TID 10650425 and worker TID 10650441. The controller's sole attached worker target is `0A3A8D98520EE329CD159C99BB6BC2D5`, at `http://127.0.0.1:51907/message-worker.mjs`. The native metadata session is `03d26351-2ab3-4034-b266-ab6017194847`. Native sender TIDs, protocol 1, session, ID, operation, direction and result kind match four controller edges per buffer: sender send-begin/send-end and receiver read-begin/read-end. The exact PID trace, attached worker target, isolate identities and controller report are retained. The descriptive peer label is joined to that observed target through this controlled single-worker/thread mapping; it is not itself a native worker object address.

| ID / operation | Native chains request / response | Request wire bytes / requested capacity | Response wire bytes / requested capacity | Selected growth-copy calls / bytes | Successful final frees |
| --- | --- | ---: | ---: | ---: | ---: |
| 3 addMany, empty | 1 / 2 | 178 / 216 | 183 / 216 | 2 / 144 | 2 |
| 4 snapshotExportSource | 3 / 4 | 179 / 216 | 4,135 / 5,112 | 3 / 360 | 2 |
| 5 clear, prior preparation | 5 / 6 | 164 / 216 | 181 / 216 | 2 / 144 | 2 |
| 6 add, prior preparation | 7 / 8 | 238 / 504 | 179 / 216 | 3 / 360 | 2 |
| 7 search, prior check | 9 / 10 | 186 / 216 | 234 / 504 | 3 / 360 | 2 |
| 8 snapshotRestore | 11 / 12 | 4,177 / 5,112 | 273 / 504 | 4 / 576 | 2 |
| 9 search, restored check | 13 / 14 | 186 / 216 | 357 / 504 | 3 / 360 | 2 |
| 10 dispose | 15 / 16 | 117 / 216 | 127 / 216 | 2 / 144 | 2 |

The selected 22 executed growth copies total 2,448 bytes. Each initial 72→216 requested growth copies 72 bytes; six later 216→504/5,112 growths copy 216 bytes. The largest witnessed pair-local requested overlap is 216 + 5,112 = **5,328 bytes**. This is not a global registry high-water or full payload-copy total. Wire sizes and requested capacities are distinct fields; neither is a physical-memory measurement.

All success final frees are qualified under explicit main/worker/main `HeapProfiler.collectGarbage` drains. They establish observed deletion and attribution under that declared control, not ordinary automatic deletion timing. The final label `export-gc-drain` also encompasses later prior/restore/search/dispose operations; exact protocol metadata, not that broad label, attributes each chain. Rows and births persist across all five checkpoints/windows, including the initial idle negative control. Idle has zero serializer allocations/copies; late buffers are never silently cleared.

## Version-specific native path

The cached executable remains HeadlessChrome 153.0.8010.12, SHA-256 `a0bfe7b4da4787b66058477d696cd1d09065d25f06a548947722b9af77ee8282`, Mach-O UUID `4C4C44C1-5555-3144-A1ED-87C8CC00F9E6`. Installation rechecks the whole binary hash, UUID and all 13 code fingerprints before creating hooks. It observes only the explicitly supplied owned renderer PID. Owner apps/settings/signatures are untouched.

The original selected shared PA realloc/copy/internal-free hooks are retained. Source proves `V8ScriptValueSerializer::Serialize` moves `serializer_.Release()` into `SerializedScriptValue::DataBufferPtr`; its `BufferDeleter` calls `Partitions::BufferFree`. The destructor's compiled path reads the data pointer at owner+8 and size at owner+16. `ConsumeAndTakeBuffer` independently corroborates those fields and calls the same destructor on reference release. Native disassembly identifies destructor entry module+`0x19ca0c8`, the data buffer load/clear at `0x19ca1fc`/`0x19ca200`, final root-free call `0x19ca210` → `0x1d6d0`, and call return `0x19ca214`. These static candidates are now executed and correlated with the actual decoded metadata and allocator births. Misleading nearest-export names in stripped disassembly are not used as actual function names.

The final-free hook requires the active top-of-stack destructor context to match pointer, allocation generation and owner register x19. It records that destructor call ID, the executed root-free entry, and the matching native return. A final free is accepted only after that return; entry alone does not retire a birth. Reused addresses receive new allocation IDs. Raw entry PC/SP/LR, return PC, current return PC/SP/LR, call IDs and parent IDs make the exact frame pairing independently replayable.

Authoritative version-pinned sources and fetch provenance are in `sources/` and `source-fetch-provenance.json`. Chromium DEPS pins V8 to `0b60d2b01800d7ba2c6eeb5e51ecd95f6dab44c7`. `value-serializer-raw.cc` is decoded from the preserved official Googlesource base64 response and establishes V8 format 16, object/string/number tags and `WriteRawBytes` semantics. The previous failed `sources/value-serializer.cc` is a retained 404 response, not an accepted source. The rendered `value-serializer-v8-pinned.cc` is supplementary; exact raw bytes are the authoritative local representation.

## Observer changes and finite guards

The metadata reader consumes an exact Blink-21/V8-16 plain-object prefix in the package's stable key order, accepting only known primitive metadata. It stops after the `payload` or `value` key, without consuming that field's value. Every read is checked against both known native extent and a 256-byte limit; actual prefixes are 108–137 bytes. This is an explicitly declared change from the historical observer's no-payload-read policy: bounded synthetic protocol metadata is read, recorded and decoded. No complete payload or unrelated owner process is read, and no argument/result/allocator setting is changed.

Rows (32,768), bindings (256), windows (128), pending native calls (256), thread entries (64), live buffers (256) and breakpoints (256) are finite. Record/binding/window/thread exhaustion disarms capture or prevents restarting an invalid window. A 600-second task-owned LLDB host watchdog and cleanup keep process ownership explicit. The guard review found two real preflight gaps: unbounded bindings/windows after record exhaustion and missing destructor-owner validation at the final-free site. Both were repaired before this run. `candidate-v1/` preserves the rejected candidate. Sixteen tests pass, including five literal trace tamper refusals, missing/wrong destructor contexts, pointer generation reuse, frame SP mismatch, all truncated request prefixes, finite exhaustion and payload/value read fences.

## Reproduce offline

```sh
PYTHONPYCACHEPREFIX=/tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/pycache python3 /tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/test_observer.py
PYTHONPYCACHEPREFIX=/tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/pycache python3 /tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/summarize_calibration.py
PYTHONPYCACHEPREFIX=/tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/pycache python3 /tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/audit_tap.py /tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/native-run-1/tap-5-export-gc-drain.json --controller /tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/controller-run-1/report.json --install /tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/native-run-1/lldb-install.json
```

The debugger removes all breakpoints and detaches normally; its retained host record exits 0 without watchdog timeout. The parent's browser controller exits 0 with owned closure and production preservation. These claims are separate from the parent's final process-absence check.

## Remaining qualification limits

- Actual 1,000/10,000 browser request/response workload matrix is unrun.
- The native in-place resize branch has only mock behavioral evidence; no actual in-place observation exists.
- The selected growth-copy call does not cover full string payload writes. Pinned V8 `WriteRawBytes` performs a separate `memcpy` after `ReserveRawBytes`, and string paths call it from `WriteOneByteString`/`WriteTwoByteString`; exact compiled/inlined sites still need binding and calibration. Whole-process memcpy interception alone would not prove compiler-inlined copies and could impose prohibitive breakpoint traffic.
- No all-native-buffer global high-water, browser physical/process memory, full transport-copy byte total, automatic GC timing or latency result is claimed. The final frees remove the historical right-censoring gap for this executed cohort only.
- Static source/disassembly preparation encountered inaccessible raw URLs, a retained 404 source response, and a broad `--macho --disassemble` command that ignored the intended address range. It was interrupted; its partial 69 MiB output remains `asm/ssv-neighborhood.asm`. The corrected bounded disassembly is `asm/ssv-neighborhood-bounded.asm`. Initial Python bytecode caching hit the owner's cache permission boundary; task-local `PYTHONPYCACHEPREFIX` resolves it without an escalation or environment change.

No production, repository tracking/documentation, release, remote or owner-app write was performed by this agent; the parent owns repository integration.
