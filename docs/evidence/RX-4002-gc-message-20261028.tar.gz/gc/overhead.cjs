'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const trace=require('internal/test/binding').internalBinding('v8'),dir=process.argv[2];
const hold=new Array(512);function work(withGC){for(let j=0;j<2;j++){for(let i=0;i<hold.length;i++)hold[i]=new Array(64).fill(i+j);if(withGC)gc({type:'minor'});}return hold[511][63];}
for(let i=0;i<8;i++)work(false);
const rows=[];
for(const withGC of [false,true])for(const [i,active]of[false,true,true,false,false,true,true,false].entries()){
 hold.fill(null);gc();let file=path.join(dir,`${withGC?'gc':'nogc'}-${i}.rdxgc`);if(active)trace.managedAllocationTraceStart(file,65536,32);
 const t0=process.hrtime.bigint();const checksum=work(withGC);const t1=process.hrtime.bigint();const t2=process.hrtime.bigint();const status=active?trace.managedAllocationTraceStop():null;const t3=process.hrtime.bigint();assert.equal(checksum,512);if(active)assert.equal(status,0);
 rows.push({withGC,index:i,active,file:active?file:null,status,workNanoseconds:Number(t1-t0),stopNanoseconds:Number(t3-t2),checksum});
}
console.log(JSON.stringify({execPath:process.execPath,execArgv:process.execArgv,scope:'Finite alternating observed timing; included timer BigInts/harness and recorder map/stream/census/sweep perturbation. No universal/default/product latency overhead claim.',rows}));
