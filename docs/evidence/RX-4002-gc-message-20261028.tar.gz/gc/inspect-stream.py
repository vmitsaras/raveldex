from pathlib import Path
import json,sys
p=Path(sys.argv[1]);data=p.read_bytes();pos=data.index(b'\n')+1
def u():
 global pos
 n=s=0
 while 1:
  b=data[pos];pos+=1;n|=(b&127)<<s
  if not b&128:return n
  s+=7
rows=[];inside=False
while pos<len(data):
 kind=u()
 if not kind:
  n=u();print(data[pos:pos+n].decode());break
 row=[kind]+[u() for _ in range(5)];rows.append(row)
 if kind==8:inside=True
 if kind==3 and inside:print('gc_shrink',len(rows),row,'near',rows[-8:])
 if kind==9:inside=False
