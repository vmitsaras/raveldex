"""Apply only after original calibrated recorder/compiler patch, in a NEW source tree."""
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('usage: apply-extension-v3.py /absolute/new/source-root')
s=Path(sys.argv[1]).resolve()
if not s.is_absolute() or 'raveldex-instrumented-node-20261027.MqKSa6' in str(s):raise SystemExit('refusing original immutable source location')
manifest=json.loads((r/'source-identity-v3-prebuild.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in manifest['files']:
 p=s/row['path'];expected=row['parentSha256']
 if expected is None:
  if p.exists():raise SystemExit('new candidate file already exists: '+str(p))
 elif not p.is_file() or sha(p)!=expected:raise SystemExit('source parent hash mismatch: '+str(p))
patch=r/'gc-extension-v3.patch'
if sha(patch)!=manifest['extensionPatchSha256']:raise SystemExit('extension patch hash mismatch')
cmd=['/usr/bin/patch','-p1','--batch','--forward','-i',str(patch)]
subprocess.run(cmd+['--dry-run'],cwd=s,check=True)
subprocess.run(cmd,cwd=s,check=True)
for row in manifest['files']:
 if sha(s/row['path'])!=row['candidateSha256']:raise SystemExit('candidate hash mismatch: '+row['path'])
print(json.dumps({'applied':True,'root':str(s),'extensionPatchSha256':sha(patch),'allCandidateHashesMatch':True}))
