from pathlib import Path
import subprocess,json,time,hashlib
r=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc');d=r/'overhead-v3';d.mkdir(exist_ok=False)
argv=[str(r/'node-gc-v3'),'--expose-internals','--expose-gc','--no-inline-new','--no-turbo-allocation-folding','--single-threaded','--no-incremental-marking',str(r/'overhead.cjs'),str(d)]
t=time.time();p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120);(d/'stdout.json').write_bytes(p.stdout);(d/'stderr.log').write_bytes(p.stderr);report={'argv':argv,'exitCode':p.returncode,'elapsedSeconds':time.time()-t,'binarySha256':hashlib.sha256((r/'node-gc-v3').read_bytes()).hexdigest()};(r/'overhead-v3-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
