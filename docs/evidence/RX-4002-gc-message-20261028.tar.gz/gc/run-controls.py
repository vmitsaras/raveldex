from pathlib import Path
import subprocess,json,time,os,hashlib
r=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc');binary=r/'node-gc-v2'
flags=['--expose-internals','--expose-gc','--no-inline-new','--no-turbo-allocation-folding','--single-threaded','--no-incremental-marking']
results=[]
for mode in ['basic','gc','negative','async','flag-guard','aborted']:
 d=r/'controls-v2'/mode;d.mkdir(parents=True,exist_ok=False)
 argv=[str(binary),*(flags if mode!='flag-guard' else flags[:-2]),str(r/'control.cjs'),mode,str(d)]
 start=time.time()
 try:
  p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
  (d/'stdout.json').write_bytes(p.stdout);(d/'stderr.log').write_bytes(p.stderr)
  row={'mode':mode,'argv':argv,'exitCode':p.returncode,'elapsedSeconds':time.time()-start,'stdout':str(d/'stdout.json'),'stderr':str(d/'stderr.log')}
 except subprocess.TimeoutExpired as e:
  (d/'stdout.json').write_bytes(e.stdout or b'');(d/'stderr.log').write_bytes(e.stderr or b'');row={'mode':mode,'argv':argv,'timedOut':True,'elapsedSeconds':time.time()-start}
 results.append(row);(r/'controls-v2-report.json').write_text(json.dumps({'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'rows':results},indent=2)+'\n');print(json.dumps(row),flush=True)
