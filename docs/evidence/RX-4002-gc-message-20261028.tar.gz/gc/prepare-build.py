from pathlib import Path
import json,hashlib,difflib
r=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc');s=r/'node-v24.21.0'
p=s/'deps/v8/src/heap/raveldex-gc-trace.inc';t=p.read_text().replace('  void Start() { gc_start_', '  void PrepareBuffer() { std::setvbuf(file_,file_buffer_,_IOFBF,sizeof(file_buffer_)); }\n  void Start() { gc_start_').replace('  const char* first_error_="none";char numbers_[5][32];','  const char* first_error_="none";char numbers_[5][32];char file_buffer_[65536];')
a='  std::fprintf(f,"{\\\"record\\\":\\\"header'
b='  auto trace=std::make_unique<RaveldexManagedAllocationTrace>(isolate->heap(),f,capacity,limit);\n  trace->PrepareBuffer();\n'
assert a in t;t=t.replace(a,b+a)
t=t.replace('  auto trace=std::make_unique<RaveldexManagedAllocationTrace>(isolate->heap(),f,capacity,limit);\n  auto* raw=trace.get();','  auto* raw=trace.get();')
p.write_text(t)
files=['src/node_v8.cc','deps/v8/src/heap/heap.cc','deps/v8/src/heap/heap.h','deps/v8/src/codegen/optimized-compilation-info.cc','deps/v8/src/heap/raveldex-gc-trace.inc']
rows=[];patch=''
for name in files:
 p=s/name;q=r/'originals'/name;before=q.read_text() if q.exists() else ''
 rows.append({'path':name,'parentSha256':hashlib.sha256(q.read_bytes()).hexdigest() if q.exists() else None,'candidateSha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 patch+=''.join(difflib.unified_diff(before.splitlines(True),p.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(r/'gc-extension.patch').write_text(patch)
(r/'source-identity-prebuild.json').write_text(json.dumps({'origin':'/tmp/raveldex-instrumented-node-20261027.MqKSa6/node-v24.21.0','copyCommand':['cp','-cR'],'baseRuntimeSha256':'28d5845f1e59182b5c8d81403836500728972b9816a7195f49e3442fcb9b5e67','upstreamSourceTarSha256':'a6f54defb6fd7c84f41dba13d61e78e9b4e0961712cf61f29715c05f5ced94fc','files':rows,'patchSha256':hashlib.sha256(patch.encode()).hexdigest(),'compiled':False},indent=2)+'\n')
old=Path('/tmp/raveldex-instrumented-node-20261027.MqKSa6/run-build-builtin-gate.py').read_text()
old=old.replace("Path('/tmp/raveldex-instrumented-node-20261027.MqKSa6')", "Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc')").replace("phase = 'runtime-builtin-gate'", "phase = 'gc-extension-attempt1'")
(r/'run-build-attempt1.py').write_text(old)
