from pathlib import Path
import shutil,difflib,hashlib,json
r=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc');s=r/'node-v24.21.0';p=s/'deps/v8/src/heap/raveldex-gc-trace.inc';shutil.copy2(p,r/'candidate-v2-raveldex-gc-trace.inc');t=p.read_text()
t=t.replace('    if(in_gc_) {Error("size_change_during_gc_unsupported");return;}\n    Address e;', '''    if(in_gc_) {
      // GC may compact a preexisting WeakArrayList. Ignore only a genuinely
      // disjoint extent; a tracked or partially tracked GC layout change has
      // not been calibrated and still invalidates the complete window.
      Address e; if(!End(a,old_n,&e)||n<=0||n>old_n){Error("invalid_gc_size_change");return;}
      bool tracked=false;
      Intersections(extents_,a,e,[&](Address,Address){tracked=true;});
      Intersections(moved_,a,e,[&](Address,Address){tracked=true;});
      if(tracked) Error("tracked_size_change_during_gc_unsupported");
      else ++unmonitored_;
      return;
    }
    Address e;''')
t=t.replace('    bool valid=errors_==0;','    if(std::fflush(file_)!=0){io_error_=true;Error("stream_flush_error");}\n    bool valid=errors_==0;')
t=t.replace('byte_cap_-4096-stream_bytes_','byte_cap_-4112-stream_bytes_').replace('reserve 4096 bytes','reserve 4112 bytes')
t=t.replace('    if(stream_full_||io_error_)return;','    ++attempts_;\n    if(stream_full_||io_error_)return;')
t=t.replace('uint64_t events_=0,stream_bytes_=0,','uint64_t attempts_=0,events_=0,stream_bytes_=0,')
t=t.replace('\\\"events\\\":%" PRIu64 ",\\\"stream_bytes_before_summary', '\\\"events\\\":%" PRIu64 ",\\\"attempted_events\\\":%" PRIu64 ",\\\"dropped_events\\\":%" PRIu64 ",\\\"stream_bytes_before_summary')
t=t.replace('aborted?"true":"false",events_,stream_bytes_', 'aborted?"true":"false",events_,attempts_,attempts_-events_,stream_bytes_')
p.write_text(t)
files=['src/node_v8.cc','deps/v8/src/heap/heap.cc','deps/v8/src/heap/heap.h','deps/v8/src/codegen/optimized-compilation-info.cc','deps/v8/src/heap/raveldex-gc-trace.inc'];rows=[];patch=''
for name in files:
 a=s/name;b=r/'originals'/name;orig=b.read_text() if b.exists() else '';rows.append({'path':name,'parentSha256':hashlib.sha256(b.read_bytes()).hexdigest() if b.exists() else None,'candidateSha256':hashlib.sha256(a.read_bytes()).hexdigest()});patch+=''.join(difflib.unified_diff(orig.splitlines(True),a.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(r/'gc-extension-v3.patch').write_text(patch);(r/'source-identity-v3-prebuild.json').write_text(json.dumps({'files':rows,'compiled':False,'extensionPatchSha256':hashlib.sha256(patch.encode()).hexdigest()},indent=2)+'\n')
b=(r/'run-build-attempt2.py').read_text().replace("phase = 'gc-extension-attempt2'","phase = 'gc-extension-attempt3'");(r/'run-build-attempt3.py').write_text(b)
# Tighten direct control: a young preexisting array genuinely crosses the trace boundary.
a=(r/'control.cjs').read_text();a=a.replace('{cap=65536,mib=64,expected=0}={}){gc();','{cap=65536,mib=64,expected=0,settle=true}={}){if(settle)gc();')
a=a.replace(" const preexisting=new Array(1111).fill(17);", " gc(); const preexisting=new Array(1111).fill(17);")
a=a.replace("return{held:held.length,preexisting:preexisting.length};});", "return{held:held.length,preexisting:preexisting.length};},{settle:false});")
(r/'control-v3.cjs').write_text(a)
b=(r/'run-controls.py').read_text().replace("node-gc-v2","node-gc-v3").replace("controls-v2","controls-v3").replace("control.cjs","control-v3.cjs");(r/'run-controls-v3.py').write_text(b)
