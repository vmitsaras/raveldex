import json, os, signal, subprocess, sys, time
from pathlib import Path

root = Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc')
source = root / 'node-v24.21.0'
phase = 'gc-extension-attempt1'
recipe = source / 'out/tools/v8_gypfiles/v8_snapshot.target.mk'
lines = recipe.read_text().splitlines()
commands = [line.split(' = ', 1) for line in lines if line.startswith('cmd_') and 'target_run_mksnapshot = ' in line]
assert len(commands) == 1
variable, original_command = commands[0]
assert '--no-turbo-allocation-folding' not in original_command
override = variable + '=' + original_command + ' --no-turbo-allocation-folding --no-inline-new'
arguments = ['/usr/bin/make', '-C', 'out', 'BUILDTYPE=Release', '-j4']
arguments += [override, 'node']
deadline = 600 if phase == 'dependencies' else 1200
report = {'phase': phase, 'command': arguments, 'cwd': str(source), 'timeoutSeconds': deadline, 'startedUnix': time.time(), 'parallelJobs': 4, 'recipe': str(recipe), 'recipeSha256': __import__('hashlib').sha256(recipe.read_bytes()).hexdigest(), 'originalMksnapshotCommand': original_command, 'addedMksnapshotFlags': ['--no-turbo-allocation-folding', '--no-inline-new']}
log_path = root / (phase + '-build.log')
env = {key: os.environ[key] for key in ['PATH', 'TMPDIR', 'LANG', 'LC_ALL'] if key in os.environ}
try:
    with log_path.open('xb') as log:
        child = subprocess.Popen(arguments, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        report['ownedPid'] = child.pid
        report['ownedProcessGroup'] = os.getpgid(child.pid)
        try:
            code = child.wait(timeout=deadline)
            report['timedOut'] = False
        except subprocess.TimeoutExpired:
            report['timedOut'] = True
            os.killpg(report['ownedProcessGroup'], signal.SIGTERM)
            try:
                code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(report['ownedProcessGroup'], signal.SIGKILL)
                code = child.wait(timeout=5)
        report['exitCode'] = code
finally:
    report['finishedUnix'] = time.time()
    report['elapsedSeconds'] = report['finishedUnix'] - report['startedUnix']
    report['logPath'] = str(log_path)
    with (root / (phase + '-build-report.json')).open('x') as output:
        json.dump(report, output, indent=2)
        output.write('\n')
print(json.dumps(report))
sys.exit(0 if report.get('exitCode') == 0 else 1)
