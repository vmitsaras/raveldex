from pathlib import Path
import hashlib,json
r=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc');old=Path('/tmp/raveldex-instrumented-node-20261027.MqKSa6/node-v24.21.0');rows=[]
for p in (r/'originals').rglob('*'):
 if p.is_file():
  rel=p.relative_to(r/'originals');a=hashlib.sha256(p.read_bytes()).hexdigest();b=hashlib.sha256((old/rel).read_bytes()).hexdigest();rows.append({'path':str(rel),'beforeSha256':a,'oldCurrentSha256':b,'unchanged':a==b})
cal=Path('/tmp/raveldex-instrumented-node-20261027.MqKSa6/node-runtime-builtin-gate');result={'oldSourceChecks':rows,'allOldSourcesUnchanged':all(x['unchanged'] for x in rows),'preservedOldCalibratedBinary':str(cal),'preservedOldCalibratedBinarySha256':hashlib.sha256(cal.read_bytes()).hexdigest(),'oldMutableOutBinarySha256':hashlib.sha256((old/'out/Release/node').read_bytes()).hexdigest(),'cloneBuildOutput':str(r/'node-v24.21.0/out/Release/node'),'note':'attempt1 incorrectly inherited old absolute builddir; old mutable build outputs were changed. No restoration was attempted. Immutable calibrated runtime remains authority.'}
(r/'source-isolation-status.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
