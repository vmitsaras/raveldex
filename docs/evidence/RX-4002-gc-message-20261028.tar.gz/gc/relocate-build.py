from pathlib import Path
import os,json,hashlib,shutil,time
r=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc');s=r/'node-v24.21.0'
old='/private/tmp/raveldex-instrumented-node-20261027.MqKSa6/node-v24.21.0';new='/private'+str(s)
# Preserve unexpected output by copying; do not modify old output again.
shutil.copy2(old+'/out/Release/node',r/'attempt1-misdirected-node')
inc=s/'deps/v8/src/heap/raveldex-gc-trace.inc';shutil.copy2(inc,r/'candidate-v1-raveldex-gc-trace.inc')
records=[]
for p in list((s/'out').rglob('*.mk'))+[s/'out/Makefile']+list((s/'out/Release/.deps').rglob('*.d')):
 if not p.is_file():continue
 raw=p.read_bytes()
 if old.encode() not in raw:continue
 stat=p.stat();p.write_bytes(raw.replace(old.encode(),new.encode()));os.utime(p,ns=(stat.st_atime_ns,stat.st_mtime_ns))
 records.append({'path':str(p.relative_to(s)),'beforeSha256':hashlib.sha256(raw).hexdigest(),'afterSha256':hashlib.sha256(p.read_bytes()).hexdigest()})
old_dep=s/'out/Release/.deps'/old.lstrip('/');new_dep=s/'out/Release/.deps'/new.lstrip('/')
new_dep.parent.mkdir(parents=True,exist_ok=True);old_dep.rename(new_dep)
(r/'build-relocation.json').write_text(json.dumps({'oldPrefix':old,'newPrefix':new,'files':records,'relocatedDependencyDirectory':str(new_dep),'unintendedOldOutputSha256':hashlib.sha256((r/'attempt1-misdirected-node').read_bytes()).hexdigest(),'oldSourceAndEvidenceTouched':False,'oldBuildOutputsTouched':True,'attempt1NotAcceptedAsIsolatedBuild':True},indent=2)+'\n')
# Fix candidate cap: exact whole-file byte count, reserve footer, explicit IO failure.
t=inc.read_text().replace('  void PrepareBuffer() { std::setvbuf(file_,file_buffer_,_IOFBF,sizeof(file_buffer_)); }','  bool PrepareBuffer() { return std::setvbuf(file_,file_buffer_,_IOFBF,sizeof(file_buffer_))==0; }\n  void NoteHeaderBytes(uint64_t n) {stream_bytes_=n;}')
t=t.replace('  trace->PrepareBuffer();','  if(!trace->PrepareBuffer()){std::fclose(f);return -EIO;}')
t=t.replace('  std::fprintf(f,"{\\\"record\\\":\\\"header','  int header_bytes=std::fprintf(f,"{\\\"record\\\":\\\"header')
t=t.replace('  if(std::fflush(f)){','  if(header_bytes<0 || std::fflush(f)){').replace('  auto* raw=trace.get();','  trace->NoteHeaderBytes(header_bytes);\n  auto* raw=trace.get();')
inc.write_text(t)
# Retain old script, use explicit clone builddir override as defense in depth.
b=(r/'run-build-attempt1.py').read_text().replace("phase = 'gc-extension-attempt1'","phase = 'gc-extension-attempt2'")
b=b.replace("arguments += [override, 'node']","arguments += ['builddir_name='+str(source.resolve()/'out'), override, 'node']")
(r/'run-build-attempt2.py').write_text(b)
print(json.dumps({'relocatedFiles':len(records),'builddir':str(source) if False else new+'/out'}))
