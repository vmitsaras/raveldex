'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const trace=require('internal/test/binding').internalBinding('v8');
const [mode,dir]=process.argv.slice(2);
function read(file){const b=fs.readFileSync(file);let p=b.indexOf(10)+1;const header=JSON.parse(b.subarray(0,p).toString());let events=[];function u(){let n=0n,s=0n;for(let k=0;k<10;k++){assert.ok(p<b.length);const c=b[p++];n|=BigInt(c&127)<<s;if(!(c&128))return n;s+=7n;}throw Error('varint');}while(p<b.length){let kind=Number(u());if(!kind){let n=Number(u());let summary=JSON.parse(b.subarray(p,p+n).toString());p+=n;assert.equal(p,b.length);assert.equal(summary.events,events.length);return{header,summary,events};}let row=[kind];for(let k=0;k<5;k++)row.push(u().toString());events.push(row);}throw Error('missing footer');}
const result={mode,runtime:{version:process.version,v8:process.versions.v8,execPath:process.execPath,execArgv:process.execArgv,pid:process.pid},rows:[]};
function capture(name,body,{cap=65536,mib=64,expected=0}={}){gc();let file=path.join(dir,name+'.rdxgc');trace.managedAllocationTraceStart(file,cap,mib);trace.managedAllocationTraceMark(1);let value=body();trace.managedAllocationTraceMark(99);let status=trace.managedAllocationTraceStop();let {header,summary,events}=read(file);assert.equal(status,expected,JSON.stringify(summary));assert.equal(summary.valid,!expected);for(let k of ['gross_birth_bytes','mutator_occupied_high_water_bytes','occupied_at_stop_bytes','trimmed_bytes','gc_removed_bytes'])assert.equal(summary[k]===null,!!expected,k);result.rows.push({name,file,status,value,header,summary,inspections:events.filter(e=>e[0]===6||e[0]===7),marks:events.filter(e=>e[0]===5),eventCounts:Object.fromEntries([...new Set(events.map(e=>e[0]))].map(k=>[k,events.filter(e=>e[0]===k).length]))});}
if(mode==='basic'){
 capture('empty',()=>null);
 capture('shrinks',()=>{let a=new Array(12345).fill(3);trace.managedAllocationTraceInspect(a,10);a.length=8;trace.managedAllocationTraceInspect(a,11);let b=new Array(150000).fill(4);trace.managedAllocationTraceInspect(b,12);b.length=8;trace.managedAllocationTraceInspect(b,13);let c=new Array(4096).fill(5);trace.managedAllocationTraceInspect(c,14);let shifted=c.shift();trace.managedAllocationTraceInspect(c,15);return{a:a.length,b:b.length,c:c.length,shifted};});
}else if(mode==='gc'){
 const preexisting=new Array(1111).fill(17);
 capture('survive-death-multiple',()=>{trace.managedAllocationTraceInspect(preexisting,100);let held=new Array(12345).fill(23);trace.managedAllocationTraceInspect(held,200);let dead=new Array(8001).fill(31);trace.managedAllocationTraceInspect(dead,300);dead=null;gc({type:'minor'});trace.managedAllocationTraceInspect(held,201);trace.managedAllocationTraceInspect(preexisting,101);held.length=8;trace.managedAllocationTraceInspect(held,202);gc();trace.managedAllocationTraceInspect(held,203);trace.managedAllocationTraceInspect(preexisting,102);assert.equal(held[7],23);assert.equal(preexisting[1110],17);return{held:held.length,preexisting:preexisting.length};});
 capture('address-reuse',()=>{let held=null;for(let i=0;i<8;i++){for(let j=0;j<500;j++)held=new Array(128).fill(i+j);trace.managedAllocationTraceInspect(held,400+i);held=null;gc({type:'minor'});}return{rounds:8};});
}else if(mode==='negative'){
 capture('active-cap',()=>{let a=new Array(100).fill(1);let b=new Array(101).fill(2);return a[0]+b[0];},{cap:1,expected:1});
 capture('stream-cap',()=>{for(let i=0;i<300000;i++)trace.managedAllocationTraceMark(i);return 300000;},{mib:1,expected:1});
 const file=path.join(dir,'sentinel.rdxgc');fs.writeFileSync(file,'sentinel',{flag:'wx'});assert.throws(()=>trace.managedAllocationTraceStart(file,16,1),{code:'EEXIST'});assert.equal(fs.readFileSync(file,'utf8'),'sentinel');result.rows.push({name:'existing-file',preserved:true});
}else if(mode==='async'){
 (async()=>{gc();const file=path.join(dir,'tiny-async.rdxgc');trace.managedAllocationTraceStart(file,65536,16);trace.managedAllocationTraceMark(1);await Promise.resolve(4);trace.managedAllocationTraceMark(2);await 5;trace.managedAllocationTraceMark(3);const status=trace.managedAllocationTraceStop();const {header,summary}=read(file);assert.equal(status,0,JSON.stringify(summary));console.log(JSON.stringify({...result,rows:[{name:'tiny-async',file,status,header,summary}]}));})().catch(e=>{console.error(e);process.exitCode=1;});
}else if(mode==='flag-guard'){
 const file=path.join(dir,'flag-guard.rdxgc');assert.throws(()=>trace.managedAllocationTraceStart(file,16,1),{code:'EINVAL'});assert.equal(fs.existsSync(file),false);result.rows.push({name:'flag-guard',noFile:true});
}else if(mode==='aborted'){
 trace.managedAllocationTraceStart(path.join(dir,'aborted.rdxgc'),65536,16);trace.managedAllocationTraceMark(1);result.expectedAborted=true;
}else throw Error('mode');
if(mode!=='async')console.log(JSON.stringify(result));
