from pathlib import Path
import hashlib,json
r=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc'); s=r/'node-v24.21.0'
for name in ['deps/v8/src/heap/heap.cc','src/node_v8.cc','deps/v8/src/heap/heap.h','deps/v8/src/codegen/optimized-compilation-info.cc']:
 p=s/name; q=r/'originals'/name; q.parent.mkdir(parents=True,exist_ok=True); q.write_bytes(p.read_bytes())
p=s/'deps/v8/src/heap/heap.cc'; t=p.read_text(); start=t.index('// Task-local, opt-in calibration instrument.'); end=t.index('\nvoid Heap::IncrementDeferredCounts(',start)
t=t[:start]+'// Task-owned GC-aware recorder. See adjacent source for explicit bounds.\n#include "src/heap/raveldex-gc-trace.inc"\n'+t[end:]
needle='      PerformGarbageCollection(collector, gc_reason, collector_reason);'
assert t.count(needle)==1
t=t.replace(needle,'      RaveldexManagedGCBegin(this, collector);\n'+needle+'\n      RaveldexManagedGCEnd(this, collector);')
p.write_text(t)
p=s/'src/node_v8.cc'; t=p.read_text(); t=t.replace('extern "C" int RaveldexManagedTraceStart(void*, const char*, uint32_t);','extern "C" int RaveldexManagedTraceStart(void*, const char*, uint32_t, uint32_t);')
t=t.replace('args.Length() != 2 || !args[0]->IsString() || !args[1]->IsUint32()', 'args.Length() != 3 || !args[0]->IsString() || !args[1]->IsUint32() || !args[2]->IsUint32()')
t=t.replace('managedAllocationTraceStart requires absolute path and uint32 capacity','managedAllocationTraceStart requires absolute path, uint32 active-extent cap, uint32 stream MiB cap')
t=t.replace('args.GetIsolate(), *path, args[1].As<Uint32>()->Value());','args.GetIsolate(), *path, args[1].As<Uint32>()->Value(),\n      args[2].As<Uint32>()->Value());')
p.write_text(t)
