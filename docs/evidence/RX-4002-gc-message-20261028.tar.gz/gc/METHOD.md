# RX-4002 GC-aware managed extent recorder candidate

Task-owned native Node/V8 calibration only. No production Raveldex source, public export, dependency, acceptance criterion, deadline, capacity, browser setting or owner app is changed. Existing no-GC instrumentation and traces remain distinct.

## Quantity and coverage

The candidate measures newly monitored main-isolate allocation-block extents, with exact notified non-filler tail/left-trim removal, at mutator event frontiers and completed-GC occupied-object checkpoints. Gross birth bytes are separate from the occupied high-water and stop quantity. Import/admission/runtime/harness/promises/codec work is included when it executes inside the active window. Preexisting managed extents are excluded, including preexisting objects moved by a collector. Coallocated births may contain several objects; a birth is not assumed to identify exactly one object.

GC census uses the same-version `HeapObjectIterator(kNoFiltering)`, skips explicit filler/free-space objects, and intersects actual occupied object extents with the tracked address fragments after relocation. This census obtains a safepoint and calls `MakeHeapIterable`, which can finish sweeping/retire allocation areas. It intentionally perturbs execution. A minor GC can leave unreachable old objects occupied. Neither census nor the high-water is a collector-live/dominant-retained metric.

Collector source/destination temporary coexistence, collector-native work, copy overlap during GC, external strings/ArrayBuffer backing, other isolates, shared/cppgc/background allocations, native allocator retained/committed bytes, process RSS and physical memory are outside this quantity. No whole-operation physical peak is claimed. GC removal is occupied-extent loss at census, without guessed individual death ordinals. Runtime/configuration differences preclude treating this as default-runtime latency or memory.

## Strict supported mode

The task build preserves the prior compiler gate and folding-disabled embedded builtin generation. Start requires `--no-inline-new --no-turbo-allocation-folding --single-threaded --no-incremental-marking`; explicit flag checks reject concurrent marking/sweeping, parallel scavenging/compaction, minor mark-sweep/sticky bits and shared-space isolates. Only exact internal scavenger and mark-compact cycles are supported. No public GC callback pairing is inferred: hooks surround the actual `PerformGarbageCollection` call after prologue callbacks and before epilogue callbacks.

Any birth during the internal GC interval, tracked/partially tracked GC size-layout change, unsupported/nested/unpaired GC, counter mismatch, malformed/overlapping extent, active-map cap, stream cap, I/O error, unfinished collection or cleanup abort invalidates the complete window. Derived gross/high-water/stop/trim/removal fields are null. Disjoint GC shrink notifications are counted as unmonitored and do not affect new monitored extents. Exact GC object type/caller is not guessed from its size.

## Online algorithm

Outside GC, new births enter a nonoverlapping ordered extent map. Exact notified trims remove their real subextents; ordinary moves are restricted to the existing same-source left-trim route. Birth at a still-occupied tracked address is invalid. Reuse after an observed trim or completed GC removal is admitted as a fresh birth, without stale identity.

During GC, the pre-GC extent map remains frozen. Every observed copied source and destination is retained in separately bounded maps; tracked source fragments are translated into a fourth map. At end, all source extents and all destinations (including PREEXISTING objects' destinations) are removed from the old map. Translated tracked fragments are added. A fifth temporary map receives the intersection with each occupied non-filler census object. This avoids interpreting a destination which overwrites a formerly tracked address as survival of the old object. Ambiguous/overlapping move sources or destinations fail strictly. Repeated movement across separate collections uses the reconciled final address map.

No raw event tape grows with total allocation count in memory. Each of at most five `std::map` instances is capped at the caller's active-extent limit (1..1,000,000). Native map nodes allocate/free during capture and their actual allocator overhead is not reported as measured managed bytes. `max_nodes_per_map` is an observed node count; it is not native allocated-byte measurement. FILE buffering is a fixed 65,536-byte recorder member. Synchronous writes and maps perturb timing and resource pressure.

## Lossless bounded stream

Start takes `(absoluteExclusiveOutputPath, uint32ActiveExtentCap, uint32StreamMiBCap)`, with stream cap 1..16,384 MiB. The path/Node write-permission checks and `O_EXCL` guard precede activation. Header bytes, data and reserved terminal bytes fit within that whole-file cap; a cap is an invalid result, not accepted prefix replay. Every event is streamed through the fixed buffer. Up to 1 MiB/64 MiB are used in the bounded controls; no heavy matrix or 148-million-event run is authorized by this candidate control slice.

The first line is UTF-8 JSON with schema `raveldex-gc-extents-varint-v1`. Following data is unsigned LEB128 (maximum ten bytes per integer), six fields per event: `(kind,address,to,bytes,old_bytes,marker)`. Sequence is the implicit 1-based complete-record ordinal. Kinds:

| Kind | Meaning |
| --- | --- |
| 1 | allocation block birth |
| 2 | move (non-GC left trim, or exact GC move) |
| 3 | exact old/new size-change |
| 4 | corroborating current-size update, no second arithmetic trim |
| 5 | numeric mark; bytes=current monitored occupied, old_bytes=peak |
| 6 | direct native argument object address/self-size |
| 7 | direct actual array-elements address/self-size |
| 8 | internal GC begin; bytes=pre-GC current; marker=collector |
| 9 | internal GC end; bytes=post-GC current, old_bytes=pre-GC current |
| 10 | each complete census non-filler object address/self-size |

Collector marker 0 is scavenger, 1 mark compactor. Kind 0 is a special terminal frame: next unsigned LEB128 is the UTF-8 JSON byte length, followed by exactly that summary JSON and EOF. The final summary contains complete-record count, attempted/drop counts, raw GC-counter pair, native guard/error status and null invalid metrics. Raw-file hashes are supplied by the host evidence inventory. Independently checking stream bytes/order/numeric arithmetic remains separate from source/coverage review and public-operation checks.

## Preserved failures and build isolation

The original source was APFS-cloned from `/tmp/raveldex-instrumented-node-20261027.MqKSa6/node-v24.21.0`, initially retaining its original generated Makefile absolute `builddir_name`. Attempt1 therefore inadvertently rebuilt the OLD mutable `out/` tree using cloned relative sources. This is a build-isolation failure, not an accepted isolated build. The resulting binary is preserved separately as `attempt1-misdirected-node`; full command/log/report and `build-relocation.json` are retained. No restoration was attempted. The four old source files retain their original exact hashes; the separately preserved calibrated `node-runtime-builtin-gate` remains SHA-256 `28d5845f1e59182b5c8d81403836500728972b9816a7195f49e3442fcb9b5e67`. Old source and evidence files were not changed. Old mutable build outputs were changed and must not be treated as their old captured identities.

After detecting this mistake, every cloned generated Makefile/dependency absolute old path was rewritten to the clone, dependency directories were moved, and an explicit cloned builddir override was added. Attempts2/3 compile/link entirely to cloned paths and have their own logs/reports. Both inherited upstream and extension source hashes are preserved. Reproduction should start from fresh owned source/build output rather than replaying attempt1 or pointing any make command at the old output.

V2 controls preserve an actual major-GC exact size change 136→104 at raw event 52,106, correctly invalidated by the initial unsupported-GC-layout guard. V3 only ignores such a change when its entire old range is disjoint from tracked frozen/moved extents; a tracked GC layout change remains unsupported/invalid. A size alone does not identify that object as a WeakArrayList. Initial no-GC/shrink/async, active-map and stream overflow, sentinel and abort outcomes remain separately preserved.

## Reproduction and pending verification

Official Node24.21.0 source tar.xz SHA-256 is `a6f54defb6fd7c84f41dba13d61e78e9b4e0961712cf61f29715c05f5ced94fc`. Apply the prior preserved V2 recorder/compiler patch, then this candidate extension patch after verifying its parent-source hashes. Existing configuration is `--without-npm --without-corepack --without-inspector --without-ssl --with-intl=small-icu --download=none`. Use Apple clang21/Darwinarm64 and the recorded Python3.12.14 runtime, bounded `make -j4`, with the recorded `mksnapshot` command override `--no-turbo-allocation-folding --no-inline-new`. The exact actual build commands appear in the build reports; no dependencies were installed/downloaded in this subtask.

`node-gc-v2`: SHA-256 `e0d898b0243b89032d83c4405357d314812a70702dc5f7e5c847bec3c6d14e0b`.
`node-gc-v3`: SHA-256 `ad443b2a6fc8092abeeb3ae8c6405e101cf15fc531f05eb769da4707d5154ae0`.

V3 bounded control execution completes: all six children exit 0. The survival/death control records two internal collections, 22 moves, 104,209 complete records, 165,704 gross birth bytes, 164,136 mutator occupied high-water bytes and 2,648 occupied at stop. The eight-minor-collection reuse control records 423,590 records, 4,354,488 gross birth bytes, 545,608 high-water bytes and 1,616 occupied at stop. Both have zero native errors/drops. These native summaries still require separate independent replay and direct control-witness validation; returning success is not coverage proof. Active-map and stream overflow remain invalid/null; the stream cap preserves 106,043 complete records from 300,058 attempts with 194,015 dropped attempts. The existing-file sentinel is preserved; missing required flags refuse before file creation; natural teardown emits an aborted/null terminal record. Raw V2 failure remains unchanged.

The finite overhead child runs eight alternating off/on loops per no-GC/GC mode (16 loops total; four off/four on each). Work medians in nanoseconds are 102,499.5 off / 175,083.5 on without GC and 362,312.5 off / 4,763,313 on with two minor GCs. Active-stop medians are 69,146 and 81,354 ns. Timer BigInts/harness, native maps, synchronous IO, complete census/sweeping and noisy scheduling all affect these observations. No product/default-runtime latency or universal overhead percentage is inferred. All active windows return valid; independent replay is still separate.

Independent replay/source review and any real public codec pilot are parent-owned and remain unclaimed by this instrumentation bundle. No full 1,000/10,000 matrix, restore cohort, physical memory, collector-overlap peak or complete AC03 qualification follows.
