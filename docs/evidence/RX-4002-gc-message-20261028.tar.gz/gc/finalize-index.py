from pathlib import Path
import json,hashlib,datetime
r=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((r/'source-identity-v3-prebuild.json').read_text());source.update({'compiled':True,'runtimePath':str(r/'node-gc-v3'),'runtimeSha256':sha(r/'node-gc-v3'),'runtimeBuildReport':'gc-extension-attempt3-build-report.json','controlReport':'controls-v3-report.json','independentAudit':'owned by parent outside gc directory; not claimed by this index','sourceReapplication':'patch-reapplication-control.log'})
(r/'source-identity-v3-final.json').write_text(json.dumps(source,indent=2)+'\n')
files=[];external=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or 'node-v24.21.0' in p.relative_to(r).parts or 'patch-dry-source' in p.relative_to(r).parts or p.name=='artifact-index.json':continue
 row={'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p)}
 if p.name.startswith('node-gc-') or p.name=='attempt1-misdirected-node':external.append(row)
 else:files.append(row)
(r/'artifact-index.json').write_text(json.dumps({'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'tooling sources, failed/successful bounded controls and build reports; no product matrix; code hash/calibration distinct from independent acceptance','embeddedCandidates':files,'externalRuntimes':external,'excluded':['node-v24.21.0 whole upstream source/build tree','patch-dry-source duplicate reapplication tree']},indent=2)+'\n')
print(json.dumps({'files':len(files),'externalRuntimes':len(external),'index':str(r/'artifact-index.json'),'sourceFinal':str(r/'source-identity-v3-final.json')}))
