## Rich directory results

Copy the [complete rich-results browser project](../../site/Cards.astro) to start with real resource pages, metadata mapping, local image assets and CSS you can edit. Its layout, density and image controls keep the same directory page and filter selection. Images start off. The basic browser/Astro directories remain available when you need linked titles and controls alone.

For an existing browser controller, use this fragment after creating your own connected HTML `root`, live `directory`, matching display records and group labels. The complete project above includes indexing, loading/Retry, optional URL replay and ownership-safe cleanup; this fragment supplies just the rich view.

```js
import { mountRaveldexDirectoryCards } from '@vmitsaras/raveldex/addons/ui/directory/cards';
import '@vmitsaras/raveldex/addons/ui/directory.css';
import '@vmitsaras/raveldex/addons/ui/directory-cards.css';

const view = mountRaveldexDirectoryCards({
  root,
  controller: directory,
  documents: [{
    id: 'route:river', title: 'Riverside walking guide', url: '/resources/river/',
    excerpt: 'Plan a route with level paths and rest stops.',
    category: 'Route guide', breadcrumb: ['Resources', 'Walking'],
    date: 'Updated November 2026',
    fields: [{ name: 'Distance', value: '5 km' }],
    image: { src: '/images/river.jpg', alt: 'Level path beside the river', width: 640, height: 400 },
  }],
  groups,
  presentation: { layout: 'cards', density: 'comfortable', images: false },
  imageUnavailable: 'Image unavailable',
});
await directory.refresh();
view.setPresentation({ layout: 'grid', density: 'compact' });
// Only this explicit change permits image requests for the current result page:
view.setPresentation({ images: true });
console.log(view.getPresentation());
// When removing the view, before separately destroying its controller:
// view.destroy();
```

Map your public content to `DirectoryCardDocument` records: required `{id,title,url}`, optional `excerpt`, `category`, ordered plain-text `breadcrumb`, already localized `date`, at most four `{name,value}` fields, and an optional `{src,alt,width,height}` image. Optional empty excerpt/category/date strings produce no output. Omit unavailable breadcrumb/field entries. Dates are shown as supplied text; the view does not parse dates or invent ancestor links. It accepts no HTML templates or renderer callbacks. Keep a matching display record for every possible native match.

Admission happens before replacing authored content. Titles and metadata are inserted as text. Result and image URLs resolve to HTTP(S) without credentials, including image data captured while images are disabled. Every image needs a deliberate alternative: `alt: ''` is decorative, otherwise use readable descriptive text. Width/height are required integers 1..4096 and reserve aspect ratio. There are at most 10,000 records and 4,000,000 captured string units, with finite admission work. ID/title/URL limits remain 256/1024/2048 UTF-16 units; excerpts allow 4096, category/date 256, up to eight breadcrumb parts of 256, field names 128 and values 1024, image source 2048 and alt 1024. Unknown keys, getters, duplicate IDs/field names, unreadable nonempty text and invalid image data refuse. `imageUnavailable` is readable localized text of at most 512 units. The [display contract](../specs/DIRECTORY_CARDS.md) records exact bounds and lifecycle behavior.

`presentation` is a partial `{layout,density,images}`. Defaults are `list`, `comfortable`, false. Layout choices are `list`, `cards`, `grid`; density choices are `compact`, `comfortable`. `getPresentation()` returns a frozen complete snapshot. `setPresentation(partial)` validates first, then changes presentation synchronously without another search/history entry, without reordering results and without losing the existing title-link Nodes/focus. Query, filters, selected chips, page and exact totals remain native. CSS grid uses the same ordered list and ordinary links, with no interactive ARIA grid or extra keyboard model.

Images use native lazy loading, asynchronous decoding and no-referrer policy. Only the current displayed page can create image elements after explicit opt-in. Disabling removes them and their callbacks; it cannot undo a request already sent. Enabling again may create a new request. The browser controls lazy-load timing and caching. A failed informative image shows localized failure text with its authored alternative; a failed decorative image disappears silently. Titles, metadata and links remain usable. There is no automatic alternate source or retry. Teardown clears image listeners as well as the base controls; late detached image events cannot update a newer page or restored/foreign markup. Controller and engine ownership stay with the application.

Import both stylesheets, then edit your own CSS. These properties control the rich layer; the existing directory palette, font, focus and control properties still apply:

```css
.raveldex-directory-cards {
  --raveldex-directory-card-min-width: 18rem;
  --raveldex-directory-card-radius: .85rem;
  --raveldex-directory-card-gap: 1.25rem;
  --raveldex-directory-card-padding: 1.25rem;
  --raveldex-directory-card-compact-padding: .75rem;
  --raveldex-directory-card-image-fit: contain;
}
```

| Public property | Default | Purpose |
| --- | --- | --- |
| `--raveldex-directory-card-min-width` | `16rem` | Preferred grid column minimum, bounded by available width |
| `--raveldex-directory-card-gap` | `1rem`; `.65rem` compact | Card/grid spacing |
| `--raveldex-directory-card-radius` | `.5rem` | Card/image corners |
| `--raveldex-directory-card-padding` | `1rem` | Comfortable card padding |
| `--raveldex-directory-card-compact-padding` | `.6rem` | Compact card padding |
| `--raveldex-directory-card-background` | Directory surface | Card surface |
| `--raveldex-directory-card-border` | Directory border | Card/image borders |
| `--raveldex-directory-card-image-height` | `auto` | Optional image-frame height; auto uses authored aspect ratio |
| `--raveldex-directory-card-image-fit` | `cover` | Image fitting within reserved space |

The public rich classes use `.raveldex-directory-cards__*` alongside the base `.raveldex-directory__*`. Keep internal `--_` variables and data hooks private. Long text/RTL, narrow layout, dark/forced colors and reduced motion retain semantic source order and visible focus. Check your actual colors, image crops/alternatives, browser zoom, devices and assistive technology after changing content or CSS. Graph/CSS bytes, DOM counts and observed requests are separate measurements from memory, latency or paint.

