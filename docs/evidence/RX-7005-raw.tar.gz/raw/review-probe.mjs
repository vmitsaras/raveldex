import { createRequire } from 'node:module';
import { readFile } from 'node:fs/promises';

const repo = '/Users/vasilis/Documents/GitHub/raveldex';
const require = createRequire(`${repo}/package.json`);
const { build } = require('esbuild');
const { chromium } = require('playwright-core');
const built = await build({
  stdin: {
    contents: `import {createRaveldex} from './src/index.ts';
import {createDirectory} from './src/addons/ui/directory.ts';
import {mountRaveldexDirectoryCards} from './src/addons/ui/directory-cards.ts';
window.api={createRaveldex,createDirectory,mountRaveldexDirectoryCards};`,
    resolveDir: repo, sourcefile: 'review-entry.ts',
  },
  bundle: true, write: false, platform: 'browser', format: 'esm', target: 'es2022', logLevel: 'silent',
});
const css = await Promise.all(['directory.css', 'directory-cards.css'].map(name => readFile(`${repo}/src/addons/ui/${name}`, 'utf8')));
const browser = await chromium.launch({ channel: 'chrome', headless: true });
try {
  const page = await browser.newPage({ viewport: { width: 320, height: 900 } });
  await page.route('**/*', route => route.abort());
  await page.setContent('<!doctype html><html lang="en"><base href="https://review.test/"><title>Read-only review</title><section id="root"><p>Original</p></section></html>');
  await page.addStyleTag({ content: css.join('\n') });
  await page.addScriptTag({ content: built.outputFiles[0].text, type: 'module' });
  await page.waitForFunction(() => window.api);
  const observations = await page.evaluate(async () => {
    const { createRaveldex, createDirectory, mountRaveldexDirectoryCards } = window.api;
    const engine = createRaveldex({ schema: { text: { title: {} } } });
    await engine.addMany([{ id: 'a', text: { title: 'Alpha' } }, { id: 'b', text: { title: 'Beta' } }]);
    const controller = createDirectory({ engine, pageSize: 1 });
    const root = document.querySelector('#root');
    const documents = ['a', 'b'].map(id => ({ id, title: id, url: '/r/' + id, image: { src: '/image' + id, alt: 'Photo ' + id, width: 40, height: 30 } }));
    const view = mountRaveldexDirectoryCards({ root, controller, documents, groups: [] });
    await controller.refresh();
    const results = [];
    view.setPresentation({ images: true });
    const oldImage = root.querySelector('img'), oldFrame = oldImage.parentNode;
    await controller.setPage(2);
    const oldText = oldFrame.textContent;
    oldImage.dispatchEvent(new Event('error'));
    results.push({ name: 'old-page-error', unchanged: oldFrame.textContent === oldText, liveID: root.querySelector('[data-raveldex-directory-result]').getAttribute('data-raveldex-directory-result') });
    const beforePresentation = view.getPresentation();
    view.setPresentation(new Proxy({ layout: 'grid' }, { ownKeys(target) { view.destroy(); return Reflect.ownKeys(target); } }));
    results.push({ name: 'setter-destroy-reentry', before: beforePresentation, after: view.getPresentation(), identityRetained: view.getPresentation() === beforePresentation, restored: root.textContent === 'Original' });
    const rich = mountRaveldexDirectoryCards({ root, controller, documents: [{ ...documents[0], image: { src: '/missing.png', alt: 'An image alternative with long localized content '.repeat(20), width: 4096, height: 1 } }, documents[1]], groups: [], presentation: { images: true } });
    await controller.refresh();
    root.querySelector('img').dispatchEvent(new Event('error'));
    const frame = root.querySelector('[data-raveldex-directory-card-image-frame]'), text = frame.firstElementChild;
    const f = frame.getBoundingClientRect(), t = text.getBoundingClientRect();
    results.push({ name: 'long-shallow-image-failure', frameHeight: f.height, textHeight: t.height, frameScrollHeight: frame.scrollHeight, clipped: t.top < f.top || t.bottom > f.bottom, overflow: getComputedStyle(frame).overflow, viewportOverflow: document.documentElement.scrollWidth > innerWidth });
    rich.destroy(); controller.destroy(); await engine.dispose();
    return results;
  });
  console.log(JSON.stringify({ browser: browser.version(), node: process.version, platform: process.platform, arch: process.arch, observations }, null, 2));
} finally { await browser.close(); }
