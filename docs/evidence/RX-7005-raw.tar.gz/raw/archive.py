import pathlib,json,hashlib,tarfile,io,gzip
root=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex');p=pathlib.Path('/private/tmp/raveldex-rx7005-y6l8asn7');e=root/'docs/evidence';v=json.loads((e/'RX-7005-verification.json').read_text());assert v['synchronizedCheck']['status']=='Pass' and v['finalPagesBuild']['status']=='Pass';files={}
for f in p.iterdir():
 if f.is_file():files['raw/'+f.name]=f
for f in (p/'baseline').rglob('*'):
 if f.is_file():files['raw/'+str(f.relative_to(p))]=f
source=set(v['sourceSHA256'])|{'docs/specs/DIRECTORY_CARDS.md','test/fixtures/directory.mjs','test/oracle/directory.mjs','README.md','docs/api/README.md','docs/api/HOSTS.md','examples/README.md','site/README.md'}
for name in sorted(source):files['qualified-source/'+name]=root/name
c=json.loads((p/'candidate-comparison.json').read_text());f=pathlib.Path(c['candidateReport']);files['raw/candidate-report.json']=f;candidate=json.loads(f.read_text());packages={}
def admit(path,expected):
 f=pathlib.Path(path);assert f.is_file(),str(f);h=hashlib.sha256(f.read_bytes()).hexdigest();assert h==expected,(str(f),h,expected);packages[h]=f
admit(candidate['package']['tarball'],candidate['package']['sha256'])
for f in p.glob('*.json'):
 d=json.loads(f.read_text())
 if isinstance(d,dict) and isinstance(d.get('consumer'),dict) and 'directory' in d['consumer'] and isinstance(d.get('package'),dict):admit(pathlib.Path(d['consumer']['directory'])/'vmitsaras-raveldex-0.1.0-rc.0.tgz',d['package']['sha256'])
for h,f in packages.items():files['private-packages/'+h+'-'+f.name]=f
manifest={'scope':'Curated local RX-7005 original/fixed/final logs and observations, diagnostics/replay, task-start baselines, qualified source and each distinct private package. No dependency trees, caches or .git. Original failures retain their actual package identities; pre-repair installed regression package deliberately precedes repaired source snapshots.','files':{a:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for a,f in sorted(files.items())}}
mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=e/'RX-7005-raw.tar.gz'
with archive.open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,f in sorted(files.items()):
    info=tar.gettarinfo(str(f),arcname=name);info.uid=info.gid=0;info.uname=info.gname=''
    with f.open('rb') as stream:tar.addfile(info,stream)
   info=tarfile.TarInfo('manifest.json');info.size=len(mb);tar.addfile(info,io.BytesIO(mb))
with tarfile.open(archive,'r:gz') as tar:
 for a,meta in manifest['files'].items():assert hashlib.sha256(tar.extractfile(a).read()).hexdigest()==meta['sha256'],a
r={'path':'docs/evidence/RX-7005-raw.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)+1,'uniquePrivatePackageSHA256':sorted(packages),'memberHashReadback':'Pass'};v['rawArchive']=r;(e/'RX-7005-verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(r,indent=2))
