import pathlib,json,hashlib
root=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex');p=pathlib.Path('/private/tmp/raveldex-rx7005-y6l8asn7');before=json.loads((p/'before-hashes.json').read_text());changed=[]
for name,h in before.items():
 f=root/name;assert f.is_file(),name
 if hashlib.sha256(f.read_bytes()).hexdigest()!=h:changed.append(name)
source=[f for f in changed if f.startswith(('src/','integrations/'))];assert set(source)=={'src/addons/ui/directory-view.ts','src/addons/ui/mounts.ts'},source
assert not any(f.startswith(('examples/','docs/evidence/')) and f != 'examples/README.md' for f in changed),[f for f in changed if f.startswith(('examples/','docs/evidence/'))]
old=json.loads((p/'baseline/docs/planning/roadmap.json').read_text());new=json.loads((root/'docs/planning/roadmap.json').read_text());a={t['id']:t for t in old['tasks']};b={t['id']:t for t in new['tasks']};assert old['milestones']==new['milestones'];assert a.keys()==b.keys()
for key in a:
 if key!='RX-7005':assert a[key]==b[key],key
for key in ['dependsOn','acceptanceCriteria','verification']:assert a['RX-7005'][key]==b['RX-7005'][key],key
v=json.loads((root/'docs/evidence/RX-7005-verification.json').read_text());
for f,h in v['sourceSHA256'].items():assert hashlib.sha256((root/f).read_bytes()).hexdigest()==h,f
r={'status':'Pass','baselinePaths':len(before),'unchanged':len(before)-len(changed),'changed':changed,'missing':[],'existingSourceChanges':source,'sourceScope':'Base view extracted to private fixed-presentation mount; mount kind union extends with directory-cards. All core/providers/nonvisual directory/URL/other UI/adapters/integrations, seven earlier starter trees and earlier evidence retain task-start hashes. Existing directory-gallery test only waits for committed exact destination/heading.','otherTaskObjectsUnchanged':len(a)-1,'allMilestonesUnchanged':len(new['milestones']),'selectedAcceptanceDependenciesVerificationUnchanged':True,'done':sum(t['status']=='done' for t in new['tasks']),'planned':sum(t['status']=='planned' for t in new['tasks']),'selectedStatus':b['RX-7005']['status'],'next':'RX-7006','sourceHashesCurrent':True};(p/'scope-final.json').write_text(json.dumps(r,indent=2)+'\n');(root/'docs/evidence/RX-7005-scope.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['changed','sourceScope']}))
