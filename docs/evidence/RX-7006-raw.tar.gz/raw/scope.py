import pathlib,json,hashlib
root=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex');p=pathlib.Path('/private/tmp/raveldex-rx7006-lb8vd1yx');before=json.loads((p/'before-hashes.json').read_text());changed=[]
for name,h in before.items():
 f=root/name;assert f.is_file(),name
 if hashlib.sha256(f.read_bytes()).hexdigest()!=h:changed.append(name)
code=[f for f in changed if f.startswith('src/') or f.startswith('integrations/') and not f.endswith('README.md')];assert code==[],code
assert not any(f.startswith('docs/evidence/') or f.startswith('examples/') and f!='examples/README.md' for f in changed),[f for f in changed if f.startswith(('docs/evidence/','examples/'))]
assert set(f for f in changed if f.startswith('test/'))=={'test/pages/solutions-qualification.test.mjs','test/ui/modal-browser.test.mjs','test/ui/announcements-browser.test.mjs'}
a=json.loads((p/'baseline/docs/planning/roadmap.json').read_text());b=json.loads((root/'docs/planning/roadmap.json').read_text());assert a['milestones']==b['milestones'];old={t['id']:t for t in a['tasks']};new={t['id']:t for t in b['tasks']};assert old.keys()==new.keys()
for key in old:
 if key!='RX-7006':assert old[key]==new[key],key
for key in ['dependsOn','acceptanceCriteria','verification']:assert old['RX-7006'][key]==new['RX-7006'][key],key
v=json.loads((root/'docs/evidence/RX-7006-verification.json').read_text());
for name,h in v['sourceSHA256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
assert (root/'docs/_pages-manifest.json').read_bytes()==(p/'site-tested-manifest.json').read_bytes()
r={'status':'Pass','baselinePaths':len(before),'unchanged':len(before)-len(changed),'changed':changed,'missing':[],'productionCodeChanges':code,'sourceScope':'All production runtime/core/provider/UI/adapter/integration code, package metadata/dependencies/lockfile, all earlier starter source trees, frozen qualification fixtures/judgments and all earlier evidence retain task-start bytes. Earlier tests change only five-family gallery assertions, exact modal-popup navigation wait and single-command/current-generation announcement guards.','otherTaskObjectsUnchanged':len(old)-1,'allMilestonesUnchanged':len(b['milestones']),'selectedAcceptanceDependenciesVerificationUnchanged':True,'done':sum(t['status']=='done' for t in b['tasks']),'planned':sum(t['status']=='planned' for t in b['tasks']),'next':None,'nextMeaning':'Active selected release backlog complete; manual/platform and remote/release decisions remain separate.','sourceHashesCurrent':True};(p/'scope-final.json').write_text(json.dumps(r,indent=2)+'\n');(root/'docs/evidence/RX-7006-scope.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['changed','sourceScope']}))
