import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
const directory='/private/var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-F9m813';
const bundle=await readFile(directory+'/browser-announcements-bundle.mjs');
const sha=createHash('sha256').update(bundle).digest('hex');
assert.equal(sha,'b868c762922dc2996389d0c854e1d9a5db19193d20e6b5364aa420c304049e39');
const html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Announcement race isolated read-only probe</title><link rel="stylesheet" href="/styles.css"></head><body><main><h1>Announcement race probe</h1><p id="announcement-mode"></p><button id="inject-error" type="button">Inject next search error</button><button id="destroy-ui" type="button">Destroy UI</button><button id="remount-ui" type="button">Remount UI</button><p id="fixture-status"></p><p id="announcement-output"></p><div id="fixture-root"><p id="authored">Authored fallback</p></div><pre id="announcement-trace"></pre></main><script type="module" src="/browser-announcements-bundle.mjs"></script></body></html>';
const server=createServer(async(req,res)=>{const path=new URL(req.url,'http://localhost').pathname;if(path==='/ui-announcements'){res.setHeader('content-type','text/html');res.end(html);}else if(path==='/browser-announcements-bundle.mjs'){res.setHeader('content-type','text/javascript');res.end(bundle);}else if(path==='/styles.css'){res.setHeader('content-type','text/css');res.end(await readFile(directory+'/styles.css'));}else res.writeHead(404).end();});
await new Promise((ok,no)=>{server.once('error',no);server.listen(0,'127.0.0.1',ok);});
const origin='http://127.0.0.1:'+server.address().port;
const report={kind:'raveldex-announcement-fill-only-isolated-probe-v1',bundleSHA256:sha,installedDirectory:directory,scope:'One isolated headless Chrome using exact synchronized-check installed bundle. No repo/runtime edits. Native Playwright fill alone selects one debounced query command. No added sleep, timeout increase, synthetic submit or production bypass. Retry remains a real click. DOM state/trace, not human speech.',observations:[]};
let browser;
try{
 browser=await chromium.launch({channel:'chrome',headless:true});report.browser=browser.version();
 const page=await browser.newPage();const pageErrors=[];page.on('pageerror',e=>pageErrors.push(e.message));
 const compact=()=>page.evaluate(()=>{const p=window.announcementProbe.snapshot(),root=document.getElementById('fixture-root');return{publishedCount:p.publishedCount,lastPublication:p.lastPublication,current:p.current,retry:{hidden:root.querySelector('[data-raveldex-retry]').hidden,ariaDisabled:root.querySelector('[data-raveldex-retry]').getAttribute('aria-disabled')},calls:window.harness.calls().map((x,i)=>({index:i,query:x.query,extensions:Object.keys(x.options.extensions??{}),completed:x.completed,aborted:x.aborted,total:x.result?.total})),rows:p.rows.filter(x=>x.kind==='publish').map(x=>({kind:x.kind,generation:x.generation,status:x.status,requestedBusy:x.requestedBusy,main:x.main,snippets:x.snippets,publication:x.publication}))};});
 const open=async()=>{await page.goto(origin+'/ui-announcements?mode=settled-assertive&busy=shell');await page.waitForFunction(()=>window.announcementProbe?.snapshot().publishedCount===1&&window.announcementProbe.snapshot().current.requestedBusy==='false');};
 await open();
 const attempts=[];
 for(let i=0;i<8;i++){
  await page.locator('#inject-error').click();
  const before=await compact(), baseline=before.calls.length;
  await page.locator('[data-raveldex-input]').fill('blue');
  // Exact parent-proposed existing helper publication predicate, with no Enter.
  await page.waitForFunction(count=>{const p=window.announcementProbe.snapshot();return p.publishedCount>count&&p.lastPublication?.text==='Search failed. Retry is available.';},before.publishedCount);
  const failure=await compact();
  assert.equal(failure.calls.length-baseline,1);assert.equal(failure.current.requestedBusy,'false');assert.equal(failure.retry.ariaDisabled,'false');assert.equal(failure.lastPublication.kind,'error');
  assert.equal(await page.locator('[data-raveldex-input]').evaluate(node=>node===document.activeElement),true);
  await page.locator('[data-raveldex-retry]').click();
  await page.waitForFunction(count=>{const p=window.announcementProbe.snapshot();return p.publishedCount>count&&p.lastPublication?.text==='1 results. Showing 1–1.';},failure.publishedCount);
  const recovered=await compact();
  assert.equal(recovered.calls.length-baseline,3);assert.equal(recovered.current.requestedBusy,'false');assert.equal(recovered.retry.ariaDisabled,'true');assert.equal(recovered.lastPublication.kind,'result');assert.deepEqual(recovered.calls.slice(-2).map(x=>x.total),[1,1]);
  attempts.push({index:i,beforeCalls:baseline,failedMainCalls:failure.calls.length-baseline,failurePublication:failure.lastPublication,failureRequestedBusy:failure.current.requestedBusy,failedRetry:failure.retry,recoveryMainAndSnippetCalls:recovered.calls.length-failure.calls.length,recoveryPublication:recovered.lastPublication,recoveryRequestedBusy:recovered.current.requestedBusy,recoveryRetry:recovered.retry,nativeTotals:recovered.calls.slice(-2).map(x=>x.total)});
 }
 report.observations.push({name:'Playwright fill-only single debounced command preserves genuine Retry and settled publication',attempts});
 report.pageErrors=pageErrors;assert.deepEqual(pageErrors,[]);await page.evaluate(()=>window.harness.cleanup());report.status='Pass';
}catch(e){report.status='Fail';report.error={message:e.message,stack:e.stack};throw e;}
finally{await writeFile('/private/tmp/raveldex-rx7006-lb8vd1yx/announcement-fill-only-probe.json',JSON.stringify(report,null,2)+'\n');await browser?.close();server.closeAllConnections();await new Promise(ok=>server.close(ok));}
console.log(JSON.stringify({status:report.status,browser:report.browser,observations:report.observations.map(x=>x.name)}));
