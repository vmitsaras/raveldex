import pathlib,json,hashlib,tarfile,io,gzip
root=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex');p=pathlib.Path('/private/tmp/raveldex-rx7006-lb8vd1yx');e=root/'docs/evidence';v=json.loads((e/'RX-7006-verification.json').read_text());assert v['synchronizedCheck']['status']=='Pass' and v['finalPagesBuild']['status']=='Pass';files={}
for f in p.iterdir():
 if f.is_file():files['raw/'+f.name]=f
for folder in ['baseline','screenshots-chrome','screenshots-webkit','screenshots-fullpage-chrome','screenshots-fullpage-webkit','screenshots-initial-chrome','screenshots-initial-webkit']:
 for f in (p/folder).rglob('*'):
  if f.is_file():files['raw/'+str(f.relative_to(p))]=f
source=set(v['sourceSHA256'])|{'package.json','site/starters.mjs','scripts/lib/packed-consumer.mjs','scripts/lib/inline-starters.mjs','test/oracle/query.mjs','docs/specs/SEARCH_SOLUTIONS.md','docs/planning/SEARCH_SOLUTIONS_IMPLEMENTATION_PLAN.md'}
for f in root.joinpath('examples').rglob('*'):
 if f.is_file() and any(part in {'inline-browser','inline-astro','modal-browser','modal-astro','dropdown-browser','directory-browser','directory-astro','cards-browser'} for part in f.parts) and not any(part in {'node_modules','dist','.astro'} for part in f.parts):source.add(str(f.relative_to(root)))
for name in sorted(source):files['qualified-source/'+name]=root/name
c=json.loads((p/'candidate-comparison.json').read_text());f=pathlib.Path(c['candidateReport']);files['raw/candidate-report.json']=f;candidate=json.loads(f.read_text());packages={}
def admit(path,expected=None):
 f=pathlib.Path(path)
 if not f.is_file():return False
 h=hashlib.sha256(f.read_bytes()).hexdigest()
 if expected is not None:assert h==expected,(str(f),h,expected)
 packages[h]=f;return True
assert admit(candidate['package']['tarball'],candidate['package']['sha256'])
for f in p.glob('*.json'):
 d=json.loads(f.read_text())
 if not isinstance(d,dict):continue
 if isinstance(d.get('consumer'),dict) and isinstance(d.get('package'),dict) and 'directory' in d['consumer']:assert admit(pathlib.Path(d['consumer']['directory'])/'vmitsaras-raveldex-0.1.0-rc.0.tgz',d['package']['sha256'])
 if isinstance(d.get('packages'),dict) and 'sourceDirectory' in d['packages']:
  pkg=d['packages'];parent=pathlib.Path(pkg['sourceDirectory']).parent;wanted={pkg[k] for k in ['coreSha256','coreSHA256','astroSha256','astroSHA256'] if k in pkg};found=set()
  for item in list(parent.glob('*.tgz'))+list(parent.glob('*/*.tgz')):
   h=hashlib.sha256(item.read_bytes()).hexdigest()
   if h in wanted:admit(item,h);found.add(h)
  assert found==wanted,(f.name,wanted-found)
 def explicit(value):
  if isinstance(value,dict):
   if isinstance(value.get('tarball'),str) and 'sha256' in value:admit(value['tarball'],value['sha256'])
   for child in value.values():explicit(child)
  elif isinstance(value,list):
   for child in value:explicit(child)
 explicit(d)
for h,f in packages.items():files['private-packages/'+h+'-'+f.name]=f
manifest={'scope':'Curated RX-7006 original/fixed/final logs/reports/probes, task-start baselines, qualified source, all raw screenshot stages and each distinct retained private package. Initial hook/selector/timing/metadata/capture failures retain their actual scope. No dependency trees, caches or Git data.','files':{a:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for a,f in sorted(files.items())}};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=e/'RX-7006-raw.tar.gz'
with archive.open('wb') as out:
 with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,f in sorted(files.items()):
    info=tar.gettarinfo(str(f),arcname=name);info.uid=info.gid=0;info.uname=info.gname=''
    with f.open('rb') as stream:tar.addfile(info,stream)
   info=tarfile.TarInfo('manifest.json');info.size=len(mb);tar.addfile(info,io.BytesIO(mb))
with tarfile.open(archive,'r:gz') as tar:
 assert json.loads(tar.extractfile('manifest.json').read())==manifest
 for name,meta in manifest['files'].items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==meta['sha256'],name
r={'path':'docs/evidence/RX-7006-raw.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files)+1,'uniquePrivatePackageSHA256':sorted(packages),'payloadHashAndManifestReadback':'Pass'};v['rawArchive']=r;(e/'RX-7006-verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(r,indent=2))
