import concurrent.futures,datetime,json,pathlib,sys,urllib.request,urllib.error,urllib.parse
root=pathlib.Path(sys.argv[1]); stage=pathlib.Path(sys.argv[2])
urls=json.loads((stage/'links-repository.json').read_text())['external']
def check(item):
    url=item['url']; row={**item}; parsed=urllib.parse.urlsplit(url)
    private=parsed.hostname=='github.com' and parsed.path.startswith('/vmitsaras/raveldex')
    request=urllib.request.Request(url,headers={'User-Agent':'Raveldex-documentation-link-audit/1.0','Accept':'text/html'})
    try:
        with urllib.request.urlopen(request,timeout=15) as response:
            row.update(httpStatus=response.status,finalUrl=response.url)
            response.read(1024)
    except urllib.error.HTTPError as e:row.update(httpStatus=e.code,finalUrl=e.url)
    except Exception as e:row.update(httpStatus=None,errorType=type(e).__name__,error=str(e)[:300])
    if private:
        row.update(status='Access required',reason='Connected repository metadata confirms private; anonymous HTTP is not authenticated file validation.')
        if '/blob/main/' in parsed.path:
            rel=urllib.parse.unquote(parsed.path.split('/blob/main/',1)[1]);row['localRepositoryTarget']=rel;row['localTargetExists']=(root/rel).is_file()
            if not row['localTargetExists']:row.update(status='Fail',reason='Required repository file missing locally')
    elif row['httpStatus'] is not None and 200<=row['httpStatus']<400:row['status']='Pass'
    elif row['httpStatus'] in (404,410):row.update(status='Fail',reason='Public URL confirmed missing')
    else:row.update(status='Blocked',reason='Network, access or upstream failure; not a confirmed missing page')
    return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(check,urls))
report={'kind':'raveldex-public-docs-external-links-v1','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repositoryVisibility':'private (fresh connected GitHub metadata)','method':'Anonymous read-only GET with redirect following, timeout15s, first1024bytes only; no credentials, remote writes or page-content instructions','fragmentScope':'HTTP does not verify fragments; private file fragments separately compared to local source where applicable','rows':rows,'counts':{s:sum(r['status']==s for r in rows) for s in ['Pass','Access required','Blocked','Fail']}}
(stage/'links-external.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['counts']));print(json.dumps([r for r in rows if r['status'] in ('Blocked','Fail')],indent=2))
