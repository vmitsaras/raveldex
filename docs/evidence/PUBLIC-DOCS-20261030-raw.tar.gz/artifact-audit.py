import hashlib,json,pathlib,re,subprocess,sys,tarfile
repo=pathlib.Path(sys.argv[1]);stage=pathlib.Path(sys.argv[2]);sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def tar(p):
 with tarfile.open(p) as t:
  rows={}
  for m in t.getmembers():
   parts=pathlib.PurePosixPath(m.name).parts
   assert parts[0]=='package' and '..' not in parts and not m.name.startswith('/')
   assert m.isfile() or m.isdir()
   if m.isfile():rows['/'.join(parts[1:])]=t.extractfile(m).read()
  return rows
prep=read(stage/'artifacts/core/preparation.json');report=read(stage/'artifacts/core/candidate-report.json')
assert prep['status']=='Pass' and prep['projectCheck']['exitCode']==0
log=(stage/'artifacts/core/verification.log').read_bytes();assert sha(log)==prep['projectCheck']['sha256'];assert sha((stage/'artifacts/core/candidate-report.json').read_bytes())==prep['candidateReport']['sha256']
text=log.decode();counts=[int(n) for n in re.findall(r'(?:ℹ tests |# tests )([0-9]+)',text)];assert counts==[776,30,24,26,1,3] and sum(counts)==860
for label in ['fail','cancelled','skipped','todo']:
 vals=[int(n) for n in re.findall(r'(?:ℹ |# )'+label+r' ([0-9]+)',text)];assert len(vals)==6 and sum(vals)==0,(label,vals)
artifacts=[]
for name,record,baseline,source in [('core','candidate-report.json','RX-A100-core-0.1.0-rc.0.tgz',repo),('english','english-package.json','RX-A040-english-0.1.0-rc.0.tgz',repo/'integrations/languages/english'),('astro','astro-package.json','RX-A100-astro-0.1.0-rc.0.tgz',repo/'integrations/astro')]:
 r=read(stage/'artifacts'/name/record);p=r['package'];archive=stage/'artifacts'/name/pathlib.Path(p['tarball']).name;actual=tar(archive);old=tar(repo/'docs/evidence'/baseline)
 assert r['status']=='Pass' and p['private'] and p['version']=='0.1.0-rc.0' and sha(archive.read_bytes())==p['sha256']
 inventory={f['path']:f for f in p['files']};assert set(inventory)==set(actual)
 for path,data in actual.items():
  f=inventory[path];assert f['sha256']==sha(data),(name,path)
  assert f.get('bytes',f.get('size'))==len(data),(name,path,f)
 runtime={k:v for k,v in actual.items() if k.startswith('dist/')};oldruntime={k:v for k,v in old.items() if k.startswith('dist/')};assert runtime==oldruntime,(name,'production changed')
 assert actual['package.json']==old['package.json'] and actual['LICENSE']==old['LICENSE']
 for path,data in actual.items():
  if path.endswith('.md'):assert data==(source/path).read_bytes(),(name,path,'packaged guide differs from final checkout')
 for path in actual:assert not path.startswith(('docs/history/','docs/planning/','docs/evidence/','examples/'))
 differences=[k for k in set(actual)|set(old) if actual.get(k)!=old.get(k)];assert all(k.endswith('.md') for k in differences)
 artifacts.append({'name':p['name'],'version':p['version'],'private':True,'bytes':len(archive.read_bytes()),'sha256':p['sha256'],'members':len(actual),'productionMembersUnchanged':len(runtime),'baseline':baseline,'documentationChanges':sorted(differences)})
protected=['src','package.json','package-lock.json','.github','scripts','test','docs/specs','docs/architecture','docs/planning/roadmap.json','integrations/astro/src','integrations/astro/package.json','integrations/languages/english/package.json','examples/astro/src','examples/astro/content.json','examples/astro/content-provenance.json','examples/astro/qualification.mjs','examples/astro/configuration.mjs','examples/astro/astro.config.mjs']
subprocess.run(['git','diff','--exit-code','87fb5c3','--',*protected],cwd=repo,check=True,stdout=subprocess.PIPE)
astro=read(stage/'astro-observations.json');assert astro['status']=='Pass' and astro['correctness']['browserComparisons']==42 and astro['correctness']['nodeSourceNativeComparisons']==84
follow=read(stage/'follow-instructions.json');assert follow['status']=='Pass' and len(follow['observations'])==4
links={k:read(stage/f'links-{k}.json') for k in ['repository','core-package','english-package','astro-package']}
assert all(v['status']=='Pass' and v['files'] for v in links.values());assert read(stage/'link-calibration.json')['status']=='Pass'
external=read(stage/'links-external.json');assert external['counts']=={'Pass':4,'Access required':25,'Blocked':0,'Fail':0}
changedPaths=subprocess.check_output(['git','diff','--name-only','87fb5c3'],cwd=repo,text=True).splitlines();allowedRecords={'docs/planning/DOCUMENTATION_REVIEW.json','docs/evidence/PUBLIC-DOCS-20261030-raw.tar.gz'};assert all(p.endswith('.md') or p in allowedRecords for p in changedPaths);sourcePaths=[p for p in changedPaths if p.endswith('.md')]
review={'kind':'raveldex-public-docs-artifact-audit-v1','status':'Pass','baseSource':'87fb5c3','testBatches':counts,'testTotal':sum(counts),'failSkipCancelTodo':0,'artifacts':artifacts,'environment':{**report['environment'],**read(stage/'environment-extra.json'),'browser':astro['environment']['browser'],'browserChannel':astro['environment']['browserChannel'],'astro':astro['environment']['astro']},'links':{k:{'files':len(v['files']),'links':v['links'],'status':v['status']} for k,v in links.items()},'externalLinks':external['counts'],'unchangedProtectedPaths':protected,'documentationPaths':[{'path':p,'sha256':sha((repo/p).read_bytes())} for p in sourcePaths],'scope':'Independent archive/report/content comparison and exact documented fresh-consumer execution; no new human AT, physical-input, broad-browser or allocation/copy qualification. No remote CI for these changed bytes.'}
(stage/'artifact-audit.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'status':'Pass','tests':860,'artifacts':artifacts,'links':review['links']}))
