# Changelog

## Unreleased

This draft describes the complete implemented product. All packages remain private `0.1.0-rc.0`; no public version, release date, npm publication or GitHub release is announced here.

### Native core

- Pure ESM TypeScript library with declarations and zero runtime dependencies: native frequency indexing, exact/prefix/Boolean/scalar-equality queries, exact totals and deterministic field-local `raveldex-bm25-v1` ranking.
- Incremental atomic mutations, coherent revisions, immutable input ownership, finite resource/work/deadline limits, FIFO execution, cooperative cancellation and explicit disposal.

### Optional search and interface capabilities

- Selected source, positions/original offsets, strict source/position/mixed phrases, numeric/set filters, exact conjunctive facets, numerical Inspector facts, original match ranges and bounded grapheme-safe snippets.
- Explicit bounded typo tolerance, dictionary-backed token suggestions and one-step directional synonyms; ordinary queries do not enable these automatically.
- Explicit English Porter 1980 analysis and code/identifier components with original-only strict phrases.
- Raw case-sensitive literal/infix predicates, ordered proximity over selected original positions, and a bounded Boolean/field/phrase/prefix query compiler. Ordered leaves explicitly refuse token-range/snippet projection.
- Revision-guarded whole-field record patches over complete selected source, using the existing atomic replacement path.
- Native DOM UI with separate CSS, composition-aware search, facets/pages, error/retry, Inspector and authored-content restoration. The application retains engine ownership.

### Hosts and separate packages

- One-owner module workers with explicit ownership and outcome receipts; versioned source and exactly qualified Node native snapshots; namespaced IndexedDB save/load/erase with generation conflicts and explicit recovery.
- Validated LocalSearch complete-source conversion into a new native owner; no foreign index or score reuse.
- Separate `@vmitsaras/raveldex-english` analyzer package and `@vmitsaras/raveldex-astro` explicit static allowlist/build-hook/on-demand-loader package. Both require the exact core `0.1.0-rc.0` peer. Astro has an optional exact `astro@7.3.2` peer and Node `>=22.12.0`; core/English declare Node `>=22`.

### Documentation and evaluation

- Current [API reference](docs/api/README.md), executable installed-package examples, local documentation pilots, complete private-artifact setup instructions and scoped [support notes](docs/support/RX-4003.md).
- Independent retrieval/ranking checks and frozen documentation relevance judgments, actual browser fixtures, bounded Safari/VoiceOver and physical-input sessions, and separately calibrated memory observations. Each record retains its exact environment, workload and quantity.

### Known limitations

- Lexical/vocabulary gaps and English overstemming remain; the original judged corpus is not a general relevance guarantee.
- The full core exceeds the unchanged 15 KiB gzip planning target. Recorded sizes depend on the selected graph, tooling and compression runtime; serialized bytes are not retained/peak heap measurements.
- Admitted collections can exceed whole-source operation budgets. Unknown worker/storage outcomes require reconciliation or explicit new-owner recovery, not assumed rollback or automatic retry.
- Native snapshots require exact qualified Node environments; browser/worker native state is unavailable. Astro supports static directory builds, not SSR, development watchers or content crawling.
- UI transport errors have generic presentation. Earlier VoiceOver interruptions retain an unconfirmed cause; accepted normal-typing observations do not establish all-reader support or a required VoiceOver setting.

See [compatibility](docs/release/COMPATIBILITY.md), [candidate scope](docs/release/CANDIDATE.md) and [publication preparation](docs/release/PUBLICATION_STATUS.md). Repository evidence links require repository access. Historical private preparations are maintainer history, not issued releases.
