# Raveldex

**Native local search with exact totals, atomic updates and optional feature costs.**

Raveldex is a framework-agnostic TypeScript library for mutable local collections. Its pure ESM core owns indexing, retrieval and field-local BM25 ranking with zero runtime dependencies. Core needs no DOM, worker or database and retains no original text. Add source, phrases, positions, filters, facets, evidence, UI or host adapters explicitly when the application needs them.

All 21 release-track and ten optional tasks are implemented. The packages remain **private `0.1.0-rc.0` and unpublished**; [release notes](CHANGELOG.md) are an Unreleased draft. Use local tarballs, not a registry-only install command. [Publication status](docs/release/PUBLICATION_STATUS.md) separates completed implementation from remaining release decisions.

## Install for evaluation

Use npm and an ESM application. Core/English declare Node `>=22`; the separate Astro package requires Node `>=22.12.0`. Node 24 is suitable for the full repository tooling. Repository and evidence links require repository access; the installed core tarball includes this README and the linked API/release/support guides.

From a source checkout, first read [preparation prerequisites](docs/release/PREPARATION.md#prerequisites), including the browser required by the full checks:

```sh
npm ci
npm run candidate:prepare -- --output /tmp/raveldex-candidate-review
```

The output directory must not already exist. In a fresh application directory:

```sh
npm init -y
npm pkg set type=module
npm install --offline --ignore-scripts /tmp/raveldex-candidate-review/vmitsaras-raveldex-0.1.0-rc.0.tgz
```

## Smallest core example

<!-- candidate-example: quick-start -->
```js
import { createRaveldex } from '@vmitsaras/raveldex';

const engine = createRaveldex({
  schema: { text: { title: { boost: 2 }, body: {} } },
});
try {
  await engine.add({
    id: 'guide:updates',
    text: { title: 'Atomic updates', body: 'Replace one complete record.' },
  });
  const page = await engine.search('atomic');
  console.log(page.revision, page.total, page.hits);
} finally {
  await engine.dispose();
}
```

The factory returns an empty revision-0 engine. It exposes `search`, `add`, `addMany`, `replace`, `remove`, `clear` and `dispose`. Configuration errors throw; operational failures reject promises. Core returns IDs and scores; the application owns display records. Plain strings require all analyzed complete terms. Quotes and operators are ordinary punctuation unless the application explicitly selects the query compiler.

## Documentation and examples

| Need | Start here |
| --- | --- |
| Records, schema, queries, ranking, limits and lifecycle | [Core reference](docs/api/CORE.md) |
| Imports and choosing optional costs | [Complete API/export map](docs/api/README.md) |
| Phrases, positions, filters/facets, Inspector, ranges/snippets | [Search add-ons](docs/api/ADDONS.md) |
| Native UI/CSS, workers, snapshots, IndexedDB and migration | [Host integration guide](docs/api/HOSTS.md) |
| Small copyable installed-package examples | [Runnable API modules](docs/api/examples/README.md) |
| Preparing and installing all three private packages | [Artifact preparation](docs/release/PREPARATION.md) |
| Browser/AT/input/memory evidence and practical limitations | [Support scope](docs/support/RX-4003.md) |

The repository [example index](https://github.com/vmitsaras/raveldex/blob/main/examples/README.md) links the real-document CLI (`npm run pilot:core -- 'atomic mutation'`), local browser pilot (`npm run pilot:ui`), Astro static fixture and migration example. These require repository access; no public demo site is offered. The browser pilot selects phrase/evidence/facet/Inspector capabilities and direct/worker execution; it does not automatically enable every optional search mode.

## Explicit optional features

- [Typo tolerance](docs/api/TYPO.md), [token suggestions](docs/api/SUGGESTIONS.md) and [directional synonyms](docs/api/SYNONYMS.md) add bounded explicit operations; suggestions do not rewrite input automatically.
- [English morphology](docs/api/ENGLISH.md) and [identifier analysis](docs/api/IDENTIFIERS.md) select analysis deliberately. Identifier component searches retain original-only strict phrases.
- [Literal/infix matching](docs/api/LITERAL.md), [ordered proximity](docs/api/PROXIMITY.md) and [query syntax](docs/api/QUERY_SYNTAX.md) have separate contracts. Ordinary core strings stay strict lexical queries.
- [Record patches](docs/api/RECORD_PATCH.md) apply revision-guarded whole-field changes over complete selected source through existing atomic replacement.
- The separate [`@vmitsaras/raveldex-astro`](docs/api/STATIC_ASTRO.md) package builds explicit allowlists and loads static artifacts on demand. The English analyzer is also available as separate `@vmitsaras/raveldex-english`; both use exact core peers. Neither is needed by core alone.

## Support and limitations

Importing core performs no network access, DOM work, worker creation, database open or automatic initialization. UI JavaScript and [CSS](docs/api/HOSTS.md#native-dom-ui-and-css) are separate imports; destroy a borrowed UI before disposing its engine.

This is lexical search. Default analysis is not accent-insensitive or semantic retrieval. Frozen documentation evaluations retain vocabulary/ranking gaps, English overstemming and the unchanged 15 KiB core gzip target miss. Resource ceilings are not universal completion or latency guarantees. Native snapshots require exact application-qualified Node environments; source rebuilds are the browser/worker route. Unknown transport/storage outcomes require explicit reconciliation or recovery.

The [support record](docs/support/RX-4003.md) distinguishes automated browser checks, bounded human VoiceOver/physical-input observations and measured memory quantities. It establishes no universal WCAG, all-reader, Unicode-portability or performance guarantee. See [compatibility](docs/release/COMPATIBILITY.md), [release scope](docs/release/CANDIDATE.md) and [preparation](docs/release/PREPARATION.md) before evaluation or release decisions.

MIT licensed. Repository-access users can read the [contribution guide](https://github.com/vmitsaras/raveldex/blob/main/CONTRIBUTING.md) and report reproducible defects through the [issue tracker](https://github.com/vmitsaras/raveldex/issues), without sharing private application data.
