import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn,execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {pathToFileURL} from 'node:url';
const exec=promisify(execFile), [repo,stage]=process.argv.slice(2), artifacts=path.join(stage,'artifacts');
const env={...process.env,RAVELDEX_REPOSITORY:repo,RAVELDEX_ARTIFACTS:artifacts,npm_config_cache:'/tmp/raveldex-docs-npm-cache',ASTRO_TELEMETRY_DISABLED:'1'};
const commands=[],observations=[];const read=p=>fs.readFile(path.join(repo,p),'utf8');
const sh=text=>[...text.matchAll(/```sh\n([\s\S]*?)\n```/g)].map(m=>m[1]);
async function run(command,cwd=repo){const row={command,cwd};commands.push(row);try{const r=await exec('/bin/bash',['-c',command],{cwd,env,timeout:180000,maxBuffer:4*1024*1024});Object.assign(row,{exitCode:0,stdout:r.stdout,stderr:r.stderr});return r;}catch(e){Object.assign(row,{exitCode:e.code,stdout:e.stdout,stderr:e.stderr});throw e;}}
let browser,server;const errors=[];
try {
 const app=path.join(stage,'readme-app-'+Date.now());await fs.mkdir(app);
 const readme=await read('README.md'),blocks=sh(readme);assert.equal(blocks.length,2);
 await run(blocks[1].replaceAll('/tmp/raveldex-candidate-review',path.join(artifacts,'core')),app);
 const quick=/<!-- candidate-example: quick-start -->\n```js\n([\s\S]*?)\n```/.exec(readme)[1];await fs.writeFile(path.join(app,'quick.mjs'),quick+'\n');const quickResult=await run('node quick.mjs',app);assert.match(quickResult.stdout,/guide:updates/);observations.push({name:'README exact installed quick start',stdout:quickResult.stdout,scope:'One fresh offline core tar install; fixed example output path replaced with actual prepared core directory.'});
 const english=await read('integrations/languages/english/README.md'),enInstall=sh(english)[0].replace('/absolute/artifacts',artifacts).replace('/absolute/artifacts',artifacts);await run(enInstall,app);const enCode=/```js\n([\s\S]*?)\n```/.exec(english)[1];await fs.writeFile(path.join(app,'english.mjs'),enCode+'\n');const en=await run('node english.mjs',app);assert.match(en.stdout,/guide/);observations.push({name:'Separate English exact README example',stdout:en.stdout});
 const fixtureSh=sh(await read('examples/astro/README.md'));assert.equal(fixtureSh.length,4);
 const setup=await run(fixtureSh[0]+'\nprintf "\\nRAVELDEX_EXAMPLE_RESULT=%s\\n" "$RAVELDEX_EXAMPLE"');const example=/RAVELDEX_EXAMPLE_RESULT=(.+)/.exec(setup.stdout)[1];env.RAVELDEX_EXAMPLE=example;
 const {chromium}=await import(pathToFileURL(path.join(repo,'node_modules/playwright-core/index.mjs')));browser=await chromium.launch({channel:'chrome',headless:true});
 for(let i=1;i<=2;i++){
  const base=i===1?'/':'/docs/', lines=fixtureSh[i===1?1:3].split('\n');assert.equal(lines.length,2);await run(lines[0]);
  const preview=await run(lines[1]);const log=preview.stdout+preview.stderr;const m=/http:\/\/127\.0\.0\.1:(\d+)/.exec(log);assert.ok(m,'Background preview reports its URL');const url='http://127.0.0.1:'+m[1]+base;
  try {
   const response=await fetch(new URL('raveldex/manifest.json',url)),manifest=await response.json();assert.equal(response.status,200);assert.equal(manifest.base,base);assert.equal(manifest.recordCount,3);
   const page=await browser.newPage(),pageErrors=[];page.on('pageerror',e=>pageErrors.push(String(e)));await page.goto(url);assert.equal(await page.locator('[data-authored-fallback]').count(),1);
   await page.getByRole('button',{name:'Load search data',exact:true}).click();await page.locator('body[data-search-state="ready"]').waitFor();await page.getByRole('button',{name:'Open search',exact:true}).click();await page.locator('body[data-search-state="open"]').waitFor();
   await page.getByRole('searchbox',{name:'Search documentation',exact:true}).fill('atomic');await page.getByRole('button',{name:'Search',exact:true}).click();await page.waitForFunction(()=>document.querySelector('[data-raveldex-status]')?.textContent==='1 results. Showing 1–1.');
   await page.getByRole('button',{name:'Inspect results',exact:true}).click();await page.getByRole('dialog',{name:'Inspector',exact:true}).waitFor();assert.equal(await page.getByRole('button',{name:'Close Inspector',exact:true}).evaluate(e=>e===document.activeElement),true);await page.keyboard.press('Escape');assert.equal(await page.getByRole('button',{name:'Inspect results',exact:true}).evaluate(e=>e===document.activeElement),true);
   await page.getByRole('button',{name:'Inject next search error',exact:true}).click();await page.getByRole('button',{name:'Search',exact:true}).click();await page.waitForFunction(()=>document.querySelector('[data-raveldex-status]')?.textContent==='Search failed. Retry is available.');await page.getByRole('button',{name:'Retry search',exact:true}).click();await page.waitForFunction(()=>document.querySelector('[data-raveldex-status]')?.textContent==='1 results. Showing 1–1.');
   const native=await page.evaluate(()=>window.raveldexAstroFixture.native());assert.equal(native.reason,'UNQUALIFIED_PROFILE');
   await page.getByRole('searchbox',{name:'Search documentation',exact:true}).fill('marzipanprivate');await page.getByRole('button',{name:'Search',exact:true}).click();await page.waitForFunction(()=>document.querySelector('[data-raveldex-status]')?.textContent==='No results.');
   await page.getByRole('button',{name:'Close search',exact:true}).click();assert.equal(await page.locator('[data-authored-fallback]').count(),1);await page.getByRole('button',{name:'Unload search data',exact:true}).click();await page.locator('body[data-search-state="unloaded"]').waitFor();
   await page.getByRole('link',{name:'Atomic publication',exact:true}).click();assert.equal(new URL(page.url()).pathname,base+'guide/atomic/');assert.deepEqual(pageErrors,[]);
   observations.push({name:'Exact README isolated Astro build/preview',base,url,recordCount:3,atomicTotal:1,excludedDraftTotal:0,initialInspectorFocus:'Close Inspector',escapeFocus:'Inspect results',nativeRefusal:native.reason,authoredFallbackRestored:true,unloaded:true,navigatedPath:new URL(page.url()).pathname,pageErrors,previewCommand:lines[1],previewLifecycle:'Explicit documented --background start and root-scoped preview stop',previewLog:log});await page.close();
  }finally{await run(fixtureSh[2]);}
 }
}catch(e){errors.push({message:e.message,stack:e.stack});throw e;}finally{await browser?.close();if(server&&server.exitCode===null)server.kill('SIGTERM');const report={kind:'raveldex-public-docs-follow-instructions-v1',status:errors.length?'Fail':'Pass',environment:{node:process.version,platform:process.platform,arch:process.arch},commands,observations,errors,scope:'Exact documented shell/JavaScript snippets with actual artifact paths; one installed Chrome automation, not human speech/physical input/AT/memory qualification. No tracked code or package metadata edits.'};await fs.writeFile(path.join(stage,'follow-instructions.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,observations:observations.length,errors}));}
