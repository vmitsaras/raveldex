from pathlib import Path
import json
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');d=json.loads((r/'cohort-summary.json').read_text());text=(r/'EVIDENCE-draft.md').read_text();lines=['| Configuration | Records | Codec operation | V5 high-water bytes (n=1) | V6 high-water bytes |','| --- | ---: | --- | ---: | --- |']
for key in sorted(set((x['mode'],x['size'],x['format'],x['role'])for x in d['rows'])):
 groups=[x for x in d['groups']if (x['mode'],x['size'],x['format'],x['role'])==key];cells=[]
 for prefix in ['5f9567','a8ef6a']:
  g=[x for x in groups if x['runtimeSha256'].startswith(prefix)]
  if not g:cells.append('—');continue
  assert len(g)==1;v=g[0]['metrics']['mutator_occupied_high_water_bytes']['values'];cells.append(', '.join(f'{n:,}'for n in v)+(f' (n={len(v)})' if prefix=='a8ef6a'else''))
 mode='Positions/original offsets'if key[0]=='positions-offsets'else'Source/phrase';op=('Export'if key[3]=='producer'else'Restore')+' '+key[2];lines.append(f'| {mode} | {key[1]:,} | {op} | {cells[0]} | {cells[1]} |')
section='''## Completed codec observations

All **39 actual windows** are fully replayed: **37 valid, two invalid/null**. The selected **36 logical windows** span source and native export/restore with source/phrase providers and native export/restore with positions/original offsets, at 1,000/10,000 records and three logical repetitions. Of these, 33 operations pass and three source-format 10,000-record restores reject with `DEADLINE_EXCEEDED`, preserve exact prior state and dispose normally. Their valid metrics describe rejected operations, not successful receiving rebuilds. The extra valid V5 positions restore and both invalid attempts are separately retained. All 19 distinct exported bodies pass the independent full literal checker. Six representative 1,000-record operation/configuration cells also agree with full Python replay; the C++ replay covers every actual window.

The exact V5 executable is `5f9567dbd6d6cf10c0deafa7f6779f81b68265831e14edd7049a86f211fbd843`; V6 is `a8ef6afd3a4773082c6905239780c9a1dd66ec050666c178251e74004262ebf8`. These are distinct native profiles. Most cells have one V5 and two V6 observations; large positions has three selected V6 observations. The [summary](RX-4002-gc-shrink-summary-20261028.json) keeps 22 groups separated by executable digest, extent capacity and stream budget. There is no single three-sample same-binary distribution across profiles.

'''+ '\n'.join(lines)+'''

The large source-format restore row contains deadline refusals. Variation in occupied high-water is not an output-size or leak diagnosis. Gross births, trims, reclaimed bytes, Stop occupation, GC counts, raw identities and per-window outcomes are preserved in the summary and independently bound replay. Later positions exports record native diagnostic maxima of 1,005,980 extent-map nodes; those counters are not relabeled as independently reconstructed byte metrics.

## Lossless evidence

The 39 raw streams contain **4,078,756,563 complete emitted records / 49,385,850,374 bytes**, including invalid attempts. All bytes are retained through **391 contiguous parts in 127 archives**, totaling **6,735,957,384 compressed bytes**. Each archive is below 100 MiB; every part is at most 128 MiB. The [raw index](RX-4002-gc-shrink-raw-index-20261028.json) binds archive/member/offset/full-stream hashes. Native/event byte measurements and archive storage volumes are different quantities.

Compression uses three initial XZ preset-6 archives and subsequent preset-0 archives. A measured offline lossless storage control verifies exact decompressed bytes; switching compression changes no event or raw byte. The owned archiver is interrupted with child cleanup; a separate resumed stderr-name collision refuses before compression. Both receipts, partial/unqualified outputs and source versions remain preserved. Standard container verification retains its 256 MiB member, 1 GiB aggregate and path/regular-file/manifest/digest guards. Reconstruction explicitly admits up to 64 streams, 64 GiB aggregate, 8 GiB per stream and 64 contiguous parts per stream; defaults of the numerical auditor remain 256 MiB, with explicit larger choices through 8 GiB. Every variant/profile/cap is reported.

'''
text=text.replace('## Browser native capability',section+'## Browser native capability');(r/'EVIDENCE-ready.md').write_text(text)
print('Rendered actual codec matrix/evidence, awaiting final archive/native review bindings')
