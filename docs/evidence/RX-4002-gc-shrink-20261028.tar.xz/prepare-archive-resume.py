from pathlib import Path
import json,hashlib,shutil
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');d=Path('/Users/vasilis/Documents/GitHub/raveldex/docs/evidence');state=json.loads((r/'raw-index-progress.json').read_text());accepted={Path(x['path']).name for x in state['archives']};rejected=[]
for p in sorted(d.glob('RX-4002-gc-shrink-raw-*-20261028.tar.xz')):
 if p.name not in accepted:
  target=r/'archive-compression-interrupted'/p.name;target.parent.mkdir(exist_ok=True);shutil.move(p,target);rejected.append({'name':str(target.relative_to(r)),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'status':'Interrupted compression output; unqualified archive, original raw unchanged'})
(r/'archive-compression-interruption.json').write_text(json.dumps({'ownedPid':61326,'signal':'SIGINT','archiverExit':130,'preservedAccepted':sorted(accepted),'unqualifiedOutputs':rejected,'reason':'Switch remaining lossless archive compression from preset6 to preset0 after measured storage control; no raw event or byte changed.'},indent=2)+'\n')
t=(r/'archive-raw-live.py').read_text().replace("'raw-index-progress.json'", "'raw-index-progress-v2.json'").replace("'-6','-c'", "'-0','-c'").replace('512*1024**2','384*1024**2')
init="""initial=json.loads((R/'raw-index-progress.json').read_text());streams=initial['streams'];parts=[];pending=[];archives=initial['archives'];seen=set();started=time.time()
accepted={Path(x['path']).name for x in archives}
for archive in archives:
 path=repo/archive['path'];assert path.stat().st_size==archive['bytes']and sha(path)==archive['sha256']
for row in streams:
 raw=R/row['name'];assert raw.stat().st_size==row['bytes']and sha(raw)==row['sha256'];seen.add(str(raw.resolve()))
 for part in row['parts']:
  part['path']=raw;parts.append(part)
  if part.get('archive')not in accepted:part.pop('archive',None);pending.append(part)
"""
t=t.replace('streams=[];parts=[];pending=[];archives=[];seen=set();started=time.time()',init)
(r/'archive-raw-live-v2.py').write_text(t)
