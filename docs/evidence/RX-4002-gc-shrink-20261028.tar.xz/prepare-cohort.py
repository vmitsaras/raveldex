from pathlib import Path
import shutil
old=Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/run-codecs.py')
root=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H')
t=old.read_text().replace("root=pathlib.Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn')", "root=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H')")
t=t.replace("runtime=pathlib.Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc/node-gc-v3')", "runtime=pathlib.Path(sys.argv[1])")
t=t.replace("mode,rawsize,format,runid=sys.argv[1:]", "expected_runtime_sha=sys.argv[2]\nmode,rawsize,format,runid=sys.argv[3:]")
t=t.replace("assert sha(runtime)=='ad443b2a6fc8092abeeb3ae8c6405e101cf15fc531f05eb769da4707d5154ae0'", "assert len(expected_runtime_sha)==64 and sha(runtime)==expected_runtime_sha")
(root/'run-codecs.py').write_text(t)
# Literal checker copy retains all invariants except explicit runtime-derived profile binding.
t=Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/review/literal-codec-audit.py').read_text()
t=t.replace("ROOT=pathlib.Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn')", "ROOT=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H')")
t=t.replace("'rx4002-gc-ad443b2a6fc8-ascii-v1'", "'rx4002-gc-'+host['runtimeSha256'][:12]+'-ascii-v2'")
(root/'literal-codec-audit.py').write_text(t)
