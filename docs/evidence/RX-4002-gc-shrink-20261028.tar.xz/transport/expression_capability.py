"""Opt-in top-level expression probe. Import performs no target expression.
The controlled call is the byte-verified read-only size quantizer, not allocation.
Native call execution and the one permitted continuation stay at LLDB prompt.
"""
import hashlib,json,pathlib,time
import lldb
import lldb_native_tap as rx
ROOT=pathlib.Path(__file__).resolve().parent
OFFSET=0x9f734
PROBE=None
ENTRY_BP=None
RETURN_BP=None

class Probe:
    def __init__(self,pid,tid,base,root,size):
        if not all(type(v) is int and 0<v<2**53 for v in (pid,tid,base,root)) or size not in (129,130):raise ValueError('Invalid probe context')
        self.pid,self.tid,self.base,self.root,self.size=pid,tid,base,root,size
        self.phase='Armed';self.continues=0;self.entry=None;self.returned=None;self.reason=None;self.rows=[]
    def record(self,kind,**fields):
        if len(self.rows)>=16:raise ValueError('Probe row bound')
        self.rows.append(dict(seq=len(self.rows)+1,kind=kind,**fields))
    def refuse(self,reason):
        self.phase='Refused';self.reason=reason;return True
    def hit_entry(self,context):
        if self.phase!='Armed':return self.refuse('Unexpected or duplicate entry')
        if context['pid']!=self.pid or context['tid']!=self.tid or context['pc']!=self.base+OFFSET or context['root']!=self.root or context['size']!=self.size:return self.refuse('Entry identity mismatch')
        if not all(type(context[k]) is int and 0<context[k]<2**53 for k in ('sp','lr')) or context['sp']%16 or context['lr']%4:return self.refuse('Invalid entry frame')
        self.entry=dict(context);self.record('probe-entry',**context);self.phase='Entry';return True
    def authorize_continue(self,context):
        if self.phase!='Entry' or self.continues:return self.refuse('Continuation not authorized')
        if any(context[k]!=self.entry[k] for k in ('pid','tid','pc','sp','lr')):return self.refuse('Stopped entry changed')
        self.continues=1;self.phase='ContinuationAuthorized';self.record('one-top-level-continuation-authorized');return False
    def hit_return(self,context):
        if self.phase!='ContinuationAuthorized' or self.continues!=1:return self.refuse('Return without authorized continuation')
        if context['pid']!=self.pid or context['tid']!=self.tid or context['pc']!=self.entry['lr'] or context['sp']!=self.entry['sp']:return self.refuse('Return frame mismatch')
        if not 130<=context['value']<=4096:return self.refuse('Quantizer result outside admitted range')
        self.returned=dict(context);self.record('probe-return',**context);self.phase='Returned';return False
    def accept_readback(self,value):
        if self.phase!='Returned' or type(value) is not int or value!=self.returned['value']:raise ValueError('Readback/return mismatch')
        self.record('persistent-expression-readback',value=value);self.phase='Pass'
    def report(self):
        return dict(schema='raveldex-top-level-expression-capability-v1',phase=self.phase,reason=self.reason,pid=self.pid,tid=self.tid,base=self.base,root=self.root,requested=self.size,continues=self.continues,entry=self.entry,returned=self.returned,rows=self.rows,nativeAllocationPerformed=False,scope='Controlled quantizer entry/return and LLDB continuation only; not allocation/in-place/copy/physical memory qualification')

def context(frame):
    thread=frame.GetThread()
    return dict(pid=thread.GetProcess().GetProcessID(),tid=thread.GetThreadID(),pc=frame.GetPC(),sp=rx.reg(frame,'sp'),lr=rx.reg(frame,'lr'))
def selected(debugger):return debugger.GetSelectedTarget().GetProcess().GetSelectedThread().GetFrameAtIndex(0)
def guarded(debugger):
    if not rx.INSTALLED or not rx.ACTIVE or rx.INVALID or rx.DROPPED or rx.LABEL!='expression-capability':raise RuntimeError('Observer must be valid active dedicated expression-capability window')
    if any(rx.CALLS.values()) or rx.LIVE:raise RuntimeError('Observer must be drained')
    process=debugger.GetSelectedTarget().GetProcess()
    if process.GetProcessID()!=rx.CONFIG['pid'] or process.GetState()!=lldb.eStateStopped:raise RuntimeError('Wrong paused owned renderer')
    frame=selected(debugger)
    if frame.GetThread().GetThreadID()!=rx.CONFIG['mainTid']:raise RuntimeError('Wrong trace-proven main thread')
    return frame

def callback(frame,bp_loc,internal_dict):
    global RETURN_BP
    if PROBE is None:return False
    try:
        if frame.GetPC()==PROBE.base+OFFSET:
            c=context(frame);c.update(root=rx.reg(frame,'x0'),size=rx.reg(frame,'x1'))
            stop=PROBE.hit_entry(c)
            if PROBE.phase=='Entry':
                RETURN_BP=rx.TARGET.BreakpointCreateByAddress(c['lr'])
                if RETURN_BP.GetNumLocations()!=1:raise RuntimeError('Unresolved quantizer return')
                error=RETURN_BP.SetScriptCallbackFunction('expression_capability.callback')
                if isinstance(error,lldb.SBError) and error.Fail():raise RuntimeError(error.GetCString())
            return stop
        c=context(frame);c['value']=rx.reg(frame,'x0');return PROBE.hit_return(c)
    except Exception as error:return PROBE.refuse(type(error).__name__+':'+str(error))

def arm(debugger,command,result,internal_dict):
    global PROBE,ENTRY_BP
    try:
        if PROBE is not None or ENTRY_BP is not None:raise RuntimeError('Single probe per fresh observer session')
        if command.strip()!='129':raise RuntimeError('Explicit requested129 required')
        frame=guarded(debugger)
        roots={row['root'] for row in rx.ROWS if row['kind']=='realloc-enter'}
        if len(roots)!=1:raise RuntimeError('One freshly observed serializer root required')
        manifest=json.loads((ROOT/'hook-manifest.json').read_text());site=manifest['sites']['pa_quantize'];expected=bytes.fromhex(site['bytes_hex']);error=lldb.SBError()
        raw=rx.TARGET.GetProcess().ReadMemory(rx.BASE+OFFSET,len(expected),error)
        if error.Fail() or raw!=expected:raise RuntimeError('Quantizer byte fingerprint mismatch')
        root=roots.pop();PROBE=Probe(rx.CONFIG['pid'],rx.CONFIG['mainTid'],rx.BASE,root,129)
        ENTRY_BP=rx.TARGET.BreakpointCreateByAddress(rx.BASE+OFFSET)
        if ENTRY_BP.GetNumLocations()!=1:raise RuntimeError('Unresolved quantizer entry')
        error=ENTRY_BP.SetScriptCallbackFunction('expression_capability.callback')
        if isinstance(error,lldb.SBError) and error.Fail():raise RuntimeError(error.GetCString())
        expression='expression --ignore-breakpoints false --unwind-on-error false --all-threads false --timeout 5000000 --language c++ -- unsigned long $rx_quant129 = ((unsigned long(*)(unsigned long,unsigned long))%d)(%d,129)'%(rx.BASE+OFFSET,root)
        result.PutCString(json.dumps(dict(action='Issue exactly once at top-level prompt',expression=expression,scope=PROBE.report())))
    except Exception as error:
        if PROBE is not None:PROBE.refuse(str(error))
        result.SetError(str(error))
def authorize(debugger,command,result,internal_dict):
    try:
        if command.strip()!='one-top-level-continue' or PROBE is None:raise RuntimeError('Explicit one-top-level-continue required')
        frame=guarded(debugger)
        if PROBE.authorize_continue(context(frame)):raise RuntimeError(PROBE.reason)
        result.PutCString('RX_PROBE_ONE_CONTINUE_AUTHORIZED; issue top-level continue exactly once')
    except Exception as error:
        if PROBE is not None:PROBE.refuse(str(error))
        result.SetError(str(error))
def status(debugger,command,result,internal_dict):
    result.PutCString(json.dumps(PROBE.report() if PROBE else dict(phase='Not armed')))
def readback(debugger,command,result,internal_dict):
    try:
        if PROBE is None or not command.strip().isdecimal():raise RuntimeError('Supply literal unsigned result from separate top-level static readback')
        guarded(debugger);PROBE.accept_readback(int(command));result.PutCString(json.dumps(PROBE.report()))
    except Exception as error:
        if PROBE is not None:PROBE.refuse(str(error))
        result.SetError(str(error))
def save(debugger,command,result,internal_dict):
    try:
        if PROBE is None or command.strip()!='new-receipt':raise RuntimeError('Require explicit new-receipt')
        receipt=PROBE.report();receipt.update(probeSha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),observerSha256=hashlib.sha256((ROOT/'lldb_native_tap.py').read_bytes()).hexdigest(),savedUnix=time.time())
        path=rx.OUT/'expression-capability.json'
        with path.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
        result.PutCString('RX_PROBE_RECEIPT '+str(path))
    except Exception as error:result.SetError(str(error))
def cleanup(debugger,command,result,internal_dict):
    global ENTRY_BP,RETURN_BP
    for bp in (ENTRY_BP,RETURN_BP):
        if bp is not None:rx.TARGET.BreakpointDelete(bp.GetID())
    ENTRY_BP=RETURN_BP=None;result.PutCString('RX_PROBE_HOOKS_REMOVED')
def __lldb_init_module(debugger,internal_dict):
    for name,fn in [('rx-probe-arm','arm'),('rx-probe-authorize','authorize'),('rx-probe-status','status'),('rx-probe-readback','readback'),('rx-probe-save','save'),('rx-probe-cleanup','cleanup')]:debugger.HandleCommand('command script add -f expression_capability.'+fn+' '+name)
