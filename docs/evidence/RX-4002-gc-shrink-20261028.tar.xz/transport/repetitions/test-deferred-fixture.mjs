import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { test } from 'node:test';
import { recordsFor, schema } from './cost-fixture.mjs';
const source = (await readFile(new URL('./message-fixture.mjs', import.meta.url), 'utf8')).replace(/^import .*\n/gm, '');

async function harness({ reject = false, corrupt = false } = {}) {
  let revision = 0, prior = false, exported, restores = 0, parses = 0, allowParse = false, disposed = false;
  const deadlines = [];
  const engine = {
    async addMany(records, options) { deadlines.push(options.deadlineMs); revision++; },
    async clear(options) { deadlines.push(options.deadlineMs); revision++; prior = true; },
    async add(record, options) { deadlines.push(options.deadlineMs); revision++; },
    async search(query, options) { deadlines.push(options.deadlineMs); return { revision, model: 'raveldex-bm25-v1', completeness: 'complete', total: 1, hits: [{ id: 'prior', score: 0 }] }; },
    async dispose() { disposed = true; },
  };
  const snapshots = {
    async exportSource(options) {
      deadlines.push(options.deadlineMs);
      const records = recordsFor(1000).map(r => ({ ...r, text: { body: [r.text.body] } }));
      if (corrupt) records[999].text.body[0] = 'wrong';
      exported = JSON.stringify({ format: 'raveldex-source', body: { header: { originRevision: revision }, payload: { records } } });
      return exported;
    },
    async restore(value, options) {
      deadlines.push(options.deadlineMs); assert.equal(value, exported); restores++;
      if (reject) throw Object.assign(new Error('deadline'), { code: 'DEADLINE_EXCEEDED', name: 'RaveldexError' });
      revision++; return { format: 'raveldex-source', reindexed: true, originRevision: 4, revision };
    },
  };
  const localJSON = { stringify: JSON.stringify, parse(value) { parses++; assert.ok(allowParse, 'No full JSON.parse before detach-gated literal phase'); return JSON.parse(value); } };
  const window = {};
  vm.runInNewContext(source, { window, Worker: class {}, JSON: localJSON, recordsFor, schema,
    observeMessages: () => ({ endpoint: {}, snapshot: () => ({}) }),
    createWorkerRaveldex: async () => engine, createWorkerSnapshots: () => snapshots,
    createSourceProvider: () => ({}), createSourcePhrases: () => ({}) });
  await window.messageControl.ready();
  return { api: window.messageControl, stats: () => ({ restores, parses, disposed, deadlines }), detach: () => { allowParse = true; } };
}

test('deferred successful restore uses same immutable string; dispose retains it for one literal verification', async () => {
  const h = await harness(); await h.api.build(1000);
  const exported = await h.api.run('export'); assert.equal(exported.literalAllExportedValues, false); assert.equal(h.stats().parses, 0);
  assert.throws(() => h.api.verifyExport(), /completed dispose/);
  await h.api.run('prior'); assert.equal((await h.api.run('restore')).publicOutcome, 'Pass');
  await h.api.run('dispose'); assert.equal(h.stats().disposed, true); assert.equal(h.stats().parses, 0);
  h.detach(); const verified = h.api.verifyExport(); assert.equal(verified.literalAllExportedValues, true); assert.equal(verified.originRevision, 4); assert.equal(verified.records, 1000);
  assert.equal(h.stats().restores, 1); assert.equal(h.stats().parses, 1); assert.ok(h.stats().deadlines.every(d => d === 60000));
  assert.throws(() => h.api.verifyExport(), /one held export/);
});

test('typed restore deadline preserves exact prior result and held export still verifies', async () => {
  const h = await harness({ reject: true }); await h.api.build(1000); await h.api.run('export'); await h.api.run('prior');
  const result = await h.api.run('restore'); assert.equal(result.publicOutcome, 'Rejected'); assert.equal(result.error.code, 'DEADLINE_EXCEEDED'); assert.equal(result.priorStatePreserved, true);
  await h.api.run('dispose'); h.detach(); assert.equal(h.api.verifyExport().literalAllExportedValues, true);
});

test('deferred checking still rejects corrupt final record', async () => {
  const h = await harness({ corrupt: true }); await h.api.build(1000); await h.api.run('export'); await h.api.run('prior'); await h.api.run('restore'); await h.api.run('dispose'); h.detach();
  assert.throws(() => h.api.verifyExport(), /Literal exported record mismatch/);
});

test('second export refuses without overwriting held restore input', async () => {
  const h = await harness(); await h.api.build(1000); await h.api.run('export'); await assert.rejects(h.api.run('export'), /Only one immutable export/);
  await h.api.run('prior'); assert.equal((await h.api.run('restore')).publicOutcome, 'Pass');
});
