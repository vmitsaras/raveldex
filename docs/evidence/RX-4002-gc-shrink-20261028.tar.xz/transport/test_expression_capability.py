import sys,types,unittest,json
sys.modules['lldb']=types.SimpleNamespace()
sys.modules['lldb_native_tap']=types.SimpleNamespace()
from expression_capability import Probe,OFFSET
class State(unittest.TestCase):
 def setUp(self):
  self.p=Probe(1,2,0x100000,0x800000,129);self.entry=dict(pid=1,tid=2,pc=0x100000+OFFSET,sp=0x4000,lr=0x5000,root=0x800000,size=129)
 def enter(self):self.assertTrue(self.p.hit_entry(self.entry));self.assertEqual(self.p.phase,'Entry')
 def authorized(self):self.enter();self.assertFalse(self.p.authorize_continue(self.entry))
 def returned(self):self.authorized();self.assertFalse(self.p.hit_return(dict(pid=1,tid=2,pc=0x5000,sp=0x4000,lr=0x5000,value=136)))
 def test_exact_context_then_single_continue_return_and_readback(self):
  self.returned();self.p.accept_readback(136);self.assertEqual(self.p.phase,'Pass');self.assertEqual(self.p.continues,1);self.assertFalse(self.p.report()['nativeAllocationPerformed']);self.assertEqual(len(self.p.rows),4)
 def test_wrong_pid_tid_pc_root_size_refuse(self):
  for key in ['pid','tid','pc','root','size']:
   with self.subTest(key=key):
    p=Probe(1,2,0x100000,0x800000,129);self.assertTrue(p.hit_entry({**self.entry,key:self.entry[key]+1}));self.assertEqual(p.phase,'Refused')
 def test_bad_stack_or_link_alignment_refuse(self):
  for key in ['sp','lr']:
   p=Probe(1,2,0x100000,0x800000,129);p.hit_entry({**self.entry,key:self.entry[key]+1});self.assertEqual(p.phase,'Refused')
 def test_no_callback_never_authorizes_continue(self):self.p.authorize_continue(self.entry);self.assertEqual(self.p.phase,'Refused');self.assertEqual(self.p.continues,0)
 def test_duplicate_entry_refuses(self):self.enter();self.p.hit_entry(self.entry);self.assertEqual(self.p.phase,'Refused')
 def test_changed_stop_refuses_continuation(self):self.enter();self.p.authorize_continue({**self.entry,'pc':0xdead});self.assertEqual(self.p.phase,'Refused');self.assertEqual(self.p.continues,0)
 def test_second_continue_refuses(self):self.authorized();self.p.authorize_continue(self.entry);self.assertEqual(self.p.phase,'Refused');self.assertEqual(self.p.continues,1)
 def test_return_before_authorized_refuses(self):self.enter();self.p.hit_return(dict(pid=1,tid=2,pc=0x5000,sp=0x4000,value=136));self.assertEqual(self.p.phase,'Refused')
 def test_wrong_return_frame_refuses(self):
  for key in ['pid','tid','pc','sp']:
   self.setUp();self.authorized();c=dict(pid=1,tid=2,pc=0x5000,sp=0x4000,value=136);c[key]+=1;self.p.hit_return(c);self.assertEqual(self.p.phase,'Refused')
 def test_invalid_result_refuses(self):self.authorized();self.p.hit_return(dict(pid=1,tid=2,pc=0x5000,sp=0x4000,value=0));self.assertEqual(self.p.phase,'Refused')
 def test_readback_without_native_return_refuses(self):
  with self.assertRaises(ValueError):self.p.accept_readback(136)
 def test_readback_mismatch_refuses(self):
  self.returned()
  with self.assertRaises(ValueError):self.p.accept_readback(137)
 def test_context_or_size_outside_bounds_refuses(self):
  for values in [(True,2,0x100000,0x800000,129),(1,2,0,0x800000,129),(1,2,0x100000,0x800000,131)]:
   with self.assertRaises(ValueError):Probe(*values)
if __name__=='__main__':unittest.main(verbosity=2)
