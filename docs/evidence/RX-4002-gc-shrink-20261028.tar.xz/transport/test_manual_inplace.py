import sys,types,unittest
sys.modules['lldb']=types.SimpleNamespace();sys.modules['lldb_native_tap']=types.SimpleNamespace()
from manual_inplace import Call,Suite,KINDS,OFFSETS,BRANCH
class Calls(unittest.TestCase):
 def setUp(self):self.origin=dict(pid=1,tid=2,pc=0x7000,sp=0x8000)
 def call(self,kind):return Call(kind,1,2,0x100000,0x800000,0xa00000,0x900000,self.origin)
 def entry(self,c):return dict(pid=1,tid=2,pc=c.base+OFFSETS[c.kind],sp=0x4000,lr=0x5000,args=c.args(),ownBreakpointHit=True)
 def branch(self,c):return dict(pid=1,tid=2,pc=c.base+BRANCH,sp=0x4000-192,lr=c.base+BRANCH,ownBreakpointHit=True,branchArgs=dict(result=1,old=c.pointer,requested=130,callerRoot=c.root,slotRoot=c.root))
 def returned(self,c,value=136):return dict(pid=1,tid=2,pc=0x5000,sp=0x4000,lr=0x5000,value=value,ownBreakpointHit=True)
 def exercise(self,c,value):
  e=self.entry(c);c.entry_at(e);c.authorize(e,'native')
  if c.kind=='realloc':b=self.branch(c);c.branch_at(b);c.authorize(b,'branch')
  r=self.returned(c,value);c.return_at(r);c.native_readback(value);c.authorize(r,'jit');c.complete_at({**self.origin,'expressionPlanComplete':True});c.persistent_readback(1 if c.kind=='free' else value)
 def test_all_five_literal_paths_have_exact_bounds(self):
  for kind,value in [('q129',136),('q130',136),('alloc',0x900000),('realloc',0x900000),('free',0)]:
   with self.subTest(kind=kind):
    c=self.call(kind);self.exercise(c,value);self.assertEqual(c.phase,'Pass');self.assertEqual(c.continues,3 if kind=='realloc' else 2)
 def test_wrong_entry_args_pid_tid_pc_refuse(self):
  for key in ['args','pid','tid','pc','ownBreakpointHit']:
   c=self.call('alloc');e=self.entry(c);e[key]=[c.root,130,c.typeptr] if key=='args' else False if key=='ownBreakpointHit' else e[key]+1
   with self.subTest(key=key),self.assertRaises(ValueError):c.entry_at(e)
 def test_entry_sp_lr_malformed_refuse(self):
  for key in ['sp','lr']:
   c=self.call('alloc');e=self.entry(c);e[key]+=1
   with self.assertRaises(ValueError):c.entry_at(e)
 def test_no_entry_no_continue(self):
  c=self.call('alloc')
  with self.assertRaises(ValueError):c.authorize(self.entry(c),'native')
 def test_changed_entry_and_second_continue_refuse(self):
  c=self.call('alloc');e=self.entry(c);c.entry_at(e)
  with self.assertRaises(ValueError):c.authorize({**e,'sp':0x9000},'native')
  c.authorize(e,'native')
  with self.assertRaises(ValueError):c.authorize(e,'native')
 def test_realloc_return_without_branch_refuses(self):
  c=self.call('realloc');e=self.entry(c);c.entry_at(e);c.authorize(e,'native')
  with self.assertRaises(ValueError):c.return_at(self.returned(c,c.pointer))
 def test_branch_false_moved_pointer_wrong_root_size_or_sp_refuse(self):
  for key in ['result','old','requested','callerRoot','slotRoot','sp']:
   c=self.call('realloc');e=self.entry(c);c.entry_at(e);c.authorize(e,'native');b=self.branch(c)
   if key=='sp':b[key]+=16
   else:b['branchArgs'][key]+=1
   with self.subTest(key=key),self.assertRaises(ValueError):c.branch_at(b)
 def test_return_wrong_context_and_moved_pointer_refuse(self):
  for key in ['pid','tid','pc','sp','value','ownBreakpointHit']:
   c=self.call('realloc');e=self.entry(c);c.entry_at(e);c.authorize(e,'native');b=self.branch(c);c.branch_at(b);c.authorize(b,'branch');r=self.returned(c,c.pointer);r[key]=False if key=='ownBreakpointHit' else r[key]+1
   with self.subTest(key=key),self.assertRaises(ValueError):c.return_at(r)
 def test_jit_continue_without_native_return_or_readback_refuses(self):
  c=self.call('alloc');e=self.entry(c);c.entry_at(e);c.authorize(e,'native');r=self.returned(c,0x900000)
  with self.assertRaises(ValueError):c.authorize(r,'jit')
  c.return_at(r)
  with self.assertRaises(ValueError):c.authorize(r,'jit')
 def test_persistent_readback_before_original_plancomplete_refuses(self):
  c=self.call('alloc');e=self.entry(c);c.entry_at(e);c.authorize(e,'native');r=self.returned(c,0x900000);c.return_at(r);c.native_readback(0x900000);c.authorize(r,'jit')
  with self.assertRaises(ValueError):c.persistent_readback(0x900000)
  with self.assertRaises(ValueError):c.complete_at({**self.origin,'expressionPlanComplete':False})
  with self.assertRaises(ValueError):c.complete_at({**self.origin,'sp':0x8008,'expressionPlanComplete':True})
 def test_free_void_return_does_not_claim_return_pointer(self):
  c=self.call('free');self.exercise(c,0x812345);self.assertEqual(c.phase,'Pass');self.assertEqual(c.rows[-1]['value'],1)
 def test_unqualified_control_pointer_refuses(self):
  with self.assertRaises(ValueError):Call('free',1,2,0x100000,0x800000,0xa00000,None,self.origin)
class Ordered(unittest.TestCase):
 setUp=Calls.setUp
 entry=Calls.entry
 branch=Calls.branch
 returned=Calls.returned
 def test_suite_five_calls_retains_one_birth_generation_and_drains_pointer(self):
  s=Suite(1,2,0x100000,0x800000)
  for kind,value in [('q129',136),('q130',136),('alloc',0x900000),('realloc',0x900000),('free',0)]:
   c=s.new(kind,self.origin);e=self.entry(c);c.entry_at(e);c.authorize(e,'native')
   if kind=='realloc':b=self.branch(c);c.branch_at(b);c.authorize(b,'branch')
   r=self.returned(c,value);c.return_at(r);c.native_readback(value);c.authorize(r,'jit');c.complete_at({**self.origin,'expressionPlanComplete':True});s.finish(1 if kind=='free' else value)
  self.assertEqual(s.phase,'Pass');self.assertIsNone(s.pointer);self.assertEqual(s.generation,1);self.assertEqual(s.report()['totalContinues'],11);self.assertFalse(s.report()['autoObserverCallbackQualification'])
  with self.assertRaises(ValueError):s.new('q129',self.origin)
 def test_suite_cannot_skip_or_overlap_calls(self):
  s=Suite(1,2,0x100000,0x800000)
  with self.assertRaises(ValueError):s.new('alloc',self.origin)
  s.new('q129',self.origin)
  with self.assertRaises(ValueError):s.new('q130',self.origin)
if __name__=='__main__':unittest.main(verbosity=2)
