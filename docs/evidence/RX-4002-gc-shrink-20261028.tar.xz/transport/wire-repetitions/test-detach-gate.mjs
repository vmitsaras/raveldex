import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { test } from 'node:test';
const url = new URL('./browser-message-observations-900s.mjs', import.meta.url);
const source = await readFile(url, 'utf8');
const start = source.indexOf("      } else if (command.cmd === 'verify-export') {") + "      } else if (command.cmd === 'verify-export') {".length;
const end = source.indexOf("      } else if (command.cmd === 'observation')", start);
assert.ok(start > 0 && end > start);
const body = source.slice(start, end).replaceAll('import.meta.url', JSON.stringify(url.href));

async function gate(change = () => {}) {
  const pid = 123, status = { actualPid: pid, expectedPid: pid, qualified: true, processStopped: true,
    schema: 'raveldex-native-wire-only-stop-status-v1', allBaseBreakpointsEnabled: true, baseRoleAddressesCovered: true, receiverProbes: 'NotInstalled/NotMeasured', unexpectedReceiverModules: [], baseErrors: 0, baseDropped: 0, basePending: 0, baseLive: 0 };
  const data = { host: { targetPid: pid, exitCode: 0, timedOut: false }, status, partial: false, markers: true, calls: 0 };
  change(data);
  const log = 'RX_WIRE_STATUS ' + JSON.stringify(status) + (data.partial ? '' : '\n') +
    (data.markers ? '\nRX_NATIVE_HOOKS_REMOVED\nProcess 123 detached\n' : '');
  const row = {};
  await vm.runInNewContext('(async () => {' + body + '})()', {
    assert: { ...assert, deepEqual: (a, b) => assert.equal(JSON.stringify(a), JSON.stringify(b)) }, join, resolve, fileURLToPath, URL, JSON,
    command: { size: 1000, nativeDirectory: fileURLToPath(new URL('./native-product-1000-wire-repeat-1', url)) },
    realpath: async p => p,
    readFile: async p => p.endsWith('host.json') ? JSON.stringify(data.host) : log,
    fileHash: async () => 'fixture-hash', report: { rendererPid: pid }, row,
    page: { evaluate: async () => { data.calls++; return { literalAllExportedValues: true }; } },
  });
  assert.equal(data.calls, 1); return row.result;
}

test('complete final status and actual detach permit one verifier', async () => assert.equal((await gate()).debuggerDetachedBeforeLiteralVerification, true));
test('debugger failure refuses before verifier', async () => assert.rejects(gate(d => { d.host.exitCode = 1; })));
test('wrong owned PID refuses before verifier', async () => assert.rejects(gate(d => { d.host.targetPid++; })));
test('pending ledger refuses even forged qualified flag', async () => assert.rejects(gate(d => { d.status.basePending = 1; })));
test('incomplete streamed JSON refuses before verifier', async () => assert.rejects(gate(d => { d.partial = true; d.markers = false; })));
test('missing actual hook removal/detach refuses', async () => assert.rejects(gate(d => { d.markers = false; })));
