"""Read-only host status for the unchanged base wire observer only."""
import hashlib
import json
import pathlib
import signal
import sys
import lldb
import lldb_native_tap as rx

ROLES = {'realloc', 'copy', 'root-free', 'internal-free', 'alloc', 'destructor', 'final-free', 'payload-onebyte', 'payload-twobyte'}


def qualify(s):
    failures = []
    if s['actualPid'] != s['expectedPid'] or not s['processStopped']:
        failures.append('Wrong owned PID or process not stopped')
    if not any(t['reason'] == 'signal' and t['signal'] == int(signal.SIGSTOP) for t in s['threads']):
        failures.append('No actual SIGSTOP thread reason')
    ids = {t['tid'] for t in s['threads']}
    if not {s['mainTid'], s['workerTid'], s['selectedTid']} <= ids:
        failures.append('Actual peer/selected threads missing')
    if not s['installed'] or not s['active'] or not s['allBaseBreakpointsEnabled'] or not s['baseRoleAddressesCovered'] or set(s['nativeWireObserverRoles']) != ROLES or len(s['baseRoleAddresses']) != len(ROLES) or not len(ROLES) <= s['baseBreakpointCount'] <= 256:
        failures.append('Exact unchanged base observer not fully armed')
    if s['baseErrors'] or s['baseDropped'] or s['basePending'] or s['baseLive']:
        failures.append('Inherited ledger not complete/drained/valid')
    if s['receiverProbes'] != 'NotInstalled/NotMeasured' or s['unexpectedReceiverModules']:
        failures.append('Unexpected receiver instrumentation in wire-only mode')
    return failures


def status(debugger, command, result, _):
    try:
        if command.strip() != 'owned-sigstop-and-drained':
            raise ValueError('Explicit owned-sigstop-and-drained required')
        process = debugger.GetSelectedTarget().GetProcess()
        count = process.GetNumThreads()
        if not 0 < count <= 128:
            raise ValueError('Thread inventory bound')
        threads = []
        for index in range(count):
            thread = process.GetThreadAtIndex(index)
            reason = thread.GetStopReason()
            sig = thread.GetStopReasonDataAtIndex(0) if reason == lldb.eStopReasonSignal and thread.GetStopReasonDataCount() else None
            threads.append(dict(tid=thread.GetThreadID(), reason='signal' if reason == lldb.eStopReasonSignal else str(reason), signal=sig))
        snapshot = dict(actualPid=process.GetProcessID(), expectedPid=rx.CONFIG['pid'],
                        processStopped=process.GetState() == lldb.eStateStopped,
                        selectedTid=process.GetSelectedThread().GetThreadID(), mainTid=rx.CONFIG['mainTid'], workerTid=rx.CONFIG['workerTid'], threads=threads,
                        installed=rx.INSTALLED, active=rx.ACTIVE,
                        allBaseBreakpointsEnabled=bool(rx.BPS) and all(bp.IsValid() and bp.IsEnabled() and bp.GetNumLocations() == 1 for bp in rx.BPS.values()),
                        baseRoleAddressesCovered=set(rx.ROLES) <= set(rx.BPS), baseBreakpointCount=len(rx.BPS),
                        baseRoleAddresses=[dict(address=a, role=r) for a, r in sorted(rx.ROLES.items())],
                        nativeWireObserverRoles=sorted(set(rx.ROLES.values())),
                        baseErrors=len(rx.INVALID), baseDropped=rx.DROPPED, basePending=sum(len(v) for v in rx.CALLS.values()), baseLive=len(rx.LIVE),
                        receiverProbes='NotInstalled/NotMeasured',
                        unexpectedReceiverModules=[n for n in ('receiver_copy_tap', 'one_byte_receiver_tap') if n in sys.modules])
        failures = qualify(snapshot)
        snapshot.update(schema='raveldex-native-wire-only-stop-status-v1', qualified=not failures, failures=failures,
                        sourceSha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
                        baseObserverSha256=hashlib.sha256(pathlib.Path(rx.__file__).read_bytes()).hexdigest())
        result.PutCString('RX_WIRE_STATUS ' + json.dumps(snapshot))
    except Exception as error:
        result.SetError(str(error))


def __lldb_init_module(debugger, _):
    debugger.HandleCommand('command script add -f wire_status.status rx-wire-status')
