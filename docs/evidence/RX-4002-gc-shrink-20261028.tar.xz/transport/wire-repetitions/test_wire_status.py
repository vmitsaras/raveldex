import ast
from pathlib import Path
import signal
import unittest

source = ast.parse(Path(__file__).with_name('wire_status.py').read_text())
selected = ast.Module(body=[n for n in source.body if isinstance(n, ast.FunctionDef) and n.name == 'qualify'], type_ignores=[])
roles = {'realloc', 'copy', 'root-free', 'internal-free', 'alloc', 'destructor', 'final-free', 'payload-onebyte', 'payload-twobyte'}
scope = {'signal': signal, 'ROLES': roles}
exec(compile(selected, 'wire_status.py', 'exec'), scope)
qualify = scope['qualify']


def fixture():
    return dict(actualPid=5, expectedPid=5, processStopped=True, mainTid=6, workerTid=7, selectedTid=6,
                threads=[dict(tid=6, reason='signal', signal=int(signal.SIGSTOP)), dict(tid=7, reason='1', signal=None)],
                installed=True, active=True, allBaseBreakpointsEnabled=True, nativeWireObserverRoles=sorted(roles),
                baseRoleAddressesCovered=True, baseBreakpointCount=9, baseRoleAddresses=list(range(9)),
                baseErrors=0, baseDropped=0, basePending=0, baseLive=0,
                receiverProbes='NotInstalled/NotMeasured', unexpectedReceiverModules=[])


class Tests(unittest.TestCase):
    def test_valid(self): self.assertEqual(qualify(fixture()), [])
    def test_wrong_pid(self):
        s=fixture();s['actualPid']=8;self.assertTrue(qualify(s))
    def test_not_sigstop(self):
        s=fixture();s['threads'][0]['reason']='breakpoint';self.assertTrue(qualify(s))
    def test_missing_peer(self):
        s=fixture();s['workerTid']=9;self.assertTrue(qualify(s))
    def test_invalid_ledger(self):
        for key in ('baseErrors','baseDropped','basePending','baseLive'):
            s=fixture();s[key]=1;self.assertTrue(qualify(s))
    def test_missing_role(self):
        s=fixture();s['nativeWireObserverRoles'].pop();self.assertTrue(qualify(s))
    def test_disarmed(self):
        s=fixture();s['allBaseBreakpointsEnabled']=False;self.assertTrue(qualify(s))
    def test_receiver_imported(self):
        s=fixture();s['unexpectedReceiverModules']=['receiver_copy_tap'];self.assertTrue(qualify(s))
    def test_receiver_fake_zero(self):
        s=fixture();s['receiverProbes']='0';self.assertTrue(qualify(s))
    def test_missing_role_breakpoint(self):
        s=fixture();s['baseRoleAddressesCovered']=False;self.assertTrue(qualify(s))


if __name__ == '__main__': unittest.main()
