"""Offline receipt builder for completed base-wire-only repetitions."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/vasilis/Documents/GitHub/raveldex')


def load(path): return json.loads(path.read_text())


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


cases = []
for size, sessions in [(1000, dict(controller=21729, debugger=35814)), (10000, dict(controller=71496, debugger=88395))]:
    label = 'product-' + str(size) + '-wire-repeat-1'
    c, n = ROOT / ('controller-' + label), ROOT / ('native-' + label)
    report = load(c / 'report.json')
    raw_path = n / 'tap-2-source-roundtrip.json'
    raw = load(raw_path)
    native = load(n / 'inherited-replay.json')
    capacity = load(n / 'wire-capacity-replay.json')
    host = load(n / 'lldb-observer-host.json')
    install = load(n / 'lldb-install.json')
    assert report['outcome'] == 'Observed actual messages' and report['commandFailures'] == 0
    assert report['preservation'] == 'Pass' and report['ownedBrowserClosed'] and not report['cleanupErrors']
    assert report['observerMode'] == 'NativeWireAPI base observer only; receiver probes NotInstalled/NotMeasured'
    assert host['exitCode'] == 0 and host['timedOut'] is False and host['timeoutSeconds'] == 900
    assert host['targetPid'] == raw['pid'] == report['rendererPid']
    assert not raw['invalid'] and raw['dropped'] == 0 and not raw['pending'] and not raw['remaining']
    assert native['remaining'] == 0 and capacity['status'] == 'BoundedPass'
    assert native['sourceSha256'] == capacity['sourceSha256'] == identity(raw_path)['sha256']
    assert len(report['productionFiles']) == 208
    for item in report['productionFiles']:
        for base in (REPO, Path(report['consumer']) / 'node_modules/@vmitsaras/raveldex', Path(report['stagedDirectory']) / 'node_modules/@vmitsaras/raveldex'):
            assert identity(base / item['path'])['sha256'] == item['sha256']
    for item in report['sources']:
        assert identity(Path(item['source']))['sha256'] == item['sha256']
        if 'target' in item: assert identity(Path(item['target']))['sha256'] == item['sha256']
    log = (n / 'lldb-observer.log').read_text().replace('\r', '')
    statuses = [json.loads(s) for s in re.findall(r'RX_WIRE_STATUS (\{[^\n]*\})\n', log)]
    assert len(statuses) == 2 and all(s['qualified'] for s in statuses)
    last = statuses[-1]
    assert last['receiverProbes'] == 'NotInstalled/NotMeasured' and not last['unexpectedReceiverModules']
    assert last['baseObserverSha256'] == raw['observerSha256'] == identity(ROOT / 'lldb_native_tap.py')['sha256']
    assert last['sourceSha256'] == identity(ROOT / 'wire_status.py')['sha256']
    assert all(last[k] == 0 for k in ('baseErrors', 'baseDropped', 'basePending', 'baseLive'))
    assert last['baseRoleAddressesCovered'] and last['allBaseBreakpointsEnabled']
    expected_roles = dict(alloc=0x1c36c, **{'root-free': 0x1d6d0, 'payload-onebyte': 0x17009b8, 'realloc': 0x17a1190, 'copy': 0x17a173c, 'internal-free': 0x17a244c, 'destructor': 0x19ca0c8, 'final-free': 0x19ca210, 'payload-twobyte': 0x3de04f0})
    assert {r['role']: r['address'] - install['base'] for r in last['baseRoleAddresses']} == expected_roles
    assert not any(s in log for s in ('RX_RECEIVER_READONLY_INSTALLED', 'RX_ONEBYTE_READONLY_INSTALLED'))
    assert 0 <= log.rfind('RX_NATIVE_HOOKS_REMOVED') < log.rfind('Process ' + str(raw['pid']) + ' detached')
    actual_cases = [r for r in report['commands'] if r['command']['cmd'] == 'case']
    assert [r['command']['kind'] for r in actual_cases] == ['export', 'prior', 'restore', 'search', 'dispose']
    verified = [r for r in report['commands'] if r['command']['cmd'] == 'verify-export']
    assert len(verified) == 1
    verified = verified[0]
    value = verified['result']
    assert value['literalAllExportedValues'] and value['sameImmutableExportHeldForRestore'] and value['debuggerDetachedBeforeLiteralVerification'] and value['records'] == size
    assert value['nativeHostSha256'] == identity(n / 'lldb-observer-host.json')['sha256']
    assert value['nativeLogSha256'] == identity(n / 'lldb-observer.log')['sha256']
    assert datetime.fromisoformat(verified['started'].replace('Z', '+00:00')).timestamp() >= host['finishedUnix']
    assert (ROOT / ('owned-' + label + '-after.log')).read_bytes() == b''
    first_dir = ROOT.parent / 'message-observations' / ('native-product-' + str(size) + '-manual-0')
    first = load(first_dir / 'wire-capacity-replay.json')
    assert first['observedRequestedCapacityHighWaterBytes'] == capacity['observedRequestedCapacityHighWaterBytes']
    cases.append(dict(size=size, status='BoundedPass; normal owned completion', toolSessionIds=sessions,
                      browserPid=report['browserPid'], rendererPid=report['rendererPid'], ownedProcessesAbsent=True,
                      publicCases=[dict(kind=r['command']['kind'], result=r['result']) for r in actual_cases],
                      deferredLiteralVerification=value, finalNativeStatus=last,
                      rows=len(raw['rows']), exactNativeFramePairs=native['counts']['native-call-return'], births=native['births'], finalRemaining=native['remaining'],
                      senderStringCopyCalls=native['selectedStringCopyCalls'], senderStringCopiedExtentBytes=native['selectedStringCopyBytes'],
                      receiverProbes='NotInstalled/NotMeasured',
                      requestedWireCapacityHighWaterBytes=capacity['observedRequestedCapacityHighWaterBytes'],
                      firstQualifiedWireObservationHighWaterBytes=first['observedRequestedCapacityHighWaterBytes'],
                      movedGrowthCopies=capacity['movedGrowthCopies'], movedGrowthCopiedExtentBytes=capacity['movedGrowthCopiedExtentBytes'],
                      artifacts=[identity(p) for p in [c / 'report.json', c / 'pid-proof-trace.json', n / 'lldb-install.json', n / 'lldb-observer-host.json', n / 'lldb-observer.log', raw_path, n / 'inherited-replay.json', n / 'wire-capacity-replay.json', ROOT / ('owned-' + label + '-after.log')]]))

result = dict(schema='raveldex-native-wire-second-owner-observations-v1', date='2026-10-28',
              status='Both second native-wire observations completed; final independent10k review binding follows separately',
              quantity='Requested-capacity sum of registered native wire extents at witnessed native frontiers, including actual old/new growth overlap',
              cases=cases,
              sourceChecks='All208 production-file hashes rechecked across repository/installed/staged package and all6 controller source aliases unchanged for both owners.',
              limits=['Same base NativeWireAPI population as the first full-probe observations; optional receiver probes are absent and not claimed repeated.',
                      'Changed telemetry mode and deferred literal verification/held harness string root are explicit; no homogeneous timing or managed-retention cohort claim.',
                      'Two native-wire observations per admitted size are now available; original1k owner timeout and both10k60second restore refusals remain separate outcomes.',
                      'Earlier refused full-probe repetition is preserved, excluded from successful repetitions, and its exact LLDB stop cause remains Unknown.',
                      'No native calls/target expressions/AutoContinue changes/keyreuse/new payload/direct allocator control retry.',
                      'No allocator rounding, global/physical memory, receiver managed lifetime, complete copy traffic or scalar/SIMD store-volume claim.',
                      'Explicit forced CDP collection is not ordinary automatic deletion timing.'],
              preservedEarlierInventories=[identity(ROOT.parent / 'message-observations/final-file-inventory.json'), identity(ROOT.parent / 'repetitions/frozen-file-inventory.json')],
              sourceAliases=[identity(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.suffix in ('.py', '.mjs', '.json', '.md') and p.name not in ('final-wire-observations.json', 'final-file-inventory.json')])
path = ROOT / 'final-wire-observations.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(identity(path)))
