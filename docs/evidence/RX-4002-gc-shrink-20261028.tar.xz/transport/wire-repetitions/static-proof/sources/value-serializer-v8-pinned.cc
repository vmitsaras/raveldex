[chromium](https://chromium.googlesource.com/?format=HTML)/ [v8](https://chromium.googlesource.com/v8/)/ [v8](https://chromium.googlesource.com/v8/v8/)/ [0b60d2b01800d7ba2c6eeb5e51ecd95f6dab44c7](https://chromium.googlesource.com/v8/v8/+/0b60d2b01800d7ba2c6eeb5e51ecd95f6dab44c7)/ [.](https://chromium.googlesource.com/v8/v8/+/0b60d2b01800d7ba2c6eeb5e51ecd95f6dab44c7/)/ [src](https://chromium.googlesource.com/v8/v8/+/0b60d2b01800d7ba2c6eeb5e51ecd95f6dab44c7/src)/ [objects](https://chromium.googlesource.com/v8/v8/+/0b60d2b01800d7ba2c6eeb5e51ecd95f6dab44c7/src/objects)/value-serializer.cc

blob: 1e7ff653c47e2e3a7fd94cae99eb4b99e62e67d3 \[ [file](https://chromium.googlesource.com/v8/v8/+/0b60d2b01800d7ba2c6eeb5e51ecd95f6dab44c7/src/objects/value-serializer.cc)\]

|     |     |
| --- | --- |
|  | // Copyright 2016 the V8 project authors. All rights reserved. |
|  | // Use of this source code is governed by a BSD-style license that can be |
|  | // found in the LICENSE file. |
|  |  |
|  | #include"src/objects/value-serializer.h" |
|  |  |
|  | #include<type\_traits> |
|  |  |
|  | #include"include/v8-maybe.h" |
|  | #include"include/v8-value-serializer-version.h" |
|  | #include"include/v8-value-serializer.h" |
|  | #include"include/v8-wasm.h" |
|  | #include"src/api/api-inl.h" |
|  | #include"src/base/logging.h" |
|  | #include"src/base/platform/memory.h" |
|  | #include"src/execution/isolate.h" |
|  | #include"src/flags/flags.h" |
|  | #include"src/handles/global-handles-inl.h" |
|  | #include"src/handles/handles-inl.h" |
|  | #include"src/handles/maybe-handles-inl.h" |
|  | #include"src/handles/shared-object-conveyor-handles.h" |
|  | #include"src/heap/factory.h" |
|  | #include"src/numbers/conversions.h" |
|  | #include"src/objects/dictionary-inl.h" |
|  | #include"src/objects/heap-number-inl.h" |
|  | #include"src/objects/js-array-buffer-inl.h" |
|  | #include"src/objects/js-array-inl.h" |
|  | #include"src/objects/js-collection-inl.h" |
|  | #include"src/objects/js-regexp-inl.h" |
|  | #include"src/objects/js-shared-array.h" |
|  | #include"src/objects/js-struct.h" |
|  | #include"src/objects/map-updater.h" |
|  | #include"src/objects/object-conversions-inl.h" |
|  | #include"src/objects/objects-inl.h" |
|  | #include"src/objects/oddball-inl.h" |
|  | #include"src/objects/ordered-hash-table-inl.h" |
|  | #include"src/objects/property-descriptor.h" |
|  | #include"src/objects/property-details.h" |
|  | #include"src/objects/smi.h" |
|  | #include"src/objects/transitions-inl.h" |
|  | #include"src/regexp/regexp.h" |
|  | #include"src/snapshot/code-serializer.h" |
|  |  |
|  | #if V8\_ENABLE\_WEBASSEMBLY |
|  | #include"src/wasm/wasm-objects-inl.h" |
|  | #endif// V8\_ENABLE\_WEBASSEMBLY |
|  |  |
|  | namespace v8 { |
|  | namespace internal { |
|  |  |
|  | // WARNING: This serialization format MUST remain backward compatible! |
|  | // |
|  | // This format is used by APIs to persist values to disk, e.g. IndexedDB. |
|  | // |
|  | // Backward compatibility means that when the format changes, deserializing |
|  | // valid values in the older format must behave identically as before the |
|  | // change. To maintain compatibility, either a format change does not affect the |
|  | // deserializing behavior of valid values in the older format, or the |
|  | // kLatestVersion constant is bumped. |
|  | // |
|  | // Adding a new tag is backwards compatible because no valid serialized value in |
|  | // older formats would contain the new object tag. |
|  | // |
|  | // On the other hand, changing the format of a particular tag is backwards |
|  | // incompatible and the version must be bumped. For example, a JSArrayBufferView |
|  | // tag prior to version 14 was followed by the sub-tag, the byte offset, and the |
|  | // byte length. Starting with version 14, a JSArrayBufferView tag is followed by |
|  | // the sub-tag, the byte offset, the byte length, and flags. Due the addition of |
|  | // flags, older valid serialized values for JSArrayBufferViews would be |
|  | // misinterpreted by newer deserializers. This requires the version to be bumped |
|  | // and the deserializer to handle both the old and new formats depending on the |
|  | // version. |
|  |  |
|  | // Version 9: (imported from Blink) |
|  | // Version 10: one-byte (Latin-1) strings |
|  | // Version 11: properly separate undefined from the hole in arrays |
|  | // Version 12: regexp and string objects share normal string encoding |
|  | // Version 13: host objects have an explicit tag (rather than handling all |
|  | // unknown tags) |
|  | // Version 14: flags for JSArrayBufferViews |
|  | // Version 15: support for shared objects with an explicit tag |
|  | // Version 16: don't truncate JSArrayBuffer's and JSArrayBufferView's lengths |
|  | // and offsets to 32-bit values and write full size\_t's instead, |
|  | // make sure deserializer is ready to handle 64-bit values even on |
|  | // 32-bit architectures. Allow serialization of resizable |
|  | // ArrayBuffers with maxByteLength larger than 4GB. |
|  | // |
|  | // WARNING: Increasing this value is a change which cannot safely be rolled |
|  | // back without breaking compatibility with data stored on disk. It is |
|  | // strongly recommended that you do not make such changes near a release |
|  | // milestone branch point. |
|  | // |
|  | // Recent changes are routinely reverted in preparation for branch, and this |
|  | // has been the cause of at least one bug in the past. |
|  | staticconstuint32\_t kLatestVersion =16; |
|  | static\_assert(kLatestVersion == v8::CurrentValueSerializerFormatVersion(), |
|  | "Exported format version must match latest version."); |
|  |  |
|  | namespace{ |
|  | // For serializing JSArrayBufferView flags. Instead of serializing / |
|  | // deserializing the flags directly, we serialize them bit by bit. This is for |
|  | // ensuring backwards compatibility in the case where the representation |
|  | // changes. Note that the ValueSerializer data can be stored on disk. |
|  | usingJSArrayBufferViewIsLengthTracking= base::BitField<bool,0,1>; |
|  | usingJSArrayBufferViewIsBackedByRab= |
|  | JSArrayBufferViewIsLengthTracking::Next<bool,1>; |
|  |  |
|  | }// namespace |
|  |  |
|  | template<typename T> |
|  | staticsize\_tBytesNeededForVarint(T value){ |
|  | static\_assert(std::is\_integral\_v<T>&& std::is\_unsigned\_v<T>, |
|  | "Only unsigned integer types can be written as varints."); |
|  | size\_t result =0; |
|  | do{ |
|  | result++; |
|  | value >>=7; |
|  | }while(value); |
|  | return result; |
|  | } |
|  |  |
|  | enumclassSerializationTag:uint8\_t{ |
|  | // version:uint32\_t (if at beginning of data, sets version > 0) |
|  | kVersion =0xFF, |
|  | // ignore |
|  | kPadding ='\\0', |
|  | // refTableSize:uint32\_t (previously used for sanity checks; safe to ignore) |
|  | kVerifyObjectCount ='?', |
|  | // Oddballs (no data). |
|  | kTheHole ='-', |
|  | kUndefined ='\_', |
|  | kNull ='0', |
|  | kTrue ='T', |
|  | kFalse ='F', |
|  | // Number represented as 32-bit integer, ZigZag-encoded |
|  | // (like sint32 in protobuf) |
|  | kInt32 ='I', |
|  | // Number represented as 32-bit unsigned integer, varint-encoded |
|  | // (like uint32 in protobuf) |
|  | kUint32 ='U', |
|  | // Number represented as a 64-bit double. |
|  | // Host byte order is used (N.B. this makes the format non-portable). |
|  | kDouble ='N', |
|  | // BigInt. Bitfield:uint32\_t, then raw digits storage. |
|  | kBigInt ='Z', |
|  | // byteLength:uint32\_t, then raw data |
|  | kUtf8String ='S', |
|  | kOneByteString ='"', |
|  | kTwoByteString ='c', |
|  | // Reference to a serialized object. objectID:uint32\_t |
|  | kObjectReference ='^', |
|  | // Beginning of a JS object. |
|  | kBeginJSObject ='o', |
|  | // End of a JS object. numProperties:uint32\_t |
|  | kEndJSObject ='{', |
|  | // Beginning of a sparse JS array. length:uint32\_t |
|  | // Elements and properties are written as key/value pairs, like objects. |
|  | kBeginSparseJSArray ='a', |
|  | // End of a sparse JS array. numProperties:uint32\_t length:uint32\_t |
|  | kEndSparseJSArray ='@', |
|  | // Beginning of a dense JS array. length:uint32\_t |
|  | // \|length\| elements, followed by properties as key/value pairs |
|  | kBeginDenseJSArray ='A', |
|  | // End of a dense JS array. numProperties:uint32\_t length:uint32\_t |
|  | kEndDenseJSArray ='$', |
|  | // Date. millisSinceEpoch:double |
|  | kDate ='D', |
|  | // Boolean object. No data. |
|  | kTrueObject ='y', |
|  | kFalseObject ='x', |
|  | // Number object. value:double |
|  | kNumberObject ='n', |
|  | // BigInt object. Bitfield:uint32\_t, then raw digits storage. |
|  | kBigIntObject ='z', |
|  | // String object, UTF-8 encoding. byteLength:uint32\_t, then raw data. |
|  | kStringObject ='s', |
|  | // Regular expression, UTF-8 encoding. byteLength:uint32\_t, raw data, |
|  | // flags:uint32\_t. |
|  | kRegExp ='R', |
|  | // Beginning of a JS map. |
|  | kBeginJSMap =';', |
|  | // End of a JS map. length:uint32\_t. |
|  | kEndJSMap =':', |
|  | // Beginning of a JS set. |
|  | kBeginJSSet ='\\'', |
|  | // End of a JS set. length:uint32\_t. |
|  | kEndJSSet =',', |
|  | // Array buffer. byteLength:uint32\_t, then raw data. |
|  | kArrayBuffer ='B', |
|  | // Immutable array buffer. byteLength:uint32\_t, then raw data. |
|  | kImmutableArrayBuffer ='C', |
|  | // Shared immutable array buffer (zero-copy for postMessage). |
|  | // backingStoreID:uint32\_t |
|  | kSharedImmutableArrayBuffer ='E', |
|  | // Resizable array buffer. byteLength:uint32\_t, maxLength:uint32\_t, raw data. |
|  | kResizableArrayBuffer ='~', |
|  | // Array buffer (transferred). transferID:uint32\_t |
|  | kArrayBufferTransfer ='t', |
|  | // View into an array buffer. |
|  | // subtag:ArrayBufferViewTag, byteOffset:uint32\_t, byteLength:uint32\_t |
|  | // For typed arrays, byteOffset and byteLength must be divisible by the size |
|  | // of the element. |
|  | // Note: kArrayBufferView is special, and should have an ArrayBuffer (or an |
|  | // ObjectReference to one) serialized just before it. This is a quirk arising |
|  | // from the previous stack-based implementation. |
|  | kArrayBufferView ='V', |
|  | // Shared array buffer. transferID:uint32\_t |
|  | kSharedArrayBuffer ='u', |
|  | // A HeapObject shared across Isolates. sharedValueID:uint32\_t |
|  | kSharedObject ='p', |
|  | // A wasm module object transfer. next value is its index. |
|  | kWasmModuleTransfer ='w', |
|  | // The delegate is responsible for processing all following data. |
|  | // This "escapes" to whatever wire format the delegate chooses. |
|  | kHostObject ='\\\', |
|  | // A transferred WebAssembly.Memory object. maximumPages:int32\_t, then by |
|  | // SharedArrayBuffer tag and its data. |
|  | kWasmMemoryTransfer ='m', |
|  | // A list of (subtag: ErrorTag, \[subtag dependent data\]). See ErrorTag for |
|  | // details. |
|  | kError ='r', |
|  |  |
|  | // The following tags are reserved because they were in use in Chromium before |
|  | // the kHostObject tag was introduced in format version 13, at |
|  | // v8 refs/heads/master@{#43466} |
|  | // chromium/src refs/heads/master@{#453568} |
|  | // |
|  | // They must not be reused without a version check to prevent old values from |
|  | // starting to deserialize incorrectly. For simplicity, it's recommended to |
|  | // avoid them altogether. |
|  | // |
|  | // This is the set of tags that existed in SerializationTag.h at that time and |
|  | // still exist at the time of this writing (i.e., excluding those that were |
|  | // removed on the Chromium side because there should be no real user data |
|  | // containing them). |
|  | // |
|  | // It might be possible to also free up other tags which were never persisted |
|  | // (e.g. because they were used only for transfer) in the future. |
|  | kLegacyReservedMessagePort ='M', |
|  | kLegacyReservedBlob ='b', |
|  | kLegacyReservedBlobIndex ='i', |
|  | kLegacyReservedFile ='f', |
|  | kLegacyReservedFileIndex ='e', |
|  | kLegacyReservedDOMFileSystem ='d', |
|  | kLegacyReservedFileList ='l', |
|  | kLegacyReservedFileListIndex ='L', |
|  | kLegacyReservedImageData ='#', |
|  | kLegacyReservedImageBitmap ='g', |
|  | kLegacyReservedImageBitmapTransfer ='G', |
|  | kLegacyReservedOffscreenCanvas ='H', |
|  | kLegacyReservedCryptoKey ='K', |
|  | kLegacyReservedRTCCertificate ='k', |
|  | }; |
|  |  |
|  | namespace{ |
|  |  |
|  | enumclassArrayBufferViewTag:uint8\_t{ |
|  | kInt8Array ='b', |
|  | kUint8Array ='B', |
|  | kUint8ClampedArray ='C', |
|  | kInt16Array ='w', |
|  | kUint16Array ='W', |
|  | kInt32Array ='d', |
|  | kUint32Array ='D', |
|  | kFloat16Array ='h', |
|  | kFloat32Array ='f', |
|  | kFloat64Array ='F', |
|  | kBigInt64Array ='q', |
|  | kBigUint64Array ='Q', |
|  | kDataView ='?', |
|  | }; |
|  |  |
|  | // Sub-tags only meaningful for error serialization. |
|  | enumclassErrorTag:uint8\_t{ |
|  | // The error is an EvalError. No accompanying data. |
|  | kEvalErrorPrototype ='E', |
|  | // The error is a RangeError. No accompanying data. |
|  | kRangeErrorPrototype ='R', |
|  | // The error is a ReferenceError. No accompanying data. |
|  | kReferenceErrorPrototype ='F', |
|  | // The error is a SyntaxError. No accompanying data. |
|  | kSyntaxErrorPrototype ='S', |
|  | // The error is a TypeError. No accompanying data. |
|  | kTypeErrorPrototype ='T', |
|  | // The error is a URIError. No accompanying data. |
|  | kUriErrorPrototype ='U', |
|  | // Followed by message: string. |
|  | kMessage ='m', |
|  | // Followed by a JS object: cause. |
|  | kCause ='c', |
|  | // Followed by stack: string. |
|  | kStack ='s', |
|  | // The end of this error information. |
|  | kEnd ='.', |
|  | }; |
|  |  |
|  | enumclassWasmMemoryArrayBufferTag:uint8\_t{ |
|  | kFixedLength ='f', |
|  | kResizable ='r' |
|  | }; |
|  |  |
|  | }// namespace |
|  |  |
|  | ValueSerializer::ValueSerializer( |
|  | Isolate\* isolate, v8::ValueSerializer::SharedImmutableArrayBufferMode |
|  | share\_immutable\_array\_buffer) |
|  | :ValueSerializer(isolate,nullptr, share\_immutable\_array\_buffer){} |
|  |  |
|  | ValueSerializer::ValueSerializer( |
|  | Isolate\* isolate, v8::ValueSerializer::Delegate\*delegate, |
|  | v8::ValueSerializer::SharedImmutableArrayBufferMode |
|  | share\_immutable\_array\_buffer) |
|  | : isolate\_(isolate), |
|  | delegate\_(delegate), |
|  | zone\_(isolate->allocator(), ZONE\_NAME), |
|  | id\_map\_(isolate->heap(),ZoneAllocationPolicy(&zone\_)), |
|  | array\_buffer\_transfer\_map\_(isolate->heap(),ZoneAllocationPolicy(&zone\_)), |
|  | share\_immutable\_array\_buffer\_(share\_immutable\_array\_buffer){ |
|  | if(delegate\_){ |
|  | v8::Isolate\* v8\_isolate =reinterpret\_cast<v8::Isolate\*>(isolate\_); |
|  | has\_custom\_host\_objects\_ = delegate\_->HasCustomHostObject(v8\_isolate); |
|  | } |
|  | } |
|  |  |
|  | ValueSerializer::~ValueSerializer(){ |
|  | DCHECK\_IMPLIES( |
|  | !buffer\_ &&!out\_of\_memory\_ && |
|  | share\_immutable\_array\_buffer\_ == |
|  | v8::ValueSerializer::SharedImmutableArrayBufferMode::kEnabled && |
|  | v8\_flags.js\_postmessage\_share\_immutable\_arraybuffer, |
|  | shared\_immutable\_backing\_stores\_.empty()); |
|  | if(buffer\_){ |
|  | if(delegate\_){ |
|  | delegate\_->FreeBufferMemory(buffer\_); |
|  | }else{ |
|  | base::Free(buffer\_); |
|  | } |
|  | } |
|  | } |
|  |  |
|  | voidValueSerializer::WriteHeader(){ |
|  | WriteTag(SerializationTag::kVersion); |
|  | WriteVarint(kLatestVersion); |
|  | } |
|  |  |
|  | voidValueSerializer::SetTreatArrayBufferViewsAsHostObjects(bool mode){ |
|  | treat\_array\_buffer\_views\_as\_host\_objects\_ = mode; |
|  | } |
|  |  |
|  | voidValueSerializer::WriteTag(SerializationTag tag){ |
|  | uint8\_t raw\_tag =static\_cast<uint8\_t>(tag); |
|  | WriteRawBytes(&raw\_tag,sizeof(raw\_tag)); |
|  | } |
|  |  |
|  | template<typename T> |
|  | voidValueSerializer::WriteVarint(T value){ |
|  | // Writes an unsigned integer as a base-128 varint. |
|  | // The number is written, 7 bits at a time, from the least significant to the |
|  | // most significant 7 bits. Each byte, except the last, has the MSB set. |
|  | // See also https://developers.google.com/protocol-buffers/docs/encoding |
|  | static\_assert(std::is\_integral\_v<T>&& std::is\_unsigned\_v<T>, |
|  | "Only unsigned integer types can be written as varints."); |
|  | uint8\_t stack\_buffer\[sizeof(T)\*8/7+1\]; |
|  | uint8\_t\* next\_byte =&stack\_buffer\[0\]; |
|  | do{ |
|  | \*next\_byte =(value &0x7F)\|0x80; |
|  | next\_byte++; |
|  | value >>=7; |
|  | }while(value); |
|  | \*(next\_byte -1)&=0x7F; |
|  | WriteRawBytes(stack\_buffer, next\_byte - stack\_buffer); |
|  | } |
|  |  |
|  | template<typename T> |
|  | voidValueSerializer::WriteZigZag(T value){ |
|  | // Writes a signed integer as a varint using ZigZag encoding (i.e. 0 is |
|  | // encoded as 0, -1 as 1, 1 as 2, -2 as 3, and so on). |
|  | // See also https://developers.google.com/protocol-buffers/docs/encoding |
|  | // Note that this implementation relies on the right shift being arithmetic. |
|  | static\_assert(std::is\_integral\_v<T>&& std::is\_signed\_v<T>, |
|  | "Only signed integer types can be written as zigzag."); |
|  | usingUnsignedT= std::make\_unsigned\_t<T>; |
|  | WriteVarint((static\_cast<UnsignedT>(value)<<1)^ |
|  | (value >>(8\*sizeof(T)-1))); |
|  | } |
|  |  |
|  | template EXPORT\_TEMPLATE\_DEFINE( |
|  | V8\_EXPORT\_PRIVATE)voidValueSerializer::WriteZigZag(int32\_t value); |
|  |  |
|  | voidValueSerializer::WriteDouble(double value){ |
|  | // Warning: this uses host endianness. |
|  | WriteRawBytes(&value,sizeof(value)); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteOneByteString(base::Vector<constuint8\_t> chars){ |
|  | WriteVarint<uint32\_t>(chars.length()); |
|  | WriteRawBytes(chars.begin(), chars.length()\*sizeof(uint8\_t)); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteTwoByteString(base::Vector<const base::uc16> chars){ |
|  | // Warning: this uses host endianness. |
|  | WriteVarint<uint32\_t>(chars.length()\*sizeof(base::uc16)); |
|  | WriteRawBytes(chars.begin(), chars.length()\*sizeof(base::uc16)); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteBigIntContents(Tagged<BigInt> bigint){ |
|  | uint32\_t bitfield = bigint->GetBitfieldForSerialization(); |
|  | size\_t bytelength =BigInt::DigitsByteLengthForBitfield(bitfield); |
|  | WriteVarint<uint32\_t>(bitfield); |
|  | uint8\_t\* dest; |
|  | if(ReserveRawBytes(bytelength).To(&dest)){ |
|  | bigint->SerializeDigits(dest, bytelength); |
|  | } |
|  | } |
|  |  |
|  | voidValueSerializer::WriteRawBytes(constvoid\* source,size\_t length){ |
|  | uint8\_t\* dest; |
|  | if(ReserveRawBytes(length).To(&dest)&& length >0){ |
|  | memcpy(dest, source, length); |
|  | } |
|  | } |
|  |  |
|  | Maybe<uint8\_t\*>ValueSerializer::ReserveRawBytes(size\_t bytes){ |
|  | size\_t old\_size = buffer\_size\_; |
|  | size\_t new\_size = old\_size + bytes; |
|  | if(V8\_UNLIKELY(new\_size > buffer\_capacity\_)){ |
|  | bool ok; |
|  | if(!ExpandBuffer(new\_size).To(&ok)){ |
|  | returnNothing<uint8\_t\*>(); |
|  | } |
|  | } |
|  | buffer\_size\_ = new\_size; |
|  | returnJust(&buffer\_\[old\_size\]); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::ExpandBuffer(size\_t required\_capacity){ |
|  | DCHECK\_GT(required\_capacity, buffer\_capacity\_); |
|  | size\_t requested\_capacity = |
|  | std::max(required\_capacity, buffer\_capacity\_ \*2)+64; |
|  | size\_t provided\_capacity =0; |
|  | void\* new\_buffer =nullptr; |
|  | if(delegate\_){ |
|  | new\_buffer = delegate\_->ReallocateBufferMemory(buffer\_, requested\_capacity, |
|  | &provided\_capacity); |
|  | }else{ |
|  | new\_buffer = base::Realloc(buffer\_, requested\_capacity); |
|  | provided\_capacity = requested\_capacity; |
|  | } |
|  | if(new\_buffer){ |
|  | DCHECK(provided\_capacity >= requested\_capacity); |
|  | buffer\_ =reinterpret\_cast<uint8\_t\*>(new\_buffer); |
|  | buffer\_capacity\_ = provided\_capacity; |
|  | returnJust(true); |
|  | }else{ |
|  | out\_of\_memory\_ =true; |
|  | returnNothing<bool>(); |
|  | } |
|  | } |
|  |  |
|  | voidValueSerializer::WriteByte(uint8\_t value){ |
|  | uint8\_t\* dest; |
|  | if(ReserveRawBytes(sizeof(uint8\_t)).To(&dest)){ |
|  | \*dest = value; |
|  | } |
|  | } |
|  |  |
|  | voidValueSerializer::WriteUint32(uint32\_t value){ |
|  | WriteVarint<uint32\_t>(value); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteUint64(uint64\_t value){ |
|  | WriteVarint<uint64\_t>(value); |
|  | } |
|  |  |
|  | std::pair<uint8\_t\*,size\_t>ValueSerializer::Release(){ |
|  | auto result = std::make\_pair(buffer\_, buffer\_size\_); |
|  | buffer\_ =nullptr; |
|  | buffer\_size\_ =0; |
|  | buffer\_capacity\_ =0; |
|  | return result; |
|  | } |
|  |  |
|  | voidValueSerializer::TransferArrayBuffer( |
|  | uint32\_t transfer\_id,DirectHandle<JSArrayBuffer> array\_buffer){ |
|  | DCHECK(!array\_buffer\_transfer\_map\_.Find(array\_buffer)); |
|  | DCHECK(!array\_buffer->is\_shared()); |
|  | array\_buffer\_transfer\_map\_.Insert(array\_buffer, transfer\_id); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteObject(DirectHandle<Object> object){ |
|  | // There is no sense in trying to proceed if we've previously run out of |
|  | // memory. Bail immediately, as this likely implies that some write has |
|  | // previously failed and so the buffer is corrupt. |
|  | if(V8\_UNLIKELY(out\_of\_memory\_))returnThrowIfOutOfMemory(); |
|  |  |
|  | if(IsSmi(\*object)){ |
|  | WriteSmi(Cast<Smi>(\*object)); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | DCHECK(IsHeapObject(\*object)); |
|  | InstanceType instance\_type = |
|  | Cast<HeapObject>(\*object)->map()->instance\_type(); |
|  | switch(instance\_type){ |
|  | case ODDBALL\_TYPE: |
|  | WriteOddball(Cast<Oddball>(\*object)); |
|  | returnThrowIfOutOfMemory(); |
|  | case HEAP\_NUMBER\_TYPE: |
|  | WriteHeapNumber(Cast<HeapNumber>(\*object)); |
|  | returnThrowIfOutOfMemory(); |
|  | case BIGINT\_TYPE: |
|  | WriteBigInt(Cast<BigInt>(\*object)); |
|  | returnThrowIfOutOfMemory(); |
|  | case JS\_TYPED\_ARRAY\_TYPE: |
|  | case JS\_DATA\_VIEW\_TYPE: |
|  | case JS\_RAB\_GSAB\_DATA\_VIEW\_TYPE:{ |
|  | // Despite being JSReceivers, these have their wrapped buffer serialized |
|  | // first. That makes this logic a little quirky, because it needs to |
|  | // happen before we assign object IDs. |
|  | // TODO(jbroman): It may be possible to avoid materializing a typed |
|  | // array's buffer here. |
|  | DirectHandle<JSArrayBufferView> view =Cast<JSArrayBufferView>(object); |
|  | if(!id\_map\_.Find(view)&&!treat\_array\_buffer\_views\_as\_host\_objects\_){ |
|  | DirectHandle<JSArrayBuffer> buffer( |
|  | InstanceTypeChecker::IsJSTypedArray(instance\_type) |
|  | ?Cast<JSTypedArray>(view)->GetBuffer(isolate\_) |
|  | : direct\_handle(Cast<JSArrayBuffer>(view->buffer()), isolate\_)); |
|  | if(!WriteJSReceiver(buffer).FromMaybe(false))returnNothing<bool>(); |
|  | } |
|  | returnWriteJSReceiver(view); |
|  | } |
|  | default: |
|  | if(InstanceTypeChecker::IsString(instance\_type)){ |
|  | WriteString(Cast<String>(object)); |
|  | returnThrowIfOutOfMemory(); |
|  | }elseif(InstanceTypeChecker::IsJSReceiver(instance\_type)){ |
|  | returnWriteJSReceiver(Cast<JSReceiver>(object)); |
|  | }else{ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, object); |
|  | } |
|  | } |
|  | } |
|  |  |
|  | voidValueSerializer::WriteOddball(Tagged<Oddball> oddball){ |
|  | SerializationTag tag =SerializationTag::kUndefined; |
|  | switch(oddball->kind()){ |
|  | caseOddball::kUndefined: |
|  | tag =SerializationTag::kUndefined; |
|  | break; |
|  | caseOddball::kFalse: |
|  | tag =SerializationTag::kFalse; |
|  | break; |
|  | caseOddball::kTrue: |
|  | tag =SerializationTag::kTrue; |
|  | break; |
|  | caseOddball::kNull: |
|  | tag =SerializationTag::kNull; |
|  | break; |
|  | default: |
|  | UNREACHABLE(); |
|  | } |
|  | WriteTag(tag); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteSmi(Tagged<Smi> smi){ |
|  | static\_assert(kSmiValueSize <=32,"Expected SMI <= 32 bits."); |
|  | WriteTag(SerializationTag::kInt32); |
|  | WriteZigZag<int32\_t>(smi.value()); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteHeapNumber(Tagged<HeapNumber> number){ |
|  | WriteTag(SerializationTag::kDouble); |
|  | WriteDouble(number->value()); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteBigInt(Tagged<BigInt> bigint){ |
|  | WriteTag(SerializationTag::kBigInt); |
|  | WriteBigIntContents(bigint); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteString(DirectHandle<String> string){ |
|  | string =String::Flatten(isolate\_, string); |
|  | DisallowGarbageCollection no\_gc; |
|  | String::FlatContent flat = string->GetFlatContent(no\_gc); |
|  | DCHECK(flat.IsFlat()); |
|  | if(flat.IsOneByte()){ |
|  | base::Vector<constuint8\_t> chars = flat.ToOneByteVector(); |
|  | WriteTag(SerializationTag::kOneByteString); |
|  | WriteOneByteString(chars); |
|  | }elseif(flat.IsTwoByte()){ |
|  | base::Vector<const base::uc16> chars = flat.ToUC16Vector(); |
|  | uint32\_t byte\_length = chars.length()\*sizeof(base::uc16); |
|  | // The existing reading code expects 16-byte strings to be aligned. |
|  | if((buffer\_size\_ +1+BytesNeededForVarint(byte\_length))&1){ |
|  | WriteTag(SerializationTag::kPadding); |
|  | } |
|  | WriteTag(SerializationTag::kTwoByteString); |
|  | WriteTwoByteString(chars); |
|  | }else{ |
|  | UNREACHABLE(); |
|  | } |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSReceiver( |
|  | DirectHandle<JSReceiver> receiver){ |
|  | // If the object has already been serialized, just write its ID. |
|  | auto find\_result = id\_map\_.FindOrInsert(receiver); |
|  | if(find\_result.already\_exists){ |
|  | WriteTag(SerializationTag::kObjectReference); |
|  | WriteVarint(\*find\_result.entry -1); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | // Otherwise, allocate an ID for it. |
|  | uint32\_t id = next\_id\_++; |
|  | \*find\_result.entry = id +1; |
|  |  |
|  | // Eliminate callable and exotic objects, which should not be serialized. |
|  | InstanceType instance\_type = receiver->map()->instance\_type(); |
|  | if(IsCallable(\*receiver)\|\| |
|  | (IsSpecialReceiverInstanceType(instance\_type)&& |
|  | instance\_type != JS\_SPECIAL\_API\_OBJECT\_TYPE |
|  | #if V8\_ENABLE\_WEBASSEMBLY |
|  | && instance\_type != WASM\_STRUCT\_TYPE && instance\_type != WASM\_ARRAY\_TYPE |
|  | #endif |
|  | )){ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, receiver); |
|  | } |
|  |  |
|  | // If we are at the end of the stack, abort. This function may recurse. |
|  | STACK\_CHECK(isolate\_,Nothing<bool>()); |
|  |  |
|  | HandleScope scope(isolate\_); |
|  | switch(instance\_type){ |
|  | case JS\_ARRAY\_TYPE: |
|  | returnWriteJSArray(Cast<JSArray>(receiver)); |
|  | case JS\_ARRAY\_ITERATOR\_PROTOTYPE\_TYPE: |
|  | case JS\_ITERATOR\_PROTOTYPE\_TYPE: |
|  | case JS\_MAP\_ITERATOR\_PROTOTYPE\_TYPE: |
|  | case JS\_OBJECT\_PROTOTYPE\_TYPE: |
|  | case JS\_OBJECT\_TYPE: |
|  | case JS\_PROMISE\_PROTOTYPE\_TYPE: |
|  | case JS\_REG\_EXP\_PROTOTYPE\_TYPE: |
|  | case JS\_SET\_ITERATOR\_PROTOTYPE\_TYPE: |
|  | case JS\_SET\_PROTOTYPE\_TYPE: |
|  | case JS\_STRING\_ITERATOR\_PROTOTYPE\_TYPE: |
|  | case JS\_TYPED\_ARRAY\_PROTOTYPE\_TYPE: |
|  | case JS\_API\_OBJECT\_TYPE:{ |
|  | DirectHandle<JSObject> js\_object =Cast<JSObject>(receiver); |
|  | Maybe<bool> is\_host\_object =IsHostObject(js\_object); |
|  | if(is\_host\_object.IsNothing()){ |
|  | return is\_host\_object; |
|  | } |
|  | if(is\_host\_object.FromJust()){ |
|  | returnWriteHostObject(js\_object); |
|  | }else{ |
|  | returnWriteJSObject(js\_object); |
|  | } |
|  | } |
|  | case JS\_SPECIAL\_API\_OBJECT\_TYPE: |
|  | returnWriteHostObject(Cast<JSObject>(receiver)); |
|  | case JS\_DATE\_TYPE: |
|  | WriteJSDate(Cast<JSDate>(\*receiver)); |
|  | returnThrowIfOutOfMemory(); |
|  | case JS\_PRIMITIVE\_WRAPPER\_TYPE: |
|  | returnWriteJSPrimitiveWrapper(Cast<JSPrimitiveWrapper>(receiver)); |
|  | case JS\_REG\_EXP\_TYPE: |
|  | WriteJSRegExp(Cast<JSRegExp>(receiver)); |
|  | returnThrowIfOutOfMemory(); |
|  | case JS\_MAP\_TYPE: |
|  | returnWriteJSMap(Cast<JSMap>(receiver)); |
|  | case JS\_SET\_TYPE: |
|  | returnWriteJSSet(Cast<JSSet>(receiver)); |
|  | case JS\_ARRAY\_BUFFER\_TYPE: |
|  | returnWriteJSArrayBuffer(Cast<JSArrayBuffer>(receiver)); |
|  | case JS\_DETACHED\_TYPED\_ARRAY\_TYPE: |
|  | returnThrowDataCloneError( |
|  | MessageTemplate::kDataCloneErrorDetachedArrayBuffer); |
|  | case JS\_TYPED\_ARRAY\_TYPE: |
|  | case JS\_DATA\_VIEW\_TYPE: |
|  | case JS\_RAB\_GSAB\_DATA\_VIEW\_TYPE: |
|  | returnWriteJSArrayBufferView(Cast<JSArrayBufferView>(\*receiver)); |
|  | case JS\_ERROR\_TYPE:{ |
|  | DirectHandle<JSObject> js\_error =Cast<JSObject>(receiver); |
|  | Maybe<bool> is\_host\_object =IsHostObject(js\_error); |
|  | if(is\_host\_object.IsNothing()){ |
|  | return is\_host\_object; |
|  | } |
|  | if(is\_host\_object.FromJust()){ |
|  | returnWriteHostObject(js\_error); |
|  | } |
|  | returnWriteJSError(js\_error); |
|  | } |
|  | case JS\_SHARED\_ARRAY\_TYPE: |
|  | returnWriteJSSharedArray(Cast<JSSharedArray>(receiver)); |
|  | case JS\_SHARED\_STRUCT\_TYPE: |
|  | returnWriteJSSharedStruct(Cast<JSSharedStruct>(receiver)); |
|  | case JS\_ATOMICS\_MUTEX\_TYPE: |
|  | case JS\_ATOMICS\_CONDITION\_TYPE: |
|  | returnWriteSharedObject(receiver); |
|  | #if V8\_ENABLE\_WEBASSEMBLY |
|  | case WASM\_MODULE\_OBJECT\_TYPE: |
|  | returnWriteWasmModule(Cast<WasmModuleObject>(receiver)); |
|  | case WASM\_MEMORY\_OBJECT\_TYPE: |
|  | returnWriteWasmMemory(Cast<WasmMemoryObject>(receiver)); |
|  | case WASM\_STRUCT\_TYPE: |
|  | case WASM\_ARRAY\_TYPE: |
|  | if(HeapLayout::InAnySharedSpace(\*receiver)){ |
|  | returnWriteSharedObject(receiver); |
|  | } |
|  | break; |
|  | #endif// V8\_ENABLE\_WEBASSEMBLY |
|  | default: |
|  | break; |
|  | } |
|  |  |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, receiver); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSObject(DirectHandle<JSObject> object){ |
|  | DCHECK(!IsCustomElementsReceiverMap(object->map())); |
|  | constbool can\_serialize\_fast = |
|  | object->HasFastProperties()&& object->elements()->ulength().value()==0; |
|  | if(!can\_serialize\_fast)returnWriteJSObjectSlow(object); |
|  |  |
|  | DirectHandle<Map>map(object->map(), isolate\_); |
|  | WriteTag(SerializationTag::kBeginJSObject); |
|  |  |
|  | // Write out fast properties as long as they are only data properties and the |
|  | // map doesn't change. |
|  | uint32\_t properties\_written =0; |
|  | bool map\_changed =false; |
|  | for(InternalIndex i :map->IterateOwnDescriptors()){ |
|  | DirectHandle<Name> key(map->instance\_descriptors()->GetKey(i), isolate\_); |
|  | if(!IsString(\*key))continue; |
|  | PropertyDetails details =map->instance\_descriptors()->GetDetails(i); |
|  | if(details.IsDontEnum())continue; |
|  |  |
|  | DirectHandle<Object> value; |
|  | if(V8\_LIKELY(!map\_changed)) map\_changed =\*map!= object->map(); |
|  | if(V8\_LIKELY(!map\_changed && |
|  | details.location()==PropertyLocation::kField)){ |
|  | DCHECK\_EQ(PropertyKind::kData, details.kind()); |
|  | FieldIndex field\_index =FieldIndex::ForDetails(\*map, details); |
|  | value = direct\_handle(object->RawFastPropertyAt(field\_index), isolate\_); |
|  | }else{ |
|  | // This logic should essentially match WriteJSObjectPropertiesSlow. |
|  | // If the property is no longer found, do not serialize it. |
|  | // This could happen if a getter deleted the property. |
|  | LookupIterator it(isolate\_, object, key,LookupIterator::OWN); |
|  | if(!it.IsFound())continue; |
|  | if(!Object::GetProperty(&it).ToHandle(&value))returnNothing<bool>(); |
|  | } |
|  |  |
|  | if(!WriteObject(key).FromMaybe(false)\|\| |
|  | !WriteObject(value).FromMaybe(false)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | properties\_written++; |
|  | } |
|  |  |
|  | WriteTag(SerializationTag::kEndJSObject); |
|  | WriteVarint<uint32\_t>(properties\_written); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSObjectSlow(DirectHandle<JSObject> object){ |
|  | WriteTag(SerializationTag::kBeginJSObject); |
|  | DirectHandle<FixedArray> keys; |
|  | uint32\_t properties\_written =0; |
|  | if(!KeyAccumulator::GetKeys(isolate\_, object,KeyCollectionMode::kOwnOnly, |
|  | ENUMERABLE\_STRINGS) |
|  | .ToHandle(&keys)\|\| |
|  | !WriteJSObjectPropertiesSlow(object, keys).To(&properties\_written)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | WriteTag(SerializationTag::kEndJSObject); |
|  | WriteVarint<uint32\_t>(properties\_written); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSArray(DirectHandle<JSArray> array){ |
|  | uint32\_t length =0; |
|  | bool valid\_length =Object::ToArrayLength(array->length(),&length); |
|  | DCHECK(valid\_length); |
|  | USE(valid\_length); |
|  |  |
|  | // To keep things simple, for now we decide between dense and sparse |
|  | // serialization based on elements kind. A more principled heuristic could |
|  | // count the elements, but would need to take care to note which indices |
|  | // existed (as only indices which were enumerable own properties at this point |
|  | // should be serialized). |
|  | constbool should\_serialize\_densely = |
|  | array->HasFastElements()&&!array->HasHoleyElements(); |
|  |  |
|  | if(should\_serialize\_densely){ |
|  | DCHECK\_LE(length,FixedArray::kMaxLength); |
|  | WriteTag(SerializationTag::kBeginDenseJSArray); |
|  | WriteVarint<uint32\_t>(length); |
|  | uint32\_t i =0; |
|  |  |
|  | // Fast paths. Note that PACKED\_ELEMENTS in particular can bail due to the |
|  | // structure of the elements changing. |
|  | switch(array->GetElementsKind()){ |
|  | case PACKED\_SMI\_ELEMENTS:{ |
|  | DisallowGarbageCollection no\_gc; |
|  | Tagged<FixedArray> elements =Cast<FixedArray>(array->elements()); |
|  | for(i =0; i < length; i++){ |
|  | WriteSmi(Cast<Smi>(elements->get(i))); |
|  | } |
|  | break; |
|  | } |
|  | case PACKED\_DOUBLE\_ELEMENTS:{ |
|  | // Elements are empty\_fixed\_array, not a FixedDoubleArray, if the array |
|  | // is empty. No elements to encode in this case anyhow. |
|  | if(length ==0)break; |
|  | DisallowGarbageCollection no\_gc; |
|  | Tagged<FixedDoubleArray> elements = |
|  | Cast<FixedDoubleArray>(array->elements()); |
|  | for(i =0; i < length; i++){ |
|  | WriteTag(SerializationTag::kDouble); |
|  | WriteDouble(elements->get\_scalar(i)); |
|  | } |
|  | break; |
|  | } |
|  | case PACKED\_ELEMENTS:{ |
|  | DirectHandle<Object> old\_length(array->length(), isolate\_); |
|  | for(; i < length; i++){ |
|  | if(array->length()!=\*old\_length \|\| |
|  | array->GetElementsKind()!= PACKED\_ELEMENTS){ |
|  | // Fall back to slow path. |
|  | break; |
|  | } |
|  | DirectHandle<Object> element( |
|  | Cast<FixedArray>(array->elements())->get(i), isolate\_); |
|  | if(!WriteObject(element).FromMaybe(false))returnNothing<bool>(); |
|  | } |
|  | break; |
|  | } |
|  | default: |
|  | break; |
|  | } |
|  |  |
|  | // If there are elements remaining, serialize them slowly. |
|  | for(; i < length; i++){ |
|  | // Serializing the array's elements can have arbitrary side effects, so we |
|  | // cannot rely on still having fast elements, even if it did to begin |
|  | // with. |
|  | DirectHandle<Object> element; |
|  | LookupIterator it(isolate\_, array, i, array,LookupIterator::OWN); |
|  | if(!it.IsFound()){ |
|  | // This can happen in the case where an array that was originally dense |
|  | // became sparse during serialization. It's too late to switch to the |
|  | // sparse format, but we can mark the elements as absent. |
|  | WriteTag(SerializationTag::kTheHole); |
|  | continue; |
|  | } |
|  | if(!Object::GetProperty(&it).ToHandle(&element)\|\| |
|  | !WriteObject(element).FromMaybe(false)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | } |
|  |  |
|  | DirectHandle<FixedArray> keys; |
|  | if(!KeyAccumulator::GetKeys(isolate\_, array,KeyCollectionMode::kOwnOnly, |
|  | ENUMERABLE\_STRINGS, |
|  | GetKeysConversion::kKeepNumbers,false,true) |
|  | .ToHandle(&keys)){ |
|  | returnNothing<bool>(); |
|  | } |
|  |  |
|  | uint32\_t properties\_written; |
|  | if(!WriteJSObjectPropertiesSlow(array, keys).To(&properties\_written)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | WriteTag(SerializationTag::kEndDenseJSArray); |
|  | WriteVarint<uint32\_t>(properties\_written); |
|  | WriteVarint<uint32\_t>(length); |
|  | }else{ |
|  | WriteTag(SerializationTag::kBeginSparseJSArray); |
|  | WriteVarint<uint32\_t>(length); |
|  | DirectHandle<FixedArray> keys; |
|  | uint32\_t properties\_written =0; |
|  | if(!KeyAccumulator::GetKeys(isolate\_, array,KeyCollectionMode::kOwnOnly, |
|  | ENUMERABLE\_STRINGS) |
|  | .ToHandle(&keys)\|\| |
|  | !WriteJSObjectPropertiesSlow(array, keys).To(&properties\_written)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | WriteTag(SerializationTag::kEndSparseJSArray); |
|  | WriteVarint<uint32\_t>(properties\_written); |
|  | WriteVarint<uint32\_t>(length); |
|  | } |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteJSDate(Tagged<JSDate> date){ |
|  | WriteTag(SerializationTag::kDate); |
|  | WriteDouble(date->value()); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSPrimitiveWrapper( |
|  | DirectHandle<JSPrimitiveWrapper> value){ |
|  | { |
|  | DisallowGarbageCollection no\_gc; |
|  | Tagged<Object> inner\_value = value->value(); |
|  | if(IsTrue(inner\_value)){ |
|  | WriteTag(SerializationTag::kTrueObject); |
|  | }elseif(IsFalse(inner\_value)){ |
|  | WriteTag(SerializationTag::kFalseObject); |
|  | }elseif(IsNumber(inner\_value)){ |
|  | WriteTag(SerializationTag::kNumberObject); |
|  | WriteDouble(Object::NumberValue(inner\_value)); |
|  | }elseif(IsBigInt(inner\_value)){ |
|  | WriteTag(SerializationTag::kBigIntObject); |
|  | WriteBigIntContents(Cast<BigInt>(inner\_value)); |
|  | }elseif(IsString(inner\_value)){ |
|  | WriteTag(SerializationTag::kStringObject); |
|  | WriteString(direct\_handle(Cast<String>(inner\_value), isolate\_)); |
|  | }else{ |
|  | AllowGarbageCollection allow\_gc; |
|  | DCHECK(IsSymbol(inner\_value)); |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, value); |
|  | } |
|  | } |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | voidValueSerializer::WriteJSRegExp(DirectHandle<JSRegExp> regexp){ |
|  | WriteTag(SerializationTag::kRegExp); |
|  | WriteString(direct\_handle(regexp->source(isolate\_), isolate\_)); |
|  | WriteVarint(static\_cast<uint32\_t>(regexp->flags())); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSMap(DirectHandle<JSMap> js\_map){ |
|  | // First copy the key-value pairs, since getters could mutate them. |
|  | DirectHandle<OrderedHashMap> table(Cast<OrderedHashMap>(js\_map->table()), |
|  | isolate\_); |
|  | int length = table->NumberOfElements()\*2; |
|  | DirectHandle<FixedArray> entries = isolate\_->factory()->NewFixedArray(length); |
|  | { |
|  | DisallowGarbageCollection no\_gc; |
|  | Tagged<OrderedHashMap> raw\_table =\*table; |
|  | Tagged<FixedArray> raw\_entries =\*entries; |
|  | Tagged<Hole> hash\_table\_hole = |
|  | ReadOnlyRoots(isolate\_).hash\_table\_hole\_value(); |
|  | int result\_index =0; |
|  | for(InternalIndex entry : raw\_table->IterateEntries()){ |
|  | Tagged<Object> key = raw\_table->KeyAt(entry); |
|  | if(key == hash\_table\_hole)continue; |
|  | raw\_entries->set(result\_index++, key); |
|  | raw\_entries->set(result\_index++, raw\_table->ValueAt(entry)); |
|  | } |
|  | DCHECK\_EQ(result\_index, length); |
|  | } |
|  |  |
|  | // Then write it out. |
|  | WriteTag(SerializationTag::kBeginJSMap); |
|  | for(int i =0; i < length; i++){ |
|  | if(!WriteObject(direct\_handle(entries->get(i), isolate\_)) |
|  | .FromMaybe(false)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | } |
|  | WriteTag(SerializationTag::kEndJSMap); |
|  | WriteVarint<uint32\_t>(length); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSSet(DirectHandle<JSSet> js\_set){ |
|  | // First copy the element pointers, since getters could mutate them. |
|  | DirectHandle<OrderedHashSet> table(Cast<OrderedHashSet>(js\_set->table()), |
|  | isolate\_); |
|  | int length = table->NumberOfElements(); |
|  | DirectHandle<FixedArray> entries = isolate\_->factory()->NewFixedArray(length); |
|  | { |
|  | DisallowGarbageCollection no\_gc; |
|  | Tagged<OrderedHashSet> raw\_table =\*table; |
|  | Tagged<FixedArray> raw\_entries =\*entries; |
|  | Tagged<Hole> hash\_table\_hole = |
|  | ReadOnlyRoots(isolate\_).hash\_table\_hole\_value(); |
|  | int result\_index =0; |
|  | for(InternalIndex entry : raw\_table->IterateEntries()){ |
|  | Tagged<Object> key = raw\_table->KeyAt(entry); |
|  | if(key == hash\_table\_hole)continue; |
|  | raw\_entries->set(result\_index++, key); |
|  | } |
|  | DCHECK\_EQ(result\_index, length); |
|  | } |
|  |  |
|  | // Then write it out. |
|  | WriteTag(SerializationTag::kBeginJSSet); |
|  | for(int i =0; i < length; i++){ |
|  | if(!WriteObject(direct\_handle(entries->get(i), isolate\_)) |
|  | .FromMaybe(false)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | } |
|  | WriteTag(SerializationTag::kEndJSSet); |
|  | WriteVarint<uint32\_t>(length); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSArrayBuffer( |
|  | DirectHandle<JSArrayBuffer> array\_buffer){ |
|  | if(array\_buffer->is\_shared()){ |
|  | if(!delegate\_){ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, |
|  | array\_buffer); |
|  | } |
|  |  |
|  | v8::Isolate\* v8\_isolate =reinterpret\_cast<v8::Isolate\*>(isolate\_); |
|  | Maybe<uint32\_t> index = delegate\_->GetSharedArrayBufferId( |
|  | v8\_isolate,Utils::ToLocalShared(array\_buffer)); |
|  | RETURN\_VALUE\_IF\_EXCEPTION(isolate\_,Nothing<bool>()); |
|  |  |
|  | WriteTag(SerializationTag::kSharedArrayBuffer); |
|  | WriteVarint(index.FromJust()); |
|  |  |
|  | #if V8\_ENABLE\_WEBASSEMBLY |
|  | // SharedArrayBuffers that are actually WebAssembly memories need special |
|  | // handling because they have metadata that may diverge from their |
|  | // BackingStore's. |
|  | // |
|  | // These are handled by also serializing/deserializing their corresponding |
|  | // WebAssembly.Memory object. |
|  | // |
|  | // See comment for WasmMemoryObject::FixUpResizableArrayBuffer for details. |
|  | auto backing\_store = array\_buffer->GetBackingStore(); |
|  | if(backing\_store && backing\_store->is\_wasm\_memory()){ |
|  | DCHECK\_EQ( |
|  | backing\_store->is\_resizable\_by\_js().value(), |
|  | !backing\_store->is\_shared()&& array\_buffer->is\_resizable\_by\_js()); |
|  | if(array\_buffer->is\_resizable\_by\_js()){ |
|  | Handle<Object> memory = |
|  | Object::GetProperty( |
|  | isolate\_, array\_buffer, |
|  | isolate\_->factory()->array\_buffer\_wasm\_memory\_symbol()) |
|  | .ToHandleChecked(); |
|  | CHECK(IsWasmMemoryObject(\*memory)); |
|  | WriteVarint(static\_cast<uint8\_t>(WasmMemoryArrayBufferTag::kResizable)); |
|  | if(!WriteJSReceiver(Cast<JSReceiver>(memory)).FromMaybe(false)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | }else{ |
|  | WriteVarint( |
|  | static\_cast<uint8\_t>(WasmMemoryArrayBufferTag::kFixedLength)); |
|  | WriteVarint<size\_t>(array\_buffer->byte\_length()); |
|  | } |
|  | } |
|  | #endif// V8\_ENABLE\_WEBASSEMBLY |
|  |  |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | uint32\_t\* transfer\_entry = array\_buffer\_transfer\_map\_.Find(array\_buffer); |
|  | if(transfer\_entry){ |
|  | WriteTag(SerializationTag::kArrayBufferTransfer); |
|  | WriteVarint(\*transfer\_entry); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  | if(array\_buffer->was\_detached()){ |
|  | returnThrowDataCloneError( |
|  | MessageTemplate::kDataCloneErrorDetachedArrayBuffer); |
|  | } |
|  | size\_t byte\_length = array\_buffer->byte\_length(); |
|  | if(byte\_length > std::numeric\_limits<uint32\_t>::max()){ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, array\_buffer); |
|  | } |
|  |  |
|  | ResizableFlag is\_resizable = array\_buffer->is\_resizable\_by\_js(); |
|  | if(is\_resizable){ |
|  | WriteTag(SerializationTag::kResizableArrayBuffer); |
|  | WriteVarint<size\_t>(byte\_length); |
|  | WriteVarint<size\_t>(array\_buffer->max\_byte\_length()); |
|  | WriteRawBytes(array\_buffer->backing\_store(), byte\_length); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | if(array\_buffer->is\_immutable()){ |
|  | if(share\_immutable\_array\_buffer\_ == |
|  | v8::ValueSerializer::SharedImmutableArrayBufferMode::kEnabled && |
|  | v8\_flags.js\_postmessage\_share\_immutable\_arraybuffer){ |
|  | auto backing\_store = array\_buffer->GetBackingStore(); |
|  | DCHECK\_IMPLIES(!backing\_store, byte\_length ==0); |
|  | if(backing\_store){ |
|  | uint32\_t id =0; |
|  | auto it = |
|  | std::find(shared\_immutable\_backing\_stores\_.begin(), |
|  | shared\_immutable\_backing\_stores\_.end(), backing\_store); |
|  | if(it != shared\_immutable\_backing\_stores\_.end()){ |
|  | id =static\_cast<uint32\_t>(it - |
|  | shared\_immutable\_backing\_stores\_.begin()); |
|  | }else{ |
|  | id =static\_cast<uint32\_t>(shared\_immutable\_backing\_stores\_.size()); |
|  | shared\_immutable\_backing\_stores\_.push\_back(backing\_store); |
|  | } |
|  | WriteTag(SerializationTag::kSharedImmutableArrayBuffer); |
|  | WriteVarint<uint32\_t>(id); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  | } |
|  | WriteTag(SerializationTag::kImmutableArrayBuffer); |
|  | }else{ |
|  | WriteTag(SerializationTag::kArrayBuffer); |
|  | } |
|  | WriteVarint<size\_t>(byte\_length); |
|  | WriteRawBytes(array\_buffer->backing\_store(), byte\_length); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSArrayBufferView( |
|  | Tagged<JSArrayBufferView> view){ |
|  | if(treat\_array\_buffer\_views\_as\_host\_objects\_){ |
|  | returnWriteHostObject(direct\_handle(view, isolate\_)); |
|  | } |
|  | WriteTag(SerializationTag::kArrayBufferView); |
|  | ArrayBufferViewTag tag =ArrayBufferViewTag::kInt8Array; |
|  | if(IsJSTypedArray(view)){ |
|  | if(Cast<JSTypedArray>(view)->IsOutOfBounds()){ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, |
|  | direct\_handle(view, isolate\_)); |
|  | } |
|  | switch(Cast<JSTypedArray>(view)->type()){ |
|  | #define TYPED\_ARRAY\_CASE(Type, type, TYPE, ctype) \ |
|  | case kExternal##Type##Array: \ |
|  | tag =ArrayBufferViewTag::k##Type##Array; \ |
|  | break; |
|  | TYPED\_ARRAYS(TYPED\_ARRAY\_CASE) |
|  | #undef TYPED\_ARRAY\_CASE |
|  | } |
|  | }else{ |
|  | DCHECK(IsJSDataViewOrRabGsabDataView(view)); |
|  | if(IsJSRabGsabDataView(view)&& |
|  | Cast<JSRabGsabDataView>(view)->IsOutOfBounds()){ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, |
|  | direct\_handle(view, isolate\_)); |
|  | } |
|  |  |
|  | tag =ArrayBufferViewTag::kDataView; |
|  | } |
|  | WriteVarint(static\_cast<uint8\_t>(tag)); |
|  | WriteVarint<size\_t>(view->byte\_offset()); |
|  | WriteVarint<size\_t>(view->byte\_length()); |
|  | uint32\_t flags = |
|  | JSArrayBufferViewIsLengthTracking::encode(view->is\_length\_tracking())\| |
|  | JSArrayBufferViewIsBackedByRab::encode(view->is\_backed\_by\_rab()); |
|  | WriteVarint(flags); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSError(DirectHandle<JSObject> error){ |
|  | DirectHandle<Object>stack; |
|  | PropertyDescriptor message\_desc; |
|  | Maybe<bool> message\_found =JSReceiver::GetOwnPropertyDescriptor( |
|  | isolate\_, error, isolate\_->factory()->message\_string(),&message\_desc); |
|  | MAYBE\_RETURN(message\_found,Nothing<bool>()); |
|  | PropertyDescriptor cause\_desc; |
|  | Maybe<bool> cause\_found =JSReceiver::GetOwnPropertyDescriptor( |
|  | isolate\_, error, isolate\_->factory()->cause\_string(),&cause\_desc); |
|  |  |
|  | WriteTag(SerializationTag::kError); |
|  |  |
|  | DirectHandle<Object> name\_object; |
|  | if(!JSReceiver::GetProperty(isolate\_, error,"name") |
|  | .ToHandle(&name\_object)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | DirectHandle<String> name; |
|  | if(!Object::ToString(isolate\_, name\_object).ToHandle(&name)){ |
|  | returnNothing<bool>(); |
|  | } |
|  |  |
|  | if(name->IsOneByteEqualTo(base::CStrVector("EvalError"))){ |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kEvalErrorPrototype)); |
|  | }elseif(name->IsOneByteEqualTo(base::CStrVector("RangeError"))){ |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kRangeErrorPrototype)); |
|  | }elseif(name->IsOneByteEqualTo(base::CStrVector("ReferenceError"))){ |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kReferenceErrorPrototype)); |
|  | }elseif(name->IsOneByteEqualTo(base::CStrVector("SyntaxError"))){ |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kSyntaxErrorPrototype)); |
|  | }elseif(name->IsOneByteEqualTo(base::CStrVector("TypeError"))){ |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kTypeErrorPrototype)); |
|  | }elseif(name->IsOneByteEqualTo(base::CStrVector("URIError"))){ |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kUriErrorPrototype)); |
|  | }else{ |
|  | // The default prototype in the deserialization side is Error.prototype, so |
|  | // we don't have to do anything here. |
|  | } |
|  |  |
|  | if(message\_found.FromJust()&& |
|  | PropertyDescriptor::IsDataDescriptor(&message\_desc)){ |
|  | DirectHandle<String> message; |
|  | if(!Object::ToString(isolate\_, message\_desc.value()).ToHandle(&message)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kMessage)); |
|  | WriteString(message); |
|  | } |
|  |  |
|  | if(!Object::GetProperty(isolate\_, error, isolate\_->factory()->stack\_string()) |
|  | .ToHandle(&stack)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | if(IsString(\*stack)){ |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kStack)); |
|  | WriteString(Cast<String>(stack)); |
|  | } |
|  |  |
|  | // The {cause} can self-reference the error. We add at the end, so that we can |
|  | // create the Error first when deserializing. |
|  | if(cause\_found.FromJust()&& |
|  | PropertyDescriptor::IsDataDescriptor(&cause\_desc)){ |
|  | DirectHandle<Object> cause = cause\_desc.value(); |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kCause)); |
|  | if(!WriteObject(cause).FromMaybe(false)){ |
|  | returnNothing<bool>(); |
|  | } |
|  | } |
|  |  |
|  | WriteVarint(static\_cast<uint8\_t>(ErrorTag::kEnd)); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSSharedStruct( |
|  | DirectHandle<JSSharedStruct> shared\_struct){ |
|  | // TODO(v8:12547): Support copying serialization for shared structs as well. |
|  | returnWriteSharedObject(shared\_struct); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteJSSharedArray( |
|  | DirectHandle<JSSharedArray> shared\_array){ |
|  | returnWriteSharedObject(shared\_array); |
|  | } |
|  |  |
|  | #if V8\_ENABLE\_WEBASSEMBLY |
|  | Maybe<bool>ValueSerializer::WriteWasmModule( |
|  | DirectHandle<WasmModuleObject> object){ |
|  | if(delegate\_ ==nullptr){ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, object); |
|  | } |
|  |  |
|  | Maybe<uint32\_t> transfer\_id = delegate\_->GetWasmModuleTransferId( |
|  | reinterpret\_cast<v8::Isolate\*>(isolate\_),Utils::ToLocal(object)); |
|  | RETURN\_VALUE\_IF\_EXCEPTION(isolate\_,Nothing<bool>()); |
|  | uint32\_t id =0; |
|  | if(transfer\_id.To(&id)){ |
|  | WriteTag(SerializationTag::kWasmModuleTransfer); |
|  | WriteVarint<uint32\_t>(id); |
|  | returnJust(true); |
|  | } |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteWasmMemory( |
|  | DirectHandle<WasmMemoryObject> object){ |
|  | DirectHandle<JSArrayBuffer> shared\_ab = |
|  | WasmMemoryObject::GetArrayBuffer(isolate\_, object); |
|  | if(!shared\_ab->is\_shared()){ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, object); |
|  | } |
|  |  |
|  | GlobalBackingStoreRegistry::Register(shared\_ab->GetBackingStore()); |
|  |  |
|  | WriteTag(SerializationTag::kWasmMemoryTransfer); |
|  | WriteZigZag<int32\_t>(object->maximum\_pages()); |
|  | WriteByte(object->is\_memory64()?1:0); |
|  | returnWriteJSReceiver(shared\_ab); |
|  | } |
|  | #endif// V8\_ENABLE\_WEBASSEMBLY |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteSharedObject( |
|  | DirectHandle<HeapObject> object){ |
|  | if(!delegate\_ \|\|!isolate\_->has\_shared\_space()){ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneError, object); |
|  | } |
|  |  |
|  | DCHECK(IsShared(\*object)); |
|  |  |
|  | // The first time a shared object is serialized, a new conveyor is made. This |
|  | // conveyor is used for every shared object in this serialization and |
|  | // subsequent deserialization sessions. The embedder owns the lifetime of the |
|  | // conveyor. |
|  | if(!shared\_object\_conveyor\_){ |
|  | v8::Isolate\* v8\_isolate =reinterpret\_cast<v8::Isolate\*>(isolate\_); |
|  | v8::SharedValueConveyor v8\_conveyor(v8\_isolate); |
|  | shared\_object\_conveyor\_ = v8\_conveyor.private\_.get(); |
|  | if(!delegate\_->AdoptSharedValueConveyor(v8\_isolate, |
|  | std::move(v8\_conveyor))){ |
|  | shared\_object\_conveyor\_ =nullptr; |
|  | RETURN\_VALUE\_IF\_EXCEPTION(isolate\_,Nothing<bool>()); |
|  | returnNothing<bool>(); |
|  | } |
|  | } |
|  |  |
|  | WriteTag(SerializationTag::kSharedObject); |
|  | WriteVarint(shared\_object\_conveyor\_->Persist(\*object)); |
|  |  |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::WriteHostObject(DirectHandle<JSObject> object){ |
|  | WriteTag(SerializationTag::kHostObject); |
|  | if(!delegate\_){ |
|  | isolate\_->Throw(\*isolate\_->factory()->NewError( |
|  | isolate\_->error\_function(),MessageTemplate::kDataCloneError, object)); |
|  | returnNothing<bool>(); |
|  | } |
|  | v8::Isolate\* v8\_isolate =reinterpret\_cast<v8::Isolate\*>(isolate\_); |
|  | Maybe<bool> result = |
|  | delegate\_->WriteHostObject(v8\_isolate,Utils::ToLocal(object)); |
|  | RETURN\_VALUE\_IF\_EXCEPTION(isolate\_,Nothing<bool>()); |
|  | USE(result); |
|  | DCHECK(!result.IsNothing()); |
|  | DCHECK(result.ToChecked()); |
|  | returnThrowIfOutOfMemory(); |
|  | } |
|  |  |
|  | Maybe<uint32\_t>ValueSerializer::WriteJSObjectPropertiesSlow( |
|  | DirectHandle<JSObject> object,DirectHandle<FixedArray> keys){ |
|  | uint32\_t properties\_written =0; |
|  | constuint32\_t length = keys->ulength().value(); |
|  | for(uint32\_t i =0; i < length; i++){ |
|  | DirectHandle<Object> key(keys->get(i), isolate\_); |
|  |  |
|  | PropertyKey lookup\_key(isolate\_, key); |
|  | LookupIterator it(isolate\_, object, lookup\_key,LookupIterator::OWN); |
|  | DirectHandle<Object> value; |
|  | if(!Object::GetProperty(&it).ToHandle(&value))returnNothing<uint32\_t>(); |
|  |  |
|  | // If the property is no longer found, do not serialize it. |
|  | // This could happen if a getter deleted the property. |
|  | if(!it.IsFound())continue; |
|  |  |
|  | if(!WriteObject(key).FromMaybe(false)\|\| |
|  | !WriteObject(value).FromMaybe(false)){ |
|  | returnNothing<uint32\_t>(); |
|  | } |
|  |  |
|  | properties\_written++; |
|  | } |
|  | returnJust(properties\_written); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::IsHostObject(DirectHandle<JSObject> js\_object){ |
|  | if(!has\_custom\_host\_objects\_){ |
|  | returnJust<bool>(JSObject::GetEmbedderFieldCount(js\_object->map())); |
|  | } |
|  | DCHECK\_NOT\_NULL(delegate\_); |
|  |  |
|  | v8::Isolate\* v8\_isolate =reinterpret\_cast<v8::Isolate\*>(isolate\_); |
|  | Maybe<bool> result = |
|  | delegate\_->IsHostObject(v8\_isolate,Utils::ToLocal(js\_object)); |
|  | RETURN\_VALUE\_IF\_EXCEPTION(isolate\_,Nothing<bool>()); |
|  | DCHECK(!result.IsNothing()); |
|  |  |
|  | if(V8\_UNLIKELY(out\_of\_memory\_))returnThrowIfOutOfMemory(); |
|  | return result; |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::ThrowIfOutOfMemory(){ |
|  | if(out\_of\_memory\_){ |
|  | returnThrowDataCloneError(MessageTemplate::kDataCloneErrorOutOfMemory); |
|  | } |
|  | returnJust(true); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::ThrowDataCloneError( |
|  | MessageTemplate template\_index){ |
|  | returnThrowDataCloneError(template\_index, |
|  | isolate\_->factory()->empty\_string()); |
|  | } |
|  |  |
|  | Maybe<bool>ValueSerializer::ThrowDataCloneError(MessageTemplate index, |
|  | DirectHandle<Object> arg0){ |
|  | DirectHandle<String> message = |
|  | MessageFormatter::Format(isolate\_, index, base::VectorOf({arg0})); |
|  | if(delegate\_){ |
|  | delegate\_->ThrowDataCloneError(Utils::ToLocal(message)); |
|  | }else{ |
|  | isolate\_->Throw( |
|  | \*isolate\_->factory()->NewError(isolate\_->error\_function(), message)); |
|  | } |
|  | returnNothing<bool>(); |
|  | } |
|  |  |
|  | ValueDeserializer::ValueDeserializer(Isolate\* isolate, |
|  | base::Vector<constuint8\_t> data, |
|  | v8::ValueDeserializer::Delegate\*delegate) |
|  | : isolate\_(isolate), |
|  | delegate\_(delegate), |
|  | position\_(data.begin()), |
|  | end\_(data.end()), |
|  | id\_map\_(isolate->global\_handles()->Create( |
|  | ReadOnlyRoots(isolate\_).empty\_fixed\_array())){} |
|  |  |
|  | ValueDeserializer::ValueDeserializer(Isolate\* isolate,constuint8\_t\* data, |
|  | size\_t size) |
|  | : isolate\_(isolate), |
|  | delegate\_(nullptr), |
|  | position\_(data), |
|  | end\_(data + size), |
|  | id\_map\_(isolate->global\_handles()->Create( |
|  | ReadOnlyRoots(isolate\_).empty\_fixed\_array())){} |
|  |  |
|  | ValueDeserializer::~ValueDeserializer(){ |
|  | DCHECK\_LE(position\_, end\_); |
|  | GlobalHandles::Destroy(id\_map\_.location()); |
|  |  |
|  | IndirectHandle<Object> transfer\_map\_handle; |
|  | if(array\_buffer\_transfer\_map\_.ToHandle(&transfer\_map\_handle)){ |
|  | GlobalHandles::Destroy(transfer\_map\_handle.location()); |
|  | } |
|  | } |
|  |  |
|  | Maybe<bool>ValueDeserializer::ReadHeader(){ |
|  | if(position\_ < end\_ && |
|  | \*position\_ ==static\_cast<uint8\_t>(SerializationTag::kVersion)){ |
|  | ReadTag().ToChecked(); |
|  | if(!ReadVarintLoop<uint32\_t>().To(&version\_)\|\| |
|  | version\_ > kLatestVersion){ |
|  | isolate\_->Throw(\*isolate\_->factory()->NewError( |
|  | MessageTemplate::kDataCloneDeserializationVersionError)); |
|  | returnNothing<bool>(); |
|  | } |
|  | } |
|  | returnJust(true); |
|  | } |
|  |  |
|  | Maybe<SerializationTag>ValueDeserializer::PeekTag()const{ |
|  | constuint8\_t\* peek\_position = position\_; |
|  | SerializationTag tag; |
|  | do{ |
|  | if(peek\_position >= end\_)returnNothing<SerializationTag>(); |
|  | tag =static\_cast<SerializationTag>(\*peek\_position); |
|  | peek\_position++; |
|  | }while(tag ==SerializationTag::kPadding); |
|  | returnJust(tag); |
|  | } |
|  |  |
|  | voidValueDeserializer::ConsumeTag(SerializationTag peeked\_tag){ |
|  | SerializationTag actual\_tag =ReadTag().ToChecked(); |
|  | DCHECK(actual\_tag == peeked\_tag); |
|  | USE(actual\_tag); |
|  | } |
|  |  |
|  | Maybe<SerializationTag>ValueDeserializer::ReadTag(){ |
|  | SerializationTag tag; |
|  | do{ |
|  | if(position\_ >= end\_)returnNothing<SerializationTag>(); |
|  | tag =static\_cast<SerializationTag>(\*position\_); |
|  | position\_++; |
|  | }while(tag ==SerializationTag::kPadding); |
|  | returnJust(tag); |
|  | } |
|  |  |
|  | template<typename T> |
|  | Maybe<T>ValueDeserializer::ReadVarint(){ |
|  | // Reads an unsigned integer as a base-128 varint. |
|  | // The number is written, 7 bits at a time, from the least significant to the |
|  | // most significant 7 bits. Each byte, except the last, has the MSB set. |
|  | // If the varint is larger than T, any more significant bits are discarded. |
|  | // See also https://developers.google.com/protocol-buffers/docs/encoding |
|  | static\_assert(std::is\_integral\_v<T>&& std::is\_unsigned\_v<T>, |
|  | "Only unsigned integer types can be read as varints."); |
|  | if(sizeof(T)>4)returnReadVarintLoop<T>(); |
|  | auto max\_read\_position = position\_ +sizeof(T)+1; |
|  | if(V8\_UNLIKELY(max\_read\_position >= end\_))returnReadVarintLoop<T>(); |
|  | #ifdef DEBUG |
|  | // DCHECK code to make sure the manually unrolled loop yields the exact |
|  | // same end state and result. |
|  | auto previous\_position = position\_; |
|  | Maybe<T> maybe\_expected\_value =ReadVarintLoop<T>(); |
|  | // ReadVarintLoop can't return Nothing here; all such conditions have been |
|  | // checked above. |
|  | T expected\_value = maybe\_expected\_value.ToChecked(); |
|  | auto expected\_position = position\_; |
|  | position\_ = previous\_position; |
|  | #endif// DEBUG |
|  | #define EXIT\_DCHECK() \ |
|  | DCHECK\_LE(position\_, end\_); \ |
|  | DCHECK\_EQ(position\_, expected\_position); \ |
|  | DCHECK\_EQ(value, expected\_value) |
|  |  |
|  | T value =0; |
|  | #define ITERATION\_SHIFTED(shift) \ |
|  | if(shift <sizeof(T)\*8){ \ |
|  | uint8\_t byte =\*position\_; \ |
|  | position\_++; \ |
|  | if(byte <0x80){ \ |
|  | value \|=static\_cast<T>(byte)<< shift; \ |
|  | EXIT\_DCHECK(); \ |
|  | returnJust(value); \ |
|  | }else{ \ |
|  | value \|=static\_cast<T>(byte &0x7F)<< shift; \ |
|  | } \ |
|  | } |
|  | // Manually unroll the loop to achieve the best measured performance. |
|  | // This is ~15% faster than ReadVarintLoop. |
|  | ITERATION\_SHIFTED(0); |
|  | ITERATION\_SHIFTED(7); |
|  | ITERATION\_SHIFTED(14); |
|  | ITERATION\_SHIFTED(21); |
|  | ITERATION\_SHIFTED(28); |
|  |  |
|  | EXIT\_DCHECK(); |
|  | returnJust(value); |
|  | #undef ITERATION\_SHIFTED |
|  | #undef EXIT\_DCHECK |
|  | } |
|  |  |
|  | template<typename T> |
|  | Maybe<T>ValueDeserializer::ReadVarintLoop(){ |
|  | static\_assert(std::is\_integral\_v<T>&& std::is\_unsigned\_v<T>, |
|  | "Only unsigned integer types can be read as varints."); |
|  | T value =0; |
|  | unsigned shift =0; |
|  | bool has\_another\_byte; |
|  | do{ |
|  | if(position\_ >= end\_)returnNothing<T>(); |
|  | uint8\_t byte =\*position\_; |
|  | has\_another\_byte = byte &0x80; |
|  | if(V8\_LIKELY(shift <sizeof(T)\*8)){ |
|  | value \|=static\_cast<T>(byte &0x7F)<< shift; |
|  | shift +=7; |
|  | }else{ |
|  | // For consistency with the fast unrolled loop in ReadVarint we return |
|  | // after we have read size(T) + 1 bytes. |
|  | #ifdef V8\_VALUE\_DESERIALIZER\_HARD\_FAIL |
|  | CHECK(!has\_another\_byte); |
|  | #endif// V8\_VALUE\_DESERIALIZER\_HARD\_FAIL |
|  | returnJust(value); |
|  | } |
|  | position\_++; |
|  | }while(has\_another\_byte); |
|  | returnJust(value); |
|  | } |
|  |  |
|  | template<typename T> |
|  | Maybe<T>ValueDeserializer::ReadZigZag(){ |
|  | // Writes a signed integer as a varint using ZigZag encoding (i.e. 0 is |
|  | // encoded as 0, -1 as 1, 1 as 2, -2 as 3, and so on). |
|  | // See also https://developers.google.com/protocol-buffers/docs/encoding |
|  | static\_assert(std::is\_integral\_v<T>&& std::is\_signed\_v<T>, |
|  | "Only signed integer types can be read as zigzag."); |
|  | usingUnsignedT= std::make\_unsigned\_t<T>; |
|  | UnsignedT unsigned\_value; |
|  | if(!ReadVarint<UnsignedT>().To(&unsigned\_value))returnNothing<T>(); |
|  | returnJust(static\_cast<T>((unsigned\_value >>1)^ |
|  | -static\_cast<T>(unsigned\_value &1))); |
|  | } |
|  |  |
|  | template EXPORT\_TEMPLATE\_DEFINE( |
|  | V8\_EXPORT\_PRIVATE)Maybe<int32\_t>ValueDeserializer::ReadZigZag(); |
|  |  |
|  | Maybe<double>ValueDeserializer::ReadDouble(){ |
|  | // Warning: this uses host endianness. |
|  | if(sizeof(double)>static\_cast<unsigned>(end\_ - position\_)){ |
|  | returnNothing<double>(); |
|  | } |
|  | double value; |
|  | memcpy(&value, position\_,sizeof(double)); |
|  | position\_ +=sizeof(double); |
|  | if(std::isnan(value)) value = std::numeric\_limits<double>::quiet\_NaN(); |
|  | returnJust(value); |
|  | } |
|  |  |
|  | Maybe<base::Vector<constuint8\_t>>ValueDeserializer::ReadRawBytes( |
|  | size\_t size){ |
|  | if(size >static\_cast<size\_t>(end\_ - position\_)){ |
|  | returnNothing<base::Vector<constuint8\_t>>(); |
|  | } |
|  | constuint8\_t\* start = position\_; |
|  | position\_ += size; |
|  | returnJust(base::Vector<constuint8\_t>(start, size)); |
|  | } |
|  |  |
|  | Maybe<base::Vector<const base::uc16>>ValueDeserializer::ReadRawTwoBytes( |
|  | size\_t size){ |
|  | if(!IsAligned(reinterpret\_cast<uintptr\_t>(position\_),2)\|\| |
|  | size >static\_cast<size\_t>(end\_ - position\_)\|\| |
|  | size %sizeof(base::uc16)!=0){ |
|  | returnNothing<base::Vector<const base::uc16>>(); |
|  | } |
|  | const base::uc16\* start =(const base::uc16\*)(position\_); |
|  | position\_ += size; |
|  | returnJust(base::Vector<const base::uc16>(start, size /sizeof(base::uc16))); |
|  | } |
|  |  |
|  | boolValueDeserializer::ReadByte(uint8\_t\* value){ |
|  | if(static\_cast<size\_t>(end\_ - position\_)<sizeof(uint8\_t))returnfalse; |
|  | \*value =\*position\_; |
|  | position\_++; |
|  | returntrue; |
|  | } |
|  |  |
|  | boolValueDeserializer::ReadUint32(uint32\_t\* value){ |
|  | returnReadVarint<uint32\_t>().To(value); |
|  | } |
|  |  |
|  | boolValueDeserializer::ReadUint64(uint64\_t\* value){ |
|  | returnReadVarint<uint64\_t>().To(value); |
|  | } |
|  |  |
|  | boolValueDeserializer::ReadSizeT(size\_t\* value){ |
|  | uint64\_t value64; |
|  | if(!ReadVarint<uint64\_t>().To(&value64)\|\| |
|  | value64 > std::numeric\_limits<size\_t>::max()){ |
|  | returnfalse; |
|  | } |
|  | \*value =static\_cast<size\_t>(value64); |
|  | returntrue; |
|  | } |
|  |  |
|  | boolValueDeserializer::ReadDouble(double\* value){ |
|  | returnReadDouble().To(value); |
|  | } |
|  |  |
|  | boolValueDeserializer::ReadRawBytes(size\_t length,constvoid\*\* data){ |
|  | if(length >static\_cast<size\_t>(end\_ - position\_))returnfalse; |
|  | \*data = position\_; |
|  | position\_ += length; |
|  | returntrue; |
|  | } |
|  |  |
|  | voidValueDeserializer::TransferArrayBuffer( |
|  | uint32\_t transfer\_id,DirectHandle<JSArrayBuffer> array\_buffer){ |
|  | if(array\_buffer\_transfer\_map\_.is\_null()){ |
|  | array\_buffer\_transfer\_map\_ = isolate\_->global\_handles()->Create( |
|  | \*SimpleNumberDictionary::New(isolate\_,0)); |
|  | } |
|  | IndirectHandle<SimpleNumberDictionary> dictionary = |
|  | array\_buffer\_transfer\_map\_.ToHandleChecked(); |
|  | DirectHandle<SimpleNumberDictionary> new\_dictionary = |
|  | SimpleNumberDictionary::Set(isolate\_, dictionary, transfer\_id, |
|  | array\_buffer); |
|  | if(!new\_dictionary.is\_identical\_to(dictionary)){ |
|  | GlobalHandles::Destroy(dictionary.location()); |
|  | array\_buffer\_transfer\_map\_ = |
|  | isolate\_->global\_handles()->Create(\*new\_dictionary); |
|  | } |
|  | } |
|  |  |
|  | MaybeDirectHandle<Object>ValueDeserializer::ReadObjectWrapper(){ |
|  | // We had a bug which produced invalid version 13 data (see |
|  | // crbug.com/1284506). This compatibility mode tries to first read the data |
|  | // normally, and if it fails, and the version is 13, tries to read the broken |
|  | // format. |
|  | constuint8\_t\* original\_position = position\_; |
|  | suppress\_deserialization\_errors\_ =true; |
|  | MaybeDirectHandle<Object> result =ReadObject(); |
|  |  |
|  | // The deserialization code doesn't throw errors for invalid data. It throws |
|  | // errors for stack overflows, though, and in that case we won't retry. |
|  | if(result.is\_null()&& version\_ ==13&&!isolate\_->has\_exception()){ |
|  | version\_13\_broken\_data\_mode\_ =true; |
|  | position\_ = original\_position; |
|  | result =ReadObject(); |
|  | } |
|  |  |
|  | if(result.is\_null()&&!isolate\_->has\_exception()){ |
|  | isolate\_->Throw(\*isolate\_->factory()->NewError( |
|  | MessageTemplate::kDataCloneDeserializationError)); |
|  | } |
|  |  |
|  | return result; |
|  | } |
|  |  |
|  | MaybeDirectHandle<Object>ValueDeserializer::ReadObject(){ |
|  | DisallowJavascriptExecution no\_js(isolate\_); |
|  | // If we are at the end of the stack, abort. This function may recurse. |
|  | STACK\_CHECK(isolate\_,MaybeDirectHandle<Object>()); |
|  |  |
|  | MaybeDirectHandle<Object> result =ReadObjectInternal(); |
|  |  |
|  | // ArrayBufferView is special in that it consumes the value before it, even |
|  | // after format version 0. |
|  | DirectHandle<Object> object; |
|  | SerializationTag tag; |
|  | if(result.ToHandle(&object)&& V8\_UNLIKELY(IsJSArrayBuffer(\*object))&& |
|  | PeekTag().To(&tag)&& tag ==SerializationTag::kArrayBufferView){ |
|  | ConsumeTag(SerializationTag::kArrayBufferView); |
|  | result =ReadJSArrayBufferView(Cast<JSArrayBuffer>(object)); |
|  | } |
|  |  |
|  | if(result.is\_null()&&!suppress\_deserialization\_errors\_ && |
|  | !isolate\_->has\_exception()){ |
|  | isolate\_->Throw(\*isolate\_->factory()->NewError( |
|  | MessageTemplate::kDataCloneDeserializationError)); |
|  | } |
|  | #if defined(DEBUG) && defined(VERIFY\_HEAP) |
|  | if(!result.is\_null()&& v8\_flags.enable\_slow\_asserts && |
|  | v8\_flags.verify\_heap){ |
|  | Object::ObjectVerify(\*object, isolate\_); |
|  | } |
|  | #endif |
|  |  |
|  | return result; |
|  | } |
|  |  |
|  | MaybeDirectHandle<Object>ValueDeserializer::ReadObjectInternal(){ |
|  | SerializationTag tag; |
|  | if(!ReadTag().To(&tag))returnMaybeDirectHandle<Object>(); |
|  | switch(tag){ |
|  | caseSerializationTag::kVerifyObjectCount: |
|  | // Read the count and ignore it. |
|  | if(ReadVarint<uint32\_t>().IsNothing()){ |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  | returnReadObject(); |
|  | caseSerializationTag::kUndefined: |
|  | return isolate\_->factory()->undefined\_value(); |
|  | caseSerializationTag::kNull: |
|  | return isolate\_->factory()->null\_value(); |
|  | caseSerializationTag::kTrue: |
|  | return isolate\_->factory()->true\_value(); |
|  | caseSerializationTag::kFalse: |
|  | return isolate\_->factory()->false\_value(); |
|  | caseSerializationTag::kInt32:{ |
|  | Maybe<int32\_t> number =ReadZigZag<int32\_t>(); |
|  | if(number.IsNothing())returnMaybeDirectHandle<Object>(); |
|  | return isolate\_->factory()->NewNumberFromInt(number.FromJust()); |
|  | } |
|  | caseSerializationTag::kUint32:{ |
|  | Maybe<uint32\_t> number =ReadVarint<uint32\_t>(); |
|  | if(number.IsNothing())returnMaybeDirectHandle<Object>(); |
|  | return isolate\_->factory()->NewNumberFromUint(number.FromJust()); |
|  | } |
|  | caseSerializationTag::kDouble:{ |
|  | Maybe<double> number =ReadDouble(); |
|  | if(number.IsNothing())returnMaybeDirectHandle<Object>(); |
|  | return isolate\_->factory()->NewNumber(number.FromJust()); |
|  | } |
|  | caseSerializationTag::kBigInt: |
|  | returnReadBigInt(); |
|  | caseSerializationTag::kUtf8String: |
|  | returnReadUtf8String(); |
|  | caseSerializationTag::kOneByteString: |
|  | returnReadOneByteString(); |
|  | caseSerializationTag::kTwoByteString: |
|  | returnReadTwoByteString(); |
|  | caseSerializationTag::kObjectReference:{ |
|  | uint32\_t id; |
|  | if(!ReadVarint<uint32\_t>().To(&id))returnMaybeDirectHandle<Object>(); |
|  | returnGetObjectWithID(id); |
|  | } |
|  | caseSerializationTag::kBeginJSObject: |
|  | returnReadJSObject(); |
|  | caseSerializationTag::kBeginSparseJSArray: |
|  | returnReadSparseJSArray(); |
|  | caseSerializationTag::kBeginDenseJSArray: |
|  | returnReadDenseJSArray(); |
|  | caseSerializationTag::kDate: |
|  | returnReadJSDate(); |
|  | caseSerializationTag::kTrueObject: |
|  | caseSerializationTag::kFalseObject: |
|  | caseSerializationTag::kNumberObject: |
|  | caseSerializationTag::kBigIntObject: |
|  | caseSerializationTag::kStringObject: |
|  | returnReadJSPrimitiveWrapper(tag); |
|  | caseSerializationTag::kRegExp: |
|  | returnReadJSRegExp(); |
|  | caseSerializationTag::kBeginJSMap: |
|  | returnReadJSMap(); |
|  | caseSerializationTag::kBeginJSSet: |
|  | returnReadJSSet(); |
|  | caseSerializationTag::kArrayBuffer:{ |
|  | returnReadJSArrayBuffer(SharedFlag{false},ResizableFlag{false}, |
|  | /\*is\_immutable\*/false); |
|  | } |
|  | caseSerializationTag::kResizableArrayBuffer:{ |
|  | returnReadJSArrayBuffer(SharedFlag{false},ResizableFlag{true}, |
|  | /\*is\_immutable\*/false); |
|  | } |
|  | caseSerializationTag::kImmutableArrayBuffer:{ |
|  | returnReadJSArrayBuffer(SharedFlag{false},ResizableFlag{false}, |
|  | /\*is\_immutable\*/true); |
|  | } |
|  | caseSerializationTag::kSharedImmutableArrayBuffer:{ |
|  | returnReadSharedImmutableJSArrayBuffer(); |
|  | } |
|  | caseSerializationTag::kArrayBufferTransfer:{ |
|  | returnReadTransferredJSArrayBuffer(); |
|  | } |
|  | caseSerializationTag::kSharedArrayBuffer:{ |
|  | returnReadJSArrayBuffer(SharedFlag{true},ResizableFlag{false}, |
|  | /\*is\_immutable\*/false); |
|  | } |
|  | caseSerializationTag::kError: |
|  | returnReadJSError(); |
|  | #if V8\_ENABLE\_WEBASSEMBLY |
|  | caseSerializationTag::kWasmModuleTransfer: |
|  | returnReadWasmModuleTransfer(); |
|  | caseSerializationTag::kWasmMemoryTransfer: |
|  | returnReadWasmMemory(); |
|  | #endif// V8\_ENABLE\_WEBASSEMBLY |
|  | caseSerializationTag::kHostObject: |
|  | returnReadHostObject(); |
|  | caseSerializationTag::kSharedObject: |
|  | if(version\_ >=15)returnReadSharedObject(); |
|  | // If the data doesn't support shared values because it is from an older |
|  | // version, treat the tag as unknown. |
|  | \[\[fallthrough\]\]; |
|  | default: |
|  | // Before there was an explicit tag for host objects, all unknown tags |
|  | // were delegated to the host. |
|  | if(version\_ <13){ |
|  | position\_--; |
|  | returnReadHostObject(); |
|  | } |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  | } |
|  |  |
|  | MaybeDirectHandle<String>ValueDeserializer::ReadString(){ |
|  | if(version\_ <12)returnReadUtf8String(); |
|  | DirectHandle<Object> object; |
|  | if(!ReadObject().ToHandle(&object)\|\|!IsString(\*object)){ |
|  | returnMaybeDirectHandle<String>(); |
|  | } |
|  | returnCast<String>(object); |
|  | } |
|  |  |
|  | MaybeDirectHandle<BigInt>ValueDeserializer::ReadBigInt(){ |
|  | uint32\_t bitfield; |
|  | if(!ReadVarint<uint32\_t>().To(&bitfield))returnMaybeDirectHandle<BigInt>(); |
|  | size\_t bytelength =BigInt::DigitsByteLengthForBitfield(bitfield); |
|  | base::Vector<constuint8\_t> digits\_storage; |
|  | if(!ReadRawBytes(bytelength).To(&digits\_storage)){ |
|  | returnMaybeDirectHandle<BigInt>(); |
|  | } |
|  | returnBigInt::FromSerializedDigits(isolate\_, bitfield, digits\_storage); |
|  | } |
|  |  |
|  | MaybeDirectHandle<String>ValueDeserializer::ReadUtf8String( |
|  | AllocationType allocation){ |
|  | uint32\_t utf8\_length; |
|  | if(!ReadVarint<uint32\_t>().To(&utf8\_length))return{}; |
|  | // utf8\_length is checked in ReadRawBytes. |
|  | base::Vector<constuint8\_t> utf8\_bytes; |
|  | if(!ReadRawBytes(utf8\_length).To(&utf8\_bytes))return{}; |
|  | return isolate\_->factory()->NewStringFromUtf8( |
|  | base::Vector<constchar>::cast(utf8\_bytes), allocation); |
|  | } |
|  |  |
|  | MaybeDirectHandle<String>ValueDeserializer::ReadOneByteString( |
|  | AllocationType allocation){ |
|  | uint32\_t byte\_length; |
|  | base::Vector<constuint8\_t> bytes; |
|  | if(!ReadVarint<uint32\_t>().To(&byte\_length))return{}; |
|  | // byte\_length is checked in ReadRawBytes. |
|  | if(!ReadRawBytes(byte\_length).To(&bytes))return{}; |
|  | return isolate\_->factory()->NewStringFromOneByte(bytes, allocation); |
|  | } |
|  |  |
|  | MaybeDirectHandle<String>ValueDeserializer::ReadTwoByteString( |
|  | AllocationType allocation){ |
|  | uint32\_t byte\_length; |
|  | base::Vector<constuint8\_t> bytes; |
|  | if(!ReadVarint<uint32\_t>().To(&byte\_length))return{}; |
|  | // byte\_length is checked in ReadRawBytes. |
|  | if(byte\_length %sizeof(base::uc16)!=0\|\| |
|  | !ReadRawBytes(byte\_length).To(&bytes)){ |
|  | returnMaybeDirectHandle<String>(); |
|  | } |
|  |  |
|  | // Allocate an uninitialized string so that we can do a raw memcpy into the |
|  | // string on the heap (regardless of alignment). |
|  | if(byte\_length ==0)return isolate\_->factory()->empty\_string(); |
|  | DirectHandle<SeqTwoByteString> string; |
|  | if(!isolate\_->factory() |
|  | ->NewRawTwoByteString(byte\_length /sizeof(base::uc16), allocation) |
|  | .ToHandle(&string)){ |
|  | returnMaybeDirectHandle<String>(); |
|  | } |
|  |  |
|  | // Copy the bytes directly into the new string. |
|  | // Warning: this uses host endianness. |
|  | DisallowGarbageCollection no\_gc; |
|  | memcpy(string->GetChars(no\_gc), bytes.begin(), bytes.length()); |
|  | return string; |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSObject>ValueDeserializer::ReadJSObject(){ |
|  | // If we are at the end of the stack, abort. This function may recurse. |
|  | STACK\_CHECK(isolate\_,MaybeDirectHandle<JSObject>()); |
|  |  |
|  | uint32\_t id = next\_id\_++; |
|  | HandleScope scope(isolate\_); |
|  | DirectHandle<JSObject> object = |
|  | isolate\_->factory()->NewJSObject(isolate\_->object\_function()); |
|  | AddObjectWithID(id, object); |
|  |  |
|  | uint32\_t num\_properties; |
|  | uint32\_t expected\_num\_properties; |
|  | if(!ReadJSObjectProperties(object,SerializationTag::kEndJSObject,true) |
|  | .To(&num\_properties)\|\| |
|  | !ReadVarint<uint32\_t>().To(&expected\_num\_properties)\|\| |
|  | num\_properties != expected\_num\_properties){ |
|  | returnMaybeDirectHandle<JSObject>(); |
|  | } |
|  |  |
|  | DCHECK(HasObjectWithID(id)); |
|  | return scope.CloseAndEscape(object); |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSArray>ValueDeserializer::ReadSparseJSArray(){ |
|  | // If we are at the end of the stack, abort. This function may recurse. |
|  | STACK\_CHECK(isolate\_,MaybeDirectHandle<JSArray>()); |
|  |  |
|  | uint32\_t length; |
|  | if(!ReadVarint<uint32\_t>().To(&length))returnMaybeDirectHandle<JSArray>(); |
|  |  |
|  | uint32\_t id = next\_id\_++; |
|  | HandleScope scope(isolate\_); |
|  | DirectHandle<JSArray> array = |
|  | isolate\_->factory()->NewJSArray(0, TERMINAL\_FAST\_ELEMENTS\_KIND); |
|  | MAYBE\_RETURN(JSArray::SetLength(isolate\_, array, length), |
|  | MaybeDirectHandle<JSArray>()); |
|  | AddObjectWithID(id, array); |
|  |  |
|  | uint32\_t num\_properties; |
|  | uint32\_t expected\_num\_properties; |
|  | uint32\_t expected\_length; |
|  | if(!ReadJSObjectProperties(array,SerializationTag::kEndSparseJSArray,false) |
|  | .To(&num\_properties)\|\| |
|  | !ReadVarint<uint32\_t>().To(&expected\_num\_properties)\|\| |
|  | !ReadVarint<uint32\_t>().To(&expected\_length)\|\| |
|  | num\_properties != expected\_num\_properties \|\| length != expected\_length){ |
|  | returnMaybeDirectHandle<JSArray>(); |
|  | } |
|  |  |
|  | DCHECK(HasObjectWithID(id)); |
|  | return scope.CloseAndEscape(array); |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSArray>ValueDeserializer::ReadDenseJSArray(){ |
|  | // If we are at the end of the stack, abort. This function may recurse. |
|  | STACK\_CHECK(isolate\_,MaybeDirectHandle<JSArray>()); |
|  |  |
|  | // We shouldn't permit an array larger than the biggest we can request from |
|  | // V8. As an additional sanity check, since each entry will take at least one |
|  | // byte to encode, if there are fewer bytes than that we can also fail fast. |
|  | uint32\_t length; |
|  | if(!ReadVarint<uint32\_t>().To(&length)\|\| length >FixedArray::kMaxLength \|\| |
|  | length >static\_cast<size\_t>(end\_ - position\_)){ |
|  | returnMaybeDirectHandle<JSArray>(); |
|  | } |
|  |  |
|  | uint32\_t id = next\_id\_++; |
|  | HandleScope scope(isolate\_); |
|  | DirectHandle<JSArray> array = isolate\_->factory()->NewJSArray( |
|  | HOLEY\_ELEMENTS, length, length, |
|  | ArrayStorageAllocationMode::INITIALIZE\_ARRAY\_ELEMENTS\_WITH\_HOLE); |
|  | AddObjectWithID(id, array); |
|  |  |
|  | DirectHandle<FixedArray> elements(Cast<FixedArray>(array->elements()), |
|  | isolate\_); |
|  | constuint32\_t elements\_length = elements->ulength().value(); |
|  | for(uint32\_t i =0; i < length; i++){ |
|  | SerializationTag tag; |
|  | if(PeekTag().To(&tag)&& tag ==SerializationTag::kTheHole){ |
|  | ConsumeTag(SerializationTag::kTheHole); |
|  | continue; |
|  | } |
|  |  |
|  | DirectHandle<Object> element; |
|  | if(!ReadObject().ToHandle(&element))returnMaybeDirectHandle<JSArray>(); |
|  |  |
|  | // Serialization versions less than 11 encode the hole the same as |
|  | // undefined. For consistency with previous behavior, store these as the |
|  | // hole. Past version 11, undefined means undefined. |
|  | if(version\_ <11&&IsUndefined(\*element))continue; |
|  |  |
|  | // Safety check. |
|  | if(i >= elements\_length)returnMaybeDirectHandle<JSArray>(); |
|  |  |
|  | elements->set(i,\*element); |
|  | } |
|  |  |
|  | uint32\_t num\_properties; |
|  | uint32\_t expected\_num\_properties; |
|  | uint32\_t expected\_length; |
|  | if(!ReadJSObjectProperties(array,SerializationTag::kEndDenseJSArray,false) |
|  | .To(&num\_properties)\|\| |
|  | !ReadVarint<uint32\_t>().To(&expected\_num\_properties)\|\| |
|  | !ReadVarint<uint32\_t>().To(&expected\_length)\|\| |
|  | num\_properties != expected\_num\_properties \|\| length != expected\_length){ |
|  | returnMaybeDirectHandle<JSArray>(); |
|  | } |
|  |  |
|  | DCHECK(HasObjectWithID(id)); |
|  | return scope.CloseAndEscape(array); |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSDate>ValueDeserializer::ReadJSDate(){ |
|  | double value; |
|  | if(!ReadDouble().To(&value))returnMaybeDirectHandle<JSDate>(); |
|  | uint32\_t id = next\_id\_++; |
|  | DirectHandle<JSDate> date; |
|  | if(!JSDate::New(isolate\_, isolate\_->date\_function(), |
|  | isolate\_->date\_function(), value) |
|  | .ToHandle(&date)){ |
|  | returnMaybeDirectHandle<JSDate>(); |
|  | } |
|  | AddObjectWithID(id, date); |
|  | return date; |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSPrimitiveWrapper>ValueDeserializer::ReadJSPrimitiveWrapper( |
|  | SerializationTag tag){ |
|  | uint32\_t id = next\_id\_++; |
|  | DirectHandle<JSPrimitiveWrapper> value; |
|  | switch(tag){ |
|  | caseSerializationTag::kTrueObject: |
|  | value =Cast<JSPrimitiveWrapper>( |
|  | isolate\_->factory()->NewJSObject(isolate\_->boolean\_function())); |
|  | value->set\_value(ReadOnlyRoots(isolate\_).true\_value()); |
|  | break; |
|  | caseSerializationTag::kFalseObject: |
|  | value =Cast<JSPrimitiveWrapper>( |
|  | isolate\_->factory()->NewJSObject(isolate\_->boolean\_function())); |
|  | value->set\_value(ReadOnlyRoots(isolate\_).false\_value()); |
|  | break; |
|  | caseSerializationTag::kNumberObject:{ |
|  | double number; |
|  | if(!ReadDouble().To(&number)){ |
|  | returnMaybeDirectHandle<JSPrimitiveWrapper>(); |
|  | } |
|  | value =Cast<JSPrimitiveWrapper>( |
|  | isolate\_->factory()->NewJSObject(isolate\_->number\_function())); |
|  | DirectHandle<Number> number\_object = |
|  | isolate\_->factory()->NewNumber(number); |
|  | value->set\_value(\*number\_object); |
|  | break; |
|  | } |
|  | caseSerializationTag::kBigIntObject:{ |
|  | DirectHandle<BigInt> bigint; |
|  | if(!ReadBigInt().ToHandle(&bigint)){ |
|  | returnMaybeDirectHandle<JSPrimitiveWrapper>(); |
|  | } |
|  | value =Cast<JSPrimitiveWrapper>( |
|  | isolate\_->factory()->NewJSObject(isolate\_->bigint\_function())); |
|  | value->set\_value(\*bigint); |
|  | break; |
|  | } |
|  | caseSerializationTag::kStringObject:{ |
|  | DirectHandle<String> string; |
|  | if(!ReadString().ToHandle(&string)){ |
|  | returnMaybeDirectHandle<JSPrimitiveWrapper>(); |
|  | } |
|  | value =Cast<JSPrimitiveWrapper>( |
|  | isolate\_->factory()->NewJSObject(isolate\_->string\_function())); |
|  | value->set\_value(\*string); |
|  | break; |
|  | } |
|  | default: |
|  | UNREACHABLE(); |
|  | } |
|  | AddObjectWithID(id, value); |
|  | return value; |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSRegExp>ValueDeserializer::ReadJSRegExp(){ |
|  | uint32\_t id = next\_id\_++; |
|  | DirectHandle<String> pattern; |
|  | uint32\_t raw\_flags; |
|  | DirectHandle<JSRegExp> regexp; |
|  | if(!ReadString().ToHandle(&pattern)\|\| |
|  | !ReadVarint<uint32\_t>().To(&raw\_flags)){ |
|  | returnMaybeDirectHandle<JSRegExp>(); |
|  | } |
|  |  |
|  | // Ensure the deserialized flags are valid. |
|  | uint32\_t bad\_flags\_mask =static\_cast<uint32\_t>(-1)<<JSRegExp::kFlagCount; |
|  | // kLinear is accepted only with the appropriate flag. |
|  | if(!v8\_flags.enable\_experimental\_regexp\_engine){ |
|  | bad\_flags\_mask \|=JSRegExp::kLinear; |
|  | } |
|  | if((raw\_flags & bad\_flags\_mask)\|\| |
|  | !RegExp::VerifyFlags(static\_cast<regexp::Flags>(raw\_flags))\|\| |
|  | !JSRegExp::New(isolate\_, pattern,static\_cast<JSRegExp::Flags>(raw\_flags)) |
|  | .ToHandle(&regexp)){ |
|  | returnMaybeDirectHandle<JSRegExp>(); |
|  | } |
|  |  |
|  | AddObjectWithID(id, regexp); |
|  | return regexp; |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSMap>ValueDeserializer::ReadJSMap(){ |
|  | // If we are at the end of the stack, abort. This function may recurse. |
|  | STACK\_CHECK(isolate\_,MaybeDirectHandle<JSMap>()); |
|  |  |
|  | HandleScope scope(isolate\_); |
|  | uint32\_t id = next\_id\_++; |
|  | DirectHandle<JSMap>map= isolate\_->factory()->NewJSMap(); |
|  | AddObjectWithID(id,map); |
|  |  |
|  | DirectHandle<JSFunction> map\_set = isolate\_->map\_set(); |
|  | uint32\_t length =0; |
|  | while(true){ |
|  | SerializationTag tag; |
|  | if(!PeekTag().To(&tag))returnMaybeDirectHandle<JSMap>(); |
|  | if(tag ==SerializationTag::kEndJSMap){ |
|  | ConsumeTag(SerializationTag::kEndJSMap); |
|  | break; |
|  | } |
|  |  |
|  | DirectHandle<Object> args\[2\]; |
|  | if(!ReadObject().ToHandle(&args\[0\])\|\|!ReadObject().ToHandle(&args\[1\])){ |
|  | returnMaybeDirectHandle<JSMap>(); |
|  | } |
|  |  |
|  | AllowJavascriptExecution allow\_js(isolate\_); |
|  | if(Execution::Call(isolate\_, map\_set,map, base::VectorOf(args)) |
|  | .is\_null()){ |
|  | returnMaybeDirectHandle<JSMap>(); |
|  | } |
|  | length +=2; |
|  | } |
|  |  |
|  | uint32\_t expected\_length; |
|  | if(!ReadVarint<uint32\_t>().To(&expected\_length)\|\| |
|  | length != expected\_length){ |
|  | returnMaybeDirectHandle<JSMap>(); |
|  | } |
|  | DCHECK(HasObjectWithID(id)); |
|  | return scope.CloseAndEscape(map); |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSSet>ValueDeserializer::ReadJSSet(){ |
|  | // If we are at the end of the stack, abort. This function may recurse. |
|  | STACK\_CHECK(isolate\_,MaybeDirectHandle<JSSet>()); |
|  |  |
|  | HandleScope scope(isolate\_); |
|  | uint32\_t id = next\_id\_++; |
|  | DirectHandle<JSSet>set= isolate\_->factory()->NewJSSet(); |
|  | AddObjectWithID(id,set); |
|  | DirectHandle<JSFunction> set\_add = isolate\_->set\_add(); |
|  | uint32\_t length =0; |
|  | while(true){ |
|  | SerializationTag tag; |
|  | if(!PeekTag().To(&tag))returnMaybeDirectHandle<JSSet>(); |
|  | if(tag ==SerializationTag::kEndJSSet){ |
|  | ConsumeTag(SerializationTag::kEndJSSet); |
|  | break; |
|  | } |
|  |  |
|  | DirectHandle<Object> args\[1\]; |
|  | if(!ReadObject().ToHandle(&args\[0\]))returnMaybeDirectHandle<JSSet>(); |
|  |  |
|  | AllowJavascriptExecution allow\_js(isolate\_); |
|  | if(Execution::Call(isolate\_, set\_add,set, base::VectorOf(args)) |
|  | .is\_null()){ |
|  | returnMaybeDirectHandle<JSSet>(); |
|  | } |
|  | length++; |
|  | } |
|  |  |
|  | uint32\_t expected\_length; |
|  | if(!ReadVarint<uint32\_t>().To(&expected\_length)\|\| |
|  | length != expected\_length){ |
|  | returnMaybeDirectHandle<JSSet>(); |
|  | } |
|  | DCHECK(HasObjectWithID(id)); |
|  | return scope.CloseAndEscape(set); |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSArrayBuffer>ValueDeserializer::ReadJSArrayBuffer( |
|  | SharedFlag is\_shared,ResizableFlag is\_resizable,bool is\_immutable){ |
|  | uint32\_t id = next\_id\_++; |
|  | if(is\_shared){ |
|  | uint32\_t clone\_id; |
|  | Local<SharedArrayBuffer> sab\_value; |
|  | if(!ReadVarint<uint32\_t>().To(&clone\_id)\|\| delegate\_ ==nullptr\|\| |
|  | !delegate\_ |
|  | ->GetSharedArrayBufferFromId( |
|  | reinterpret\_cast<v8::Isolate\*>(isolate\_), clone\_id) |
|  | .ToLocal(&sab\_value)){ |
|  | RETURN\_EXCEPTION\_IF\_EXCEPTION(isolate\_); |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | DirectHandle<JSArrayBuffer> array\_buffer = |
|  | Utils::OpenDirectHandle(\*sab\_value); |
|  | DCHECK\_EQ(is\_shared, array\_buffer->is\_shared()); |
|  | AddObjectWithID(id, array\_buffer); |
|  |  |
|  | #if V8\_ENABLE\_WEBASSEMBLY |
|  | auto backing\_store = array\_buffer->GetBackingStore(); |
|  | if(backing\_store && backing\_store->is\_wasm\_memory()){ |
|  | JSReceiver::SetIntegrityLevel(isolate\_, array\_buffer, FROZEN, kDontThrow) |
|  | .Check(); |
|  | uint8\_t resizable\_subtag; |
|  | if(!ReadVarint<uint8\_t>().To(&resizable\_subtag))return{}; |
|  | if(resizable\_subtag == |
|  | static\_cast<uint8\_t>(WasmMemoryArrayBufferTag::kResizable)){ |
|  | array\_buffer->set\_is\_resizable\_by\_js(ResizableFlag{true}); |
|  | // GSABs don't use byte\_length getter; avoid DCHECK from firing. |
|  | array\_buffer->set\_byte\_length(0); |
|  | DirectHandle<Object> wasm\_memory\_obj; |
|  | if(!ReadObject().ToHandle(&wasm\_memory\_obj))return{}; |
|  | if(!IsWasmMemoryObject(\*wasm\_memory\_obj))return{}; |
|  | // If the WasmMemoryObject was deserialized just now, it will have set |
|  | // up the link from the ArrayBuffer already. If it was reused |
|  | // (deserialized earlier), then we need to establish a link from this |
|  | // second AB. |
|  | Object::SetProperty( |
|  | isolate\_, array\_buffer, |
|  | isolate\_->factory()->array\_buffer\_wasm\_memory\_symbol(), |
|  | wasm\_memory\_obj) |
|  | .Check(); |
|  | }elseif(resizable\_subtag == |
|  | static\_cast<uint8\_t>(WasmMemoryArrayBufferTag::kFixedLength)){ |
|  | DCHECK(!array\_buffer->is\_resizable\_by\_js()); |
|  | size\_t byte\_length; |
|  | if(!ReadVarint<size\_t>().To(&byte\_length))return{}; |
|  | if(byte\_length > array\_buffer->byte\_length())return{}; |
|  | array\_buffer->set\_byte\_length(byte\_length); |
|  | array\_buffer->set\_max\_byte\_length(byte\_length); |
|  | }else{ |
|  | return{}; |
|  | } |
|  | } |
|  | #endif// V8\_ENABLE\_WEBASSEMBLY |
|  |  |
|  | return array\_buffer; |
|  | } |
|  | size\_t byte\_length; |
|  | if(!ReadSizeT(&byte\_length)){ |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | size\_t max\_byte\_length = byte\_length; |
|  | if(is\_resizable){ |
|  | if(!ReadSizeT(&max\_byte\_length)){ |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | if(byte\_length > max\_byte\_length){ |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | } |
|  | if(byte\_length >static\_cast<size\_t>(end\_ - position\_)){ |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | MaybeDirectHandle<JSArrayBuffer> result = |
|  | isolate\_->factory()->NewJSArrayBufferAndBackingStore( |
|  | byte\_length, max\_byte\_length,InitializedFlag{false}, |
|  | is\_resizable ?ResizableFlag{true}:ResizableFlag{false}); |
|  | DirectHandle<JSArrayBuffer> array\_buffer; |
|  | if(!result.ToHandle(&array\_buffer))return result; |
|  |  |
|  | if(is\_immutable){ |
|  | array\_buffer->MakeImmutable(isolate\_); |
|  | } |
|  |  |
|  | if(byte\_length >0){ |
|  | memcpy(array\_buffer->backing\_store(), position\_, byte\_length); |
|  | } |
|  | position\_ += byte\_length; |
|  | AddObjectWithID(id, array\_buffer); |
|  | return array\_buffer; |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSArrayBuffer> |
|  | ValueDeserializer::ReadTransferredJSArrayBuffer(){ |
|  | uint32\_t id = next\_id\_++; |
|  | uint32\_t transfer\_id; |
|  | DirectHandle<SimpleNumberDictionary> transfer\_map; |
|  | if(!ReadVarint<uint32\_t>().To(&transfer\_id)\|\| |
|  | !array\_buffer\_transfer\_map\_.ToHandle(&transfer\_map)){ |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | InternalIndex index = transfer\_map->FindEntry(isolate\_, transfer\_id); |
|  | if(index.is\_not\_found()){ |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | DirectHandle<JSArrayBuffer> array\_buffer( |
|  | Cast<JSArrayBuffer>(transfer\_map->ValueAt(index)), isolate\_); |
|  | AddObjectWithID(id, array\_buffer); |
|  | return array\_buffer; |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSArrayBuffer> |
|  | ValueDeserializer::ReadSharedImmutableJSArrayBuffer(){ |
|  | uint32\_t id = next\_id\_++; |
|  | uint32\_t backing\_store\_id; |
|  | if(!ReadVarint<uint32\_t>().To(&backing\_store\_id)){ |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | if(backing\_store\_id >= shared\_immutable\_backing\_stores\_.size()){ |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | std::shared\_ptr<BackingStore> backing\_store = |
|  | shared\_immutable\_backing\_stores\_\[backing\_store\_id\]; |
|  | if(!backing\_store){ |
|  | returnMaybeDirectHandle<JSArrayBuffer>(); |
|  | } |
|  | CHECK(!backing\_store->is\_resizable\_by\_js()); |
|  | DirectHandle<JSArrayBuffer> array\_buffer = |
|  | isolate\_->factory()->NewJSArrayBuffer(std::move(backing\_store)); |
|  | array\_buffer->MakeImmutable(isolate\_); |
|  | AddObjectWithID(id, array\_buffer); |
|  | return array\_buffer; |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSArrayBufferView>ValueDeserializer::ReadJSArrayBufferView( |
|  | DirectHandle<JSArrayBuffer> buffer){ |
|  | size\_t buffer\_byte\_length = buffer->GetByteLength(); |
|  | uint8\_t tag =0; |
|  | size\_t byte\_offset =0; |
|  | size\_t byte\_length =0; |
|  | uint32\_t flags =0; |
|  | if(!ReadVarint<uint8\_t>().To(&tag)\|\|!ReadSizeT(&byte\_offset)\|\| |
|  | !ReadSizeT(&byte\_length)\|\| byte\_offset > buffer\_byte\_length \|\| |
|  | byte\_length > buffer\_byte\_length - byte\_offset){ |
|  | returnMaybeDirectHandle<JSArrayBufferView>(); |
|  | } |
|  | constbool should\_read\_flags = version\_ >=14\|\| version\_13\_broken\_data\_mode\_; |
|  | if(should\_read\_flags &&!ReadVarint<uint32\_t>().To(&flags)){ |
|  | returnMaybeDirectHandle<JSArrayBufferView>(); |
|  | } |
|  | uint32\_t id = next\_id\_++; |
|  | ExternalArrayType external\_array\_type = kExternalInt8Array; |
|  | unsigned element\_size =0; |
|  |  |
|  | switch(static\_cast<ArrayBufferViewTag>(tag)){ |
|  | caseArrayBufferViewTag::kDataView:{ |
|  | bool is\_length\_tracking =false; |
|  | bool is\_backed\_by\_rab =false; |
|  | if(!ValidateJSArrayBufferViewFlags(\*buffer, flags, is\_length\_tracking, |
|  | is\_backed\_by\_rab)){ |
|  | returnMaybeDirectHandle<JSArrayBufferView>(); |
|  | } |
|  | DirectHandle<JSDataViewOrRabGsabDataView> data\_view = |
|  | isolate\_->factory()->NewJSDataViewOrRabGsabDataView( |
|  | buffer, byte\_offset, byte\_length, is\_length\_tracking); |
|  | CHECK\_EQ(is\_backed\_by\_rab, data\_view->is\_backed\_by\_rab()); |
|  | CHECK\_EQ(is\_length\_tracking, data\_view->is\_length\_tracking()); |
|  | AddObjectWithID(id, data\_view); |
|  | return data\_view; |
|  | } |
|  | #define TYPED\_ARRAY\_CASE(Type, type, TYPE, ctype) \ |
|  | caseArrayBufferViewTag::k##Type##Array: \ |
|  | external\_array\_type = kExternal##Type##Array; \ |
|  | element\_size =sizeof(ctype); \ |
|  | break; |
|  | TYPED\_ARRAYS\_BASE(TYPED\_ARRAY\_CASE) |
|  | #undef TYPED\_ARRAY\_CASE |
|  | caseArrayBufferViewTag::kFloat16Array:{ |
|  | if(i::v8\_flags.js\_float16array){ |
|  | external\_array\_type = kExternalFloat16Array; |
|  | element\_size =sizeof(uint16\_t); |
|  | } |
|  | break; |
|  | } |
|  | } |
|  | if(element\_size ==0\|\| byte\_offset % element\_size !=0\|\| |
|  | byte\_length % element\_size !=0){ |
|  | returnMaybeDirectHandle<JSArrayBufferView>(); |
|  | } |
|  | bool is\_length\_tracking =false; |
|  | bool is\_backed\_by\_rab =false; |
|  | if(!ValidateJSArrayBufferViewFlags(\*buffer, flags, is\_length\_tracking, |
|  | is\_backed\_by\_rab)){ |
|  | returnMaybeDirectHandle<JSArrayBufferView>(); |
|  | } |
|  | DirectHandle<JSTypedArray> typed\_array = isolate\_->factory()->NewJSTypedArray( |
|  | external\_array\_type, buffer, byte\_offset, byte\_length / element\_size, |
|  | is\_length\_tracking); |
|  | CHECK\_EQ(is\_length\_tracking, typed\_array->is\_length\_tracking()); |
|  | CHECK\_EQ(is\_backed\_by\_rab, typed\_array->is\_backed\_by\_rab()); |
|  | AddObjectWithID(id, typed\_array); |
|  | return typed\_array; |
|  | } |
|  |  |
|  | boolValueDeserializer::ValidateJSArrayBufferViewFlags( |
|  | Tagged<JSArrayBuffer> buffer,uint32\_t serialized\_flags, |
|  | bool& is\_length\_tracking,bool& is\_backed\_by\_rab){ |
|  | is\_length\_tracking = |
|  | JSArrayBufferViewIsLengthTracking::decode(serialized\_flags); |
|  | is\_backed\_by\_rab =JSArrayBufferViewIsBackedByRab::decode(serialized\_flags); |
|  |  |
|  | // TODO(marja): When the version number is bumped the next time, check that |
|  | // serialized\_flags doesn't contain spurious 1-bits. |
|  |  |
|  | if(is\_backed\_by\_rab \|\| is\_length\_tracking){ |
|  | if(!buffer->is\_resizable\_by\_js()){ |
|  | returnfalse; |
|  | } |
|  | if(is\_backed\_by\_rab && buffer->is\_shared()){ |
|  | returnfalse; |
|  | } |
|  | } |
|  | // The RAB-ness of the buffer and the TA's "is\_backed\_by\_rab" need to be in |
|  | // sync. |
|  | if(buffer->is\_resizable\_by\_js()&&!buffer->is\_shared()&& |
|  | !is\_backed\_by\_rab){ |
|  | returnfalse; |
|  | } |
|  | returntrue; |
|  | } |
|  |  |
|  | MaybeDirectHandle<Object>ValueDeserializer::ReadJSError(){ |
|  | uint32\_t id = next\_id\_++; |
|  |  |
|  | #define READ\_NEXT\_ERROR\_TAG() \ |
|  | do{ \ |
|  | if(!ReadVarint<uint8\_t>().To(&tag)){ \ |
|  | returnMaybeDirectHandle<JSObject>(); \ |
|  | } \ |
|  | }while(false) |
|  |  |
|  | uint8\_t tag; |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  |  |
|  | // Read error type constructor. |
|  | DirectHandle<JSFunction> constructor; |
|  | switch(static\_cast<ErrorTag>(tag)){ |
|  | caseErrorTag::kEvalErrorPrototype: |
|  | constructor = isolate\_->eval\_error\_function(); |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  | break; |
|  | caseErrorTag::kRangeErrorPrototype: |
|  | constructor = isolate\_->range\_error\_function(); |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  | break; |
|  | caseErrorTag::kReferenceErrorPrototype: |
|  | constructor = isolate\_->reference\_error\_function(); |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  | break; |
|  | caseErrorTag::kSyntaxErrorPrototype: |
|  | constructor = isolate\_->syntax\_error\_function(); |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  | break; |
|  | caseErrorTag::kTypeErrorPrototype: |
|  | constructor = isolate\_->type\_error\_function(); |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  | break; |
|  | caseErrorTag::kUriErrorPrototype: |
|  | constructor = isolate\_->uri\_error\_function(); |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  | break; |
|  | default: |
|  | // The default prototype in the deserialization side is Error.prototype, |
|  | // so we don't have to do anything here. |
|  | constructor = isolate\_->error\_function(); |
|  | break; |
|  | } |
|  |  |
|  | // Check for message property. |
|  | DirectHandle<Object> message = isolate\_->factory()->undefined\_value(); |
|  | if(static\_cast<ErrorTag>(tag)==ErrorTag::kMessage){ |
|  | DirectHandle<String> message\_string; |
|  | if(!ReadString().ToHandle(&message\_string)){ |
|  | returnMaybeDirectHandle<JSObject>(); |
|  | } |
|  | message = message\_string; |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  | } |
|  |  |
|  | // Check for stack property. |
|  | DirectHandle<UnionOf<Undefined,String>>stack= |
|  | isolate\_->factory()->undefined\_value(); |
|  | if(static\_cast<ErrorTag>(tag)==ErrorTag::kStack){ |
|  | DirectHandle<String> stack\_string; |
|  | if(!ReadString().ToHandle(&stack\_string)){ |
|  | returnMaybeDirectHandle<JSObject>(); |
|  | } |
|  | stack= stack\_string; |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  | } |
|  |  |
|  | // Create error object before adding the cause property. |
|  | DirectHandle<JSObject> error; |
|  | DirectHandle<Object> no\_caller; |
|  | DirectHandle<Object> undefined\_options = |
|  | isolate\_->factory()->undefined\_value(); |
|  | if(!ErrorUtils::Construct(isolate\_, constructor, constructor, message, |
|  | undefined\_options, SKIP\_NONE, no\_caller, |
|  | ErrorUtils::StackTraceCollection::kDisabled) |
|  | .ToHandle(&error)){ |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  | ErrorUtils::SetFormattedStack(isolate\_, error,stack); |
|  | AddObjectWithID(id, error); |
|  |  |
|  | // Add cause property if needed. |
|  | if(static\_cast<ErrorTag>(tag)==ErrorTag::kCause){ |
|  | DirectHandle<Object> cause; |
|  | if(!ReadObject().ToHandle(&cause)){ |
|  | returnMaybeDirectHandle<JSObject>(); |
|  | } |
|  | DirectHandle<Name> cause\_string = isolate\_->factory()->cause\_string(); |
|  | if(JSObject::SetOwnPropertyIgnoreAttributes(error, cause\_string, cause, |
|  | DONT\_ENUM) |
|  | .is\_null()){ |
|  | returnMaybeDirectHandle<JSObject>(); |
|  | } |
|  | READ\_NEXT\_ERROR\_TAG(); |
|  | } |
|  |  |
|  | #undef READ\_NEXT\_ERROR\_TAG |
|  |  |
|  | if(static\_cast<ErrorTag>(tag)!=ErrorTag::kEnd){ |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  | return error; |
|  | } |
|  |  |
|  | #if V8\_ENABLE\_WEBASSEMBLY |
|  | MaybeDirectHandle<JSObject>ValueDeserializer::ReadWasmModuleTransfer(){ |
|  | uint32\_t transfer\_id =0; |
|  | Local<Value> module\_value; |
|  | if(!ReadVarint<uint32\_t>().To(&transfer\_id)\|\| delegate\_ ==nullptr\|\| |
|  | !delegate\_ |
|  | ->GetWasmModuleFromId(reinterpret\_cast<v8::Isolate\*>(isolate\_), |
|  | transfer\_id) |
|  | .ToLocal(&module\_value)){ |
|  | RETURN\_EXCEPTION\_IF\_EXCEPTION(isolate\_); |
|  | returnMaybeDirectHandle<JSObject>(); |
|  | } |
|  | uint32\_t id = next\_id\_++; |
|  | DirectHandle<JSObject> module = |
|  | Cast<JSObject>(Utils::OpenDirectHandle(\*module\_value)); |
|  | AddObjectWithID(id, module); |
|  | return module; |
|  | } |
|  |  |
|  | MaybeDirectHandle<WasmMemoryObject>ValueDeserializer::ReadWasmMemory(){ |
|  | uint32\_t id = next\_id\_++; |
|  |  |
|  | int32\_t maximum\_pages; |
|  | if(!ReadZigZag<int32\_t>().To(&maximum\_pages))return{}; |
|  |  |
|  | uint8\_t memory64\_byte; |
|  | if(!ReadByte(&memory64\_byte))return{}; |
|  | if(memory64\_byte >1)return{}; |
|  | wasm::AddressType address\_type = |
|  | memory64\_byte ? wasm::AddressType::kI64 : wasm::AddressType::kI32; |
|  |  |
|  | // Validate maximum\_pages. |
|  | size\_t max\_supported\_pages = address\_type == wasm::AddressType::kI64 |
|  | ? wasm::kSpecMaxMemory64Pages |
|  | : wasm::kSpecMaxMemory32Pages; |
|  | if(maximum\_pages !=WasmMemoryObject::kNoMaximum && |
|  | (maximum\_pages <0\|\| |
|  | static\_cast<size\_t>(maximum\_pages)> max\_supported\_pages)){ |
|  | return{}; |
|  | } |
|  |  |
|  | // To break a cycle on deserialization, we first allocate the |
|  | // \`WasmMemoryObject\`, then read the \`JSArrayBuffer\`, then link the two. |
|  | DirectHandle<WasmMemoryObject> result =WasmMemoryObject::New( |
|  | isolate\_,MaybeDirectHandle<JSArrayBuffer>{},nullptr/\\* backing store \*/, |
|  | maximum\_pages, address\_type); |
|  |  |
|  | AddObjectWithID(id, result); |
|  |  |
|  | // Now read the AB. |
|  | DirectHandle<Object> buffer\_object; |
|  | if(!ReadObjectInternal().ToHandle(&buffer\_object))return{}; |
|  | if(!IsJSArrayBuffer(\*buffer\_object))return{}; |
|  |  |
|  | DirectHandle<JSArrayBuffer> buffer =Cast<JSArrayBuffer>(buffer\_object); |
|  | if(!buffer->is\_shared())return{}; |
|  |  |
|  | // If the memory was grown in the meantime, the JSArrayBuffer we just read |
|  | // might be stale. In that case, we don't link it to the WasmMemoryObject, so |
|  | // the first access to the \`buffer\` property will create a fresh |
|  | // JSArrayBuffer with the correct length. |
|  | // We use GetByteLength() here because for resizable shared buffers, |
|  | // byte\_length() will trigger a DCHECK. |
|  | std::shared\_ptr<BackingStore> backing\_store = buffer->GetBackingStore(); |
|  | // Update the managed backing store first. |
|  | result->managed\_backing\_store()->SetManagedObject( |
|  | backing\_store, isolate\_, backing\_store->byte\_length()); |
|  | // Register the memory object in the isolate and the isolate in the global |
|  | // registry for the backing store. This must happen before we check if the |
|  | // buffer is stale. If it grows between the registration and the check, we |
|  | // will see it's stale. If it grows after the check, we will receive a |
|  | // broadcast and refresh the buffer on the next access. |
|  | backing\_store->AttachSharedWasmMemoryObject(isolate\_, result); |
|  |  |
|  | if(buffer->GetByteLength()>= backing\_store->byte\_length()){ |
|  | // Link the two. |
|  | WasmMemoryObject::SetNewBuffer(isolate\_, result, buffer); |
|  | } |
|  |  |
|  | return result; |
|  | } |
|  | #endif// V8\_ENABLE\_WEBASSEMBLY |
|  |  |
|  | namespace{ |
|  |  |
|  | // Throws a generic "deserialization failed" exception by default, unless a more |
|  | // specific exception has already been thrown. |
|  | voidThrowDeserializationExceptionIfNonePending(Isolate\* isolate){ |
|  | if(!isolate->has\_exception()){ |
|  | isolate->Throw(\*isolate->factory()->NewError( |
|  | MessageTemplate::kDataCloneDeserializationError)); |
|  | } |
|  | DCHECK(isolate->has\_exception()); |
|  | } |
|  |  |
|  | }// namespace |
|  |  |
|  | MaybeDirectHandle<HeapObject>ValueDeserializer::ReadSharedObject(){ |
|  | STACK\_CHECK(isolate\_,MaybeDirectHandle<HeapObject>()); |
|  | DCHECK\_GE(version\_,15); |
|  |  |
|  | uint32\_t shared\_object\_id; |
|  | if(!ReadVarint<uint32\_t>().To(&shared\_object\_id)){ |
|  | RETURN\_EXCEPTION\_IF\_EXCEPTION(isolate\_); |
|  | returnMaybeDirectHandle<HeapObject>(); |
|  | } |
|  |  |
|  | if(!delegate\_){ |
|  | ThrowDeserializationExceptionIfNonePending(isolate\_); |
|  | returnMaybeDirectHandle<HeapObject>(); |
|  | } |
|  |  |
|  | if(shared\_object\_conveyor\_ ==nullptr){ |
|  | const v8::SharedValueConveyor\* conveyor = delegate\_->GetSharedValueConveyor( |
|  | reinterpret\_cast<v8::Isolate\*>(isolate\_)); |
|  | if(!conveyor){ |
|  | RETURN\_EXCEPTION\_IF\_EXCEPTION(isolate\_); |
|  | returnMaybeDirectHandle<HeapObject>(); |
|  | } |
|  | shared\_object\_conveyor\_ = conveyor->private\_.get(); |
|  | } |
|  |  |
|  | DirectHandle<HeapObject> shared\_object( |
|  | shared\_object\_conveyor\_->GetPersisted(shared\_object\_id), isolate\_); |
|  | DCHECK(IsShared(\*shared\_object)); |
|  | return shared\_object; |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSObject>ValueDeserializer::ReadHostObject(){ |
|  | if(!delegate\_)returnMaybeDirectHandle<JSObject>(); |
|  | STACK\_CHECK(isolate\_,MaybeDirectHandle<JSObject>()); |
|  | uint32\_t id = next\_id\_++; |
|  | v8::Isolate\* v8\_isolate =reinterpret\_cast<v8::Isolate\*>(isolate\_); |
|  | v8::Local<v8::Object> object; |
|  | if(!delegate\_->ReadHostObject(v8\_isolate).ToLocal(&object)){ |
|  | RETURN\_EXCEPTION\_IF\_EXCEPTION(isolate\_); |
|  | returnMaybeDirectHandle<JSObject>(); |
|  | } |
|  | DirectHandle<JSObject> js\_object = |
|  | Cast<JSObject>(Utils::OpenDirectHandle(\*object)); |
|  | AddObjectWithID(id, js\_object); |
|  | return js\_object; |
|  | } |
|  |  |
|  | // Copies a vector of property values into an object, given the map that should |
|  | // be used. |
|  | staticvoidCommitProperties( |
|  | Isolate\* isolate,DirectHandle<JSObject> object,DirectHandle<Map>map, |
|  | base::Vector<constDirectHandle<Object>> properties){ |
|  | JSObject::AllocateStorageForMap(isolate, object,map); |
|  | DCHECK(!object->map()->is\_dictionary\_map()); |
|  |  |
|  | DisallowGarbageCollection no\_gc; |
|  | Tagged<DescriptorArray> descriptors = object->map()->instance\_descriptors(); |
|  | for(InternalIndex i :InternalIndex::Range(properties.size())){ |
|  | // Initializing store. |
|  | object->WriteToField(i, descriptors->GetDetails(i), |
|  | \*properties\[i.raw\_value()\]); |
|  | } |
|  | } |
|  |  |
|  | staticboolIsValidObjectKey(Tagged<Object> value,Isolate\* isolate){ |
|  | if(IsSmi(value))returntrue; |
|  | auto instance\_type =Cast<HeapObject>(value)->map()->instance\_type(); |
|  | returnInstanceTypeChecker::IsName(instance\_type)\|\| |
|  | InstanceTypeChecker::IsHeapNumber(instance\_type); |
|  | } |
|  |  |
|  | Maybe<uint32\_t>ValueDeserializer::ReadJSObjectProperties( |
|  | DirectHandle<JSObject> object,SerializationTag end\_tag, |
|  | bool can\_use\_transitions){ |
|  | uint32\_t num\_properties =0; |
|  |  |
|  | // Fast path (following map transitions). |
|  | if(can\_use\_transitions){ |
|  | bool transitioning =true; |
|  | DirectHandle<Map>map(object->map(), isolate\_); |
|  | DCHECK(!map->is\_dictionary\_map()); |
|  | DCHECK\_EQ(0,map->instance\_descriptors()->number\_of\_descriptors()); |
|  | DirectHandleVector<Object> properties(isolate\_); |
|  | properties.reserve(8); |
|  |  |
|  | while(transitioning){ |
|  | // If there are no more properties, finish. |
|  | SerializationTag tag; |
|  | if(!PeekTag().To(&tag))returnNothing<uint32\_t>(); |
|  | if(tag == end\_tag){ |
|  | ConsumeTag(end\_tag); |
|  | CommitProperties(isolate\_, object,map, base::VectorOf(properties)); |
|  | CHECK\_LT(properties.size(), std::numeric\_limits<uint32\_t>::max()); |
|  | returnJust(static\_cast<uint32\_t>(properties.size())); |
|  | } |
|  |  |
|  | // Determine the key to be used and the target map to transition to, if |
|  | // possible. Transitioning may abort if the key is not a string, or if no |
|  | // transition was found. |
|  | DirectHandle<Object> key; |
|  | DirectHandle<Map> target; |
|  | bool transition\_was\_found =false; |
|  | constuint8\_t\* start\_position = position\_; |
|  | uint32\_t byte\_length; |
|  | if(!ReadTag().To(&tag)\|\|!ReadVarint<uint32\_t>().To(&byte\_length)){ |
|  | returnNothing<uint32\_t>(); |
|  | } |
|  | // Length is also checked in ReadRawBytes. |
|  | #ifdef V8\_VALUE\_DESERIALIZER\_HARD\_FAIL |
|  | CHECK\_LE(byte\_length, |
|  | static\_cast<uint32\_t>(std::numeric\_limits<int32\_t>::max())); |
|  | #endif// V8\_VALUE\_DESERIALIZER\_HARD\_FAIL |
|  | std::pair<DirectHandle<String>,DirectHandle<Map>> expected\_transition; |
|  | { |
|  | TransitionsAccessor transitions(isolate\_,\*map); |
|  | if(tag ==SerializationTag::kOneByteString){ |
|  | base::Vector<constuint8\_t> key\_chars; |
|  | if(ReadRawBytes(byte\_length).To(&key\_chars)){ |
|  | expected\_transition = transitions.ExpectedTransition(key\_chars); |
|  | } |
|  | }elseif(tag ==SerializationTag::kTwoByteString){ |
|  | base::Vector<const base::uc16> key\_chars; |
|  | if(ReadRawTwoBytes(byte\_length).To(&key\_chars)){ |
|  | expected\_transition = transitions.ExpectedTransition(key\_chars); |
|  | } |
|  | }elseif(tag ==SerializationTag::kUtf8String){ |
|  | base::Vector<constuint8\_t> key\_chars; |
|  | if(ReadRawBytes(byte\_length).To(&key\_chars)&& |
|  | String::IsAscii(key\_chars.begin(), key\_chars.length())){ |
|  | expected\_transition = transitions.ExpectedTransition(key\_chars); |
|  | } |
|  | } |
|  | if(!expected\_transition.first.is\_null()){ |
|  | transition\_was\_found =true; |
|  | key = expected\_transition.first; |
|  | target = expected\_transition.second; |
|  | } |
|  | } |
|  | if(!transition\_was\_found){ |
|  | position\_ = start\_position; |
|  | if(!ReadObject().ToHandle(&key)\|\|!IsValidObjectKey(\*key, isolate\_)){ |
|  | returnNothing<uint32\_t>(); |
|  | } |
|  | if(IsString(\*key)){ |
|  | key = isolate\_->factory()->InternalizeString(Cast<String>(key)); |
|  | // Don't reuse \|transitions\| because it could be stale. |
|  | transitioning =TransitionsAccessor(isolate\_,\*map) |
|  | .FindTransitionToField(Cast<String>(key)) |
|  | .ToHandle(&target); |
|  | }else{ |
|  | transitioning =false; |
|  | } |
|  | } |
|  |  |
|  | // Read the value that corresponds to it. |
|  | DirectHandle<Object> value; |
|  | if(!ReadObject().ToHandle(&value))returnNothing<uint32\_t>(); |
|  |  |
|  | // If still transitioning and the value fits the field representation |
|  | // (though generalization may be required), store the property value so |
|  | // that we can copy them all at once. Otherwise, stop transitioning. |
|  | if(transitioning){ |
|  | // Deserializaton of \|value\| might have deprecated current \|target\|, |
|  | // ensure we are working with the up-to-date version. |
|  | target =Map::Update(isolate\_, target); |
|  | if(!target->is\_dictionary\_map()){ |
|  | InternalIndex descriptor(properties.size()); |
|  | PropertyDetails details = |
|  | target->instance\_descriptors()->GetDetails(descriptor); |
|  | Representation expected\_representation = details.representation(); |
|  | if(Object::FitsRepresentation(\*value, expected\_representation)){ |
|  | if(expected\_representation.IsHeapObject()&& |
|  | !FieldType::NowContains( |
|  | target->instance\_descriptors()->GetFieldType(descriptor), |
|  | value)){ |
|  | DirectHandle<FieldType> value\_type =Object::OptimalType( |
|  | \*value, isolate\_, expected\_representation); |
|  | MapUpdater::GeneralizeField(isolate\_, target, descriptor, |
|  | details.constness(), |
|  | expected\_representation, value\_type); |
|  | } |
|  | DCHECK(FieldType::NowContains( |
|  | target->instance\_descriptors()->GetFieldType(descriptor), |
|  | value)); |
|  | properties.push\_back(value); |
|  | map= target; |
|  | continue; |
|  | } |
|  | } |
|  | transitioning =false; |
|  | } |
|  |  |
|  | // Fell out of transitioning fast path. Commit the properties gathered so |
|  | // far, and then start setting properties slowly instead. |
|  | DCHECK(!transitioning); |
|  | CHECK\_LT(properties.size(), std::numeric\_limits<uint32\_t>::max()); |
|  | CHECK(!map->is\_dictionary\_map()); |
|  | CommitProperties(isolate\_, object,map, base::VectorOf(properties)); |
|  | num\_properties =static\_cast<uint32\_t>(properties.size()); |
|  |  |
|  | // We checked earlier that IsValidObjectKey(key). |
|  | PropertyKey lookup\_key(isolate\_, key); |
|  | LookupIterator it(isolate\_, object, lookup\_key,LookupIterator::OWN); |
|  | if(it.state()!=LookupIterator::NOT\_FOUND \|\| |
|  | JSObject::DefineOwnPropertyIgnoreAttributes(&it, value, NONE) |
|  | .is\_null()){ |
|  | returnNothing<uint32\_t>(); |
|  | } |
|  | num\_properties++; |
|  | } |
|  |  |
|  | // At this point, transitioning should be done, but at least one property |
|  | // should have been written (in the zero-property case, there is an early |
|  | // return). |
|  | DCHECK(!transitioning); |
|  | DCHECK\_GE(num\_properties,1u); |
|  | } |
|  |  |
|  | // Slow path. |
|  | for(;; num\_properties++){ |
|  | SerializationTag tag; |
|  | if(!PeekTag().To(&tag))returnNothing<uint32\_t>(); |
|  | if(tag == end\_tag){ |
|  | ConsumeTag(end\_tag); |
|  | returnJust(num\_properties); |
|  | } |
|  |  |
|  | DirectHandle<Object> key; |
|  | if(!ReadObject().ToHandle(&key)\|\|!IsValidObjectKey(\*key, isolate\_)){ |
|  | returnNothing<uint32\_t>(); |
|  | } |
|  | DirectHandle<Object> value; |
|  | if(!ReadObject().ToHandle(&value))returnNothing<uint32\_t>(); |
|  |  |
|  | // We checked earlier that IsValidObjectKey(key). |
|  | PropertyKey lookup\_key(isolate\_, key); |
|  | LookupIterator it(isolate\_, object, lookup\_key,LookupIterator::OWN); |
|  | if(it.state()!=LookupIterator::NOT\_FOUND \|\| |
|  | JSObject::DefineOwnPropertyIgnoreAttributes(&it, value, NONE) |
|  | .is\_null()){ |
|  | returnNothing<uint32\_t>(); |
|  | } |
|  | } |
|  | } |
|  |  |
|  | boolValueDeserializer::HasObjectWithID(uint32\_t id){ |
|  | return id < id\_map\_->ulength().value()&&!IsTheHole(id\_map\_->get(id)); |
|  | } |
|  |  |
|  | MaybeDirectHandle<JSReceiver>ValueDeserializer::GetObjectWithID(uint32\_t id){ |
|  | if(id >= id\_map\_->ulength().value()){ |
|  | returnMaybeDirectHandle<JSReceiver>(); |
|  | } |
|  | Tagged<Object> value = id\_map\_->get(id); |
|  | if(IsTheHole(value))returnMaybeDirectHandle<JSReceiver>(); |
|  | DCHECK(IsJSReceiver(value)); |
|  | returnDirectHandle<JSReceiver>(Cast<JSReceiver>(value), isolate\_); |
|  | } |
|  |  |
|  | voidValueDeserializer::AddObjectWithID(uint32\_t id, |
|  | DirectHandle<JSReceiver> object){ |
|  | DCHECK(!HasObjectWithID(id)); |
|  | DirectHandle<FixedArray> new\_array = |
|  | FixedArray::SetAndGrow(isolate\_, id\_map\_, id, object); |
|  |  |
|  | // If the dictionary was reallocated, update the global handle. |
|  | if(!new\_array.is\_identical\_to(id\_map\_)){ |
|  | GlobalHandles::Destroy(id\_map\_.location()); |
|  | id\_map\_ = isolate\_->global\_handles()->Create(\*new\_array); |
|  | } |
|  | } |
|  |  |
|  | staticMaybe<bool>SetPropertiesFromKeyValuePairs(Isolate\* isolate, |
|  | DirectHandle<JSObject> object, |
|  | DirectHandle<Object>\* data, |
|  | uint32\_t num\_properties){ |
|  | for(unsigned i =0; i <2\* num\_properties; i +=2){ |
|  | DirectHandle<Object> key = data\[i\]; |
|  | if(!IsValidObjectKey(\*key, isolate))returnNothing<bool>(); |
|  | DirectHandle<Object> value = data\[i +1\]; |
|  | PropertyKey lookup\_key(isolate, key); |
|  | LookupIterator it(isolate, object, lookup\_key,LookupIterator::OWN); |
|  | if(it.state()!=LookupIterator::NOT\_FOUND \|\| |
|  | JSObject::DefineOwnPropertyIgnoreAttributes(&it, value, NONE) |
|  | .is\_null()){ |
|  | returnNothing<bool>(); |
|  | } |
|  | } |
|  | returnJust(true); |
|  | } |
|  |  |
|  | MaybeDirectHandle<Object> |
|  | ValueDeserializer::ReadObjectUsingEntireBufferForLegacyFormat(){ |
|  | DCHECK\_EQ(version\_,0u); |
|  | HandleScope scope(isolate\_); |
|  | DirectHandleVector<Object>stack(isolate\_); |
|  | while(position\_ < end\_){ |
|  | SerializationTag tag; |
|  | if(!PeekTag().To(&tag))break; |
|  |  |
|  | DirectHandle<Object> new\_object; |
|  | switch(tag){ |
|  | caseSerializationTag::kEndJSObject:{ |
|  | ConsumeTag(SerializationTag::kEndJSObject); |
|  |  |
|  | // JS Object: Read the last 2\*n values from the stack and use them as |
|  | // key-value pairs. |
|  | uint32\_t num\_properties; |
|  | if(!ReadVarint<uint32\_t>().To(&num\_properties)\|\| |
|  | stack.size()/2< num\_properties){ |
|  | isolate\_->Throw(\*isolate\_->factory()->NewError( |
|  | MessageTemplate::kDataCloneDeserializationError)); |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  |  |
|  | size\_t begin\_properties = |
|  | stack.size()-2\*static\_cast<size\_t>(num\_properties); |
|  | DirectHandle<JSObject> js\_object = |
|  | isolate\_->factory()->NewJSObject(isolate\_->object\_function()); |
|  | if(num\_properties && |
|  | !SetPropertiesFromKeyValuePairs( |
|  | isolate\_, js\_object,&stack\[begin\_properties\], num\_properties) |
|  | .FromMaybe(false)){ |
|  | ThrowDeserializationExceptionIfNonePending(isolate\_); |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  |  |
|  | stack.resize(begin\_properties); |
|  | new\_object = js\_object; |
|  | break; |
|  | } |
|  | caseSerializationTag::kEndSparseJSArray:{ |
|  | ConsumeTag(SerializationTag::kEndSparseJSArray); |
|  |  |
|  | // Sparse JS Array: Read the last 2\*\|num\_properties\| from the stack. |
|  | uint32\_t num\_properties; |
|  | uint32\_t length; |
|  | if(!ReadVarint<uint32\_t>().To(&num\_properties)\|\| |
|  | !ReadVarint<uint32\_t>().To(&length)\|\| |
|  | stack.size()/2< num\_properties){ |
|  | isolate\_->Throw(\*isolate\_->factory()->NewError( |
|  | MessageTemplate::kDataCloneDeserializationError)); |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  |  |
|  | DirectHandle<JSArray> js\_array = |
|  | isolate\_->factory()->NewJSArray(0, TERMINAL\_FAST\_ELEMENTS\_KIND); |
|  | MAYBE\_RETURN\_NULL(JSArray::SetLength(isolate\_, js\_array, length)); |
|  | size\_t begin\_properties = |
|  | stack.size()-2\*static\_cast<size\_t>(num\_properties); |
|  | if(num\_properties && |
|  | !SetPropertiesFromKeyValuePairs( |
|  | isolate\_, js\_array,&stack\[begin\_properties\], num\_properties) |
|  | .FromMaybe(false)){ |
|  | ThrowDeserializationExceptionIfNonePending(isolate\_); |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  |  |
|  | stack.resize(begin\_properties); |
|  | new\_object = js\_array; |
|  | break; |
|  | } |
|  | caseSerializationTag::kEndDenseJSArray:{ |
|  | // This was already broken in Chromium, and apparently wasn't missed. |
|  | isolate\_->Throw(\*isolate\_->factory()->NewError( |
|  | MessageTemplate::kDataCloneDeserializationError)); |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  | default: |
|  | if(!ReadObject().ToHandle(&new\_object)){ |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  | break; |
|  | } |
|  | stack.push\_back(new\_object); |
|  | } |
|  |  |
|  | // Nothing remains but padding. |
|  | #ifdef DEBUG |
|  | while(position\_ < end\_){ |
|  | DCHECK(\*position\_++==static\_cast<uint8\_t>(SerializationTag::kPadding)); |
|  | } |
|  | #endif |
|  | position\_ = end\_; |
|  |  |
|  | if(stack.size()!=1){ |
|  | isolate\_->Throw(\*isolate\_->factory()->NewError( |
|  | MessageTemplate::kDataCloneDeserializationError)); |
|  | returnMaybeDirectHandle<Object>(); |
|  | } |
|  | return scope.CloseAndEscape(stack\[0\]); |
|  | } |
|  |  |
|  | }// namespace internal |
|  | }// namespace v8 |
