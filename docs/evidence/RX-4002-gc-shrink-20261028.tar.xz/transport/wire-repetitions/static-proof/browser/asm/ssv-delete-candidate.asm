
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010192d27c <_sfv$cxxbridge1$199$decode_dictionary>:
1019ca0c8: d10143ff    	sub	sp, sp, #0x50
1019ca0cc: a9015ff8    	stp	x24, x23, [sp, #0x10]
1019ca0d0: a90257f6    	stp	x22, x21, [sp, #0x20]
1019ca0d4: a9034ff4    	stp	x20, x19, [sp, #0x30]
1019ca0d8: a9047bfd    	stp	x29, x30, [sp, #0x40]
1019ca0dc: 910103fd    	add	x29, sp, #0x40
1019ca0e0: aa0003f3    	mov	x19, x0
1019ca0e4: 3945c008    	ldrb	w8, [x0, #0x170]
1019ca0e8: 34000108    	cbz	w8, 0x1019ca108 <_sfv$cxxbridge1$199$decode_dictionary+0x9ce8c>
1019ca0ec: f9400a68    	ldr	x8, [x19, #0x10]
1019ca0f0: b40000c8    	cbz	x8, 0x1019ca108 <_sfv$cxxbridge1$199$decode_dictionary+0x9ce8c>
1019ca0f4: f940b669    	ldr	x9, [x19, #0x168]
1019ca0f8: 529f8c0a    	mov	w10, #0xfc60            ; =64608
1019ca0fc: cb0803e1    	neg	x1, x8
1019ca100: 8b0a0120    	add	x0, x9, x10
1019ca104: 979c5d5f    	bl	0x1000e1680 <_cxxbridge1$slice$new+0x9bba4>
1019ca108: f940b660    	ldr	x0, [x19, #0x168]
1019ca10c: 925e7408    	and	x8, x0, #0xfffffffc00000000
1019ca110: d0042c49    	adrp	x9, 0x109f54000 <dyld_stub_binder+0x109f54000>
1019ca114: f945c529    	ldr	x9, [x9, #0xb88]
1019ca118: eb09011f    	cmp	x8, x9
1019ca11c: 54000041    	b.ne	0x1019ca124 <_sfv$cxxbridge1$199$decode_dictionary+0x9cea8>
1019ca120: 979977bc    	bl	0x100028010 <__text+0x24010>
1019ca124: f900b67f    	str	xzr, [x19, #0x168]
1019ca128: 39458268    	ldrb	w8, [x19, #0x160]
1019ca12c: 35002228    	cbnz	w8, 0x1019ca570 <_sfv$cxxbridge1$199$decode_dictionary+0x9d2f4>
1019ca130: f940a268    	ldr	x8, [x19, #0x140]
1019ca134: b5001e08    	cbnz	x8, 0x1019ca4f4 <_sfv$cxxbridge1$199$decode_dictionary+0x9d278>
1019ca138: f9409a60    	ldr	x0, [x19, #0x130]
1019ca13c: b5001c40    	cbnz	x0, 0x1019ca4c4 <_sfv$cxxbridge1$199$decode_dictionary+0x9d248>
1019ca140: b9411e68    	ldr	w8, [x19, #0x11c]
1019ca144: f9408a74    	ldr	x20, [x19, #0x110]
1019ca148: 35001808    	cbnz	w8, 0x1019ca448 <_sfv$cxxbridge1$199$decode_dictionary+0x9d1cc>
1019ca14c: 91048268    	add	x8, x19, #0x120
1019ca150: eb08029f    	cmp	x20, x8
1019ca154: 54002141    	b.ne	0x1019ca57c <_sfv$cxxbridge1$199$decode_dictionary+0x9d300>
1019ca158: aa1303e0    	mov	x0, x19
1019ca15c: f84f0c01    	ldr	x1, [x0, #0xf0]!
1019ca160: f900101f    	str	xzr, [x0, #0x20]
1019ca164: b9400c08    	ldr	w8, [x0, #0xc]
1019ca168: 35001828    	cbnz	w8, 0x1019ca46c <_sfv$cxxbridge1$199$decode_dictionary+0x9d1f0>
1019ca16c: 91040268    	add	x8, x19, #0x100
1019ca170: eb08003f    	cmp	x1, x8
1019ca174: 54001ee1    	b.ne	0x1019ca550 <_sfv$cxxbridge1$199$decode_dictionary+0x9d2d4>
1019ca178: f9007a7f    	str	xzr, [x19, #0xf0]
1019ca17c: f9407268    	ldr	x8, [x19, #0xe0]
1019ca180: b5000f48    	cbnz	x8, 0x1019ca368 <_sfv$cxxbridge1$199$decode_dictionary+0x9d0ec>
1019ca184: f9406660    	ldr	x0, [x19, #0xc8]
1019ca188: b5002020    	cbnz	x0, 0x1019ca58c <_sfv$cxxbridge1$199$decode_dictionary+0x9d310>
1019ca18c: f9405e60    	ldr	x0, [x19, #0xb8]
1019ca190: b5000aa0    	cbnz	x0, 0x1019ca2e4 <_sfv$cxxbridge1$199$decode_dictionary+0x9d068>
1019ca194: f9405668    	ldr	x8, [x19, #0xa8]
1019ca198: b5001148    	cbnz	x8, 0x1019ca3c0 <_sfv$cxxbridge1$199$decode_dictionary+0x9d144>
1019ca19c: aa1303e0    	mov	x0, x19
1019ca1a0: f8458c01    	ldr	x1, [x0, #0x58]!
1019ca1a4: b9400c08    	ldr	w8, [x0, #0xc]
1019ca1a8: 35000708    	cbnz	w8, 0x1019ca288 <_sfv$cxxbridge1$199$decode_dictionary+0x9d00c>
1019ca1ac: 9101a268    	add	x8, x19, #0x68
1019ca1b0: eb08003f    	cmp	x1, x8
1019ca1b4: 54001d21    	b.ne	0x1019ca558 <_sfv$cxxbridge1$199$decode_dictionary+0x9d2dc>
1019ca1b8: aa1303e0    	mov	x0, x19
1019ca1bc: f8440c01    	ldr	x1, [x0, #0x40]!
1019ca1c0: f9000c1f    	str	xzr, [x0, #0x18]
1019ca1c4: b9400c08    	ldr	w8, [x0, #0xc]
1019ca1c8: 35000348    	cbnz	w8, 0x1019ca230 <_sfv$cxxbridge1$199$decode_dictionary+0x9cfb4>
1019ca1cc: 91014268    	add	x8, x19, #0x50
1019ca1d0: eb08003f    	cmp	x1, x8
1019ca1d4: 54001c61    	b.ne	0x1019ca560 <_sfv$cxxbridge1$199$decode_dictionary+0x9d2e4>
1019ca1d8: aa1303e0    	mov	x0, x19
1019ca1dc: f8420c01    	ldr	x1, [x0, #0x20]!
1019ca1e0: f900101f    	str	xzr, [x0, #0x20]
1019ca1e4: b9400c08    	ldr	w8, [x0, #0xc]
1019ca1e8: 35001588    	cbnz	w8, 0x1019ca498 <_sfv$cxxbridge1$199$decode_dictionary+0x9d21c>
1019ca1ec: 9100c268    	add	x8, x19, #0x30
1019ca1f0: eb08003f    	cmp	x1, x8
1019ca1f4: 54001ba1    	b.ne	0x1019ca568 <_sfv$cxxbridge1$199$decode_dictionary+0x9d2ec>
1019ca1f8: f900127f    	str	xzr, [x19, #0x20]
1019ca1fc: f9400661    	ldr	x1, [x19, #0x8]
1019ca200: f900067f    	str	xzr, [x19, #0x8]
1019ca204: b4000081    	cbz	x1, 0x1019ca214 <_sfv$cxxbridge1$199$decode_dictionary+0x9cf98>
1019ca208: 900443c8    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
1019ca20c: f946ed00    	ldr	x0, [x8, #0xdd8]
1019ca210: 97994d30    	bl	0x10001d6d0 <__text+0x196d0>
1019ca214: aa1303e0    	mov	x0, x19
1019ca218: a9447bfd    	ldp	x29, x30, [sp, #0x40]
1019ca21c: a9434ff4    	ldp	x20, x19, [sp, #0x30]
1019ca220: a94257f6    	ldp	x22, x21, [sp, #0x20]
1019ca224: a9415ff8    	ldp	x24, x23, [sp, #0x10]
1019ca228: 910143ff    	add	sp, sp, #0x50
1019ca22c: d65f03c0    	ret
1019ca230: aa0103f5    	mov	x21, x1
1019ca234: aa0003f4    	mov	x20, x0
1019ca238: d37df116    	lsl	x22, x8, #3
1019ca23c: 12800017    	mov	w23, #-0x1              ; =-1
1019ca240: 14000007    	b	0x1019ca25c <_sfv$cxxbridge1$199$decode_dictionary+0x9cfe0>
1019ca244: f9400008    	ldr	x8, [x0]
1019ca248: f9400508    	ldr	x8, [x8, #0x8]
1019ca24c: d63f0100    	blr	x8
1019ca250: 910022b5    	add	x21, x21, #0x8
1019ca254: f10022d6    	subs	x22, x22, #0x8
1019ca258: 54000100    	b.eq	0x1019ca278 <_sfv$cxxbridge1$199$decode_dictionary+0x9cffc>
1019ca25c: f94002a0    	ldr	x0, [x21]
1019ca260: b4ffff80    	cbz	x0, 0x1019ca250 <_sfv$cxxbridge1$199$decode_dictionary+0x9cfd4>
1019ca264: 91002008    	add	x8, x0, #0x8
1019ca268: b8f70108    	ldaddal	w23, w8, [x8]
1019ca26c: 7100051f    	cmp	w8, #0x1
1019ca270: 54ffff01    	b.ne	0x1019ca250 <_sfv$cxxbridge1$199$decode_dictionary+0x9cfd4>
1019ca274: 17fffff4    	b	0x1019ca244 <_sfv$cxxbridge1$199$decode_dictionary+0x9cfc8>
1019ca278: f9402261    	ldr	x1, [x19, #0x40]
1019ca27c: b9004e7f    	str	wzr, [x19, #0x4c]
1019ca280: aa1403e0    	mov	x0, x20
1019ca284: 17ffffd2    	b	0x1019ca1cc <_sfv$cxxbridge1$199$decode_dictionary+0x9cf50>
1019ca288: aa0003f5    	mov	x21, x0
1019ca28c: d37ae516    	lsl	x22, x8, #6
1019ca290: 9100e034    	add	x20, x1, #0x38
1019ca294: 12800017    	mov	w23, #-0x1              ; =-1
1019ca298: 14000007    	b	0x1019ca2b4 <_sfv$cxxbridge1$199$decode_dictionary+0x9d038>
1019ca29c: 9452de4f    	bl	0x102e81bd8 <_media$cxxbridge1$199$init_symphonia_decoder+0x28b188>
1019ca2a0: 52800401    	mov	w1, #0x20               ; =32
1019ca2a4: 9798f4dd    	bl	0x100007618 <__text+0x3618>
1019ca2a8: 91010294    	add	x20, x20, #0x40
1019ca2ac: f10102d6    	subs	x22, x22, #0x40
1019ca2b0: 54000120    	b.eq	0x1019ca2d4 <_sfv$cxxbridge1$199$decode_dictionary+0x9d058>
1019ca2b4: aa1403e0    	mov	x0, x20
1019ca2b8: 97e6d0cd    	bl	0x10137e5ec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x524b44>
1019ca2bc: f85f8280    	ldur	x0, [x20, #-0x8]
1019ca2c0: b4ffff40    	cbz	x0, 0x1019ca2a8 <_sfv$cxxbridge1$199$decode_dictionary+0x9d02c>
1019ca2c4: b8f70008    	ldaddal	w23, w8, [x0]
1019ca2c8: 7100051f    	cmp	w8, #0x1
1019ca2cc: 54fffee1    	b.ne	0x1019ca2a8 <_sfv$cxxbridge1$199$decode_dictionary+0x9d02c>
1019ca2d0: 17fffff3    	b	0x1019ca29c <_sfv$cxxbridge1$199$decode_dictionary+0x9d020>
1019ca2d4: f9402e61    	ldr	x1, [x19, #0x58]
1019ca2d8: b900667f    	str	wzr, [x19, #0x64]
1019ca2dc: aa1503e0    	mov	x0, x21
1019ca2e0: 17ffffb3    	b	0x1019ca1ac <_sfv$cxxbridge1$199$decode_dictionary+0x9cf30>
1019ca2e4: b940c668    	ldr	w8, [x19, #0xc4]
1019ca2e8: 340003a8    	cbz	w8, 0x1019ca35c <_sfv$cxxbridge1$199$decode_dictionary+0x9d0e0>
1019ca2ec: 8b080908    	add	x8, x8, x8, lsl #2
1019ca2f0: d37df115    	lsl	x21, x8, #3
1019ca2f4: 91008016    	add	x22, x0, #0x20
1019ca2f8: 92800017    	mov	x23, #-0x1              ; =-1
1019ca2fc: 1400000a    	b	0x1019ca324 <_sfv$cxxbridge1$199$decode_dictionary+0x9d0a8>
1019ca300: f9400288    	ldr	x8, [x20]
1019ca304: f9400908    	ldr	x8, [x8, #0x10]
1019ca308: aa1403e0    	mov	x0, x20
1019ca30c: d63f0100    	blr	x8
1019ca310: aa1403e0    	mov	x0, x20
1019ca314: 94171743    	bl	0x101f90020 <_rust_png$cxxbridge1$199$Reader$has_trns_chunk+0x4800>
1019ca318: 9100a2d6    	add	x22, x22, #0x28
1019ca31c: f100a2b5    	subs	x21, x21, #0x28
1019ca320: 540001a0    	b.eq	0x1019ca354 <_sfv$cxxbridge1$199$decode_dictionary+0x9d0d8>
1019ca324: 39c01ec8    	ldrsb	w8, [x22, #0x7]
1019ca328: 36f800a8    	tbz	w8, #0x1f, 0x1019ca33c <_sfv$cxxbridge1$199$decode_dictionary+0x9d0c0>
1019ca32c: f85f02c0    	ldur	x0, [x22, #-0x10]
1019ca330: f94002c8    	ldr	x8, [x22]
1019ca334: 9240f901    	and	x1, x8, #0x7fffffffffffffff
1019ca338: 9798f4b8    	bl	0x100007618 <__text+0x3618>
1019ca33c: f85e82d4    	ldur	x20, [x22, #-0x18]
1019ca340: b4fffed4    	cbz	x20, 0x1019ca318 <_sfv$cxxbridge1$199$decode_dictionary+0x9d09c>
1019ca344: 91002288    	add	x8, x20, #0x8
1019ca348: f8f70108    	ldaddal	x23, x8, [x8]
1019ca34c: b5fffe68    	cbnz	x8, 0x1019ca318 <_sfv$cxxbridge1$199$decode_dictionary+0x9d09c>
1019ca350: 17ffffec    	b	0x1019ca300 <_sfv$cxxbridge1$199$decode_dictionary+0x9d084>
1019ca354: f9405e60    	ldr	x0, [x19, #0xb8]
1019ca358: b900c67f    	str	wzr, [x19, #0xc4]
1019ca35c: 979b5549    	bl	0x10009f880 <_cxxbridge1$slice$new+0x59da4>
1019ca360: f9005e7f    	str	xzr, [x19, #0xb8]
1019ca364: 17ffff8c    	b	0x1019ca194 <_sfv$cxxbridge1$199$decode_dictionary+0x9cf18>
1019ca368: f90007e8    	str	x8, [sp, #0x8]
1019ca36c: b940ee68    	ldr	w8, [x19, #0xec]
1019ca370: 34000208    	cbz	w8, 0x1019ca3b0 <_sfv$cxxbridge1$199$decode_dictionary+0x9d134>
1019ca374: d37df114    	lsl	x20, x8, #3
1019ca378: 14000007    	b	0x1019ca394 <_sfv$cxxbridge1$199$decode_dictionary+0x9d118>
1019ca37c: 97d252ef    	bl	0x100e5ef38 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x5490>
1019ca380: f94007e8    	ldr	x8, [sp, #0x8]
1019ca384: 91002108    	add	x8, x8, #0x8
1019ca388: f90007e8    	str	x8, [sp, #0x8]
1019ca38c: f1002294    	subs	x20, x20, #0x8
1019ca390: 540000a0    	b.eq	0x1019ca3a4 <_sfv$cxxbridge1$199$decode_dictionary+0x9d128>
1019ca394: f94007e8    	ldr	x8, [sp, #0x8]
1019ca398: f9400100    	ldr	x0, [x8]
1019ca39c: b4ffff20    	cbz	x0, 0x1019ca380 <_sfv$cxxbridge1$199$decode_dictionary+0x9d104>
1019ca3a0: 17fffff7    	b	0x1019ca37c <_sfv$cxxbridge1$199$decode_dictionary+0x9d100>
1019ca3a4: f9407268    	ldr	x8, [x19, #0xe0]
1019ca3a8: f90007e8    	str	x8, [sp, #0x8]
1019ca3ac: b900ee7f    	str	wzr, [x19, #0xec]
1019ca3b0: f94007e0    	ldr	x0, [sp, #0x8]
1019ca3b4: 979b5533    	bl	0x10009f880 <_cxxbridge1$slice$new+0x59da4>
1019ca3b8: f900727f    	str	xzr, [x19, #0xe0]
1019ca3bc: 17ffff72    	b	0x1019ca184 <_sfv$cxxbridge1$199$decode_dictionary+0x9cf08>
1019ca3c0: f90007e8    	str	x8, [sp, #0x8]
1019ca3c4: b940b668    	ldr	w8, [x19, #0xb4]
1019ca3c8: 34000388    	cbz	w8, 0x1019ca438 <_sfv$cxxbridge1$199$decode_dictionary+0x9d1bc>
1019ca3cc: 8b080508    	add	x8, x8, x8, lsl #1
1019ca3d0: d37df114    	lsl	x20, x8, #3
1019ca3d4: 1400000a    	b	0x1019ca3fc <_sfv$cxxbridge1$199$decode_dictionary+0x9d180>
1019ca3d8: f9400008    	ldr	x8, [x0]
1019ca3dc: f9400508    	ldr	x8, [x8, #0x8]
1019ca3e0: d63f0100    	blr	x8
1019ca3e4: f94007e0    	ldr	x0, [sp, #0x8]
1019ca3e8: 94504b6c    	bl	0x102ddd198 <_media$cxxbridge1$199$init_symphonia_decoder+0x1e6748>
1019ca3ec: 91006000    	add	x0, x0, #0x18
1019ca3f0: f90007e0    	str	x0, [sp, #0x8]
1019ca3f4: f1006294    	subs	x20, x20, #0x18
1019ca3f8: 540001a0    	b.eq	0x1019ca42c <_sfv$cxxbridge1$199$decode_dictionary+0x9d1b0>
1019ca3fc: f94007e8    	ldr	x8, [sp, #0x8]
1019ca400: f9400900    	ldr	x0, [x8, #0x10]
1019ca404: f900091f    	str	xzr, [x8, #0x10]
1019ca408: b4000080    	cbz	x0, 0x1019ca418 <_sfv$cxxbridge1$199$decode_dictionary+0x9d19c>
1019ca40c: f9400008    	ldr	x8, [x0]
1019ca410: f9400508    	ldr	x8, [x8, #0x8]
1019ca414: d63f0100    	blr	x8
1019ca418: f94007e8    	ldr	x8, [sp, #0x8]
1019ca41c: f9400500    	ldr	x0, [x8, #0x8]
1019ca420: f900051f    	str	xzr, [x8, #0x8]
1019ca424: b4fffe00    	cbz	x0, 0x1019ca3e4 <_sfv$cxxbridge1$199$decode_dictionary+0x9d168>
1019ca428: 17ffffec    	b	0x1019ca3d8 <_sfv$cxxbridge1$199$decode_dictionary+0x9d15c>
1019ca42c: f9405668    	ldr	x8, [x19, #0xa8]
1019ca430: f90007e8    	str	x8, [sp, #0x8]
1019ca434: b900b67f    	str	wzr, [x19, #0xb4]
1019ca438: f94007e0    	ldr	x0, [sp, #0x8]
1019ca43c: 979b5511    	bl	0x10009f880 <_cxxbridge1$slice$new+0x59da4>
1019ca440: f900567f    	str	xzr, [x19, #0xa8]
1019ca444: 17ffff56    	b	0x1019ca19c <_sfv$cxxbridge1$199$decode_dictionary+0x9cf20>
1019ca448: d37ced15    	lsl	x21, x8, #4
1019ca44c: aa1403e0    	mov	x0, x20
1019ca450: 944865f2    	bl	0x102be3c18 <_rust_png$cxxbridge1$199$new_writer+0x277498>
1019ca454: 91004294    	add	x20, x20, #0x10
1019ca458: f10042b5    	subs	x21, x21, #0x10
1019ca45c: 54ffff81    	b.ne	0x1019ca44c <_sfv$cxxbridge1$199$decode_dictionary+0x9d1d0>
1019ca460: f9408a74    	ldr	x20, [x19, #0x110]
1019ca464: b9011e7f    	str	wzr, [x19, #0x11c]
1019ca468: 17ffff39    	b	0x1019ca14c <_sfv$cxxbridge1$199$decode_dictionary+0x9ced0>
1019ca46c: aa0003f4    	mov	x20, x0
1019ca470: d37ced15    	lsl	x21, x8, #4
1019ca474: aa0103e0    	mov	x0, x1
1019ca478: 944865e8    	bl	0x102be3c18 <_rust_png$cxxbridge1$199$new_writer+0x277498>
1019ca47c: 91004001    	add	x1, x0, #0x10
1019ca480: f10042b5    	subs	x21, x21, #0x10
1019ca484: 54ffff81    	b.ne	0x1019ca474 <_sfv$cxxbridge1$199$decode_dictionary+0x9d1f8>
1019ca488: f9407a61    	ldr	x1, [x19, #0xf0]
1019ca48c: b900fe7f    	str	wzr, [x19, #0xfc]
1019ca490: aa1403e0    	mov	x0, x20
1019ca494: 17ffff36    	b	0x1019ca16c <_sfv$cxxbridge1$199$decode_dictionary+0x9cef0>
1019ca498: aa0003f4    	mov	x20, x0
1019ca49c: d37ced15    	lsl	x21, x8, #4
1019ca4a0: aa0103e0    	mov	x0, x1
1019ca4a4: 944865dd    	bl	0x102be3c18 <_rust_png$cxxbridge1$199$new_writer+0x277498>
1019ca4a8: 91004001    	add	x1, x0, #0x10
1019ca4ac: f10042b5    	subs	x21, x21, #0x10
1019ca4b0: 54ffff81    	b.ne	0x1019ca4a0 <_sfv$cxxbridge1$199$decode_dictionary+0x9d224>
1019ca4b4: f9401261    	ldr	x1, [x19, #0x20]
1019ca4b8: b9002e7f    	str	wzr, [x19, #0x2c]
1019ca4bc: aa1403e0    	mov	x0, x20
1019ca4c0: 17ffff4b    	b	0x1019ca1ec <_sfv$cxxbridge1$199$decode_dictionary+0x9cf70>
1019ca4c4: b9413e68    	ldr	w8, [x19, #0x13c]
1019ca4c8: 34000108    	cbz	w8, 0x1019ca4e8 <_sfv$cxxbridge1$199$decode_dictionary+0x9d26c>
1019ca4cc: d37ced14    	lsl	x20, x8, #4
1019ca4d0: 941193e5    	bl	0x101e2f464 <_cxxbridge1$string$new+0x6699c>
1019ca4d4: 91004000    	add	x0, x0, #0x10
1019ca4d8: f1004294    	subs	x20, x20, #0x10
1019ca4dc: 54ffffa1    	b.ne	0x1019ca4d0 <_sfv$cxxbridge1$199$decode_dictionary+0x9d254>
1019ca4e0: f9409a60    	ldr	x0, [x19, #0x130]
1019ca4e4: b9013e7f    	str	wzr, [x19, #0x13c]
1019ca4e8: 979b54e6    	bl	0x10009f880 <_cxxbridge1$slice$new+0x59da4>
1019ca4ec: f9009a7f    	str	xzr, [x19, #0x130]
1019ca4f0: 17ffff14    	b	0x1019ca140 <_sfv$cxxbridge1$199$decode_dictionary+0x9cec4>
1019ca4f4: f90007e8    	str	x8, [sp, #0x8]
1019ca4f8: b9414a74    	ldr	w20, [x19, #0x148]
1019ca4fc: 34000234    	cbz	w20, 0x1019ca540 <_sfv$cxxbridge1$199$decode_dictionary+0x9d2c4>
1019ca500: f94007e8    	ldr	x8, [sp, #0x8]
1019ca504: 91002115    	add	x21, x8, #0x8
1019ca508: 14000007    	b	0x1019ca524 <_sfv$cxxbridge1$199$decode_dictionary+0x9d2a8>
1019ca50c: f9400008    	ldr	x8, [x0]
1019ca510: f9400508    	ldr	x8, [x8, #0x8]
1019ca514: d63f0100    	blr	x8
1019ca518: 910042b5    	add	x21, x21, #0x10
1019ca51c: f1000694    	subs	x20, x20, #0x1
1019ca520: 54000100    	b.eq	0x1019ca540 <_sfv$cxxbridge1$199$decode_dictionary+0x9d2c4>
1019ca524: f85f82a8    	ldur	x8, [x21, #-0x8]
1019ca528: b100051f    	cmn	x8, #0x1
1019ca52c: 54ffff60    	b.eq	0x1019ca518 <_sfv$cxxbridge1$199$decode_dictionary+0x9d29c>
1019ca530: f94002a0    	ldr	x0, [x21]
1019ca534: f90002bf    	str	xzr, [x21]
1019ca538: b4ffff00    	cbz	x0, 0x1019ca518 <_sfv$cxxbridge1$199$decode_dictionary+0x9d29c>
1019ca53c: 17fffff4    	b	0x1019ca50c <_sfv$cxxbridge1$199$decode_dictionary+0x9d290>
1019ca540: f94007e0    	ldr	x0, [sp, #0x8]
1019ca544: 979b54cf    	bl	0x10009f880 <_cxxbridge1$slice$new+0x59da4>
1019ca548: f900a27f    	str	xzr, [x19, #0x140]
1019ca54c: 17fffefb    	b	0x1019ca138 <_sfv$cxxbridge1$199$decode_dictionary+0x9cebc>
1019ca550: 955ebbec    	bl	0x107179500 <__Z23_v8_internal_Node_PrintPv+0x3069ed4>
1019ca554: 17ffff09    	b	0x1019ca178 <_sfv$cxxbridge1$199$decode_dictionary+0x9cefc>
1019ca558: 97b62c2a    	bl	0x100755600 <_icu4x_Locale_destroy_mv1+0x3853c>
1019ca55c: 17ffff17    	b	0x1019ca1b8 <_sfv$cxxbridge1$199$decode_dictionary+0x9cf3c>
1019ca560: 97b62c28    	bl	0x100755600 <_icu4x_Locale_destroy_mv1+0x3853c>
1019ca564: 17ffff1d    	b	0x1019ca1d8 <_sfv$cxxbridge1$199$decode_dictionary+0x9cf5c>
1019ca568: 955ebbe6    	bl	0x107179500 <__Z23_v8_internal_Node_PrintPv+0x3069ed4>
1019ca56c: 17ffff23    	b	0x1019ca1f8 <_sfv$cxxbridge1$199$decode_dictionary+0x9cf7c>
1019ca570: 91056260    	add	x0, x19, #0x158
1019ca574: 9488041d    	bl	0x103bcb5e8 <_llg_tokenize_bytes+0x22b74c>
1019ca578: 17fffeee    	b	0x1019ca130 <_sfv$cxxbridge1$199$decode_dictionary+0x9ceb4>
1019ca57c: 91044260    	add	x0, x19, #0x110
1019ca580: aa1403e1    	mov	x1, x20
1019ca584: 955ebbdf    	bl	0x107179500 <__Z23_v8_internal_Node_PrintPv+0x3069ed4>
1019ca588: 17fffef4    	b	0x1019ca158 <_sfv$cxxbridge1$199$decode_dictionary+0x9cedc>
1019ca58c: b940d261    	ldr	w1, [x19, #0xd0]
1019ca590: 955ebb2e    	bl	0x107179248 <__Z23_v8_internal_Node_PrintPv+0x3069c1c>
1019ca594: f900667f    	str	xzr, [x19, #0xc8]
1019ca598: 17fffefd    	b	0x1019ca18c <_sfv$cxxbridge1$199$decode_dictionary+0x9cf10>
1019ca59c: 14000001    	b	0x1019ca5a0 <_sfv$cxxbridge1$199$decode_dictionary+0x9d324>
1019ca5a0: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
1019ca5a4: a9014ff4    	stp	x20, x19, [sp, #0x10]
1019ca5a8: a9027bfd    	stp	x29, x30, [sp, #0x20]
1019ca5ac: 910083fd    	add	x29, sp, #0x20
1019ca5b0: aa0003f3    	mov	x19, x0
1019ca5b4: 9100a000    	add	x0, x0, #0x28
1019ca5b8: 94000028    	bl	0x1019ca658 <_sfv$cxxbridge1$199$decode_dictionary+0x9d3dc>
1019ca5bc: f9400e74    	ldr	x20, [x19, #0x18]
