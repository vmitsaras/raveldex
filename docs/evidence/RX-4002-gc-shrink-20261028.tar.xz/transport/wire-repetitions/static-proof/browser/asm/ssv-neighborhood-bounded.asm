
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010410f62c <__Z23_v8_internal_Node_PrintPv>:
107177e40: b9400008    	ldr	w8, [x0]
107177e44: 71000509    	subs	w9, w8, #0x1
107177e48: 540000e0    	b.eq	0x107177e64 <__Z23_v8_internal_Node_PrintPv+0x3068838>
107177e4c: aa0803ea    	mov	x10, x8
107177e50: 88aafc09    	casl	w10, w9, [x0]
107177e54: 6b08015f    	cmp	w10, w8
107177e58: aa0a03e8    	mov	x8, x10
107177e5c: 54ffff41    	b.ne	0x107177e44 <__Z23_v8_internal_Node_PrintPv+0x3068818>
107177e60: 14000002    	b	0x107177e68 <__Z23_v8_internal_Node_PrintPv+0x306883c>
107177e64: 963ba6c7    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
107177e68: aa1303e0    	mov	x0, x19
107177e6c: a9467bfd    	ldp	x29, x30, [sp, #0x60]
107177e70: a9454ff4    	ldp	x20, x19, [sp, #0x50]
107177e74: 9101c3ff    	add	sp, sp, #0x70
107177e78: d65f03c0    	ret
107177e7c: d4200000    	brk	#0
107177e80: d4400000    	hlt	#0
107177e84: d4200020    	brk	#0x1
107177e88: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
107177e8c: a9014ff4    	stp	x20, x19, [sp, #0x10]
107177e90: a9027bfd    	stp	x29, x30, [sp, #0x20]
107177e94: 910083fd    	add	x29, sp, #0x20
107177e98: aa0003f3    	mov	x19, x0
107177e9c: f9400008    	ldr	x8, [x0]
107177ea0: b4000188    	cbz	x8, 0x107177ed0 <__Z23_v8_internal_Node_PrintPv+0x30688a4>
107177ea4: b9400516    	ldr	w22, [x8, #0x4]
107177ea8: d37ffad4    	lsl	x20, x22, #1
107177eac: f0018648    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
107177eb0: f946ed00    	ldr	x0, [x8, #0xdd8]
107177eb4: f0012e62    	adrp	x2, 0x109746000 <dyld_stub_binder+0x109746000>
107177eb8: 91256c42    	add	x2, x2, #0x95b
107177ebc: aa1403e1    	mov	x1, x20
107177ec0: 963a912b    	bl	0x10001c36c <__text+0x1836c>
107177ec4: aa0003f5    	mov	x21, x0
107177ec8: 34000136    	cbz	w22, 0x107177eec <__Z23_v8_internal_Node_PrintPv+0x30688c0>
107177ecc: 1400000a    	b	0x107177ef4 <__Z23_v8_internal_Node_PrintPv+0x30688c8>
107177ed0: f0018648    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
107177ed4: f946ed00    	ldr	x0, [x8, #0xdd8]
107177ed8: f0012e62    	adrp	x2, 0x109746000 <dyld_stub_binder+0x109746000>
107177edc: 91256c42    	add	x2, x2, #0x95b
107177ee0: d2800001    	mov	x1, #0x0                ; =0
107177ee4: 963a9122    	bl	0x10001c36c <__text+0x1836c>
107177ee8: aa0003f5    	mov	x21, x0
107177eec: b5000215    	cbnz	x21, 0x107177f2c <__Z23_v8_internal_Node_PrintPv+0x3068900>
107177ef0: d2800014    	mov	x20, #0x0               ; =0
107177ef4: f9400260    	ldr	x0, [x19]
107177ef8: b40000a0    	cbz	x0, 0x107177f0c <__Z23_v8_internal_Node_PrintPv+0x30688e0>
107177efc: b9400402    	ldr	w2, [x0, #0x4]
107177f00: aa1503e1    	mov	x1, x21
107177f04: 52800003    	mov	w3, #0x0                ; =0
107177f08: 96c63246    	bl	0x102304820 <___crubit_thunk_e6a5303ce3f78306__uRNvYNtCsjNIBaewBlLS_u20font_uformat_u1bef5ad514FontFormatInfoNtNtNtCs9kG8YiNG2f0_u4core3ops4drop4Drop4dropB4_u+0x2d0f0>
107177f0c: 52802f00    	mov	w0, #0x178              ; =376
107177f10: 946b808b    	bl	0x108c5813c <dyld_stub_binder+0x108c5813c>
107177f14: aa1503e1    	mov	x1, x21
107177f18: aa1403e2    	mov	x2, x20
107177f1c: a9427bfd    	ldp	x29, x30, [sp, #0x20]
107177f20: a9414ff4    	ldp	x20, x19, [sp, #0x10]
107177f24: a8c357f6    	ldp	x22, x21, [sp], #0x30
107177f28: 170cb04f    	b	0x1034a4064 <_media$cxxbridge1$199$init_symphonia_decoder+0x8ad614>
107177f2c: d4200000    	brk	#0
107177f30: d4400000    	hlt	#0
107177f34: d4200020    	brk	#0x1
107177f38: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
107177f3c: a9017bfd    	stp	x29, x30, [sp, #0x10]
107177f40: 910043fd    	add	x29, sp, #0x10
107177f44: aa0003f3    	mov	x19, x0
107177f48: f0018648    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
107177f4c: f946ed00    	ldr	x0, [x8, #0xdd8]
107177f50: f0012e62    	adrp	x2, 0x109746000 <dyld_stub_binder+0x109746000>
107177f54: 91256c42    	add	x2, x2, #0x95b
107177f58: aa1303e1    	mov	x1, x19
107177f5c: 963a9104    	bl	0x10001c36c <__text+0x1836c>
107177f60: b5000053    	cbnz	x19, 0x107177f68 <__Z23_v8_internal_Node_PrintPv+0x306893c>
107177f64: b50000a0    	cbnz	x0, 0x107177f78 <__Z23_v8_internal_Node_PrintPv+0x306894c>
107177f68: aa1303e1    	mov	x1, x19
107177f6c: a9417bfd    	ldp	x29, x30, [sp, #0x10]
107177f70: a8c24ff4    	ldp	x20, x19, [sp], #0x20
107177f74: d65f03c0    	ret
107177f78: d4200000    	brk	#0
107177f7c: d4400000    	hlt	#0
107177f80: d4200020    	brk	#0x1
		...
107177fc0: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
107177fc4: a9014ff4    	stp	x20, x19, [sp, #0x10]
107177fc8: a9027bfd    	stp	x29, x30, [sp, #0x20]
107177fcc: 910083fd    	add	x29, sp, #0x20
107177fd0: aa0003f3    	mov	x19, x0
107177fd4: 96db2df0    	bl	0x102843794 <_cxxbridge1$box$media$SymphoniaDecoder$drop+0xfd224>
107177fd8: 36000220    	tbz	w0, #0x0, 0x10717801c <__Z23_v8_internal_Node_PrintPv+0x30689f0>
107177fdc: a940d674    	ldp	x20, x21, [x19, #0x8]
107177fe0: a900fe7f    	stp	xzr, xzr, [x19, #0x8]
107177fe4: 12800008    	mov	w8, #-0x1               ; =-1
107177fe8: b8e80268    	ldaddal	w8, w8, [x19]
107177fec: 7100051f    	cmp	w8, #0x1
107177ff0: fa400a64    	ccmp	x19, #0x0, #0x4, eq
107177ff4: 54000080    	b.eq	0x107178004 <__Z23_v8_internal_Node_PrintPv+0x30689d8>
107177ff8: aa1303e0    	mov	x0, x19
107177ffc: 96a14833    	bl	0x1019ca0c8 <_sfv$cxxbridge1$199$decode_dictionary+0x9ce4c>
107178000: 946b8046    	bl	0x108c58118 <dyld_stub_binder+0x108c58118>
107178004: aa1403e0    	mov	x0, x20
107178008: aa1503e1    	mov	x1, x21
10717800c: a9427bfd    	ldp	x29, x30, [sp, #0x20]
107178010: a9414ff4    	ldp	x20, x19, [sp, #0x10]
107178014: a8c357f6    	ldp	x22, x21, [sp], #0x30
107178018: d65f03c0    	ret
10717801c: d4200000    	brk	#0
107178020: d4400000    	hlt	#0
107178024: d4200020    	brk	#0x1
		...
107178030: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
107178034: a9014ff4    	stp	x20, x19, [sp, #0x10]
107178038: a9027bfd    	stp	x29, x30, [sp, #0x20]
10717803c: 910083fd    	add	x29, sp, #0x20
107178040: aa0403f5    	mov	x21, x4
107178044: aa0303f4    	mov	x20, x3
107178048: aa0103f6    	mov	x22, x1
10717804c: aa0003f3    	mov	x19, x0
107178050: aa0203e1    	mov	x1, x2
107178054: 94000021    	bl	0x1071780d8 <__Z23_v8_internal_Node_PrintPv+0x3068aac>
107178058: aa0003e2    	mov	x2, x0
10717805c: aa1403e0    	mov	x0, x20
107178060: aa1603e1    	mov	x1, x22
107178064: aa1503e3    	mov	x3, x21
107178068: 941cd9c0    	bl	0x1078ae768 <__Z23_v8_internal_Node_PrintPv+0x379f13c>
10717806c: 394082a8    	ldrb	w8, [x21, #0x20]
107178070: 360000a8    	tbz	w8, #0x0, 0x107178084 <__Z23_v8_internal_Node_PrintPv+0x3068a58>
107178074: a9427bfd    	ldp	x29, x30, [sp, #0x20]
107178078: a9414ff4    	ldp	x20, x19, [sp, #0x10]
10717807c: a8c357f6    	ldp	x22, x21, [sp], #0x30
107178080: d65f03c0    	ret
107178084: aa1403e0    	mov	x0, x20
107178088: 941cdaae    	bl	0x1078aeb40 <__Z23_v8_internal_Node_PrintPv+0x379f514>
10717808c: b940b668    	ldr	w8, [x19, #0xb4]
107178090: 340001e8    	cbz	w8, 0x1071780cc <__Z23_v8_internal_Node_PrintPv+0x3068aa0>
107178094: 51000508    	sub	w8, w8, #0x1
107178098: f9405669    	ldr	x9, [x19, #0xa8]
10717809c: 5280030a    	mov	w10, #0x18              ; =24
1071780a0: 9baa2509    	umaddl	x9, w8, w10, x9
1071780a4: f9400528    	ldr	x8, [x9, #0x8]
1071780a8: f9000520    	str	x0, [x9, #0x8]
1071780ac: b4fffe48    	cbz	x8, 0x107178074 <__Z23_v8_internal_Node_PrintPv+0x3068a48>
1071780b0: f9400109    	ldr	x9, [x8]
1071780b4: f9400521    	ldr	x1, [x9, #0x8]
1071780b8: aa0803e0    	mov	x0, x8
1071780bc: a9427bfd    	ldp	x29, x30, [sp, #0x20]
1071780c0: a9414ff4    	ldp	x20, x19, [sp, #0x10]
1071780c4: a8c357f6    	ldp	x22, x21, [sp], #0x30
1071780c8: d61f0020    	br	x1
1071780cc: d4200000    	brk	#0
1071780d0: d4400000    	hlt	#0
1071780d4: d4200020    	brk	#0x1
1071780d8: d103c3ff    	sub	sp, sp, #0xf0
1071780dc: a90c57f6    	stp	x22, x21, [sp, #0xc0]
1071780e0: a90d4ff4    	stp	x20, x19, [sp, #0xd0]
1071780e4: a90e7bfd    	stp	x29, x30, [sp, #0xe0]
1071780e8: 910383fd    	add	x29, sp, #0xe0
1071780ec: aa0103f3    	mov	x19, x1
1071780f0: aa0003f4    	mov	x20, x0
1071780f4: 6f00e400    	movi.2d	v0, #0000000000000000
1071780f8: ad0403e0    	stp	q0, q0, [sp, #0x80]
1071780fc: ad0303e0    	stp	q0, q0, [sp, #0x60]
107178100: 910183f5    	add	x21, sp, #0x60
107178104: 910183e0    	add	x0, sp, #0x60
107178108: 96a1a126    	bl	0x1019e05a0 <_sfv$cxxbridge1$199$decode_dictionary+0xb3324>
10717810c: aa1303e0    	mov	x0, x19
107178110: 96ad888f    	bl	0x101cda34c <_crabby_avifPeekCompatibleFileType+0x46640>
107178114: aa0003f3    	mov	x19, x0
107178118: 910103e0    	add	x0, sp, #0x40
10717811c: 910183e1    	add	x1, sp, #0x60
107178120: 97088d86    	bl	0x10339b738 <_media$cxxbridge1$199$init_symphonia_decoder+0x7a4ce8>
107178124: 910103e1    	add	x1, sp, #0x40
107178128: aa1303e0    	mov	x0, x19
10717812c: d2800002    	mov	x2, #0x0                ; =0
107178130: 96b20982    	bl	0x101dfa738 <_cxxbridge1$string$new+0x31c70>
107178134: 910103e0    	add	x0, sp, #0x40
107178138: 96933811    	bl	0x10164617c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x7ec6d4>
10717813c: 910023e0    	add	x0, sp, #0x8
107178140: 910082a1    	add	x1, x21, #0x20
107178144: 97088d7d    	bl	0x10339b738 <_media$cxxbridge1$199$init_symphonia_decoder+0x7a4ce8>
107178148: d10103a0    	sub	x0, x29, #0x40
10717814c: 910023e1    	add	x1, sp, #0x8
107178150: 97088d7a    	bl	0x10339b738 <_media$cxxbridge1$199$init_symphonia_decoder+0x7a4ce8>
107178154: 9100a3e0    	add	x0, sp, #0x28
107178158: d10103a1    	sub	x1, x29, #0x40
10717815c: 969338b9    	bl	0x101646440 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x7ec998>
107178160: d10103a0    	sub	x0, x29, #0x40
107178164: 96933806    	bl	0x10164617c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x7ec6d4>
107178168: a9037fff    	stp	xzr, xzr, [sp, #0x30]
10717816c: 29562289    	ldp	w9, w8, [x20, #0xb0]
107178170: 6b09011f    	cmp	w8, w9
107178174: 540004e0    	b.eq	0x107178210 <__Z23_v8_internal_Node_PrintPv+0x3068be4>
107178178: f9405689    	ldr	x9, [x20, #0xa8]
10717817c: 5280030a    	mov	w10, #0x18              ; =24
107178180: 9baa2500    	umaddl	x0, w8, w10, x9
107178184: 9100a3e1    	add	x1, sp, #0x28
107178188: 96a21242    	bl	0x1019fca90 <_sfv$cxxbridge1$199$decode_dictionary+0xcf814>
10717818c: f9401be8    	ldr	x8, [sp, #0x30]
107178190: f9001bff    	str	xzr, [sp, #0x30]
107178194: f9000408    	str	x8, [x0, #0x8]
107178198: f9401fe8    	ldr	x8, [sp, #0x38]
10717819c: f9001fff    	str	xzr, [sp, #0x38]
1071781a0: f9000808    	str	x8, [x0, #0x10]
1071781a4: b940b688    	ldr	w8, [x20, #0xb4]
1071781a8: 11000508    	add	w8, w8, #0x1
1071781ac: b900b688    	str	w8, [x20, #0xb4]
1071781b0: f9401fe0    	ldr	x0, [sp, #0x38]
1071781b4: f9001fff    	str	xzr, [sp, #0x38]
1071781b8: b4000080    	cbz	x0, 0x1071781c8 <__Z23_v8_internal_Node_PrintPv+0x3068b9c>
1071781bc: f9400008    	ldr	x8, [x0]
1071781c0: f9400508    	ldr	x8, [x8, #0x8]
1071781c4: d63f0100    	blr	x8
1071781c8: f9401be0    	ldr	x0, [sp, #0x30]
1071781cc: f9001bff    	str	xzr, [sp, #0x30]
1071781d0: b4000080    	cbz	x0, 0x1071781e0 <__Z23_v8_internal_Node_PrintPv+0x3068bb4>
1071781d4: f9400008    	ldr	x8, [x0]
1071781d8: f9400508    	ldr	x8, [x8, #0x8]
1071781dc: d63f0100    	blr	x8
1071781e0: 9100a3e0    	add	x0, sp, #0x28
1071781e4: 96f193ed    	bl	0x102ddd198 <_media$cxxbridge1$199$init_symphonia_decoder+0x1e6748>
1071781e8: 910023e0    	add	x0, sp, #0x8
1071781ec: 969337e4    	bl	0x10164617c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x7ec6d4>
1071781f0: 910183e0    	add	x0, sp, #0x60
1071781f4: 96a6e146    	bl	0x101b3070c <_media$cxxbridge1$199$SymphoniaDecoder$decode+0x11ed4>
1071781f8: aa1303e0    	mov	x0, x19
1071781fc: a94e7bfd    	ldp	x29, x30, [sp, #0xe0]
107178200: a94d4ff4    	ldp	x20, x19, [sp, #0xd0]
107178204: a94c57f6    	ldp	x22, x21, [sp, #0xc0]
107178208: 9103c3ff    	add	sp, sp, #0xf0
10717820c: d65f03c0    	ret
107178210: 9102a280    	add	x0, x20, #0xa8
107178214: 9100a3e1    	add	x1, sp, #0x28
107178218: 94000a70    	bl	0x10717abd8 <__Z23_v8_internal_Node_PrintPv+0x306b5ac>
10717821c: 17ffffe5    	b	0x1071781b0 <__Z23_v8_internal_Node_PrintPv+0x3068b84>
107178220: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
107178224: a9014ff4    	stp	x20, x19, [sp, #0x10]
107178228: a9027bfd    	stp	x29, x30, [sp, #0x20]
10717822c: 910083fd    	add	x29, sp, #0x20
107178230: aa0403f5    	mov	x21, x4
107178234: aa0303f4    	mov	x20, x3
107178238: aa0103f6    	mov	x22, x1
10717823c: aa0003f3    	mov	x19, x0
107178240: aa0203e1    	mov	x1, x2
107178244: 97ffffa5    	bl	0x1071780d8 <__Z23_v8_internal_Node_PrintPv+0x3068aac>
107178248: aa0003e2    	mov	x2, x0
10717824c: aa1403e0    	mov	x0, x20
107178250: aa1603e1    	mov	x1, x22
107178254: aa1503e3    	mov	x3, x21
107178258: 941d1ff6    	bl	0x1078c0230 <__Z23_v8_internal_Node_PrintPv+0x37b0c04>
10717825c: 394082a8    	ldrb	w8, [x21, #0x20]
107178260: 360000a8    	tbz	w8, #0x0, 0x107178274 <__Z23_v8_internal_Node_PrintPv+0x3068c48>
107178264: a9427bfd    	ldp	x29, x30, [sp, #0x20]
107178268: a9414ff4    	ldp	x20, x19, [sp, #0x10]
10717826c: a8c357f6    	ldp	x22, x21, [sp], #0x30
107178270: d65f03c0    	ret
107178274: aa1403e0    	mov	x0, x20
107178278: 97e203c2    	bl	0x1069f9180 <__Z23_v8_internal_Node_PrintPv+0x28e9b54>
10717827c: b940b668    	ldr	w8, [x19, #0xb4]
107178280: 340001e8    	cbz	w8, 0x1071782bc <__Z23_v8_internal_Node_PrintPv+0x3068c90>
107178284: 51000508    	sub	w8, w8, #0x1
107178288: f9405669    	ldr	x9, [x19, #0xa8]
10717828c: 5280030a    	mov	w10, #0x18              ; =24
107178290: 9baa2509    	umaddl	x9, w8, w10, x9
107178294: f9400928    	ldr	x8, [x9, #0x10]
107178298: f9000920    	str	x0, [x9, #0x10]
10717829c: b4fffe48    	cbz	x8, 0x107178264 <__Z23_v8_internal_Node_PrintPv+0x3068c38>
1071782a0: f9400109    	ldr	x9, [x8]
1071782a4: f9400521    	ldr	x1, [x9, #0x8]
1071782a8: aa0803e0    	mov	x0, x8
1071782ac: a9427bfd    	ldp	x29, x30, [sp, #0x20]
1071782b0: a9414ff4    	ldp	x20, x19, [sp, #0x10]
1071782b4: a8c357f6    	ldp	x22, x21, [sp], #0x30
1071782b8: d61f0020    	br	x1
1071782bc: d4200000    	brk	#0
1071782c0: d4400000    	hlt	#0
1071782c4: d4200020    	brk	#0x1
1071782c8: d10143ff    	sub	sp, sp, #0x50
1071782cc: a9034ff4    	stp	x20, x19, [sp, #0x30]
1071782d0: a9047bfd    	stp	x29, x30, [sp, #0x40]
1071782d4: 910103fd    	add	x29, sp, #0x40
1071782d8: aa0003f3    	mov	x19, x0
1071782dc: 90013de8    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
1071782e0: f9401108    	ldr	x8, [x8, #0x20]
1071782e4: f9400108    	ldr	x8, [x8]
1071782e8: f81e83a8    	stur	x8, [x29, #-0x18]
1071782ec: 910023e8    	add	x8, sp, #0x8
1071782f0: aa0103e0    	mov	x0, x1
1071782f4: aa0203e1    	mov	x1, x2
1071782f8: aa0303e2    	mov	x2, x3
1071782fc: 94000017    	bl	0x107178358 <__Z23_v8_internal_Node_PrintPv+0x3068d2c>
107178300: 91008260    	add	x0, x19, #0x20
107178304: 52800001    	mov	w1, #0x0                ; =0
107178308: 970cafaa    	bl	0x1034a41b0 <_media$cxxbridge1$199$init_symphonia_decoder+0x8ad760>
10717830c: 91008260    	add	x0, x19, #0x20
107178310: 910023e1    	add	x1, sp, #0x8
107178314: d2800002    	mov	x2, #0x0                ; =0
107178318: d2800003    	mov	x3, #0x0                ; =0
10717831c: 52800004    	mov	w4, #0x0                ; =0
