
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010410f62c <__Z23_v8_internal_Node_PrintPv>:
107170240: d10283ff    	sub	sp, sp, #0xa0
107170244: a90757f6    	stp	x22, x21, [sp, #0x70]
107170248: a9084ff4    	stp	x20, x19, [sp, #0x80]
10717024c: a9097bfd    	stp	x29, x30, [sp, #0x90]
107170250: 910243fd    	add	x29, sp, #0x90
107170254: 90013e28    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
107170258: f9401108    	ldr	x8, [x8, #0x20]
10717025c: f9400108    	ldr	x8, [x8]
107170260: f81d83a8    	stur	x8, [x29, #-0x28]
107170264: 39415408    	ldrb	w8, [x0, #0x55]
107170268: 37000508    	tbnz	w8, #0x0, 0x107170308 <__Z23_v8_internal_Node_PrintPv+0x3060cdc>
10717026c: aa0203f5    	mov	x21, x2
107170270: aa0103f4    	mov	x20, x1
107170274: aa0003f3    	mov	x19, x0
107170278: 6f00e400    	movi.2d	v0, #0000000000000000
10717027c: ad0083e0    	stp	q0, q0, [sp, #0x10]
107170280: a902ffe1    	stp	x1, xzr, [sp, #0x28]
107170284: aa0103e0    	mov	x0, x1
107170288: aa0203e1    	mov	x1, x2
10717028c: 94223377    	bl	0x1079fd068 <__Z23_v8_internal_Node_PrintPv+0x38eda3c>
107170290: 37000100    	tbnz	w0, #0x0, 0x1071702b0 <__Z23_v8_internal_Node_PrintPv+0x3060c84>
107170294: d0012ea2    	adrp	x2, 0x109746000 <dyld_stub_binder+0x109746000>
107170298: 9121a442    	add	x2, x2, #0x869
10717029c: 910043e0    	add	x0, sp, #0x10
1071702a0: 52800321    	mov	w1, #0x19               ; =25
1071702a4: 942219d6    	bl	0x1079f69fc <__Z23_v8_internal_Node_PrintPv+0x38e73d0>
1071702a8: 52800000    	mov	w0, #0x0                ; =0
1071702ac: 14000018    	b	0x10717030c <__Z23_v8_internal_Node_PrintPv+0x3060ce0>
1071702b0: f94002a8    	ldr	x8, [x21]
1071702b4: b840b108    	ldur	w8, [x8, #0xb]
1071702b8: f9417a89    	ldr	x9, [x20, #0x2f0]
1071702bc: d343fd08    	lsr	x8, x8, #3
1071702c0: 927d6508    	and	x8, x8, #0x1ffffff8
1071702c4: f8686928    	ldr	x8, [x9, x8]
1071702c8: 121f3909    	and	w9, w8, #0xfffe
1071702cc: f9001fff    	str	xzr, [sp, #0x38]
1071702d0: 513f3929    	sub	w9, w9, #0xfce
1071702d4: d350fd08    	lsr	x8, x8, #16
1071702d8: 3137393f    	cmn	w9, #0xdce
1071702dc: 9a8833e8    	csel	x8, xzr, x8, lo
1071702e0: f9001fe8    	str	x8, [sp, #0x38]
1071702e4: f9401ff4    	ldr	x20, [sp, #0x38]
1071702e8: b4000814    	cbz	x20, 0x1071703e8 <__Z23_v8_internal_Node_PrintPv+0x3060dbc>
1071702ec: f9400268    	ldr	x8, [x19]
1071702f0: f9402d08    	ldr	x8, [x8, #0x58]
1071702f4: 910043e2    	add	x2, sp, #0x10
1071702f8: aa1303e0    	mov	x0, x19
1071702fc: aa1403e1    	mov	x1, x20
107170300: d63f0100    	blr	x8
107170304: 360001e0    	tbz	w0, #0x0, 0x107170340 <__Z23_v8_internal_Node_PrintPv+0x3060d14>
107170308: 52802020    	mov	w0, #0x101              ; =257
10717030c: f85d83a8    	ldur	x8, [x29, #-0x28]
107170310: 90013e29    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
107170314: f9401129    	ldr	x9, [x9, #0x20]
107170318: f9400129    	ldr	x9, [x9]
10717031c: eb08013f    	cmp	x9, x8
107170320: 540006a1    	b.ne	0x1071703f4 <__Z23_v8_internal_Node_PrintPv+0x3060dc8>
107170324: a9497bfd    	ldp	x29, x30, [sp, #0x90]
107170328: a9484ff4    	ldp	x20, x19, [sp, #0x80]
10717032c: a94757f6    	ldp	x22, x21, [sp, #0x70]
107170330: 910283ff    	add	sp, sp, #0xa0
107170334: d65f03c0    	ret
107170338: 52800000    	mov	w0, #0x0                ; =0
10717033c: 1400000d    	b	0x107170370 <__Z23_v8_internal_Node_PrintPv+0x3060d44>
107170340: 3940c3e8    	ldrb	w8, [sp, #0x30]
107170344: 3707fb28    	tbnz	w8, #0x0, 0x1071702a8 <__Z23_v8_internal_Node_PrintPv+0x3060c7c>
107170348: aa1403e0    	mov	x0, x20
10717034c: 967ecf58    	bl	0x1011240ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x2ca604>
107170350: f9400c13    	ldr	x19, [x0, #0x18]
107170354: f0017148    	adrp	x8, 0x109f9b000 <dyld_stub_binder+0x109f9b000>
107170358: f940c114    	ldr	x20, [x8, #0x180]
10717035c: b4fffef3    	cbz	x19, 0x107170338 <__Z23_v8_internal_Node_PrintPv+0x3060d0c>
107170360: aa1303e0    	mov	x0, x19
107170364: 946b9f97    	bl	0x108c581c0 <dyld_stub_binder+0x108c581c0>
107170368: d360fc08    	lsr	x8, x0, #32
10717036c: b5000428    	cbnz	x8, 0x1071703f0 <__Z23_v8_internal_Node_PrintPv+0x3060dc4>
107170370: a903cff4    	stp	x20, x19, [sp, #0x38]
107170374: b9004be0    	str	w0, [sp, #0x48]
107170378: d0012ea8    	adrp	x8, 0x109746000 <dyld_stub_binder+0x109746000>
10717037c: 91222108    	add	x8, x8, #0x888
107170380: a90523f4    	stp	x20, x8, [sp, #0x50]
107170384: 52800388    	mov	w8, #0x1c               ; =28
107170388: b90063e8    	str	w8, [sp, #0x60]
10717038c: 9100e3e0    	add	x0, sp, #0x38
107170390: 52800041    	mov	w1, #0x2                ; =2
107170394: 963dfe47    	bl	0x1000efcb0 <_cxxbridge1$slice$new+0xaa1d4>
107170398: f90007e0    	str	x0, [sp, #0x8]
10717039c: 910043e0    	add	x0, sp, #0x10
1071703a0: 910023e2    	add	x2, sp, #0x8
1071703a4: 52800321    	mov	w1, #0x19               ; =25
1071703a8: 963dfdf2    	bl	0x1000efb70 <_cxxbridge1$slice$new+0xaa094>
1071703ac: f94007e0    	ldr	x0, [sp, #0x8]
1071703b0: b4fff7c0    	cbz	x0, 0x1071702a8 <__Z23_v8_internal_Node_PrintPv+0x3060c7c>
1071703b4: b9400808    	ldr	w8, [x0, #0x8]
1071703b8: 370ff788    	tbnz	w8, #0x1, 0x1071702a8 <__Z23_v8_internal_Node_PrintPv+0x3060c7c>
1071703bc: b9400008    	ldr	w8, [x0]
1071703c0: 71000509    	subs	w9, w8, #0x1
1071703c4: 540000e0    	b.eq	0x1071703e0 <__Z23_v8_internal_Node_PrintPv+0x3060db4>
1071703c8: aa0803ea    	mov	x10, x8
1071703cc: 88aafc09    	casl	w10, w9, [x0]
1071703d0: 6b08015f    	cmp	w10, w8
1071703d4: aa0a03e8    	mov	x8, x10
1071703d8: 54ffff41    	b.ne	0x1071703c0 <__Z23_v8_internal_Node_PrintPv+0x3060d94>
1071703dc: 17ffffb3    	b	0x1071702a8 <__Z23_v8_internal_Node_PrintPv+0x3060c7c>
1071703e0: 963bc568    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
1071703e4: 17ffffb1    	b	0x1071702a8 <__Z23_v8_internal_Node_PrintPv+0x3060c7c>
1071703e8: d4200000    	brk	#0
1071703ec: d4400000    	hlt	#0
1071703f0: d4200020    	brk	#0x1
1071703f4: 946b9f40    	bl	0x108c580f4 <dyld_stub_binder+0x108c580f4>
1071703f8: d10203ff    	sub	sp, sp, #0x80
1071703fc: a90557f6    	stp	x22, x21, [sp, #0x50]
107170400: a9064ff4    	stp	x20, x19, [sp, #0x60]
107170404: a9077bfd    	stp	x29, x30, [sp, #0x70]
107170408: 9101c3fd    	add	x29, sp, #0x70
10717040c: 6f00e400    	movi.2d	v0, #0000000000000000
107170410: ad0003e0    	stp	q0, q0, [sp]
107170414: a901ffe1    	stp	x1, xzr, [sp, #0x18]
107170418: 39415008    	ldrb	w8, [x0, #0x54]
10717041c: 34000188    	cbz	w8, 0x10717044c <__Z23_v8_internal_Node_PrintPv+0x3060e20>
107170420: d0012ea2    	adrp	x2, 0x109746000 <dyld_stub_binder+0x109746000>
107170424: 91229442    	add	x2, x2, #0x8a5
107170428: 910003e0    	mov	x0, sp
10717042c: 52800321    	mov	w1, #0x19               ; =25
107170430: 94221973    	bl	0x1079f69fc <__Z23_v8_internal_Node_PrintPv+0x38e73d0>
107170434: d2800000    	mov	x0, #0x0                ; =0
107170438: a9477bfd    	ldp	x29, x30, [sp, #0x70]
10717043c: a9464ff4    	ldp	x20, x19, [sp, #0x60]
107170440: a94557f6    	ldp	x22, x21, [sp, #0x50]
107170444: 910203ff    	add	sp, sp, #0x80
107170448: d65f03c0    	ret
10717044c: aa0203f4    	mov	x20, x2
107170450: aa0103f5    	mov	x21, x1
107170454: aa0003f3    	mov	x19, x0
107170458: aa0203e0    	mov	x0, x2
10717045c: 96bac391    	bl	0x1020212a0 <_rust_png$cxxbridge1$199$Reader$has_trns_chunk+0x95a80>
107170460: 360008e0    	tbz	w0, #0x0, 0x10717057c <__Z23_v8_internal_Node_PrintPv+0x3060f50>
107170464: f9400288    	ldr	x8, [x20]
107170468: b840b108    	ldur	w8, [x8, #0xb]
10717046c: f9417aa9    	ldr	x9, [x21, #0x2f0]
107170470: d343fd08    	lsr	x8, x8, #3
107170474: 927d6508    	and	x8, x8, #0x1ffffff8
107170478: f8686928    	ldr	x8, [x9, x8]
10717047c: f81d03bf    	stur	xzr, [x29, #-0x30]
107170480: d350fd09    	lsr	x9, x8, #16
107170484: 927f3908    	and	x8, x8, #0xfffe
107170488: f13f011f    	cmp	x8, #0xfc0
10717048c: 9a9f0128    	csel	x8, x9, xzr, eq
107170490: f81d03a8    	stur	x8, [x29, #-0x30]
107170494: f85d03b6    	ldur	x22, [x29, #-0x30]
107170498: b4000476    	cbz	x22, 0x107170524 <__Z23_v8_internal_Node_PrintPv+0x3060ef8>
10717049c: f81d03b6    	stur	x22, [x29, #-0x30]
1071704a0: 394083e8    	ldrb	w8, [sp, #0x20]
1071704a4: 3707fc88    	tbnz	w8, #0x0, 0x107170434 <__Z23_v8_internal_Node_PrintPv+0x3060e08>
1071704a8: aa1303e0    	mov	x0, x19
1071704ac: f8440c0b    	ldr	x11, [x0, #0x40]!
1071704b0: b9400c0a    	ldr	w10, [x0, #0xc]
1071704b4: 8b0a0968    	add	x8, x11, x10, lsl #2
1071704b8: d343fec9    	lsr	x9, x22, #3
1071704bc: eb08017f    	cmp	x11, x8
1071704c0: 54000122    	b.hs	0x1071704e4 <__Z23_v8_internal_Node_PrintPv+0x3060eb8>
1071704c4: d280000c    	mov	x12, #0x0               ; =0
1071704c8: b86c696d    	ldr	w13, [x11, x12]
1071704cc: 6b0901bf    	cmp	w13, w9
1071704d0: 540001e0    	b.eq	0x10717050c <__Z23_v8_internal_Node_PrintPv+0x3060ee0>
1071704d4: 9100118c    	add	x12, x12, #0x4
1071704d8: 8b0c016d    	add	x13, x11, x12
1071704dc: eb0801bf    	cmp	x13, x8
1071704e0: 54ffff43    	b.lo	0x1071704c8 <__Z23_v8_internal_Node_PrintPv+0x3060e9c>
1071704e4: b9404a6b    	ldr	w11, [x19, #0x48]
1071704e8: 6b0b015f    	cmp	w10, w11
1071704ec: 54000760    	b.eq	0x1071705d8 <__Z23_v8_internal_Node_PrintPv+0x3060fac>
1071704f0: b9000109    	str	w9, [x8]
1071704f4: aa0803e0    	mov	x0, x8
1071704f8: 96b8f572    	bl	0x101fadac0 <_rust_png$cxxbridge1$199$Reader$has_trns_chunk+0x222a0>
1071704fc: b9404e6b    	ldr	w11, [x19, #0x4c]
107170500: 11000568    	add	w8, w11, #0x1
107170504: b9004e68    	str	w8, [x19, #0x4c]
107170508: 14000004    	b	0x107170518 <__Z23_v8_internal_Node_PrintPv+0x3060eec>
10717050c: d342fd8b    	lsr	x11, x12, #2
107170510: 3100057f    	cmn	w11, #0x1
107170514: 54fffe80    	b.eq	0x1071704e4 <__Z23_v8_internal_Node_PrintPv+0x3060eb8>
107170518: 52800028    	mov	w8, #0x1                ; =1
10717051c: aa0b8100    	orr	x0, x8, x11, lsl #32
107170520: 17ffffc6    	b	0x107170438 <__Z23_v8_internal_Node_PrintPv+0x3060e0c>
107170524: aa1403e0    	mov	x0, x20
107170528: 9729707f    	bl	0x103bcc724 <_llg_tokenize_bytes+0x22c888>
10717052c: a93d07a0    	stp	x0, x1, [x29, #-0x30]
107170530: a90307e0    	stp	x0, x1, [sp, #0x30]
107170534: b4000081    	cbz	x1, 0x107170544 <__Z23_v8_internal_Node_PrintPv+0x3060f18>
107170538: 91002028    	add	x8, x1, #0x8
10717053c: 52800029    	mov	w9, #0x1                ; =1
107170540: f8290108    	ldadd	x9, x8, [x8]
107170544: 9100c3e0    	add	x0, sp, #0x30
107170548: 94001b59    	bl	0x1071772ac <__Z23_v8_internal_Node_PrintPv+0x3067c80>
10717054c: aa0003f6    	mov	x22, x0
107170550: 9100c3e0    	add	x0, sp, #0x30
107170554: 96e9cdb1    	bl	0x102be3c18 <_rust_png$cxxbridge1$199$new_writer+0x277498>
107170558: d0016362    	adrp	x2, 0x109dde000 <_kLiteRtRuntimeBuiltin+0xe8e0>
10717055c: 91004042    	add	x2, x2, #0x10
107170560: aa1603e0    	mov	x0, x22
107170564: aa1503e1    	mov	x1, x21
107170568: aa1403e3    	mov	x3, x20
10717056c: 9641de25    	bl	0x1001e7e00 <_cxxbridge1$slice$new+0x1a2324>
107170570: d100c3a0    	sub	x0, x29, #0x30
107170574: 96e9cda9    	bl	0x102be3c18 <_rust_png$cxxbridge1$199$new_writer+0x277498>
107170578: 17ffffc9    	b	0x10717049c <__Z23_v8_internal_Node_PrintPv+0x3060e70>
10717057c: b00115e0    	adrp	x0, 0x10942d000 <dyld_stub_binder+0x10942d000>
107170580: 9130a400    	add	x0, x0, #0xc29
107170584: 942212d5    	bl	0x1079f50d8 <__Z23_v8_internal_Node_PrintPv+0x38e5aac>
107170588: f81d03a0    	stur	x0, [x29, #-0x30]
10717058c: 910003e0    	mov	x0, sp
107170590: d100c3a1    	sub	x1, x29, #0x30
107170594: 942218ee    	bl	0x1079f694c <__Z23_v8_internal_Node_PrintPv+0x38e7320>
107170598: f85d03a0    	ldur	x0, [x29, #-0x30]
10717059c: b40001a0    	cbz	x0, 0x1071705d0 <__Z23_v8_internal_Node_PrintPv+0x3060fa4>
1071705a0: b9400808    	ldr	w8, [x0, #0x8]
1071705a4: 37080168    	tbnz	w8, #0x1, 0x1071705d0 <__Z23_v8_internal_Node_PrintPv+0x3060fa4>
1071705a8: b9400008    	ldr	w8, [x0]
1071705ac: 71000509    	subs	w9, w8, #0x1
1071705b0: 540000e0    	b.eq	0x1071705cc <__Z23_v8_internal_Node_PrintPv+0x3060fa0>
1071705b4: aa0803ea    	mov	x10, x8
1071705b8: 88aafc09    	casl	w10, w9, [x0]
1071705bc: 6b08015f    	cmp	w10, w8
1071705c0: aa0a03e8    	mov	x8, x10
1071705c4: 54ffff41    	b.ne	0x1071705ac <__Z23_v8_internal_Node_PrintPv+0x3060f80>
1071705c8: 14000002    	b	0x1071705d0 <__Z23_v8_internal_Node_PrintPv+0x3060fa4>
1071705cc: 963bc4ed    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
1071705d0: d2800016    	mov	x22, #0x0               ; =0
1071705d4: 17ffffb2    	b	0x10717049c <__Z23_v8_internal_Node_PrintPv+0x3060e70>
1071705d8: d100c3a1    	sub	x1, x29, #0x30
1071705dc: 94000ab9    	bl	0x1071730c0 <__Z23_v8_internal_Node_PrintPv+0x3063a94>
1071705e0: b9404e68    	ldr	w8, [x19, #0x4c]
1071705e4: 5100050b    	sub	w11, w8, #0x1
1071705e8: 17ffffcc    	b	0x107170518 <__Z23_v8_internal_Node_PrintPv+0x3060eec>
1071705ec: d10143ff    	sub	sp, sp, #0x50
1071705f0: a9034ff4    	stp	x20, x19, [sp, #0x30]
1071705f4: a9047bfd    	stp	x29, x30, [sp, #0x40]
1071705f8: 910103fd    	add	x29, sp, #0x40
1071705fc: aa0103f4    	mov	x20, x1
107170600: 39415008    	ldrb	w8, [x0, #0x54]
107170604: 350005a8    	cbnz	w8, 0x1071706b8 <__Z23_v8_internal_Node_PrintPv+0x306108c>
107170608: aa0003f3    	mov	x19, x0
10717060c: b9405008    	ldr	w8, [x0, #0x50]
107170610: 7100051f    	cmp	w8, #0x1
107170614: 54000ae0    	b.eq	0x107170770 <__Z23_v8_internal_Node_PrintPv+0x3061144>
107170618: 71000d1f    	cmp	w8, #0x3
10717061c: 540009e1    	b.ne	0x107170758 <__Z23_v8_internal_Node_PrintPv+0x306112c>
107170620: d0012ea1    	adrp	x1, 0x109746000 <dyld_stub_binder+0x109746000>
107170624: 91245021    	add	x1, x1, #0x914
107170628: 910003e0    	mov	x0, sp
10717062c: 528008c2    	mov	w2, #0x46               ; =70
107170630: 9695615a    	bl	0x1016c8b98 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x86f0f0>
107170634: f81e83bf    	stur	xzr, [x29, #-0x18]
107170638: 910003e2    	mov	x2, sp
10717063c: d10063a3    	sub	x3, x29, #0x18
107170640: aa1403e0    	mov	x0, x20
107170644: 52800321    	mov	w1, #0x19               ; =25
107170648: 97ffcf5a    	bl	0x1071643b0 <__Z23_v8_internal_Node_PrintPv+0x3054d84>
10717064c: f85e83a0    	ldur	x0, [x29, #-0x18]
107170650: b40001a0    	cbz	x0, 0x107170684 <__Z23_v8_internal_Node_PrintPv+0x3061058>
107170654: b9400808    	ldr	w8, [x0, #0x8]
107170658: 37080168    	tbnz	w8, #0x1, 0x107170684 <__Z23_v8_internal_Node_PrintPv+0x3061058>
10717065c: b9400008    	ldr	w8, [x0]
107170660: 71000509    	subs	w9, w8, #0x1
107170664: 540000e0    	b.eq	0x107170680 <__Z23_v8_internal_Node_PrintPv+0x3061054>
107170668: aa0803ea    	mov	x10, x8
10717066c: 88aafc09    	casl	w10, w9, [x0]
107170670: 6b08015f    	cmp	w10, w8
107170674: aa0a03e8    	mov	x8, x10
107170678: 54ffff41    	b.ne	0x107170660 <__Z23_v8_internal_Node_PrintPv+0x3061034>
10717067c: 14000002    	b	0x107170684 <__Z23_v8_internal_Node_PrintPv+0x3061058>
107170680: 963bc4c0    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
107170684: f94003e0    	ldr	x0, [sp]
107170688: b40006a0    	cbz	x0, 0x10717075c <__Z23_v8_internal_Node_PrintPv+0x3061130>
10717068c: b9400808    	ldr	w8, [x0, #0x8]
107170690: 37080668    	tbnz	w8, #0x1, 0x10717075c <__Z23_v8_internal_Node_PrintPv+0x3061130>
107170694: b9400008    	ldr	w8, [x0]
107170698: 71000509    	subs	w9, w8, #0x1
10717069c: 540005a0    	b.eq	0x107170750 <__Z23_v8_internal_Node_PrintPv+0x3061124>
1071706a0: aa0803ea    	mov	x10, x8
1071706a4: 88aafc09    	casl	w10, w9, [x0]
1071706a8: 6b08015f    	cmp	w10, w8
1071706ac: aa0a03e8    	mov	x8, x10
1071706b0: 54000560    	b.eq	0x10717075c <__Z23_v8_internal_Node_PrintPv+0x3061130>
1071706b4: 17fffff9    	b	0x107170698 <__Z23_v8_internal_Node_PrintPv+0x306106c>
1071706b8: d0012ea1    	adrp	x1, 0x109746000 <dyld_stub_binder+0x109746000>
1071706bc: 91237021    	add	x1, x1, #0x8dc
1071706c0: 910003e0    	mov	x0, sp
1071706c4: 528006e2    	mov	w2, #0x37               ; =55
1071706c8: 96956134    	bl	0x1016c8b98 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x86f0f0>
1071706cc: f81e83bf    	stur	xzr, [x29, #-0x18]
1071706d0: 910003e2    	mov	x2, sp
1071706d4: d10063a3    	sub	x3, x29, #0x18
1071706d8: aa1403e0    	mov	x0, x20
1071706dc: 52800321    	mov	w1, #0x19               ; =25
1071706e0: 97ffcf34    	bl	0x1071643b0 <__Z23_v8_internal_Node_PrintPv+0x3054d84>
1071706e4: f85e83a0    	ldur	x0, [x29, #-0x18]
1071706e8: b40001a0    	cbz	x0, 0x10717071c <__Z23_v8_internal_Node_PrintPv+0x30610f0>
1071706ec: b9400808    	ldr	w8, [x0, #0x8]
1071706f0: 37080168    	tbnz	w8, #0x1, 0x10717071c <__Z23_v8_internal_Node_PrintPv+0x30610f0>
1071706f4: b9400008    	ldr	w8, [x0]
1071706f8: 71000509    	subs	w9, w8, #0x1
1071706fc: 540000e0    	b.eq	0x107170718 <__Z23_v8_internal_Node_PrintPv+0x30610ec>
107170700: aa0803ea    	mov	x10, x8
107170704: 88aafc09    	casl	w10, w9, [x0]
107170708: 6b08015f    	cmp	w10, w8
10717070c: aa0a03e8    	mov	x8, x10
107170710: 54ffff41    	b.ne	0x1071706f8 <__Z23_v8_internal_Node_PrintPv+0x30610cc>
107170714: 14000002    	b	0x10717071c <__Z23_v8_internal_Node_PrintPv+0x30610f0>
107170718: 963bc49a    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
10717071c: f94003e0    	ldr	x0, [sp]
107170720: b40001e0    	cbz	x0, 0x10717075c <__Z23_v8_internal_Node_PrintPv+0x3061130>
107170724: b9400808    	ldr	w8, [x0, #0x8]
107170728: 370801a8    	tbnz	w8, #0x1, 0x10717075c <__Z23_v8_internal_Node_PrintPv+0x3061130>
10717072c: b9400008    	ldr	w8, [x0]
107170730: 71000509    	subs	w9, w8, #0x1
107170734: 540000e0    	b.eq	0x107170750 <__Z23_v8_internal_Node_PrintPv+0x3061124>
107170738: aa0803ea    	mov	x10, x8
10717073c: 88aafc09    	casl	w10, w9, [x0]
107170740: 6b08015f    	cmp	w10, w8
107170744: aa0a03e8    	mov	x8, x10
107170748: 54ffff41    	b.ne	0x107170730 <__Z23_v8_internal_Node_PrintPv+0x3061104>
10717074c: 14000004    	b	0x10717075c <__Z23_v8_internal_Node_PrintPv+0x3061130>
107170750: 963bc48c    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
107170754: 14000002    	b	0x10717075c <__Z23_v8_internal_Node_PrintPv+0x3061130>
107170758: 34000848    	cbz	w8, 0x107170860 <__Z23_v8_internal_Node_PrintPv+0x3061234>
10717075c: d2800000    	mov	x0, #0x0                ; =0
107170760: a9447bfd    	ldp	x29, x30, [sp, #0x40]
107170764: a9434ff4    	ldp	x20, x19, [sp, #0x30]
107170768: 910143ff    	add	sp, sp, #0x50
10717076c: d65f03c0    	ret
107170770: f9400a74    	ldr	x20, [x19, #0x10]
107170774: 910003e8    	mov	x8, sp
107170778: aa0203e0    	mov	x0, x2
10717077c: 97298267    	bl	0x103bd1118 <_llg_tokenize_bytes+0x23127c>
107170780: 29582289    	ldp	w9, w8, [x20, #0xc0]
107170784: 6b09011f    	cmp	w8, w9
107170788: 54000640    	b.eq	0x107170850 <__Z23_v8_internal_Node_PrintPv+0x3061224>
10717078c: f84b8289    	ldur	x9, [x20, #0xb8]
107170790: 5280050a    	mov	w10, #0x28              ; =40
107170794: 9baa2508    	umaddl	x8, w8, w10, x9
107170798: f94003e9    	ldr	x9, [sp]
10717079c: f9000109    	str	x9, [x8]
1071707a0: f94007e9    	ldr	x9, [sp, #0x8]
1071707a4: f9000509    	str	x9, [x8, #0x8]
1071707a8: b4000089    	cbz	x9, 0x1071707b8 <__Z23_v8_internal_Node_PrintPv+0x306118c>
1071707ac: 91002129    	add	x9, x9, #0x8
1071707b0: 5280002a    	mov	w10, #0x1               ; =1
1071707b4: f82a0129    	ldadd	x10, x9, [x9]
1071707b8: 39c09fe9    	ldrsb	w9, [sp, #0x27]
1071707bc: 37f80429    	tbnz	w9, #0x1f, 0x107170840 <__Z23_v8_internal_Node_PrintPv+0x3061214>
1071707c0: 910003e9    	mov	x9, sp
1071707c4: 3cc10120    	ldur	q0, [x9, #0x10]
1071707c8: f8420129    	ldur	x9, [x9, #0x20]
1071707cc: f8020109    	stur	x9, [x8, #0x20]
1071707d0: 3c810100    	stur	q0, [x8, #0x10]
1071707d4: b940c688    	ldr	w8, [x20, #0xc4]
1071707d8: 11000508    	add	w8, w8, #0x1
1071707dc: b900c688    	str	w8, [x20, #0xc4]
1071707e0: 39c09fe8    	ldrsb	w8, [sp, #0x27]
1071707e4: 36f800a8    	tbz	w8, #0x1f, 0x1071707f8 <__Z23_v8_internal_Node_PrintPv+0x30611cc>
1071707e8: f9400be0    	ldr	x0, [sp, #0x10]
1071707ec: f94013e8    	ldr	x8, [sp, #0x20]
1071707f0: 9240f901    	and	x1, x8, #0x7fffffffffffffff
1071707f4: 963a5b89    	bl	0x100007618 <__text+0x3618>
1071707f8: f94007f4    	ldr	x20, [sp, #0x8]
1071707fc: b4000174    	cbz	x20, 0x107170828 <__Z23_v8_internal_Node_PrintPv+0x30611fc>
107170800: 91002288    	add	x8, x20, #0x8
107170804: 92800009    	mov	x9, #-0x1               ; =-1
107170808: f8e90108    	ldaddal	x9, x8, [x8]
10717080c: b50000e8    	cbnz	x8, 0x107170828 <__Z23_v8_internal_Node_PrintPv+0x30611fc>
107170810: f9400288    	ldr	x8, [x20]
107170814: f9400908    	ldr	x8, [x8, #0x10]
107170818: aa1403e0    	mov	x0, x20
10717081c: d63f0100    	blr	x8
107170820: aa1403e0    	mov	x0, x20
107170824: 96b87dff    	bl	0x101f90020 <_rust_png$cxxbridge1$199$Reader$has_trns_chunk+0x4800>
107170828: f9400a68    	ldr	x8, [x19, #0x10]
10717082c: b940c508    	ldr	w8, [x8, #0xc4]
107170830: 51000508    	sub	w8, w8, #0x1
107170834: 52800029    	mov	w9, #0x1                ; =1
107170838: aa088120    	orr	x0, x9, x8, lsl #32
10717083c: 17ffffc9    	b	0x107170760 <__Z23_v8_internal_Node_PrintPv+0x3061134>
107170840: a9410be1    	ldp	x1, x2, [sp, #0x10]
107170844: 91004100    	add	x0, x8, #0x10
107170848: 963a98a8    	bl	0x100016ae8 <__text+0x12ae8>
10717084c: 17ffffe2    	b	0x1071707d4 <__Z23_v8_internal_Node_PrintPv+0x30611a8>
107170850: 9102e280    	add	x0, x20, #0xb8
107170854: 910003e1    	mov	x1, sp
107170858: 94000b28    	bl	0x1071734f8 <__Z23_v8_internal_Node_PrintPv+0x3063ecc>
10717085c: 17ffffe1    	b	0x1071707e0 <__Z23_v8_internal_Node_PrintPv+0x30611b4>
107170860: d4200000    	brk	#0
107170864: d4400000    	hlt	#0
107170868: d4200020    	brk	#0x1
10717086c: aa0103e0    	mov	x0, x1
107170870: 163ab394    	b	0x10001d6c0 <__text+0x196c0>
107170874: d10103ff    	sub	sp, sp, #0x40
107170878: a90157f6    	stp	x22, x21, [sp, #0x10]
10717087c: a9024ff4    	stp	x20, x19, [sp, #0x20]
107170880: a9037bfd    	stp	x29, x30, [sp, #0x30]
107170884: 9100c3fd    	add	x29, sp, #0x30
107170888: aa0103f3    	mov	x19, x1
10717088c: 39415008    	ldrb	w8, [x0, #0x54]
107170890: 35000468    	cbnz	w8, 0x10717091c <__Z23_v8_internal_Node_PrintPv+0x30612f0>
107170894: aa0203f4    	mov	x20, x2
107170898: aa0003f5    	mov	x21, x0
10717089c: f9400408    	ldr	x8, [x0, #0x8]
1071708a0: b9805508    	ldrsw	x8, [x8, #0x54]
1071708a4: d0016ea9    	adrp	x9, 0x109f46000 <dyld_stub_binder+0x109f46000>
1071708a8: f944e129    	ldr	x9, [x9, #0x9c0]
1071708ac: 8a080d20    	and	x0, x9, x8, lsl #3
1071708b0: 968c76cc    	bl	0x10148e3e0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x634938>
1071708b4: 360001e0    	tbz	w0, #0x0, 0x1071708f0 <__Z23_v8_internal_Node_PrintPv+0x30612c4>
1071708b8: f9400ab3    	ldr	x19, [x21, #0x10]
1071708bc: 91056275    	add	x21, x19, #0x158
1071708c0: 39458268    	ldrb	w8, [x19, #0x160]
1071708c4: 34000088    	cbz	w8, 0x1071708d4 <__Z23_v8_internal_Node_PrintPv+0x30612a8>
1071708c8: 91056260    	add	x0, x19, #0x158
1071708cc: 97296b47    	bl	0x103bcb5e8 <_llg_tokenize_bytes+0x22b74c>
1071708d0: 3905827f    	strb	wzr, [x19, #0x160]
1071708d4: b40007f5    	cbz	x21, 0x1071709d0 <__Z23_v8_internal_Node_PrintPv+0x30613a4>
1071708d8: 91056260    	add	x0, x19, #0x158
1071708dc: aa1403e1    	mov	x1, x20
1071708e0: 96883a04    	bl	0x10137f0f0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x525648>
1071708e4: 52800020    	mov	w0, #0x1                ; =1
1071708e8: 39058260    	strb	w0, [x19, #0x160]
1071708ec: 14000034    	b	0x1071709bc <__Z23_v8_internal_Node_PrintPv+0x3061390>
1071708f0: 394152a8    	ldrb	w8, [x21, #0x54]
1071708f4: 7200011f    	tst	w8, #0x1
1071708f8: 528007a8    	mov	w8, #0x3d               ; =61
1071708fc: 52800669    	mov	w9, #0x33               ; =51
107170900: 9a881122    	csel	x2, x9, x8, ne
107170904: d0012ea8    	adrp	x8, 0x109746000 <dyld_stub_binder+0x109746000>
107170908: 9126b108    	add	x8, x8, #0x9ac
10717090c: d0012ea9    	adrp	x9, 0x109746000 <dyld_stub_binder+0x109746000>
107170910: 9125e129    	add	x9, x9, #0x978
107170914: 9a881121    	csel	x1, x9, x8, ne
107170918: 14000004    	b	0x107170928 <__Z23_v8_internal_Node_PrintPv+0x30612fc>
10717091c: d0012ea1    	adrp	x1, 0x109746000 <dyld_stub_binder+0x109746000>
107170920: 9125e021    	add	x1, x1, #0x978
107170924: 52800662    	mov	w2, #0x33               ; =51
107170928: 910023e0    	add	x0, sp, #0x8
10717092c: 9695609b    	bl	0x1016c8b98 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x86f0f0>
107170930: f90003ff    	str	xzr, [sp]
107170934: 910023e2    	add	x2, sp, #0x8
107170938: 910003e3    	mov	x3, sp
10717093c: aa1303e0    	mov	x0, x19
107170940: 52800321    	mov	w1, #0x19               ; =25
107170944: 97ffce9b    	bl	0x1071643b0 <__Z23_v8_internal_Node_PrintPv+0x3054d84>
107170948: f94003e0    	ldr	x0, [sp]
10717094c: b40001a0    	cbz	x0, 0x107170980 <__Z23_v8_internal_Node_PrintPv+0x3061354>
107170950: b9400808    	ldr	w8, [x0, #0x8]
107170954: 37080168    	tbnz	w8, #0x1, 0x107170980 <__Z23_v8_internal_Node_PrintPv+0x3061354>
107170958: b9400008    	ldr	w8, [x0]
10717095c: 71000509    	subs	w9, w8, #0x1
107170960: 540000e0    	b.eq	0x10717097c <__Z23_v8_internal_Node_PrintPv+0x3061350>
107170964: aa0803ea    	mov	x10, x8
107170968: 88aafc09    	casl	w10, w9, [x0]
10717096c: 6b08015f    	cmp	w10, w8
107170970: aa0a03e8    	mov	x8, x10
107170974: 54ffff41    	b.ne	0x10717095c <__Z23_v8_internal_Node_PrintPv+0x3061330>
107170978: 14000002    	b	0x107170980 <__Z23_v8_internal_Node_PrintPv+0x3061354>
10717097c: 963bc401    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
107170980: f94007e0    	ldr	x0, [sp, #0x8]
107170984: b40001a0    	cbz	x0, 0x1071709b8 <__Z23_v8_internal_Node_PrintPv+0x306138c>
107170988: b9400808    	ldr	w8, [x0, #0x8]
10717098c: 37080168    	tbnz	w8, #0x1, 0x1071709b8 <__Z23_v8_internal_Node_PrintPv+0x306138c>
107170990: b9400008    	ldr	w8, [x0]
107170994: 71000509    	subs	w9, w8, #0x1
107170998: 540000e0    	b.eq	0x1071709b4 <__Z23_v8_internal_Node_PrintPv+0x3061388>
10717099c: aa0803ea    	mov	x10, x8
1071709a0: 88aafc09    	casl	w10, w9, [x0]
1071709a4: 6b08015f    	cmp	w10, w8
1071709a8: aa0a03e8    	mov	x8, x10
1071709ac: 54ffff41    	b.ne	0x107170994 <__Z23_v8_internal_Node_PrintPv+0x3061368>
1071709b0: 14000002    	b	0x1071709b8 <__Z23_v8_internal_Node_PrintPv+0x306138c>
1071709b4: 963bc3f3    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
1071709b8: 52800000    	mov	w0, #0x0                ; =0
1071709bc: a9437bfd    	ldp	x29, x30, [sp, #0x30]
1071709c0: a9424ff4    	ldp	x20, x19, [sp, #0x20]
1071709c4: a94157f6    	ldp	x22, x21, [sp, #0x10]
1071709c8: 910103ff    	add	sp, sp, #0x40
1071709cc: d65f03c0    	ret
1071709d0: d4200020    	brk	#0x1
1071709d4: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
1071709d8: a9017bfd    	stp	x29, x30, [sp, #0x10]
1071709dc: 910043fd    	add	x29, sp, #0x10
1071709e0: aa0003f3    	mov	x19, x0
1071709e4: d0014968    	adrp	x8, 0x109a9e000 <dyld_stub_binder+0x109a9e000>
1071709e8: 9112a108    	add	x8, x8, #0x4a8
1071709ec: f8020408    	str	x8, [x0], #0x20
1071709f0: 970ccc24    	bl	0x1034a3a80 <_media$cxxbridge1$199$init_symphonia_decoder+0x8ad030>
1071709f4: 91006260    	add	x0, x19, #0x18
1071709f8: 96ede39c    	bl	0x102ce9868 <_media$cxxbridge1$199$init_symphonia_decoder+0xf2e18>
1071709fc: f9400a60    	ldr	x0, [x19, #0x10]
107170a00: b40000e0    	cbz	x0, 0x107170a1c <__Z23_v8_internal_Node_PrintPv+0x30613f0>
107170a04: 12800008    	mov	w8, #-0x1               ; =-1
107170a08: b8e80008    	ldaddal	w8, w8, [x0]
107170a0c: 7100051f    	cmp	w8, #0x1
107170a10: 54000061    	b.ne	0x107170a1c <__Z23_v8_internal_Node_PrintPv+0x30613f0>
107170a14: 96f5c23d    	bl	0x102ee1308 <_media$cxxbridge1$199$init_symphonia_decoder+0x2ea8b8>
107170a18: 946b9dc0    	bl	0x108c58118 <dyld_stub_binder+0x108c58118>
107170a1c: aa1303e0    	mov	x0, x19
107170a20: a9417bfd    	ldp	x29, x30, [sp, #0x10]
107170a24: a8c24ff4    	ldp	x20, x19, [sp], #0x20
107170a28: d65f03c0    	ret
107170a2c: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
107170a30: a9017bfd    	stp	x29, x30, [sp, #0x10]
107170a34: 910043fd    	add	x29, sp, #0x10
107170a38: aa0003f3    	mov	x19, x0
107170a3c: d0014968    	adrp	x8, 0x109a9e000 <dyld_stub_binder+0x109a9e000>
107170a40: 9112a108    	add	x8, x8, #0x4a8
107170a44: f8020408    	str	x8, [x0], #0x20
107170a48: 970ccc0e    	bl	0x1034a3a80 <_media$cxxbridge1$199$init_symphonia_decoder+0x8ad030>
107170a4c: 91006260    	add	x0, x19, #0x18
107170a50: 96ede386    	bl	0x102ce9868 <_media$cxxbridge1$199$init_symphonia_decoder+0xf2e18>
107170a54: f9400a60    	ldr	x0, [x19, #0x10]
107170a58: b40000e0    	cbz	x0, 0x107170a74 <__Z23_v8_internal_Node_PrintPv+0x3061448>
107170a5c: 12800008    	mov	w8, #-0x1               ; =-1
107170a60: b8e80008    	ldaddal	w8, w8, [x0]
107170a64: 7100051f    	cmp	w8, #0x1
107170a68: 54000061    	b.ne	0x107170a74 <__Z23_v8_internal_Node_PrintPv+0x3061448>
107170a6c: 96f5c227    	bl	0x102ee1308 <_media$cxxbridge1$199$init_symphonia_decoder+0x2ea8b8>
107170a70: 946b9daa    	bl	0x108c58118 <dyld_stub_binder+0x108c58118>
107170a74: aa1303e0    	mov	x0, x19
107170a78: 52800b01    	mov	w1, #0x58               ; =88
107170a7c: a9417bfd    	ldp	x29, x30, [sp, #0x10]
107170a80: a8c24ff4    	ldp	x20, x19, [sp], #0x20
107170a84: 163a5ae5    	b	0x100007618 <__text+0x3618>
		...
107170aa0: 1400003f    	b	0x107170b9c <__Z23_v8_internal_Node_PrintPv+0x3061570>
107170aa4: 7100043f    	cmp	w1, #0x1
107170aa8: f00100e8    	adrp	x8, 0x10918f000 <dyld_stub_binder+0x10918f000>
107170aac: 9135a108    	add	x8, x8, #0xd68
107170ab0: 1a9f17e1    	cset	w1, eq
107170ab4: d000dfc9    	adrp	x9, 0x108d6a000 <dyld_stub_binder+0x108d6a000>
107170ab8: 913d0129    	add	x9, x9, #0xf40
107170abc: 9a880120    	csel	x0, x9, x8, eq
107170ac0: d65f03c0    	ret
107170ac4: 14000289    	b	0x1071714e8 <__Z23_v8_internal_Node_PrintPv+0x3061ebc>
107170ac8: 7100043f    	cmp	w1, #0x1
107170acc: f00100e8    	adrp	x8, 0x10918f000 <dyld_stub_binder+0x10918f000>
107170ad0: 913a5108    	add	x8, x8, #0xe94
107170ad4: 1a9f17e1    	cset	w1, eq
107170ad8: d000dfc9    	adrp	x9, 0x108d6a000 <dyld_stub_binder+0x108d6a000>
107170adc: 913d0129    	add	x9, x9, #0xf40
107170ae0: 9a880120    	csel	x0, x9, x8, eq
107170ae4: d65f03c0    	ret
107170ae8: 14000323    	b	0x107171774 <__Z23_v8_internal_Node_PrintPv+0x3062148>
107170aec: 7100043f    	cmp	w1, #0x1
107170af0: f00100e8    	adrp	x8, 0x10918f000 <dyld_stub_binder+0x10918f000>
107170af4: 9137ed08    	add	x8, x8, #0xdfb
107170af8: 1a9f17e1    	cset	w1, eq
107170afc: d000dfc9    	adrp	x9, 0x108d6a000 <dyld_stub_binder+0x108d6a000>
107170b00: 913d0129    	add	x9, x9, #0xf40
107170b04: 9a880120    	csel	x0, x9, x8, eq
107170b08: d65f03c0    	ret
107170b0c: 140004dd    	b	0x107171e80 <__Z23_v8_internal_Node_PrintPv+0x3062854>
107170b10: 7100043f    	cmp	w1, #0x1
107170b14: f00100e8    	adrp	x8, 0x10918f000 <dyld_stub_binder+0x10918f000>
107170b18: 912bb508    	add	x8, x8, #0xaed
107170b1c: 1a9f17e1    	cset	w1, eq
107170b20: d000dfc9    	adrp	x9, 0x108d6a000 <dyld_stub_binder+0x108d6a000>
107170b24: 913d0129    	add	x9, x9, #0xf40
107170b28: 9a880120    	csel	x0, x9, x8, eq
107170b2c: d65f03c0    	ret
107170b30: 140005f2    	b	0x1071722f8 <__Z23_v8_internal_Node_PrintPv+0x3062ccc>
107170b34: 7100043f    	cmp	w1, #0x1
107170b38: f00100e8    	adrp	x8, 0x10918f000 <dyld_stub_binder+0x10918f000>
107170b3c: 912e2908    	add	x8, x8, #0xb8a
107170b40: 1a9f17e1    	cset	w1, eq
107170b44: d000dfc9    	adrp	x9, 0x108d6a000 <dyld_stub_binder+0x108d6a000>
107170b48: 913d0129    	add	x9, x9, #0xf40
107170b4c: 9a880120    	csel	x0, x9, x8, eq
107170b50: d65f03c0    	ret
107170b54: 14000709    	b	0x107172778 <__Z23_v8_internal_Node_PrintPv+0x306314c>
107170b58: 7100043f    	cmp	w1, #0x1
107170b5c: f00100e8    	adrp	x8, 0x10918f000 <dyld_stub_binder+0x10918f000>
107170b60: 91309d08    	add	x8, x8, #0xc27
107170b64: 1a9f17e1    	cset	w1, eq
107170b68: d000dfc9    	adrp	x9, 0x108d6a000 <dyld_stub_binder+0x108d6a000>
107170b6c: 913d0129    	add	x9, x9, #0xf40
107170b70: 9a880120    	csel	x0, x9, x8, eq
107170b74: d65f03c0    	ret
107170b78: 14000a30    	b	0x107173438 <__Z23_v8_internal_Node_PrintPv+0x3063e0c>
107170b7c: 7100043f    	cmp	w1, #0x1
107170b80: f00100e8    	adrp	x8, 0x10918f000 <dyld_stub_binder+0x10918f000>
107170b84: 91331508    	add	x8, x8, #0xcc5
107170b88: 1a9f17e1    	cset	w1, eq
107170b8c: d000dfc9    	adrp	x9, 0x108d6a000 <dyld_stub_binder+0x108d6a000>
107170b90: 913d0129    	add	x9, x9, #0xf40
107170b94: 9a880120    	csel	x0, x9, x8, eq
107170b98: d65f03c0    	ret
107170b9c: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
107170ba0: a90157f6    	stp	x22, x21, [sp, #0x10]
107170ba4: a9024ff4    	stp	x20, x19, [sp, #0x20]
107170ba8: a9037bfd    	stp	x29, x30, [sp, #0x30]
107170bac: 9100c3fd    	add	x29, sp, #0x30
107170bb0: aa0103f3    	mov	x19, x1
107170bb4: aa0003f4    	mov	x20, x0
107170bb8: 785fe028    	ldurh	w8, [x1, #-0x2]
107170bbc: 7100051f    	cmp	w8, #0x1
107170bc0: 54000469    	b.ls	0x107170c4c <__Z23_v8_internal_Node_PrintPv+0x3061620>
107170bc4: 785fe268    	ldurh	w8, [x19, #-0x2]
107170bc8: 531e7508    	lsl	w8, w8, #2
107170bcc: 927d3908    	and	x8, x8, #0x3fff8
107170bd0: d1002108    	sub	x8, x8, #0x8
107170bd4: d342fd16    	lsr	x22, x8, #2
107170bd8: b4000316    	cbz	x22, 0x107170c38 <__Z23_v8_internal_Node_PrintPv+0x306160c>
107170bdc: d2800009    	mov	x9, #0x0                ; =0
107170be0: d0016eb7    	adrp	x23, 0x109f46000 <dyld_stub_binder+0x109f46000>
107170be4: f944e2e8    	ldr	x8, [x23, #0x9c0]
107170be8: 52800038    	mov	w24, #0x1               ; =1
107170bec: d0fe1995    	adrp	x21, 0x1034a2000 <_media$cxxbridge1$199$init_symphonia_decoder+0x8ab5b0>
107170bf0: 911702b5    	add	x21, x21, #0x5c0
107170bf4: 1400000c    	b	0x107170c24 <__Z23_v8_internal_Node_PrintPv+0x30615f8>
107170bf8: f9400288    	ldr	x8, [x20]
107170bfc: f9401508    	ldr	x8, [x8, #0x28]
107170c00: aa1403e0    	mov	x0, x20
107170c04: aa0103e2    	mov	x2, x1
107170c08: aa1503e3    	mov	x3, x21
107170c0c: d63f0100    	blr	x8
107170c10: f944e2e8    	ldr	x8, [x23, #0x9c0]
107170c14: 2a1803e9    	mov	w9, w24
107170c18: eb3842df    	cmp	x22, w24, uxtw
107170c1c: 11000718    	add	w24, w24, #0x1
107170c20: 540000c9    	b.ls	0x107170c38 <__Z23_v8_internal_Node_PrintPv+0x306160c>
107170c24: b8697a69    	ldr	w9, [x19, x9, lsl #2]
107170c28: 93407d29    	sxtw	x9, w9
107170c2c: ea090d01    	ands	x1, x8, x9, lsl #3
107170c30: 54ffff20    	b.eq	0x107170c14 <__Z23_v8_internal_Node_PrintPv+0x30615e8>
107170c34: 17fffff1    	b	0x107170bf8 <__Z23_v8_internal_Node_PrintPv+0x30615cc>
107170c38: a9437bfd    	ldp	x29, x30, [sp, #0x30]
107170c3c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
107170c40: a94157f6    	ldp	x22, x21, [sp, #0x10]
107170c44: a8c45ff8    	ldp	x24, x23, [sp], #0x40
107170c48: d65f03c0    	ret
107170c4c: d1002268    	sub	x8, x19, #0x8
107170c50: 926fb908    	and	x8, x8, #0xfffffffffffe0000
107170c54: f9401d08    	ldr	x8, [x8, #0x38]
107170c58: 17ffffde    	b	0x107170bd0 <__Z23_v8_internal_Node_PrintPv+0x30615a4>
107170c5c: d503201f    	nop
		...
107170c80: f81a0fef    	str	x15, [sp, #-0x60]!
107170c84: a90137ee    	stp	x14, x13, [sp, #0x10]
107170c88: a9022fec    	stp	x12, x11, [sp, #0x20]
107170c8c: a90327ea    	stp	x10, x9, [sp, #0x30]
107170c90: a9044ff4    	stp	x20, x19, [sp, #0x40]
107170c94: a9057bfd    	stp	x29, x30, [sp, #0x50]
107170c98: 910143fd    	add	x29, sp, #0x50
107170c9c: aa0103f3    	mov	x19, x1
107170ca0: aa0003f4    	mov	x20, x0
107170ca4: 29412010    	ldp	w16, w8, [x0, #0x8]
107170ca8: 11000511    	add	w17, w8, #0x1
107170cac: 0b500a10    	add	w16, w16, w16, lsr #2
107170cb0: 11000610    	add	w16, w16, #0x1
107170cb4: 6b11021f    	cmp	w16, w17
107170cb8: 1a888608    	csinc	w8, w16, w8, hi
107170cbc: 52800090    	mov	w16, #0x4               ; =4
107170cc0: 7100111f    	cmp	w8, #0x4
107170cc4: 1a908101    	csel	w1, w8, w16, hi
107170cc8: 94000012    	bl	0x107170d10 <__Z23_v8_internal_Node_PrintPv+0x30616e4>
107170ccc: f9400288    	ldr	x8, [x20]
107170cd0: b9400e90    	ldr	w16, [x20, #0xc]
107170cd4: 8b100900    	add	x0, x8, x16, lsl #2
107170cd8: f9400268    	ldr	x8, [x19]
107170cdc: d343fd08    	lsr	x8, x8, #3
107170ce0: b9000008    	str	w8, [x0]
107170ce4: 967fc6f7    	bl	0x1011628c0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x308e18>
107170ce8: b9400e88    	ldr	w8, [x20, #0xc]
107170cec: 11000508    	add	w8, w8, #0x1
107170cf0: b9000e88    	str	w8, [x20, #0xc]
107170cf4: a9457bfd    	ldp	x29, x30, [sp, #0x50]
107170cf8: a9444ff4    	ldp	x20, x19, [sp, #0x40]
107170cfc: a94327ea    	ldp	x10, x9, [sp, #0x30]
107170d00: a9422fec    	ldp	x12, x11, [sp, #0x20]
107170d04: a94137ee    	ldp	x14, x13, [sp, #0x10]
107170d08: f84607ef    	ldr	x15, [sp], #0x60
107170d0c: d65f03c0    	ret
107170d10: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
107170d14: a9014ff4    	stp	x20, x19, [sp, #0x10]
107170d18: a9027bfd    	stp	x29, x30, [sp, #0x20]
107170d1c: 910083fd    	add	x29, sp, #0x20
107170d20: b9400808    	ldr	w8, [x0, #0x8]
107170d24: 6b08003f    	cmp	w1, w8
107170d28: 54000209    	b.ls	0x107170d68 <__Z23_v8_internal_Node_PrintPv+0x306173c>
107170d2c: aa0103f3    	mov	x19, x1
107170d30: aa0003f4    	mov	x20, x0
107170d34: f9400000    	ldr	x0, [x0]
107170d38: b4000200    	cbz	x0, 0x107170d78 <__Z23_v8_internal_Node_PrintPv+0x306174c>
107170d3c: 52a3ff08    	mov	w8, #0x1ff80000         ; =536346624
107170d40: 6b08027f    	cmp	w19, w8
107170d44: 540003c8    	b.hi	0x107170dbc <__Z23_v8_internal_Node_PrintPv+0x3061790>
107170d48: 531e7668    	lsl	w8, w19, #2
107170d4c: 11001108    	add	w8, w8, #0x4
107170d50: 121d6d15    	and	w21, w8, #0x7ffffff8
107170d54: aa1503e1    	mov	x1, x21
107170d58: 96400b9d    	bl	0x100173bcc <_cxxbridge1$slice$new+0x12e0f0>
107170d5c: 340001c0    	cbz	w0, 0x107170d94 <__Z23_v8_internal_Node_PrintPv+0x3061768>
107170d60: 53027ea8    	lsr	w8, w21, #2
107170d64: b9000a88    	str	w8, [x20, #0x8]
107170d68: a9427bfd    	ldp	x29, x30, [sp, #0x20]
107170d6c: a9414ff4    	ldp	x20, x19, [sp, #0x10]
107170d70: a8c357f6    	ldp	x22, x21, [sp], #0x30
107170d74: d65f03c0    	ret
107170d78: aa1403e0    	mov	x0, x20
107170d7c: aa1303e1    	mov	x1, x19
107170d80: 52800002    	mov	w2, #0x0                ; =0
107170d84: a9427bfd    	ldp	x29, x30, [sp, #0x20]
107170d88: a9414ff4    	ldp	x20, x19, [sp, #0x10]
107170d8c: a8c357f6    	ldp	x22, x21, [sp], #0x30
107170d90: 14000011    	b	0x107170dd4 <__Z23_v8_internal_Node_PrintPv+0x30617a8>
107170d94: 963c9cef    	bl	0x100098150 <_cxxbridge1$slice$new+0x52674>
107170d98: f9400400    	ldr	x0, [x0, #0x8]
107170d9c: 969f581c    	bl	0x101946e0c <_sfv$cxxbridge1$199$decode_dictionary+0x19b90>
107170da0: 36000140    	tbz	w0, #0x0, 0x107170dc8 <__Z23_v8_internal_Node_PrintPv+0x306179c>
107170da4: aa1403e0    	mov	x0, x20
107170da8: aa1303e1    	mov	x1, x19
107170dac: a9427bfd    	ldp	x29, x30, [sp, #0x20]
107170db0: a9414ff4    	ldp	x20, x19, [sp, #0x10]
107170db4: a8c357f6    	ldp	x22, x21, [sp], #0x30
107170db8: 14000025    	b	0x107170e4c <__Z23_v8_internal_Node_PrintPv+0x3061820>
107170dbc: d4200000    	brk	#0
107170dc0: d4400000    	hlt	#0
107170dc4: d4200020    	brk	#0x1
107170dc8: d4200000    	brk	#0
107170dcc: d4400000    	hlt	#0
107170dd0: d4200020    	brk	#0x1
107170dd4: 52a3ff08    	mov	w8, #0x1ff80000         ; =536346624
107170dd8: 6b08003f    	cmp	w1, w8
107170ddc: 54000328    	b.hi	0x107170e40 <__Z23_v8_internal_Node_PrintPv+0x3061814>
107170de0: d10103ff    	sub	sp, sp, #0x40
107170de4: a90157f6    	stp	x22, x21, [sp, #0x10]
107170de8: a9024ff4    	stp	x20, x19, [sp, #0x20]
107170dec: a9037bfd    	stp	x29, x30, [sp, #0x30]
107170df0: 9100c3fd    	add	x29, sp, #0x30
107170df4: aa0203f4    	mov	x20, x2
107170df8: aa0003f3    	mov	x19, x0
107170dfc: 11000428    	add	w8, w1, #0x1
107170e00: 121f7115    	and	w21, w8, #0x3ffffffe
107170e04: f90007f5    	str	x21, [sp, #0x8]
107170e08: 910023e0    	add	x0, sp, #0x8
107170e0c: 94000049    	bl	0x107170f30 <__Z23_v8_internal_Node_PrintPv+0x3061904>
107170e10: f9000260    	str	x0, [x19]
107170e14: b9000a75    	str	w21, [x19, #0x8]
107170e18: 7100069f    	cmp	w20, #0x1
107170e1c: 54000080    	b.eq	0x107170e2c <__Z23_v8_internal_Node_PrintPv+0x3061800>
107170e20: aa0003e1    	mov	x1, x0
107170e24: aa1303e0    	mov	x0, x19
107170e28: 96a7ab68    	bl	0x101b5bbc8 <_media$cxxbridge1$199$SymphoniaDecoder$decode+0x3d390>
107170e2c: a9437bfd    	ldp	x29, x30, [sp, #0x30]
107170e30: a9424ff4    	ldp	x20, x19, [sp, #0x20]
107170e34: a94157f6    	ldp	x22, x21, [sp, #0x10]
107170e38: 910103ff    	add	sp, sp, #0x40
107170e3c: d65f03c0    	ret
107170e40: d4200000    	brk	#0
107170e44: d4400000    	hlt	#0
107170e48: d4200020    	brk	#0x1
107170e4c: d10103ff    	sub	sp, sp, #0x40
107170e50: a90157f6    	stp	x22, x21, [sp, #0x10]
107170e54: a9024ff4    	stp	x20, x19, [sp, #0x20]
107170e58: a9037bfd    	stp	x29, x30, [sp, #0x30]
107170e5c: 9100c3fd    	add	x29, sp, #0x30
107170e60: aa0003f3    	mov	x19, x0
107170e64: 350001c1    	cbnz	w1, 0x107170e9c <__Z23_v8_internal_Node_PrintPv+0x3061870>
107170e68: f9400274    	ldr	x20, [x19]
107170e6c: b9400e68    	ldr	w8, [x19, #0xc]
107170e70: f900027f    	str	xzr, [x19]
107170e74: b9000a7f    	str	wzr, [x19, #0x8]
107170e78: d37ef501    	lsl	x1, x8, #2
107170e7c: aa1403e0    	mov	x0, x20
107170e80: 963ba69f    	bl	0x10005a8fc <_cxxbridge1$slice$new+0x14e20>
107170e84: aa1403e0    	mov	x0, x20
107170e88: a9437bfd    	ldp	x29, x30, [sp, #0x30]
107170e8c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
107170e90: a94157f6    	ldp	x22, x21, [sp, #0x10]
107170e94: 910103ff    	add	sp, sp, #0x40
107170e98: 14000072    	b	0x107171060 <__Z23_v8_internal_Node_PrintPv+0x3061a34>
107170e9c: 52a3ff08    	mov	w8, #0x1ff80000         ; =536346624
107170ea0: 6b08003f    	cmp	w1, w8
107170ea4: 54000408    	b.hi	0x107170f24 <__Z23_v8_internal_Node_PrintPv+0x30618f8>
107170ea8: 11000428    	add	w8, w1, #0x1
107170eac: 121f7115    	and	w21, w8, #0x3ffffffe
107170eb0: f90007f5    	str	x21, [sp, #0x8]
107170eb4: 910023e0    	add	x0, sp, #0x8
107170eb8: 9400001e    	bl	0x107170f30 <__Z23_v8_internal_Node_PrintPv+0x3061904>
107170ebc: aa0003f4    	mov	x20, x0
107170ec0: f9400268    	ldr	x8, [x19]
107170ec4: b4000100    	cbz	x0, 0x107170ee4 <__Z23_v8_internal_Node_PrintPv+0x30618b8>
107170ec8: b40000e8    	cbz	x8, 0x107170ee4 <__Z23_v8_internal_Node_PrintPv+0x30618b8>
107170ecc: b9400e69    	ldr	w9, [x19, #0xc]
107170ed0: d37ef522    	lsl	x2, x9, #2
107170ed4: aa1403e0    	mov	x0, x20
107170ed8: aa0803e1    	mov	x1, x8
107170edc: 964c3935    	bl	0x10047f3b0 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0xb0230>
107170ee0: f9400268    	ldr	x8, [x19]
107170ee4: b9400e69    	ldr	w9, [x19, #0xc]
107170ee8: d37ef521    	lsl	x1, x9, #2
107170eec: aa0803e0    	mov	x0, x8
107170ef0: 963ba683    	bl	0x10005a8fc <_cxxbridge1$slice$new+0x14e20>
107170ef4: f9400260    	ldr	x0, [x19]
107170ef8: 9400005a    	bl	0x107171060 <__Z23_v8_internal_Node_PrintPv+0x3061a34>
107170efc: f9000274    	str	x20, [x19]
107170f00: aa1303e0    	mov	x0, x19
107170f04: aa1403e1    	mov	x1, x20
107170f08: 96a7ab30    	bl	0x101b5bbc8 <_media$cxxbridge1$199$SymphoniaDecoder$decode+0x3d390>
107170f0c: b9000a75    	str	w21, [x19, #0x8]
107170f10: a9437bfd    	ldp	x29, x30, [sp, #0x30]
107170f14: a9424ff4    	ldp	x20, x19, [sp, #0x20]
107170f18: a94157f6    	ldp	x22, x21, [sp, #0x10]
107170f1c: 910103ff    	add	sp, sp, #0x40
107170f20: d65f03c0    	ret
107170f24: d4200000    	brk	#0
107170f28: d4400000    	hlt	#0
107170f2c: d4200020    	brk	#0x1
107170f30: d100c3ff    	sub	sp, sp, #0x30
107170f34: a9014ff4    	stp	x20, x19, [sp, #0x10]
107170f38: a9027bfd    	stp	x29, x30, [sp, #0x20]
107170f3c: 910083fd    	add	x29, sp, #0x20
107170f40: aa0003f3    	mov	x19, x0
107170f44: d0018688    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
107170f48: f946f508    	ldr	x8, [x8, #0xde8]
107170f4c: 910023e9    	add	x9, sp, #0x8
107170f50: d001868a    	adrp	x10, 0x10a242000 <dyld_stub_binder+0x10a242000>
107170f54: f946f94a    	ldr	x10, [x10, #0xdf0]
107170f58: cb090108    	sub	x8, x8, x9
107170f5c: eb0a011f    	cmp	x8, x10
107170f60: 54000063    	b.lo	0x107170f6c <__Z23_v8_internal_Node_PrintPv+0x3061940>
107170f64: 963c9c7b    	bl	0x100098150 <_cxxbridge1$slice$new+0x52674>
107170f68: 14000003    	b	0x107170f74 <__Z23_v8_internal_Node_PrintPv+0x3061948>
107170f6c: f0018160    	adrp	x0, 0x10a19f000 <dyld_stub_binder+0x10a19f000>
107170f70: 9100c000    	add	x0, x0, #0x30
107170f74: f9400268    	ldr	x8, [x19]
107170f78: b4000628    	cbz	x8, 0x10717103c <__Z23_v8_internal_Node_PrintPv+0x3061a10>
107170f7c: f9400000    	ldr	x0, [x0]
107170f80: f940000a    	ldr	x10, [x0]
107170f84: f9400949    	ldr	x9, [x10, #0x10]
107170f88: f100153f    	cmp	x9, #0x5
107170f8c: 540005c9    	b.ls	0x107171044 <__Z23_v8_internal_Node_PrintPv+0x3061a18>
107170f90: 90016b49    	adrp	x9, 0x109ed8000 <dyld_stub_binder+0x109ed8000>
107170f94: 91000129    	add	x9, x9, #0x0
107170f98: b0016b4b    	adrp	x11, 0x109ed9000 <dyld_stub_binder+0x109ed9000>
107170f9c: 9119016b    	add	x11, x11, #0x640
107170fa0: d37ef50c    	lsl	x12, x8, #2
107170fa4: 4b090168    	sub	w8, w11, w9
107170fa8: 53057d08    	lsr	w8, w8, #5
107170fac: 11000508    	add	w8, w8, #0x1
107170fb0: 91003d89    	add	x9, x12, #0xf
107170fb4: 927df122    	and	x2, x9, #0xfffffffffffffff8
107170fb8: f940054a    	ldr	x10, [x10, #0x8]
107170fbc: f9401541    	ldr	x1, [x10, #0x28]
107170fc0: a9442c2a    	ldp	x10, x11, [x1, #0x40]
107170fc4: cb0a016b    	sub	x11, x11, x10
107170fc8: eb02017f    	cmp	x11, x2
107170fcc: 540002a3    	b.lo	0x107171020 <__Z23_v8_internal_Node_PrintPv+0x30619f4>
107170fd0: 8b02014b    	add	x11, x10, x2
107170fd4: f900202b    	str	x11, [x1, #0x40]
107170fd8: b900015f    	str	wzr, [x10]
107170fdc: 12003d0b    	and	w11, w8, #0xffff
107170fe0: 7140117f    	cmp	w11, #0x4, lsl #12      ; =0x4000
107170fe4: 54000322    	b.hs	0x107171048 <__Z23_v8_internal_Node_PrintPv+0x3061a1c>
107170fe8: 37900369    	tbnz	w9, #0x12, 0x107171054 <__Z23_v8_internal_Node_PrintPv+0x3061a28>
107170fec: 12003d08    	and	w8, w8, #0xffff
107170ff0: d3524529    	lsl	x9, x9, #46
107170ff4: 924f3929    	and	x9, x9, #0xfffe000000000000
107170ff8: aa088128    	orr	x8, x9, x8, lsl #32
107170ffc: f9000148    	str	x8, [x10]
