import sys,types,unittest
sys.modules['lldb']=types.SimpleNamespace();sys.modules['lldb_native_tap']=types.SimpleNamespace()
from manual_capability import Manual,OFFSET
class Tests(unittest.TestCase):
 def setUp(self):self.p=Manual(1,2,0x100000,0x800000);self.p.origin=dict(pid=1,tid=2,pc=0x7000,sp=0x8000);self.e=dict(pid=1,tid=2,pc=0x100000+OFFSET,sp=0x4000,lr=0x5000,root=0x800000,size=129,ownBreakpointHit=True)
 def returned(self):self.p.observe_entry(self.e);self.p.authorize(self.e);self.p.observe_return(dict(pid=1,tid=2,pc=0x5000,sp=0x4000,value=136,ownBreakpointHit=True))
 def test_actual_frame_path_one_continue_then_static_register_readback(self):self.returned();self.p.register_readback(136);self.p.authorize_completion(dict(pid=1,tid=2,pc=0x5000,sp=0x4000,ownBreakpointHit=True));self.p.completion(dict(pid=1,tid=2,pc=0x7000,sp=0x8000));self.p.readback(136);self.assertEqual(self.p.phase,'Pass');self.assertEqual(self.p.continues,2);self.assertFalse(self.p.report()['autoTapEventsAdded']);self.assertTrue(self.p.report()['originalPersistentExpressionCompletionQualified'])
 def test_missing_callback_does_not_invalidate_real_frames(self):self.returned();self.p.register_readback(136);self.assertEqual(self.p.phase,'ReturnVerified');self.assertEqual(len(self.p.rows),4)
 def test_wrong_entry_identity_refuses(self):
  for k in ['pid','tid','pc','root','size']:
   with self.subTest(k=k):
    p=Manual(1,2,0x100000,0x800000)
    with self.assertRaises(ValueError):p.observe_entry({**self.e,k:self.e[k]+1})
 def test_wrong_breakpoint_refuses(self):
  with self.assertRaises(ValueError):self.p.observe_entry({**self.e,'ownBreakpointHit':False})
 def test_no_actual_entry_no_continuation(self):
  with self.assertRaises(ValueError):self.p.authorize(self.e)
 def test_changed_sp_or_pc_refuses_continuation(self):
  self.p.observe_entry(self.e)
  with self.assertRaises(ValueError):self.p.authorize({**self.e,'sp':0x9000})
 def test_second_continue_refuses(self):
  self.p.observe_entry(self.e);self.p.authorize(self.e)
  with self.assertRaises(ValueError):self.p.authorize(self.e)
 def test_return_wrong_identity_or_breakpoint_refuses(self):
  for k in ['pid','tid','pc','sp','ownBreakpointHit']:
   self.setUp();self.p.observe_entry(self.e);self.p.authorize(self.e);c=dict(pid=1,tid=2,pc=0x5000,sp=0x4000,value=136,ownBreakpointHit=True);c[k]=False if k=='ownBreakpointHit' else c[k]+1
   with self.assertRaises(ValueError):self.p.observe_return(c)
 def test_no_return_or_mismatch_readback_refuses(self):
  with self.assertRaises(ValueError):self.p.readback(136)
  self.returned()
  with self.assertRaises(ValueError):self.p.register_readback(137)
 def test_completion_before_real_return_refuses(self):
  with self.assertRaises(ValueError):self.p.authorize_completion(self.e)
 def test_completion_wrong_return_context_refuses(self):
  self.returned();self.p.register_readback(136)
  with self.assertRaises(ValueError):self.p.authorize_completion(dict(pid=1,tid=2,pc=0x5004,sp=0x4000,ownBreakpointHit=True))
 def test_completion_wrong_original_context_refuses(self):
  self.returned();self.p.register_readback(136);self.p.authorize_completion(dict(pid=1,tid=2,pc=0x5000,sp=0x4000,ownBreakpointHit=True))
  with self.assertRaises(ValueError):self.p.completion(dict(pid=1,tid=2,pc=0x7004,sp=0x8000))
 def test_type_bool_or_invalid_address_refuses(self):
  with self.assertRaises(ValueError):Manual(True,2,0x100000,0x800000)
if __name__=='__main__':unittest.main(verbosity=2)
