// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/capabilities/worker-identity.js
function workerIdentity(family, options) {
  function canonical2(value) {
    if (value === null || typeof value !== "object")
      return JSON.stringify(value);
    if (Array.isArray(value))
      return `[${value.map(canonical2).join(",")}]`;
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical2(value[key])}`).join(",")}}`;
  }
  return `raveldex:${family}:1:${canonical2(options)}`;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/errors/error.js
var ERROR_CODES = Object.freeze([
  "INVALID_SCHEMA",
  "INVALID_RECORD",
  "INVALID_QUERY",
  "INVALID_OPTIONS",
  "ID_EXISTS",
  "ID_NOT_FOUND",
  "LIMIT_EXCEEDED",
  "QUEUE_FULL",
  "WORK_LIMIT_EXCEEDED",
  "DEADLINE_EXCEEDED",
  "CANCELLED",
  "DISPOSED",
  "MISSING_CAPABILITY",
  "INCOMPATIBLE_CAPABILITY",
  "REVISION_MISMATCH",
  "REVISION_EXHAUSTED",
  "RESOURCE_EXHAUSTED",
  "UNSUPPORTED_ENVIRONMENT",
  "INTERNAL_ERROR"
]);
var RaveldexError = class extends Error {
  code;
  details;
  constructor(code, details = {}) {
    super(`Raveldex: ${code}`);
    this.name = "RaveldexError";
    this.code = code;
    this.details = Object.freeze({
      ...details.path === void 0 ? {} : { path: details.path.slice(0, 256) },
      ...details.limit === void 0 ? {} : { limit: details.limit },
      ...details.actual === void 0 ? {} : { actual: details.actual }
    });
  }
};
function invalid(code, path) {
  throw new RaveldexError(code, { path });
}
function bound(actual, limit, path) {
  if (!Number.isSafeInteger(actual) || actual > limit) {
    throw new RaveldexError("LIMIT_EXCEEDED", { path, limit, actual });
  }
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/data.js
var Admission = class {
  maximum;
  entries = 0;
  constructor(maximum) {
    this.maximum = maximum;
  }
  get count() {
    return this.entries;
  }
  charge(count3, path) {
    this.entries += count3;
    bound(this.entries, this.maximum, path);
  }
};
function ownObject(input, code, path, admission) {
  if (typeof input !== "object" || input === null)
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Object.prototype)
    invalid(code, path);
  const keys = Reflect.ownKeys(input);
  admission.charge(keys.length, path);
  const copy = /* @__PURE__ */ Object.create(null);
  for (const key of keys) {
    if (typeof key !== "string")
      invalid(code, path);
    const descriptor = Object.getOwnPropertyDescriptor(input, key);
    if (!descriptor || !("value" in descriptor))
      invalid(code, path);
    copy[key] = descriptor.value;
  }
  return copy;
}
function ownArray(input, maximum, code, path, admission) {
  if (!Array.isArray(input))
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Array.prototype)
    invalid(code, path);
  bound(input.length, maximum, path);
  const keys = Reflect.ownKeys(input);
  admission.charge(keys.length, path);
  if (keys.length !== input.length + 1)
    invalid(code, path);
  for (const key of keys) {
    if (key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= input.length)) {
      invalid(code, path);
    }
  }
  const copy = [];
  for (let i = 0; i < input.length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(input, String(i));
    if (!descriptor || !("value" in descriptor))
      invalid(code, `${path}[${i}]`);
    copy.push(descriptor.value);
  }
  return copy;
}
function keysOnly(data, allowed, code, path) {
  for (const key of Object.keys(data))
    if (!allowed.includes(key))
      invalid(code, path);
}
function has(data, key) {
  return Object.prototype.hasOwnProperty.call(data, key);
}
function stringValue(input, maximum, code, path) {
  if (typeof input !== "string")
    invalid(code, path);
  bound(input.length, maximum, path);
  return input;
}
function* scanUnicode(value, code, path) {
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, path);
    i += width;
    yield { workUnits: 1 };
  }
}
function codePointWidth(value, index, code, path) {
  const first = value.charCodeAt(index);
  if (first >= 55296 && first <= 56319) {
    const second = value.charCodeAt(index + 1);
    if (!(second >= 56320 && second <= 57343))
      invalid(code, path);
    return 2;
  }
  if (first >= 56320 && first <= 57343)
    invalid(code, path);
  return 1;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/limits/limits.js
var DEFAULT_LIMITS = Object.freeze({
  maxDocuments: 1e4,
  maxTextFields: 32,
  maxMetadataFields: 32,
  maxFieldNameCodeUnits: 64,
  maxIdCodeUnits: 256,
  maxTextValuesPerField: 64,
  maxMetadataValuesPerField: 128,
  maxMetadataStringCodeUnits: 1024,
  maxMetadataCodeUnitsPerRecord: 32768,
  maxTextCodeUnitsPerValue: 65536,
  maxTextCodeUnitsPerRecord: 262144,
  maxCorpusTextCodeUnits: 67108864,
  maxRawTokenCodeUnits: 256,
  maxTermCodeUnits: 256,
  maxTokensPerRecord: 32768,
  maxCorpusTokens: 4e6,
  maxDictionaryEntries: 25e4,
  maxPostingEntries: 2e6,
  maxMutationBatch: 256,
  maxAdmissionEntries: 16384,
  maxQueryNodes: 128,
  maxQueryDepth: 16,
  maxQueryLexicalCodeUnits: 2048,
  maxQueryCodeUnits: 16384,
  maxQueryTokens: 64,
  maxQueryGroups: 64,
  maxVariantsPerGroup: 16,
  maxExpansionsPerGroup: 256,
  maxQueryExpansions: 1024,
  minPrefixCodePoints: 2,
  maxHits: 100,
  maxQueuedOperations: 32,
  maxSearchWorkUnits: 1e7,
  maxMutationWorkUnits: 5e7,
  checkpointWorkUnits: 2048,
  maxDeadlineMs: 6e4
});
function resolveLimits(input = {}, admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries)) {
  const data = ownObject(input, "INVALID_OPTIONS", "limits", admission);
  const result = { ...DEFAULT_LIMITS };
  for (const key of Object.keys(data)) {
    if (!has(DEFAULT_LIMITS, key))
      invalid("INVALID_OPTIONS", "limits");
    const name = key;
    const value = data[key];
    const minimum = name === "maxMetadataFields" || name === "maxQueuedOperations" ? 0 : name === "minPrefixCodePoints" ? 2 : 1;
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid("INVALID_OPTIONS", `limits.${name}`);
    if (name !== "minPrefixCodePoints")
      bound(value, DEFAULT_LIMITS[name], `limits.${name}`);
    result[name] = value;
  }
  if (result.checkpointWorkUnits > Math.min(result.maxSearchWorkUnits, result.maxMutationWorkUnits)) {
    invalid("INVALID_OPTIONS", "limits.checkpointWorkUnits");
  }
  return Object.freeze(result);
}
function validateStateCounts(counts, limits) {
  const pairs = [
    ["documents", "maxDocuments"],
    ["textCodeUnits", "maxCorpusTextCodeUnits"],
    ["tokens", "maxCorpusTokens"],
    ["dictionaryEntries", "maxDictionaryEntries"],
    ["postingEntries", "maxPostingEntries"]
  ];
  for (const [count3, limit] of pairs) {
    if (!Number.isSafeInteger(counts[count3]) || counts[count3] < 0)
      invalid("INTERNAL_ERROR", `state.${count3}`);
    bound(counts[count3], limits[limit], `state.${count3}`);
  }
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/analyzer/basic.js
var BASIC_ANALYZER = Object.freeze({ id: "basic-v1", environmentProfile: "unqualified" });
var START = /[\p{L}\p{N}]/u;
var CONTINUE = /[\p{L}\p{N}\p{M}]/u;
function* analyzeValue(value, valueIndex = 0, limits = DEFAULT_LIMITS, code = "INVALID_RECORD") {
  bound(value.length, limits.maxTextCodeUnitsPerValue, "analysis.value");
  let start = -1;
  let position = 0;
  function emit(end) {
    const raw = value.slice(start, end);
    const term = raw.normalize("NFKC").toLowerCase();
    bound(term.length, limits.maxTermCodeUnits, "analysis.term");
    const token = Object.freeze({ term, valueIndex, position: position++, start, end });
    start = -1;
    return { workUnits: raw.length + term.length, token };
  }
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, "analysis.value");
    const point = value.slice(i, i + width);
    if (start >= 0 && !CONTINUE.test(point))
      yield emit(i);
    if (start < 0 && START.test(point))
      start = i;
    i += width;
    if (start >= 0)
      bound(i - start, limits.maxRawTokenCodeUnits, "analysis.rawToken");
    yield { workUnits: 1 };
  }
  if (start >= 0)
    yield emit(value.length);
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/index/directory.js
var DIRECTORY_SLOTS = 256;
function bucketOf(key) {
  let hash = 2166136261;
  for (let i = 0; i < key.length; i++)
    hash = Math.imul(hash ^ key.charCodeAt(i), 16777619);
  return String((hash >>> 0) % DIRECTORY_SLOTS);
}
function directoryGet(directory2, key) {
  return directory2.buckets[bucketOf(key)]?.[key];
}
function* directoryEntries(directory2) {
  for (const bucket of Object.values(directory2.buckets)) {
    for (const key of Object.keys(bucket))
      yield [key, bucket[key]];
  }
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/addons/phrases/options.js
function sourceEntryCeiling(documents, fields, values) {
  return documents * (1 + fields * (1 + values));
}
function capturePhraseOptions(input, source2) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const options = ownObject(input, "INVALID_OPTIONS", "addons.options", admission);
  keysOnly(options, source2 ? ["fields", "id", "maxRetainedEntries", "maxWorkUnits"] : ["fields", "id", "maxWorkUnits"], "INVALID_OPTIONS", "addons.options");
  const fieldsInput = ownArray(options.fields, DEFAULT_LIMITS.maxTextFields, "INVALID_OPTIONS", "addons.fields", admission);
  if (fieldsInput.length === 0)
    invalid("INVALID_OPTIONS", "addons.fields");
  const seen = /* @__PURE__ */ new Set();
  const fields = Object.freeze(fieldsInput.map((value) => {
    const field = stringValue(value, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", "addons.fields");
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) || field === "constructor" || field === "prototype" || seen.has(field))
      invalid("INVALID_OPTIONS", "addons.fields");
    seen.add(field);
    return field;
  }));
  const id = has(options, "id") ? stringValue(options.id, 64, "INVALID_OPTIONS", "addons.id") : source2 ? "source" : "source-phrases";
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "addons.id");
  const workCeiling = source2 ? DEFAULT_LIMITS.maxMutationWorkUnits : DEFAULT_LIMITS.maxSearchWorkUnits;
  const maxWorkUnits = has(options, "maxWorkUnits") ? options.maxWorkUnits : workCeiling;
  if (typeof maxWorkUnits !== "number" || !Number.isSafeInteger(maxWorkUnits) || maxWorkUnits < 1)
    invalid("INVALID_OPTIONS", "addons.maxWorkUnits");
  bound(maxWorkUnits, workCeiling, "addons.maxWorkUnits");
  const entryCeiling = sourceEntryCeiling(DEFAULT_LIMITS.maxDocuments, fields.length, DEFAULT_LIMITS.maxTextValuesPerField);
  const maxRetainedEntries = source2 && has(options, "maxRetainedEntries") ? options.maxRetainedEntries : source2 ? entryCeiling : 0;
  if (typeof maxRetainedEntries !== "number" || !Number.isSafeInteger(maxRetainedEntries) || maxRetainedEntries < 0)
    invalid("INVALID_OPTIONS", "addons.maxRetainedEntries");
  bound(maxRetainedEntries, entryCeiling, "addons.maxRetainedEntries");
  return Object.freeze({ fields, id, maxWorkUnits, maxRetainedEntries });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/index/staging.js
function emptyDirectory() {
  return Object.freeze({ size: 0, buckets: Object.freeze(/* @__PURE__ */ Object.create(null)) });
}
var DirectoryStage = class {
  original;
  charge;
  counts;
  pointers;
  touched = /* @__PURE__ */ new Map();
  count;
  sealed = false;
  constructor(original, charge, counts) {
    this.original = original;
    this.charge = charge;
    this.counts = counts;
    this.count = original.size;
  }
  get size() {
    return this.count;
  }
  get(key) {
    return (this.pointers ?? this.original.buckets)[bucketOf(key)]?.[key];
  }
  *bucket(slot) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    if (!this.pointers) {
      const pointers = /* @__PURE__ */ Object.create(null);
      if (this.counts)
        this.counts.directories++;
      for (const slot2 of Object.keys(this.original.buckets)) {
        yield this.charge(1);
        pointers[slot2] = this.original.buckets[slot2];
        if (this.counts)
          this.counts.directoryPointers++;
      }
      this.pointers = pointers;
    }
    const cached = this.touched.get(slot);
    if (cached)
      return cached;
    const bucket = /* @__PURE__ */ Object.create(null);
    if (this.counts)
      this.counts.buckets++;
    const previous = this.original.buckets[slot];
    for (const entry of Object.keys(previous ?? {})) {
      yield this.charge(entry.length + 1);
      bucket[entry] = previous[entry];
      if (this.counts)
        this.counts.bucketEntries++;
    }
    this.touched.set(slot, bucket);
    this.pointers[slot] = bucket;
    return bucket;
  }
  *set(key, value) {
    yield this.charge(key.length + 1);
    const bucket = yield* this.bucket(bucketOf(key));
    if (!Object.hasOwn(bucket, key)) {
      this.count++;
      if (this.counts)
        this.counts.insertions++;
    }
    bucket[key] = value;
    if (this.counts)
      this.counts.writes++;
  }
  *delete(key) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    yield this.charge(key.length + 1);
    const slot = bucketOf(key);
    if ((this.pointers ?? this.original.buckets)[slot]?.[key] === void 0)
      return;
    const bucket = yield* this.bucket(slot);
    delete bucket[key];
    this.count--;
    if (this.counts)
      this.counts.deletes++;
  }
  *finish() {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    this.sealed = true;
    if (!this.pointers)
      return this.original;
    for (const [slot, bucket] of this.touched) {
      const keys = Object.keys(bucket);
      for (const key of keys)
        yield this.charge(key.length + 1);
      if (keys.length)
        Object.freeze(bucket);
      else
        delete this.pointers[slot];
    }
    for (const slot of Object.keys(this.pointers)) {
      void slot;
      yield this.charge(1);
    }
    return Object.freeze({ size: this.count, buckets: Object.freeze(this.pointers) });
  }
};

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/addons/phrases/store.js
var rawCharge = (workUnits) => ({ workUnits });
function requireSourceRoot(input, field, revision, analyzer) {
  if (input === void 0 || input === null)
    invalid("MISSING_CAPABILITY", "phrases.source");
  if (typeof input !== "object" || !Object.isFrozen(input))
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.source");
  const root = input;
  if (root.kind !== "raveldex-source-v1" || !Array.isArray(root.fields) || !Object.isFrozen(root.fields) || root.fields.length === 0 || root.fields.length > DEFAULT_LIMITS.maxTextFields || typeof root.analyzer !== "object" || root.analyzer === null || !Object.isFrozen(root.analyzer) || typeof root.records !== "object" || root.records === null || !Object.isFrozen(root.records) || !Number.isSafeInteger(root.records.size) || root.records.size < 0 || root.records.size > DEFAULT_LIMITS.maxDocuments || typeof root.records.buckets !== "object" || root.records.buckets === null || !Object.isFrozen(root.records.buckets) || !Number.isSafeInteger(root.revision) || root.revision < 0 || !Number.isSafeInteger(root.retainedEntries) || root.retainedEntries < 0 || !Number.isSafeInteger(root.textCodeUnits) || root.textCodeUnits < 0 || !Number.isSafeInteger(root.maxRetainedEntries) || root.maxRetainedEntries < root.retainedEntries || !Number.isSafeInteger(root.maxTextCodeUnits) || root.maxTextCodeUnits < root.textCodeUnits)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.source");
  if (!root.fields.includes(field))
    invalid("MISSING_CAPABILITY", "phrases.source.field");
  if (root.revision !== revision)
    invalid("REVISION_MISMATCH", "phrases.source.revision");
  if (root.analyzer.id !== analyzer.id || root.analyzer.environmentProfile !== analyzer.environmentProfile)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.analyzer");
  return root;
}
function* retainRecord(record, fields) {
  const text = /* @__PURE__ */ Object.create(null);
  let retainedEntries = 1, textCodeUnits = 0;
  for (const field of fields) {
    yield rawCharge(field.length + 1);
    if (!has(record.text, field))
      continue;
    const values = record.text[field];
    if (!Object.isFrozen(values))
      invalid("INTERNAL_ERROR", "source.record.values");
    retainedEntries += 1 + values.length;
    for (const value of values) {
      yield rawCharge(1);
      textCodeUnits += value.length;
    }
    text[field] = values;
  }
  return Object.freeze({ text: Object.freeze(text), retainedEntries, textCodeUnits });
}
function initialRoot(configuration, fields, requestedEntries) {
  for (const field of fields)
    if (!has(configuration.schema.text, field))
      invalid("MISSING_CAPABILITY", "source.fields");
  const maxRetainedEntries = Math.min(requestedEntries, sourceEntryCeiling(configuration.limits.maxDocuments, fields.length, configuration.limits.maxTextValuesPerField));
  return Object.freeze({
    kind: "raveldex-source-v1",
    revision: 0,
    analyzer: Object.freeze({ id: configuration.analyzer.id, environmentProfile: configuration.analyzer.environmentProfile }),
    fields,
    records: emptyDirectory(),
    retainedEntries: 0,
    textCodeUnits: 0,
    maxRetainedEntries,
    maxTextCodeUnits: configuration.limits.maxCorpusTextCodeUnits
  });
}
function* prepareSource(previous, context, fields) {
  const old = requireSourceRoot(previous, fields[0], context.previousRevision, context.analyzer);
  if (context.revision !== context.previousRevision + 1 || !Number.isSafeInteger(context.revision))
    invalid("REVISION_MISMATCH", "source.revision");
  if (context.kind === "clear") {
    yield rawCharge(1);
    return Object.freeze({ ...old, revision: context.revision, records: emptyDirectory(), retainedEntries: 0, textCodeUnits: 0 });
  }
  const stage = new DirectoryStage(old.records, rawCharge);
  let retainedEntries = old.retainedEntries, textCodeUnits = old.textCodeUnits;
  for (const id of context.removedIds) {
    yield rawCharge(id.length + 1);
    const retained = stage.get(id);
    if (!retained)
      invalid("MISSING_CAPABILITY", "source.record");
    retainedEntries -= retained.retainedEntries;
    textCodeUnits -= retained.textCodeUnits;
    yield* stage.delete(id);
  }
  for (const record of context.records) {
    yield rawCharge(record.id.length + 1);
    const retained = stage.get(record.id);
    if (context.kind === "replace" && !retained)
      invalid("MISSING_CAPABILITY", "source.record");
    if (context.kind !== "replace" && retained)
      invalid("INCOMPATIBLE_CAPABILITY", "source.record");
    if (retained) {
      retainedEntries -= retained.retainedEntries;
      textCodeUnits -= retained.textCodeUnits;
    }
    const next = yield* retainRecord(record, fields);
    retainedEntries += next.retainedEntries;
    textCodeUnits += next.textCodeUnits;
    bound(retainedEntries, old.maxRetainedEntries, "source.retainedEntries");
    bound(textCodeUnits, old.maxTextCodeUnits, "source.textCodeUnits");
    yield* stage.set(record.id, next);
  }
  if (retainedEntries < 0 || textCodeUnits < 0)
    invalid("INCOMPATIBLE_CAPABILITY", "source.counts");
  const records = yield* stage.finish();
  return Object.freeze({ ...old, revision: context.revision, records, retainedEntries, textCodeUnits });
}
function createSourceProvider(options) {
  const captured = capturePhraseOptions(options, true);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["transaction-participant"]),
      provides: Object.freeze(captured.fields.map((field) => Object.freeze({ id: `source:${field}`, contractVersion: 1 }))),
      requires: Object.freeze([]),
      dataRequirements: Object.freeze({ fields: captured.fields, source: true, positions: false, offsets: false, metadata: false }),
      indexEffect: "transactional",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("source", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: captured.maxRetainedEntries, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Selected-source capture and copy-on-write directory staging; no phrase verifier.", retainedRepresentation: "One entry per record, present selected field and original value; selected original UTF-16 strings only.", transientWork: "Changed selected-field values and touched source-directory buckets; shared mutation budget.", externalResources: "none" }),
      codec: Object.freeze({ id: "raveldex-source-v1", version: 1 })
    }),
    participant: Object.freeze({
      initialize: (configuration) => initialRoot(configuration, captured.fields, captured.maxRetainedEntries),
      prepare: (previous, context) => prepareSource(previous, context, captured.fields)
    })
  });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/query/work.js
function* compareStrings(a, b, charge) {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    yield charge(1);
    const difference = a.charCodeAt(i) - b.charCodeAt(i);
    if (difference)
      return difference;
  }
  yield charge(1);
  return a.length - b.length;
}
function* sortedStrings(input, charge) {
  const output = [];
  for (const value of input) {
    yield charge(value.length + 1);
    let i = output.length;
    while (i > 0 && (yield* compareStrings(value, output[i - 1], charge)) < 0) {
      yield charge(1);
      output[i] = output[i - 1];
      i--;
    }
    output[i] = value;
  }
  return output;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/addons/phrases/verifier.js
var rawCharge2 = (workUnits) => ({ workUnits });
function* phraseFailureTable(terms) {
  const failure = [];
  if (terms.length) {
    yield rawCharge2(1);
    failure.push(0);
  }
  for (let i = 1; i < terms.length; i++) {
    let matched = failure[i - 1];
    for (; ; ) {
      if ((yield* compareStrings(terms[i], terms[matched], rawCharge2)) === 0) {
        matched++;
        break;
      }
      if (matched === 0)
        break;
      yield rawCharge2(1);
      matched = failure[matched - 1];
    }
    yield rawCharge2(1);
    failure.push(matched);
  }
  return Object.freeze(failure);
}
function* sourceValueMatches(value, valueIndex, terms, failure, limits) {
  if (terms.length === 0)
    return false;
  let matched = 0;
  for (const step of analyzeValue(value, valueIndex, limits)) {
    yield rawCharge2(step.workUnits);
    if (!step.token)
      continue;
    for (; ; ) {
      if ((yield* compareStrings(step.token.term, terms[matched], rawCharge2)) === 0) {
        matched++;
        if (matched === terms.length)
          return true;
        break;
      }
      if (matched === 0)
        break;
      yield rawCharge2(1);
      matched = failure[matched - 1];
    }
  }
  return false;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/addons/phrases/index.js
var MAX_PHRASE_TOKENS = 32;
var rawCharge3 = (workUnits) => ({ workUnits });
function* preparePhrase(context, enabledFields) {
  if (context.analyzer.id !== BASIC_ANALYZER.id)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.analyzer");
  bound(context.terms.length, Math.min(MAX_PHRASE_TOKENS, context.limits.maxQueryTokens), "phrases.tokens");
  const fields = [];
  for (const field of context.fields) {
    yield rawCharge3(field.length + enabledFields.length + 1);
    if (!enabledFields.includes(field))
      invalid("MISSING_CAPABILITY", "phrases.field");
    const root = requireSourceRoot(context.state(`source:${field}`), field, context.revision, context.analyzer);
    yield rawCharge3(root.fields.length + 1);
    fields.push(Object.freeze({ name: field, root }));
  }
  const failure = yield* phraseFailureTable(context.terms);
  const sources = Object.freeze(fields);
  const terms = context.terms, limits = context.limits;
  return Object.freeze({
    *test(id) {
      const records = [];
      for (const field of sources) {
        yield rawCharge3(id.length + 1);
        const record = directoryGet(field.root.records, id);
        if (!record)
          invalid("MISSING_CAPABILITY", "phrases.source.record");
        if (!Object.isFrozen(record) || typeof record.text !== "object" || record.text === null || !Object.isFrozen(record.text))
          invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.record");
        records.push({ field: field.name, record });
      }
      for (const { field, record } of records) {
        const values = record.text[field];
        if (!values)
          continue;
        if (!Array.isArray(values) || !Object.isFrozen(values) || values.length > limits.maxTextValuesPerField)
          invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.values");
        for (let i = 0; i < values.length; i++) {
          yield rawCharge3(1);
          if (typeof values[i] !== "string")
            invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.values");
          if (yield* sourceValueMatches(values[i], i, terms, failure, limits))
            return true;
        }
      }
      return false;
    }
  });
}
function createSourcePhrases(options) {
  const captured = capturePhraseOptions(options, false);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["leaf-refinement"]),
      provides: Object.freeze([Object.freeze({ id: "phrases", contractVersion: 1 })]),
      requires: Object.freeze(captured.fields.map((field) => Object.freeze({ id: `source:${field}`, contractVersion: 1 }))),
      dataRequirements: Object.freeze({ fields: captured.fields, source: true, positions: false, offsets: false, metadata: false }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("source-phrases", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Native analyzer, resumable source phrase verifier and selected-source protocol.", retainedRepresentation: "No additional index state; source providers retain declared originals.", transientWork: "At most 32 phrase-prefix entries plus one current token; complete lexical candidates are scanned under the shared search budget.", externalResources: "none" })
    }),
    refinement: Object.freeze({
      kind: "exact-token-sequence",
      maxTokens: MAX_PHRASE_TOKENS,
      prepare: (context) => preparePhrase(context, captured.fields)
    })
  });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/capabilities/registration.js
function captureRegistrations(input, context) {
  const { schema, limits, admission } = context, code = "INCOMPATIBLE_CAPABILITY";
  const entries = ownArray(input, 32, code, "addons", admission);
  const registrations = /* @__PURE__ */ new Map();
  const providers = /* @__PURE__ */ Object.create(null);
  const object3 = (value, path, keys) => {
    const data = ownObject(value, code, path, admission);
    keysOnly(data, keys, code, path);
    return data;
  };
  const string = (value, path, maximum = 128) => {
    const result = stringValue(value, maximum, code, path);
    if (!result.length)
      invalid(code, path);
    for (const step of scanUnicode(result, code, path)) {
      void step;
    }
    return result;
  };
  const id = (value, path) => {
    const result = string(value, path);
    if (!/^[A-Za-z][A-Za-z0-9:._-]*$/.test(result))
      invalid(code, path);
    return result;
  };
  const integer3 = (value, path, minimum = 0) => {
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid(code, path);
    return value;
  };
  const flag = (value, path) => {
    if (typeof value !== "boolean")
      invalid(code, path);
    return value;
  };
  const references = (value, path) => {
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(ownArray(value, 64, code, path, admission).map((value2) => {
      const ref = object3(value2, path, ["id", "contractVersion"]), name = id(ref.id, path);
      if (ref.contractVersion !== 1 || seen.has(name))
        invalid(code, path);
      seen.add(name);
      return Object.freeze({ id: name, contractVersion: 1 });
    }));
  };
  for (const entry of entries) {
    const data = object3(entry, "addons.registration", ["manifest", "participant", "refinement", "predicate", "aggregation", "evidence"]);
    const raw = object3(data.manifest, "addons.manifest", ["id", "version", "contractVersion", "roles", "provides", "requires", "dataRequirements", "indexEffect", "rebuildPolicy", "execution", "limits", "costs", "codec"]);
    const name = id(raw.id, "addons.id"), version = string(raw.version, "addons.version");
    const semanticVersion = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/;
    if (!semanticVersion.test(version) || raw.contractVersion !== 1 || registrations.has(name))
      invalid(code, "addons.identity");
    const roles = ownArray(raw.roles, 4, code, "addons.roles", admission);
    if (!roles.length || new Set(roles).size !== roles.length || roles.some((role) => role !== "leaf-refinement" && role !== "transaction-participant" && role !== "aggregation" && role !== "evidence"))
      invalid(code, "addons.roles");
    const requirements = object3(raw.dataRequirements, "addons.dataRequirements", ["fields", "source", "positions", "offsets", "metadata"]);
    const metadata2 = flag(requirements.metadata, "addons.metadata");
    const fields = ownArray(requirements.fields, metadata2 ? limits.maxMetadataFields : limits.maxTextFields, code, "addons.fields", admission).map((field) => {
      const name2 = id(field, "addons.fields");
      if (!has(metadata2 ? schema.metadata : schema.text, name2))
        invalid(code, "addons.fields");
      return name2;
    });
    if (new Set(fields).size !== fields.length)
      invalid(code, "addons.fields");
    const execution = object3(raw.execution, "addons.execution", ["direct", "worker", "workerRegistration"]);
    if (execution.direct !== true || typeof execution.worker !== "boolean" || execution.worker !== has(execution, "workerRegistration"))
      invalid(code, "addons.execution");
    const workerRegistration = execution.worker ? string(execution.workerRegistration, "addons.workerRegistration", 8192) : void 0;
    const caps = object3(raw.limits, "addons.limits", ["maxPayloadCodeUnits", "maxWorkUnits", "maxRetainedEntries", "maxOutputEntries"]);
    const ownedLimits = Object.freeze({ maxPayloadCodeUnits: integer3(caps.maxPayloadCodeUnits, "addons.limits", 1), maxWorkUnits: integer3(caps.maxWorkUnits, "addons.limits", 1), maxRetainedEntries: integer3(caps.maxRetainedEntries, "addons.limits"), maxOutputEntries: integer3(caps.maxOutputEntries, "addons.limits") });
    if (ownedLimits.maxPayloadCodeUnits > DEFAULT_LIMITS.maxQueryCodeUnits || ownedLimits.maxWorkUnits > Math.max(DEFAULT_LIMITS.maxSearchWorkUnits, DEFAULT_LIMITS.maxMutationWorkUnits))
      invalid(code, "addons.limits");
    const costs = object3(raw.costs, "addons.costs", ["importedCode", "retainedRepresentation", "transientWork", "externalResources"]);
    if (costs.externalResources !== "none" || raw.rebuildPolicy !== "new-index")
      invalid(code, "addons.costs");
    const participantRole = roles.includes("transaction-participant"), refinementRole = roles.includes("leaf-refinement"), aggregationRole = roles.includes("aggregation"), evidenceRole = roles.includes("evidence");
    if (participantRole !== has(data, "participant") || refinementRole !== (has(data, "refinement") || has(data, "predicate")) || has(data, "refinement") && has(data, "predicate") || aggregationRole !== has(data, "aggregation") || evidenceRole !== has(data, "evidence") || raw.indexEffect !== (participantRole ? "transactional" : "none"))
      invalid(code, "addons.roles");
    if ((has(data, "predicate") || aggregationRole) && (!metadata2 || participantRole || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.dataRequirements");
    if (evidenceRole && (participantRole || metadata2 || requirements.offsets === true && requirements.positions !== true))
      invalid(code, "addons.dataRequirements");
    const implementations = {};
    for (const key of ["participant", "refinement", "predicate", "aggregation", "evidence"]) {
      if (!has(data, key))
        continue;
      const methods = key === "participant" ? ["initialize", "prepare"] : key === "refinement" ? ["prepare"] : key === "evidence" ? ["capture", "select", "prepare"] : ["capture", "prepare"];
      const attributes = key === "refinement" ? ["kind", "maxTokens"] : key === "aggregation" ? ["fieldType"] : [];
      const handles = object3(data[key], `addons.${key}`, [...methods, ...attributes]);
      for (const method of methods) {
        const callback = handles[method];
        if (typeof callback !== "function")
          invalid(code, `addons.${key}`);
        handles[method] = callback.bind(data[key]);
      }
      if (key === "refinement" && (handles.kind !== "exact-token-sequence" || integer3(handles.maxTokens, "addons.maxTokens", 1) > DEFAULT_LIMITS.maxQueryTokens))
        invalid(code, "addons.refinement");
      if (key === "aggregation" && (handles.fieldType !== "string" || fields.some((field) => schema.metadata[field]?.type !== handles.fieldType)))
        invalid(code, "addons.aggregation");
      implementations[key] = Object.freeze(handles);
    }
    let codec;
    if (has(raw, "codec")) {
      const value = object3(raw.codec, "addons.codec", ["id", "version"]);
      codec = Object.freeze({ id: id(value.id, "addons.codec"), version: integer3(value.version, "addons.codec", 1) });
    }
    const manifest = Object.freeze({
      id: name,
      version,
      contractVersion: 1,
      roles: Object.freeze(roles),
      provides: references(raw.provides, "addons.provides"),
      requires: references(raw.requires, "addons.requires"),
      dataRequirements: Object.freeze({ fields: Object.freeze(fields.sort()), source: flag(requirements.source, "addons.source"), positions: flag(requirements.positions, "addons.positions"), offsets: flag(requirements.offsets, "addons.offsets"), metadata: metadata2 }),
      indexEffect: participantRole ? "transactional" : "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: execution.worker, ...workerRegistration ? { workerRegistration } : {} }),
      limits: ownedLimits,
      costs: Object.freeze({ importedCode: string(costs.importedCode, "addons.costs", 1024), retainedRepresentation: string(costs.retainedRepresentation, "addons.costs", 1024), transientWork: string(costs.transientWork, "addons.costs", 1024), externalResources: "none" }),
      ...codec ? { codec } : {}
    });
    const captured = Object.freeze({ manifest, ...implementations });
    registrations.set(name, captured);
    if (!manifest.provides.length)
      invalid(code, "addons.provides");
    for (const provided of manifest.provides) {
      if (has(providers, provided.id))
        invalid(code, "addons.providers");
      providers[provided.id] = captured;
    }
  }
  const ordered = [], visited = /* @__PURE__ */ new Set(), active = /* @__PURE__ */ new Set();
  function visit(registration) {
    const { manifest } = registration;
    if (visited.has(manifest.id))
      return;
    if (active.has(manifest.id))
      invalid(code, "addons.cycle");
    active.add(manifest.id);
    for (const requirement of [...manifest.requires].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0)) {
      const provider = providers[requirement.id];
      if (!provider)
        invalid("MISSING_CAPABILITY", "addons.requires");
      visit(provider);
    }
    const data = manifest.dataRequirements;
    if ((data.source || data.positions) && registration.refinement)
      for (const field of data.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field}`) && !!providers[`${kind}:${field}`]?.participant;
        if (!(data.source && present("source") || data.positions && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    if (registration.evidence && (data.source || data.positions || data.offsets))
      for (const field of data.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field}`) && !!providers[`${kind}:${field}`]?.participant;
        if (!(data.source && present("source") || data.offsets && present("offsets") || data.positions && !data.offsets && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    active.delete(manifest.id);
    visited.add(manifest.id);
    ordered.push(registration);
  }
  for (const name of [...registrations.keys()].sort())
    visit(registrations.get(name));
  return Object.freeze({ ordered: Object.freeze(ordered), providers: Object.freeze(providers) });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/schema.js
function captureSchema(input, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const schema = ownObject(input, "INVALID_SCHEMA", "schema", admission);
  keysOnly(schema, ["text", "metadata"], "INVALID_SCHEMA", "schema");
  const text = ownObject(schema.text, "INVALID_SCHEMA", "schema.text", admission);
  const metadata2 = has(schema, "metadata") ? ownObject(schema.metadata, "INVALID_SCHEMA", "schema.metadata", admission) : /* @__PURE__ */ Object.create(null);
  const textNames = Object.keys(text);
  const metadataNames = Object.keys(metadata2);
  if (textNames.length === 0)
    invalid("INVALID_SCHEMA", "schema.text");
  bound(textNames.length, limits.maxTextFields, "schema.text");
  bound(metadataNames.length, limits.maxMetadataFields, "schema.metadata");
  const ownedText = /* @__PURE__ */ Object.create(null);
  const ownedMetadata = /* @__PURE__ */ Object.create(null);
  for (const [group, names] of [[text, textNames], [metadata2, metadataNames]]) {
    for (const name of names) {
      if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(name) || name === "constructor" || name === "prototype")
        invalid("INVALID_SCHEMA", "schema.fields");
      bound(name.length, limits.maxFieldNameCodeUnits, "schema.fields");
      if (has(text, name) && has(metadata2, name))
        invalid("INVALID_SCHEMA", "schema.fields");
      const path = `schema.${group === text ? "text" : "metadata"}.${name}`;
      const field = ownObject(group[name], "INVALID_SCHEMA", path, admission);
      if (group === text) {
        keysOnly(field, ["boost"], "INVALID_SCHEMA", path);
        const boost = has(field, "boost") ? field.boost : 1;
        if (typeof boost !== "number" || !Number.isFinite(boost) || boost <= 0 || boost > 16)
          invalid("INVALID_SCHEMA", `${path}.boost`);
        ownedText[name] = Object.freeze({ boost });
      } else {
        keysOnly(field, ["type", "multi", "nullable"], "INVALID_SCHEMA", path);
        if (field.type !== "string" && field.type !== "number" && field.type !== "boolean")
          invalid("INVALID_SCHEMA", `${path}.type`);
        const multi = has(field, "multi") ? field.multi : false;
        const nullable = has(field, "nullable") ? field.nullable : false;
        if (typeof multi !== "boolean" || typeof nullable !== "boolean")
          invalid("INVALID_SCHEMA", path);
        ownedMetadata[name] = Object.freeze({ type: field.type, multi, nullable });
      }
    }
  }
  return Object.freeze({ text: Object.freeze(ownedText), metadata: Object.freeze(ownedMetadata) });
}
function captureConfiguration(input) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const config = ownObject(input, "INVALID_OPTIONS", "config", admission);
  keysOnly(config, ["schema", "limits", "analyzer", "addons"], "INVALID_OPTIONS", "config");
  if (has(config, "limits") && config.limits === void 0)
    invalid("INVALID_OPTIONS", "config.limits");
  const limits = has(config, "limits") ? resolveLimits(config.limits, admission) : DEFAULT_LIMITS;
  const schema = captureSchema(config.schema, limits, admission);
  if (has(config, "analyzer")) {
    const analyzer = ownObject(config.analyzer, "INVALID_OPTIONS", "config.analyzer", admission);
    keysOnly(analyzer, ["id", "environmentProfile"], "INVALID_OPTIONS", "config.analyzer");
    if (typeof analyzer.id !== "string" || typeof analyzer.environmentProfile !== "string")
      invalid("INVALID_OPTIONS", "config.analyzer");
    if (analyzer.id !== BASIC_ANALYZER.id)
      invalid("MISSING_CAPABILITY", "config.analyzer");
    if (analyzer.environmentProfile !== BASIC_ANALYZER.environmentProfile)
      invalid("INCOMPATIBLE_CAPABILITY", "config.analyzer");
  }
  const capabilities = has(config, "addons") ? captureRegistrations(config.addons, { schema, limits, admission }) : void 0;
  bound(admission.count, limits.maxAdmissionEntries, "config");
  return Object.freeze({ schema, limits, analyzer: BASIC_ANALYZER, ...capabilities?.ordered.length ? { capabilities } : {} });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/capabilities/participants.js
function initializeParticipants(configuration) {
  const states = /* @__PURE__ */ Object.create(null);
  const participants = [];
  for (const registration of configuration.capabilities?.ordered ?? []) {
    const handle = registration.participant;
    if (!handle)
      continue;
    const id = registration.manifest.id;
    states[id] = handle.initialize(configuration);
    participants.push(Object.freeze({ id, maxWorkUnits: Math.min(registration.manifest.limits.maxWorkUnits, configuration.limits.maxMutationWorkUnits), *prepare(previous, context) {
      const removedIds = [];
      for (const change of context.changes)
        if (change.previous && !change.next) {
          yield { workUnits: change.previous.id.length + 1 };
          removedIds.push(change.previous.id);
        }
      const request = Object.freeze({ kind: context.kind, previousRevision: context.previous.revision, revision: context.core.revision, analyzer: configuration.analyzer, records: context.records, removedIds: Object.freeze(removedIds) });
      const cursor = handle.prepare(previous, request);
      try {
        for (; ; ) {
          const step = cursor.next();
          if (step.done)
            return step.value;
          yield step.value;
        }
      } finally {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    } }));
  }
  return Object.freeze({ states: Object.freeze(states), participants: Object.freeze(participants) });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/limits/work.js
var WorkBudget = class {
  maximum;
  policy = "work-v1";
  used = 0;
  constructor(maximum) {
    this.maximum = maximum;
  }
  get consumed() {
    return this.used;
  }
  charge(units) {
    if (!Number.isSafeInteger(units) || units < 0)
      invalid("INTERNAL_ERROR", "work.units");
    this.used += units;
    if (!Number.isSafeInteger(this.used) || this.used > this.maximum)
      invalid("WORK_LIMIT_EXCEEDED", "work");
  }
};
function validateExpansionCounts(perGroup, wholeQuery, limits) {
  for (const count3 of [perGroup, wholeQuery])
    if (!Number.isSafeInteger(count3) || count3 < 0)
      invalid("INTERNAL_ERROR", "expansions");
  bound(perGroup, limits.maxExpansionsPerGroup, "expansions.group");
  bound(wholeQuery, limits.maxQueryExpansions, "expansions.query");
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/record.js
function captureId(input, limits, code, path) {
  const id = stringValue(input, limits.maxIdCodeUnits, code, path);
  if (!id.length)
    invalid(code, path);
  return id;
}
function captureScalar(input, field, limits, code, path) {
  if (input === null && field.nullable)
    return null;
  if (typeof input !== field.type)
    invalid(code, path);
  if (typeof input === "number") {
    if (!Number.isFinite(input))
      invalid(code, path);
    return input === 0 ? 0 : input;
  }
  if (typeof input === "string")
    return stringValue(input, limits.maxMetadataStringCodeUnits, code, path);
  if (typeof input === "boolean")
    return input;
  return invalid(code, path);
}
function captureRecord(input, schema, limits, admission = new Admission(limits.maxAdmissionEntries), path = "record") {
  const record = ownObject(input, "INVALID_RECORD", path, admission);
  keysOnly(record, ["id", "text", "metadata"], "INVALID_RECORD", path);
  const id = captureId(record.id, limits, "INVALID_RECORD", `${path}.id`);
  const textInput = ownObject(record.text, "INVALID_RECORD", `${path}.text`, admission);
  const metadataInput = has(record, "metadata") ? ownObject(record.metadata, "INVALID_RECORD", `${path}.metadata`, admission) : /* @__PURE__ */ Object.create(null);
  const text = /* @__PURE__ */ Object.create(null);
  const metadata2 = /* @__PURE__ */ Object.create(null);
  let textCodeUnits = 0;
  let metadataCodeUnits = 0;
  for (const name of Object.keys(textInput)) {
    if (!has(schema.text, name))
      invalid("INVALID_RECORD", `${path}.text`);
    const fieldPath = `${path}.text.${name}`;
    const raw = textInput[name];
    const values = typeof raw === "string" ? [raw] : ownArray(raw, limits.maxTextValuesPerField, "INVALID_RECORD", fieldPath, admission);
    text[name] = Object.freeze(values.map((value, i) => {
      const string = stringValue(value, limits.maxTextCodeUnitsPerValue, "INVALID_RECORD", `${fieldPath}[${i}]`);
      textCodeUnits += string.length;
      bound(textCodeUnits, limits.maxTextCodeUnitsPerRecord, `${path}.text`);
      return string;
    }));
  }
  for (const name of Object.keys(metadataInput)) {
    const field = schema.metadata[name];
    if (!field)
      invalid("INVALID_RECORD", `${path}.metadata`);
    const fieldPath = `${path}.metadata.${name}`;
    const value = metadataInput[name];
    const values = field.multi ? ownArray(value, limits.maxMetadataValuesPerField, "INVALID_RECORD", fieldPath, admission) : [value];
    const owned = values.map((item, i) => {
      const scalar = captureScalar(item, field, limits, "INVALID_RECORD", `${fieldPath}[${i}]`);
      if (typeof scalar === "string")
        metadataCodeUnits += scalar.length;
      bound(metadataCodeUnits, limits.maxMetadataCodeUnitsPerRecord, `${path}.metadata`);
      return scalar;
    });
    metadata2[name] = field.multi ? Object.freeze(owned) : owned[0];
  }
  return Object.freeze({ id, text: Object.freeze(text), metadata: Object.freeze(metadata2), textCodeUnits });
}
function captureBatch(input, schema, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const values = ownArray(input, limits.maxMutationBatch, "INVALID_RECORD", "records", admission);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const record = captureRecord(value, schema, limits, admission, `records[${i}]`);
    if (ids.has(record.id))
      invalid("INVALID_RECORD", `records[${i}].id`);
    ids.add(record.id);
    return record;
  }));
}
function captureRemoveIds(input, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const values = typeof input === "string" ? [input] : ownArray(input, limits.maxMutationBatch, "INVALID_OPTIONS", "ids", admission);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const id = captureId(value, limits, "INVALID_OPTIONS", `ids[${i}]`);
    if (ids.has(id))
      invalid("INVALID_OPTIONS", `ids[${i}]`);
    ids.add(id);
    return id;
  }));
}
function* analyzeRecord(record, limits, counts) {
  if (counts)
    counts.records++;
  yield* scanUnicode(record.id, "INVALID_RECORD", "record.id");
  for (const [field, value] of Object.entries(record.metadata)) {
    for (const item of Array.isArray(value) ? value : [value]) {
      if (typeof item === "string")
        yield* scanUnicode(item, "INVALID_RECORD", `record.metadata.${field}`);
    }
  }
  let tokens = 0;
  for (const [field, values] of Object.entries(record.text)) {
    for (let i = 0; i < values.length; i++) {
      if (counts) {
        counts.values++;
        counts.textCodeUnits += values[i].length;
      }
      for (const step of analyzeValue(values[i], i, limits)) {
        if (step.token) {
          bound(++tokens, limits.maxTokensPerRecord, "record.tokens");
          yield { ...step, field };
        } else
          yield step;
      }
    }
  }
}
function canonicalMetadata(record) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const [name, value] of Object.entries(record.metadata)) {
    result[name] = Array.isArray(value) ? Object.freeze([...new Set(value)]) : value;
  }
  return Object.freeze(result);
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/capabilities/capture.js
function captureExtension(capture, input, admission, limits, maximum) {
  const maxCodeUnits = Math.min(maximum, limits.maxQueryCodeUnits);
  const captured = capture(input, Object.freeze({ admission, limits, maxCodeUnits }));
  if (!captured || !Number.isSafeInteger(captured.codeUnits) || captured.codeUnits < 0 || captured.value !== null && typeof captured.value === "object" && !Object.isFrozen(captured.value))
    invalid("INCOMPATIBLE_CAPABILITY", "extensions.capture");
  bound(captured.codeUnits, maxCodeUnits, "extensions.payload");
  return captured;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/options.js
function integer(value, minimum, maximum, path) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
    invalid("INVALID_OPTIONS", path);
  bound(value, maximum, path);
  return value;
}
function captureOptions(input = {}, limits, search, admission = new Admission(limits.maxAdmissionEntries), capabilities) {
  const data = ownObject(input, "INVALID_OPTIONS", "options", admission);
  keysOnly(data, search ? ["signal", "deadlineMs", "limit", "offset", "extensions"] : ["signal", "deadlineMs"], "INVALID_OPTIONS", "options");
  const deadlineMs = has(data, "deadlineMs") ? integer(data.deadlineMs, 1, limits.maxDeadlineMs, "options.deadlineMs") : Math.min(3e4, limits.maxDeadlineMs);
  let signal;
  if (has(data, "signal")) {
    const candidate = data.signal;
    if (typeof candidate !== "object" || candidate === null || typeof candidate.aborted !== "boolean" || typeof candidate.addEventListener !== "function" || typeof candidate.removeEventListener !== "function")
      invalid("INVALID_OPTIONS", "options.signal");
    signal = candidate;
  }
  const base = { deadlineMs, ...signal ? { signal } : {} };
  if (!search)
    return Object.freeze(base);
  const offset = has(data, "offset") ? integer(data.offset, 0, limits.maxDocuments, "options.offset") : 0;
  const limit = has(data, "limit") ? integer(data.limit, 0, limits.maxHits, "options.limit") : Math.min(20, limits.maxHits, limits.maxDocuments - offset);
  bound(offset + limit, limits.maxDocuments, "options.page");
  let extensions;
  if (has(data, "extensions")) {
    const captured = ownObject(data.extensions, "INVALID_OPTIONS", "options.extensions", admission);
    let units = 0;
    for (const capability of Object.keys(captured)) {
      const registration = capabilities?.providers[capability];
      const handler = registration?.evidence ?? registration?.aggregation;
      if (!registration || !handler)
        invalid("MISSING_CAPABILITY", "options.extensions");
      const payload = captureExtension(handler.capture, captured[capability], admission, limits, registration.manifest.limits.maxPayloadCodeUnits);
      units += capability.length + payload.codeUnits;
      bound(units, limits.maxQueryCodeUnits, "options.extensions");
      captured[capability] = payload.value;
    }
    if (Object.keys(captured).length)
      extensions = Object.freeze(captured);
  }
  return Object.freeze({ ...base, offset, limit, ...extensions ? { extensions } : {} });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/mutations/capture.js
function captureMutation(configuration, kind, input, options) {
  const { schema, limits } = configuration, admission = new Admission(limits.maxAdmissionEntries);
  const capturedOptions = captureOptions(options, limits, false, admission);
  if (capturedOptions.signal?.aborted)
    invalid("CANCELLED", "options.signal");
  let records = [], ids = [];
  switch (kind) {
    case "add":
    case "replace":
      records = Object.freeze([captureRecord(input, schema, limits, admission)]);
      break;
    case "addMany":
      records = captureBatch(input, schema, limits, admission);
      break;
    case "remove":
      ids = captureRemoveIds(input, limits, admission);
      break;
    case "clear":
      if (input !== void 0)
        invalid("INVALID_OPTIONS", "clear");
      break;
    default:
      invalid("INVALID_OPTIONS", "mutation.kind");
  }
  return Object.freeze({ kind, records: Object.freeze(records), ids: Object.freeze(ids), options: capturedOptions });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/mutations/delta.js
function nonnegative(value, path) {
  if (!Number.isSafeInteger(value) || value < 0)
    invalid("INTERNAL_ERROR", path);
}
var CoreDelta = class {
  old;
  charge;
  diagnostics;
  documents;
  fields = /* @__PURE__ */ new Map();
  counts;
  constructor(old, charge, diagnostics) {
    this.old = old;
    this.charge = charge;
    this.diagnostics = diagnostics;
    validateStateCounts(old.counts, old.configuration.limits);
    if (old.documents.size !== old.counts.documents)
      invalid("INTERNAL_ERROR", "state.documents");
    this.counts = { ...old.counts };
    this.documents = new DirectoryStage(old.documents, charge, diagnostics?.documents);
  }
  field(name) {
    let field = this.fields.get(name);
    if (!field) {
      const original = this.old.fields[name];
      if (!original)
        invalid("INTERNAL_ERROR", "reverse.field");
      nonnegative(original.documents, "field.documents");
      nonnegative(original.length, "field.length");
      if (original.documents > this.old.documents.size || original.length < original.documents)
        invalid("INTERNAL_ERROR", "field.statistics");
      field = { documents: original.documents, length: original.length, terms: new DirectoryStage(original.terms, this.charge, this.diagnostics?.dictionary), cache: /* @__PURE__ */ new Map() };
      this.fields.set(name, field);
    }
    return field;
  }
  term(field, term) {
    let staged = field.cache.get(term);
    if (!staged) {
      const original = field.terms.get(term);
      if (original) {
        nonnegative(original.df, "term.df");
        nonnegative(original.frequency, "term.frequency");
        if (!original.df || original.df !== original.postings.size || original.frequency < original.df)
          invalid("INTERNAL_ERROR", "term.statistics");
      }
      staged = { ...original ? { original } : {}, df: original?.df ?? 0, frequency: original?.frequency ?? 0, postings: new DirectoryStage(original?.postings ?? emptyDirectory(), this.charge, this.diagnostics?.postings) };
      field.cache.set(term, staged);
    }
    return staged;
  }
  *contribute(document, sign) {
    nonnegative(document.textCodeUnits, "reverse.textCodeUnits");
    this.counts.textCodeUnits += sign * document.textCodeUnits;
    for (const [name, reverse] of Object.entries(document.fields)) {
      yield this.charge(name.length + 2);
      const field = this.field(name);
      nonnegative(reverse.length, "reverse.length");
      if (!reverse.length)
        invalid("INTERNAL_ERROR", "reverse.length");
      field.documents += sign;
      field.length += sign * reverse.length;
      this.counts.tokens += sign * reverse.length;
      if (this.diagnostics)
        this.diagnostics.fieldUpdates++;
      let length = 0;
      for (const [key, tf] of Object.entries(reverse.terms)) {
        yield this.charge(key.length + document.id.length + 4);
        nonnegative(tf, "reverse.tf");
        if (!tf)
          invalid("INTERNAL_ERROR", "reverse.tf");
        length += tf;
        const term = this.term(field, key), current = term.postings.get(document.id);
        if (sign < 0) {
          if (current !== tf)
            invalid("INTERNAL_ERROR", "reverse.posting");
          yield* term.postings.delete(document.id);
        } else {
          if (current !== void 0)
            invalid("INTERNAL_ERROR", "posting.duplicate");
          yield* term.postings.set(document.id, tf);
        }
        term.df += sign;
        term.frequency += sign * tf;
        this.counts.postingEntries += sign;
        if (this.diagnostics)
          this.diagnostics.termUpdates++;
      }
      if (length !== reverse.length)
        invalid("INTERNAL_ERROR", "reverse.length");
    }
  }
  *apply(delta) {
    if (delta.previous) {
      yield* this.contribute(delta.previous, -1);
      yield* this.documents.delete(delta.previous.id);
      this.counts.documents--;
    }
    if (delta.next) {
      yield* this.contribute(delta.next, 1);
      yield* this.documents.set(delta.next.id, delta.next);
      this.counts.documents++;
    }
  }
  *finish() {
    const fields = /* @__PURE__ */ Object.create(null);
    for (const name of Object.keys(this.old.fields)) {
      yield this.charge(1);
      const field = this.fields.get(name);
      if (!field) {
        fields[name] = this.old.fields[name];
        continue;
      }
      for (const [key, term] of field.cache) {
        yield this.charge(key.length + 3);
        nonnegative(term.df, "term.df");
        nonnegative(term.frequency, "term.frequency");
        if (term.df !== term.postings.size || term.df > field.documents || term.frequency < term.df || term.frequency > field.length || !term.df && term.frequency !== 0)
          invalid("INTERNAL_ERROR", "term.statistics");
        if (!term.df) {
          if (term.original) {
            yield* field.terms.delete(key);
            this.counts.dictionaryEntries--;
          }
        } else {
          const postings = yield* term.postings.finish();
          yield* field.terms.set(key, Object.freeze({ df: term.df, frequency: term.frequency, postings }));
          if (!term.original)
            this.counts.dictionaryEntries++;
        }
      }
      nonnegative(field.documents, "field.documents");
      nonnegative(field.length, "field.length");
      if (field.documents > this.counts.documents || field.length < field.documents || !field.documents && field.length !== 0)
        invalid("INTERNAL_ERROR", "field.statistics");
      const terms = yield* field.terms.finish();
      if (field.documents === 0 !== (terms.size === 0))
        invalid("INTERNAL_ERROR", "field.terms");
      fields[name] = Object.freeze({ documents: field.documents, length: field.length, terms });
    }
    const documents = yield* this.documents.finish();
    yield this.charge(5);
    validateStateCounts(this.counts, this.old.configuration.limits);
    if (documents.size !== this.counts.documents)
      invalid("INTERNAL_ERROR", "state.documents");
    return { documents, fields: Object.freeze(fields), counts: Object.freeze(this.counts) };
  }
};
function* clearedCore(old, charge) {
  const fields = /* @__PURE__ */ Object.create(null);
  for (const name of Object.keys(old.fields)) {
    yield charge(1);
    fields[name] = Object.freeze({ documents: 0, length: 0, terms: emptyDirectory() });
  }
  yield charge(5);
  return { documents: emptyDirectory(), fields: Object.freeze(fields), counts: Object.freeze({ documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 }) };
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/mutations/document.js
function* prepareDocument(record, limits, charge, counts) {
  for (const values of Object.values(record.text)) {
    yield charge(1);
    for (let i = 0; i < values.length; i++)
      yield charge(1);
  }
  const fields = /* @__PURE__ */ Object.create(null);
  for (const step of analyzeRecord(record, limits, counts)) {
    yield charge(step.workUnits);
    if (step.token) {
      yield charge(step.token.term.length + 2);
      const field = fields[step.field] ??= { length: 0, terms: /* @__PURE__ */ Object.create(null) };
      field.length++;
      field.terms[step.token.term] = (field.terms[step.token.term] ?? 0) + 1;
    }
  }
  const frozen = /* @__PURE__ */ Object.create(null);
  for (const [name, field] of Object.entries(fields)) {
    for (const term of Object.keys(field.terms))
      yield charge(term.length + 1);
    yield charge(1);
    frozen[name] = Object.freeze({ length: field.length, terms: Object.freeze(field.terms) });
  }
  for (const value of Object.values(record.metadata)) {
    yield charge(1);
    for (const item of Array.isArray(value) ? value : [value])
      yield charge(typeof item === "string" ? item.length + 1 : 1);
  }
  const metadata2 = canonicalMetadata(record);
  for (const value of Object.values(metadata2))
    yield charge(Array.isArray(value) ? value.length + 1 : 1);
  return Object.freeze({ id: record.id, textCodeUnits: record.textCodeUnits, metadata: metadata2, fields: Object.freeze(frozen) });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/mutations/owner.js
var MutationOwner = class {
  #root;
  #active = false;
  participants;
  admitted = /* @__PURE__ */ new WeakSet();
  constructor(root, participants = []) {
    if (!Number.isSafeInteger(root.revision) || root.revision < 0 || !Object.isFrozen(root))
      invalid("INTERNAL_ERROR", "revision.root");
    const ids = /* @__PURE__ */ new Set();
    for (const participant of participants) {
      if (!participant.id || ids.has(participant.id) || typeof participant.prepare !== "function" || !Object.hasOwn(root.participants, participant.id))
        invalid("INCOMPATIBLE_CAPABILITY", "participants");
      ids.add(participant.id);
    }
    if (Object.keys(root.participants).length !== ids.size)
      invalid("INCOMPATIBLE_CAPABILITY", "participants");
    this.#root = root;
    this.participants = Object.freeze(participants.map((p) => {
      if (p.maxWorkUnits !== void 0 && (!Number.isSafeInteger(p.maxWorkUnits) || p.maxWorkUnits < 1))
        invalid("INCOMPATIBLE_CAPABILITY", "participants.limits");
      return Object.freeze({ id: p.id, prepare: p.prepare.bind(p), ...p.maxWorkUnits !== void 0 ? { maxWorkUnits: p.maxWorkUnits } : {} });
    }));
  }
  get root() {
    return this.#root;
  }
  /** Trusted optional adapter publication after complete bounded preparation.
   * It runs in ExecutionOwner's FIFO, with no callbacks at the commit point. */
  publishPrepared(root, previous) {
    if (this.#active || this.#root !== previous || root.configuration !== previous.configuration || !Object.isFrozen(root) || previous.revision === Number.MAX_SAFE_INTEGER || root.revision !== previous.revision + 1 || Object.keys(root.participants).length !== this.participants.length || this.participants.some((participant) => !Object.hasOwn(root.participants, participant.id)))
      invalid("INTERNAL_ERROR", "adapter.publication");
    this.#root = root;
  }
  capture(kind, input, options) {
    const request = captureMutation(this.#root.configuration, kind, input, options);
    this.admitted.add(request);
    return request;
  }
  mutate(kind, input, options) {
    return this.execute(this.capture(kind, input, options));
  }
  execute(request, control = {}) {
    if (!this.admitted.delete(request))
      invalid("INTERNAL_ERROR", "mutation.admission");
    return this.consume(request, control);
  }
  *consume(request, control) {
    if (this.#active)
      invalid("INTERNAL_ERROR", "mutation.active");
    this.#active = true;
    const old = this.#root, budget = new WorkBudget(old.configuration.limits.maxMutationWorkUnits);
    let phase = "start";
    const check2 = () => {
      control.checkpoint?.(phase);
      if (control.checkStop)
        control.checkStop(phase);
      else if (request.options.signal?.aborted)
        invalid("CANCELLED", "options.signal");
    };
    const charge = (workUnits) => {
      check2();
      budget.charge(workUnits);
      if (control.diagnostics)
        control.diagnostics.workUnits = budget.consumed;
      return { workUnits };
    };
    const boundary = (next) => {
      phase = next;
      check2();
    };
    try {
      check2();
      const changes = [];
      let added = 0, replaced = 0, removed = 0;
      boundary("validation");
      if (request.kind === "remove") {
        for (const id of request.ids) {
          for (const step of scanUnicode(id, "INVALID_OPTIONS", "ids"))
            yield charge(step.workUnits);
          yield charge(id.length + 1);
          const previous = directoryGet(old.documents, id);
          if (previous) {
            changes.push(Object.freeze({ previous }));
            removed++;
          }
        }
      } else if (request.kind === "clear") {
        removed = old.documents.size;
      } else {
        for (const record of request.records) {
          yield charge(record.id.length + 1);
          const previous = directoryGet(old.documents, record.id);
          if (request.kind === "replace") {
            if (!previous)
              invalid("ID_NOT_FOUND", "record.id");
          } else if (previous)
            invalid("ID_EXISTS", "record.id");
          boundary("analysis");
          const next = yield* prepareDocument(record, old.configuration.limits, charge, control.diagnostics?.analysis);
          changes.push(Object.freeze({ ...previous ? { previous } : {}, next }));
          if (previous)
            replaced++;
          else
            added++;
          boundary("validation");
        }
      }
      const changed = added + replaced + removed > 0;
      if (!changed) {
        const result2 = Object.freeze({ revision: old.revision, changed: false, added, replaced, removed });
        boundary("precommit");
        yield charge(1);
        check2();
        return result2;
      }
      if (old.revision === Number.MAX_SAFE_INTEGER)
        invalid("REVISION_EXHAUSTED", "revision");
      boundary("staging");
      let coreData;
      if (request.kind === "clear")
        coreData = yield* clearedCore(old, charge);
      else {
        const delta = new CoreDelta(old, charge, control.diagnostics?.copies);
        for (const change of changes)
          yield* delta.apply(change);
        boundary("core");
        coreData = yield* delta.finish();
      }
      const core = Object.freeze({ ...coreData, revision: old.revision + 1, configuration: old.configuration, participants: old.participants });
      const context = Object.freeze({ kind: request.kind, previous: old, core, changes: Object.freeze(changes), records: request.records });
      const participants = /* @__PURE__ */ Object.create(null);
      for (const participant of this.participants) {
        boundary("participant");
        yield charge(participant.id.length + 1);
        const participantBudget = participant.maxWorkUnits === void 0 ? void 0 : new WorkBudget(participant.maxWorkUnits);
        const iterator = participant.prepare(old.participants[participant.id], context);
        let finished = false;
        try {
          for (; ; ) {
            const step = iterator.next();
            if (step.done) {
              participants[participant.id] = step.value;
              finished = true;
              break;
            }
            const charged = charge(step.value.workUnits);
            participantBudget?.charge(step.value.workUnits);
            yield charged;
          }
        } finally {
          if (!finished) {
            try {
              iterator.return(void 0);
            } catch {
            }
          }
        }
      }
      boundary("prepared");
      const root = Object.freeze({ ...core, participants: Object.freeze(participants) });
      const result = Object.freeze({ revision: root.revision, changed: true, added, replaced, removed });
      boundary("precommit");
      yield charge(1);
      check2();
      this.#root = root;
      return result;
    } finally {
      this.#active = false;
    }
  }
};

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/query.js
function captureQuery(input, schema, limits, admission = new Admission(limits.maxAdmissionEntries), capabilities) {
  let nodes = 0;
  let lexicalUnits = 0;
  let stringUnits = 0;
  const ancestors = /* @__PURE__ */ new Set();
  function string(value, lexical, path) {
    const text = stringValue(value, limits.maxQueryCodeUnits, "INVALID_QUERY", path);
    stringUnits += text.length;
    bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
    if (lexical) {
      lexicalUnits += text.length;
      bound(lexicalUnits, limits.maxQueryLexicalCodeUnits, "query.lexical");
    }
    return text;
  }
  function fields(value, path) {
    const names = ownArray(value, limits.maxTextFields, "INVALID_QUERY", path, admission);
    if (!names.length)
      invalid("INVALID_QUERY", path);
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(names.map((name) => {
      const selected = string(name, false, path);
      if (!has(schema.text, selected) || seen.has(selected))
        invalid("INVALID_QUERY", path);
      seen.add(selected);
      return selected;
    }));
  }
  function node(value, depth, path) {
    bound(++nodes, limits.maxQueryNodes, "query.nodes");
    bound(depth, limits.maxQueryDepth, "query.depth");
    const data = ownObject(value, "INVALID_QUERY", path, admission);
    if (ancestors.has(value))
      invalid("INVALID_QUERY", path);
    ancestors.add(value);
    const kind = string(data.kind, false, `${path}.kind`);
    let result;
    switch (kind) {
      case "text": {
        keysOnly(data, ["kind", "text", "operator", "fields"], "INVALID_QUERY", path);
        const operator = has(data, "operator") ? string(data.operator, false, `${path}.operator`) : "and";
        if (operator !== "and" && operator !== "or")
          invalid("INVALID_QUERY", `${path}.operator`);
        result = {
          kind,
          text: string(data.text, true, `${path}.text`),
          operator,
          ...has(data, "fields") ? { fields: fields(data.fields, `${path}.fields`) } : {}
        };
        break;
      }
      case "group": {
        keysOnly(data, ["kind", "variants", "fields"], "INVALID_QUERY", path);
        const variants = ownArray(data.variants, limits.maxVariantsPerGroup, "INVALID_QUERY", `${path}.variants`, admission);
        if (!variants.length)
          invalid("INVALID_QUERY", `${path}.variants`);
        const owned = variants.map((variant, i) => {
          const variantPath = `${path}.variants[${i}]`;
          const item = ownObject(variant, "INVALID_QUERY", variantPath, admission);
          keysOnly(item, ["text", "match", "weight"], "INVALID_QUERY", variantPath);
          const match = string(item.match, false, `${variantPath}.match`);
          if (match !== "exact" && match !== "prefix")
            invalid("INVALID_QUERY", `${variantPath}.match`);
          const weight = has(item, "weight") ? item.weight : 1;
          if (typeof weight !== "number" || !Number.isFinite(weight) || weight <= 0 || weight > 1)
            invalid("INVALID_QUERY", `${variantPath}.weight`);
          return Object.freeze({ text: string(item.text, true, `${variantPath}.text`), match, weight });
        });
        result = { kind, variants: Object.freeze(owned), ...has(data, "fields") ? { fields: fields(data.fields, `${path}.fields`) } : {} };
        break;
      }
      case "and":
      case "or": {
        keysOnly(data, ["kind", "children"], "INVALID_QUERY", path);
        const children = ownArray(data.children, limits.maxQueryNodes, "INVALID_QUERY", `${path}.children`, admission);
        if (!children.length)
          invalid("INVALID_QUERY", `${path}.children`);
        result = { kind, children: Object.freeze(children.map((child, i) => node(child, depth + 1, `${path}.children[${i}]`))) };
        break;
      }
      case "not":
        keysOnly(data, ["kind", "child"], "INVALID_QUERY", path);
        result = { kind, child: node(data.child, depth + 1, `${path}.child`) };
        break;
      case "eq": {
        keysOnly(data, ["kind", "field", "value"], "INVALID_QUERY", path);
        const name = string(data.field, false, `${path}.field`);
        const field = schema.metadata[name];
        if (!field)
          invalid("INVALID_QUERY", `${path}.field`);
        const scalar = captureScalar(data.value, field, limits, "INVALID_QUERY", `${path}.value`);
        if (typeof scalar === "string")
          string(scalar, false, `${path}.value`);
        result = { kind, field: name, value: scalar };
        break;
      }
      case "all":
      case "none":
        keysOnly(data, ["kind"], "INVALID_QUERY", path);
        result = { kind };
        break;
      case "extension": {
        keysOnly(data, ["kind", "capability", "version", "payload"], "INVALID_QUERY", path);
        if (typeof data.capability !== "string" || !data.capability.length || !Number.isSafeInteger(data.version) || data.version < 1 || !has(data, "payload"))
          invalid("INVALID_QUERY", path);
        const capability = string(data.capability, false, `${path}.capability`);
        const registration = capabilities?.providers[capability];
        if (!registration?.refinement && !registration?.predicate)
          invalid("MISSING_CAPABILITY", path);
        if (data.version !== 1)
          invalid("INCOMPATIBLE_CAPABILITY", `${path}.version`);
        if (registration.predicate) {
          const captured = captureExtension(registration.predicate.capture, data.payload, admission, limits, registration.manifest.limits.maxPayloadCodeUnits);
          stringUnits += captured.codeUnits;
          bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
          result = { kind: "predicate", capability, payload: captured.value };
          break;
        }
        const payload = ownObject(data.payload, "INVALID_QUERY", `${path}.payload`, admission);
        keysOnly(payload, ["text", "fields"], "INVALID_QUERY", `${path}.payload`);
        const text = string(payload.text, true, `${path}.payload.text`);
        const selected = has(payload, "fields") ? fields(payload.fields, `${path}.payload.fields`) : void 0;
        bound(text.length + (selected?.reduce((sum, field) => sum + field.length, 0) ?? 0), registration.manifest.limits.maxPayloadCodeUnits, `${path}.payload`);
        result = { kind, capability, version: 1, payload: Object.freeze({ text, ...selected ? { fields: selected } : {} }) };
        break;
      }
      default:
        return invalid("INVALID_QUERY", path);
    }
    ancestors.delete(value);
    return Object.freeze(result);
  }
  if (typeof input === "string") {
    bound(1, limits.maxQueryNodes, "query.nodes");
    bound(1, limits.maxQueryDepth, "query.depth");
    return Object.freeze({ kind: "text", text: string(input, true, "query"), operator: "and" });
  }
  return node(input, 1, "query");
}
function* analyzeQuery(query, schema, limits, capabilities) {
  let tokens = 0;
  const groups = /* @__PURE__ */ new Set();
  const queryLimits = { ...limits, maxTextCodeUnitsPerValue: limits.maxQueryLexicalCodeUnits };
  function groupKey(fields, variants) {
    const names = [...fields ?? Object.keys(schema.text)].sort();
    const alternatives = [...new Set(variants.map((variant) => JSON.stringify(variant)))].sort();
    return JSON.stringify([names, alternatives]);
  }
  function addGroup(key) {
    groups.add(key);
    bound(groups.size, limits.maxQueryGroups, "query.groups");
  }
  function* walk(leaf) {
    switch (leaf.kind) {
      case "text":
        for (const step of analyzeValue(leaf.text, 0, queryLimits, "INVALID_QUERY")) {
          if (step.token) {
            bound(++tokens, limits.maxQueryTokens, "query.tokens");
            addGroup(groupKey(leaf.fields, [[step.token.term, "exact", 1]]));
          }
          yield { ...step, leaf };
        }
        break;
      case "extension": {
        const registration = capabilities?.providers[leaf.capability];
        if (!registration?.refinement)
          invalid("MISSING_CAPABILITY", "query.capability");
        let count3 = 0;
        for (const step of analyzeValue(leaf.payload.text, 0, queryLimits, "INVALID_QUERY")) {
          if (step.token) {
            bound(++count3, registration.refinement.maxTokens, "query.phraseTokens");
            bound(++tokens, limits.maxQueryTokens, "query.tokens");
            addGroup(groupKey(leaf.payload.fields, [[step.token.term, "exact", 1]]));
          }
          yield { ...step, leaf };
        }
        break;
      }
      case "group": {
        const variants = [];
        for (let i = 0; i < leaf.variants.length; i++) {
          const variant = leaf.variants[i];
          let count3 = 0;
          for (const step of analyzeValue(variant.text, 0, queryLimits, "INVALID_QUERY")) {
            if (step.token) {
              bound(++tokens, limits.maxQueryTokens, "query.tokens");
              if (++count3 > 1)
                invalid("INVALID_QUERY", "query.variants");
              if (variant.match === "prefix" && [...step.token.term].length < limits.minPrefixCodePoints)
                invalid("INVALID_QUERY", "query.prefix");
              variants.push([step.token.term, variant.match, variant.weight ?? 1]);
            }
            yield { ...step, leaf, variantIndex: i };
          }
          if (count3 !== 1)
            invalid("INVALID_QUERY", "query.variants");
        }
        addGroup(groupKey(leaf.fields, variants));
        break;
      }
      case "and":
      case "or":
        for (const child of leaf.children)
          yield* walk(child);
        break;
      case "not":
        yield* walk(leaf.child);
        break;
      case "eq":
        if (typeof leaf.value === "string")
          yield* scanUnicode(leaf.value, "INVALID_QUERY", "query.value");
        break;
      case "predicate":
      case "all":
      case "none":
        break;
    }
  }
  yield* walk(query);
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/ranking/bm25.js
var positiveInteger = (value) => Number.isSafeInteger(value) && value > 0;
function* scoreDocument(root, doc, participating, expansions, charge, facts) {
  let score = 0;
  for (const key of yield* sortedStrings(participating, charge)) {
    const expanded = expansions.get(key);
    let groupScore = 0;
    for (const field of expanded.group.fields) {
      let best = 0;
      let found = false;
      let selected;
      for (const alternative of expanded.fields.get(field)) {
        yield charge(doc.id.length + field.length + alternative.term.length + 3);
        const tf = directoryGet(alternative.entry.postings, doc.id);
        if (tf === void 0)
          continue;
        yield charge(1);
        const statistics = root.fields[field];
        const length = doc.fields[field]?.length ?? 0;
        const N = statistics.documents;
        const totalLength = statistics.length;
        const df = alternative.entry.df;
        const boost = root.configuration.schema.text[field].boost;
        if (!positiveInteger(tf) || !positiveInteger(df) || !positiveInteger(N) || !positiveInteger(totalLength) || !positiveInteger(length) || tf > length || df > N || N > root.documents.size || totalLength < N || length > totalLength || !Number.isFinite(boost) || boost <= 0 || boost > 16)
          invalid("INTERNAL_ERROR", "ranking.statistics");
        const avgLength = totalLength / N;
        const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
        const normalizer = 1.2 * (1 - 0.75 + 0.75 * length / avgLength);
        const tfPart = tf * (1.2 + 1) / (tf + normalizer);
        const base = boost * idf * tfPart;
        const weighted = alternative.weight * base;
        if (!Number.isFinite(weighted) || weighted < 0)
          invalid("INTERNAL_ERROR", "ranking.score");
        if (!found || weighted > best) {
          found = true;
          best = weighted;
          if (facts)
            selected = { kind: "field", id: doc.id, group: key, field, term: alternative.term, variant: alternative.variantKey, weight: alternative.weight, boost, tf, df, N, length, totalLength, avgLength, k1: 1.2, b: 0.75, idf, normalizer, tfPart, base, selected: weighted };
        }
      }
      groupScore += best;
      if (facts && selected) {
        yield charge(1);
        facts.record(selected);
      }
    }
    score += groupScore;
    if (facts) {
      yield charge(1);
      facts.record({ kind: "group", id: doc.id, group: key, score: groupScore });
    }
  }
  if (!Number.isFinite(score) || score < 0)
    invalid("INTERNAL_ERROR", "ranking.score");
  return score;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/ranking/page.js
var PageSelection = class {
  capacity;
  charge;
  heap = [];
  constructor(capacity, charge) {
    this.capacity = capacity;
    this.charge = charge;
  }
  *compare(a, b) {
    yield this.charge(1);
    return a.score === b.score ? yield* compareStrings(a.id, b.id, this.charge) : b.score - a.score;
  }
  *add(hit) {
    if (!this.capacity)
      return;
    if (this.heap.length === this.capacity) {
      if ((yield* this.compare(hit, this.heap[0])) >= 0)
        return;
      this.heap[0] = hit;
      yield* this.down();
    } else {
      let i = this.heap.length;
      this.heap.push(hit);
      yield this.charge(1);
      while (i > 0) {
        const parent = Math.floor((i - 1) / 2);
        if ((yield* this.compare(this.heap[i], this.heap[parent])) <= 0)
          break;
        yield this.charge(1);
        [this.heap[parent], this.heap[i]] = [this.heap[i], this.heap[parent]];
        i = parent;
      }
    }
  }
  *down() {
    let i = 0;
    while (i * 2 + 1 < this.heap.length) {
      let child = i * 2 + 1;
      if (child + 1 < this.heap.length && (yield* this.compare(this.heap[child + 1], this.heap[child])) > 0)
        child++;
      if ((yield* this.compare(this.heap[i], this.heap[child])) >= 0)
        break;
      yield this.charge(1);
      [this.heap[i], this.heap[child]] = [this.heap[child], this.heap[i]];
      i = child;
    }
  }
  *finish(offset, limit) {
    const reversed = [];
    while (this.heap.length) {
      const rank = this.heap.length - 1;
      const hit = this.heap[0];
      const last = this.heap.pop();
      yield this.charge(1);
      if (this.heap.length) {
        this.heap[0] = last;
        yield* this.down();
      }
      if (rank >= offset && rank < offset + limit) {
        yield this.charge(1);
        reversed.push(Object.freeze(hit));
      }
    }
    return Object.freeze(reversed.reverse());
  }
};

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/retrieval/expand.js
function* expandGroups(root, groups, charge, checkpoint) {
  const queryPairs = /* @__PURE__ */ new Set();
  const result = /* @__PURE__ */ new Map();
  for (const key of yield* sortedStrings(groups.keys(), charge)) {
    const group = groups.get(key);
    let perGroup = 0;
    const fields = /* @__PURE__ */ new Map();
    const ids = /* @__PURE__ */ new Set();
    for (const name of group.fields) {
      const field = root.fields[name];
      if (!field)
        invalid("INTERNAL_ERROR", "index.fields");
      const terms = /* @__PURE__ */ new Map();
      function* add(term, entry, weight, variantKey) {
        yield charge(term.length + 1);
        const old = terms.get(term);
        if (!old) {
          yield charge(name.length + term.length + 1);
          queryPairs.add(JSON.stringify([name, term]));
          validateExpansionCounts(++perGroup, queryPairs.size, root.configuration.limits);
        }
        if (!old || weight > old.weight || weight === old.weight && (yield* compareStrings(variantKey, old.variantKey, charge)) < 0) {
          terms.set(term, Object.freeze({ term, entry, weight, variantKey }));
        }
      }
      for (const variant of group.variants) {
        if (variant.match === "exact") {
          checkpoint?.("dictionary");
          yield charge(variant.term.length + 1);
          const entry = directoryGet(field.terms, variant.term);
          if (entry)
            yield* add(variant.term, entry, variant.weight, variant.key);
        } else {
          for (const [term, entry] of directoryEntries(field.terms)) {
            checkpoint?.("dictionary");
            yield charge(1);
            let matches = term.length >= variant.term.length;
            for (let i = 0; matches && i < variant.term.length; i++) {
              yield charge(1);
              matches = term.charCodeAt(i) === variant.term.charCodeAt(i);
            }
            if (matches)
              yield* add(term, entry, variant.weight, variant.key);
          }
        }
      }
      const alternatives = [];
      for (const term of yield* sortedStrings(terms.keys(), charge)) {
        const expansion = terms.get(term);
        const entry = expansion.entry;
        if (!Number.isSafeInteger(entry.df) || entry.df < 1 || entry.df > field.documents || entry.df !== entry.postings.size)
          invalid("INTERNAL_ERROR", "index.df");
        alternatives.push(expansion);
        for (const [id, tf] of directoryEntries(entry.postings)) {
          checkpoint?.("postings");
          yield charge(id.length + name.length + term.length + 3);
          const doc = directoryGet(root.documents, id);
          if (!doc || !Number.isSafeInteger(tf) || tf <= 0 || doc.fields[name]?.terms[term] !== tf)
            invalid("INTERNAL_ERROR", "index.postings");
          yield charge(id.length + 1);
          ids.add(id);
        }
      }
      fields.set(name, Object.freeze(alternatives));
    }
    result.set(key, { group, fields, ids });
  }
  return result;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/trace/facts.js
function captureTrace(input, limits, admission) {
  const data = ownObject(input, "INVALID_OPTIONS", "trace", admission);
  keysOnly(data, ["ids", "maxFacts", "expectedRevision"], "INVALID_OPTIONS", "trace");
  const ids = ownArray(data.ids, limits.maxDocuments, "INVALID_OPTIONS", "trace.ids", admission).map((id) => {
    const value = stringValue(id, limits.maxIdCodeUnits, "INVALID_OPTIONS", "trace.ids");
    if (!value.length)
      invalid("INVALID_OPTIONS", "trace.ids");
    return value;
  });
  if (new Set(ids).size !== ids.length)
    invalid("INVALID_OPTIONS", "trace.ids");
  const maxFacts = has(data, "maxFacts") ? data.maxFacts : 4096;
  if (typeof maxFacts !== "number" || !Number.isSafeInteger(maxFacts) || maxFacts < 1)
    invalid("INVALID_OPTIONS", "trace.maxFacts");
  bound(maxFacts, 4096, "trace.maxFacts");
  const revision = data.expectedRevision;
  if (has(data, "expectedRevision") && (typeof revision !== "number" || !Number.isSafeInteger(revision) || revision < 0))
    invalid("INVALID_OPTIONS", "trace.expectedRevision");
  return Object.freeze({ ids: Object.freeze(ids), maxFacts, ...typeof revision === "number" ? { expectedRevision: revision } : {} });
}
var FactCollector = class {
  maximum;
  facts = [];
  constructor(maximum) {
    this.maximum = maximum;
    bound(1, maximum, "trace.facts");
  }
  record(fact) {
    bound(this.facts.length + 2, this.maximum, "trace.facts");
    this.facts.push(Object.freeze(fact));
  }
  finish(revision, analyzer, query) {
    return Object.freeze({ revision, model: "raveldex-bm25-v1", analyzer, query, tieBreaker: "utf16-id-ascending", facts: Object.freeze(this.facts) });
  }
};

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/query/compile.js
function* compileQuery(query, configuration, charge) {
  const tokens = /* @__PURE__ */ new Map();
  for (const step of analyzeQuery(query, configuration.schema, configuration.limits, configuration.capabilities)) {
    yield charge(step.workUnits);
    if (step.token && step.leaf) {
      yield charge(1);
      let list = tokens.get(step.leaf);
      if (!list) {
        list = [];
        tokens.set(step.leaf, list);
      }
      list.push(step.token.term);
    }
  }
  const groups = /* @__PURE__ */ new Map();
  function* group(fields, variants) {
    const names = yield* sortedStrings(fields ?? Object.keys(configuration.schema.text), charge);
    const entries = /* @__PURE__ */ new Map();
    for (const variant of variants) {
      yield charge(variant.term.length + 1);
      const key3 = JSON.stringify([variant.term, variant.match, variant.weight]);
      yield charge(key3.length + 1);
      entries.set(key3, Object.freeze({ ...variant, key: key3 }));
    }
    const keys = yield* sortedStrings(entries.keys(), charge);
    yield charge(names.reduce((n, field) => n + field.length, 1) + keys.reduce((n, key3) => n + key3.length, 1));
    const key2 = JSON.stringify([names, keys]);
    yield charge(key2.length + 1);
    let canonical2 = groups.get(key2);
    if (!canonical2) {
      canonical2 = Object.freeze({ key: key2, fields: Object.freeze(names), variants: Object.freeze(keys.map((entry) => entries.get(entry))) });
      groups.set(key2, canonical2);
    }
    return Object.freeze({ kind: "group", group: canonical2 });
  }
  function* walk(raw) {
    yield charge(1);
    switch (raw.kind) {
      case "text": {
        const children = [];
        for (const term of tokens.get(raw) ?? [])
          children.push(yield* group(raw.fields, [{ term, match: "exact", weight: 1 }]));
        return children.length ? Object.freeze({ kind: raw.operator ?? "and", children: Object.freeze(children) }) : Object.freeze({ kind: "none" });
      }
      case "group":
        return yield* group(raw.fields, raw.variants.map((variant, i) => ({ term: tokens.get(raw)[i], match: variant.match, weight: variant.weight ?? 1 })));
      case "extension": {
        const lexical = [], terms = Object.freeze(tokens.get(raw) ?? []);
        for (const term of terms) {
          const node2 = yield* group(raw.payload.fields, [{ term, match: "exact", weight: 1 }]);
          if (node2.kind === "group")
            lexical.push(node2.group);
        }
        return Object.freeze({
          kind: "extension",
          capability: raw.capability,
          fields: Object.freeze(yield* sortedStrings(raw.payload.fields ?? Object.keys(configuration.schema.text), charge)),
          terms,
          groups: Object.freeze(lexical)
        });
      }
      case "and":
      case "or": {
        const children = [];
        for (const child of raw.children)
          children.push(yield* walk(child));
        return Object.freeze({ kind: raw.kind, children: Object.freeze(children) });
      }
      case "not":
        return Object.freeze({ kind: "not", child: yield* walk(raw.child) });
      case "predicate":
        return Object.freeze({ kind: "predicate", capability: raw.capability, payload: raw.payload });
      case "eq":
        return Object.freeze({ kind: "eq", field: raw.field, value: raw.value });
      case "all":
      case "none":
        return Object.freeze({ kind: raw.kind });
    }
  }
  const node = yield* walk(query);
  const key = JSON.stringify(node);
  yield charge(key.length + 1);
  return { node, groups, key };
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/query/evaluate.js
function* evaluate(node, doc, expansions, charge, facts, path = "query", refinements) {
  yield charge(1);
  let matched = false;
  let groups = /* @__PURE__ */ new Set();
  switch (node.kind) {
    case "group":
      yield charge(doc.id.length + node.group.key.length + 1);
      matched = expansions.get(node.group.key).ids.has(doc.id);
      if (matched) {
        yield charge(node.group.key.length + 1);
        groups.add(node.group.key);
      }
      break;
    case "extension": {
      matched = node.terms.length > 0;
      for (const group of node.groups) {
        yield charge(doc.id.length + group.key.length + 1);
        if (!expansions.get(group.key).ids.has(doc.id))
          matched = false;
      }
      if (matched) {
        const verifier = refinements?.get(node);
        if (!verifier)
          invalid("MISSING_CAPABILITY", "query.refinement");
        const cursor = verifier.test(doc.id, doc.metadata);
        try {
          for (; ; ) {
            const step = cursor.next();
            if (step.done) {
              matched = step.value;
              break;
            }
            yield step.value;
          }
        } finally {
          try {
            cursor.return(false);
          } catch {
          }
        }
      }
      if (matched)
        for (const group of node.groups) {
          yield charge(group.key.length + 1);
          groups.add(group.key);
        }
      break;
    }
    case "predicate": {
      const predicate = refinements?.get(node);
      if (!predicate)
        invalid("MISSING_CAPABILITY", "query.predicate");
      matched = yield* predicate.test(doc.id, doc.metadata);
      break;
    }
    case "all":
      matched = true;
      break;
    case "none":
      break;
    case "eq": {
      yield charge(node.field.length + 1);
      if (Object.hasOwn(doc.metadata, node.field)) {
        const value = doc.metadata[node.field];
        const values = Array.isArray(value) ? value : [value];
        for (const scalar of values) {
          yield charge(typeof scalar === "string" && typeof node.value === "string" ? Math.max(scalar.length, node.value.length) + 1 : 1);
          if (scalar === node.value) {
            matched = true;
            break;
          }
        }
      }
      break;
    }
    case "not":
      matched = !(yield* evaluate(node.child, doc, expansions, charge, facts, facts ? `${path}.child` : "", refinements)).matched;
      break;
    case "and":
    case "or": {
      matched = node.kind === "and";
      for (let i = 0; i < node.children.length; i++) {
        const child = yield* evaluate(node.children[i], doc, expansions, charge, facts, facts ? `${path}.children[${i}]` : "", refinements);
        matched = node.kind === "and" ? matched && child.matched : matched || child.matched;
        if (child.matched)
          for (const key of child.groups) {
            yield charge(key.length + 1);
            groups.add(key);
          }
      }
      if (!matched)
        groups = /* @__PURE__ */ new Set();
      break;
    }
  }
  if (facts) {
    const keys = Object.freeze(yield* sortedStrings(groups, charge));
    yield charge(1);
    facts.record({
      kind: "node",
      id: doc.id,
      path,
      node: node.kind,
      matched,
      groups: keys,
      ...node.kind === "predicate" || node.kind === "extension" ? { capability: node.capability } : {},
      ...node.kind === "eq" ? { field: node.field } : {}
    });
  }
  return { matched, groups };
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/capabilities/refinement.js
function* prepareRefinements(node, root, charge, options) {
  const leaves = /* @__PURE__ */ new Map();
  const aggregations = [], budgets = /* @__PURE__ */ new Map();
  let evidence;
  function setup(capability) {
    const set = root.configuration.capabilities, registration = set?.providers[capability];
    if (!registration)
      invalid("MISSING_CAPABILITY", "query.capability");
    let budget = budgets.get(registration.manifest.id);
    if (!budget) {
      budget = new WorkBudget(Math.min(registration.manifest.limits.maxWorkUnits, root.configuration.limits.maxSearchWorkUnits));
      budgets.set(registration.manifest.id, budget);
    }
    const shared = budget;
    return { registration, *run(cursor) {
      try {
        for (; ; ) {
          const step = cursor.next();
          if (step.done)
            return step.value;
          const charged = charge(step.value.workUnits);
          shared.charge(step.value.workUnits);
          yield charged;
        }
      } finally {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    } };
  }
  const metadataContext = (capability, payload) => Object.freeze({ revision: root.revision, schema: root.configuration.schema, limits: root.configuration.limits, capability, payload });
  function state(capability, consumer) {
    const registration = root.configuration.capabilities.providers[consumer];
    if (!registration.manifest.requires.some((ref) => ref.id === capability))
      invalid("MISSING_CAPABILITY", "query.provider");
    const provider = root.configuration.capabilities.providers[capability];
    if (!provider?.participant || !Object.hasOwn(root.participants, provider.manifest.id))
      invalid("MISSING_CAPABILITY", "query.provider");
    return root.participants[provider.manifest.id];
  }
  function output(capability, result) {
    if (!result || !Number.isSafeInteger(result.entries) || result.entries < 0 || result.value !== null && typeof result.value === "object" && !Object.isFrozen(result.value))
      invalid("INCOMPATIBLE_CAPABILITY", "extensions.output");
    bound(result.entries, Math.min(root.configuration.capabilities.providers[capability].manifest.limits.maxOutputEntries, root.configuration.limits.maxAdmissionEntries), "extensions.output");
    return result.value;
  }
  function* walk(node2) {
    if (node2.kind === "extension" || node2.kind === "predicate") {
      const { registration, run } = setup(node2.capability);
      let test;
      if (node2.kind === "extension") {
        if (!registration.refinement)
          invalid("MISSING_CAPABILITY", "query.refinement");
        const context = Object.freeze({
          revision: root.revision,
          analyzer: root.configuration.analyzer,
          limits: root.configuration.limits,
          fields: node2.fields,
          terms: node2.terms,
          state(capability) {
            return state(capability, node2.capability);
          }
        });
        const prepared = yield* run(registration.refinement.prepare(context));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement");
        test = prepared.test.bind(prepared);
      } else {
        if (!registration.predicate)
          invalid("MISSING_CAPABILITY", "query.predicate");
        const prepared = yield* run(registration.predicate.prepare(metadataContext(node2.capability, node2.payload)));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.predicate");
        const predicate = prepared.test.bind(prepared);
        test = (_id, metadata2) => predicate(metadata2);
      }
      leaves.set(node2, Object.freeze({ *test(id, metadata2) {
        const matched = yield* run(test(id, metadata2));
        if (typeof matched !== "boolean")
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement");
        return matched;
      } }));
    } else if (node2.kind === "and" || node2.kind === "or")
      for (const child of node2.children)
        yield* walk(child);
    else if (node2.kind === "not")
      yield* walk(node2.child);
  }
  yield* walk(node);
  for (const capability of Object.keys(options.extensions ?? {}).sort()) {
    yield charge(capability.length + 1);
    const { registration, run } = setup(capability);
    if (registration.evidence) {
      if (evidence)
        invalid("INVALID_OPTIONS", "options.extensions.evidence");
      const prepared2 = yield* run(registration.evidence.prepare(Object.freeze({
        ...metadataContext(capability, options.extensions[capability]),
        analyzer: root.configuration.analyzer,
        state: (requested) => state(requested, capability)
      })));
      if (!prepared2 || typeof prepared2.finish !== "function")
        invalid("INCOMPATIBLE_CAPABILITY", "extensions.evidence");
      const finish2 = prepared2.finish.bind(prepared2);
      evidence = Object.freeze({ capability, *finish(context) {
        return output(capability, yield* run(finish2(context)));
      } });
      continue;
    }
    if (!registration.aggregation)
      invalid("MISSING_CAPABILITY", "options.extensions");
    const prepared = yield* run(registration.aggregation.prepare(metadataContext(capability, options.extensions[capability])));
    if (!prepared || typeof prepared.add !== "function" || typeof prepared.finish !== "function")
      invalid("INCOMPATIBLE_CAPABILITY", "extensions.aggregation");
    const add = prepared.add.bind(prepared), finish = prepared.finish.bind(prepared);
    aggregations.push(Object.freeze({
      capability,
      *add(metadata2) {
        if ((yield* run(add(metadata2))) !== void 0)
          invalid("INCOMPATIBLE_CAPABILITY", "extensions.aggregation");
      },
      *finish() {
        return output(capability, yield* run(finish()));
      }
    }));
  }
  return { leaves, aggregations, ...evidence ? { evidence } : {} };
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/query/search.js
function captureSearch(configuration, input, options, trace) {
  const { schema, limits } = configuration;
  const admission = new Admission(limits.maxAdmissionEntries);
  const page = captureOptions(options, limits, true, admission, configuration.capabilities);
  if (page.signal?.aborted)
    invalid("CANCELLED", "options.signal");
  const query = captureQuery(input, schema, limits, admission, configuration.capabilities);
  let request = trace === void 0 ? void 0 : captureTrace(trace, limits, admission);
  let evidence;
  for (const capability of Object.keys(page.extensions ?? {})) {
    const handler = configuration.capabilities?.providers[capability]?.evidence;
    if (!handler)
      continue;
    if (request || evidence)
      invalid("INVALID_OPTIONS", "options.extensions.evidence");
    request = captureTrace(handler.select(page.extensions[capability]), limits, admission);
    evidence = capability;
  }
  return Object.freeze({ query, options: page, ...request ? { trace: request } : {}, ...evidence ? { evidence } : {} });
}
function* executeOwnedSearch(root, request, control = {}) {
  const { query, options, trace } = request;
  const budget = new WorkBudget(root.configuration.limits.maxSearchWorkUnits);
  let phase = "start";
  const check2 = () => {
    control.checkpoint?.(phase);
    if (control.checkStop)
      control.checkStop(phase);
    else if (options.signal?.aborted)
      invalid("CANCELLED", "options.signal");
  };
  const boundary = (next) => {
    phase = next;
    check2();
  };
  const charge = (workUnits) => {
    check2();
    budget.charge(workUnits);
    return { workUnits };
  };
  check2();
  if (trace?.expectedRevision !== void 0 && trace.expectedRevision !== root.revision)
    invalid("REVISION_MISMATCH", "trace.expectedRevision");
  const selected = /* @__PURE__ */ new Set();
  if (trace)
    for (const id of trace.ids) {
      for (const step of scanUnicode(id, "INVALID_OPTIONS", "trace.ids"))
        yield charge(step.workUnits);
      yield charge(id.length + 1);
      selected.add(id);
    }
  const collector = trace ? new FactCollector(trace.maxFacts) : void 0;
  boundary("analysis");
  const compiled = yield* compileQuery(query, root.configuration, charge);
  boundary("expansion");
  const expansions = yield* expandGroups(root, compiled.groups, charge, boundary);
  const extensions = root.configuration.capabilities ? yield* prepareRefinements(compiled.node, root, charge, options) : void 0;
  const page = new PageSelection(options.limit ? options.offset + options.limit : 0, charge);
  let total = 0;
  for (const [id, doc] of directoryEntries(root.documents)) {
    boundary("evaluation");
    yield charge(id.length + 1);
    if (doc.id !== id)
      invalid("INTERNAL_ERROR", "index.documents");
    const facts = selected.has(id) ? collector : void 0;
    const qualified = yield* evaluate(compiled.node, doc, expansions, charge, facts, "query", extensions?.leaves);
    boundary("scoring");
    const score = qualified.matched ? yield* scoreDocument(root, doc, qualified.groups, expansions, charge, facts) : 0;
    if (qualified.matched) {
      total++;
      if (extensions?.aggregations.length) {
        boundary("aggregation");
        for (const aggregation of extensions.aggregations)
          yield* aggregation.add(doc.metadata);
      }
      boundary("selection");
      yield* page.add({ id, score });
    }
    if (facts) {
      const groups = Object.freeze(yield* sortedStrings(qualified.groups, charge));
      yield charge(1);
      facts.record({ kind: "document", id, exists: true, matched: qualified.matched, groups, score });
    }
  }
  if (collector)
    for (const id of selected) {
      yield charge(id.length + 1);
      if (!directoryGet(root.documents, id))
        collector.record({ kind: "document", id, exists: false, matched: false, groups: Object.freeze([]), score: 0 });
    }
  boundary("selection");
  const hits = yield* page.finish(options.offset, options.limit);
  let additional;
  if (extensions?.aggregations.length) {
    boundary("aggregation");
    const result2 = /* @__PURE__ */ Object.create(null);
    for (const aggregation of extensions.aggregations)
      result2[aggregation.capability] = yield* aggregation.finish();
    additional = Object.freeze(result2);
  }
  const scoreTrace = collector?.finish(root.revision, root.configuration.analyzer, compiled.key);
  if (extensions?.evidence) {
    boundary("aggregation");
    if (!scoreTrace)
      invalid("INTERNAL_ERROR", "extensions.evidence");
    const publicResult = Object.freeze({ revision: root.revision, model: "raveldex-bm25-v1", completeness: "complete", total, hits, ...additional ? { extensions: additional } : {} });
    const value = yield* extensions.evidence.finish(Object.freeze({
      query: compiled.node,
      trace: scoreTrace,
      result: publicResult,
      counts: root.counts,
      searchWorkUnits: budget.consumed,
      maxSearchWorkUnits: root.configuration.limits.maxSearchWorkUnits,
      capabilities: Object.freeze(root.configuration.capabilities.ordered.map((registration) => registration.manifest))
    }));
    additional = Object.freeze({ ...additional, [extensions.evidence.capability]: value });
  }
  boundary("result");
  yield charge(1);
  const result = Object.freeze({
    revision: root.revision,
    model: "raveldex-bm25-v1",
    completeness: "complete",
    total,
    hits,
    ...scoreTrace && !request.evidence ? { trace: scoreTrace } : {},
    ...additional ? { extensions: additional } : {}
  });
  check2();
  return result;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/execution/host.js
function directHost() {
  const host = globalThis;
  if (typeof host.performance?.now !== "function" || typeof host.setTimeout !== "function" || typeof host.clearTimeout !== "function")
    invalid("INTERNAL_ERROR", "execution.host");
  const now = host.performance.now.bind(host.performance);
  const schedule = host.setTimeout.bind(host), cancel = host.clearTimeout.bind(host);
  return Object.freeze({ now, schedule(callback, delayMs) {
    const handle = schedule(callback, delayMs);
    return () => cancel(handle);
  } });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/execution/engine.js
function emptyRoot(configuration, states = Object.freeze(/* @__PURE__ */ Object.create(null))) {
  const fields = /* @__PURE__ */ Object.create(null);
  for (const name of Object.keys(configuration.schema.text))
    fields[name] = Object.freeze({ documents: 0, length: 0, terms: emptyDirectory() });
  return Object.freeze({
    configuration,
    revision: 0,
    documents: emptyDirectory(),
    fields: Object.freeze(fields),
    counts: Object.freeze({ documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 }),
    participants: states
  });
}
var ExecutionOwner = class {
  #owner;
  #configuration;
  #host;
  #metrics;
  #queue = [];
  #active;
  #closing = false;
  #pumping = false;
  #disposal;
  #disposed;
  constructor(root, host, participants = [], metrics) {
    this.#owner = new MutationOwner(root, participants);
    this.#configuration = root.configuration;
    this.#metrics = metrics;
    this.#host = Object.freeze({ now: host.now.bind(host), schedule: host.schedule.bind(host) });
  }
  get root() {
    return this.#owner?.root;
  }
  adapterOperation(capture, control) {
    return this.admit(() => {
      const request = capture(this.#configuration);
      return { options: request.options, start: (check2) => {
        const owner = this.#owner, previous = owner.root;
        return request.start(previous, check2, (root) => owner.publishPrepared(root, previous));
      } };
    }, control);
  }
  search(query, options) {
    return this.searchControlled(query, options);
  }
  searchControlled(query, options, control) {
    return this.admit(() => {
      const request = captureSearch(this.#configuration, query, options);
      return { options: request.options, start: (check2) => executeOwnedSearch(this.#owner.root, request, { checkStop: check2 }) };
    }, control);
  }
  add(record, options) {
    return this.mutate("add", record, options);
  }
  addMany(records, options) {
    return this.mutate("addMany", records, options);
  }
  replace(record, options) {
    return this.mutate("replace", record, options);
  }
  remove(ids, options) {
    return this.mutate("remove", ids, options);
  }
  clear(options) {
    return this.mutate("clear", void 0, options);
  }
  mutate(kind, input, options) {
    return this.mutateControlled(kind, input, options);
  }
  mutateControlled(kind, input, options, control) {
    return this.admit(() => {
      const request = this.#owner.capture(kind, input, options);
      return { options: request.options, start: (check2) => this.#owner.execute(request, { checkStop: check2 }) };
    }, control);
  }
  check(op, phase) {
    if (this.#metrics) {
      this.#metrics.checks++;
      if (phase)
        this.#metrics.phaseChecks[phase] = (this.#metrics.phaseChecks[phase] ?? 0) + 1;
    }
    if (this.#closing)
      invalid("DISPOSED", "execution");
    const aborted = op.options?.signal?.aborted;
    const expired = this.#host.now() >= op.deadline;
    if (this.#closing)
      invalid("DISPOSED", "execution");
    if (aborted || op.cancelled)
      invalid("CANCELLED", "options.signal");
    if (expired)
      invalid("DEADLINE_EXCEEDED", "options.deadlineMs");
  }
  admit(capture, control) {
    try {
      if (this.#closing)
        invalid("DISPOSED", "execution");
      const admittedAt = this.#host.now();
      const request = capture();
      if (control) {
        if (!Number.isFinite(control.elapsedMs) || control.elapsedMs < 0)
          invalid("INTERNAL_ERROR", "execution.control");
        request.options = Object.freeze({ ...request.options, signal: control.signal });
      }
      if (this.#closing)
        invalid("DISPOSED", "execution");
      if (request.options.signal?.aborted)
        invalid("CANCELLED", "options.signal");
      if (control && control.elapsedMs >= request.options.deadlineMs)
        invalid("DEADLINE_EXCEEDED", "options.deadlineMs");
      if (this.#active && this.#queue.length >= this.#configuration.limits.maxQueuedOperations)
        invalid("QUEUE_FULL", "execution.queue");
      let resolve, reject;
      const promise = new Promise((yes, no) => {
        resolve = yes;
        reject = no;
      });
      const op = {
        options: request.options,
        start: void 0,
        cursor: void 0,
        resolve,
        reject,
        deadline: admittedAt + request.options.deadlineMs - (control?.elapsedMs ?? 0),
        detach: void 0,
        timer: void 0,
        resume: void 0,
        settled: false,
        executing: false,
        cancelled: false
      };
      op.start = () => request.start((phase) => this.check(op, phase));
      if (this.#active)
        this.#queue.push(op);
      else
        this.#active = op;
      try {
        const signal = op.options.signal;
        if (signal) {
          const stop = () => {
            op.cancelled = true;
            this.stop(op);
          };
          op.detach = () => signal.removeEventListener("abort", stop);
          signal.addEventListener("abort", stop, { once: true });
          if (op.settled) {
            try {
              signal.removeEventListener("abort", stop);
            } catch {
            }
          }
        }
        if (!op.settled) {
          this.check(op);
          op.timer = this.#host.schedule(() => {
            op.timer = void 0;
            this.stop(op);
          }, Math.max(0, op.deadline - this.#host.now()));
        }
      } catch (error) {
        this.finish(op, void 0, this.error(error));
      }
      this.pump();
      return promise;
    } catch (error) {
      return Promise.reject(this.error(error));
    }
  }
  /** Event/timer stop while suspended closes staging immediately; running code checks cooperatively. */
  stop(op) {
    if (op.settled || op.executing)
      return;
    try {
      this.check(op);
      op.timer?.();
      op.timer = this.#host.schedule(() => {
        op.timer = void 0;
        this.stop(op);
      }, Math.max(0, op.deadline - this.#host.now()));
    } catch (error) {
      this.finish(op, void 0, this.error(error));
      this.pump();
    }
  }
  pump() {
    if (this.#pumping)
      return;
    this.#pumping = true;
    let consumed = 0;
    try {
      for (; ; ) {
        if (!this.#active)
          this.#active = this.#queue.shift();
        const op = this.#active;
        if (!op || op.resume)
          break;
        op.executing = true;
        try {
          this.check(op);
          op.cursor ??= op.start();
          op.start = void 0;
          for (; ; ) {
            this.check(op);
            const step = op.cursor.next();
            if (step.done) {
              this.finish(op, step.value);
              break;
            }
            consumed += step.value.workUnits;
            if (this.#metrics) {
              this.#metrics.workUnits += step.value.workUnits;
              this.#metrics.steps++;
              this.#metrics.maxStepWorkUnits = Math.max(this.#metrics.maxStepWorkUnits, step.value.workUnits);
              this.#metrics.maxTaskWorkUnits = Math.max(this.#metrics.maxTaskWorkUnits, consumed);
            }
            if (consumed >= this.#configuration.limits.checkpointWorkUnits) {
              this.check(op);
              op.resume = this.#host.schedule(() => {
                op.resume = void 0;
                this.pump();
              }, 0);
              if (this.#metrics)
                this.#metrics.hostYields++;
              break;
            }
          }
        } catch (error) {
          this.finish(op, void 0, this.error(error));
        } finally {
          op.executing = false;
        }
        if (this.#active === op)
          break;
      }
    } finally {
      this.#pumping = false;
      this.release();
    }
  }
  error(error) {
    return error instanceof RaveldexError ? error : new RaveldexError("INTERNAL_ERROR");
  }
  finish(op, result, failure) {
    if (op.settled)
      return;
    op.settled = true;
    const resolve = op.resolve, reject = op.reject;
    const cursor = op.cursor;
    op.options = void 0;
    op.start = void 0;
    op.cursor = void 0;
    op.resolve = void 0;
    op.reject = void 0;
    if (failure !== void 0) {
      try {
        cursor?.return(void 0);
      } catch {
      }
    }
    for (const cleanup of [op.resume, op.timer, op.detach]) {
      try {
        cleanup?.();
      } catch {
      }
    }
    op.resume = void 0;
    op.timer = void 0;
    op.detach = void 0;
    if (this.#active === op)
      this.#active = void 0;
    else
      this.#queue = this.#queue.filter((item) => item !== op);
    if (failure !== void 0)
      reject(this.error(failure));
    else
      resolve(result);
    this.release();
  }
  dispose() {
    if (this.#disposal)
      return this.#disposal;
    this.#closing = true;
    this.#disposal = new Promise((resolve) => {
      this.#disposed = resolve;
    });
    for (const op of [...this.#queue])
      this.finish(op, void 0, new RaveldexError("DISPOSED"));
    if (this.#active && !this.#active.executing)
      this.finish(this.#active, void 0, new RaveldexError("DISPOSED"));
    this.release();
    return this.#disposal;
  }
  release() {
    if (this.#closing && !this.#active && this.#queue.length === 0) {
      this.#owner = void 0;
      const resolve = this.#disposed;
      this.#disposed = void 0;
      resolve?.();
    }
  }
};
var executionOwners = /* @__PURE__ */ new WeakMap();
function getExecutionOwner(engine) {
  return executionOwners.get(engine);
}
function facadeFromExecutionOwner(owner) {
  const facade = Object.freeze({
    search: owner.search.bind(owner),
    add: owner.add.bind(owner),
    addMany: owner.addMany.bind(owner),
    replace: owner.replace.bind(owner),
    remove: owner.remove.bind(owner),
    clear: owner.clear.bind(owner),
    dispose: owner.dispose.bind(owner)
  });
  executionOwners.set(facade, owner);
  return facade;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/error.js
var SNAPSHOT_REASONS = Object.freeze([
  "MALFORMED_SNAPSHOT",
  "ENCODED_LIMIT_EXCEEDED",
  "INTEGRITY_MISMATCH",
  "UNSUPPORTED_FORMAT",
  "UNSUPPORTED_CODEC",
  "SCHEMA_MISMATCH",
  "ANALYZER_MISMATCH",
  "RANKING_MISMATCH",
  "CAPABILITY_MISMATCH",
  "INDEX_DETAIL_MISMATCH",
  "LIMITS_MISMATCH",
  "SOURCE_UNAVAILABLE",
  "UNQUALIFIED_PROFILE",
  "PROFILE_MISMATCH",
  "INVALID_NATIVE_STATE",
  "UNSUPPORTED_ENGINE"
]);
var SnapshotAdapterError = class extends RaveldexError {
  reason;
  constructor(reason, path = "snapshot") {
    super(reason === "ENCODED_LIMIT_EXCEEDED" ? "LIMIT_EXCEEDED" : reason === "SOURCE_UNAVAILABLE" || reason === "UNSUPPORTED_ENGINE" ? "MISSING_CAPABILITY" : "INCOMPATIBLE_CAPABILITY", { path });
    this.name = "SnapshotAdapterError";
    this.reason = reason;
  }
};
function fail(reason, path) {
  throw new SnapshotAdapterError(reason, path);
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/qualification.js
function currentNodeSnapshotEnvironment() {
  const process = globalThis.process;
  const versions = process?.versions;
  if (!versions || ["node", "v8", "icu", "unicode"].some((key) => typeof versions[key] !== "string") || typeof process?.platform !== "string" || typeof process?.arch !== "string")
    fail("UNQUALIFIED_PROFILE", "snapshot.environment");
  return Object.freeze({
    runtime: "node",
    version: versions.node,
    v8: versions.v8,
    icu: versions.icu,
    unicode: versions.unicode,
    platform: process.platform,
    arch: process.arch
  });
}
function captureQualification(input, matchCurrent = true) {
  const admission = new Admission(256), code = "INVALID_OPTIONS";
  const data = ownObject(input, code, "snapshot.qualification", admission);
  keysOnly(data, ["profileId", "scope", "environment", "evidence"], code, "snapshot.qualification");
  if (typeof data.profileId !== "string" || !/^[A-Za-z][A-Za-z0-9:._-]{0,127}$/.test(data.profileId) || data.profileId === "unqualified" || data.scope !== "exact-node-runtime")
    invalid(code, "snapshot.qualification");
  const environment = ownObject(data.environment, code, "snapshot.environment", admission);
  const keys = ["runtime", "version", "v8", "icu", "unicode", "platform", "arch"];
  keysOnly(environment, keys, code, "snapshot.environment");
  for (const key of keys) {
    if (!has(environment, key) || typeof environment[key] !== "string" || !environment[key].length || environment[key].length > 128)
      invalid(code, "snapshot.environment");
    for (const step of scanUnicode(environment[key], code, "snapshot.environment")) {
      void step;
    }
  }
  if (environment.runtime !== "node")
    invalid(code, "snapshot.environment");
  const ownedEnvironment = Object.freeze(environment);
  if (matchCurrent) {
    const current = currentNodeSnapshotEnvironment();
    for (const key of keys)
      if (ownedEnvironment[key] !== current[key])
        fail("PROFILE_MISMATCH", "snapshot.environment");
  }
  const evidence = ownArray(data.evidence, 32, code, "snapshot.evidence", admission).map((value) => {
    if (typeof value !== "string" || !value.trim().length || value.length > 256)
      invalid(code, "snapshot.evidence");
    for (const step of scanUnicode(value, code, "snapshot.evidence")) {
      void step;
    }
    return value;
  });
  if (!evidence.length || new Set(evidence).size !== evidence.length)
    invalid(code, "snapshot.evidence");
  return Object.freeze({ profileId: data.profileId, scope: "exact-node-runtime", environment: ownedEnvironment, evidence: Object.freeze(evidence) });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/json.js
var MAX_ENCODED_BYTES = 64 * 1024 * 1024;
var MAX_DEPTH = 64;
var MAX_NODES = 8e6;
var MAX_STRING = 262144;
var HEX = /^[0-9a-f]{8}$/;
function* utf8Bytes(text, maximum) {
  let bytes = 0, units = 0;
  for (let i = 0; i < text.length; i++) {
    const point = text.charCodeAt(i);
    if (point < 128)
      bytes++;
    else if (point < 2048)
      bytes += 2;
    else if (point >= 55296 && point <= 56319) {
      const next = text.charCodeAt(++i);
      if (!(next >= 56320 && next <= 57343))
        fail("MALFORMED_SNAPSHOT");
      bytes += 4;
    } else {
      if (point >= 56320 && point <= 57343)
        fail("MALFORMED_SNAPSHOT");
      bytes += 3;
    }
    if (bytes > maximum)
      fail("ENCODED_LIMIT_EXCEEDED");
    if (++units === 256) {
      yield { workUnits: units };
      units = 0;
    }
  }
  if (units)
    yield { workUnits: units };
  return bytes;
}
function* checksum(text) {
  let hash = 2166136261, units = 0;
  for (let i = 0; i < text.length; i++) {
    hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    if (++units === 256) {
      yield { workUnits: units };
      units = 0;
    }
  }
  if (units)
    yield { workUnits: units };
  return (hash >>> 0).toString(16).padStart(8, "0");
}
function* encodeJson(value, maximum) {
  const chunks = [], active = /* @__PURE__ */ new Set();
  let bytes = 0, nodes = 0;
  function* append(text) {
    bytes += yield* utf8Bytes(text, maximum - bytes);
    chunks.push(text);
  }
  function* visit(value2, depth) {
    yield { workUnits: 1 };
    if (++nodes > MAX_NODES || depth > MAX_DEPTH)
      fail("ENCODED_LIMIT_EXCEEDED");
    if (value2 === null || typeof value2 === "boolean") {
      yield* append(String(value2));
      return;
    }
    if (typeof value2 === "number") {
      if (!Number.isFinite(value2))
        fail("INVALID_NATIVE_STATE");
      yield* append(JSON.stringify(value2));
      return;
    }
    if (typeof value2 === "string") {
      if (value2.length > MAX_STRING)
        fail("ENCODED_LIMIT_EXCEEDED");
      for (const step of scanUnicode(value2, "INCOMPATIBLE_CAPABILITY", "snapshot.string"))
        yield step;
      yield* append(JSON.stringify(value2));
      return;
    }
    if (typeof value2 !== "object" || active.has(value2))
      fail("INVALID_NATIVE_STATE");
    active.add(value2);
    try {
      if (Array.isArray(value2)) {
        if (value2.length > MAX_NODES)
          fail("ENCODED_LIMIT_EXCEEDED");
        if (!Object.isFrozen(value2) || Reflect.ownKeys(value2).length !== value2.length + 1)
          fail("INVALID_NATIVE_STATE");
        yield* append("[");
        for (let i = 0; i < value2.length; i++) {
          const descriptor = Object.getOwnPropertyDescriptor(value2, String(i));
          if (!descriptor || !("value" in descriptor))
            fail("INVALID_NATIVE_STATE");
          if (i)
            yield* append(",");
          yield* visit(descriptor.value, depth + 1);
        }
        yield* append("]");
      } else {
        const prototype = Object.getPrototypeOf(value2);
        if (prototype !== null && prototype !== Object.prototype || !Object.isFrozen(value2))
          fail("INVALID_NATIVE_STATE");
        const keys = Object.keys(value2);
        if (Reflect.ownKeys(value2).length !== keys.length)
          fail("INVALID_NATIVE_STATE");
        for (const key of keys)
          yield { workUnits: key.length + Math.ceil(Math.log2(keys.length + 1)) + 1 };
        keys.sort();
        yield* append("{");
        for (let i = 0; i < keys.length; i++) {
          const key = keys[i], descriptor = Object.getOwnPropertyDescriptor(value2, key);
          if (!descriptor || !("value" in descriptor))
            fail("INVALID_NATIVE_STATE");
          if (i)
            yield* append(",");
          yield* visit(key, depth + 1);
          yield* append(":");
          yield* visit(descriptor.value, depth + 1);
        }
        yield* append("}");
      }
    } finally {
      active.delete(value2);
    }
  }
  yield* visit(value, 0);
  yield { workUnits: 1 };
  return chunks.join("");
}
function* decodeJson(text, maximum) {
  yield* utf8Bytes(text, maximum);
  let position = 0, nodes = 0, bodyStart = -1, bodyEnd = -1, uncharged = 0;
  function* step() {
    if (++uncharged >= 128) {
      yield { workUnits: uncharged };
      uncharged = 0;
    }
  }
  function* whitespace() {
    while (position < text.length && /[\x20\t\r\n]/.test(text[position])) {
      position++;
      yield* step();
    }
  }
  function* string() {
    if (text[position++] !== '"')
      fail("MALFORMED_SNAPSHOT");
    let value2 = "", pieces = [];
    for (; ; ) {
      if (position >= text.length)
        fail("MALFORMED_SNAPSHOT");
      const character = text[position++];
      yield* step();
      if (character === '"')
        break;
      if (character.charCodeAt(0) < 32)
        fail("MALFORMED_SNAPSHOT");
      if (character === "\\") {
        const escaped = text[position++];
        yield* step();
        const simple = { '"': '"', "\\": "\\", "/": "/", b: "\b", f: "\f", n: "\n", r: "\r", t: "	" };
        if (Object.hasOwn(simple, escaped))
          value2 += simple[escaped];
        else if (escaped === "u") {
          const digits = text.slice(position, position + 4);
          if (!/^[0-9a-fA-F]{4}$/.test(digits))
            fail("MALFORMED_SNAPSHOT");
          value2 += String.fromCharCode(parseInt(digits, 16));
          position += 4;
          uncharged += 4;
        } else
          fail("MALFORMED_SNAPSHOT");
      } else
        value2 += character;
      if (value2.length >= 1024) {
        pieces.push(value2);
        value2 = "";
      }
      if (pieces.length * 1024 + value2.length > MAX_STRING)
        fail("ENCODED_LIMIT_EXCEEDED");
    }
    pieces.push(value2);
    value2 = pieces.join("");
    pieces = [];
    if (value2.length > MAX_STRING)
      fail("ENCODED_LIMIT_EXCEEDED");
    for (const item of scanUnicode(value2, "INCOMPATIBLE_CAPABILITY", "snapshot.string"))
      yield item;
    return value2;
  }
  function* visit(depth) {
    yield { workUnits: 1 };
    if (++nodes > MAX_NODES || depth > MAX_DEPTH)
      fail("ENCODED_LIMIT_EXCEEDED");
    yield* whitespace();
    const next = text[position];
    if (next === '"')
      return yield* string();
    if (next === "{") {
      position++;
      yield* step();
      const result = /* @__PURE__ */ Object.create(null);
      yield* whitespace();
      if (text[position] === "}") {
        position++;
        return Object.freeze(result);
      }
      for (; ; ) {
        yield* whitespace();
        const key = yield* string();
        if (Object.hasOwn(result, key))
          fail("MALFORMED_SNAPSHOT");
        yield* whitespace();
        if (text[position++] !== ":")
          fail("MALFORMED_SNAPSHOT");
        yield* whitespace();
        const start2 = position;
        result[key] = yield* visit(depth + 1);
        if (depth === 0 && key === "body") {
          bodyStart = start2;
          bodyEnd = position;
        }
        yield* whitespace();
        const delimiter = text[position++];
        if (delimiter === "}")
          break;
        if (delimiter !== ",")
          fail("MALFORMED_SNAPSHOT");
      }
      return Object.freeze(result);
    }
    if (next === "[") {
      position++;
      yield* step();
      const result = [];
      yield* whitespace();
      if (text[position] === "]") {
        position++;
        return Object.freeze(result);
      }
      for (; ; ) {
        result.push(yield* visit(depth + 1));
        yield* whitespace();
        const delimiter = text[position++];
        if (delimiter === "]")
          break;
        if (delimiter !== ",")
          fail("MALFORMED_SNAPSHOT");
      }
      return Object.freeze(result);
    }
    for (const [literal, value2] of [["true", true], ["false", false], ["null", null]]) {
      if (text.slice(position, position + literal.length) === literal) {
        position += literal.length;
        uncharged += literal.length;
        return value2;
      }
    }
    const start = position;
    while (position < text.length && /[0-9eE+.\-]/.test(text[position])) {
      position++;
      if (position - start > 128)
        fail("MALFORMED_SNAPSHOT");
      yield* step();
    }
    const token = text.slice(start, position);
    if (!/^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?$/.test(token))
      fail("MALFORMED_SNAPSHOT");
    const number = Number(token);
    if (!Number.isFinite(number))
      fail("MALFORMED_SNAPSHOT");
    return number;
  }
  const value = yield* visit(0);
  yield* whitespace();
  if (position !== text.length || bodyStart < 0)
    fail("MALFORMED_SNAPSHOT");
  if (uncharged)
    yield { workUnits: uncharged };
  return Object.freeze({ value, bodyText: text.slice(bodyStart, bodyEnd) });
}
function object(value, keys, reason = "MALFORMED_SNAPSHOT") {
  if (typeof value !== "object" || value === null || Array.isArray(value))
    fail(reason);
  const result = value;
  const prototype = Object.getPrototypeOf(result);
  if (prototype !== null && prototype !== Object.prototype || !Object.isFrozen(result) || Reflect.ownKeys(result).length !== keys.length || keys.some((key) => {
    const descriptor = Object.getOwnPropertyDescriptor(result, key);
    return !descriptor || !("value" in descriptor) || !descriptor.enumerable;
  }))
    fail(reason);
  return result;
}
function count(value, maximum, minimum = 0) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum)
    fail("INVALID_NATIVE_STATE");
  return value;
}
function isChecksum(value) {
  return typeof value === "string" && HEX.test(value);
}
function equalData(left, right) {
  if (left === right)
    return true;
  if (typeof left !== "object" || left === null || typeof right !== "object" || right === null)
    return false;
  if (Array.isArray(left) || Array.isArray(right))
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((value, index) => equalData(value, right[index]));
  const a = left, b = right, keys = Object.keys(a);
  return keys.length === Object.keys(b).length && keys.every((key) => Object.hasOwn(b, key) && equalData(a[key], b[key]));
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/index/invariants.js
function check(value, path) {
  if (!value)
    invalid("INTERNAL_ERROR", `index.${path}`);
}
function count2(value, path, positive = false) {
  check(Number.isSafeInteger(value) && value >= (positive ? 1 : 0), path);
}
function* inspectIndex(root) {
  const budget = new WorkBudget(root.configuration.limits.maxMutationWorkUnits);
  const charge = (workUnits) => {
    budget.charge(workUnits);
    return { workUnits };
  };
  function* directory2(data) {
    count2(data.size, "directory.size");
    check(Object.getPrototypeOf(data.buckets) === null, "directory.prototype");
    let entries = 0;
    for (const [slot, bucket] of Object.entries(data.buckets)) {
      yield charge(1);
      check(Number.isInteger(Number(slot)) && Number(slot) >= 0 && Number(slot) < DIRECTORY_SLOTS && String(Number(slot)) === slot, "directory.slot");
      check(Object.getPrototypeOf(bucket) === null && Object.keys(bucket).length > 0, "directory.bucket");
      for (const key of Object.keys(bucket)) {
        yield charge(key.length + 1);
        check(bucketOf(key) === slot, "directory.hash");
        entries++;
      }
    }
    check(entries === data.size, "directory.size");
  }
  count2(root.revision, "revision");
  yield* directory2(root.documents);
  const counts = { documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 };
  const statistics = /* @__PURE__ */ Object.create(null);
  for (const field of Object.keys(root.configuration.schema.text))
    statistics[field] = { documents: 0, length: 0 };
  for (const [id, record] of directoryEntries(root.documents)) {
    yield charge(id.length + 1);
    check(record.id === id, "documents.id");
    count2(record.textCodeUnits, "documents.textCodeUnits");
    counts.documents++;
    counts.textCodeUnits += record.textCodeUnits;
    for (const [name, field] of Object.entries(record.fields)) {
      yield charge(1);
      check(Object.hasOwn(statistics, name), "reverse.field");
      count2(field.length, "reverse.length", true);
      let length = 0;
      for (const [term, tf] of Object.entries(field.terms)) {
        yield charge(term.length + id.length + 2);
        count2(tf, "reverse.frequency", true);
        length += tf;
        const entry = root.fields[name] && directoryGet(root.fields[name].terms, term);
        check(entry !== void 0 && directoryGet(entry.postings, id) === tf, "reverse.posting");
      }
      check(length === field.length, "reverse.length");
      statistics[name].documents++;
      statistics[name].length += length;
      counts.tokens += length;
    }
  }
  check(Object.keys(root.fields).length === Object.keys(statistics).length, "fields.count");
  for (const [name, field] of Object.entries(root.fields)) {
    yield charge(1);
    const expected = statistics[name];
    check(expected !== void 0, "fields.name");
    check(field.documents === expected.documents && field.length === expected.length, "fields.statistics");
    yield* directory2(field.terms);
    for (const [term, entry] of directoryEntries(field.terms)) {
      yield charge(term.length + 1);
      count2(entry.df, "terms.df", true);
      count2(entry.frequency, "terms.frequency", true);
      check(entry.df <= field.documents, "terms.df");
      yield* directory2(entry.postings);
      let df = 0, frequency = 0;
      for (const [id, tf] of directoryEntries(entry.postings)) {
        yield charge(id.length + term.length + 2);
        count2(tf, "postings.frequency", true);
        const record = directoryGet(root.documents, id);
        check(record !== void 0 && record.fields[name]?.terms[term] === tf, "postings.reverse");
        df++;
        frequency += tf;
      }
      check(entry.df === df && entry.frequency === frequency, "terms.statistics");
      counts.dictionaryEntries++;
      counts.postingEntries += df;
    }
  }
  for (const name of Object.keys(counts)) {
    yield charge(1);
    check(root.counts[name] === counts[name], "corpus.statistics");
  }
  validateStateCounts(counts, root.configuration.limits);
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/native.js
function map(input) {
  if (typeof input !== "object" || input === null || Array.isArray(input) || Object.getPrototypeOf(input) !== null || !Object.isFrozen(input))
    fail("INVALID_NATIVE_STATE");
  const result = input;
  for (const key of Reflect.ownKeys(result)) {
    const descriptor = Object.getOwnPropertyDescriptor(result, key);
    if (typeof key !== "string" || !descriptor || !("value" in descriptor) || !descriptor.enumerable)
      fail("INVALID_NATIVE_STATE");
  }
  return result;
}
function fieldsEqual(input, expected) {
  return Array.isArray(input) && input.length === expected.length && input.every((value, index) => value === expected[index]);
}
function* unicode(value, maximum, nonempty = false) {
  if (typeof value !== "string" || value.length > maximum || nonempty && !value.length)
    fail("INVALID_NATIVE_STATE");
  yield* scanUnicode(value, "INCOMPATIBLE_CAPABILITY", "snapshot.native.string");
  return value;
}
function* canonicalTerm(value, maximum) {
  const term = yield* unicode(value, maximum, true);
  yield { workUnits: term.length + 1 };
  if (term.toLowerCase() !== term)
    fail("INVALID_NATIVE_STATE");
  return term;
}
function* directory(input, maximum, keyMaximum) {
  const data = object(input, ["size", "buckets"], "INVALID_NATIVE_STATE"), expectedSize = count(data.size, maximum), buckets = map(data.buckets);
  let size = 0;
  for (const [slot, raw] of Object.entries(buckets)) {
    yield { workUnits: 1 };
    if (!/^(0|[1-9][0-9]*)$/.test(slot) || Number(slot) > 255)
      fail("INVALID_NATIVE_STATE");
    const bucket = map(raw);
    if (!Object.keys(bucket).length)
      fail("INVALID_NATIVE_STATE");
    for (const key of Object.keys(bucket)) {
      yield* unicode(key, keyMaximum, true);
      yield { workUnits: key.length + 1 };
      if (bucketOf(key) !== slot || ++size > maximum)
        fail("INVALID_NATIVE_STATE");
    }
  }
  if (size !== expectedSize)
    fail("INVALID_NATIVE_STATE");
  return input;
}
function requireCodecs(configuration) {
  for (const registration of configuration.capabilities?.ordered ?? [])
    if (registration.participant) {
      const codec = registration.manifest.codec;
      if (!codec || codec.version !== 1 || !["raveldex-source-v1", "raveldex-positions-v1"].includes(codec.id))
        fail("UNSUPPORTED_CODEC", "snapshot.participants");
      const identity = registration.manifest.execution.workerRegistration;
      const family = codec.id === "raveldex-source-v1" ? "source" : "positions";
      if (!identity?.startsWith(`raveldex:${family}:1:`))
        fail("UNSUPPORTED_CODEC", "snapshot.participants");
    }
}
function* metadata(entry, configuration) {
  const owned = captureRecord({ id: entry.id, text: {}, metadata: entry.metadata }, configuration.schema, configuration.limits);
  for (const [field, raw] of Object.entries(owned.metadata)) {
    yield { workUnits: field.length + 1 };
    if (Array.isArray(raw) && new Set(raw).size !== raw.length)
      fail("INVALID_NATIVE_STATE");
    const original = entry.metadata[field];
    if (Array.isArray(raw) ? !Array.isArray(original) || raw.some((item, index) => !Object.is(item, original[index])) : !Object.is(raw, original))
      fail("INVALID_NATIVE_STATE");
    for (const item of Array.isArray(raw) ? raw : [raw])
      if (typeof item === "string")
        yield* unicode(item, configuration.limits.maxMetadataStringCodeUnits);
  }
}
function* validateNative(payload, configuration, revision) {
  requireCodecs(configuration);
  const data = object(payload, ["documents", "fields", "counts", "participants"], "INVALID_NATIVE_STATE"), limits = configuration.limits;
  const documents = yield* directory(data.documents, limits.maxDocuments, limits.maxIdCodeUnits);
  const fieldData = map(data.fields), fieldNames = Object.keys(configuration.schema.text);
  if (Object.keys(fieldData).length !== fieldNames.length || fieldNames.some((name) => !Object.hasOwn(fieldData, name)))
    fail("INVALID_NATIVE_STATE");
  const counts = object(data.counts, ["documents", "textCodeUnits", "tokens", "dictionaryEntries", "postingEntries"], "INVALID_NATIVE_STATE");
  for (const [name, maximum] of [["documents", limits.maxDocuments], ["textCodeUnits", limits.maxCorpusTextCodeUnits], ["tokens", limits.maxCorpusTokens], ["dictionaryEntries", limits.maxDictionaryEntries], ["postingEntries", limits.maxPostingEntries]])
    count(counts[name], maximum);
  for (const [id, entry] of directoryEntries(documents)) {
    object(entry, ["id", "textCodeUnits", "metadata", "fields"], "INVALID_NATIVE_STATE");
    yield* unicode(entry.id, limits.maxIdCodeUnits, true);
    if (entry.id !== id)
      fail("INVALID_NATIVE_STATE");
    count(entry.textCodeUnits, limits.maxTextCodeUnitsPerRecord);
    yield* metadata(entry, configuration);
    const fields = map(entry.fields);
    let tokens = 0;
    for (const [name, raw] of Object.entries(fields)) {
      if (!Object.hasOwn(configuration.schema.text, name))
        fail("INVALID_NATIVE_STATE");
      const reverse = object(raw, ["length", "terms"], "INVALID_NATIVE_STATE"), terms = map(reverse.terms);
      tokens += count(reverse.length, limits.maxTokensPerRecord, 1);
      if (!Object.keys(terms).length || tokens > limits.maxTokensPerRecord)
        fail("INVALID_NATIVE_STATE");
      for (const [term, frequency] of Object.entries(terms)) {
        yield* canonicalTerm(term, limits.maxTermCodeUnits);
        count(frequency, limits.maxTokensPerRecord, 1);
      }
    }
    if (tokens > entry.textCodeUnits)
      fail("INVALID_NATIVE_STATE");
  }
  for (const name of fieldNames) {
    const field = object(fieldData[name], ["documents", "length", "terms"], "INVALID_NATIVE_STATE");
    count(field.documents, limits.maxDocuments);
    count(field.length, limits.maxCorpusTokens);
    const terms = yield* directory(field.terms, limits.maxDictionaryEntries, limits.maxTermCodeUnits);
    for (const [, entry] of directoryEntries(terms)) {
      object(entry, ["df", "frequency", "postings"], "INVALID_NATIVE_STATE");
      count(entry.df, limits.maxDocuments, 1);
      count(entry.frequency, limits.maxCorpusTokens, 1);
      const postings = yield* directory(entry.postings, limits.maxDocuments, limits.maxIdCodeUnits);
      for (const [, frequency] of directoryEntries(postings)) {
        yield { workUnits: 1 };
        count(frequency, limits.maxTokensPerRecord, 1);
      }
    }
  }
  const participants = map(data.participants);
  const expected = initializeParticipants(configuration).states;
  if (Object.keys(participants).length !== Object.keys(expected).length || Object.keys(expected).some((id) => !Object.hasOwn(participants, id)))
    fail("INVALID_NATIVE_STATE");
  const root = Object.freeze({ revision, configuration, documents, fields: fieldData, counts, participants });
  yield* inspectIndex(root);
  for (const registration of configuration.capabilities?.ordered ?? []) {
    if (!registration.participant)
      continue;
    const id = registration.manifest.id;
    const budget = new WorkBudget(Math.min(registration.manifest.limits.maxWorkUnits, limits.maxMutationWorkUnits));
    const cursor = registration.manifest.codec.id === "raveldex-source-v1" ? source(participants[id], expected[id], root) : positions(participants[id], expected[id], root);
    let finished = false;
    try {
      for (; ; ) {
        const step = cursor.next();
        if (step.done) {
          finished = true;
          break;
        }
        budget.charge(step.value.workUnits);
        yield step.value;
      }
    } finally {
      if (!finished) {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    }
  }
  const completeSource = fieldNames.every((field) => !!configuration.capabilities?.providers[`source:${field}`]?.participant);
  if (completeSource)
    for (const [id, document] of directoryEntries(root.documents)) {
      let units = 0;
      for (const field of fieldNames) {
        const provider = configuration.capabilities.providers[`source:${field}`], values = directoryGet(root.participants[provider.manifest.id].records, id).text[field];
        for (const value of values ?? []) {
          yield { workUnits: value.length + 1 };
          units += value.length;
        }
      }
      if (units !== document.textCodeUnits)
        fail("INVALID_NATIVE_STATE");
    }
  return root;
}
function* source(input, expected, core) {
  const data = object(input, ["kind", "revision", "analyzer", "fields", "records", "retainedEntries", "textCodeUnits", "maxRetainedEntries", "maxTextCodeUnits"], "INVALID_NATIVE_STATE");
  if (data.kind !== expected.kind || data.revision !== core.revision || !equalData(data.analyzer, core.configuration.analyzer) || !fieldsEqual(data.fields, expected.fields) || data.maxRetainedEntries !== expected.maxRetainedEntries || data.maxTextCodeUnits !== expected.maxTextCodeUnits)
    fail("INVALID_NATIVE_STATE");
  const records = yield* directory(data.records, core.documents.size, core.configuration.limits.maxIdCodeUnits);
  if (records.size !== core.documents.size)
    fail("INVALID_NATIVE_STATE");
  let retainedEntries = 0, textCodeUnits = 0;
  for (const [id, entry] of directoryEntries(records)) {
    object(entry, ["text", "retainedEntries", "textCodeUnits"], "INVALID_NATIVE_STATE");
    const document = directoryGet(core.documents, id);
    if (!document)
      fail("INVALID_NATIVE_STATE");
    const text = map(entry.text);
    let entries = 1, units = 0;
    for (const field of Object.keys(text)) {
      if (!expected.fields.includes(field))
        fail("INVALID_NATIVE_STATE");
      const values = text[field];
      if (!Array.isArray(values) || values.length > core.configuration.limits.maxTextValuesPerField)
        fail("INVALID_NATIVE_STATE");
      entries += 1 + values.length;
      const terms = /* @__PURE__ */ Object.create(null);
      for (const value of values) {
        yield* unicode(value, core.configuration.limits.maxTextCodeUnitsPerValue);
        units += value.length;
        for (const step of analyzeValue(value, 0, core.configuration.limits)) {
          yield { workUnits: step.workUnits };
          if (step.token)
            terms[step.token.term] = (terms[step.token.term] ?? 0) + 1;
        }
      }
      const reverse = document.fields[field];
      if (Object.keys(terms).length !== Object.keys(reverse?.terms ?? {}).length)
        fail("INVALID_NATIVE_STATE");
      for (const term of Object.keys(terms)) {
        yield { workUnits: term.length + 1 };
        if (terms[term] !== reverse?.terms[term])
          fail("INVALID_NATIVE_STATE");
      }
    }
    for (const field of expected.fields)
      if (!Object.hasOwn(text, field) && document.fields[field])
        fail("INVALID_NATIVE_STATE");
    if (entries !== entry.retainedEntries || units !== entry.textCodeUnits || units > document.textCodeUnits)
      fail("INVALID_NATIVE_STATE");
    retainedEntries += entries;
    textCodeUnits += units;
  }
  if (data.retainedEntries !== retainedEntries || data.textCodeUnits !== textCodeUnits || retainedEntries > expected.maxRetainedEntries || textCodeUnits > expected.maxTextCodeUnits)
    fail("INVALID_NATIVE_STATE");
}
function* positions(input, expected, core) {
  const keys = ["kind", "revision", "analyzer", "fields", "offsetFields", "records", "limits", "maxRetainedEntries", "maxOccurrences", "maxTermCodeUnits", "retainedEntries", "occurrenceCount", "offsetCount", "termEntries", "termCodeUnits"];
  const data = object(input, keys, "INVALID_NATIVE_STATE");
  if (data.kind !== expected.kind || data.revision !== core.revision || !equalData(data.analyzer, core.configuration.analyzer) || !equalData(data.limits, expected.limits) || !fieldsEqual(data.fields, expected.fields) || !fieldsEqual(data.offsetFields, expected.offsetFields) || data.maxRetainedEntries !== expected.maxRetainedEntries || data.maxOccurrences !== expected.maxOccurrences || data.maxTermCodeUnits !== expected.maxTermCodeUnits)
    fail("INVALID_NATIVE_STATE");
  const records = yield* directory(data.records, core.documents.size, core.configuration.limits.maxIdCodeUnits);
  if (records.size !== core.documents.size)
    fail("INVALID_NATIVE_STATE");
  const totals = { retainedEntries: 0, occurrenceCount: 0, offsetCount: 0, termEntries: 0, termCodeUnits: 0 };
  for (const [id, entry] of directoryEntries(records)) {
    object(entry, ["positions", ...Object.keys(totals)], "INVALID_NATIVE_STATE");
    const document = directoryGet(core.documents, id);
    if (!document)
      fail("INVALID_NATIVE_STATE");
    const fields = map(entry.positions), counts = { retainedEntries: 1, occurrenceCount: 0, offsetCount: 0, termEntries: 0, termCodeUnits: 0 };
    let minimumCodeUnits = 0;
    for (const [field, rawValues] of Object.entries(fields)) {
      if (!expected.fields.includes(field) || !Array.isArray(rawValues) || rawValues.length > expected.limits.maxTextValuesPerField)
        fail("INVALID_NATIVE_STATE");
      counts.retainedEntries += 1 + rawValues.length;
      const withOffsets = expected.offsetFields.includes(field), frequencies = /* @__PURE__ */ Object.create(null);
      const sourceProvider = core.configuration.capabilities?.providers[`source:${field}`];
      const sourceRoot = sourceProvider ? core.participants[sourceProvider.manifest.id] : void 0;
      const sourceValues = sourceRoot ? directoryGet(sourceRoot.records, id)?.text[field] : void 0;
      if (sourceRoot && (!sourceValues || sourceValues.length !== rawValues.length))
        fail("INVALID_NATIVE_STATE");
      for (let valueIndex = 0; valueIndex < rawValues.length; valueIndex++) {
        const value = object(rawValues[valueIndex], ["tokenCount", "terms"], "INVALID_NATIVE_STATE"), tokenCount = count(value.tokenCount, expected.limits.maxTokensPerRecord), terms = map(value.terms);
        const ordinals = /* @__PURE__ */ new Map();
        for (const [term, rawOccurrences] of Object.entries(terms)) {
          yield* canonicalTerm(term, expected.limits.maxTermCodeUnits);
          if (!Array.isArray(rawOccurrences) || !rawOccurrences.length || rawOccurrences.length > tokenCount)
            fail("INVALID_NATIVE_STATE");
          counts.termEntries++;
          counts.termCodeUnits += term.length;
          counts.retainedEntries++;
          let last = -1;
          for (const rawOccurrence of rawOccurrences) {
            yield { workUnits: term.length + 1 };
            const occurrence = object(rawOccurrence, withOffsets ? ["position", "positionLength", "start", "end"] : ["position", "positionLength"], "INVALID_NATIVE_STATE");
            const position = count(occurrence.position, tokenCount - 1);
            if (position <= last || occurrence.positionLength !== 1 || ordinals.has(position))
              fail("INVALID_NATIVE_STATE");
            last = position;
            let span = {};
            if (withOffsets) {
              const start = count(occurrence.start, expected.limits.maxTextCodeUnitsPerValue), end = count(occurrence.end, expected.limits.maxTextCodeUnitsPerValue, 1);
              if (end <= start || end - start > expected.limits.maxRawTokenCodeUnits)
                fail("INVALID_NATIVE_STATE");
              span = { start, end };
              counts.offsetCount++;
              counts.retainedEntries += 2;
            }
            ordinals.set(position, span);
            counts.occurrenceCount++;
            counts.retainedEntries++;
          }
          frequencies[term] = (frequencies[term] ?? 0) + rawOccurrences.length;
        }
        if (ordinals.size !== tokenCount || counts.occurrenceCount > expected.limits.maxTokensPerRecord)
          fail("INVALID_NATIVE_STATE");
        let previousEnd = 0;
        for (let position = 0; position < tokenCount; position++) {
          yield { workUnits: 1 };
          const span = ordinals.get(position);
          if (!span)
            fail("INVALID_NATIVE_STATE");
          if (withOffsets) {
            if (span.start < previousEnd)
              fail("INVALID_NATIVE_STATE");
            previousEnd = span.end;
          }
        }
        minimumCodeUnits += previousEnd;
        if (sourceValues) {
          const seen = /* @__PURE__ */ Object.create(null);
          let analyzed = 0;
          for (const step of analyzeValue(sourceValues[valueIndex], valueIndex, expected.limits)) {
            yield { workUnits: step.workUnits };
            if (!step.token)
              continue;
            const token = step.token, occurrence = value.terms[token.term]?.[seen[token.term] ?? 0];
            if (!occurrence || occurrence.position !== token.position || withOffsets && (occurrence.start !== token.start || occurrence.end !== token.end))
              fail("INVALID_NATIVE_STATE");
            seen[token.term] = (seen[token.term] ?? 0) + 1;
            analyzed++;
          }
          if (analyzed !== tokenCount)
            fail("INVALID_NATIVE_STATE");
        }
      }
      const reverse = document.fields[field]?.terms ?? {};
      if (Object.keys(frequencies).length !== Object.keys(reverse).length || Object.keys(frequencies).some((term) => frequencies[term] !== reverse[term]))
        fail("INVALID_NATIVE_STATE");
    }
    for (const field of expected.fields) {
      if (!Object.hasOwn(fields, field) && document.fields[field])
        fail("INVALID_NATIVE_STATE");
      const provider = core.configuration.capabilities?.providers[`source:${field}`], retained = provider ? directoryGet(core.participants[provider.manifest.id].records, id)?.text : void 0;
      if (retained && Object.hasOwn(retained, field) !== Object.hasOwn(fields, field))
        fail("INVALID_NATIVE_STATE");
    }
    if (minimumCodeUnits > document.textCodeUnits)
      fail("INVALID_NATIVE_STATE");
    for (const key of Object.keys(totals)) {
      if (entry[key] !== counts[key])
        fail("INVALID_NATIVE_STATE");
      totals[key] += counts[key];
    }
  }
  for (const key of Object.keys(totals))
    if (data[key] !== totals[key])
      fail("INVALID_NATIVE_STATE");
  if (totals.retainedEntries > expected.maxRetainedEntries || totals.occurrenceCount > expected.maxOccurrences || totals.termCodeUnits > expected.maxTermCodeUnits)
    fail("INVALID_NATIVE_STATE");
}
function rebaseNative(root, revision) {
  const participants = /* @__PURE__ */ Object.create(null);
  for (const [id, state] of Object.entries(root.participants))
    participants[id] = Object.freeze({ ...state, revision });
  return Object.freeze({ ...root, revision, participants: Object.freeze(participants) });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/source.js
function* sourceRecords(root) {
  const fields = Object.keys(root.configuration.schema.text);
  const providers = requireCompleteSource(root);
  const records = [];
  for (const [id, entry] of directoryEntries(root.documents)) {
    yield { workUnits: id.length + 1 };
    const text = /* @__PURE__ */ Object.create(null);
    let textCodeUnits = 0;
    for (let index = 0; index < fields.length; index++) {
      const field = fields[index], retained = directoryGet(providers[index].records, id);
      yield { workUnits: id.length + field.length + 1 };
      if (!retained)
        fail("INVALID_NATIVE_STATE");
      if (Object.hasOwn(retained.text, field)) {
        text[field] = retained.text[field];
        for (const value of text[field]) {
          yield { workUnits: value.length + 1 };
          textCodeUnits += value.length;
        }
      }
    }
    if (textCodeUnits !== entry.textCodeUnits)
      fail("INVALID_NATIVE_STATE");
    records.push(Object.freeze({ id, text: Object.freeze(text), metadata: entry.metadata }));
  }
  for (const record of records)
    yield { workUnits: record.id.length + Math.ceil(Math.log2(records.length + 1)) + 1 };
  records.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  return Object.freeze(records);
}
function requireCompleteSource(root) {
  return Object.keys(root.configuration.schema.text).map((field) => {
    const registration = root.configuration.capabilities?.providers[`source:${field}`];
    if (!registration?.participant || registration.manifest.codec?.id !== "raveldex-source-v1" || registration.manifest.codec.version !== 1)
      fail("SOURCE_UNAVAILABLE");
    return requireSourceRoot(root.participants[registration.manifest.id], field, root.revision, root.configuration.analyzer);
  });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/snapshots.js
var CODEC = Object.freeze({ id: "raveldex-json-v1", version: 1 });
var INDEX_DETAIL = Object.freeze({ id: "frequency-directory-256-v1", version: 1 });
var RANKING = Object.freeze({ model: "raveldex-bm25-v1", implementationVersion: 1 });
var bindings = /* @__PURE__ */ new WeakMap();
function* metered(cursor, maximum, check2) {
  const budget = new WorkBudget(maximum);
  let finished = false;
  try {
    for (; ; ) {
      check2("snapshot");
      const step = cursor.next();
      if (step.done) {
        finished = true;
        return step.value;
      }
      check2("snapshot");
      budget.charge(step.value.workUnits);
      yield step.value;
    }
  } finally {
    if (!finished) {
      try {
        cursor.return(void 0);
      } catch {
      }
    }
  }
}
function header(root, qualification) {
  return Object.freeze({
    schemaVersion: 1,
    schema: root.configuration.schema,
    analyzer: root.configuration.analyzer,
    ranking: RANKING,
    capabilities: Object.freeze((root.configuration.capabilities?.ordered ?? []).map((entry) => entry.manifest)),
    indexDetail: INDEX_DETAIL,
    limits: root.configuration.limits,
    originRevision: root.revision,
    nativeQualification: qualification ?? null
  });
}
function nativeQualification(engine, root) {
  const qualification = bindings.get(engine);
  if (!qualification || root.configuration.analyzer.environmentProfile === "unqualified")
    fail("UNQUALIFIED_PROFILE");
  const current = captureQualification(qualification);
  if (current.profileId !== root.configuration.analyzer.environmentProfile)
    fail("PROFILE_MISMATCH");
  return current;
}
function* encoded(root, format, qualification, maximum) {
  requireCodecs(root.configuration);
  if (format === "raveldex-source")
    requireCompleteSource(root);
  const native = Object.freeze({ documents: root.documents, fields: root.fields, counts: root.counts, participants: root.participants });
  try {
    yield* validateNative(native, root.configuration, root.revision);
  } catch (error) {
    if (error instanceof SnapshotAdapterError || error instanceof RaveldexError && ["CANCELLED", "DISPOSED", "DEADLINE_EXCEEDED", "WORK_LIMIT_EXCEEDED", "RESOURCE_EXHAUSTED"].includes(error.code))
      throw error;
    fail("INVALID_NATIVE_STATE");
  }
  const payload = format === "raveldex-source" ? Object.freeze({ records: yield* sourceRecords(root) }) : native;
  const body = yield* encodeJson(Object.freeze({ header: header(root, qualification), payload }), maximum);
  const integrity = yield* checksum(body);
  const result = `{"format":${JSON.stringify(format)},"formatVersion":1,"codec":{"id":"${CODEC.id}","version":1},"body":${body},"integrity":{"algorithm":"fnv1a32-utf16","value":"${integrity}"}}`;
  yield* utf8Bytes(result, maximum);
  return result;
}
function checkedHeader(raw, root, format, qualification) {
  const value = object(raw, ["schemaVersion", "schema", "analyzer", "ranking", "capabilities", "indexDetail", "limits", "originRevision", "nativeQualification"]);
  if (value.schemaVersion !== 1 || !equalData(value.schema, root.configuration.schema))
    fail("SCHEMA_MISMATCH");
  if (!equalData(value.ranking, RANKING))
    fail("RANKING_MISMATCH");
  if (!equalData(value.indexDetail, INDEX_DETAIL))
    fail("INDEX_DETAIL_MISMATCH");
  if (!equalData(value.limits, root.configuration.limits))
    fail("LIMITS_MISMATCH");
  if (!equalData(value.capabilities, (root.configuration.capabilities?.ordered ?? []).map((entry) => entry.manifest)))
    fail("CAPABILITY_MISMATCH");
  const analyzer = object(value.analyzer, ["id", "environmentProfile"]);
  if (analyzer.id !== root.configuration.analyzer.id || typeof analyzer.environmentProfile !== "string" || !analyzer.environmentProfile.length || analyzer.environmentProfile.length > 128)
    fail("ANALYZER_MISMATCH");
  if (format === "raveldex-native") {
    if (analyzer.environmentProfile === "unqualified" || value.nativeQualification === null)
      fail("UNQUALIFIED_PROFILE");
    if (!equalData(value.analyzer, root.configuration.analyzer) || !equalData(value.nativeQualification, qualification))
      fail("PROFILE_MISMATCH");
  } else {
    if (value.nativeQualification !== null) {
      let declared;
      try {
        declared = captureQualification(value.nativeQualification, false);
      } catch {
        fail("PROFILE_MISMATCH");
      }
      if (declared.profileId !== analyzer.environmentProfile)
        fail("PROFILE_MISMATCH");
    } else if (analyzer.environmentProfile !== "unqualified")
      fail("PROFILE_MISMATCH");
  }
  count(value.originRevision, Number.MAX_SAFE_INTEGER);
  return value;
}
function* preparedSource(payload, configuration) {
  const data = object(payload, ["records"]);
  if (!Array.isArray(data.records) || data.records.length > configuration.limits.maxDocuments)
    fail("MALFORMED_SNAPSHOT");
  const installed = initializeParticipants(configuration);
  const participants = installed.participants.map((participant) => {
    const budget = new WorkBudget(participant.maxWorkUnits ?? configuration.limits.maxMutationWorkUnits);
    return Object.freeze({ id: participant.id, ...participant.maxWorkUnits !== void 0 ? { maxWorkUnits: participant.maxWorkUnits } : {}, *prepare(previous, context) {
      const cursor = participant.prepare(previous, context);
      let finished = false;
      try {
        for (; ; ) {
          const step = cursor.next();
          if (step.done) {
            finished = true;
            return step.value;
          }
          budget.charge(step.value.workUnits);
          yield step.value;
        }
      } finally {
        if (!finished) {
          try {
            cursor.return(void 0);
          } catch {
          }
        }
      }
    } });
  });
  const owner = new MutationOwner(emptyRoot(configuration, installed.states), participants);
  for (const record of data.records) {
    yield { workUnits: 1 };
    const request = owner.capture("add", record);
    yield* owner.execute(request);
  }
  return owner.root;
}
function* restoreCursor(engine, root, encoded2, maximum, publish, check2) {
  check2("snapshot.decode");
  let decoded;
  try {
    decoded = yield* decodeJson(encoded2, maximum);
  } catch (error) {
    if (error instanceof SnapshotAdapterError || error instanceof RaveldexError && ["CANCELLED", "DISPOSED", "DEADLINE_EXCEEDED", "WORK_LIMIT_EXCEEDED", "RESOURCE_EXHAUSTED"].includes(error.code))
      throw error;
    fail("MALFORMED_SNAPSHOT");
  }
  const envelope = object(decoded.value, ["format", "formatVersion", "codec", "body", "integrity"]);
  if (envelope.format !== "raveldex-source" && envelope.format !== "raveldex-native" || envelope.formatVersion !== 1)
    fail("UNSUPPORTED_FORMAT");
  if (!equalData(envelope.codec, CODEC))
    fail("UNSUPPORTED_CODEC");
  const integrity = object(envelope.integrity, ["algorithm", "value"]);
  if (integrity.algorithm !== "fnv1a32-utf16" || !isChecksum(integrity.value))
    fail("UNSUPPORTED_CODEC");
  check2("snapshot.integrity");
  if ((yield* checksum(decoded.bodyText)) !== integrity.value)
    fail("INTEGRITY_MISMATCH");
  const format = envelope.format, body = object(envelope.body, ["header", "payload"]);
  const qualification = format === "raveldex-native" ? nativeQualification(engine, root) : void 0;
  check2("snapshot.compatibility");
  const origin = checkedHeader(body.header, root, format, qualification);
  requireCodecs(root.configuration);
  if (root.revision === Number.MAX_SAFE_INTEGER)
    invalid("REVISION_EXHAUSTED", "revision");
  let prepared;
  check2(format === "raveldex-native" ? "snapshot.validation" : "snapshot.staging");
  try {
    prepared = format === "raveldex-native" ? yield* validateNative(body.payload, root.configuration, origin.originRevision) : yield* preparedSource(body.payload, root.configuration);
  } catch (error) {
    if (error instanceof SnapshotAdapterError || error instanceof RaveldexError && ["CANCELLED", "DISPOSED", "DEADLINE_EXCEEDED", "WORK_LIMIT_EXCEEDED", "REVISION_EXHAUSTED", "RESOURCE_EXHAUSTED"].includes(error.code))
      throw error;
    fail("INVALID_NATIVE_STATE");
  }
  const next = rebaseNative(prepared, root.revision + 1);
  const result = Object.freeze({
    format,
    originRevision: origin.originRevision,
    revision: next.revision,
    reindexed: format === "raveldex-source",
    receivingAnalyzer: root.configuration.analyzer
  });
  yield { workUnits: 1 };
  check2("snapshot.precommit");
  publish(next);
  return result;
}
function controlledSnapshots(engine, options = {}, control) {
  const owner = getExecutionOwner(engine);
  if (!owner)
    fail("UNSUPPORTED_ENGINE");
  const data = ownObject(options, "INVALID_OPTIONS", "snapshot.options", new Admission(32));
  keysOnly(data, ["maxEncodedBytes"], "INVALID_OPTIONS", "snapshot.options");
  const maximum = has(data, "maxEncodedBytes") ? data.maxEncodedBytes : MAX_ENCODED_BYTES;
  if (typeof maximum !== "number" || !Number.isSafeInteger(maximum) || maximum < 1024 || maximum > MAX_ENCODED_BYTES)
    invalid("INVALID_OPTIONS", "snapshot.maxEncodedBytes");
  function exportFormat(format, options2) {
    return owner.adapterOperation((configuration) => ({ options: captureOptions(options2, configuration.limits, false), *start(root, check2) {
      const qualification = format === "raveldex-native" ? nativeQualification(engine, root) : bindings.get(engine);
      return yield* metered(encoded(root, format, qualification, maximum), configuration.limits.maxMutationWorkUnits, check2);
    } }), control);
  }
  return Object.freeze({
    exportSource: (options2) => exportFormat("raveldex-source", options2),
    exportNative: (options2) => exportFormat("raveldex-native", options2),
    restore(encoded2, options2) {
      return owner.adapterOperation((configuration) => {
        const capturedOptions = captureOptions(options2, configuration.limits, false);
        if (capturedOptions.signal?.aborted)
          invalid("CANCELLED", "options.signal");
        if (typeof encoded2 !== "string")
          fail("MALFORMED_SNAPSHOT");
        if (encoded2.length > maximum)
          fail("ENCODED_LIMIT_EXCEEDED");
        return { options: capturedOptions, *start(root, check2, publish) {
          return yield* metered(restoreCursor(engine, root, encoded2, maximum, publish, check2), configuration.limits.maxMutationWorkUnits, check2);
        } };
      }, control);
    }
  });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/worker/error.js
var WORKER_ERROR_CODES = Object.freeze([
  "INVALID_TRANSPORT",
  "TRANSPORT_LIMIT",
  "INCOMPATIBLE_WORKER",
  "TIMEOUT",
  "TERMINATED",
  "STARTUP_FAILED",
  "OUTCOME_UNKNOWN",
  "DISPOSED"
]);
var WorkerAdapterError = class extends Error {
  code;
  details;
  operationId;
  constructor(code, details = {}) {
    super(`Raveldex worker: ${code}`);
    this.name = "WorkerAdapterError";
    this.code = code;
    this.operationId = details.operationId;
    this.details = Object.freeze({ ...details });
  }
};

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/worker/protocol.js
var PROTOCOL = 1;
var IMPLEMENTATION = "raveldex-native-v1";
var MAX_MESSAGE_BYTES = 8 * 1024 * 1024;
var MAX_PENDING = 64;
var RECEIPT_WINDOW = 256;
var MAX_NODES2 = 131072;
var MAX_DEPTH2 = 64;
var MAX_ARRAY = 65536;
var OPERATIONS = Object.freeze(["init", "search", "add", "addMany", "replace", "remove", "clear", "reconcile", "dispose", "snapshotExportSource", "snapshotRestore", "snapshotReconcile"]);
var mutation = (operation) => ["add", "addMany", "replace", "remove", "clear", "snapshotRestore"].includes(operation);
function monotonicEpoch() {
  const origin = performance.timeOrigin, now = performance.now();
  if (!Number.isFinite(origin) || !Number.isFinite(now))
    throw new WorkerAdapterError("STARTUP_FAILED", { path: "worker.clock" });
  return origin + now;
}
function fail2(path = "transport") {
  throw new WorkerAdapterError("INVALID_TRANSPORT", { path });
}
function object2(value, allowed) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    fail2();
  const data = value;
  if (allowed && Object.keys(data).some((key) => !allowed.includes(key)))
    fail2();
  return data;
}
function integer2(value, maximum = Number.MAX_SAFE_INTEGER, minimum = 0) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum)
    fail2();
  return value;
}
function cap(value = MAX_MESSAGE_BYTES) {
  return integer2(value, MAX_MESSAGE_BYTES, 1024);
}
function sessionValue(value) {
  if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value))
    fail2("transport.session");
  return value;
}
function captureMessage(input, maximum) {
  let bytes = 0, nodes = 0;
  const active = /* @__PURE__ */ new Set();
  const charge = (amount) => {
    bytes += amount;
    if (bytes > maximum)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.bytes", limit: maximum, actual: bytes });
  };
  function string(value) {
    charge(2);
    for (let i = 0; i < value.length; i++) {
      const point = value.charCodeAt(i);
      if (point === 34 || point === 92 || point === 8 || point === 9 || point === 10 || point === 12 || point === 13)
        charge(2);
      else if (point < 32)
        charge(6);
      else if (point < 128)
        charge(1);
      else if (point < 2048)
        charge(2);
      else if (point >= 55296 && point <= 56319 && value.charCodeAt(i + 1) >= 56320 && value.charCodeAt(i + 1) <= 57343) {
        charge(4);
        i++;
      } else
        charge(point >= 55296 && point <= 57343 ? 6 : 3);
    }
  }
  function visit(value, depth) {
    if (++nodes > MAX_NODES2 || depth > MAX_DEPTH2)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.structure", limit: depth > MAX_DEPTH2 ? MAX_DEPTH2 : MAX_NODES2, actual: depth > MAX_DEPTH2 ? depth : nodes });
    if (value === null) {
      charge(4);
      return null;
    }
    if (typeof value === "boolean") {
      charge(value ? 4 : 5);
      return value;
    }
    if (typeof value === "string") {
      string(value);
      return value;
    }
    if (typeof value === "number" && Number.isFinite(value)) {
      charge(String(value).length);
      return value;
    }
    if (!value || typeof value !== "object" || active.has(value))
      fail2("transport.data");
    const array = Array.isArray(value), prototype = Object.getPrototypeOf(value);
    if (prototype !== null && prototype !== (array ? Array.prototype : Object.prototype))
      fail2("transport.prototype");
    const keys = Reflect.ownKeys(value);
    if (keys.length > MAX_NODES2 - nodes)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.structure", limit: MAX_NODES2, actual: keys.length + nodes });
    active.add(value);
    charge(2);
    if (array) {
      if (value.length > MAX_ARRAY)
        throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.array", limit: MAX_ARRAY, actual: value.length });
      if (keys.length !== value.length + 1 || keys.some((key) => key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length)))
        fail2("transport.array");
      const result2 = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
        if (!descriptor || !("value" in descriptor))
          fail2("transport.accessor");
        if (i)
          charge(1);
        result2.push(visit(descriptor.value, depth + 1));
      }
      active.delete(value);
      return Object.freeze(result2);
    }
    const result = /* @__PURE__ */ Object.create(null);
    let index = 0;
    for (const key of keys) {
      if (typeof key !== "string" || key.length > 256)
        fail2("transport.key");
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !("value" in descriptor))
        fail2("transport.accessor");
      if (index++)
        charge(1);
      string(key);
      charge(1);
      result[key] = visit(descriptor.value, depth + 1);
    }
    active.delete(value);
    return Object.freeze(result);
  }
  return visit(input, 0);
}
function canonical(value) {
  if (value === null || typeof value !== "object")
    return JSON.stringify(value);
  if (Array.isArray(value))
    return `[${value.map(canonical).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
}
function wireError(error) {
  if (error instanceof RaveldexError && error.name === "SnapshotAdapterError" && "reason" in error && typeof error.reason === "string" && error.reason.length <= 64)
    return Object.freeze({ name: "SnapshotAdapterError", code: error.code, reason: error.reason, details: error.details });
  if (error instanceof RaveldexError)
    return Object.freeze({ name: "RaveldexError", code: error.code, details: error.details });
  if (error instanceof WorkerAdapterError)
    return Object.freeze({ name: "WorkerAdapterError", code: error.code, details: error.details });
  return Object.freeze({ name: "RaveldexError", code: "INTERNAL_ERROR", details: Object.freeze({}) });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/worker/host.js
var liveScopes = /* @__PURE__ */ new WeakSet();
function serveWorkerWithSnapshots(scope, options = {}, snapshotFactory) {
  if (liveScopes.has(scope))
    throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.owner" });
  liveScopes.add(scope);
  try {
    return installWorkerHost(scope, options, snapshotFactory);
  } catch (error) {
    liveScopes.delete(scope);
    throw error;
  }
}
function installWorkerHost(scope, options, snapshotFactory) {
  const data = ownObject(options, "INVALID_OPTIONS", "worker.host", new Admission(64));
  keysOnly(data, ["addons", "maxMessageBytes"], "INVALID_OPTIONS", "worker.host");
  const addons = Object.hasOwn(data, "addons") ? ownArray(data.addons, 32, "INVALID_OPTIONS", "worker.host.addons", new Admission(64)) : [];
  const hostMaximum = cap(data.maxMessageBytes);
  const post = scope.postMessage.bind(scope), addListener = scope.addEventListener.bind(scope), removeListener = scope.removeEventListener.bind(scope);
  let maximum = hostMaximum, session, lastId = 0;
  let owner, configuration;
  let initialized = false, closing = false, cleaned = false, disposal;
  const active = /* @__PURE__ */ new Map();
  const receipts = /* @__PURE__ */ new Map();
  const receiptDomains = /* @__PURE__ */ new Map();
  let snapshots;
  const inflight = /* @__PURE__ */ new Map();
  function record(value) {
    receipts.set(value.operationId, value);
    while (receipts.size > RECEIPT_WINDOW) {
      const victim = [...receipts].find(([, receipt]) => receipt.status !== "pending");
      if (!victim)
        break;
      receipts.delete(victim[0]);
      receiptDomains.delete(victim[0]);
    }
  }
  function send(request, kind, value) {
    const envelope = { protocol: PROTOCOL, session: request.session, id: request.id, operation: request.operation, kind, value };
    try {
      post(captureMessage(envelope, maximum));
    } catch (error) {
      const failure2 = mutation(request.operation) ? new WorkerAdapterError("OUTCOME_UNKNOWN", { operationId: `${request.session}:${request.id}` }) : error instanceof WorkerAdapterError ? error : new WorkerAdapterError("TERMINATED");
      try {
        post(captureMessage({ ...envelope, kind: "error", value: wireError(failure2) }, maximum));
      } catch {
      }
    }
  }
  function identity(value) {
    return { schema: value.schema, limits: value.limits, analyzer: value.analyzer };
  }
  async function execute(request) {
    const id = request.id, operation = request.operation;
    const operationId = `${request.session}:${id}`;
    let trackedMutation = false;
    try {
      const payload = object2(request.payload);
      if (operation === "init") {
        if (initialized || closing)
          throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.initialized" });
        initialized = true;
        object2(payload, ["implementation", "model", "configuration", "identity", "hasAddons", "manifests", "sameHost", "maxMessageBytes"]);
        if (payload.implementation !== IMPLEMENTATION || payload.model !== "raveldex-bm25-v1" || payload.sameHost !== true || typeof payload.hasAddons !== "boolean")
          throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.sameHost" });
        const incomingConfiguration = object2(payload.configuration, ["schema", "limits", "analyzer"]);
        maximum = Math.min(hostMaximum, cap(payload.maxMessageBytes));
        const captured = captureConfiguration({ ...incomingConfiguration, ...payload.hasAddons || addons.length ? { addons } : {} });
        const manifests = (captured.capabilities?.ordered ?? []).map((registration) => registration.manifest);
        if (manifests.some((manifest) => !manifest.execution.worker || !manifest.execution.workerRegistration) || canonical(identity(captured)) !== canonical(payload.identity) || canonical(manifests) !== canonical(payload.manifests))
          throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.configuration" });
        const installed = initializeParticipants(captured);
        configuration = captured;
        owner = new ExecutionOwner(emptyRoot(captured, installed.states), directHost(), installed.participants);
        snapshots = snapshotFactory?.(owner);
        send(request, "result", { implementation: IMPLEMENTATION, model: "raveldex-bm25-v1", analyzer: captured.analyzer, identity: identity(captured), manifests, maxMessageBytes: maximum, receipts: RECEIPT_WINDOW });
        return;
      }
      if (!owner || !configuration)
        throw new WorkerAdapterError("STARTUP_FAILED");
      if (closing)
        throw new WorkerAdapterError("DISPOSED");
      if (operation === "reconcile" || operation === "snapshotReconcile") {
        object2(payload, ["operationId"]);
        if (typeof payload.operationId !== "string" || !payload.operationId.startsWith(`${session}:`) || !/^[1-9][0-9]*$/.test(payload.operationId.slice(session.length + 1)))
          fail2("transport.operationId");
        integer2(Number(payload.operationId.slice(session.length + 1)), lastId, 1);
        const domain = receiptDomains.get(payload.operationId);
        if (domain !== void 0 && domain !== (operation === "snapshotReconcile"))
          throw new WorkerAdapterError("INVALID_TRANSPORT", { path: "transport.receiptDomain" });
        send(request, "result", receipts.get(payload.operationId) ?? { operationId: payload.operationId, status: "expired" });
        return;
      }
      if (operation === "dispose") {
        object2(payload, []);
        closing = true;
        await owner.dispose();
        await Promise.all([...inflight].filter(([requestId]) => requestId !== id).map(([, promise]) => promise));
        send(request, "result", null);
        cleanup();
        return;
      }
      if ((operation === "snapshotExportSource" || operation === "snapshotRestore") && !snapshots)
        throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "snapshot.host" });
      if (active.size >= MAX_PENDING)
        throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.pending", limit: MAX_PENDING, actual: active.size + 1 });
      object2(payload, operation === "search" ? ["query", "options", "admittedAt"] : ["input", "options", "admittedAt"]);
      const requestOptions = object2(payload.options, operation === "search" ? ["deadlineMs", "limit", "offset", "extensions"] : ["deadlineMs"]);
      if (typeof payload.admittedAt !== "number" || !Number.isFinite(payload.admittedAt) || payload.admittedAt < 0)
        fail2("transport.admission");
      const controller = new AbortController();
      active.set(id, controller);
      const control = { signal: controller.signal, elapsedMs: Math.max(0, monotonicEpoch() - payload.admittedAt) };
      if (mutation(operation)) {
        trackedMutation = true;
        receiptDomains.set(operationId, operation === "snapshotRestore");
        record(Object.freeze({ operationId, status: "pending" }));
      }
      const result = operation === "snapshotExportSource" ? await snapshots.exportSource(requestOptions, control) : operation === "snapshotRestore" ? await snapshots.restore(payload.input, requestOptions, control) : operation === "search" ? await owner.searchControlled(payload.query, requestOptions, control) : await owner.mutateControlled(operation, payload.input, requestOptions, control);
      if (trackedMutation)
        record(Object.freeze({ operationId, status: "committed", result }));
      send(request, "result", result);
    } catch (error) {
      const failure2 = wireError(error);
      if (trackedMutation)
        record(Object.freeze({ operationId, status: "rejected", error: failure2 }));
      send(request, "error", failure2);
    } finally {
      active.delete(id);
    }
  }
  function receive(raw) {
    if (closing)
      return;
    let request;
    try {
      request = object2(captureMessage(raw, maximum), ["protocol", "session", "id", "operation", "payload"]);
      if (request.protocol !== PROTOCOL)
        fail2("transport.protocol");
      const incomingSession = sessionValue(request.session), id = integer2(request.id, Number.MAX_SAFE_INTEGER, 1);
      if (session !== void 0 && incomingSession !== session || id <= lastId)
        fail2("transport.identity");
      if (request.operation !== "cancel" && !OPERATIONS.includes(request.operation))
        fail2("transport.operation");
      if (session === void 0) {
        if (request.operation !== "init")
          throw new WorkerAdapterError("STARTUP_FAILED");
        session = incomingSession;
      }
      lastId = id;
      if (request.operation === "cancel") {
        const payload = object2(request.payload, ["targetId"]);
        active.get(integer2(payload.targetId, id - 1, 1))?.abort();
        return;
      }
      const running = execute(request);
      inflight.set(id, running);
      void running.finally(() => inflight.delete(id));
    } catch (error) {
      if (request && request.protocol === PROTOCOL && request.session === session && typeof request.id === "number" && Number.isSafeInteger(request.id) && request.id > lastId && OPERATIONS.includes(request.operation))
        send(request, "error", wireError(error));
    }
  }
  const message = (event) => receive(event.data);
  const failure = () => {
    void dispose();
  };
  function cleanup() {
    if (cleaned)
      return;
    cleaned = true;
    closing = true;
    for (const [type, listener] of [["message", message], ["messageerror", failure]]) {
      try {
        removeListener(type, listener);
      } catch {
      }
    }
    active.clear();
    receipts.clear();
    receiptDomains.clear();
    snapshots = void 0;
    owner = void 0;
    configuration = void 0;
    liveScopes.delete(scope);
  }
  function dispose() {
    if (disposal)
      return disposal;
    if (cleaned)
      return Promise.resolve();
    closing = true;
    disposal = (async () => {
      try {
        await owner?.dispose();
        await Promise.all([...inflight.values()]);
      } finally {
        cleanup();
      }
    })();
    return disposal;
  }
  try {
    addListener("message", message);
    addListener("messageerror", failure);
  } catch (error) {
    cleanup();
    throw error;
  }
  return Object.freeze({ dispose });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/worker/snapshots-host.js
function serveSnapshotRaveldexWorker(scope, options = {}) {
  return serveWorkerWithSnapshots(scope, options, (owner) => {
    const engine = facadeFromExecutionOwner(owner);
    return Object.freeze({
      exportSource: (options2, control) => controlledSnapshots(engine, {}, control).exportSource(options2),
      restore: (encoded2, options2, control) => controlledSnapshots(engine, {}, control).restore(encoded2, options2)
    });
  });
}

// message-observer.mjs
function observeMessages(native, realm) {
  if (!["main", "worker"].includes(realm)) throw Error("Unknown realm");
  const rows = [], listeners = /* @__PURE__ */ new Map();
  const post = native.postMessage.bind(native);
  const add = native.addEventListener.bind(native), remove = native.removeEventListener.bind(native);
  let sequence = 0, dropped = 0;
  function note(data, direction, edge, token2) {
    if (rows.length >= 1024) {
      dropped++;
      return;
    }
    rows.push({
      sequence: ++sequence,
      token: token2,
      realm,
      direction,
      edge,
      protocol: Number.isSafeInteger(data?.protocol) ? data.protocol : null,
      session: typeof data?.session === "string" ? data.session : null,
      id: Number.isSafeInteger(data?.id) ? data.id : null,
      operation: typeof data?.operation === "string" ? data.operation : null,
      kind: typeof data?.kind === "string" ? data.kind : null
    });
    performance.mark(`rx:message:${realm}:${direction}:${token2}:${edge}`);
  }
  let token = 0;
  const endpoint = {
    postMessage(...args) {
      const current = ++token;
      note(args[0], "send", "begin", current);
      try {
        return post(...args);
      } finally {
        note(args[0], "send", "end", current);
      }
    },
    addEventListener(type, listener, ...options) {
      if (type !== "message" || listener === null) return add(type, listener, ...options);
      if (options.length) throw Error("Only option-free adapter listeners are supported");
      let wrapped = listeners.get(listener);
      if (!wrapped) {
        wrapped = function(event) {
          const data = event.data, current = ++token;
          note(data, "read", "begin", current);
          try {
            return typeof listener === "function" ? listener.call(this, event) : listener.handleEvent(event);
          } finally {
            note(data, "read", "end", current);
          }
        };
        listeners.set(listener, wrapped);
      }
      return add(type, wrapped);
    },
    removeEventListener(type, listener, ...options) {
      const wrapped = type === "message" ? listeners.get(listener) : void 0;
      if (type === "message") listeners.delete(listener);
      return remove(type, wrapped ?? listener, ...options);
    },
    terminate() {
      return native.terminate?.();
    }
  };
  return { endpoint, snapshot: () => ({
    realm,
    dropped,
    messageListeners: listeners.size,
    rows: rows.map((row) => ({ ...row }))
  }) };
}

// message-worker.mjs
var observation = observeMessages(self, "worker");
globalThis.messageObservation = () => observation.snapshot();
serveSnapshotRaveldexWorker(observation.endpoint, {
  addons: [createSourceProvider({ fields: ["body"] }), createSourcePhrases({ fields: ["body"] })]
});
