// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/worker/snapshot-channel.js
var channels = /* @__PURE__ */ new WeakMap();
function bindSnapshotChannel(engine2, channel) {
  channels.set(engine2, channel);
}
function getSnapshotChannel(engine2) {
  return channels.get(engine2);
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/errors/error.js
var ERROR_CODES = Object.freeze([
  "INVALID_SCHEMA",
  "INVALID_RECORD",
  "INVALID_QUERY",
  "INVALID_OPTIONS",
  "ID_EXISTS",
  "ID_NOT_FOUND",
  "LIMIT_EXCEEDED",
  "QUEUE_FULL",
  "WORK_LIMIT_EXCEEDED",
  "DEADLINE_EXCEEDED",
  "CANCELLED",
  "DISPOSED",
  "MISSING_CAPABILITY",
  "INCOMPATIBLE_CAPABILITY",
  "REVISION_MISMATCH",
  "REVISION_EXHAUSTED",
  "RESOURCE_EXHAUSTED",
  "UNSUPPORTED_ENVIRONMENT",
  "INTERNAL_ERROR"
]);
var RaveldexError = class extends Error {
  code;
  details;
  constructor(code, details = {}) {
    super(`Raveldex: ${code}`);
    this.name = "RaveldexError";
    this.code = code;
    this.details = Object.freeze({
      ...details.path === void 0 ? {} : { path: details.path.slice(0, 256) },
      ...details.limit === void 0 ? {} : { limit: details.limit },
      ...details.actual === void 0 ? {} : { actual: details.actual }
    });
  }
};
function invalid(code, path) {
  throw new RaveldexError(code, { path });
}
function bound(actual, limit, path) {
  if (!Number.isSafeInteger(actual) || actual > limit) {
    throw new RaveldexError("LIMIT_EXCEEDED", { path, limit, actual });
  }
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/data.js
var Admission = class {
  maximum;
  entries = 0;
  constructor(maximum) {
    this.maximum = maximum;
  }
  get count() {
    return this.entries;
  }
  charge(count, path) {
    this.entries += count;
    bound(this.entries, this.maximum, path);
  }
};
function ownObject(input, code, path, admission) {
  if (typeof input !== "object" || input === null)
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Object.prototype)
    invalid(code, path);
  const keys = Reflect.ownKeys(input);
  admission.charge(keys.length, path);
  const copy = /* @__PURE__ */ Object.create(null);
  for (const key of keys) {
    if (typeof key !== "string")
      invalid(code, path);
    const descriptor = Object.getOwnPropertyDescriptor(input, key);
    if (!descriptor || !("value" in descriptor))
      invalid(code, path);
    copy[key] = descriptor.value;
  }
  return copy;
}
function ownArray(input, maximum, code, path, admission) {
  if (!Array.isArray(input))
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Array.prototype)
    invalid(code, path);
  bound(input.length, maximum, path);
  const keys = Reflect.ownKeys(input);
  admission.charge(keys.length, path);
  if (keys.length !== input.length + 1)
    invalid(code, path);
  for (const key of keys) {
    if (key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= input.length)) {
      invalid(code, path);
    }
  }
  const copy = [];
  for (let i = 0; i < input.length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(input, String(i));
    if (!descriptor || !("value" in descriptor))
      invalid(code, `${path}[${i}]`);
    copy.push(descriptor.value);
  }
  return copy;
}
function keysOnly(data, allowed, code, path) {
  for (const key of Object.keys(data))
    if (!allowed.includes(key))
      invalid(code, path);
}
function has(data, key) {
  return Object.prototype.hasOwnProperty.call(data, key);
}
function stringValue(input, maximum, code, path) {
  if (typeof input !== "string")
    invalid(code, path);
  bound(input.length, maximum, path);
  return input;
}
function* scanUnicode(value, code, path) {
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, path);
    i += width;
    yield { workUnits: 1 };
  }
}
function codePointWidth(value, index, code, path) {
  const first = value.charCodeAt(index);
  if (first >= 55296 && first <= 56319) {
    const second = value.charCodeAt(index + 1);
    if (!(second >= 56320 && second <= 57343))
      invalid(code, path);
    return 2;
  }
  if (first >= 56320 && first <= 57343)
    invalid(code, path);
  return 1;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/limits/limits.js
var DEFAULT_LIMITS = Object.freeze({
  maxDocuments: 1e4,
  maxTextFields: 32,
  maxMetadataFields: 32,
  maxFieldNameCodeUnits: 64,
  maxIdCodeUnits: 256,
  maxTextValuesPerField: 64,
  maxMetadataValuesPerField: 128,
  maxMetadataStringCodeUnits: 1024,
  maxMetadataCodeUnitsPerRecord: 32768,
  maxTextCodeUnitsPerValue: 65536,
  maxTextCodeUnitsPerRecord: 262144,
  maxCorpusTextCodeUnits: 67108864,
  maxRawTokenCodeUnits: 256,
  maxTermCodeUnits: 256,
  maxTokensPerRecord: 32768,
  maxCorpusTokens: 4e6,
  maxDictionaryEntries: 25e4,
  maxPostingEntries: 2e6,
  maxMutationBatch: 256,
  maxAdmissionEntries: 16384,
  maxQueryNodes: 128,
  maxQueryDepth: 16,
  maxQueryLexicalCodeUnits: 2048,
  maxQueryCodeUnits: 16384,
  maxQueryTokens: 64,
  maxQueryGroups: 64,
  maxVariantsPerGroup: 16,
  maxExpansionsPerGroup: 256,
  maxQueryExpansions: 1024,
  minPrefixCodePoints: 2,
  maxHits: 100,
  maxQueuedOperations: 32,
  maxSearchWorkUnits: 1e7,
  maxMutationWorkUnits: 5e7,
  checkpointWorkUnits: 2048,
  maxDeadlineMs: 6e4
});
function resolveLimits(input = {}, admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries)) {
  const data = ownObject(input, "INVALID_OPTIONS", "limits", admission);
  const result2 = { ...DEFAULT_LIMITS };
  for (const key of Object.keys(data)) {
    if (!has(DEFAULT_LIMITS, key))
      invalid("INVALID_OPTIONS", "limits");
    const name = key;
    const value = data[key];
    const minimum = name === "maxMetadataFields" || name === "maxQueuedOperations" ? 0 : name === "minPrefixCodePoints" ? 2 : 1;
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid("INVALID_OPTIONS", `limits.${name}`);
    if (name !== "minPrefixCodePoints")
      bound(value, DEFAULT_LIMITS[name], `limits.${name}`);
    result2[name] = value;
  }
  if (result2.checkpointWorkUnits > Math.min(result2.maxSearchWorkUnits, result2.maxMutationWorkUnits)) {
    invalid("INVALID_OPTIONS", "limits.checkpointWorkUnits");
  }
  return Object.freeze(result2);
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/analyzer/basic.js
var BASIC_ANALYZER = Object.freeze({ id: "basic-v1", environmentProfile: "unqualified" });
var START = /[\p{L}\p{N}]/u;
var CONTINUE = /[\p{L}\p{N}\p{M}]/u;
function* analyzeValue(value, valueIndex = 0, limits = DEFAULT_LIMITS, code = "INVALID_RECORD") {
  bound(value.length, limits.maxTextCodeUnitsPerValue, "analysis.value");
  let start = -1;
  let position = 0;
  function emit(end) {
    const raw = value.slice(start, end);
    const term = raw.normalize("NFKC").toLowerCase();
    bound(term.length, limits.maxTermCodeUnits, "analysis.term");
    const token = Object.freeze({ term, valueIndex, position: position++, start, end });
    start = -1;
    return { workUnits: raw.length + term.length, token };
  }
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, "analysis.value");
    const point = value.slice(i, i + width);
    if (start >= 0 && !CONTINUE.test(point))
      yield emit(i);
    if (start < 0 && START.test(point))
      start = i;
    i += width;
    if (start >= 0)
      bound(i - start, limits.maxRawTokenCodeUnits, "analysis.rawToken");
    yield { workUnits: 1 };
  }
  if (start >= 0)
    yield emit(value.length);
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/capabilities/registration.js
function captureRegistrations(input, context) {
  const { schema: schema2, limits, admission } = context, code = "INCOMPATIBLE_CAPABILITY";
  const entries = ownArray(input, 32, code, "addons", admission);
  const registrations = /* @__PURE__ */ new Map();
  const providers = /* @__PURE__ */ Object.create(null);
  const object2 = (value, path, keys) => {
    const data = ownObject(value, code, path, admission);
    keysOnly(data, keys, code, path);
    return data;
  };
  const string = (value, path, maximum = 128) => {
    const result2 = stringValue(value, maximum, code, path);
    if (!result2.length)
      invalid(code, path);
    for (const step of scanUnicode(result2, code, path)) {
      void step;
    }
    return result2;
  };
  const id = (value, path) => {
    const result2 = string(value, path);
    if (!/^[A-Za-z][A-Za-z0-9:._-]*$/.test(result2))
      invalid(code, path);
    return result2;
  };
  const integer3 = (value, path, minimum = 0) => {
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid(code, path);
    return value;
  };
  const flag = (value, path) => {
    if (typeof value !== "boolean")
      invalid(code, path);
    return value;
  };
  const references = (value, path) => {
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(ownArray(value, 64, code, path, admission).map((value2) => {
      const ref = object2(value2, path, ["id", "contractVersion"]), name = id(ref.id, path);
      if (ref.contractVersion !== 1 || seen.has(name))
        invalid(code, path);
      seen.add(name);
      return Object.freeze({ id: name, contractVersion: 1 });
    }));
  };
  for (const entry of entries) {
    const data = object2(entry, "addons.registration", ["manifest", "participant", "refinement", "predicate", "aggregation", "evidence"]);
    const raw = object2(data.manifest, "addons.manifest", ["id", "version", "contractVersion", "roles", "provides", "requires", "dataRequirements", "indexEffect", "rebuildPolicy", "execution", "limits", "costs", "codec"]);
    const name = id(raw.id, "addons.id"), version = string(raw.version, "addons.version");
    const semanticVersion = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/;
    if (!semanticVersion.test(version) || raw.contractVersion !== 1 || registrations.has(name))
      invalid(code, "addons.identity");
    const roles = ownArray(raw.roles, 4, code, "addons.roles", admission);
    if (!roles.length || new Set(roles).size !== roles.length || roles.some((role) => role !== "leaf-refinement" && role !== "transaction-participant" && role !== "aggregation" && role !== "evidence"))
      invalid(code, "addons.roles");
    const requirements = object2(raw.dataRequirements, "addons.dataRequirements", ["fields", "source", "positions", "offsets", "metadata"]);
    const metadata = flag(requirements.metadata, "addons.metadata");
    const fields = ownArray(requirements.fields, metadata ? limits.maxMetadataFields : limits.maxTextFields, code, "addons.fields", admission).map((field) => {
      const name2 = id(field, "addons.fields");
      if (!has(metadata ? schema2.metadata : schema2.text, name2))
        invalid(code, "addons.fields");
      return name2;
    });
    if (new Set(fields).size !== fields.length)
      invalid(code, "addons.fields");
    const execution = object2(raw.execution, "addons.execution", ["direct", "worker", "workerRegistration"]);
    if (execution.direct !== true || typeof execution.worker !== "boolean" || execution.worker !== has(execution, "workerRegistration"))
      invalid(code, "addons.execution");
    const workerRegistration = execution.worker ? string(execution.workerRegistration, "addons.workerRegistration", 8192) : void 0;
    const caps = object2(raw.limits, "addons.limits", ["maxPayloadCodeUnits", "maxWorkUnits", "maxRetainedEntries", "maxOutputEntries"]);
    const ownedLimits = Object.freeze({ maxPayloadCodeUnits: integer3(caps.maxPayloadCodeUnits, "addons.limits", 1), maxWorkUnits: integer3(caps.maxWorkUnits, "addons.limits", 1), maxRetainedEntries: integer3(caps.maxRetainedEntries, "addons.limits"), maxOutputEntries: integer3(caps.maxOutputEntries, "addons.limits") });
    if (ownedLimits.maxPayloadCodeUnits > DEFAULT_LIMITS.maxQueryCodeUnits || ownedLimits.maxWorkUnits > Math.max(DEFAULT_LIMITS.maxSearchWorkUnits, DEFAULT_LIMITS.maxMutationWorkUnits))
      invalid(code, "addons.limits");
    const costs = object2(raw.costs, "addons.costs", ["importedCode", "retainedRepresentation", "transientWork", "externalResources"]);
    if (costs.externalResources !== "none" || raw.rebuildPolicy !== "new-index")
      invalid(code, "addons.costs");
    const participantRole = roles.includes("transaction-participant"), refinementRole = roles.includes("leaf-refinement"), aggregationRole = roles.includes("aggregation"), evidenceRole = roles.includes("evidence");
    if (participantRole !== has(data, "participant") || refinementRole !== (has(data, "refinement") || has(data, "predicate")) || has(data, "refinement") && has(data, "predicate") || aggregationRole !== has(data, "aggregation") || evidenceRole !== has(data, "evidence") || raw.indexEffect !== (participantRole ? "transactional" : "none"))
      invalid(code, "addons.roles");
    if ((has(data, "predicate") || aggregationRole) && (!metadata || participantRole || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.dataRequirements");
    if (evidenceRole && (participantRole || metadata || requirements.offsets === true && requirements.positions !== true))
      invalid(code, "addons.dataRequirements");
    const implementations = {};
    for (const key of ["participant", "refinement", "predicate", "aggregation", "evidence"]) {
      if (!has(data, key))
        continue;
      const methods = key === "participant" ? ["initialize", "prepare"] : key === "refinement" ? ["prepare"] : key === "evidence" ? ["capture", "select", "prepare"] : ["capture", "prepare"];
      const attributes = key === "refinement" ? ["kind", "maxTokens"] : key === "aggregation" ? ["fieldType"] : [];
      const handles = object2(data[key], `addons.${key}`, [...methods, ...attributes]);
      for (const method of methods) {
        const callback = handles[method];
        if (typeof callback !== "function")
          invalid(code, `addons.${key}`);
        handles[method] = callback.bind(data[key]);
      }
      if (key === "refinement" && (handles.kind !== "exact-token-sequence" || integer3(handles.maxTokens, "addons.maxTokens", 1) > DEFAULT_LIMITS.maxQueryTokens))
        invalid(code, "addons.refinement");
      if (key === "aggregation" && (handles.fieldType !== "string" || fields.some((field) => schema2.metadata[field]?.type !== handles.fieldType)))
        invalid(code, "addons.aggregation");
      implementations[key] = Object.freeze(handles);
    }
    let codec;
    if (has(raw, "codec")) {
      const value = object2(raw.codec, "addons.codec", ["id", "version"]);
      codec = Object.freeze({ id: id(value.id, "addons.codec"), version: integer3(value.version, "addons.codec", 1) });
    }
    const manifest = Object.freeze({
      id: name,
      version,
      contractVersion: 1,
      roles: Object.freeze(roles),
      provides: references(raw.provides, "addons.provides"),
      requires: references(raw.requires, "addons.requires"),
      dataRequirements: Object.freeze({ fields: Object.freeze(fields.sort()), source: flag(requirements.source, "addons.source"), positions: flag(requirements.positions, "addons.positions"), offsets: flag(requirements.offsets, "addons.offsets"), metadata }),
      indexEffect: participantRole ? "transactional" : "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: execution.worker, ...workerRegistration ? { workerRegistration } : {} }),
      limits: ownedLimits,
      costs: Object.freeze({ importedCode: string(costs.importedCode, "addons.costs", 1024), retainedRepresentation: string(costs.retainedRepresentation, "addons.costs", 1024), transientWork: string(costs.transientWork, "addons.costs", 1024), externalResources: "none" }),
      ...codec ? { codec } : {}
    });
    const captured = Object.freeze({ manifest, ...implementations });
    registrations.set(name, captured);
    if (!manifest.provides.length)
      invalid(code, "addons.provides");
    for (const provided of manifest.provides) {
      if (has(providers, provided.id))
        invalid(code, "addons.providers");
      providers[provided.id] = captured;
    }
  }
  const ordered = [], visited = /* @__PURE__ */ new Set(), active = /* @__PURE__ */ new Set();
  function visit(registration) {
    const { manifest } = registration;
    if (visited.has(manifest.id))
      return;
    if (active.has(manifest.id))
      invalid(code, "addons.cycle");
    active.add(manifest.id);
    for (const requirement of [...manifest.requires].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0)) {
      const provider = providers[requirement.id];
      if (!provider)
        invalid("MISSING_CAPABILITY", "addons.requires");
      visit(provider);
    }
    const data = manifest.dataRequirements;
    if ((data.source || data.positions) && registration.refinement)
      for (const field of data.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field}`) && !!providers[`${kind}:${field}`]?.participant;
        if (!(data.source && present("source") || data.positions && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    if (registration.evidence && (data.source || data.positions || data.offsets))
      for (const field of data.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field}`) && !!providers[`${kind}:${field}`]?.participant;
        if (!(data.source && present("source") || data.offsets && present("offsets") || data.positions && !data.offsets && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    active.delete(manifest.id);
    visited.add(manifest.id);
    ordered.push(registration);
  }
  for (const name of [...registrations.keys()].sort())
    visit(registrations.get(name));
  return Object.freeze({ ordered: Object.freeze(ordered), providers: Object.freeze(providers) });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/schema.js
function captureSchema(input, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const schema2 = ownObject(input, "INVALID_SCHEMA", "schema", admission);
  keysOnly(schema2, ["text", "metadata"], "INVALID_SCHEMA", "schema");
  const text = ownObject(schema2.text, "INVALID_SCHEMA", "schema.text", admission);
  const metadata = has(schema2, "metadata") ? ownObject(schema2.metadata, "INVALID_SCHEMA", "schema.metadata", admission) : /* @__PURE__ */ Object.create(null);
  const textNames = Object.keys(text);
  const metadataNames = Object.keys(metadata);
  if (textNames.length === 0)
    invalid("INVALID_SCHEMA", "schema.text");
  bound(textNames.length, limits.maxTextFields, "schema.text");
  bound(metadataNames.length, limits.maxMetadataFields, "schema.metadata");
  const ownedText = /* @__PURE__ */ Object.create(null);
  const ownedMetadata = /* @__PURE__ */ Object.create(null);
  for (const [group, names] of [[text, textNames], [metadata, metadataNames]]) {
    for (const name of names) {
      if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(name) || name === "constructor" || name === "prototype")
        invalid("INVALID_SCHEMA", "schema.fields");
      bound(name.length, limits.maxFieldNameCodeUnits, "schema.fields");
      if (has(text, name) && has(metadata, name))
        invalid("INVALID_SCHEMA", "schema.fields");
      const path = `schema.${group === text ? "text" : "metadata"}.${name}`;
      const field = ownObject(group[name], "INVALID_SCHEMA", path, admission);
      if (group === text) {
        keysOnly(field, ["boost"], "INVALID_SCHEMA", path);
        const boost = has(field, "boost") ? field.boost : 1;
        if (typeof boost !== "number" || !Number.isFinite(boost) || boost <= 0 || boost > 16)
          invalid("INVALID_SCHEMA", `${path}.boost`);
        ownedText[name] = Object.freeze({ boost });
      } else {
        keysOnly(field, ["type", "multi", "nullable"], "INVALID_SCHEMA", path);
        if (field.type !== "string" && field.type !== "number" && field.type !== "boolean")
          invalid("INVALID_SCHEMA", `${path}.type`);
        const multi = has(field, "multi") ? field.multi : false;
        const nullable = has(field, "nullable") ? field.nullable : false;
        if (typeof multi !== "boolean" || typeof nullable !== "boolean")
          invalid("INVALID_SCHEMA", path);
        ownedMetadata[name] = Object.freeze({ type: field.type, multi, nullable });
      }
    }
  }
  return Object.freeze({ text: Object.freeze(ownedText), metadata: Object.freeze(ownedMetadata) });
}
function captureConfiguration(input) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const config = ownObject(input, "INVALID_OPTIONS", "config", admission);
  keysOnly(config, ["schema", "limits", "analyzer", "addons"], "INVALID_OPTIONS", "config");
  if (has(config, "limits") && config.limits === void 0)
    invalid("INVALID_OPTIONS", "config.limits");
  const limits = has(config, "limits") ? resolveLimits(config.limits, admission) : DEFAULT_LIMITS;
  const schema2 = captureSchema(config.schema, limits, admission);
  if (has(config, "analyzer")) {
    const analyzer = ownObject(config.analyzer, "INVALID_OPTIONS", "config.analyzer", admission);
    keysOnly(analyzer, ["id", "environmentProfile"], "INVALID_OPTIONS", "config.analyzer");
    if (typeof analyzer.id !== "string" || typeof analyzer.environmentProfile !== "string")
      invalid("INVALID_OPTIONS", "config.analyzer");
    if (analyzer.id !== BASIC_ANALYZER.id)
      invalid("MISSING_CAPABILITY", "config.analyzer");
    if (analyzer.environmentProfile !== BASIC_ANALYZER.environmentProfile)
      invalid("INCOMPATIBLE_CAPABILITY", "config.analyzer");
  }
  const capabilities = has(config, "addons") ? captureRegistrations(config.addons, { schema: schema2, limits, admission }) : void 0;
  bound(admission.count, limits.maxAdmissionEntries, "config");
  return Object.freeze({ schema: schema2, limits, analyzer: BASIC_ANALYZER, ...capabilities?.ordered.length ? { capabilities } : {} });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/capabilities/capture.js
function captureExtension(capture, input, admission, limits, maximum) {
  const maxCodeUnits = Math.min(maximum, limits.maxQueryCodeUnits);
  const captured = capture(input, Object.freeze({ admission, limits, maxCodeUnits }));
  if (!captured || !Number.isSafeInteger(captured.codeUnits) || captured.codeUnits < 0 || captured.value !== null && typeof captured.value === "object" && !Object.isFrozen(captured.value))
    invalid("INCOMPATIBLE_CAPABILITY", "extensions.capture");
  bound(captured.codeUnits, maxCodeUnits, "extensions.payload");
  return captured;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/options.js
function integer(value, minimum, maximum, path) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
    invalid("INVALID_OPTIONS", path);
  bound(value, maximum, path);
  return value;
}
function captureOptions(input = {}, limits, search, admission = new Admission(limits.maxAdmissionEntries), capabilities) {
  const data = ownObject(input, "INVALID_OPTIONS", "options", admission);
  keysOnly(data, search ? ["signal", "deadlineMs", "limit", "offset", "extensions"] : ["signal", "deadlineMs"], "INVALID_OPTIONS", "options");
  const deadlineMs2 = has(data, "deadlineMs") ? integer(data.deadlineMs, 1, limits.maxDeadlineMs, "options.deadlineMs") : Math.min(3e4, limits.maxDeadlineMs);
  let signal;
  if (has(data, "signal")) {
    const candidate = data.signal;
    if (typeof candidate !== "object" || candidate === null || typeof candidate.aborted !== "boolean" || typeof candidate.addEventListener !== "function" || typeof candidate.removeEventListener !== "function")
      invalid("INVALID_OPTIONS", "options.signal");
    signal = candidate;
  }
  const base = { deadlineMs: deadlineMs2, ...signal ? { signal } : {} };
  if (!search)
    return Object.freeze(base);
  const offset = has(data, "offset") ? integer(data.offset, 0, limits.maxDocuments, "options.offset") : 0;
  const limit = has(data, "limit") ? integer(data.limit, 0, limits.maxHits, "options.limit") : Math.min(20, limits.maxHits, limits.maxDocuments - offset);
  bound(offset + limit, limits.maxDocuments, "options.page");
  let extensions;
  if (has(data, "extensions")) {
    const captured = ownObject(data.extensions, "INVALID_OPTIONS", "options.extensions", admission);
    let units = 0;
    for (const capability of Object.keys(captured)) {
      const registration = capabilities?.providers[capability];
      const handler = registration?.evidence ?? registration?.aggregation;
      if (!registration || !handler)
        invalid("MISSING_CAPABILITY", "options.extensions");
      const payload = captureExtension(handler.capture, captured[capability], admission, limits, registration.manifest.limits.maxPayloadCodeUnits);
      units += capability.length + payload.codeUnits;
      bound(units, limits.maxQueryCodeUnits, "options.extensions");
      captured[capability] = payload.value;
    }
    if (Object.keys(captured).length)
      extensions = Object.freeze(captured);
  }
  return Object.freeze({ ...base, offset, limit, ...extensions ? { extensions } : {} });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/record.js
function captureId(input, limits, code, path) {
  const id = stringValue(input, limits.maxIdCodeUnits, code, path);
  if (!id.length)
    invalid(code, path);
  return id;
}
function captureScalar(input, field, limits, code, path) {
  if (input === null && field.nullable)
    return null;
  if (typeof input !== field.type)
    invalid(code, path);
  if (typeof input === "number") {
    if (!Number.isFinite(input))
      invalid(code, path);
    return input === 0 ? 0 : input;
  }
  if (typeof input === "string")
    return stringValue(input, limits.maxMetadataStringCodeUnits, code, path);
  if (typeof input === "boolean")
    return input;
  return invalid(code, path);
}
function captureRecord(input, schema2, limits, admission = new Admission(limits.maxAdmissionEntries), path = "record") {
  const record = ownObject(input, "INVALID_RECORD", path, admission);
  keysOnly(record, ["id", "text", "metadata"], "INVALID_RECORD", path);
  const id = captureId(record.id, limits, "INVALID_RECORD", `${path}.id`);
  const textInput = ownObject(record.text, "INVALID_RECORD", `${path}.text`, admission);
  const metadataInput = has(record, "metadata") ? ownObject(record.metadata, "INVALID_RECORD", `${path}.metadata`, admission) : /* @__PURE__ */ Object.create(null);
  const text = /* @__PURE__ */ Object.create(null);
  const metadata = /* @__PURE__ */ Object.create(null);
  let textCodeUnits = 0;
  let metadataCodeUnits = 0;
  for (const name of Object.keys(textInput)) {
    if (!has(schema2.text, name))
      invalid("INVALID_RECORD", `${path}.text`);
    const fieldPath = `${path}.text.${name}`;
    const raw = textInput[name];
    const values = typeof raw === "string" ? [raw] : ownArray(raw, limits.maxTextValuesPerField, "INVALID_RECORD", fieldPath, admission);
    text[name] = Object.freeze(values.map((value, i) => {
      const string = stringValue(value, limits.maxTextCodeUnitsPerValue, "INVALID_RECORD", `${fieldPath}[${i}]`);
      textCodeUnits += string.length;
      bound(textCodeUnits, limits.maxTextCodeUnitsPerRecord, `${path}.text`);
      return string;
    }));
  }
  for (const name of Object.keys(metadataInput)) {
    const field = schema2.metadata[name];
    if (!field)
      invalid("INVALID_RECORD", `${path}.metadata`);
    const fieldPath = `${path}.metadata.${name}`;
    const value = metadataInput[name];
    const values = field.multi ? ownArray(value, limits.maxMetadataValuesPerField, "INVALID_RECORD", fieldPath, admission) : [value];
    const owned = values.map((item, i) => {
      const scalar = captureScalar(item, field, limits, "INVALID_RECORD", `${fieldPath}[${i}]`);
      if (typeof scalar === "string")
        metadataCodeUnits += scalar.length;
      bound(metadataCodeUnits, limits.maxMetadataCodeUnitsPerRecord, `${path}.metadata`);
      return scalar;
    });
    metadata[name] = field.multi ? Object.freeze(owned) : owned[0];
  }
  return Object.freeze({ id, text: Object.freeze(text), metadata: Object.freeze(metadata), textCodeUnits });
}
function captureBatch(input, schema2, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const values = ownArray(input, limits.maxMutationBatch, "INVALID_RECORD", "records", admission);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const record = captureRecord(value, schema2, limits, admission, `records[${i}]`);
    if (ids.has(record.id))
      invalid("INVALID_RECORD", `records[${i}].id`);
    ids.add(record.id);
    return record;
  }));
}
function captureRemoveIds(input, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const values = typeof input === "string" ? [input] : ownArray(input, limits.maxMutationBatch, "INVALID_OPTIONS", "ids", admission);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const id = captureId(value, limits, "INVALID_OPTIONS", `ids[${i}]`);
    if (ids.has(id))
      invalid("INVALID_OPTIONS", `ids[${i}]`);
    ids.add(id);
    return id;
  }));
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/contracts/query.js
function captureQuery(input, schema2, limits, admission = new Admission(limits.maxAdmissionEntries), capabilities) {
  let nodes = 0;
  let lexicalUnits = 0;
  let stringUnits = 0;
  const ancestors = /* @__PURE__ */ new Set();
  function string(value, lexical, path) {
    const text = stringValue(value, limits.maxQueryCodeUnits, "INVALID_QUERY", path);
    stringUnits += text.length;
    bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
    if (lexical) {
      lexicalUnits += text.length;
      bound(lexicalUnits, limits.maxQueryLexicalCodeUnits, "query.lexical");
    }
    return text;
  }
  function fields(value, path) {
    const names = ownArray(value, limits.maxTextFields, "INVALID_QUERY", path, admission);
    if (!names.length)
      invalid("INVALID_QUERY", path);
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(names.map((name) => {
      const selected = string(name, false, path);
      if (!has(schema2.text, selected) || seen.has(selected))
        invalid("INVALID_QUERY", path);
      seen.add(selected);
      return selected;
    }));
  }
  function node(value, depth, path) {
    bound(++nodes, limits.maxQueryNodes, "query.nodes");
    bound(depth, limits.maxQueryDepth, "query.depth");
    const data = ownObject(value, "INVALID_QUERY", path, admission);
    if (ancestors.has(value))
      invalid("INVALID_QUERY", path);
    ancestors.add(value);
    const kind = string(data.kind, false, `${path}.kind`);
    let result2;
    switch (kind) {
      case "text": {
        keysOnly(data, ["kind", "text", "operator", "fields"], "INVALID_QUERY", path);
        const operator = has(data, "operator") ? string(data.operator, false, `${path}.operator`) : "and";
        if (operator !== "and" && operator !== "or")
          invalid("INVALID_QUERY", `${path}.operator`);
        result2 = {
          kind,
          text: string(data.text, true, `${path}.text`),
          operator,
          ...has(data, "fields") ? { fields: fields(data.fields, `${path}.fields`) } : {}
        };
        break;
      }
      case "group": {
        keysOnly(data, ["kind", "variants", "fields"], "INVALID_QUERY", path);
        const variants = ownArray(data.variants, limits.maxVariantsPerGroup, "INVALID_QUERY", `${path}.variants`, admission);
        if (!variants.length)
          invalid("INVALID_QUERY", `${path}.variants`);
        const owned = variants.map((variant, i) => {
          const variantPath = `${path}.variants[${i}]`;
          const item = ownObject(variant, "INVALID_QUERY", variantPath, admission);
          keysOnly(item, ["text", "match", "weight"], "INVALID_QUERY", variantPath);
          const match = string(item.match, false, `${variantPath}.match`);
          if (match !== "exact" && match !== "prefix")
            invalid("INVALID_QUERY", `${variantPath}.match`);
          const weight = has(item, "weight") ? item.weight : 1;
          if (typeof weight !== "number" || !Number.isFinite(weight) || weight <= 0 || weight > 1)
            invalid("INVALID_QUERY", `${variantPath}.weight`);
          return Object.freeze({ text: string(item.text, true, `${variantPath}.text`), match, weight });
        });
        result2 = { kind, variants: Object.freeze(owned), ...has(data, "fields") ? { fields: fields(data.fields, `${path}.fields`) } : {} };
        break;
      }
      case "and":
      case "or": {
        keysOnly(data, ["kind", "children"], "INVALID_QUERY", path);
        const children = ownArray(data.children, limits.maxQueryNodes, "INVALID_QUERY", `${path}.children`, admission);
        if (!children.length)
          invalid("INVALID_QUERY", `${path}.children`);
        result2 = { kind, children: Object.freeze(children.map((child, i) => node(child, depth + 1, `${path}.children[${i}]`))) };
        break;
      }
      case "not":
        keysOnly(data, ["kind", "child"], "INVALID_QUERY", path);
        result2 = { kind, child: node(data.child, depth + 1, `${path}.child`) };
        break;
      case "eq": {
        keysOnly(data, ["kind", "field", "value"], "INVALID_QUERY", path);
        const name = string(data.field, false, `${path}.field`);
        const field = schema2.metadata[name];
        if (!field)
          invalid("INVALID_QUERY", `${path}.field`);
        const scalar = captureScalar(data.value, field, limits, "INVALID_QUERY", `${path}.value`);
        if (typeof scalar === "string")
          string(scalar, false, `${path}.value`);
        result2 = { kind, field: name, value: scalar };
        break;
      }
      case "all":
      case "none":
        keysOnly(data, ["kind"], "INVALID_QUERY", path);
        result2 = { kind };
        break;
      case "extension": {
        keysOnly(data, ["kind", "capability", "version", "payload"], "INVALID_QUERY", path);
        if (typeof data.capability !== "string" || !data.capability.length || !Number.isSafeInteger(data.version) || data.version < 1 || !has(data, "payload"))
          invalid("INVALID_QUERY", path);
        const capability = string(data.capability, false, `${path}.capability`);
        const registration = capabilities?.providers[capability];
        if (!registration?.refinement && !registration?.predicate)
          invalid("MISSING_CAPABILITY", path);
        if (data.version !== 1)
          invalid("INCOMPATIBLE_CAPABILITY", `${path}.version`);
        if (registration.predicate) {
          const captured = captureExtension(registration.predicate.capture, data.payload, admission, limits, registration.manifest.limits.maxPayloadCodeUnits);
          stringUnits += captured.codeUnits;
          bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
          result2 = { kind: "predicate", capability, payload: captured.value };
          break;
        }
        const payload = ownObject(data.payload, "INVALID_QUERY", `${path}.payload`, admission);
        keysOnly(payload, ["text", "fields"], "INVALID_QUERY", `${path}.payload`);
        const text = string(payload.text, true, `${path}.payload.text`);
        const selected = has(payload, "fields") ? fields(payload.fields, `${path}.payload.fields`) : void 0;
        bound(text.length + (selected?.reduce((sum, field) => sum + field.length, 0) ?? 0), registration.manifest.limits.maxPayloadCodeUnits, `${path}.payload`);
        result2 = { kind, capability, version: 1, payload: Object.freeze({ text, ...selected ? { fields: selected } : {} }) };
        break;
      }
      default:
        return invalid("INVALID_QUERY", path);
    }
    ancestors.delete(value);
    return Object.freeze(result2);
  }
  if (typeof input === "string") {
    bound(1, limits.maxQueryNodes, "query.nodes");
    bound(1, limits.maxQueryDepth, "query.depth");
    return Object.freeze({ kind: "text", text: string(input, true, "query"), operator: "and" });
  }
  return node(input, 1, "query");
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/mutations/capture.js
function captureMutation(configuration, kind, input, options) {
  const { schema: schema2, limits } = configuration, admission = new Admission(limits.maxAdmissionEntries);
  const capturedOptions = captureOptions(options, limits, false, admission);
  if (capturedOptions.signal?.aborted)
    invalid("CANCELLED", "options.signal");
  let records = [], ids = [];
  switch (kind) {
    case "add":
    case "replace":
      records = Object.freeze([captureRecord(input, schema2, limits, admission)]);
      break;
    case "addMany":
      records = captureBatch(input, schema2, limits, admission);
      break;
    case "remove":
      ids = captureRemoveIds(input, limits, admission);
      break;
    case "clear":
      if (input !== void 0)
        invalid("INVALID_OPTIONS", "clear");
      break;
    default:
      invalid("INVALID_OPTIONS", "mutation.kind");
  }
  return Object.freeze({ kind, records: Object.freeze(records), ids: Object.freeze(ids), options: capturedOptions });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/worker/error.js
var WORKER_ERROR_CODES = Object.freeze([
  "INVALID_TRANSPORT",
  "TRANSPORT_LIMIT",
  "INCOMPATIBLE_WORKER",
  "TIMEOUT",
  "TERMINATED",
  "STARTUP_FAILED",
  "OUTCOME_UNKNOWN",
  "DISPOSED"
]);
var WorkerAdapterError = class extends Error {
  code;
  details;
  operationId;
  constructor(code, details = {}) {
    super(`Raveldex worker: ${code}`);
    this.name = "WorkerAdapterError";
    this.code = code;
    this.operationId = details.operationId;
    this.details = Object.freeze({ ...details });
  }
};

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/worker/protocol.js
var PROTOCOL = 1;
var IMPLEMENTATION = "raveldex-native-v1";
var MAX_MESSAGE_BYTES = 8 * 1024 * 1024;
var MAX_PENDING = 64;
var MAX_NODES = 131072;
var MAX_DEPTH = 64;
var MAX_ARRAY = 65536;
var OPERATIONS = Object.freeze(["init", "search", "add", "addMany", "replace", "remove", "clear", "reconcile", "dispose", "snapshotExportSource", "snapshotRestore", "snapshotReconcile"]);
var mutation = (operation) => ["add", "addMany", "replace", "remove", "clear", "snapshotRestore"].includes(operation);
function monotonicEpoch() {
  const origin = performance.timeOrigin, now = performance.now();
  if (!Number.isFinite(origin) || !Number.isFinite(now))
    throw new WorkerAdapterError("STARTUP_FAILED", { path: "worker.clock" });
  return origin + now;
}
function fail(path = "transport") {
  throw new WorkerAdapterError("INVALID_TRANSPORT", { path });
}
function object(value, allowed) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    fail();
  const data = value;
  if (allowed && Object.keys(data).some((key) => !allowed.includes(key)))
    fail();
  return data;
}
function integer2(value, maximum = Number.MAX_SAFE_INTEGER, minimum = 0) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum)
    fail();
  return value;
}
function cap(value = MAX_MESSAGE_BYTES) {
  return integer2(value, MAX_MESSAGE_BYTES, 1024);
}
function sessionValue(value) {
  if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value))
    fail("transport.session");
  return value;
}
function captureMessage(input, maximum) {
  let bytes = 0, nodes = 0;
  const active = /* @__PURE__ */ new Set();
  const charge = (amount) => {
    bytes += amount;
    if (bytes > maximum)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.bytes", limit: maximum, actual: bytes });
  };
  function string(value) {
    charge(2);
    for (let i = 0; i < value.length; i++) {
      const point = value.charCodeAt(i);
      if (point === 34 || point === 92 || point === 8 || point === 9 || point === 10 || point === 12 || point === 13)
        charge(2);
      else if (point < 32)
        charge(6);
      else if (point < 128)
        charge(1);
      else if (point < 2048)
        charge(2);
      else if (point >= 55296 && point <= 56319 && value.charCodeAt(i + 1) >= 56320 && value.charCodeAt(i + 1) <= 57343) {
        charge(4);
        i++;
      } else
        charge(point >= 55296 && point <= 57343 ? 6 : 3);
    }
  }
  function visit(value, depth) {
    if (++nodes > MAX_NODES || depth > MAX_DEPTH)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.structure", limit: depth > MAX_DEPTH ? MAX_DEPTH : MAX_NODES, actual: depth > MAX_DEPTH ? depth : nodes });
    if (value === null) {
      charge(4);
      return null;
    }
    if (typeof value === "boolean") {
      charge(value ? 4 : 5);
      return value;
    }
    if (typeof value === "string") {
      string(value);
      return value;
    }
    if (typeof value === "number" && Number.isFinite(value)) {
      charge(String(value).length);
      return value;
    }
    if (!value || typeof value !== "object" || active.has(value))
      fail("transport.data");
    const array = Array.isArray(value), prototype = Object.getPrototypeOf(value);
    if (prototype !== null && prototype !== (array ? Array.prototype : Object.prototype))
      fail("transport.prototype");
    const keys = Reflect.ownKeys(value);
    if (keys.length > MAX_NODES - nodes)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.structure", limit: MAX_NODES, actual: keys.length + nodes });
    active.add(value);
    charge(2);
    if (array) {
      if (value.length > MAX_ARRAY)
        throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.array", limit: MAX_ARRAY, actual: value.length });
      if (keys.length !== value.length + 1 || keys.some((key) => key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length)))
        fail("transport.array");
      const result3 = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
        if (!descriptor || !("value" in descriptor))
          fail("transport.accessor");
        if (i)
          charge(1);
        result3.push(visit(descriptor.value, depth + 1));
      }
      active.delete(value);
      return Object.freeze(result3);
    }
    const result2 = /* @__PURE__ */ Object.create(null);
    let index = 0;
    for (const key of keys) {
      if (typeof key !== "string" || key.length > 256)
        fail("transport.key");
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !("value" in descriptor))
        fail("transport.accessor");
      if (index++)
        charge(1);
      string(key);
      charge(1);
      result2[key] = visit(descriptor.value, depth + 1);
    }
    active.delete(value);
    return Object.freeze(result2);
  }
  return visit(input, 0);
}
function canonical(value) {
  if (value === null || typeof value !== "object")
    return JSON.stringify(value);
  if (Array.isArray(value))
    return `[${value.map(canonical).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
}
function validateError(value) {
  const data = object(value, ["name", "code", "details", "reason"]), details = object(data.details, ["path", "limit", "actual", "operationId"]);
  if (details.path !== void 0 && (typeof details.path !== "string" || details.path.length > 256))
    fail("transport.error");
  for (const field of ["limit", "actual"])
    if (details[field] !== void 0)
      integer2(details[field]);
  if (data.name === "SnapshotAdapterError") {
    if (!ERROR_CODES.includes(data.code) || typeof data.reason !== "string" || data.reason.length > 64 || details.operationId !== void 0)
      fail("transport.error");
  } else if (data.name === "RaveldexError") {
    if (data.reason !== void 0)
      fail("transport.error");
    if (!ERROR_CODES.includes(data.code) || details.operationId !== void 0)
      fail("transport.error");
  } else if (data.name === "WorkerAdapterError") {
    if (data.reason !== void 0)
      fail("transport.error");
    if (!WORKER_ERROR_CODES.includes(data.code) || details.operationId !== void 0 && (typeof details.operationId !== "string" || details.operationId.length > 80))
      fail("transport.error");
  } else
    fail("transport.error");
  return data;
}
function inflateError(value) {
  if (value.name === "SnapshotAdapterError") {
    const error = new RaveldexError(value.code, value.details);
    error.name = value.name;
    error.reason = value.reason;
    return error;
  }
  return value.name === "RaveldexError" ? new RaveldexError(value.code, value.details) : new WorkerAdapterError(value.code, value.details);
}
function mutationResult(value, maxDocuments, operation, maximumChanged = maxDocuments) {
  const result2 = object(value, ["revision", "changed", "added", "replaced", "removed"]);
  integer2(result2.revision);
  const sum = integer2(result2.added, maxDocuments) + integer2(result2.replaced, maxDocuments) + integer2(result2.removed, maxDocuments);
  if (sum > maxDocuments || sum > maximumChanged || typeof result2.changed !== "boolean" || result2.changed !== sum > 0 || result2.changed && result2.revision === 0)
    fail("transport.mutation");
  if (operation === "add" && (result2.replaced !== 0 || result2.removed !== 0 || result2.added !== 1) || operation === "addMany" && (result2.replaced !== 0 || result2.removed !== 0) || operation === "replace" && (result2.added !== 0 || result2.removed !== 0 || result2.replaced !== 1) || (operation === "remove" || operation === "clear") && (result2.added !== 0 || result2.replaced !== 0))
    fail("transport.mutation");
  if ((operation === "add" || operation === "addMany") && result2.added !== maximumChanged)
    fail("transport.mutation");
  return result2;
}
function searchResult(value, maxDocuments, offset, limit, requestedExtensions) {
  const result2 = object(value, ["revision", "model", "completeness", "total", "hits", "extensions"]);
  integer2(result2.revision);
  const total = integer2(result2.total, maxDocuments);
  if (result2.model !== "raveldex-bm25-v1" || result2.completeness !== "complete" || !Array.isArray(result2.hits) || result2.hits.length !== Math.min(limit, Math.max(0, total - offset)))
    fail("transport.search");
  const ids = /* @__PURE__ */ new Set();
  let previous;
  for (const raw of result2.hits) {
    const hit = object(raw, ["id", "score"]);
    if (typeof hit.id !== "string" || !hit.id.length || hit.id.length > 256 || ids.has(hit.id) || typeof hit.score !== "number" || !Number.isFinite(hit.score) || hit.score < 0)
      fail("transport.search");
    for (let i = 0; i < hit.id.length; i++) {
      const point = hit.id.charCodeAt(i);
      if (point >= 55296 && point <= 56319) {
        const next = hit.id.charCodeAt(++i);
        if (!(next >= 56320 && next <= 57343))
          fail("transport.search");
      } else if (point >= 56320 && point <= 57343)
        fail("transport.search");
    }
    if (previous && (hit.score > previous.score || hit.score === previous.score && hit.id <= previous.id))
      fail("transport.search");
    previous = { id: hit.id, score: hit.score };
    ids.add(hit.id);
  }
  if (result2.extensions !== void 0) {
    const extensions = object(result2.extensions);
    if (Object.keys(extensions).some((key) => !requestedExtensions.includes(key)))
      fail("transport.extensions");
  }
  if (requestedExtensions.length && (result2.extensions === void 0 || requestedExtensions.some((key) => !Object.hasOwn(result2.extensions, key))))
    fail("transport.extensions");
  return result2;
}
function receipt(value, operationId, maxDocuments) {
  const data = object(value, ["operationId", "status", "result", "error"]);
  if (data.operationId !== operationId)
    fail("transport.receipt");
  if (data.status === "pending" || data.status === "expired") {
    if (data.result !== void 0 || data.error !== void 0)
      fail("transport.receipt");
  } else if (data.status === "committed") {
    if (data.error !== void 0)
      fail("transport.receipt");
    mutationResult(data.result, maxDocuments);
  } else if (data.status === "rejected") {
    if (data.result !== void 0)
      fail("transport.receipt");
    validateError(data.error);
  } else
    fail("transport.receipt");
  return data;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/worker/client.js
var liveEndpoints = /* @__PURE__ */ new WeakSet();
function nativeFailure(error) {
  return error instanceof RaveldexError || error instanceof WorkerAdapterError ? error : new RaveldexError("INTERNAL_ERROR");
}
function transportFailure(error) {
  return error instanceof WorkerAdapterError ? error : new WorkerAdapterError("TERMINATED");
}
var Client = class {
  #worker;
  #owned;
  #session;
  #configuration;
  #maximum;
  #timeout;
  #wireConfiguration;
  #hasAddons;
  #sequence = 0;
  #pending = /* @__PURE__ */ new Map();
  #closing = false;
  #closed = false;
  #ready = false;
  #dispatches = /* @__PURE__ */ new Map();
  #flushedThrough = 0;
  #flushing = false;
  #releaseEndpoint;
  #disposal;
  #message;
  #failure;
  constructor(worker2, owned, configuration, wireConfiguration, hasAddons, maximum, timeout, releaseEndpoint) {
    this.#worker = worker2;
    this.#owned = owned;
    this.#configuration = configuration;
    this.#maximum = maximum;
    this.#timeout = timeout;
    this.#session = sessionValue(crypto.randomUUID());
    this.#wireConfiguration = wireConfiguration;
    this.#hasAddons = hasAddons;
    this.#releaseEndpoint = releaseEndpoint;
    this.#message = (event) => this.receive(event.data);
    this.#failure = () => this.close(new WorkerAdapterError(this.#ready ? "TERMINATED" : "STARTUP_FAILED"));
    try {
      worker2.addEventListener("message", this.#message);
      worker2.addEventListener("messageerror", this.#failure);
      worker2.addEventListener("error", this.#failure);
    } catch (error) {
      for (const [type, listener] of [["message", this.#message], ["messageerror", this.#failure], ["error", this.#failure]]) {
        try {
          worker2.removeEventListener(type, listener);
        } catch {
        }
      }
      throw error;
    }
  }
  async start() {
    try {
      await this.request("init", {
        implementation: IMPLEMENTATION,
        model: "raveldex-bm25-v1",
        configuration: this.#wireConfiguration,
        hasAddons: this.#hasAddons,
        identity: { schema: this.#configuration.schema, limits: this.#configuration.limits, analyzer: this.#configuration.analyzer },
        manifests: (this.#configuration.capabilities?.ordered ?? []).map((registration) => registration.manifest),
        sameHost: true,
        maxMessageBytes: this.#maximum
      }, (value) => {
        const result2 = object(value, ["implementation", "model", "analyzer", "identity", "manifests", "maxMessageBytes", "receipts"]);
        if (result2.implementation !== IMPLEMENTATION || result2.model !== "raveldex-bm25-v1" || cap(result2.maxMessageBytes) > this.#maximum || result2.receipts !== 256)
          fail("transport.init");
        const analyzer = object(result2.analyzer, ["id", "environmentProfile"]);
        if (analyzer.id !== this.#configuration.analyzer.id || analyzer.environmentProfile !== this.#configuration.analyzer.environmentProfile)
          fail("transport.init");
        if (canonical(result2.identity) !== canonical({ schema: this.#configuration.schema, limits: this.#configuration.limits, analyzer: this.#configuration.analyzer }) || canonical(result2.manifests) !== canonical((this.#configuration.capabilities?.ordered ?? []).map((registration) => registration.manifest)))
          fail("transport.init");
        this.#maximum = result2.maxMessageBytes;
        return void 0;
      });
      this.#ready = true;
    } catch (error) {
      this.close(error);
      throw error;
    }
  }
  next() {
    if (this.#sequence === Number.MAX_SAFE_INTEGER)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.ids" });
    if (this.#dispatches.size >= MAX_PENDING * 2)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.dispatch", limit: MAX_PENDING * 2, actual: this.#dispatches.size + 1 });
    const id = ++this.#sequence;
    this.#dispatches.set(id, { ready: false });
    return id;
  }
  release(id) {
    const dispatch = this.#dispatches.get(id);
    if (dispatch) {
      dispatch.ready = true;
      delete dispatch.message;
    }
    this.flush();
  }
  flush() {
    if (this.#flushing)
      return;
    this.#flushing = true;
    try {
      if (this.#closed) {
        this.#dispatches.clear();
        this.#flushedThrough = this.#sequence;
        return;
      }
      while (true) {
        const id = this.#flushedThrough + 1, dispatch = this.#dispatches.get(id);
        if (!dispatch?.ready)
          break;
        this.#dispatches.delete(id);
        this.#flushedThrough = id;
        if (dispatch.message === void 0)
          continue;
        const pending = this.#pending.get(id);
        if (pending && this.#closing && pending.operation !== "dispose") {
          this.settle(id, void 0, new WorkerAdapterError("DISPOSED"));
          continue;
        }
        try {
          if (pending)
            pending.dispatched = true;
          this.#worker.postMessage(dispatch.message);
        } catch (error) {
          if (pending)
            this.settle(id, void 0, mutation(pending.operation) ? new WorkerAdapterError("OUTCOME_UNKNOWN", { operationId: pending.operationId }) : transportFailure(error));
          else
            this.close(transportFailure(error));
        }
        if (this.#closed)
          break;
      }
    } finally {
      this.#flushing = false;
    }
  }
  request(operation, payload, validate, signal, identifier) {
    let id = identifier ?? this.next();
    if (this.#closed || this.#closing && operation !== "dispose") {
      this.release(id);
      return Promise.reject(new WorkerAdapterError("DISPOSED"));
    }
    if (this.#pending.size >= MAX_PENDING) {
      this.release(id);
      return Promise.reject(new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.pending", limit: MAX_PENDING, actual: this.#pending.size + 1 }));
    }
    let message;
    try {
      message = captureMessage({ protocol: PROTOCOL, session: this.#session, id, operation, payload }, this.#maximum);
    } catch (error) {
      this.release(id);
      return Promise.reject(error instanceof WorkerAdapterError ? error : new WorkerAdapterError("INVALID_TRANSPORT"));
    }
    return new Promise((resolve, reject) => {
      const operationId = `${this.#session}:${id}`;
      const timer = setTimeout(() => {
        const pending2 = this.#pending.get(id);
        if (!pending2)
          return;
        this.settle(id, void 0, mutation(operation) && pending2.dispatched ? new WorkerAdapterError("OUTCOME_UNKNOWN", { operationId }) : new WorkerAdapterError("TIMEOUT"));
      }, this.#timeout);
      const cancel = () => {
        const pending2 = this.#pending.get(id);
        if (!pending2 || pending2.cancelRequested)
          return;
        pending2.cancelRequested = true;
        try {
          const cancelId = this.next(), dispatch = this.#dispatches.get(cancelId);
          dispatch.message = captureMessage({ protocol: PROTOCOL, session: this.#session, id: cancelId, operation: "cancel", payload: { targetId: id } }, this.#maximum);
          dispatch.ready = true;
          this.flush();
        } catch (error) {
          this.close(transportFailure(error));
        }
      };
      const pending = {
        operation,
        operationId,
        resolve,
        reject,
        timer,
        validate,
        dispatched: false,
        cancelRequested: false,
        ...signal ? { detach: () => signal.removeEventListener("abort", cancel) } : {}
      };
      this.#pending.set(id, pending);
      try {
        if (signal) {
          signal.addEventListener("abort", cancel, { once: true });
          if (!this.#pending.has(id)) {
            try {
              signal.removeEventListener("abort", cancel);
            } catch {
            }
            this.release(id);
            return;
          }
          if (this.#closed || this.#closing) {
            this.settle(id, void 0, new WorkerAdapterError("DISPOSED"));
            return;
          }
          if (signal.aborted || pending.cancelRequested) {
            this.settle(id, void 0, new RaveldexError("CANCELLED", { path: "options.signal" }));
            return;
          }
        }
        const dispatch = this.#dispatches.get(id);
        dispatch.message = message;
        dispatch.ready = true;
        this.flush();
      } catch (error) {
        this.settle(id, void 0, mutation(operation) && pending.dispatched ? new WorkerAdapterError("OUTCOME_UNKNOWN", { operationId }) : pending.dispatched ? transportFailure(error) : nativeFailure(error));
      }
    });
  }
  settle(id, value, error) {
    const pending = this.#pending.get(id);
    if (!pending)
      return;
    this.#pending.delete(id);
    clearTimeout(pending.timer);
    this.release(id);
    try {
      pending.detach?.();
    } catch {
    }
    if (error !== void 0)
      pending.reject(error);
    else
      pending.resolve(value);
  }
  receive(raw) {
    if (this.#closed)
      return;
    try {
      const response = object(captureMessage(raw, this.#maximum), ["protocol", "session", "id", "operation", "kind", "value"]);
      if (response.protocol !== PROTOCOL || response.session !== this.#session || !OPERATIONS.includes(response.operation))
        fail("transport.identity");
      const id = integer2(response.id, this.#sequence, 1), pending = this.#pending.get(id);
      if (response.kind !== "result" && response.kind !== "error")
        fail("transport.response");
      if (response.kind === "error")
        validateError(response.value);
      if (!pending)
        return;
      if (pending.operation !== response.operation)
        fail("transport.operation");
      if (response.kind === "error")
        this.settle(id, void 0, inflateError(validateError(response.value)));
      else
        this.settle(id, pending.validate(response.value));
    } catch (error) {
      this.close(error instanceof WorkerAdapterError ? error : new WorkerAdapterError("INVALID_TRANSPORT"));
    }
  }
  close(error) {
    if (this.#closed)
      return;
    this.#closed = true;
    this.#closing = true;
    for (const [id, pending] of this.#pending)
      this.settle(id, void 0, mutation(pending.operation) && pending.dispatched ? new WorkerAdapterError("OUTCOME_UNKNOWN", { operationId: pending.operationId }) : error);
    for (const [type, listener] of [["message", this.#message], ["messageerror", this.#failure], ["error", this.#failure]]) {
      try {
        this.#worker.removeEventListener(type, listener);
      } catch {
      }
    }
    if (this.#owned) {
      try {
        this.#worker.terminate();
      } catch {
      }
    }
    this.#dispatches.clear();
    this.#releaseEndpoint();
  }
  options(input, search, admission = new Admission(this.#configuration.limits.maxAdmissionEntries)) {
    const admittedAt = monotonicEpoch();
    const captured = search ? captureOptions(input, this.#configuration.limits, true, admission, this.#configuration.capabilities) : captureOptions(input, this.#configuration.limits, false, admission);
    const { signal } = captured;
    const data = ownObject(input === void 0 ? {} : input, "INVALID_OPTIONS", "options", new Admission(this.#configuration.limits.maxAdmissionEntries));
    delete data.signal;
    if (signal?.aborted)
      throw new RaveldexError("CANCELLED", { path: "options.signal" });
    return { options: data, admittedAt, ...signal ? { signal } : {}, ...search ? { search: captured } : {} };
  }
  search(query, options) {
    if (this.#closed || this.#closing)
      return Promise.reject(new WorkerAdapterError("DISPOSED"));
    try {
      const admission = new Admission(this.#configuration.limits.maxAdmissionEntries);
      const captured = this.options(options, true, admission), page = captured.search;
      captureQuery(query, this.#configuration.schema, this.#configuration.limits, admission, this.#configuration.capabilities);
      if (captured.signal?.aborted)
        throw new RaveldexError("CANCELLED", { path: "options.signal" });
      return this.request("search", { query, options: captured.options, admittedAt: captured.admittedAt }, (value) => searchResult(value, this.#configuration.limits.maxDocuments, page.offset, page.limit, Object.keys(page.extensions ?? {})), captured.signal);
    } catch (error) {
      return Promise.reject(nativeFailure(error));
    }
  }
  mutate(operation, input, options) {
    let id;
    let promise;
    try {
      if (this.#closed || this.#closing)
        throw new WorkerAdapterError("DISPOSED");
      const admittedAt = monotonicEpoch();
      const admitted = captureMutation(this.#configuration, operation, input, options);
      const signal = admitted.options.signal;
      if (signal?.aborted)
        throw new RaveldexError("CANCELLED", { path: "options.signal" });
      const wireOptions = ownObject(options === void 0 ? {} : options, "INVALID_OPTIONS", "options", new Admission(this.#configuration.limits.maxAdmissionEntries));
      delete wireOptions.signal;
      const maximumChanged = operation === "clear" ? this.#configuration.limits.maxDocuments : operation === "remove" ? admitted.ids.length : admitted.records.length;
      id = this.next();
      promise = this.request(operation, { ...input === void 0 ? {} : { input }, options: wireOptions, admittedAt }, (value) => mutationResult(value, this.#configuration.limits.maxDocuments, operation, maximumChanged), signal, id);
    } catch (error) {
      promise = Promise.reject(nativeFailure(error));
      if (id === void 0) {
        try {
          id = this.next();
        } catch {
        }
      }
      if (id !== void 0)
        this.release(id);
    }
    Object.defineProperty(promise, "operationId", { value: id === void 0 ? "" : `${this.#session}:${id}`, enumerable: true });
    return promise;
  }
  add(record, options) {
    return this.mutate("add", record, options);
  }
  addMany(records, options) {
    return this.mutate("addMany", records, options);
  }
  replace(record, options) {
    return this.mutate("replace", record, options);
  }
  remove(ids, options) {
    return this.mutate("remove", ids, options);
  }
  clear(options) {
    return this.mutate("clear", void 0, options);
  }
  reconcile(operationId) {
    if (this.#closed || this.#closing)
      return Promise.reject(new WorkerAdapterError("DISPOSED"));
    try {
      if (typeof operationId !== "string" || !operationId.startsWith(`${this.#session}:`) || !/^[1-9][0-9]*$/.test(operationId.slice(this.#session.length + 1)))
        fail("transport.operationId");
      integer2(Number(operationId.slice(this.#session.length + 1)), this.#sequence, 1);
      return this.request("reconcile", { operationId }, (value) => receipt(value, operationId, this.#configuration.limits.maxDocuments));
    } catch (error) {
      return Promise.reject(nativeFailure(error));
    }
  }
  snapshot(operation, input, options, validate) {
    let id, promise;
    try {
      if (this.#closed || this.#closing)
        throw new WorkerAdapterError("DISPOSED");
      const captured = this.options(options, false);
      if (operation === "snapshotRestore" && typeof input !== "string")
        throw new WorkerAdapterError("INVALID_TRANSPORT", { path: "snapshot.encoded" });
      id = this.next();
      promise = this.request(operation, { ...operation === "snapshotRestore" ? { input } : {}, options: captured.options, admittedAt: captured.admittedAt }, validate, captured.signal, id);
    } catch (error) {
      promise = Promise.reject(nativeFailure(error));
      if (id !== void 0)
        this.release(id);
    }
    if (operation === "snapshotRestore")
      Object.defineProperty(promise, "operationId", { value: id === void 0 ? "" : `${this.#session}:${id}`, enumerable: true });
    return promise;
  }
  snapshotReconcile(operationId, validate) {
    if (this.#closed || this.#closing)
      return Promise.reject(new WorkerAdapterError("DISPOSED"));
    try {
      if (typeof operationId !== "string" || !operationId.startsWith(`${this.#session}:`) || !/^[1-9][0-9]*$/.test(operationId.slice(this.#session.length + 1)))
        fail("transport.operationId");
      integer2(Number(operationId.slice(this.#session.length + 1)), this.#sequence, 1);
      return this.request("snapshotReconcile", { operationId }, validate);
    } catch (error) {
      return Promise.reject(nativeFailure(error));
    }
  }
  dispose() {
    if (this.#disposal)
      return this.#disposal;
    if (this.#closed)
      return Promise.resolve();
    this.#closing = true;
    this.#disposal = (async () => {
      try {
        await this.request("dispose", {}, (value) => {
          if (value !== null)
            fail("transport.dispose");
          return void 0;
        });
      } finally {
        this.close(new WorkerAdapterError("DISPOSED"));
      }
    })();
    return this.#disposal;
  }
  destroy() {
    return this.dispose();
  }
  facade() {
    const facade = Object.freeze({ search: this.search.bind(this), add: this.add.bind(this), addMany: this.addMany.bind(this), replace: this.replace.bind(this), remove: this.remove.bind(this), clear: this.clear.bind(this), reconcile: this.reconcile.bind(this), dispose: this.dispose.bind(this), destroy: this.destroy.bind(this) });
    bindSnapshotChannel(facade, Object.freeze({ invoke: this.snapshot.bind(this), reconcile: this.snapshotReconcile.bind(this) }));
    return facade;
  }
};
async function createWorkerRaveldex(options) {
  const data = ownObject(options, "INVALID_OPTIONS", "worker.options", new Admission(64));
  keysOnly(data, ["worker", "configuration", "ownership", "sameHost", "maxMessageBytes", "responseTimeoutMs"], "INVALID_OPTIONS", "worker.options");
  const worker2 = data.worker;
  if (!worker2 || typeof worker2.postMessage !== "function" || typeof worker2.addEventListener !== "function" || typeof worker2.removeEventListener !== "function" || typeof worker2.terminate !== "function")
    throw new RaveldexError("INVALID_OPTIONS", { path: "worker.options.worker" });
  if (data.ownership !== "owned" && data.ownership !== "external")
    throw new RaveldexError("INVALID_OPTIONS", { path: "worker.options.ownership" });
  if (liveEndpoints.has(worker2))
    throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.owner" });
  liveEndpoints.add(worker2);
  let client;
  try {
    if (data.sameHost !== true)
      throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.sameHost" });
    const configuration = captureConfiguration(data.configuration);
    for (const registration of configuration.capabilities?.ordered ?? [])
      if (!registration.manifest.execution.worker || !registration.manifest.execution.workerRegistration)
        throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.addons" });
    const maximum = cap(data.maxMessageBytes), timeout = data.responseTimeoutMs === void 0 ? 65e3 : integer2(data.responseTimeoutMs, 12e4, 1);
    const wireConfiguration = ownObject(data.configuration, "INVALID_OPTIONS", "config", new Admission(configuration.limits.maxAdmissionEntries));
    const hasAddons = Object.hasOwn(wireConfiguration, "addons");
    delete wireConfiguration.addons;
    const boundWorker = { postMessage: worker2.postMessage.bind(worker2), addEventListener: worker2.addEventListener.bind(worker2), removeEventListener: worker2.removeEventListener.bind(worker2), terminate: worker2.terminate.bind(worker2) };
    client = new Client(boundWorker, data.ownership === "owned", configuration, captureMessage(wireConfiguration, maximum), hasAddons, maximum, timeout, () => liveEndpoints.delete(worker2));
    await client.start();
    return client.facade();
  } catch (error) {
    if (!client && data.ownership === "owned") {
      try {
        worker2.terminate();
      } catch {
      }
    }
    liveEndpoints.delete(worker2);
    throw error instanceof RaveldexError || error instanceof WorkerAdapterError ? error : new WorkerAdapterError("STARTUP_FAILED");
  }
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/error.js
var SNAPSHOT_REASONS = Object.freeze([
  "MALFORMED_SNAPSHOT",
  "ENCODED_LIMIT_EXCEEDED",
  "INTEGRITY_MISMATCH",
  "UNSUPPORTED_FORMAT",
  "UNSUPPORTED_CODEC",
  "SCHEMA_MISMATCH",
  "ANALYZER_MISMATCH",
  "RANKING_MISMATCH",
  "CAPABILITY_MISMATCH",
  "INDEX_DETAIL_MISMATCH",
  "LIMITS_MISMATCH",
  "SOURCE_UNAVAILABLE",
  "UNQUALIFIED_PROFILE",
  "PROFILE_MISMATCH",
  "INVALID_NATIVE_STATE",
  "UNSUPPORTED_ENGINE"
]);
var SnapshotAdapterError = class extends RaveldexError {
  reason;
  constructor(reason, path = "snapshot") {
    super(reason === "ENCODED_LIMIT_EXCEEDED" ? "LIMIT_EXCEEDED" : reason === "SOURCE_UNAVAILABLE" || reason === "UNSUPPORTED_ENGINE" ? "MISSING_CAPABILITY" : "INCOMPATIBLE_CAPABILITY", { path });
    this.name = "SnapshotAdapterError";
    this.reason = reason;
  }
};

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/adapters/worker/snapshots.js
function result(input) {
  const value = object(input, ["format", "originRevision", "revision", "reindexed", "receivingAnalyzer"]);
  if (value.format !== "raveldex-source" || value.reindexed !== true)
    fail("snapshot.result");
  integer2(value.originRevision);
  integer2(value.revision, Number.MAX_SAFE_INTEGER, 1);
  const analyzer = object(value.receivingAnalyzer, ["id", "environmentProfile"]);
  if (analyzer.id !== "basic-v1" || analyzer.environmentProfile !== "unqualified")
    fail("snapshot.analyzer");
  return value;
}
function receipt2(input, operationId) {
  const value = object(input, ["operationId", "status", "result", "error"]);
  if (value.operationId !== operationId)
    fail("snapshot.receipt");
  if (value.status === "pending" || value.status === "expired") {
    if (value.result !== void 0 || value.error !== void 0)
      fail("snapshot.receipt");
  } else if (value.status === "committed") {
    if (value.error !== void 0)
      fail("snapshot.receipt");
    result(value.result);
  } else if (value.status === "rejected") {
    if (value.result !== void 0)
      fail("snapshot.receipt");
    validateError(value.error);
  } else
    fail("snapshot.receipt");
  return value;
}
function inflate(error) {
  if (error && typeof error === "object" && "name" in error && error.name === "SnapshotAdapterError" && "reason" in error && SNAPSHOT_REASONS.includes(error.reason)) {
    const path = "details" in error && error.details && typeof error.details === "object" && "path" in error.details && typeof error.details.path === "string" ? error.details.path : void 0;
    throw new SnapshotAdapterError(error.reason, path);
  }
  throw error;
}
function createWorkerSnapshots(engine2) {
  const channel = getSnapshotChannel(engine2);
  if (!channel)
    throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "snapshot.engine" });
  return Object.freeze({
    exportSource(options) {
      return channel.invoke("snapshotExportSource", void 0, options, (value) => {
        if (typeof value !== "string")
          fail("snapshot.encoded");
        return value;
      }).catch(inflate);
    },
    restore(encoded2, options) {
      const promise = channel.invoke("snapshotRestore", encoded2, options, result), mapped = promise.catch(inflate);
      Object.defineProperty(mapped, "operationId", { value: promise.operationId ?? "", enumerable: true });
      return mapped;
    },
    reconcile(operationId) {
      return channel.reconcile(operationId, (value) => receipt2(value, operationId));
    }
  });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/capabilities/worker-identity.js
function workerIdentity(family, options) {
  function canonical2(value) {
    if (value === null || typeof value !== "object")
      return JSON.stringify(value);
    if (Array.isArray(value))
      return `[${value.map(canonical2).join(",")}]`;
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical2(value[key])}`).join(",")}}`;
  }
  return `raveldex:${family}:1:${canonical2(options)}`;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/index/directory.js
var DIRECTORY_SLOTS = 256;
function bucketOf(key) {
  let hash = 2166136261;
  for (let i = 0; i < key.length; i++)
    hash = Math.imul(hash ^ key.charCodeAt(i), 16777619);
  return String((hash >>> 0) % DIRECTORY_SLOTS);
}
function directoryGet(directory, key) {
  return directory.buckets[bucketOf(key)]?.[key];
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/addons/phrases/options.js
function sourceEntryCeiling(documents, fields, values) {
  return documents * (1 + fields * (1 + values));
}
function capturePhraseOptions(input, source) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const options = ownObject(input, "INVALID_OPTIONS", "addons.options", admission);
  keysOnly(options, source ? ["fields", "id", "maxRetainedEntries", "maxWorkUnits"] : ["fields", "id", "maxWorkUnits"], "INVALID_OPTIONS", "addons.options");
  const fieldsInput = ownArray(options.fields, DEFAULT_LIMITS.maxTextFields, "INVALID_OPTIONS", "addons.fields", admission);
  if (fieldsInput.length === 0)
    invalid("INVALID_OPTIONS", "addons.fields");
  const seen = /* @__PURE__ */ new Set();
  const fields = Object.freeze(fieldsInput.map((value) => {
    const field = stringValue(value, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", "addons.fields");
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) || field === "constructor" || field === "prototype" || seen.has(field))
      invalid("INVALID_OPTIONS", "addons.fields");
    seen.add(field);
    return field;
  }));
  const id = has(options, "id") ? stringValue(options.id, 64, "INVALID_OPTIONS", "addons.id") : source ? "source" : "source-phrases";
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "addons.id");
  const workCeiling = source ? DEFAULT_LIMITS.maxMutationWorkUnits : DEFAULT_LIMITS.maxSearchWorkUnits;
  const maxWorkUnits = has(options, "maxWorkUnits") ? options.maxWorkUnits : workCeiling;
  if (typeof maxWorkUnits !== "number" || !Number.isSafeInteger(maxWorkUnits) || maxWorkUnits < 1)
    invalid("INVALID_OPTIONS", "addons.maxWorkUnits");
  bound(maxWorkUnits, workCeiling, "addons.maxWorkUnits");
  const entryCeiling = sourceEntryCeiling(DEFAULT_LIMITS.maxDocuments, fields.length, DEFAULT_LIMITS.maxTextValuesPerField);
  const maxRetainedEntries = source && has(options, "maxRetainedEntries") ? options.maxRetainedEntries : source ? entryCeiling : 0;
  if (typeof maxRetainedEntries !== "number" || !Number.isSafeInteger(maxRetainedEntries) || maxRetainedEntries < 0)
    invalid("INVALID_OPTIONS", "addons.maxRetainedEntries");
  bound(maxRetainedEntries, entryCeiling, "addons.maxRetainedEntries");
  return Object.freeze({ fields, id, maxWorkUnits, maxRetainedEntries });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/index/staging.js
function emptyDirectory() {
  return Object.freeze({ size: 0, buckets: Object.freeze(/* @__PURE__ */ Object.create(null)) });
}
var DirectoryStage = class {
  original;
  charge;
  counts;
  pointers;
  touched = /* @__PURE__ */ new Map();
  count;
  sealed = false;
  constructor(original, charge, counts) {
    this.original = original;
    this.charge = charge;
    this.counts = counts;
    this.count = original.size;
  }
  get size() {
    return this.count;
  }
  get(key) {
    return (this.pointers ?? this.original.buckets)[bucketOf(key)]?.[key];
  }
  *bucket(slot) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    if (!this.pointers) {
      const pointers = /* @__PURE__ */ Object.create(null);
      if (this.counts)
        this.counts.directories++;
      for (const slot2 of Object.keys(this.original.buckets)) {
        yield this.charge(1);
        pointers[slot2] = this.original.buckets[slot2];
        if (this.counts)
          this.counts.directoryPointers++;
      }
      this.pointers = pointers;
    }
    const cached = this.touched.get(slot);
    if (cached)
      return cached;
    const bucket = /* @__PURE__ */ Object.create(null);
    if (this.counts)
      this.counts.buckets++;
    const previous = this.original.buckets[slot];
    for (const entry of Object.keys(previous ?? {})) {
      yield this.charge(entry.length + 1);
      bucket[entry] = previous[entry];
      if (this.counts)
        this.counts.bucketEntries++;
    }
    this.touched.set(slot, bucket);
    this.pointers[slot] = bucket;
    return bucket;
  }
  *set(key, value) {
    yield this.charge(key.length + 1);
    const bucket = yield* this.bucket(bucketOf(key));
    if (!Object.hasOwn(bucket, key)) {
      this.count++;
      if (this.counts)
        this.counts.insertions++;
    }
    bucket[key] = value;
    if (this.counts)
      this.counts.writes++;
  }
  *delete(key) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    yield this.charge(key.length + 1);
    const slot = bucketOf(key);
    if ((this.pointers ?? this.original.buckets)[slot]?.[key] === void 0)
      return;
    const bucket = yield* this.bucket(slot);
    delete bucket[key];
    this.count--;
    if (this.counts)
      this.counts.deletes++;
  }
  *finish() {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    this.sealed = true;
    if (!this.pointers)
      return this.original;
    for (const [slot, bucket] of this.touched) {
      const keys = Object.keys(bucket);
      for (const key of keys)
        yield this.charge(key.length + 1);
      if (keys.length)
        Object.freeze(bucket);
      else
        delete this.pointers[slot];
    }
    for (const slot of Object.keys(this.pointers)) {
      void slot;
      yield this.charge(1);
    }
    return Object.freeze({ size: this.count, buckets: Object.freeze(this.pointers) });
  }
};

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/addons/phrases/store.js
var rawCharge = (workUnits) => ({ workUnits });
function requireSourceRoot(input, field, revision, analyzer) {
  if (input === void 0 || input === null)
    invalid("MISSING_CAPABILITY", "phrases.source");
  if (typeof input !== "object" || !Object.isFrozen(input))
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.source");
  const root = input;
  if (root.kind !== "raveldex-source-v1" || !Array.isArray(root.fields) || !Object.isFrozen(root.fields) || root.fields.length === 0 || root.fields.length > DEFAULT_LIMITS.maxTextFields || typeof root.analyzer !== "object" || root.analyzer === null || !Object.isFrozen(root.analyzer) || typeof root.records !== "object" || root.records === null || !Object.isFrozen(root.records) || !Number.isSafeInteger(root.records.size) || root.records.size < 0 || root.records.size > DEFAULT_LIMITS.maxDocuments || typeof root.records.buckets !== "object" || root.records.buckets === null || !Object.isFrozen(root.records.buckets) || !Number.isSafeInteger(root.revision) || root.revision < 0 || !Number.isSafeInteger(root.retainedEntries) || root.retainedEntries < 0 || !Number.isSafeInteger(root.textCodeUnits) || root.textCodeUnits < 0 || !Number.isSafeInteger(root.maxRetainedEntries) || root.maxRetainedEntries < root.retainedEntries || !Number.isSafeInteger(root.maxTextCodeUnits) || root.maxTextCodeUnits < root.textCodeUnits)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.source");
  if (!root.fields.includes(field))
    invalid("MISSING_CAPABILITY", "phrases.source.field");
  if (root.revision !== revision)
    invalid("REVISION_MISMATCH", "phrases.source.revision");
  if (root.analyzer.id !== analyzer.id || root.analyzer.environmentProfile !== analyzer.environmentProfile)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.analyzer");
  return root;
}
function* retainRecord(record, fields) {
  const text = /* @__PURE__ */ Object.create(null);
  let retainedEntries = 1, textCodeUnits = 0;
  for (const field of fields) {
    yield rawCharge(field.length + 1);
    if (!has(record.text, field))
      continue;
    const values = record.text[field];
    if (!Object.isFrozen(values))
      invalid("INTERNAL_ERROR", "source.record.values");
    retainedEntries += 1 + values.length;
    for (const value of values) {
      yield rawCharge(1);
      textCodeUnits += value.length;
    }
    text[field] = values;
  }
  return Object.freeze({ text: Object.freeze(text), retainedEntries, textCodeUnits });
}
function initialRoot(configuration, fields, requestedEntries) {
  for (const field of fields)
    if (!has(configuration.schema.text, field))
      invalid("MISSING_CAPABILITY", "source.fields");
  const maxRetainedEntries = Math.min(requestedEntries, sourceEntryCeiling(configuration.limits.maxDocuments, fields.length, configuration.limits.maxTextValuesPerField));
  return Object.freeze({
    kind: "raveldex-source-v1",
    revision: 0,
    analyzer: Object.freeze({ id: configuration.analyzer.id, environmentProfile: configuration.analyzer.environmentProfile }),
    fields,
    records: emptyDirectory(),
    retainedEntries: 0,
    textCodeUnits: 0,
    maxRetainedEntries,
    maxTextCodeUnits: configuration.limits.maxCorpusTextCodeUnits
  });
}
function* prepareSource(previous, context, fields) {
  const old = requireSourceRoot(previous, fields[0], context.previousRevision, context.analyzer);
  if (context.revision !== context.previousRevision + 1 || !Number.isSafeInteger(context.revision))
    invalid("REVISION_MISMATCH", "source.revision");
  if (context.kind === "clear") {
    yield rawCharge(1);
    return Object.freeze({ ...old, revision: context.revision, records: emptyDirectory(), retainedEntries: 0, textCodeUnits: 0 });
  }
  const stage = new DirectoryStage(old.records, rawCharge);
  let retainedEntries = old.retainedEntries, textCodeUnits = old.textCodeUnits;
  for (const id of context.removedIds) {
    yield rawCharge(id.length + 1);
    const retained = stage.get(id);
    if (!retained)
      invalid("MISSING_CAPABILITY", "source.record");
    retainedEntries -= retained.retainedEntries;
    textCodeUnits -= retained.textCodeUnits;
    yield* stage.delete(id);
  }
  for (const record of context.records) {
    yield rawCharge(record.id.length + 1);
    const retained = stage.get(record.id);
    if (context.kind === "replace" && !retained)
      invalid("MISSING_CAPABILITY", "source.record");
    if (context.kind !== "replace" && retained)
      invalid("INCOMPATIBLE_CAPABILITY", "source.record");
    if (retained) {
      retainedEntries -= retained.retainedEntries;
      textCodeUnits -= retained.textCodeUnits;
    }
    const next = yield* retainRecord(record, fields);
    retainedEntries += next.retainedEntries;
    textCodeUnits += next.textCodeUnits;
    bound(retainedEntries, old.maxRetainedEntries, "source.retainedEntries");
    bound(textCodeUnits, old.maxTextCodeUnits, "source.textCodeUnits");
    yield* stage.set(record.id, next);
  }
  if (retainedEntries < 0 || textCodeUnits < 0)
    invalid("INCOMPATIBLE_CAPABILITY", "source.counts");
  const records = yield* stage.finish();
  return Object.freeze({ ...old, revision: context.revision, records, retainedEntries, textCodeUnits });
}
function createSourceProvider(options) {
  const captured = capturePhraseOptions(options, true);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["transaction-participant"]),
      provides: Object.freeze(captured.fields.map((field) => Object.freeze({ id: `source:${field}`, contractVersion: 1 }))),
      requires: Object.freeze([]),
      dataRequirements: Object.freeze({ fields: captured.fields, source: true, positions: false, offsets: false, metadata: false }),
      indexEffect: "transactional",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("source", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: captured.maxRetainedEntries, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Selected-source capture and copy-on-write directory staging; no phrase verifier.", retainedRepresentation: "One entry per record, present selected field and original value; selected original UTF-16 strings only.", transientWork: "Changed selected-field values and touched source-directory buckets; shared mutation budget.", externalResources: "none" }),
      codec: Object.freeze({ id: "raveldex-source-v1", version: 1 })
    }),
    participant: Object.freeze({
      initialize: (configuration) => initialRoot(configuration, captured.fields, captured.maxRetainedEntries),
      prepare: (previous, context) => prepareSource(previous, context, captured.fields)
    })
  });
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/core/query/work.js
function* compareStrings(a, b, charge) {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    yield charge(1);
    const difference = a.charCodeAt(i) - b.charCodeAt(i);
    if (difference)
      return difference;
  }
  yield charge(1);
  return a.length - b.length;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/addons/phrases/verifier.js
var rawCharge2 = (workUnits) => ({ workUnits });
function* phraseFailureTable(terms) {
  const failure = [];
  if (terms.length) {
    yield rawCharge2(1);
    failure.push(0);
  }
  for (let i = 1; i < terms.length; i++) {
    let matched = failure[i - 1];
    for (; ; ) {
      if ((yield* compareStrings(terms[i], terms[matched], rawCharge2)) === 0) {
        matched++;
        break;
      }
      if (matched === 0)
        break;
      yield rawCharge2(1);
      matched = failure[matched - 1];
    }
    yield rawCharge2(1);
    failure.push(matched);
  }
  return Object.freeze(failure);
}
function* sourceValueMatches(value, valueIndex, terms, failure, limits) {
  if (terms.length === 0)
    return false;
  let matched = 0;
  for (const step of analyzeValue(value, valueIndex, limits)) {
    yield rawCharge2(step.workUnits);
    if (!step.token)
      continue;
    for (; ; ) {
      if ((yield* compareStrings(step.token.term, terms[matched], rawCharge2)) === 0) {
        matched++;
        if (matched === terms.length)
          return true;
        break;
      }
      if (matched === 0)
        break;
      yield rawCharge2(1);
      matched = failure[matched - 1];
    }
  }
  return false;
}

// ../../../../../var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz/node_modules/@vmitsaras/raveldex/dist/addons/phrases/index.js
var MAX_PHRASE_TOKENS = 32;
var rawCharge3 = (workUnits) => ({ workUnits });
function* preparePhrase(context, enabledFields) {
  if (context.analyzer.id !== BASIC_ANALYZER.id)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.analyzer");
  bound(context.terms.length, Math.min(MAX_PHRASE_TOKENS, context.limits.maxQueryTokens), "phrases.tokens");
  const fields = [];
  for (const field of context.fields) {
    yield rawCharge3(field.length + enabledFields.length + 1);
    if (!enabledFields.includes(field))
      invalid("MISSING_CAPABILITY", "phrases.field");
    const root = requireSourceRoot(context.state(`source:${field}`), field, context.revision, context.analyzer);
    yield rawCharge3(root.fields.length + 1);
    fields.push(Object.freeze({ name: field, root }));
  }
  const failure = yield* phraseFailureTable(context.terms);
  const sources = Object.freeze(fields);
  const terms = context.terms, limits = context.limits;
  return Object.freeze({
    *test(id) {
      const records = [];
      for (const field of sources) {
        yield rawCharge3(id.length + 1);
        const record = directoryGet(field.root.records, id);
        if (!record)
          invalid("MISSING_CAPABILITY", "phrases.source.record");
        if (!Object.isFrozen(record) || typeof record.text !== "object" || record.text === null || !Object.isFrozen(record.text))
          invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.record");
        records.push({ field: field.name, record });
      }
      for (const { field, record } of records) {
        const values = record.text[field];
        if (!values)
          continue;
        if (!Array.isArray(values) || !Object.isFrozen(values) || values.length > limits.maxTextValuesPerField)
          invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.values");
        for (let i = 0; i < values.length; i++) {
          yield rawCharge3(1);
          if (typeof values[i] !== "string")
            invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.values");
          if (yield* sourceValueMatches(values[i], i, terms, failure, limits))
            return true;
        }
      }
      return false;
    }
  });
}
function createSourcePhrases(options) {
  const captured = capturePhraseOptions(options, false);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["leaf-refinement"]),
      provides: Object.freeze([Object.freeze({ id: "phrases", contractVersion: 1 })]),
      requires: Object.freeze(captured.fields.map((field) => Object.freeze({ id: `source:${field}`, contractVersion: 1 }))),
      dataRequirements: Object.freeze({ fields: captured.fields, source: true, positions: false, offsets: false, metadata: false }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("source-phrases", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Native analyzer, resumable source phrase verifier and selected-source protocol.", retainedRepresentation: "No additional index state; source providers retain declared originals.", transientWork: "At most 32 phrase-prefix entries plus one current token; complete lexical candidates are scanned under the shared search budget.", externalResources: "none" })
    }),
    refinement: Object.freeze({
      kind: "exact-token-sequence",
      maxTokens: MAX_PHRASE_TOKENS,
      prepare: (context) => preparePhrase(context, captured.fields)
    })
  });
}

// cost-fixture.mjs
var METHOD = Object.freeze({
  version: "rx4001-cost-v1",
  seed: "rx4001-ascii-cycle-37-3-v1",
  sizes: [100, 1e3, 1e4],
  owners: 3,
  batchSize: 256,
  queryWarmups: 2,
  queryRepetitions: 5,
  deadlineMs: 6e4,
  requestedPage: { limit: 20, offset: 0 },
  timingResolutionMs: 1
});
var schema = { text: { body: {} }, metadata: { group: { type: "string" } } };
function recordsFor(size2) {
  if (!Number.isSafeInteger(size2) || size2 < 1 || size2 > 1e4) throw Error("size outside admitted contract");
  return Array.from({ length: size2 }, (_, index) => ({
    id: `item:${String(index).padStart(5, "0")}`,
    text: { body: `${index % 3 === 0 ? "red blue" : "red green blue"} echo echo value${index % 37}` },
    metadata: { group: `group${index % 5}` }
  }));
}
var features = Object.freeze({
  query: "Native exact ASCII text AND, exact full total plus deterministic BM25 top20. Strict phrase additionally requires same token sequence in one original field value.",
  filter: "No filter/facet requested. Core scalar equality is available; extended metadata predicates and facets are uninstalled in these measured configurations.",
  count: "Exact complete membership count before top20.",
  evidence: "No Inspector, range/snippet output or rendering requested.",
  analyzer: "basic-v1 NFKC then lowercase; this ASCII fixture does not compare Unicode platform behavior.",
  runtimeDependencies: [],
  limits: "Unchanged default admission, corpus, search/mutation work and optional participant bounds. Deadline 60000ms; batchSize256."
});

// message-observer.mjs
function observeMessages(native, realm) {
  if (!["main", "worker"].includes(realm)) throw Error("Unknown realm");
  const rows = [], listeners = /* @__PURE__ */ new Map();
  const post = native.postMessage.bind(native);
  const add = native.addEventListener.bind(native), remove = native.removeEventListener.bind(native);
  let sequence = 0, dropped = 0;
  function note(data, direction, edge, token2) {
    if (rows.length >= 1024) {
      dropped++;
      return;
    }
    rows.push({
      sequence: ++sequence,
      token: token2,
      realm,
      direction,
      edge,
      protocol: Number.isSafeInteger(data?.protocol) ? data.protocol : null,
      session: typeof data?.session === "string" ? data.session : null,
      id: Number.isSafeInteger(data?.id) ? data.id : null,
      operation: typeof data?.operation === "string" ? data.operation : null,
      kind: typeof data?.kind === "string" ? data.kind : null
    });
    performance.mark(`rx:message:${realm}:${direction}:${token2}:${edge}`);
  }
  let token = 0;
  const endpoint = {
    postMessage(...args) {
      const current = ++token;
      note(args[0], "send", "begin", current);
      try {
        return post(...args);
      } finally {
        note(args[0], "send", "end", current);
      }
    },
    addEventListener(type, listener, ...options) {
      if (type !== "message" || listener === null) return add(type, listener, ...options);
      if (options.length) throw Error("Only option-free adapter listeners are supported");
      let wrapped = listeners.get(listener);
      if (!wrapped) {
        wrapped = function(event) {
          const data = event.data, current = ++token;
          note(data, "read", "begin", current);
          try {
            return typeof listener === "function" ? listener.call(this, event) : listener.handleEvent(event);
          } finally {
            note(data, "read", "end", current);
          }
        };
        listeners.set(listener, wrapped);
      }
      return add(type, wrapped);
    },
    removeEventListener(type, listener, ...options) {
      const wrapped = type === "message" ? listeners.get(listener) : void 0;
      if (type === "message") listeners.delete(listener);
      return remove(type, wrapped ?? listener, ...options);
    },
    terminate() {
      return native.terminate?.();
    }
  };
  return { endpoint, snapshot: () => ({
    realm,
    dropped,
    messageListeners: listeners.size,
    rows: rows.map((row) => ({ ...row }))
  }) };
}

// message-fixture.mjs
var worker = new Worker("/message-worker.mjs", { type: "module" });
var observation = observeMessages(worker, "main");
var engine;
var snapshots;
var encoded;
var size = 0;
var deadlineMs = 6e4;
var ready = (async () => {
  engine = await createWorkerRaveldex({
    worker: observation.endpoint,
    ownership: "external",
    sameHost: true,
    responseTimeoutMs: 12e4,
    configuration: {
      schema,
      addons: [createSourceProvider({ fields: ["body"] }), createSourcePhrases({ fields: ["body"] })]
    }
  });
  snapshots = createWorkerSnapshots(engine);
})();
window.messageControl = {
  ready: () => ready,
  async build(count) {
    await ready;
    if (![4, 1e3, 1e4].includes(count) || size) throw Error("Unsupported build state");
    const records = recordsFor(count);
    for (let i = 0; i < count; i += 256) await engine.addMany(records.slice(i, i + 256), { deadlineMs });
    size = count;
    return { size, revision: Math.ceil(count / 256) };
  },
  async run(kind) {
    await ready;
    if (kind === "empty") return engine.addMany([], { deadlineMs });
    if (kind === "search") {
      const result2 = await engine.search("red", { limit: 20, deadlineMs });
      if (result2.total !== size || result2.completeness !== "complete" || result2.hits.length !== Math.min(20, size) || result2.hits.some((hit) => !Number.isFinite(hit.score)))
        throw Error("Literal query verification failed");
      return result2;
    }
    if (kind === "export") {
      encoded = await snapshots.exportSource({ deadlineMs });
      return { codeUnits: encoded.length, encodedLengthIsNotMemory: true };
    }
    if (kind === "prior") {
      await engine.clear({ deadlineMs });
      await engine.add({ id: "prior", text: { body: "prior state" }, metadata: { group: "prior" } }, { deadlineMs });
      return engine.search({ kind: "all" }, { deadlineMs });
    }
    if (kind === "restore") {
      if (typeof encoded !== "string") throw Error("Export must precede restore");
      return snapshots.restore(encoded, { deadlineMs });
    }
    if (kind === "dispose") {
      await engine.dispose();
      engine = snapshots = encoded = void 0;
      return { disposed: true };
    }
    throw Error("Unknown operation");
  },
  observation: () => observation.snapshot(),
  release() {
    encoded = void 0;
    return { encodedReleased: true };
  },
  terminate() {
    worker.terminate();
    return { terminated: true };
  }
};
