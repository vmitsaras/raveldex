import sys,types,unittest
sys.modules['lldb']=types.SimpleNamespace();sys.modules['lldb_native_tap']=types.SimpleNamespace()
import receiver_copy_tap as module
from receiver_copy_tap import Receiver,ENTRY,COPY,COPY_RETURN,READER_RETURN
class Tests(unittest.TestCase):
 def setUp(self):
  self.r=Receiver(1,2,3,0x100000,'peer');self.wire=dict(ptr=0x800000,cap=512,allocation=1,chain=1,originTid=2);self.meta=dict(direction='main-to-worker',processId=1,peer='peer',session='s',id=4,operation='search',kind=None)
  self.entry=dict(pid=1,tid=3,pc=0x100000+ENTRY,sp=0x4000,lr=0x100000+READER_RETURN,owner=0xa00000,cursor=0x800060,end=0x800100)
  self.copy=dict(pid=1,tid=3,pc=0x100000+COPY,sp=0x4000-64,lr=0x100000+0x3de2b2c,owner=0xa00000,src=0x800061,dest=0x90000c,length=12,sourceRegister=0x800061,lengthRegister=12,handle=0xb00000,positionAfter=0x80006d,endAfter=0x800100)
  self.header=dict(tagged=0x900001,map=221,hash=3,units=6)
 def enter(self):self.r.enter(self.entry,self.wire,self.meta)
 def copied(self):self.enter();self.r.copy(self.copy,self.wire,self.header)
 def returned(self):self.copied();self.r.copy_return(dict(pid=1,tid=3,pc=0x100000+COPY_RETURN,sp=self.copy['sp'],lr=0x100000+COPY_RETURN,value=self.copy['dest']),self.wire)
 def test_literal_known_message_copy_and_complete_reader(self):
  self.returned();self.r.reader_return(dict(pid=1,tid=3,pc=0x100000+READER_RETURN,sp=0x4000,value=0xb00000),self.wire);d=self.r.report();self.assertTrue(d['valid']);self.assertEqual(d['completedCopies'],1);self.assertEqual(d['selectedCopiedBytes'],12);self.assertEqual(len(d['rows']),4)
 def test_wrong_pid_tid_lr_sp_refuse(self):
  for k in ['pid','tid','lr','sp']:
   self.setUp();e={**self.entry,k:self.entry[k]+1}
   with self.subTest(k=k),self.assertRaises(ValueError):self.r.enter(e,self.wire,self.meta)
 def test_wire_outside_extent_refuses(self):
  with self.assertRaises(ValueError):self.r.enter({**self.entry,'end':0x800201},self.wire,self.meta)
 def test_wrong_sender_receiver_peer_identity_refuses(self):
  for m in [{**self.meta,'direction':'worker-to-main'},{**self.meta,'peer':'foreign'},{**self.meta,'processId':99}]:
   self.setUp()
   with self.assertRaises(ValueError):self.r.enter(self.entry,self.wire,m)
 def test_nested_entry_refuses(self):
  self.enter()
  with self.assertRaises(ValueError):self.r.enter(self.entry,self.wire,self.meta)
 def test_copy_without_bound_entry_refuses(self):
  with self.assertRaises(ValueError):self.r.copy(self.copy,self.wire,self.header)
 def test_source_length_owner_sp_frame_bounds_refuse(self):
  for change in [{'length':11},{'length':0},{'src':0x800200},{'positionAfter':0x80006c},{'endAfter':0x800101},{'sourceRegister':0x800062},{'lengthRegister':14},{'owner':0xa00008},{'sp':0x4000-48},{'pc':0x100000+COPY+4}]:
   self.setUp();self.enter()
   with self.subTest(change=change),self.assertRaises(ValueError):self.r.copy({**self.copy,**change},self.wire,self.header)
 def test_stale_wire_generation_refuses_copy_and_return(self):
  self.enter()
  with self.assertRaises(ValueError):self.r.copy(self.copy,{**self.wire,'allocation':2},self.header)
  self.setUp();self.copied()
  with self.assertRaises(ValueError):self.r.copy_return(dict(pid=1,tid=3,pc=0x100000+COPY_RETURN,sp=self.copy['sp'],lr=0x100000+COPY_RETURN,value=self.copy['dest']),{**self.wire,'allocation':2})
 def test_destination_header_handle_or_overlap_refuses(self):
  for change in [{'map':222},{'hash':0},{'units':5},{'tagged':0x900000},{'tagged':0x800061}]:
   self.setUp();self.enter()
   with self.subTest(change=change),self.assertRaises(ValueError):self.r.copy(self.copy,self.wire,{**self.header,**change})
  self.setUp();self.enter()
  with self.assertRaises(ValueError):self.r.copy({**self.copy,'handle':0xb00001},self.wire,self.header)
 def test_return_wrong_pc_sp_lr_dest_refuses(self):
  for key in ['pc','sp','lr','value','tid']:
   self.setUp();self.copied();c=dict(pid=1,tid=3,pc=0x100000+COPY_RETURN,sp=self.copy['sp'],lr=0x100000+COPY_RETURN,value=self.copy['dest']);c[key]+=1
   with self.subTest(key=key),self.assertRaises(ValueError):self.r.copy_return(c,self.wire)
 def test_missing_copy_or_wrong_reader_handle_refuses(self):
  self.enter()
  with self.assertRaises(ValueError):self.r.reader_return(dict(pid=1,tid=3,pc=0x100000+READER_RETURN,sp=0x4000,value=0xb00000),self.wire)
  self.setUp();self.returned()
  with self.assertRaises(ValueError):self.r.reader_return(dict(pid=1,tid=3,pc=0x100000+READER_RETURN,sp=0x4000,value=0xb00008),self.wire)
 def test_pending_or_error_does_not_expose_copy_totals(self):
  self.enter();d=self.r.report();self.assertFalse(d['valid']);self.assertIsNone(d['selectedCopiedBytes']);self.r.problem('guard');self.assertIsNone(self.r.report()['completedCopies'])
 def test_zero_hit_is_only_empty_observation(self):
  d=self.r.report();self.assertTrue(d['valid']);self.assertEqual(d['completedCopies'],0);self.assertIn('Zero hits alone',d['scope'])
 def test_event_cap_refuses_and_nulls_counts(self):
  self.r.rows=[{'kind':'literal-control-row'}]*8192
  with self.assertRaises(ValueError):self.r.row('overflow')
  self.assertEqual(self.r.dropped,1);self.assertFalse(self.r.report()['valid'])
 def valid_base(self):
  module.STATE=self.r;module.rx=types.SimpleNamespace(INSTALLED=True,ACTIVE=True,INVALID=[],DROPPED=0,ROWS=[],BASE=0x100000,CONFIG=dict(pid=1,mainTid=2,workerTid=3,peer='peer'),TARGET=types.SimpleNamespace(GetProcess=lambda:types.SimpleNamespace(GetProcessID=lambda:1)))
 def completed(self):
  self.returned();self.r.reader_return(dict(pid=1,tid=3,pc=0x100000+READER_RETURN,sp=0x4000,value=0xb00000),self.wire)
 def test_inherited_invalid_drop_or_identity_nulls_existing_copy_totals(self):
  for key,value in [('INVALID',['lost']),('DROPPED',1),('INSTALLED',False),('ACTIVE',False),('BASE',0x200000)]:
   self.setUp();self.completed();self.valid_base();setattr(module.rx,key,value);d=module.checked_report()
   with self.subTest(key=key):self.assertFalse(d['valid']);self.assertIsNone(d['selectedCopiedBytes']);self.assertIsNone(d['completedCopies']);self.assertFalse(d['inheritedLedgerVerified'])
 def test_callback_fails_closed_before_reading_frame_when_base_invalid(self):
  self.valid_base();module.rx.INVALID=['bad'];self.assertFalse(module.callback(None,None,None));self.assertIn('Inherited observer invalid',self.r.invalid[0]);self.assertIsNone(self.r.report()['selectedCopiedBytes'])
 def test_valid_base_qualified_report_preserves_counts(self):
  self.completed();self.valid_base();d=module.checked_report();self.assertTrue(d['valid']);self.assertTrue(d['inheritedLedgerVerified']);self.assertEqual(d['selectedCopiedBytes'],12)
 def test_destination_in_unused_wire_tail_is_rejected(self):
  self.enter();dest=self.wire['ptr']+0x110
  with self.assertRaises(ValueError):self.r.copy({**self.copy,'dest':dest},self.wire,{**self.header,'tagged':dest-11})
if __name__=='__main__':unittest.main(verbosity=2)
