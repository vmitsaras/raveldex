"""One finite fresh ordinary-public-JS owner; read-only native callback capture.
No target expressions, native function invocation or expression-plan continuation.
"""
import argparse,hashlib,json,os,pathlib,re,signal,subprocess,sys,threading,time
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex')
CONSUMER=pathlib.Path('/private/var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz')
p=argparse.ArgumentParser(description=__doc__);p.add_argument('size',type=int,choices=(1000,10000));p.add_argument('repetition',type=int,choices=(0,1,2));a=p.parse_args()
name='product-'+str(a.size)+'-'+str(a.repetition);controller=ROOT/('controller-'+name);native=ROOT/('native-'+name);hostpath=ROOT/('host-'+name+'.json');assert not controller.exists() and not native.exists() and not hostpath.exists()
def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
host=dict(schema='raveldex-readonly-product-owner-host-v1',size=a.size,repetition=a.repetition,startedUnix=time.time(),status='Running',deadlineMs=60000,batchSize=256,publicFormat='raveldex-source',buildBeforeAttach=True,windows=[],sources={n:sha(ROOT/n) for n in ['run_product_owner.py','browser-message-observations.mjs','message-fixture.mjs','message-worker.mjs','message-observer.mjs','cost-fixture.mjs','browser-cdp.mjs','bounded-lldb.py','lldb_native_tap.py','receiver_copy_tap.py','one_byte_receiver_tap.py','receiver-hook-manifest.json','hook-manifest.json','wire_metadata.py']})
def save():hostpath.write_text(json.dumps(host,indent=2)+'\n')
class Output:
 def __init__(self,process,path,limit=4*1024*1024):
  self.process=process;self.data='';self.condition=threading.Condition();self.error=None;self.limit=limit;self.path=path
  self.thread=threading.Thread(target=self.read,daemon=True);self.thread.start()
 def read(self):
  try:
   with self.path.open('xb') as log:
    while True:
     raw=os.read(self.process.stdout.fileno(),65536)
     if not raw:break
     log.write(raw);log.flush()
     with self.condition:
      self.data+=raw.decode(errors='replace');assert len(self.data.encode())<=self.limit,'Host stdout bound';self.condition.notify_all()
  except Exception as error:self.error=str(error)
  finally:
   with self.condition:self.condition.notify_all()
 def wait(self,pattern,start=0,timeout=30):
  until=time.monotonic()+timeout
  with self.condition:
   while True:
    if self.error:raise RuntimeError(self.error)
    m=re.search(pattern,self.data[start:],re.S)
    if m:return start+m.end(),m
    if self.process.poll() is not None:raise RuntimeError('Owned process exited before expected output:'+pattern)
    remain=until-time.monotonic()
    if remain<=0:raise TimeoutError('Output wait:'+pattern)
    self.condition.wait(min(remain,.5))
 def json_command(self,command,timeout=150):
  start=len(self.data);self.process.stdin.write((json.dumps(command)+'\n').encode());self.process.stdin.flush();until=time.monotonic()+timeout
  with self.condition:
   while True:
    for line in self.data[start:].splitlines():
     try:value=json.loads(line)
     except Exception:continue
     if value.get('command')==command:return value
    if self.process.poll() is not None:raise RuntimeError('Controller ended during command')
    remain=until-time.monotonic()
    if remain<=0:raise TimeoutError('Ordinary application command timeout')
    self.condition.wait(min(remain,.5))
node=lldb=None;nodeout=debugout=None;stderr=None;attached=False;paused=False;owned=[]
try:
 env={**os.environ,'TMPDIR':str(ROOT/'tmp'),'PYTHONDONTWRITEBYTECODE':'1'}
 stderr=(ROOT/('stderr-'+name+'.log')).open('xb')
 argv=['node',str(ROOT/'browser-message-observations.mjs'),str(CONSUMER),str(controller)]
 node=subprocess.Popen(argv,cwd=REPO,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr);host['controllerHostPid']=node.pid;nodeout=Output(node,ROOT/('stdout-'+name+'.log'));save()
 _,m=nodeout.wait(r'(\{"ready":true[^\n]+)',timeout=30);ready=json.loads(m.group(1));report=json.loads((controller/'report.json').read_text());owned=[ready['browserPid'],ready['rendererPid']];host['ownedBrowserPid'],host['ownedRendererPid']=owned;host['pidProof']=ready['pidProof']
 for command in [dict(cmd='build',size=a.size),dict(cmd='gc')]:
  result=nodeout.json_command(command);assert not result.get('error'),result
 config=dict(pid=ready['rendererPid'],mainTid=next(x['tid'] for x in ready['pidProof']['marks'] if x['name'].endswith(':main')),workerTid=next(x['tid'] for x in ready['pidProof']['marks'] if x['name'].endswith(':worker')),peer=report['workerUrl'],output=str(native));configpath=ROOT/('config-'+name+'.json');configpath.write_text(json.dumps(config,indent=2)+'\n');host['config']=config;save()
 argv=[sys.executable,'-B',str(ROOT/'bounded-lldb.py'),'--config',str(configpath),'--timeout','300'];lldb=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);host['debuggerHostPid']=lldb.pid;debugout=Output(lldb,ROOT/('debug-console-'+name+'.log'));debugout.wait(r'RX_NATIVE_INSTALLED [0-9]+',timeout=30);attached=paused=True
 def debug(commands,pattern,timeout=30):
  start=len(debugout.data);lldb.stdin.write((commands+'\n').encode());lldb.stdin.flush();return debugout.wait(pattern,start,timeout)
 debug('rx-begin idle\ncommand script import '+str(ROOT/'receiver_copy_tap.py')+'\nrx-receiver-install read-only-owned-two-byte\ncommand script import '+str(ROOT/'one_byte_receiver_tap.py')+'\nrx-onebyte-install read-only-owned-one-byte','RX_ONEBYTE_READONLY_INSTALLED')
 def checkpoint(label):
  _,m=debug('rx-receiver-checkpoint '+label+'\nrx-onebyte-checkpoint '+label+'\nrx-end',r'RX_NATIVE_END ([^\r\n ]+) rows=([0-9]+) invalid=([0-9]+)')
  tap=pathlib.Path(m.group(1));n=json.loads(tap.read_text());one=json.loads((native/('onebyte-'+label+'.json')).read_text());two=json.loads((native/('receiver-'+label+'.json')).read_text());assert not n['invalid'] and not n['dropped'] and not n['pending'] and not n['remaining'];assert one['valid'] and two['valid'] and not one['pending'] and not two['pending']
  host['windows'].append(dict(label=label,nativePath=str(tap),nativeRows=len(n['rows']),oneByteBulkStrings=one['completedBulkStrings'],oneByteLogicalExtentBytes=one['selectedBulkLogicalExtentBytes'],twoByteCopies=two['completedCopies'],twoByteBytes=two['selectedCopiedBytes'],unboundEntries=dict(one=one['unboundEntries'],two=two['unboundEntries'])));save();return tap
 checkpoint('idle')
 def run_case(kind):
  global paused
  debug('rx-begin '+kind+'\ncontinue',r'Process '+str(config['pid'])+r' resuming');paused=False
  result=nodeout.json_command(dict(cmd='case',kind=kind),timeout=150);gc=nodeout.json_command(dict(cmd='gc'),timeout=60);assert not gc.get('error'),gc
  start=len(debugout.data);os.kill(lldb.pid,signal.SIGINT);debugout.wait(r'Process '+str(config['pid'])+r' stopped',start,timeout=15);paused=True
  checkpoint(kind);host['windows'][-1]['publicCommand']=result;save();print(json.dumps(dict(owner=name,operation=kind,result=result.get('result'),error=result.get('error'))),flush=True);return result
 export=run_case('export')
 if export.get('error'):
  assert export['error']['code'] in ('DEADLINE_EXCEEDED','WORK_LIMIT_EXCEEDED','LIMIT_EXCEEDED','RESOURCE_EXHAUSTED'),export
  host['dependentRestore']='Not run: source export rejected without an encoded snapshot'
 else:
  assert export['result']['publicOutcome']=='Pass' and export['result']['format']=='raveldex-source'
  prior=run_case('prior');assert not prior.get('error'),prior
  restored=run_case('restore');assert not restored.get('error'),restored
  assert restored['result']['publicOutcome'] in ('Pass','Rejected') and (restored['result']['publicOutcome']=='Pass' or restored['result']['priorStatePreserved'])
 search=run_case('search');assert not search.get('error'),search
 disposed=run_case('dispose');assert not disposed.get('error') and disposed['result']['disposed'] is True,disposed
 debug('rx-onebyte-cleanup\nrx-receiver-cleanup\nrx-cleanup\nprocess detach\nquit',r'Process '+str(config['pid'])+r' detached');attached=False;lldb.wait(timeout=15);assert lldb.returncode==0
 node.stdin.write(b'{"cmd":"close"}\n');node.stdin.flush();node.wait(timeout=20);assert node.returncode==0
 report=json.loads((controller/'report.json').read_text());assert report['ownedBrowserClosed'] and report['cleanupErrors']==[] and report['preservation']=='Pass'
 host['status']='Observed ordinary source-format operations; native/receiver raw checks passed';host['controllerExitCode']=node.returncode;host['debuggerExitCode']=lldb.returncode;host['ownedBrowserClosed']=True
except Exception as error:
 host['status']='Fail/measurement refused';host['error']=dict(type=type(error).__name__,message=str(error));save();raise
finally:
 if lldb is not None and lldb.poll() is None:
  try:
   if not paused:os.kill(lldb.pid,signal.SIGINT);time.sleep(.3)
   lldb.stdin.write(b'rx-onebyte-cleanup\nrx-receiver-cleanup\nrx-cleanup\nprocess detach\nquit\n');lldb.stdin.flush();lldb.wait(timeout=15)
  except Exception as error:host['debuggerCleanupError']=str(error)
 if node is not None and node.poll() is None:
  try:node.stdin.write(b'{"cmd":"close"}\n');node.stdin.flush();node.wait(timeout=20)
  except Exception as error:host['controllerCleanupError']=str(error)
 if owned:
  try:
   result=subprocess.run(['ps','-p',','.join(map(str,owned)),'-o','pid=,comm='],capture_output=True);(ROOT/('owned-after-'+name+'.log')).write_bytes(result.stdout+result.stderr);host['ownedProcessCheck']=dict(exitCode=result.returncode,outputBytes=len(result.stdout)+len(result.stderr));host['ownedProcessesAbsent']=result.returncode==1 and not result.stdout and not result.stderr
  except Exception as error:host['ownedProcessesAbsent']=False;host['ownedProcessCheckError']=str(error)
 try:host['sourcesUnchanged']=all(sha(ROOT/n)==digest for n,digest in host['sources'].items())
 except Exception as error:host['sourcesUnchanged']=False;host['sourceGuardError']=str(error)
 final_failures=[]
 if owned and not host.get('ownedProcessesAbsent'):final_failures.append('Owned process absence not verified')
 if not host['sourcesUnchanged']:final_failures.append('Executed source identity changed or unavailable')
 if host.get('debuggerCleanupError') or host.get('controllerCleanupError'):final_failures.append('Owned cleanup did not complete normally')
 if final_failures:host['status']='Fail/measurement refused';host['finalGuardFailures']=final_failures
 host['finishedUnix']=time.time();save()
 if stderr:stderr.close()
 if final_failures and sys.exc_info()[0] is None:raise SystemExit(1)
