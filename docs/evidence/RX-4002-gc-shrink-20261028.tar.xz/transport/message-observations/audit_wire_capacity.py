"""Offline requested-capacity frontier replay; no debugger/product imports.

This is a peak over selected, witnessed native wire extents at recorded native
frontiers, not a physical allocator or whole-process peak. In-place transitions
and API-only retirements deliberately refuse this version's qualification.
"""
import argparse
import hashlib
import json
from pathlib import Path

U64 = (1 << 64) - 1


def integer(value):
    assert type(value) is int and 0 <= value <= U64
    return value


def replay(record):
    assert record['schema'] == 'raveldex-lldb-buffer-observation-v2'
    assert record['dropped'] == 0 and not record['invalid'] and not record['pending']
    live = {}
    births = set()
    closed = set()
    peak = 0
    peak_rows = []
    chain_peaks = {}
    growth_bytes = 0
    moved = 0
    for seq, row in enumerate(record['rows'], 1):
        assert row['seq'] == seq and row['pid'] == record['pid']
        kind = row['kind']
        assert kind not in ('buffer-resize', 'api-only-retirement'), 'Unqualified transition semantics'
        if kind == 'buffer-live':
            ptr, cap, allocation, chain = (integer(row[k]) for k in ('ptr', 'cap', 'allocation', 'chain'))
            assert ptr > 0 and cap > 0 and ptr + cap <= U64
            assert ptr not in live and allocation not in births
            assert all(ptr + cap <= p or p + d['cap'] <= ptr for p, d in live.items())
            live[ptr] = dict(cap=cap, allocation=allocation, chain=chain)
            births.add(allocation)
        elif kind == 'buffer-confirmed':
            assert live[row['ptr']] == {k: row[k] for k in ('cap', 'allocation', 'chain')}
        elif kind in ('root-free-return', 'internal-free-return', 'final-free-return'):
            data = live.pop(row['ptr'])
            assert data == {k: row[k] for k in ('cap', 'allocation', 'chain')}
            assert data['allocation'] not in closed
            closed.add(data['allocation'])
        elif kind == 'copy-enter':
            assert row['src'] in live and row['dest'] not in live
            assert live[row['src']]['cap'] == row['oldCap']
            assert 0 <= row['length'] <= min(row['oldCap'], row['newCap'])
        elif kind == 'copy-return':
            assert row['src'] in live and row['dest'] in live
            assert row['returned'] == row['dest']
            growth_bytes += integer(row['length'])
            moved += 1
        elif kind == 'realloc-return':
            assert not (row['old'] and row['old'] == row['dest']), 'In-place requires separate qualification'
        total = sum(d['cap'] for d in live.values())
        assert total <= U64
        by_chain = {}
        for data in live.values():
            by_chain[data['chain']] = by_chain.get(data['chain'], 0) + data['cap']
        for chain, value in by_chain.items():
            chain_peaks[chain] = max(chain_peaks.get(chain, 0), value)
        if total > peak:
            peak = total
            peak_rows = [dict(seq=seq, kind=kind, window=row['window'], requestedBytes=total,
                              extents=[dict(ptr=p, **d) for p, d in sorted(live.items())])]
    assert not live and not record['remaining'] and births == closed
    assert set(chain_peaks) == {int(k) for k in record['bindings']}
    return dict(schema='raveldex-selected-native-wire-frontier-capacity-v1',
                status='BoundedPass', pid=record['pid'], rows=len(record['rows']),
                observedRequestedCapacityHighWaterBytes=peak, firstPeakWitness=peak_rows[0],
                births=len(births), observedReturnsRetiringExtents=len(closed), remaining=0,
                movedGrowthCopies=moved, movedGrowthCopiedExtentBytes=growth_bytes,
                inPlaceObserved=False,
                perChain=[dict(chain=k, observedRequestedCapacityHighWaterBytes=v,
                               metadata=record['bindings'][str(k)]) for k, v in sorted(chain_peaks.items())],
                limits=['Only selected protocol-bound native wire extents observed at native frontiers.',
                        'Old and new requested capacities overlap from witnessed growth destination until actual old-free return.',
                        'No allocator rounding, preexisting allocations, receiver managed destination lifetime, global physical peak, or SIMD store-volume claim.',
                        'Same-address reallocations and API-only retirements refuse qualification in this replay.',
                        'Requires separate raw frame/call-return/controller/source-identity qualification.'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('path')
    args = parser.parse_args()
    path = Path(args.path)
    raw = path.read_bytes()
    result = replay(json.loads(raw))
    result['source'] = str(path.resolve())
    result['sourceSha256'] = hashlib.sha256(raw).hexdigest()
    result['auditorSourceSha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    print(json.dumps(result, indent=2))
