import sys,types,unittest
sys.modules['lldb']=types.SimpleNamespace();sys.modules['lldb_native_tap']=types.SimpleNamespace()
import receiver_copy_tap as two
import one_byte_receiver_tap as module
from one_byte_receiver_tap import OneByte,ENTRY,FRONTIER,RETURN
class Tests(unittest.TestCase):
 def setUp(self):
  self.r=OneByte(1,2,3,0x100000,'peer');self.w=dict(ptr=0x800000,cap=512,allocation=1,chain=2,originTid=2);self.m=dict(direction='main-to-worker',processId=1,peer='peer',session='s',id=4,operation='search',kind=None)
  self.e=dict(pid=1,tid=3,pc=0x100000+ENTRY,sp=0x4000,lr=0x100000+RETURN,owner=0xa00000,src=0x800060,length=6,positionAfter=0x800066,end=0x800100,isolate=0xc00000,allocationType=0)
  self.c=dict(pid=1,tid=3,pc=0x100000+FRONTIER,sp=0x4000-48,src=0x800060,length=6,positionAfter=0x800066,endAfter=0x800100,dest=0x90000c,handle=0xb00000);self.h=dict(tagged=0x900001,map=261,hash=3,units=6)
 def enter(self):self.r.enter(self.e,self.w,self.m)
 def frontier(self):self.enter();self.r.frontier(self.c,self.w,self.h)
 def complete(self):self.frontier();self.r.returned(dict(pid=1,tid=3,pc=0x100000+RETURN,sp=0x4000,value=0xb00000),self.w)
 def base(self):
  module.STATE=self.r;module.rx=two.rx=types.SimpleNamespace(INSTALLED=True,ACTIVE=True,INVALID=[],DROPPED=0,ROWS=[],BASE=0x100000,CONFIG=dict(pid=1,mainTid=2,workerTid=3,peer='peer'),TARGET=types.SimpleNamespace(GetProcess=lambda:types.SimpleNamespace(GetProcessID=lambda:1)));two.STATE=two.Receiver(1,2,3,0x100000,'peer');two.INSTALLED=True
 def test_literal_bulk_frontier_and_actual_factory_return(self):self.complete();d=self.r.report();self.assertTrue(d['valid']);self.assertEqual(d['completedBulkStrings'],1);self.assertEqual(d['selectedBulkLogicalExtentBytes'],6);self.assertFalse(d['rows'][1]['actualStoreTrafficMeasured'])
 def test_empty_and_single_bypass_bulk_frontier(self):
  for n in (0,1):
   self.setUp();self.e.update(length=n,positionAfter=self.e['src']+n);self.enter();value=self.e['isolate']+0x3a0 if n==0 else 0xb00000;self.r.returned(dict(pid=1,tid=3,pc=0x100000+RETURN,sp=0x4000,value=value),self.w);d=self.r.report();self.assertEqual(d['completedBulkStrings'],0);self.assertEqual(d['selectedBulkLogicalExtentBytes'],0);self.assertEqual(d['nonBulkLengthZero']+d['nonBulkLengthOne'],1)
 def test_empty_root_handle_mismatch_refuses(self):
  self.e.update(length=0,positionAfter=self.e['src']);self.enter()
  with self.assertRaises(ValueError):self.r.returned(dict(pid=1,tid=3,pc=0x100000+RETURN,sp=0x4000,value=0xb00000),self.w)
 def test_entry_wrong_pc_tid_lr_position_type_refuses(self):
  for change in [{'pc':self.e['pc']+4},{'tid':2},{'lr':self.e['lr']+4},{'positionAfter':0x800067},{'allocationType':1},{'length':-1},{'end':0x800201}]:
   self.setUp()
   with self.subTest(change=change),self.assertRaises(ValueError):self.r.enter({**self.e,**change},self.w,self.m)
 def test_wrong_direction_or_peer_refuses(self):
  for change in [{'direction':'worker-to-main'},{'peer':'foreign'},{'processId':99}]:
   self.setUp()
   with self.assertRaises(ValueError):self.r.enter(self.e,self.w,{**self.m,**change})
 def test_missing_or_nested_entry_refuses(self):
  with self.assertRaises(ValueError):self.r.frontier(self.c,self.w,self.h)
  self.enter()
  with self.assertRaises(ValueError):self.r.enter(self.e,self.w,self.m)
 def test_frontier_bad_frame_source_length_handle_refuses(self):
  for change in [{'sp':self.c['sp']+16},{'src':0x800061},{'length':7},{'handle':0xb00001},{'dest':0x90000d},{'endAfter':0x800101}]:
   self.setUp();self.enter()
   with self.assertRaises(ValueError):self.r.frontier({**self.c,**change},self.w,self.h)
 def test_header_mismatch_or_wire_tail_overlap_refuses(self):
  for change in [{'map':221},{'hash':0},{'units':7}]:
   self.setUp();self.enter()
   with self.assertRaises(ValueError):self.r.frontier(self.c,self.w,{**self.h,**change})
  self.setUp();self.enter();dest=self.w['ptr']+0x110
  with self.assertRaises(ValueError):self.r.frontier({**self.c,'dest':dest},self.w,{**self.h,'tagged':dest-11})
 def test_stale_generation_or_return_handle_refuses(self):
  self.enter()
  with self.assertRaises(ValueError):self.r.frontier(self.c,{**self.w,'allocation':2},self.h)
  self.setUp();self.frontier()
  with self.assertRaises(ValueError):self.r.returned(dict(pid=1,tid=3,pc=0x100000+RETURN,sp=0x4000,value=0xb00008),self.w)
 def test_bulk_return_without_frontier_refuses(self):
  self.enter()
  with self.assertRaises(ValueError):self.r.returned(dict(pid=1,tid=3,pc=0x100000+RETURN,sp=0x4000,value=0xb00000),self.w)
 def test_inherited_invalid_drop_and_companion_failure_null_totals(self):
  for key in ['INVALID','DROPPED','INSTALLED']:
   self.setUp();self.complete();self.base();setattr(module.rx,key,['lost'] if key=='INVALID' else 1 if key=='DROPPED' else False);d=module.checked_report();self.assertFalse(d['valid']);self.assertIsNone(d['selectedBulkLogicalExtentBytes'])
  self.setUp();self.complete();self.base();two.STATE.problem('lost receiver');self.assertIsNone(module.checked_report()['completedBulkStrings'])
 def test_valid_base_preserves_counts(self):self.complete();self.base();d=module.checked_report();self.assertTrue(d['valid']);self.assertEqual(d['selectedBulkLogicalExtentBytes'],6)
 def test_pending_error_or_event_overflow_null_totals(self):
  self.enter();self.assertIsNone(self.r.report()['selectedBulkLogicalExtentBytes']);self.r.problem('bad');self.assertFalse(self.r.report()['valid']);self.setUp();self.r.rows=[{'kind':'control'}]*16384
  with self.assertRaises(ValueError):self.r.row('overflow')
  self.assertEqual(self.r.dropped,1);self.assertIsNone(self.r.report()['completedBulkStrings'])
if __name__=='__main__':unittest.main(verbosity=2)
