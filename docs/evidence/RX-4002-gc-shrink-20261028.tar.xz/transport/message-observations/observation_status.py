"""Host-only read-only stop/ledger status; no target expression or function call."""
import hashlib,json,pathlib,signal
import lldb
import lldb_native_tap as rx
import receiver_copy_tap as two
import one_byte_receiver_tap as one

def qualify(s):
 failures=[]
 if s['actualPid']!=s['expectedPid'] or not s['processStopped']:failures.append('Wrong owned PID or process not stopped')
 if not any(t['reason']=='signal' and t['signal']==int(signal.SIGSTOP) for t in s['threads']):failures.append('No actual SIGSTOP thread reason')
 ids={t['tid'] for t in s['threads']}
 if s['mainTid'] not in ids or s['workerTid'] not in ids or s['selectedTid'] not in ids:failures.append('Actual peer/selected threads missing')
 if not s['installed'] or not s['active'] or s['baseErrors'] or s['baseDropped'] or s['basePending'] or s['baseLive']:failures.append('Inherited ledger not complete/drained/valid')
 if not s['oneValid'] or not s['twoValid'] or s['onePending'] or s['twoPending']:failures.append('Receiver ledger not complete/drained/valid')
 return failures

def status(debugger,command,result,_):
 try:
  if command.strip()!='owned-sigstop-and-drained':raise ValueError('Explicit owned-sigstop-and-drained required')
  process=debugger.GetSelectedTarget().GetProcess();count=process.GetNumThreads()
  if not 0<count<=128:raise ValueError('Thread inventory bound')
  threads=[]
  for index in range(count):
   thread=process.GetThreadAtIndex(index);reason=thread.GetStopReason();sig=thread.GetStopReasonDataAtIndex(0) if reason==lldb.eStopReasonSignal and thread.GetStopReasonDataCount() else None
   threads.append(dict(tid=thread.GetThreadID(),reason='signal' if reason==lldb.eStopReasonSignal else str(reason),signal=sig))
  first=one.checked_report();second=two.checked_report()
  snapshot=dict(actualPid=process.GetProcessID(),expectedPid=rx.CONFIG['pid'],processStopped=process.GetState()==lldb.eStateStopped,selectedTid=process.GetSelectedThread().GetThreadID(),mainTid=rx.CONFIG['mainTid'],workerTid=rx.CONFIG['workerTid'],threads=threads,installed=rx.INSTALLED,active=rx.ACTIVE,baseErrors=len(rx.INVALID),baseDropped=rx.DROPPED,basePending=sum(len(v) for v in rx.CALLS.values()),baseLive=len(rx.LIVE),oneValid=first['valid'],twoValid=second['valid'],onePending=len(one.STATE.pending),twoPending=len(two.STATE.pending))
  failures=qualify(snapshot);snapshot.update(schema='raveldex-owned-sigstop-status-v1',qualified=not failures,failures=failures,sourceSha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
  result.PutCString('RX_OBSERVATION_STATUS '+json.dumps(snapshot))
 except Exception as error:result.SetError(str(error))
def __lldb_init_module(debugger,_):debugger.HandleCommand('command script add -f observation_status.status rx-observation-status')
