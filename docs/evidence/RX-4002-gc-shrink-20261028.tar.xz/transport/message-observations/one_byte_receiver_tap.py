"""Read-only normal-message OneByte factory/frontier/return callbacks.
Tracks logical copied string extents, never actual overlapping store traffic.
No target expressions, function invocation, writes or process continuation.
"""
import hashlib,json,pathlib,time
import lldb
import lldb_native_tap as rx
import receiver_copy_tap as two
from wire_metadata import decode,PrefixError
ROOT=pathlib.Path(__file__).resolve().parent
ENTRY,FRONTIER,RETURN=0x5212c8,0x521388,0x166c230
STATE=None
BPS=[]
INSTALLED=False
need=two.need
class OneByte:
 def __init__(self,pid,main,worker,base,peer):
  self.pid,self.main,self.worker,self.base,self.peer=pid,main,worker,base,peer;self.rows=[];self.pending={};self.invalid=[];self.dropped=0;self.unbound=0
 def problem(self,why):
  if len(self.invalid)<128:self.invalid.append(str(why))
 def row(self,kind,**fields):
  if len(self.rows)>=16384:self.dropped+=1;raise ValueError('OneByte row bound')
  self.rows.append(dict(seq=len(self.rows)+1,kind=kind,pid=self.pid,wallNs=time.time_ns(),nativeLedgerSequence=len(rx.ROWS) if isinstance(getattr(rx,'ROWS',None),list) else None,**fields))
 def enter(self,c,wire,metadata):
  tid=c['tid'];need(c['pid']==self.pid and tid in (self.main,self.worker),'Wrong OneByte PID/TID')
  need(c['pc']==self.base+ENTRY and c['lr']==self.base+RETURN and c['sp']>0 and c['sp']%16==0,'OneByte entry frame mismatch')
  need(tid not in self.pending and len(self.pending)<64,'Nested OneByte/pending bound')
  need(type(c['length']) is int and 0<=c['length']<=64*1024**2 and c['allocationType']==0,'OneByte length/allocation mismatch')
  need(wire['ptr']<=c['src'] and c['src']+c['length']==c['positionAfter']<=c['end']<=wire['ptr']+wire['cap'] and wire['ptr']<c['end'],'OneByte source/position/wire mismatch')
  sender=self.main if metadata['direction']=='main-to-worker' else self.worker;receiver=self.worker if metadata['direction']=='main-to-worker' else self.main
  need(wire['originTid']==sender and tid==receiver and metadata['processId']==self.pid and metadata['peer']==self.peer,'OneByte message thread/identity mismatch')
  self.pending[tid]=dict(entry=dict(c),wire=dict(wire),metadata=dict(metadata),frontier=None);self.row('onebyte-factory-entry',frame=dict(c),wire=dict(wire),metadata=dict(metadata))
 def frontier(self,c,wire,header):
  ctx=self.pending.get(c['tid']);need(ctx is not None and ctx['frontier'] is None,'OneByte frontier without entry')
  e=ctx['entry'];need(e['length']>1,'Empty/single-byte path is not selected bulk copy')
  need(c['pid']==self.pid and c['pc']==self.base+FRONTIER and c['sp']==e['sp']-48,'OneByte frontier frame mismatch')
  need(wire==ctx['wire'] and c['src']==e['src'] and c['length']==e['length'] and c['positionAfter']==e['positionAfter'] and c['endAfter']==e['end'],'OneByte source/generation changed')
  need(0<c['handle']<2**53 and c['handle']%8==0 and header['tagged']%2==1 and 0<header['tagged']<2**53-e['length']-11,'Invalid OneByte handle/pointer')
  need(c['dest']==header['tagged']+11 and header['map']==261 and header['hash']==3 and header['units']==e['length'],'OneByte destination/header mismatch')
  need(c['dest']+e['length']<=wire['ptr'] or wire['ptr']+wire['cap']<=c['dest'],'OneByte destination overlaps wire capacity')
  ctx['frontier']=dict(c);ctx['header']=dict(header);self.row('onebyte-bulk-frontier',frame=dict(c),wire=dict(wire),metadata=ctx['metadata'],destinationHeader=dict(header),logicalCopiedExtentBytes=e['length'],actualStoreTrafficMeasured=False)
 def returned(self,c,wire):
  ctx=self.pending.get(c['tid']);need(ctx is not None,'OneByte return without entry');e=ctx['entry']
  need(c['pid']==self.pid and c['pc']==self.base+RETURN and c['sp']==e['sp'] and 0<c['value']<2**53 and c['value']%8==0,'OneByte return frame/handle mismatch')
  need(wire==ctx['wire'],'OneByte return wire generation changed')
  if e['length']>1:need(ctx['frontier'] is not None and c['value']==ctx['frontier']['handle'],'OneByte return omitted/changed bulk handle')
  else:need(ctx['frontier'] is None,'Unexpected empty/single-byte bulk frontier')
  if e['length']==0:need(c['value']==e['isolate']+0x3a0,'Empty-string root handle mismatch')
  self.row('onebyte-factory-return',frame=dict(c),wire=dict(wire),metadata=ctx['metadata'],logicalCopiedExtentBytes=e['length'] if e['length']>1 else 0,inputLength=e['length'],selectedBulk=e['length']>1,scope='OneByte bulk logical extent; n0/n1 bypass selected bulk frontier, not zero-allocation or zero-store claims')
  del self.pending[c['tid']]
 def report(self):
  done=[r for r in self.rows if r['kind']=='onebyte-factory-return'];valid=not self.invalid and not self.dropped and not self.pending
  return dict(schema='raveldex-readonly-one-byte-receiver-v1',pid=self.pid,peer=self.peer,valid=valid,invalid=self.invalid,dropped=self.dropped,pending=self.pending,unboundEntries=self.unbound,rows=self.rows,completedBulkStrings=sum(r['selectedBulk'] for r in done) if valid else None,selectedBulkLogicalExtentBytes=sum(r['logicalCopiedExtentBytes'] for r in done) if valid else None,nonBulkLengthZero=sum(r['inputLength']==0 for r in done) if valid else None,nonBulkLengthOne=sum(r['inputLength']==1 for r in done) if valid else None,scope='Read-only normal-message OneByte bulk string frontier/factory-return, exact owned wire metadata/gen and tagged-header witness. Inline stores can overlap: logical copied extents are not actual store traffic, full payload counts, allocator extents or global/native/physical peaks.')

def base_problem():
 why=two.inherited_problem()
 if why:return why
 if not two.INSTALLED or two.STATE.invalid or two.STATE.dropped:return 'TwoByte companion not installed or invalid/dropped'
 if STATE is None or (STATE.pid,STATE.main,STATE.worker,STATE.base,STATE.peer)!=(two.STATE.pid,two.STATE.main,two.STATE.worker,two.STATE.base,two.STATE.peer):return 'OneByte companion exact identity mismatch'
 return None
def checked_report():
 why=base_problem()
 if why:STATE.problem(why)
 record=STATE.report();record['inheritedLedgerVerified']=why is None;return record
def wire_for(src,end):
 hits=[p for p,d in rx.LIVE.items() if p<end and p<=src<=end<=p+d['cap']];need(len(hits)<=1,'Ambiguous OneByte source wire');return two.wire_value(hits[0]) if hits else None
def callback(frame,location,_):
 if STATE is None or not rx.ACTIVE or STATE.invalid or STATE.dropped:return False
 why=base_problem()
 if why:STATE.problem(why);return False
 try:
  c=two.regs(frame);offset=c['pc']-rx.BASE;tid=c['tid']
  if offset==ENTRY:
   if c['lr']!=rx.BASE+RETURN:return False
   owner=rx.reg(frame,'x19');src=rx.reg(frame,'x1');n=rx.reg(frame,'x2');bounds=two.read(owner+16,16);position=int.from_bytes(bounds[:8],'little');end=int.from_bytes(bounds[8:],'little');wire=wire_for(src,end)
   if wire is None:STATE.unbound+=1;return False
   try:metadata=decode(lambda o,n:two.read(wire['ptr']+o,n),end-wire['ptr'])
   except PrefixError:STATE.unbound+=1;return False
   metadata.update(peer=rx.CONFIG['peer'],processId=rx.CONFIG['pid']);c.update(owner=owner,src=src,length=n,positionAfter=position,end=end,isolate=rx.reg(frame,'x0'),allocationType=rx.reg(frame,'x3'));need(int.from_bytes(two.read(owner,8),'little')==c['isolate'],'Caller isolate mismatch');STATE.enter(c,wire,metadata)
  elif tid in STATE.pending:
   ctx=STATE.pending[tid];wire=two.wire_value(ctx['wire']['ptr'])
   if offset==FRONTIER:
    c.update(src=rx.reg(frame,'x20'),length=rx.reg(frame,'x19'),dest=rx.reg(frame,'x8'),handle=rx.reg(frame,'x0'));bounds=two.read(ctx['entry']['owner']+16,16);c.update(positionAfter=int.from_bytes(bounds[:8],'little'),endAfter=int.from_bytes(bounds[8:],'little'));tagged=int.from_bytes(two.read(c['handle'],8),'little');header=two.read(tagged-1,12);STATE.frontier(c,wire,dict(tagged=tagged,map=int.from_bytes(header[:4],'little'),hash=int.from_bytes(header[4:8],'little'),units=int.from_bytes(header[8:12],'little')))
   elif offset==RETURN:c['value']=rx.reg(frame,'x0');STATE.returned(c,wire)
 except Exception as error:STATE.problem(type(error).__name__+':'+str(error))
 return False

def install(debugger,command,result,_):
 global STATE,INSTALLED
 try:
  need(command.strip()=='read-only-owned-one-byte' and not INSTALLED and two.INSTALLED,'Fresh OneByte install requires TwoByte companion')
  need(two.inherited_problem() is None and rx.TARGET.GetProcess().GetState()==lldb.eStateStopped,'Owned observer must be valid active and paused')
  m=json.loads((ROOT/'receiver-hook-manifest.json').read_text())
  for site in m['sites']:
   expected=bytes.fromhex(site['bytesHex']);need(two.read(rx.BASE+int(site['moduleOffset'],16),len(expected),code=True)==expected,'OneByte code fingerprint mismatch')
  STATE=OneByte(rx.CONFIG['pid'],rx.CONFIG['mainTid'],rx.CONFIG['workerTid'],rx.BASE,rx.CONFIG['peer'])
  for offset in (ENTRY,FRONTIER,RETURN):
   bp=rx.TARGET.BreakpointCreateByAddress(rx.BASE+offset);need(bp.GetNumLocations()==1,'OneByte unresolved breakpoint');BPS.append(bp);error=bp.SetScriptCallbackFunction('one_byte_receiver_tap.callback');need(not isinstance(error,lldb.SBError) or not error.Fail(),'OneByte callback registration failed')
  INSTALLED=True;result.PutCString('RX_ONEBYTE_READONLY_INSTALLED')
 except Exception as error:
  for bp in BPS:rx.TARGET.BreakpointDelete(bp.GetID())
  BPS.clear();result.SetError(str(error))
def checkpoint(debugger,command,result,_):
 try:
  need(INSTALLED and command and len(command)<=64 and all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in command),'Bad OneByte checkpoint label')
  record=checked_report();record.update(sourceSha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),companionSha256=hashlib.sha256((ROOT/'receiver_copy_tap.py').read_bytes()).hexdigest(),inheritedObserverSha256=hashlib.sha256((ROOT/'lldb_native_tap.py').read_bytes()).hexdigest(),manifestSha256=hashlib.sha256((ROOT/'receiver-hook-manifest.json').read_bytes()).hexdigest(),savedUnix=time.time())
  p=rx.OUT/('onebyte-'+command+'.json')
  with p.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
  result.PutCString(json.dumps(dict(path=str(p),valid=record['valid'],completedBulkStrings=record['completedBulkStrings'],logicalBytes=record['selectedBulkLogicalExtentBytes'],invalid=record['invalid'],pending=len(record['pending']))))
 except Exception as error:result.SetError(str(error))
def cleanup(debugger,command,result,_):
 global INSTALLED
 for bp in BPS:rx.TARGET.BreakpointDelete(bp.GetID())
 BPS.clear();INSTALLED=False;result.PutCString('RX_ONEBYTE_HOOKS_REMOVED')
def __lldb_init_module(debugger,_):
 for n,f in [('rx-onebyte-install','install'),('rx-onebyte-checkpoint','checkpoint'),('rx-onebyte-cleanup','cleanup')]:debugger.HandleCommand('command script add -f one_byte_receiver_tap.'+f+' '+n)
