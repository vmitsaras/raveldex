"""Read-only native callbacks for normal two-byte receiver copies.
No target expressions, target calls, argument writes or process continuation.
"""
import hashlib,json,pathlib,time
import lldb
import lldb_native_tap as rx
from wire_metadata import decode,PrefixError
ROOT=pathlib.Path(__file__).resolve().parent
ENTRY,COPY,COPY_RETURN,READER_RETURN=0x3de2aa8,0x3de2b48,0x3de2b4c,0x166c970
STATE=None
BPS=[]
INSTALLED=False

def need(test,message):
 if not test:raise ValueError(message)
class Receiver:
 def __init__(self,pid,main,worker,base,peer):
  need(all(type(x) is int and 0<x<2**53 for x in (pid,main,worker,base)) and main!=worker,'Invalid owned context')
  self.pid,self.main,self.worker,self.base,self.peer=pid,main,worker,base,peer;self.pending={};self.rows=[];self.invalid=[];self.dropped=0;self.unbound=0
 def problem(self,why):
  if len(self.invalid)<128:self.invalid.append(str(why))
 def row(self,kind,**fields):
  if len(self.rows)>=8192:self.dropped+=1;raise ValueError('Receiver row cap')
  self.rows.append(dict(seq=len(self.rows)+1,kind=kind,pid=self.pid,wallNs=time.time_ns(),nativeLedgerSequence=len(rx.ROWS) if isinstance(getattr(rx,'ROWS',None),list) else None,**fields))
 def enter(self,c,wire,metadata):
  tid=c['tid'];need(c['pid']==self.pid and tid in (self.main,self.worker),'Wrong receiver PID/TID')
  need(c['pc']==self.base+ENTRY and c['lr']==self.base+READER_RETURN and c['sp']>0 and c['sp']%16==0,'Reader entry frame mismatch')
  need(tid not in self.pending and len(self.pending)<64,'Nested/pending receiver cap')
  need(wire['ptr']<=c['cursor']<c['end']<=wire['ptr']+wire['cap'] and c['end']-wire['ptr']<=64*1024**2,'Reader outside tracked wire')
  expectedSender=self.main if metadata['direction']=='main-to-worker' else self.worker
  expectedReceiver=self.worker if metadata['direction']=='main-to-worker' else self.main
  need(wire['originTid']==expectedSender and tid==expectedReceiver,'Receiver direction/thread mismatch')
  need(metadata['processId']==self.pid and metadata['peer']==self.peer,'Wire metadata ownership mismatch')
  ctx=dict(c);ctx.update(wire=dict(wire),metadata=dict(metadata),stage='Entered',copy=None)
  self.pending[tid]=ctx;self.row('reader-entry',frame=dict(c),wire=dict(wire),metadata=dict(metadata))
 def copy(self,c,wire,header):
  ctx=self.pending.get(c['tid']);need(ctx is not None and ctx['stage']=='Entered','Copy without one reader entry')
  need(c['pid']==self.pid and c['pc']==self.base+COPY and c['sp']==ctx['sp']-64 and c['owner']==ctx['owner'],'Copy frame/owner mismatch')
  need(wire==ctx['wire'],'Wire generation/capacity changed')
  n=c['length'];src=c['src'];dest=c['dest'];need(type(n) is int and 0<n<=64*1024**2 and n%2==0,'Invalid two-byte copy length')
  need(src==c['sourceRegister'] and n==c['lengthRegister'] and 1<=src-ctx['cursor']<=5,'Source/varint frontier mismatch')
  need(ctx['wire']['ptr']<=src and src+n<=ctx['end'] and c['positionAfter']==src+n and c['endAfter']==ctx['end'],'Copy exceeds exact deserializer/wire frontier')
  need(c['handle']>0 and c['handle']%8==0 and header['tagged']%2==1 and 0<header['tagged']<2**53-n-11,'Invalid new factory handle/pointer')
  need(dest==header['tagged']+11 and header['map']==221 and header['hash']==3 and header['units']==n//2,'Destination metadata/representation mismatch')
  need(dest+n<=ctx['wire']['ptr'] or ctx['wire']['ptr']+ctx['wire']['cap']<=dest,'Wire and managed destination overlap')
  ctx['copy']=dict(c);ctx['header']=dict(header);ctx['stage']='CopyEntered'
  self.row('receiver-copy-enter',frame=dict(c),wire=dict(wire),metadata=ctx['metadata'],destinationHeader=dict(header),scope='Selected memcpy requested byte count; destination header witness, not managed/native/global/physical occupied extent metric')
 def copy_return(self,c,wire):
  ctx=self.pending.get(c['tid']);need(ctx is not None and ctx['stage']=='CopyEntered','Copy return without entry')
  copy=ctx['copy'];need(c['pid']==self.pid and c['pc']==self.base+COPY_RETURN and c['sp']==copy['sp'] and c['lr']==self.base+COPY_RETURN,'Copy return frame mismatch')
  need(wire==ctx['wire'] and c['value']==copy['dest'],'Copy return pointer/generation mismatch')
  ctx['stage']='CopyReturned';self.row('receiver-copy-return',frame=dict(c),entry=copy,wire=dict(wire),metadata=ctx['metadata'])
 def reader_return(self,c,wire):
  ctx=self.pending.get(c['tid']);need(ctx is not None and ctx['stage']=='CopyReturned','Reader returned without completed selected copy')
  need(c['pid']==self.pid and c['pc']==self.base+READER_RETURN and c['sp']==ctx['sp'] and c['value']==ctx['copy']['handle'],'Reader return frame/handle mismatch')
  need(wire==ctx['wire'],'Reader wire generation changed before completion')
  self.row('reader-return',frame=dict(c),copyBytes=ctx['copy']['length'],wire=dict(wire),metadata=ctx['metadata']);del self.pending[c['tid']]
 def report(self):
  copies=[r for r in self.rows if r['kind']=='reader-return']
  valid=not self.invalid and not self.dropped and not self.pending
  return dict(schema='raveldex-readonly-two-byte-receiver-v1',pid=self.pid,peer=self.peer,valid=valid,invalid=self.invalid,dropped=self.dropped,pending=self.pending,unboundEntries=self.unbound,rows=self.rows,completedCopies=len(copies) if valid else None,selectedCopiedBytes=sum(r['copyBytes'] for r in copies) if valid else None,scope='Normal public-JS messages, read-only native callbacks. Selected two-byte receiver copy calls and factory/header/return witnesses only; no one-byte receiver/full payload/global/native/physical peak qualification. Zero hits alone is not a positive two-byte calibration.')

def regs(frame):return dict(pid=frame.GetThread().GetProcess().GetProcessID(),tid=frame.GetThread().GetThreadID(),pc=frame.GetPC(),sp=rx.reg(frame,'sp'),lr=rx.reg(frame,'lr'))
def read(address,size,code=False):
 need(0<address<2**53 and 0<size<=(4096 if code else 256),'Code/metadata read bound');error=lldb.SBError();b=rx.TARGET.GetProcess().ReadMemory(address,size,error);need(not error.Fail() and len(b)==size,'Selected metadata unreadable');return b
def wire_value(ptr):
 data=rx.LIVE.get(ptr);need(data is not None,'Tracked wire no longer live');return dict(ptr=ptr,cap=data['cap'],allocation=data['allocation'],chain=data['chain'],originTid=data['originTid'])
def wire_for(cursor,end):
 hits=[ptr for ptr,v in rx.LIVE.items() if ptr<=cursor<end<=ptr+v['cap']]
 need(len(hits)<=1,'Ambiguous receiver source wire');return wire_value(hits[0]) if hits else None
def inherited_problem():
 try:
  if not rx.INSTALLED or not rx.ACTIVE:return 'Inherited observer not installed/active'
  if not isinstance(getattr(rx,'ROWS',None),list):return 'Inherited event ledger unavailable'
  if rx.INVALID or rx.DROPPED:return 'Inherited observer invalid or dropped records'
  if rx.TARGET.GetProcess().GetProcessID()!=STATE.pid or rx.BASE!=STATE.base or rx.CONFIG['pid']!=STATE.pid or rx.CONFIG['mainTid']!=STATE.main or rx.CONFIG['workerTid']!=STATE.worker or rx.CONFIG['peer']!=STATE.peer:return 'Inherited exact identity changed'
 except Exception as error:return 'Inherited identity unavailable:'+type(error).__name__
 return None
def checked_report():
 why=inherited_problem()
 if why:STATE.problem(why)
 record=STATE.report();record['inheritedLedgerVerified']=why is None
 return record
def callback(frame,location,internal_dict):
 if STATE is None or not rx.ACTIVE or STATE.invalid or STATE.dropped:return False
 why=inherited_problem()
 if why:STATE.problem(why);return False
 try:
  c=regs(frame);offset=c['pc']-rx.BASE;tid=c['tid']
  if offset==ENTRY:
   if c['lr']!=rx.BASE+READER_RETURN:return False
   owner=rx.reg(frame,'x0');bounds=read(owner+16,16);cursor=int.from_bytes(bounds[:8],'little');end=int.from_bytes(bounds[8:],'little');wire=wire_for(cursor,end)
   if wire is None:STATE.unbound+=1;return False
   c.update(owner=owner,cursor=cursor,end=end)
   try:metadata=decode(lambda offset,count:read(wire['ptr']+offset,count),end-wire['ptr'])
   except PrefixError:STATE.unbound+=1;return False
   metadata.update(peer=rx.CONFIG['peer'],processId=rx.CONFIG['pid'])
   STATE.enter(c,wire,metadata)
  elif tid in STATE.pending:
   ctx=STATE.pending[tid];wire=wire_value(ctx['wire']['ptr'])
   if offset==COPY:
    c.update(owner=rx.reg(frame,'x19'),src=rx.reg(frame,'x1'),dest=rx.reg(frame,'x0'),length=rx.reg(frame,'x2'),sourceRegister=rx.reg(frame,'x23'),lengthRegister=rx.reg(frame,'x21'),handle=rx.reg(frame,'x22'))
    bounds=read(c['owner']+16,16);c.update(positionAfter=int.from_bytes(bounds[:8],'little'),endAfter=int.from_bytes(bounds[8:],'little'))
    tagged=int.from_bytes(read(c['handle'],8),'little');raw=read(tagged-1,12);header=dict(tagged=tagged,map=int.from_bytes(raw[:4],'little'),hash=int.from_bytes(raw[4:8],'little'),units=int.from_bytes(raw[8:12],'little'));STATE.copy(c,wire,header)
   elif offset==COPY_RETURN:c['value']=rx.reg(frame,'x0');STATE.copy_return(c,wire)
   elif offset==READER_RETURN:c['value']=rx.reg(frame,'x0');STATE.reader_return(c,wire)
 except Exception as error:STATE.problem(type(error).__name__+':'+str(error))
 return False

def install(debugger,command,result,_):
 global STATE,INSTALLED
 try:
  need(command.strip()=='read-only-owned-two-byte' and not INSTALLED,'Explicit fresh install required')
  need(rx.INSTALLED and rx.TARGET.GetProcess().GetProcessID()==rx.CONFIG['pid'],'Inherited owned observer required')
  m=json.loads((ROOT/'receiver-hook-manifest.json').read_text())
  need(rx.TARGET.GetProcess().GetState()==lldb.eStateStopped,'Install only while owned target paused')
  for site in m['sites']:
   expected=bytes.fromhex(site['bytesHex']);need(read(rx.BASE+int(site['moduleOffset'],16),len(expected),code=True)==expected,'Receiver code fingerprint mismatch:'+site['name'])
  STATE=Receiver(rx.CONFIG['pid'],rx.CONFIG['mainTid'],rx.CONFIG['workerTid'],rx.BASE,rx.CONFIG['peer'])
  for offset in (ENTRY,COPY,COPY_RETURN,READER_RETURN):
   bp=rx.TARGET.BreakpointCreateByAddress(rx.BASE+offset);need(bp.GetNumLocations()==1,'Unresolved receiver hook');BPS.append(bp);error=bp.SetScriptCallbackFunction('receiver_copy_tap.callback');need(not isinstance(error,lldb.SBError) or not error.Fail(),'Receiver callback registration failed')
  INSTALLED=True;result.PutCString('RX_RECEIVER_READONLY_INSTALLED')
 except Exception as error:
  for bp in BPS:rx.TARGET.BreakpointDelete(bp.GetID())
  BPS.clear();result.SetError(str(error))
def checkpoint(debugger,command,result,_):
 try:
  need(INSTALLED and STATE is not None and command and all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in command) and len(command)<=64,'Invalid checkpoint label')
  record=checked_report();record.update(sourceSha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),inheritedObserverSha256=hashlib.sha256((ROOT/'lldb_native_tap.py').read_bytes()).hexdigest(),manifestSha256=hashlib.sha256((ROOT/'receiver-hook-manifest.json').read_bytes()).hexdigest(),savedUnix=time.time())
  p=rx.OUT/('receiver-'+command+'.json')
  with p.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
  result.PutCString(json.dumps(dict(path=str(p),valid=record['valid'],completedCopies=record['completedCopies'],selectedCopiedBytes=record['selectedCopiedBytes'],invalid=record['invalid'],pending=len(record['pending']))))
 except Exception as error:result.SetError(str(error))
def cleanup(debugger,command,result,_):
 global INSTALLED
 for bp in BPS:rx.TARGET.BreakpointDelete(bp.GetID())
 BPS.clear();INSTALLED=False;result.PutCString('RX_RECEIVER_HOOKS_REMOVED')
def __lldb_init_module(debugger,_):
 for n,f in [('rx-receiver-install','install'),('rx-receiver-checkpoint','checkpoint'),('rx-receiver-cleanup','cleanup')]:debugger.HandleCommand('command script add -f receiver_copy_tap.'+f+' '+n)
