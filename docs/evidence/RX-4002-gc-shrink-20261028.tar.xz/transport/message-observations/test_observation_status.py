import sys,types,unittest,signal
sys.modules['lldb']=types.SimpleNamespace();sys.modules['lldb_native_tap']=types.SimpleNamespace()
from observation_status import qualify
class Tests(unittest.TestCase):
 def setUp(self):self.s=dict(actualPid=1,expectedPid=1,processStopped=True,selectedTid=2,mainTid=2,workerTid=3,threads=[dict(tid=2,reason='signal',signal=int(signal.SIGSTOP)),dict(tid=3,reason='none',signal=None)],installed=True,active=True,baseErrors=0,baseDropped=0,basePending=0,baseLive=0,oneValid=True,twoValid=True,onePending=0,twoPending=0)
 def test_owned_sigstop_with_complete_ledgers_passes(self):self.assertEqual(qualify(self.s),[])
 def test_wrong_pid_or_running_refuses(self):
  for change in [{'actualPid':9},{'processStopped':False}]:self.assertTrue(qualify({**self.s,**change}))
 def test_generic_private_breakpoint_is_not_sigstop(self):self.s['threads']=[dict(tid=2,reason='breakpoint',signal=None),dict(tid=3,reason='none',signal=None)];self.assertTrue(qualify(self.s))
 def test_wrong_signal_refuses(self):self.s['threads'][0]['signal']=int(signal.SIGINT);self.assertTrue(qualify(self.s))
 def test_missing_owned_peer_or_selected_thread_refuses(self):
  for change in [{'workerTid':9},{'selectedTid':9},{'mainTid':9}]:self.assertTrue(qualify({**self.s,**change}))
 def test_any_base_incomplete_state_refuses(self):
  for key in ['baseErrors','baseDropped','basePending','baseLive']:self.assertTrue(qualify({**self.s,key:1}))
  for key in ['installed','active']:self.assertTrue(qualify({**self.s,key:False}))
 def test_receiver_invalid_or_pending_refuses(self):
  for key in ['oneValid','twoValid']:self.assertTrue(qualify({**self.s,key:False}))
  for key in ['onePending','twoPending']:self.assertTrue(qualify({**self.s,key:1}))
if __name__=='__main__':unittest.main(verbosity=2)
