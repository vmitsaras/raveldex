import { createWorkerRaveldex } from '@vmitsaras/raveldex/adapters/worker';
import { createWorkerSnapshots } from '@vmitsaras/raveldex/adapters/worker/snapshots';
import { createSourceProvider, createSourcePhrases } from '@vmitsaras/raveldex/addons/phrases';
import { recordsFor, schema } from './cost-fixture.mjs';
import { observeMessages } from './message-observer.mjs';
const worker = new Worker('/message-worker.mjs', { type: 'module' });
const observation = observeMessages(worker, 'main');
let engine, snapshots, encoded, size = 0, revision = 0, priorResult, unicode = false, restoreRejected = false, exportOrigin;
const deadlineMs = 60000;
const ready = (async () => {
  engine = await createWorkerRaveldex({ worker: observation.endpoint, ownership: 'external', sameHost: true,
    responseTimeoutMs: 120000, configuration: { schema,
      addons: [createSourceProvider({ fields: ['body'] }), createSourcePhrases({ fields: ['body'] })] } });
  snapshots = createWorkerSnapshots(engine);
})();
function check(test, message) { if (!test) throw Error(message); }
function allPriorEqual(result) { return JSON.stringify(result) === JSON.stringify(priorResult); }
window.messageControl = {
  ready: () => ready,
  async build(count) {
    await ready; check([4, 1000, 10000].includes(count) && !size, 'Unsupported build state');
    const records = recordsFor(count);
    for (let i = 0; i < count; i += 256) await engine.addMany(records.slice(i, i + 256), { deadlineMs });
    size = count; revision = Math.ceil(count / 256); return { size, revision, batchSize: 256, deadlineMs, fixture: 'Unchanged ASCII cycle' };
  },
  async run(kind) {
    await ready;
    if (kind === 'empty') return engine.addMany([], { deadlineMs });
    if (['ascii-empty', 'ascii-single', 'latin1-query'].includes(kind)) {
      check(size === 4, 'Small ordinary-string controls use separate four-record owner only');
      const query = kind === 'ascii-empty' ? '' : kind === 'ascii-single' ? 'r' : 'café';
      const result = await engine.search(query, { limit: 20, deadlineMs });
      check(result.total === 0 && result.hits.length === 0 && result.revision === revision && result.completeness === 'complete', 'Literal ordinary-string control query result');
      return { control: kind, queryCodeUnits: query.length, publicOutcome: 'Pass', result, scope: 'Separate synthetic ordinary public query, no product ASCII corpus change' };
    }
    if (kind === 'unicode-query') {
      check(size === 4, 'Unicode control only for separately labelled four-record owner');
      const result = await engine.search('δοκιμή', { limit: 20, deadlineMs });
      check(result.total === (unicode ? 1 : 0) && result.revision === revision && result.completeness === 'complete', 'Unicode control query verification');
      if (unicode) check(result.hits.length === 1 && result.hits[0].id === 'unicode-control', 'Unicode control ID');
      return { control: 'Separate ordinary public search, Greek six-UTF16-unit query', queryCodeUnits: 6, expectedStringContentBytes: 12, result };
    }
    if (kind === 'unicode-add') {
      check(size === 4 && !unicode, 'Unicode add only once in separately labelled four-record owner');
      const result = await engine.add({ id: 'unicode-control', text: { body: 'δοκιμή' }, metadata: { group: 'δοκιμή' } }, { deadlineMs });
      revision++; unicode = true; check(result.revision === revision, 'Unicode add revision');
      return { control: 'Separate synthetic Unicode record via unchanged public API', result };
    }
    if (kind === 'search') {
      if (restoreRejected) {
        const result = await engine.search({ kind: 'all' }, { limit: 20, deadlineMs });
        check(allPriorEqual(result), 'Prior state changed after rejected restore');
        return { priorStatePreserved: true, result };
      }
      const result = await engine.search('red', { limit: 20, deadlineMs });
      check(result.total === size && result.revision === revision && result.completeness === 'complete' &&
        result.hits.length === Math.min(20, size) && new Set(result.hits.map(h => h.id)).size === result.hits.length && result.hits.every(h => Number.isFinite(h.score)), 'Literal query verification failed');
      const phrase = await engine.search({ kind: 'extension', capability: 'phrases', version: 1, payload: { text: 'red blue', fields: ['body'] } }, { limit: 20, deadlineMs });
      check(phrase.total === Math.ceil(size / 3) && phrase.revision === revision && phrase.completeness === 'complete', 'Literal phrase verification failed');
      return { exactTotalAndRevision: true, result, phrase };
    }
    if (kind === 'export') {
      encoded = await snapshots.exportSource({ deadlineMs }); exportOrigin = revision;
      const envelope = JSON.parse(encoded), records = envelope.body.payload.records;
      check(envelope.format === 'raveldex-source' && envelope.body.header.originRevision === revision && records.length === size + (unicode ? 1 : 0), 'Source envelope header/length');
      const expected = recordsFor(size);
      for (let i = 0; i < size; i++) check(records[i].id === expected[i].id && JSON.stringify(records[i].text) === JSON.stringify({ body: [expected[i].text.body] }) && JSON.stringify(records[i].metadata) === JSON.stringify(expected[i].metadata), 'Literal exported record mismatch');
      if (unicode) check(records.at(-1).id === 'unicode-control' && JSON.stringify(records.at(-1).text) === JSON.stringify({ body: ['δοκιμή'] }) && records.at(-1).metadata.group === 'δοκιμή', 'Literal Unicode record mismatch');
      return { publicOutcome: 'Pass', format: 'raveldex-source', originRevision: revision, records: records.length, literalAllExportedValues: true, codeUnits: encoded.length,
        expectedSnapshotStringContentBytes: encoded.length * (unicode ? 2 : 1), expectedStringRepresentation: unicode ? 'Two-byte: separate Unicode control' : 'One-byte: unchanged ASCII product corpus', encodedLengthIsNotMemory: true };
    }
    if (kind === 'prior') {
      await engine.clear({ deadlineMs }); revision++;
      await engine.add({ id: 'prior', text: { body: 'prior state' }, metadata: { group: 'prior' } }, { deadlineMs }); revision++;
      priorResult = await engine.search({ kind: 'all' }, { limit: 20, deadlineMs });
      check(priorResult.total === 1 && priorResult.revision === revision && priorResult.hits[0].id === 'prior', 'Prior receiver state verification');
      return priorResult;
    }
    if (kind === 'restore') {
      check(typeof encoded === 'string' && priorResult, 'Export and prior state must precede restore');
      try {
        const result = await snapshots.restore(encoded, { deadlineMs }); revision++;
        check(result.format === 'raveldex-source' && result.reindexed === true && result.revision === revision && result.originRevision === exportOrigin, 'Restore header/revision verification');
        return { publicOutcome: 'Pass', result };
      } catch (error) {
        if (!['DEADLINE_EXCEEDED', 'WORK_LIMIT_EXCEEDED', 'LIMIT_EXCEEDED', 'RESOURCE_EXHAUSTED'].includes(error.code)) throw error;
        const after = await engine.search({ kind: 'all' }, { limit: 20, deadlineMs });
        check(allPriorEqual(after), 'Rejected restore changed exact prior state'); restoreRejected = true;
        return { publicOutcome: 'Rejected', error: { name: error.name, code: error.code, message: error.message }, priorStatePreserved: true, prior: priorResult };
      }
    }
    if (kind === 'dispose') { await engine.dispose(); engine = snapshots = encoded = priorResult = undefined; return { disposed: true }; }
    throw Error('Unknown operation');
  },
  observation: () => observation.snapshot(),
  release() { encoded = undefined; return { encodedReleased: true }; },
  terminate() { worker.terminate(); return { terminated: true }; },
};
