"""Build a source-bound receipt from unchanged completed ordinary-message inputs."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/vasilis/Documents/GitHub/raveldex')


def load(path):
    return json.loads(path.read_text())


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


cases = []
for label, native_name, controller_name, raw_name, receiver_name, absence, sessions in [
    ('separate-unicode-control', 'native-controls-1', 'controller-controls-1', 'tap-4-unicode-roundtrip.json', 'receiver-linkage-replay-v2.json', 'owned-controls-after.log', dict(controller=27579, debugger=83474)),
    ('source-1000', 'native-product-1000-manual-0', 'controller-product-1000-manual-0', 'tap-2-source-roundtrip.json', 'receiver-replay.json', 'owned-product-1000-manual-0-after.log', dict(controller=33635, debugger=83457)),
    ('source-10000', 'native-product-10000-manual-0', 'controller-product-10000-manual-0', 'tap-2-source-roundtrip.json', 'receiver-replay.json', 'owned-product-10000-manual-0-after.log', dict(controller=5071, debugger=57991))]:
    native = ROOT / native_name
    controller = ROOT / controller_name
    report = load(controller / 'report.json')
    record = load(native / raw_name)
    audit_path = native / ('inherited-replay.json')
    if not audit_path.exists():
        audit_path = native / 'inherited-replay-v2.json'
    audit = load(audit_path)
    receiver = load(native / receiver_name)
    capacity = load(native / 'wire-capacity-replay.json')
    host = load(native / 'lldb-observer-host.json')
    assert report['preservation'] == 'Pass' and report['ownedBrowserClosed'] and report['cleanupErrors'] == []
    assert host['exitCode'] == 0 and host['timedOut'] is False
    assert (ROOT / absence).read_bytes() == b''
    assert record['observerSha256'] == identity(ROOT / 'lldb_native_tap.py')['sha256']
    assert audit['remaining'] == 0 and receiver['status'] == 'Pass' and capacity['status'] == 'BoundedPass'
    assert len(report['productionFiles']) == 208
    for item in report['productionFiles']:
        for base in (REPO, Path(report['consumer']) / 'node_modules/@vmitsaras/raveldex', Path(report['stagedDirectory']) / 'node_modules/@vmitsaras/raveldex'):
            assert identity(base / item['path'])['sha256'] == item['sha256']
    for item in report['sources']:
        assert identity(Path(item['source']))['sha256'] == item['sha256']
        if 'target' in item:
            assert identity(Path(item['target']))['sha256'] == item['sha256']
    text = (native / 'lldb-observer.log').read_text()
    statuses = [json.loads(s) for s in re.findall(r'RX_OBSERVATION_STATUS (\{[^\r\n]*\})', text)]
    if label != 'separate-unicode-control':
        assert statuses and statuses[-1]['qualified'] is True
    assert all(mark in text for mark in ['RX_ONEBYTE_HOOKS_REMOVED', 'RX_RECEIVER_HOOKS_REMOVED', 'RX_NATIVE_HOOKS_REMOVED'])
    assert 'detached' in text
    results = [dict(command=c['command'], result=c.get('result'), error=c.get('error')) for c in report['commands']]
    cases.append(dict(label=label, publicCommands=results, controllerOutcome=report['outcome'],
                      ownerCompletion='Fail: controller watchdog expired after all measured operations and final native checkpoint' if label == 'source-1000' else 'Pass: normal close',
                      containedWindow='BoundedPass', productionFilesUnchanged=208,
                      debuggerExit=host['exitCode'], ownedBrowserClosed=True, ownedProcessesAbsent=True,
                      toolSessionIds=sessions, finalStopStatus=statuses[-1] if statuses else None,
                      nativeFramePairs=audit['counts']['native-call-return'], births=audit['births'], remaining=audit['remaining'],
                      senderCopyCalls=audit['selectedStringCopyCalls'], senderCopiedExtentBytes=audit['selectedStringCopyBytes'],
                      selectedReceiver={k: receiver[k] for k in ['oneByteBulkStrings', 'oneByteLogicalExtentBytes', 'oneByteNonBulkZero', 'oneByteNonBulkOne', 'twoByteCopyCalls', 'twoByteRequestedBytes', 'exactSenderSpanMatches', 'unmatchedSenderSpanCount']},
                      wireCapacity={k: capacity[k] for k in ['observedRequestedCapacityHighWaterBytes', 'firstPeakWitness', 'movedGrowthCopies', 'movedGrowthCopiedExtentBytes', 'inPlaceObserved']},
                      artifacts=[identity(p) for p in [controller / 'report.json', controller / 'pid-proof-trace.json', native / 'lldb-install.json', native / 'lldb-observer-host.json', native / 'lldb-observer.log', native / raw_name, native / 'onebyte-final.json', native / 'receiver-final.json', audit_path, native / receiver_name, native / 'wire-capacity-replay.json', ROOT / absence]]))

result = dict(schema='raveldex-ordinary-message-observations-final-v1', date='2026-10-28',
              status='Completed bounded observations; independent final 10k/capacity review pending',
              binarySha256=cases and load(ROOT / 'controller-product-10000-manual-0/report.json')['binarySha256'],
              publicSnapshotFormat='raveldex-source only; no native browser qualification enabled',
              cases=cases,
              limits=['Single fresh native observation at each admitted product size; no repeated-cohort or statistical claim.',
                      '1k completed public restore/search and contained native window, but owner completion failed its five-minute host watchdog after final capture.',
                      '10k export succeeded; restore rejected DEADLINE_EXCEEDED under unchanged60000ms/default bounds and preserved exact prior revision42. No successful10krestore claim.',
                      'Build happened before attach and is outside native transport observation scope.',
                      'Broad generic receiver factory breakpoints and literal export JSON verification cause substantial observer/harness cost; no ordinary latency claim.',
                      'Explicit CDP forced GC is not ordinary automatic deletion timing.',
                      'Selected sender/receiver copy extents only;25/80/29 sender spans in control/1k/10k lack selected receiver witnesses and remain Unknown, never inferred zero-copy.',
                      'Wire capacity is requested native wire extents at observed frontiers; no rounded allocator/global physical/receiver managed lifetime or scalar/SIMD store-volume claim.',
                      'No natural same-address resize observed; in-place control remains unqualified.'],
              stoppedDirectAllocatorControl=dict(status='NotRun/Interrupted', retry=False,
                                                receipt=str(ROOT.parent / 'native-run-3/security-interrupted-cleanup.json'),
                                                reason='Automatic security review stopped native allocation-control execution; only owned cleanup was performed. Ordinary API observations do not resume or qualify that method.'),
              preservedFailedDriverAttempts=['host-product-1000-0.json', 'host-product-1000-0-cli-v2.json', 'host-product-1000-0-sigstop-v3.json'],
              sources=[identity(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.suffix in ('.py', '.mjs', '.json', '.md') and p.name not in ('final-observations.json', 'final-file-inventory.json')])
out = ROOT / 'final-observations.json'
assert not out.exists(), 'Final receipt is new-file-only'
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(identity(out)))
