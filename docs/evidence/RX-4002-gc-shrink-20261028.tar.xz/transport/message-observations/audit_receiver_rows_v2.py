"""Independent offline linkage of receiver frames to actual inherited wire tape.
No browser/debugger imports, product calls, target expressions or native calls.
"""
import argparse,collections,hashlib,json,pathlib

def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def audit(native_path,one_path,two_path,install_path):
 native=json.loads(pathlib.Path(native_path).read_text());one=json.loads(pathlib.Path(one_path).read_text());two=json.loads(pathlib.Path(two_path).read_text());install=json.loads(pathlib.Path(install_path).read_text());config=install['config'];base=install['base']
 assert native['invalid']==[] and native['dropped']==0 and native['pending']=={} and native['remaining']=={}
 assert one['valid'] and two['valid'] and one['invalid']==two['invalid']==[] and one['dropped']==two['dropped']==0 and one['pending']==two['pending']=={}
 assert one['inheritedLedgerVerified'] is True and two['inheritedLedgerVerified'] is True and one['pid']==two['pid']==native['pid']==install['pid']==config['pid'] and one['peer']==two['peer']==config['peer']
 old=native['rows'];assert all(r['seq']==i for i,r in enumerate(old,1));bindings=native['bindings'];sender=collections.Counter()
 for r in old:
  if r['kind']=='payload-copy-return':sender[(r['chain'],r['dest']-r['ptr'],r['length'],r['site'])]+=1
 allrows=[]
 for label,record in [('one',one),('two',two)]:
  assert all(r['seq']==i for i,r in enumerate(record['rows'],1));last=-1
  for r in record['rows']:
   anchor=r['nativeLedgerSequence'];assert type(anchor) is int and last<=anchor<=len(old);last=anchor
   assert type(r['wallNs']) is int and r['wallNs']>0
   allrows.append((anchor,label,r))
 allrows.sort(key=lambda x:(x[0],x[2]['wallNs'],x[1],x[2]['seq']))
 live={};position=0;states={'one':{},'two':{}};oneDone=[];twoDone=[];matched=[];nonBulkMatched=collections.Counter()
 def advance(n):
  nonlocal position
  while position<n:
   r=old[position];position+=1;k=r['kind']
   if k=='buffer-live':assert r['ptr'] not in live;live[r['ptr']]=dict(ptr=r['ptr'],cap=r['cap'],allocation=r['allocation'],chain=r['chain'],originTid=r['tid'])
   elif k=='buffer-resize':assert live[r['ptr']]['allocation']==r['allocation'];live[r['ptr']]['cap']=r['cap']
   elif k in ('root-free-return','internal-free-return','final-free-return'):assert live[r['ptr']]['allocation']==r['allocation'];del live[r['ptr']]
   elif k=='api-only-retirement':assert r['ptr'] in live;del live[r['ptr']]
 def linkage(row):
  w=row['wire'];m=row['metadata'];assert live.get(w['ptr'])==w
  b=bindings[str(w['chain'])]
  for key in ('protocol','session','id','operation','kind','direction','peer','processId'):assert m[key]==b[key]
  senderTid=config['mainTid'] if m['direction']=='main-to-worker' else config['workerTid'];receiverTid=config['workerTid'] if m['direction']=='main-to-worker' else config['mainTid']
  assert w['originTid']==senderTid and row['frame']['tid']==receiverTid and row['frame']['pid']==native['pid']
  return w,m
 for anchor,label,r in allrows:
  advance(anchor);w,m=linkage(r);f=r['frame'];tid=f['tid'];k=r['kind'];pending=states[label]
  if k in ('onebyte-factory-entry','reader-entry'):
   assert tid not in pending
   assert f['pc']==base+(0x5212c8 if label=='one' else 0x3de2aa8) and f['lr']==base+(0x166c230 if label=='one' else 0x166c970) and f['sp']%16==0
   if label=='one':assert f['src']+f['length']==f['positionAfter']<=f['end']<=w['ptr']+w['cap'] and f['allocationType']==0
   else:assert w['ptr']<=f['cursor']<f['end']<=w['ptr']+w['cap']
   pending[tid]=dict(entry=f,wire=w,meta=m,frontier=None,copyReturned=False)
  elif k in ('onebyte-bulk-frontier','receiver-copy-enter'):
   p=pending[tid];e=p['entry'];assert w==p['wire'] and p['frontier'] is None
   h=r['destinationHeader'];assert f['dest']==h['tagged']+11 and h['hash']==3
   assert f['dest']+f['length']<=w['ptr'] or w['ptr']+w['cap']<=f['dest']
   if label=='one':
    assert f['pc']==base+0x521388 and f['sp']==e['sp']-48 and f['src']==e['src'] and f['length']==e['length']>1 and h['map']==261 and h['units']==e['length'] and r['actualStoreTrafficMeasured'] is False
   else:
    assert f['pc']==base+0x3de2b48 and f['sp']==e['sp']-64 and f['owner']==e['owner'] and f['src']==f['sourceRegister'] and f['length']==f['lengthRegister']>0 and f['length']%2==0 and 1<=f['src']-e['cursor']<=5 and f['positionAfter']==f['src']+f['length']<=e['end'] and h['map']==221 and h['units']*2==f['length']
   assert w['ptr']<=f['src']<f['src']+f['length']<=e['end'];p['frontier']=f
   identity=(w['chain'],f['src']-w['ptr'],f['length'],0x17009b8 if label=='one' else 0x3de04f0)
   assert sender[identity]>0,('No exact sender span counterpart',identity,m)
   matched.append(dict(route=label,chain=w['chain'],allocation=w['allocation'],wireOffset=f['src']-w['ptr'],bytes=f['length'],session=m['session'],id=m['id'],operation=m['operation'],kind=m['kind'],direction=m['direction'],receiverTid=tid,peer=m['peer']))
  elif k=='receiver-copy-return':
   p=pending[tid];c=p['frontier'];assert c and not p['copyReturned'] and f['pc']==f['lr']==base+0x3de2b4c and f['sp']==c['sp'] and f['value']==c['dest'];p['copyReturned']=True
  elif k in ('onebyte-factory-return','reader-return'):
   p=pending.pop(tid);e=p['entry'];c=p['frontier'];assert w==p['wire'] and f['pc']==e['lr'] and f['sp']==e['sp']
   if label=='one':
    if e['length']>1:assert c and f['value']==c['handle'] and r['selectedBulk'] is True and r['logicalCopiedExtentBytes']==e['length']
    else:
     assert c is None and r['selectedBulk'] is False and r['logicalCopiedExtentBytes']==0
     if e['length']==0:assert f['value']==e['isolate']+0x3a0
     else:
      identity=(w['chain'],e['src']-w['ptr'],1,0x17009b8);assert sender[identity]>0;nonBulkMatched[identity]+=1
    oneDone.append(r)
   else:assert c and p['copyReturned'] and f['value']==c['handle'] and r['copyBytes']==c['length'];twoDone.append(r)
  else:raise AssertionError('Unknown receiver row kind:'+k)
 assert not states['one'] and not states['two'];advance(len(old));assert not live
 assert one['completedBulkStrings']==sum(r['selectedBulk'] for r in oneDone) and one['selectedBulkLogicalExtentBytes']==sum(r['logicalCopiedExtentBytes'] for r in oneDone)
 assert one['nonBulkLengthZero']==sum(r['inputLength']==0 for r in oneDone) and one['nonBulkLengthOne']==sum(r['inputLength']==1 for r in oneDone)
 assert two['completedCopies']==len(twoDone) and two['selectedCopiedBytes']==sum(r['copyBytes'] for r in twoDone)
 bulkMatched=collections.Counter((r['chain'],r['wireOffset'],r['bytes'],0x17009b8 if r['route']=='one' else 0x3de04f0) for r in matched)
 unmatched=[]
 for identity,count in (sender-bulkMatched-nonBulkMatched).items():
  chain,offset,n,site=identity;m=bindings[str(chain)];unmatched.append(dict(chain=chain,wireOffset=offset,bytes=n,site=site,count=count,session=m['session'],id=m['id'],operation=m['operation'],kind=m['kind'],direction=m['direction'],receiverRoute='Unknown/unobserved; no zero-copy inference'))
 return dict(schema='raveldex-independent-receiver-wire-linkage-v2',auditorSourceSha256=sha(pathlib.Path(__file__)),observedNonBulkSenderCounterparts=sum(nonBulkMatched.values()),unmatchedSenderSpans=unmatched,unmatchedSenderSpanCount=sum(r['count'] for r in unmatched),unmatchedScope='Selected receiver hooks do not cover these sender spans. Fast property-key routes may explain some but remain unobserved; no zero-copy or full-copy-total claim.',status='Pass',sources={str(p):sha(p) for p in [native_path,one_path,two_path,install_path]},oneByteBulkStrings=one['completedBulkStrings'],oneByteLogicalExtentBytes=one['selectedBulkLogicalExtentBytes'],oneByteNonBulkZero=one['nonBulkLengthZero'],oneByteNonBulkOne=one['nonBulkLengthOne'],twoByteCopyCalls=two['completedCopies'],twoByteRequestedBytes=two['selectedCopiedBytes'],exactSenderSpanMatches=len(matched),matches=matched,unboundEntries={'oneByte':one['unboundEntries'],'twoByte':two['unboundEntries']},scope='Independent raw-row pairing and source-generation liveness at inherited tape anchors, exact message binding and sender span-offset/length counterparts. OneByte logical extents are not overlapping store traffic; no all payload/global/physical peak claim.')
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--native',required=True);p.add_argument('--one',required=True);p.add_argument('--two',required=True);p.add_argument('--install',required=True);a=p.parse_args();print(json.dumps(audit(a.native,a.one,a.two,a.install),indent=2))
