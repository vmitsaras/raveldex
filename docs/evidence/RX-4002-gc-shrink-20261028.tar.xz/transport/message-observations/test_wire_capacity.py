import copy
import unittest
from audit_wire_capacity import replay


def fixture():
    rows = [dict(kind='buffer-live', ptr=100, cap=10, allocation=1, chain=1),
            dict(kind='copy-enter', src=100, dest=200, length=10, oldCap=10, newCap=20),
            dict(kind='buffer-live', ptr=200, cap=20, allocation=2, chain=1),
            dict(kind='copy-return', src=100, dest=200, length=10, returned=200),
            dict(kind='internal-free-return', ptr=100, cap=10, allocation=1, chain=1),
            dict(kind='final-free-return', ptr=200, cap=20, allocation=2, chain=1)]
    for i, row in enumerate(rows, 1):
        row.update(seq=i, pid=1, window='literal')
    return dict(schema='raveldex-lldb-buffer-observation-v2', pid=1, rows=rows,
                dropped=0, invalid=[], pending={}, remaining={}, bindings={'1': {}})


class Tests(unittest.TestCase):
    def test_old_new_overlap(self):
        result = replay(fixture())
        self.assertEqual(result['observedRequestedCapacityHighWaterBytes'], 30)
        self.assertEqual(result['firstPeakWitness']['seq'], 3)
        self.assertEqual(result['movedGrowthCopiedExtentBytes'], 10)

    def refused(self, change):
        data = fixture()
        change(data)
        with self.assertRaises((AssertionError, KeyError)):
            replay(data)

    def test_loss_refused(self):
        self.refused(lambda d: d.update(dropped=1))

    def test_missing_free_refused(self):
        self.refused(lambda d: d['rows'].pop())

    def test_overlap_refused(self):
        self.refused(lambda d: d['rows'][2].update(ptr=105))

    def test_wrong_generation_refused(self):
        self.refused(lambda d: d['rows'][-1].update(allocation=1))

    def test_resize_refused(self):
        self.refused(lambda d: d['rows'][3].update(kind='buffer-resize'))

    def test_extent_overflow_refused(self):
        self.refused(lambda d: d['rows'][0].update(ptr=2**64-5))

    def test_api_retirement_refused(self):
        self.refused(lambda d: d['rows'][-1].update(kind='api-only-retirement'))


if __name__ == '__main__':
    unittest.main()
