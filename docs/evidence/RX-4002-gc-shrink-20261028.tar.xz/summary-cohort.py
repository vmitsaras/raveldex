import pathlib,json,statistics,hashlib
r=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H')
rows=[]
for hostp in sorted((r/'codecs').glob('*/host.json')):
 h=json.loads(hostp.read_text())
 for p in h['processes']:
  c=p.get('child');
  if not c:continue
  name=c['operation']['name'];raw=pathlib.Path(c['operation']['file'])
  with raw.open('rb') as f:
   f.seek(max(0,raw.stat().st_size-4200));tail=f.read()
  start=tail.rindex(b'{"record":"summary"');s=json.loads(tail[start:]);assert s['valid'] or all(s[k] is None for k in ('gross_birth_bytes','mutator_occupied_high_water_bytes','occupied_at_stop_bytes','trimmed_bytes','gc_removed_bytes'))
  rows.append({'case':hostp.parent.name,'mode':h['mode'],'size':h['size'],'format':h['format'],'role':p['role'],'operation':name,'publicOutcome':c['operation']['publicOutcome'],'error':c['operation']['error'],'priorStatePreserved':c.get('priorStatePreserved'),'disposed':c.get('disposed'),'rawBytes':raw.stat().st_size,'summary':s,'runtimeSha256':h['runtimeSha256'],'profile':c['qualification']['profileId'],'extentCap':c.get('extentCap',1000000),'streamMiB':c['streamMiB'],'selected':s['valid'] and hostp.parent.name!='positions-offsets-10000-native-r1','hostPath':str(hostp),'hostSha256':hashlib.sha256(hostp.read_bytes()).hexdigest()})
groups=[]
for key in sorted(set((x['mode'],x['size'],x['format'],x['role'],x['runtimeSha256'],x['extentCap'],x['streamMiB']) for x in rows)):
 selected=[x for x in rows if (x['mode'],x['size'],x['format'],x['role'],x['runtimeSha256'],x['extentCap'],x['streamMiB'])==key and x['selected']];
 if not selected:continue
 q={'mode':key[0],'size':key[1],'format':key[2],'role':key[3],'runtimeSha256':key[4],'extentCap':key[5],'streamMiB':key[6],'observations':len(selected),'publicOutcomes':[x['publicOutcome'] for x in selected],'metrics':{}}
 for name in ('gross_birth_bytes','mutator_occupied_high_water_bytes','occupied_at_stop_bytes','trimmed_bytes','gc_removed_bytes','gc_pre_move_shrinks'):
  values=[x['summary'][name] for x in selected];q['metrics'][name]={'values':values,'min':min(values),'median':statistics.median(values),'max':max(values)}
 groups.append(q)
(r/'cohort-summary.json').write_text(json.dumps({'schema':'raveldex-gc-shrink-cohort-summary-v1','scope':'Descriptive managed occupied extents grouped by exact runtimeSHA,extentCap andstreamMiB. Never one same-binary distribution acrossgroups; no latency, exclusive attribution or physical/process/native-backing claim','rows':rows,'groups':groups},indent=2)+'\n')
print(json.dumps({'windows':len(rows),'rawBytes':sum(x['rawBytes'] for x in rows),'events':sum(x['summary']['events'] for x in rows),'publicRejected':sum(x['publicOutcome']!='Pass' for x in rows)}))
