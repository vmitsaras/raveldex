import importlib.util,json,pathlib,time
root=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex/bench/memory');temp=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');out=temp/'audit'
def load(name,file):
 s=importlib.util.spec_from_file_location(name,out/'sources-v4'/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
py=load('py','gc-runtime-audit.py');fast=load('fast','gc-runtime-fast-audit.py')
rows=[]
paths=sorted((temp/'runtime'/'synthetic-controls-v6').rglob('*.rdxgc'))+sorted((temp/'runtime'/'native-controls-v6').rglob('*.rdxgc'))
report={'streams':rows,'allAgree':False,'excludedSentinels':[]}
for path in paths:
 if path.name=='sentinel.rdxgc':
  assert path.read_bytes()==b'sentinel';report['excludedSentinels'].append(str(path));continue
 started=time.time();a=py.audit(path);b=fast.audit(path,out/'gc-runtime-replay-v4')
 for key in ('bytes','sha256','events','valid','summary'):assert a[key]==b[key],(path,key)
 if a['valid']:assert a['marks']=={int(k):v for k,v in b['marks'].items()}
 elif a['prefixFailure'] is not None and b['prefixFailure'] is not None:assert a['prefixFailure']['sequence']==b['prefixFailure']['sequence']
 rows.append({'path':str(path),'sha256':a['sha256'],'bytes':a['bytes'],'events':a['events'],'valid':a['valid'],'bothAgree':True,'prefixFailurePython':a['prefixFailure'],'prefixFailureCpp':b['prefixFailure'],'summary':a['summary'],'elapsedSeconds':time.time()-started})
 (out/'cohort-v6-independent-controls-replay.json').write_text(json.dumps(report,indent=2)+'\n')
 print(path.name,a['valid'],a['events'],flush=True)
report['allAgree']=True
(out/'cohort-v6-independent-controls-replay.json').write_text(json.dumps(report,indent=2)+'\n')
print('All controls agree:',len(rows))
