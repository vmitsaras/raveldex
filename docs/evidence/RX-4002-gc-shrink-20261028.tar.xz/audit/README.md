# Independent GC shrink audit

Repository changes are limited to the five `bench/memory/gc-runtime-*` auditor/test files. Frozen source copies are in `sources/`; the Python interval primitive is included so those copies can execute separately. No runtime launch/build, browser operation, product change, network operation, push, or alteration of historical temp sources was performed by this auditor.

Commands actually run from `/Users/vasilis/Documents/GitHub/raveldex`:

```
python3 bench/memory/gc-runtime-audit.test.py
clang++ -std=c++17 -O2 bench/memory/gc-runtime-replay.cc -o /tmp/raveldex-ac03-shrink-20261028.F26U9H/audit/gc-runtime-replay-v2
python3 bench/memory/gc-runtime-fast-audit.test.py --executable /tmp/raveldex-ac03-shrink-20261028.F26U9H/audit/gc-runtime-replay-v2 --report /tmp/raveldex-ac03-shrink-20261028.F26U9H/audit/differential-literals-final.json
python3 /tmp/raveldex-ac03-shrink-20261028.F26U9H/audit/replay-v5-controls.py
python3 /tmp/raveldex-ac03-shrink-20261028.F26U9H/audit/native-tail-witnesses.py
python3 /tmp/raveldex-ac03-shrink-20261028.F26U9H/audit/save-python-fixtures.py
git diff --check -- bench/memory/gc-runtime-audit.py bench/memory/gc-runtime-audit.test.py bench/memory/gc-runtime-fast-audit.py bench/memory/gc-runtime-fast-audit.test.py bench/memory/gc-runtime-replay.cc
```

Final results: Python 14/14; C++ differential plus separate independent literal 15/15; 55 captured Python literals; 22 control streams fully agree across Python and C++ (13 exact-class synthetic, 9 genuine/legacy native), excluding the separately checked sentinel; genuine native control has 825,610 complete events, 35 paired pre-move shrinks and 13 later move destination overlaps with removed tails. Apple clang 21.0.0 arm64-apple-darwin27.0.0. Diff whitespace check passes.

`v5-calibration-gate.json` is the independently source/hash-bound gate. It qualifies bounded same-runtime calibration only, not AC03 as a whole. New schema `raveldex-gc-extents-varint-v2` requires exact method `pre-move-full-coverage-right-trim-v1`. Legacy v1 is never silently promoted. Matched update-only semantics, global phase, full old coverage, strict tracked decrease, released-tail frozen source removal, post-trim GC-end baseline and shrink counter are verified. Explicit offline 4096 MiB choice is added; default 256 MiB remains.

Prior `fixtures/`, `python-literals.log`, `python-literal-fixtures.json`, and reports with `v2`/`v3` suffixes preserve intermediate test iterations. Final fixtures/reports use `-final`; no intermediates are treated as final evidence. A preliminary direct replay encountered the nonstream sentinel after 19 complete streams and therefore saved no completed report; `replay-v5-controls.py` explicitly excludes and checks that sentinel, then completes all 22 streams. No metrics came from that incomplete preliminary invocation.
