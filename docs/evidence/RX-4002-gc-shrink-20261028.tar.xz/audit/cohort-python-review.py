"""Full Python replay of completed1k windows; no measurement workload launch."""
import importlib.util,json,pathlib,time
ROOT=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');OUT=ROOT/'audit'
s=importlib.util.spec_from_file_location('reference',OUT/'sources/gc-runtime-audit.py');reference=importlib.util.module_from_spec(s);s.loader.exec_module(reference)
def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
start=time.time();done=[]
try:
 while time.time()-start<7200:
  for path in sorted(OUT.glob('cohort-window-*.json')):
   if path.name in done:continue
   try:r=json.loads(path.read_text())
   except json.JSONDecodeError:continue
   if r['size']!=1000:done.append(path.name);continue
   before=time.time();p=reference.audit(r['path'],r['maxStreamMiB'])
   for key in ('bytes','sha256','events','valid','independentReplay','summary','maxStreamMiB'):assert p[key]==r[key],(path,key)
   if p['valid']:assert {str(k):v for k,v in p['marks'].items()}==r['marks']
   else:
    if p['prefixFailure'] is not None and r['prefixFailure'] is not None:assert p['prefixFailure']['sequence']==r['prefixFailure']['sequence']
   p.update(case=r['case'],role=r['role'],cppReport=str(path),bothAgree=True,elapsedSeconds=time.time()-before)
   write(OUT/f'cohort-python-{r["case"]}-{r["role"]}.json',p);done.append(path.name)
   print(r['case'],r['role'],p['events'],p['valid'],round(p['elapsedSeconds'],2),flush=True)
  if (OUT/'cohort-fast-complete.json').exists() and all(p.name in done for p in OUT.glob('cohort-window-*.json')):
   write(OUT/'cohort-python-complete.json',{'processedWindowReports':done,'differentialReports':[str(p) for p in sorted(OUT.glob('cohort-python-*.json')) if p.name!='cohort-python-complete.json'],'elapsedSeconds':time.time()-start});print('PYTHON COMPLETE',len(done),flush=True);break
  time.sleep(10)
 else:raise TimeoutError('Finite7200secondofflinePythoncohortreviewbound')
except Exception as e:
 write(OUT/f'cohort-python-error-{int(time.time())}.json',{'type':type(e).__name__,'message':str(e),'processedWindowReports':done});raise
