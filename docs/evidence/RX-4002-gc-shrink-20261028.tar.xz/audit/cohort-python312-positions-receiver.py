import hashlib,importlib.util,json,pathlib,sys,time
root=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/audit');s=importlib.util.spec_from_file_location('reference',root/'sources/gc-runtime-audit.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
cpp=root/'cohort-window-positions-offsets-1000-native-r1-receiver.json';r=json.loads(cpp.read_text());start=time.time();p=m.audit(r['path'],r['maxStreamMiB'])
for k in ('bytes','sha256','events','valid','summary','maxStreamMiB'):assert p[k]==r[k],k
assert {str(k):v for k,v in p['marks'].items()}==r['marks']
exe=pathlib.Path(sys.executable).resolve();p.update(case=r['case'],role=r['role'],cppReport=str(cpp),bothAgree=True,elapsedSeconds=time.time()-start,python={'executable':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'version':sys.version})
with (root/'cohort-python312-positions-offsets-1000-native-r1-receiver.json').open('x') as f:json.dump(p,f,indent=2);f.write('\n')
print('positions-offsets-1000-native-r1 receiver',p['events'],round(p['elapsedSeconds'],2),flush=True)
