import hashlib,json,pathlib
root=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');p=root/'runtime/native-controls-v5/native-shrink.rdxgc'
raw=p.read_bytes();pos=raw.index(b'\n')+1
header=json.loads(raw[:pos]);seq=gc=0;inside=False;locked=False;trims=[];overlaps=[];last=None

def integer():
 global pos
 value=shift=0
 while True:
  byte=raw[pos];pos+=1;value|=(byte&127)<<shift
  if not byte&128:return value
  shift+=7
while True:
 kind=integer()
 if kind==0:
  n=integer();footer=json.loads(raw[pos:pos+n]);pos+=n;assert pos==len(raw);break
 row=(kind,*(integer() for _ in range(5)));seq+=1
 _,a,to,size,old,marker=row
 if last and last['sequence']==seq-1:
  assert row==(4,last['address'],0,last['new'],0,0)
 if kind==8:inside=True;locked=False;gc+=1
 elif kind==9:inside=False
 elif kind==3 and inside:
  assert not locked and 0<size<old
  last={'sequence':seq,'gc':gc,'address':a,'old':old,'new':size,'tail':[a+size,a+old]};trims.append(last)
 elif kind==2 and inside:
  locked=True
  for t in trims:
   if a==to:continue
   lo=max(to,t['tail'][0]);hi=min(to+size,t['tail'][1])
   if lo<hi:overlaps.append({'sequence':seq,'gc':gc,'source':a,'destination':to,'bytes':size,'overlapBytes':hi-lo,'trimSequence':t['sequence']})
 elif kind==10:locked=True
assert seq==footer['events'] and len(trims)==footer['gc_pre_move_shrinks']==35
result={'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'events':seq,'inGcSizeChanges':trims,'laterTailDestinationOverlaps':overlaps,'laterTailDestinationOverlapCount':len(overlaps),'scope':'Literal raw event/adjacent update and later numeric address overlaps. Full monitored extent accounting established separately by two independent replays; no concrete object type inferred.'}
assert len(overlaps)==13
(root/'audit/native-tail-witnesses.json').write_text(json.dumps(result,indent=2)+'\n')
print('Literal native control:',seq,'events;',len(trims),'pre-move paired shrinks;',len(overlaps),'later move destinations overlapping released tails')
