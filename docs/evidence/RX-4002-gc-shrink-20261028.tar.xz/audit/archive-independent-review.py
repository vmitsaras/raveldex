"""Verify closed raw archives and concatenated stream hashes without extraction."""
import hashlib,importlib.util,json,pathlib,stat,tarfile,time
ROOT=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');OUT=ROOT/'audit';REPO=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex')
s=importlib.util.spec_from_file_location('archive',REPO/'bench/memory/runtime-archive.py');archive=importlib.util.module_from_spec(s);s.loader.exec_module(archive)
def parse(raw):return json.loads(raw,object_pairs_hook=archive.unique_members)
def read(p):return parse(p.read_bytes())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def bind(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def manifest(p):
 with tarfile.open(p,'r|xz') as tar:
  first=next(iter(tar));assert first.name=='MANIFEST.json' and first.isfile() and 0<=first.size<=8*1048576
  raw=tar.extractfile(first).read();return parse(raw),hashlib.sha256(raw).hexdigest()
cohort=read(OUT/'cohort-v6-terminal-independent-review.json');expected={}
for w in cohort['actualAttemptWindows']:
 receipt=read(pathlib.Path(w['fullReplayReceipt']['path']));name=str(pathlib.Path(receipt['path']).resolve().relative_to(ROOT.resolve()))
 assert name not in expected;expected[name]={'bytes':w['bytes'],'sha256':w['sha256']}
assert len(expected)==39
verified=[];known_archives={};stream_hashers={};stream_offsets={};full_streams={};seen_parts=set();started=time.time()
def index_maps(index):
 assert index['schema']=='raveldex-raw-parts-v1' and len(index['streams'])<=64
 assert len({x['name'] for x in index['streams']})==len(index['streams'])
 total=0;parts={};streams={}
 for row in index['streams']:
  archive.safe(row['name']);assert row['name'] in expected and type(row['bytes']) is int and 0<row['bytes']<=8*1024**3
  assert {'bytes':row['bytes'],'sha256':row['sha256']}==expected[row['name']]
  assert 0<len(row['parts'])<=64;offset=0
  for i,p in enumerate(row['parts']):
   archive.safe(p['name']);archive.safe(p['archive']);assert len(pathlib.PurePosixPath(p['archive']).parts)==1 and p['archive'].endswith('.tar.xz')
   assert p['name']==f'raw/{row["name"]}.part-{i:03d}' and type(p['offset']) is int and p['offset']==offset
   assert type(p['bytes']) is int and 0<p['bytes']<=128*1048576;offset+=p['bytes']
   key=(p['archive'],p['name']);assert key not in parts;parts[key]=(row,p)
  assert offset==row['bytes'];total+=row['bytes'];streams[row['name']]=row
 assert total<=64*1024**3
 paths=[a['path'] for a in index['archives']];assert len(paths)==len(set(paths))
 for a in index['archives']:
  archive.safe(a['path']);assert pathlib.PurePosixPath(a['path']).parent==pathlib.PurePosixPath('docs/evidence')
  assert type(a['bytes']) is int and 0<a['bytes']<100*1048576
 return parts,streams,total
try:
 while time.time()-started<7200:
  final=(ROOT/'raw-index.json').exists();indexpath=ROOT/('raw-index.json' if final else 'raw-index-progress-v3.json');index=read(indexpath);partmap,streammap,total=index_maps(index)
  for position,a in enumerate(index['archives']):
   if a['path'] in known_archives:
    assert known_archives[a['path']]==a;continue
   p=REPO/a['path'];assert stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size==a['bytes'] and sha(p)==a['sha256']
   data,mhash=manifest(p);assert data['schema']=='raveldex-ac03-workload-archive-v1'
   # Progress indexes commit streams after every part has an assigned archive.
   # Defer only this archive and its successors until those identities arrive.
   if any((p.name,x['name']) not in partmap for x in data['members']):break
   standalone=archive.verify(p);assert standalone==a['verification'] and standalone['manifestSha256']==mhash
   members=[];local_names=set()
   with tarfile.open(p,'r|xz') as tar:
    for item in tar:
     archive.safe(item.name);assert item.isfile() and item.name not in local_names;local_names.add(item.name)
     if item.name=='MANIFEST.json':continue
     assert (p.name,item.name) not in seen_parts;row,part=partmap[(p.name,item.name)]
     match=next(x for x in data['members'] if x['name']==item.name)
     assert item.size==part['bytes']==match['bytes'] and part['sha256']==match['sha256'] and item.size<=128*1048576
     name=row['name'];assert stream_offsets.get(name,0)==part['offset'];h=stream_hashers.setdefault(name,hashlib.sha256());digest=hashlib.sha256();n=0
     source=tar.extractfile(item)
     for b in iter(lambda:source.read(1048576),b''):
      n+=len(b);assert n<=part['bytes'];digest.update(b);h.update(b)
     assert n==part['bytes'] and digest.hexdigest()==part['sha256'];stream_offsets[name]=part['offset']+n;seen_parts.add((p.name,item.name));members.append({'name':item.name,'bytes':n,'sha256':digest.hexdigest(),'stream':name,'offset':part['offset']})
     if stream_offsets[name]==row['bytes']:
      assert h.hexdigest()==row['sha256'];full_streams[name]={'bytes':row['bytes'],'sha256':h.hexdigest(),'outcome':'Exact concatenated archive bytes match the accepted full-stream replay hash; no extraction'}
   assert len(members)==len(data['members']) and local_names=={'MANIFEST.json',*(x['name'] for x in data['members'])}
   record={'path':a['path'],'compressedBytes':a['bytes'],'sha256':a['sha256'],'manifestSha256':mhash,'standaloneVerification':standalone,'parts':members,'outcome':'Pass'};verified.append(record);known_archives[a['path']]=a
   progress={'status':'In progress','archivesVerified':len(verified),'membersVerified':len(seen_parts),'fullStreamsVerified':len(full_streams),'fullStreamBytesVerified':sum(x['bytes'] for x in full_streams.values()),'elapsedSeconds':time.time()-started,'archives':verified,'streams':full_streams,'scope':'Byte/container and concatenation identity only; no extraction or new numerical/runtime workload'}
   (OUT/'archive-independent-progress.json').write_text(json.dumps(progress,indent=2)+'\n');print('Verified archive',position+1,p.name,'full streams',len(full_streams),flush=True)
  if final and len(verified)==len(index['archives']):
   assert set(streammap)==set(expected)==set(full_streams) and len(streammap)==39
   assert seen_parts==set(partmap) and total==sum(x['bytes'] for x in expected.values())==49385850374
   result={'schema':'raveldex-independent-raw-archive-review-v1','status':'Pass','archivesVerified':len(verified),'membersVerified':len(seen_parts),'fullStreamsVerified':39,'rawBytes':total,'compressedArchiveBytes':sum(x['compressedBytes'] for x in verified),'archives':verified,'streams':full_streams,'index':bind(indexpath),'verifierSource':bind(REPO/'bench/memory/runtime-archive.py'),'independentReviewSource':bind(pathlib.Path(__file__)),'acceptedCohortReceipt':bind(OUT/'cohort-v6-terminal-independent-review.json'),'elapsedSeconds':time.time()-started,'scope':'All accepted closed containers verified with runtime-archive.py; every regular part independently hashed again and concatenated in offset order, without extraction. All 39 full hashes match the accepted independent numerical replay receipts. No archive/raw prefix is promoted to a numeric metric.','limits':{'compressedArchiveBytesExclusive':100*1048576,'regularPartBytes':128*1048576,'streamBytes':8*1024**3,'aggregateBytes':64*1024**3,'partsPerStream':64,'streams':64}}
   with (OUT/'newrawarchive-review.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
   progress['status']='Complete; see newrawarchive-review.json';(OUT/'archive-independent-progress.json').write_text(json.dumps(progress,indent=2)+'\n');print('ARCHIVE REVIEW COMPLETE',len(verified),len(seen_parts),len(full_streams),flush=True);break
  time.sleep(10)
 else:raise TimeoutError('Finite7200secondarchiveverificationbound')
except Exception as e:
 with (OUT/f'archive-independent-error-{int(time.time())}.json').open('x') as f:json.dump({'type':type(e).__name__,'message':str(e),'archivesVerified':len(verified),'fullStreamsVerified':len(full_streams)},f,indent=2);f.write('\n')
 raise
