import json,os,pathlib,signal,time
root=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/audit');target=root/'cohort-python-source-phrase-1000-native-r1-receiver.json';start=time.time()
while time.time()-start<900:
 if target.exists():
  try:report=json.loads(target.read_text())
  except json.JSONDecodeError:time.sleep(.1);continue
  assert report['bothAgree'] and report['role']=='receiver'
  try:os.kill(56785,signal.SIGTERM);outcome='Stopped exactowned oldobserver after currentfullresult'
  except ProcessLookupError:outcome='Oldobserver alreadyexited after currentfullresult'
  with (root/'cohort-old-python-stop-receipt.json').open('x') as f:json.dump({'pid':56785,'completedCurrentReport':str(target),'outcome':outcome,'elapsedSeconds':time.time()-start},f,indent=2);f.write('\n')
  break
 time.sleep(.1)
else:raise TimeoutError('No currentresult within900seconds; no signal sent')
