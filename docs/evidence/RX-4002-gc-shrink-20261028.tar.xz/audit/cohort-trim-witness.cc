// Offline raw row witness scan only; no native/runtime calls or metric derivation.
#include <cstdint>
#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using U=uint64_t;
struct Trim{U seq,gc,a,n,old;bool paired=false;};
int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("path required");FILE*f=fopen(argv[1],"rb");if(!f)throw std::runtime_error("open");U bytes=0;auto get=[&](){int c=fgetc(f);if(c==EOF||++bytes>U(4096)*1048576)throw std::runtime_error("framing bound");return c;};auto integer=[&](){U n=0;for(int k=0;k<10;k++){int c=get();if(k==9&&c>1)throw std::runtime_error("overflow");n|=U(c&127)<<(7*k);if(!(c&128))return n;}throw std::runtime_error("varint");};for(int i=0;i<4096;i++){if(get()=='\n')break;if(i==4095)throw std::runtime_error("header");}U seq=0,gc=0,moves=0,census=0;bool inside=false;std::vector<Trim> trims;struct Reuse{U seq,gc,source,dest,n,trim,overlap;};std::vector<Reuse>reuse;
while(true){U k=integer();if(!k){U n=integer();if(n>4096)throw std::runtime_error("footer");for(U j=0;j<n;j++)get();if(fgetc(f)!=EOF)throw std::runtime_error("trailing");break;}U a=integer(),to=integer(),n=integer(),old=integer(),marker=integer();++seq;
if(!trims.empty()&&trims.back().seq==seq-1){auto&t=trims.back();t.paired=(k==4&&a==t.a&&n==t.n&&to==0&&old==0&&marker==0);}
if(k==8){inside=true;++gc;moves=census=0;}
else if(k==9)inside=false;
else if(k==3&&inside){if(!a||!n||n>=old||old>UINT64_MAX-a||moves||census)throw std::runtime_error("unexpected GC trim witness");trims.push_back({seq,gc,a,n,old});}
else if(k==2&&inside){++moves;if(n>UINT64_MAX-to)throw std::runtime_error("destination overflow");for(auto&t:trims){U lo=std::max(to,t.a+t.n),hi=std::min(to+n,t.a+t.old);if(lo<hi)reuse.push_back({seq,gc,a,to,n,t.seq,hi-lo});}}
else if(k==10)++census;
}
fclose(f);std::cout<<"{\"events\":"<<seq<<",\"bytes\":"<<bytes<<",\"gcSizeChanges\":[";bool comma=false;for(auto&t:trims){if(comma)std::cout<<',';comma=true;std::cout<<"{\"sequence\":"<<t.seq<<",\"gc\":"<<t.gc<<",\"address\":"<<t.a<<",\"newBytes\":"<<t.n<<",\"oldBytes\":"<<t.old<<",\"adjacentMatchingUpdate\":"<<(t.paired?"true":"false")<<'}';}std::cout<<"],\"laterTailDestinationOverlaps\":[";comma=false;for(auto&r:reuse){if(comma)std::cout<<',';comma=true;std::cout<<"{\"sequence\":"<<r.seq<<",\"gc\":"<<r.gc<<",\"source\":"<<r.source<<",\"destination\":"<<r.dest<<",\"bytes\":"<<r.n<<",\"trimSequence\":"<<r.trim<<",\"overlapBytes\":"<<r.overlap<<'}';}std::cout<<"]}\n";
}catch(std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
