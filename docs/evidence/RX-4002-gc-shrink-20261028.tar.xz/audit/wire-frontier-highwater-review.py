"""Independent existing-row API-event-order wire-capacity replay. No target calls."""
import argparse,collections,hashlib,json,pathlib,re,struct,datetime

def need(ok,why):
 if not ok:raise ValueError(why)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def prefix(meta):
 raw=bytes.fromhex(meta['prefixHex']);need(len(raw)==meta['prefixBytes']<=256,'prefix extent');pos=0
 def take(n):
  nonlocal pos
  need(0<=n and pos+n<=len(raw),'prefix bound');v=raw[pos:pos+n];pos+=n;return v
 def number():
  n=0
  for shift in range(0,35,7):
   b=take(1)[0];n|=(b&127)<<shift
   if not b&128:need(n<2**32,'integer bound');return n
  raise ValueError('integer framing')
 def tag():
  b=take(1)[0]
  while b==0:b=take(1)[0]
  return b
 def text():
  t=tag();n=number();need(t in (34,83,99) and n<=96,'metadata string');return take(n).decode({34:'latin1',83:'utf8',99:'utf-16le'}[t])
 def integer():
  t=tag()
  if t in (73,85):
   n=number();return (n>>1)^-(n&1) if t==73 else n
  need(t==78,'metadata integer');v=struct.unpack('<d',take(8))[0];need(v.is_integer() and 0<=v<=2**53-1,'metadata integer range');return int(v)
 need(take(1)==b'\xff' and number()==21 and take(1)==b'\xfe','Blink version');trailer=take(12)
 need(take(1)==b'\xff' and number()==16 and tag()==111,'V8 version')
 need(text()=='protocol' and integer()==1 and text()=='session','protocol')
 session=text();need(re.fullmatch('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',session),'session')
 need(text()=='id','id key');identifier=integer();need(identifier>0 and text()=='operation','operation key');operation=text();key=text()
 if key=='payload':kind=None;direction='main-to-worker'
 else:need(key=='kind','response key');kind=text();need(kind in ('result','error') and text()=='value','response metadata');direction='worker-to-main'
 need(pos==len(raw) and trailer.hex()==meta['trailerHeaderHex'],'exact prefix end')
 for key,value in dict(protocol=1,session=session,id=identifier,operation=operation,kind=kind,direction=direction).items():need(meta[key]==value,'prefix/metadata mismatch '+key)

def review(label,tracepath,hostpath):
 tracepath=pathlib.Path(tracepath);hostpath=pathlib.Path(hostpath);d=json.loads(tracepath.read_text());h=json.loads(hostpath.read_text())
 need(d['schema']=='raveldex-lldb-buffer-observation-v2' and not d['invalid'] and d['dropped']==0 and not d['pending'],'invalid/lost/pending native window')
 pid=d['pid'];need(pid==h['rendererPid'],'renderer PID');marks=h['pidProof']['marks'];tids={}
 for mark in marks:
  need(mark['pid']==pid,'proof PID')
  for realm in ('main','worker'):
   if mark['name'].endswith(':'+realm):need(realm not in tids or tids[realm]==mark['tid'],'proof thread ambiguity');tids[realm]=mark['tid']
 need(len(tids)==2 and tids['main']!=tids['worker'],'peer threads');need(h['isolates']['main']['id']!=h['isolates']['worker']['id'],'distinct Runtime isolates')
 edges={}
 for observations in [h.get('initialObservation',{}),*(c.get('observations',{}) for c in h['commands'])]:
  for realm in ('main','worker'):
   observed=observations.get(realm,{})
   need(observed.get('dropped',0)==0,'endpoint observation loss')
   for row in observed.get('rows',[]):
    key=(realm,row['sequence']);need(key not in edges or edges[key]==row,'endpoint sequence collision');edges[key]=row
 live={};births={};chains=collections.defaultdict(list);bindings={};stacks=collections.defaultdict(list);callids=set();pairs=0;counts=collections.Counter();bases=set();peak=0;peakrow=None;peaklive=[];frontiers=[];growth=[];windows=[]
 for sequence,row in enumerate(d['rows'],1):
  need(row['seq']==sequence and row['pid']==pid,'native sequence/PID');kind=row['kind'];counts[kind]+=1;tid=row['tid'];frame=row['nativeFrame']
  if tid:
   need(tid in tids.values() and frame is not None,'native peer/frame');bases.add(frame['pc']-frame['moduleOffset'])
  if kind=='native-call-begin':
   c=row['call'];need(c['callId'] not in callids and c['sp']==frame['sp'] and c['entryPC']==frame['pc'] and c['lr']==frame['lr'],'native begin frame')
   need(c['parentCallId']==(stacks[tid][-1]['callId'] if stacks[tid] else None),'native parent stack');callids.add(c['callId']);stacks[tid].append(c)
  elif kind=='native-call-return':
   need(bool(stacks[tid]),'return without call');c=stacks[tid].pop()
   need(row['callId']==c['callId'] and row['matchedEntryPC']==c['entryPC'] and row['matchedSP']==c['sp'] and row['matchedLR']==c['lr'] and row['matchedReturnPC']==c['returnPC'] and frame['pc']==c['returnPC'] and frame['sp']==c['sp'],'native return frame');pairs+=1
  elif kind=='buffer-live':
   a,n,g,chain=row['ptr'],row['cap'],row['allocation'],row['chain'];need(0<a<a+n<2**64 and 0<n<=64*1048576 and a not in live and g not in births,'birth identity/extent')
   need(all(a+n<=p or a>=p+v['cap'] for p,v in live.items()),'overlapping requested extents')
   previous=d['rows'][sequence-2] if sequence>1 else {}
   if row['origin']=='observed-copy-destination':need(previous.get('kind')=='copy-enter' and previous['dest']==a and previous['newCap']==n and previous['chain']==chain,'growth birth frontier')
   elif row['origin']=='realloc':need(previous.get('kind')=='realloc-return' and previous['dest']==a and previous['cap']==n and previous['chain']==chain,'allocation return frontier')
   elif row['origin']=='requested-buffer-alloc':need(previous.get('kind')=='buffer-alloc-return' and previous['ptr']==a and previous['cap']==n,'allocation return frontier')
   else:raise ValueError('unqualified birth origin')
   live[a]=dict(row);births[g]=dict(row);chains[chain].append(g)
  elif kind=='buffer-confirmed':
   need(row['ptr'] in live and all(live[row['ptr']][k]==row[k] for k in ('allocation','cap','chain')),'confirmation is not a birth')
  elif kind=='copy-enter':
   need(row['src'] in live and row['dest'] not in live and live[row['src']]['cap']==row['oldCap'] and 0<row['length']<=row['oldCap'] and row['length']<=row['newCap'],'growth copy source')
   growth.append({'sequence':sequence,'chain':row['chain'],'oldCapacity':row['oldCap'],'newCapacity':row['newCap'],'copiedBytes':row['length'],'actualPairRequestedBytes':row['oldCap']+row['newCap']})
  elif kind in ('buffer-resize','api-only-retirement'):
   raise ValueError('Observed route lacks this review\'s calibrated retirement/overlap policy: '+kind)
  elif kind in ('internal-free-return','final-free-return','root-free-return'):
   need(row['ptr'] in live and all(live[row['ptr']][k]==row[k] for k in ('allocation','cap','chain')),'unmatched free/birth');del live[row['ptr']]
  elif kind=='message-bound':
   need(row['ptr'] in live and live[row['ptr']]['allocation']==row['allocation'] and live[row['ptr']]['chain']==row['chain'],'message bound live generation');m=row['metadata'];prefix(m)
   need(m['processId']==pid and m['peer']==h['workerUrl'] and 0<m['wireBytes']<=live[row['ptr']]['cap'],'message process/peer/wire extent')
   sender=tids['main'] if m['direction']=='main-to-worker' else tids['worker'];need(m['senderTid']==sender,'sender thread')
   need(row['chain'] not in bindings or bindings[row['chain']]==m,'chain RPC identity');bindings[row['chain']]=m
  elif kind=='window-begin':windows.append({'label':row['label'],'sequence':sequence,'registeredWireBytesAtBegin':sum(x['cap'] for x in live.values()),'birthsAtBegin':[x['allocation'] for x in live.values()]})
  total=sum(x['cap'] for x in live.values())
  if kind in ('buffer-live','internal-free-return','final-free-return','root-free-return'):frontiers.append({'sequence':sequence,'kind':kind,'bytes':total})
  if total>peak:peak=total;peakrow=sequence;peaklive=[dict(v) for v in live.values()]
 need(len(bases)==1 and all(not v for v in stacks.values()),'native module/frame closure')
 need(not live and not d['remaining'],'nonzero/censored final registered state');need(set(chains)==set(bindings),'unbound registered wire chain')
 need({str(k):v for k,v in bindings.items()}==d['bindings'],'native binding summary')
 message_rows=[]
 for chain,m in bindings.items():
  direction=m['direction'];sender='main' if direction=='main-to-worker' else 'worker';receiver='worker' if sender=='main' else 'main'
  matched=[]
  for realm,edge_direction in ((sender,'send'),(receiver,'read')):
   for edge in ('begin','end'):
    hits=[r for (rr,_),r in edges.items() if rr==realm and r['direction']==edge_direction and r['edge']==edge and all(r.get(k)==m[k] for k in ('protocol','session','id','operation','kind'))]
    need(len(hits)==1,'missing/duplicate actual endpoint RPC edge');matched.append({'realm':realm,'direction':edge_direction,'edge':edge,'sequence':hits[0]['sequence']})
  message_rows.append({'chain':chain,'metadata':m,'allocations':chains[chain],'endpointEdges':matched})
 peak_allocations=[]
 for row in peaklive:
  m=bindings[row['chain']];peak_allocations.append({'allocation':row['allocation'],'pointer':row['ptr'],'capacity':row['cap'],'chain':row['chain'],'origin':row['origin'],'birthSequence':row['seq'],'session':m['session'],'id':m['id'],'operation':m['operation'],'kind':m['kind'],'direction':m['direction'],'senderTid':m['senderTid'],'peer':m['peer']})
 return {'label':label,'status':'Pass for declared registered wire-frontier quantity','trace':{'path':str(tracepath),'sha256':sha(tracepath)},'controller':{'path':str(hostpath),'sha256':sha(hostpath),'outcome':h.get('outcome'),'ownedBrowserClosed':h.get('ownedBrowserClosed'),'commandFailures':h.get('commandFailures'),'containedResults':[{'command':c['command'],'result':c.get('result'),'error':c.get('error')} for c in h['commands']]},'rendererPid':pid,'peer':h['workerUrl'],'threads':tids,'runtimeIsolates':h['isolates'],'nativeRows':len(d['rows']),'nativeFramePairs':pairs,'births':len(births),'freeReturns':sum(counts[k] for k in ('internal-free-return','final-free-return','root-free-return')),'confirmationsNotBirths':counts['buffer-confirmed'],'growthCopies':growth,'apiEventOrderWireCapacityHighWaterBytes':peak,'peakSequence':peakrow,'peakAllocations':peak_allocations,'registeredAtEndBytes':0,'inPlaceResizeRows':counts['buffer-resize'],'apiOnlyRetirementRows':counts['api-only-retirement'],'windowsWithoutReset':windows,'frontiers':frontiers,'messages':message_rows,'scope':'Sum of previously registered selected API-requested wire-buffer extents at actual native allocation-return/growth-copy-entry/free-return frontiers. Includes observed growth old/new coexistence and cross-message concurrence. No physical allocator usable/reserved/committed bytes, continuous physical/global native peak, V8 receiver-string liveness or complete store-traffic claim. A later host watchdog does not change these complete contained native rows or successful public outcomes; it does not become a normal owner-completion claim.'}

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--case',nargs=3,action='append',metavar=('LABEL','TRACE','CONTROLLER'),required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();cases=[review(*x) for x in a.case]
 result={'schema':'raveldex-independent-wire-frontier-highwater-review-v1','status':'Pass for declared bounded wire-frontier observations','reviewedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewSourceSha256':sha(__file__),'cases':cases,'method':'Independent event/state/frame/prefix/RPC replay; imports no candidate observer classes or linkage analyzer. No target/runtime/browser/workload calls. The metric is defined at recorded native frontiers and uses requested extents, not serialized string lengths or receiver lifetime proxies.','AC03StatusChanged':False}
 with a.output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps([{'label':x['label'],'highWaterBytes':x['apiEventOrderWireCapacityHighWaterBytes'],'nativePairs':x['nativeFramePairs'],'births':x['births'],'frees':x['freeReturns']} for x in cases]))
