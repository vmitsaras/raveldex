import hashlib,importlib.util,io,json,pathlib,unittest
root=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex/bench/memory')
out=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/audit')
fixtures=out/'fixtures-final';fixtures.mkdir()
spec=importlib.util.spec_from_file_location('literal_tests',root/'gc-runtime-audit.test.py');tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
original=tests.Replay.run_bytes;records=[]
def capture(self,raw):
 path=fixtures/f'{len(records)+1:03d}.rdxgc';path.write_bytes(raw)
 row={'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};records.append(row)
 try:
  result=original(self,raw);row['accepted']=True;row['valid']=result['valid'];return result
 except ValueError as e:row['accepted']=False;row['refusal']=str(e);raise
tests.Replay.run_bytes=capture
log=io.StringIO();result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(tests.Replay))
(out/'python-literals-final.log').write_text(log.getvalue())
(out/'python-literal-fixtures-final.json').write_text(json.dumps({'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'fixtures':records},indent=2)+'\n')
print(log.getvalue());print('Saved fixtures:',len(records))
raise SystemExit(not result.wasSuccessful())
