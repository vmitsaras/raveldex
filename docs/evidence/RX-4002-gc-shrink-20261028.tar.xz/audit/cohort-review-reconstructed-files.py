"""Read-only independent hash checks of the parent's new reconstructed files."""
import hashlib,json,pathlib,stat,time
ROOT=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');OUT=ROOT/'audit'
def read(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
receipt=read(ROOT/'reconstruction.json');index=read(ROOT/'raw-index.json');review=read(OUT/'cohort-summary-reassembler-review.json')
assert receipt['outcome']=='Pass' and len(receipt['streams'])==len(index['streams'])==39
assert receipt['rawIndexSha256']==sha(ROOT/'raw-index.json') and receipt['reassemblerSha256']==sha(ROOT/'reassemble.py')
assert receipt['reassemblerSha256']==next(x['sha256'] for x in review['bindings'] if x['path'].endswith('/reassemble.py'))
base=pathlib.Path(receipt['root']).resolve();assert base.name.startswith('raveldex-shrink-verified-20261028.')
expected={x['name']:x for x in index['streams']};assert sum(x['bytes'] for x in expected.values())==49385850374
rows=[];started=time.time()
for row in receipt['streams']:
 name=pathlib.PurePosixPath(row['name']);assert not name.is_absolute() and all(x not in ('','.','..') for x in row['name'].split('/'))
 assert row['name'] in expected and row['bytes']==expected[row['name']]['bytes'] and row['sha256']==expected[row['name']]['sha256']
 path=base/'assembled'/name;assert stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size==row['bytes']<=8*1024**3
 digest=sha(path);assert digest==row['sha256'];rows.append({'name':row['name'],'path':str(path),'bytes':row['bytes'],'sha256':digest,'outcome':'Pass'})
 print('Reconstructed file Pass',len(rows),row['name'],flush=True)
assert {x['name'] for x in rows}==set(expected)
result={'schema':'raveldex-independent-reconstructed-files-review-v1','status':'Pass','files':rows,'streams':39,'bytes':sum(x['bytes'] for x in rows),'elapsedSeconds':time.time()-started,'reconstructionReceiptSha256':sha(ROOT/'reconstruction.json'),'rawIndexSha256':sha(ROOT/'raw-index.json'),'reviewedReassemblerSha256':receipt['reassemblerSha256'],'scope':'Read-only hashes of all39 actual files reconstructed by the parent into a new task-owned root. No extraction, assembly or numerical/runtime workload was executed by this reviewer. Every full file matches the final raw index and the accepted full-stream replay identity.'}
with (OUT/'cohort-reconstruction-independent-review.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
