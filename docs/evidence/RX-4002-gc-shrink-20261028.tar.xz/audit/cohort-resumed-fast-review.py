"""Offline completed-cell review; no Node/browser/product workload launch."""
import hashlib,importlib.util,json,pathlib,time
ROOT=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');OUT=ROOT/'audit';REPO=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex')
EXPECTED='5f9567dbd6d6cf10c0deafa7f6779f81b68265831e14edd7049a86f211fbd843';PACKAGE='6ff6e90128f60af39bb8f47800c61ed83d85d4ded7a8e3c96d2bd34467f9c437'
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
fast=load('fast',OUT/'sources/gc-runtime-fast-audit.py');literal=load('literal',ROOT/'literal-codec-audit.py')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def write(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def review(hostpath):
 h=json.loads(hostpath.read_text());name=hostpath.parent.name;hosthash=sha(hostpath);assert h['runtimeSha256']==EXPECTED and h['packageSha256']==PACKAGE and len(h['productionFiles'])==208
 assert sha(ROOT/'runtime/node-gc-shrink-v5')==EXPECTED
 rows=h['processes'];roles=[r['role'] for r in rows];assert roles in (['producer'],['producer','receiver'],['receiver'])
 if roles==['receiver']:
  reused=h['reusedProducer'];priorpath=pathlib.Path(reused['host']);prior=json.loads(priorpath.read_text());encoded=pathlib.Path(reused['encoded'])
  assert sha(priorpath)==reused['hostSha256'] and sha(encoded)==reused['encodedSha256']
  assert (prior['runtimeSha256'],prior['mode'],prior['size'],prior['format'])==(h['runtimeSha256'],h['mode'],h['size'],h['format'])
  producer=prior['processes'][0];assert producer['role']=='producer' and producer['child']['operation']['publicOutcome']=='Pass' and producer['child']['traceStatus']==0
  assert producer['child']['export']['path']==str(encoded)
  assert rows[0]['argv'][-3]==str(encoded)
 consumer=pathlib.Path(rows[0]['cwd']);assert sha(consumer/'vmitsaras-raveldex-0.0.0.tgz')==PACKAGE
 installed=consumer/'node_modules/@vmitsaras/raveldex'
 for item in h['productionFiles']:assert sha(installed/item['path'])==sha(REPO/item['path'])==item['sha256']
 for item in h['sources']:assert sha(pathlib.Path(item['target']))==sha(REPO/item['path'])==item['sha256']
 results=[]
 for r in rows:
  assert r['exitCode']==0 and not r.get('timedOut') and all(r[k] for k in ('runtimeUnchanged','productionUnchanged','sourcesUnchanged'))
  c=r['child'];folder=hostpath.parent/r['role'];assert c==json.loads((folder/'report.json').read_text())
  assert c['disposed'] and c['deadlineMs']==60000 and c['batchSize']==256 and c['changedFixture'] is False
  assert c['runtime']['sha256']==EXPECTED and pathlib.Path(c['runtime']['path']).resolve()==(ROOT/'runtime/node-gc-shrink-v5').resolve()
  assert r['argv'][-1]==EXPECTED and c['qualification']['profileId']=='rx4002-gc-'+EXPECTED[:12]+'-ascii-v2'
  assert c['qualification']['scope']=='exact-node-runtime' and c['runtime']['versions']['node']=='24.21.0' and c['runtime']['versions']['v8']=='13.6.233.17-node.53'
  for v in c['verification']:
   assert v['total']==h['size'] and v['literalFirst20AllIds'] and v['revision']==((h['size']+255)//256 if r['role']=='producer' else 2)
   for q in v['checks']:
    candidates=range(h['size']) if q['name']=='common-exact-total-top20' else [i for i in range(h['size']) if i%37==7] if q['name']=='selective-exact-total-top20' else [i for i in range(h['size']) if i%3==0]
    eligible={f'item:{i:05d}' for i in candidates};assert q['total']==len(eligible) and q['returned']==min(20,len(eligible)) and len(q['ids'])==len(set(q['ids']))==q['returned'] and set(q['ids'])<=eligible
  operation=c['operation'];assert operation['publicOutcome'] in ('Pass','Rejected')
  if operation['publicOutcome']=='Rejected':
   assert operation['error']['code'] in ('DEADLINE_EXCEEDED','WORK_LIMIT_EXCEEDED','LIMIT_EXCEEDED','RESOURCE_EXHAUSTED')
   if r['role']=='receiver':assert c['priorStatePreserved']
  elif r['role']=='receiver':assert c['restore']['originRevision']==(h['size']+255)//256 and c['restore']['revision']==2 and c['restore']['reindexed']==(h['format']=='source')
  path=pathlib.Path(operation['file']);result=fast.audit(path,OUT/'gc-runtime-replay-v2',c['streamMiB'])
  assert result['valid']==(c['traceStatus']==0)
  if result['valid']:
   assert result['marks']['100']=={'count':1,'firstSequence':1,'lastSequence':1}
   assert result['marks']['101']=={'count':1,'firstSequence':result['events'],'lastSequence':result['events']}
  for item in r['artifacts']:
   p=folder/item['name'];assert p.stat().st_size==item['bytes']
   assert (result['sha256'] if p==path else sha(p))==item['sha256']
  result.update(case=name,role=r['role'],mode=h['mode'],size=h['size'],format=h['format'],publicOutcome=operation['publicOutcome'],publicError=operation['error'],disposed=c['disposed'],hostSha256=hosthash,sourceIdentityVerified=True,markerBoundaryChecks='Pass' if result['valid'] else 'Invalid window retained',scope='Full C++ replay; host-bound runtime SHA; unchanged208productionfiles/package/stagedsources and public report. Not default-runtime latency/physical memory/fullranking.')
  write(OUT/f'cohort-resumed-window-{name}-{r["role"]}.json',result);results.append(result)
  print(name,r['role'],result['events'],result['valid'],operation['publicOutcome'],flush=True)
 exported=pathlib.Path(h['reusedProducer']['encoded']) if roles==['receiver'] else hostpath.parent/'producer/encoded.json';lit=literal.check(exported) if exported.exists() else None
 if roles==['producer']:assert rows[0]['child']['operation']['publicOutcome']=='Rejected' and rows[0]['receiverNotRun']
 assert sha(hostpath)==hosthash
 report={'case':name,'host':str(hostpath),'hostSha256':hosthash,'runtimeSha256':EXPECTED,'packageSha256':PACKAGE,'productionFilesVerified':208,'stagedSourcesVerified':h['sources'],'windows':[str(OUT/f'cohort-resumed-window-{name}-{r["role"]}.json') for r in rows],'literalExport':lit,'roles':roles,'successfulRoundTrip':len(rows)==2 and all(r['child']['operation']['publicOutcome']=='Pass' for r in rows),'reusedProducer':h.get('reusedProducer'),'allLaunchedDisposed':True,'publicOutcomes':[r['child']['operation']['publicOutcome'] for r in rows]}
 write(OUT/f'cohort-resumed-host-{name}.json',report)
 return report
start=time.time();completed=[]
try:
 while time.time()-start<7200:
  if not (ROOT/'matrix-progress-v2.json').exists():
   time.sleep(10);continue
  progress=json.loads((ROOT/'matrix-progress-v2.json').read_text())
  planned=[{'case':'source-phrase-10000-source-r1-receiver-4g'},*progress['processes']]
  for cell in planned:
   path=ROOT/'codecs'/cell['case']/'host.json'
   if cell['case'] in completed or not path.exists():continue
   h=json.loads(path.read_text())
   if 'finished' not in h:continue
   review(path);completed.append(cell['case'])
  terminal='finishedUnix' in progress or 'stopped' in progress
  if terminal and all(p['case'] in completed for p in planned):
   write(OUT/'cohort-resumed-fast-complete.json',{'completedCases':completed,'matrixOutcome':progress.get('outcome'),'matrixStopped':progress.get('stopped'),'matrixProgressSha256':sha(ROOT/'matrix-progress-v2.json'),'elapsedSeconds':time.time()-start,'scope':'All finalized launched cells independently reviewed; expected planned36windows assessed in final aggregation, not assumed.'});print('FAST COMPLETE',len(completed),flush=True);break
  time.sleep(10)
 else:raise TimeoutError('Finite7200secondofflinecohortreviewbound')
except Exception as e:
 write(OUT/f'cohort-resumed-fast-error-{int(time.time())}.json',{'type':type(e).__name__,'message':str(e),'completedCases':completed});raise
