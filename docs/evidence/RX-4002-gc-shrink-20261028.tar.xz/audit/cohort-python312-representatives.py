"""Remaining first-repetition1k full Python reference audits, offline only."""
import hashlib,importlib.util,json,pathlib,sys,time
ROOT=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');OUT=ROOT/'audit';s=importlib.util.spec_from_file_location('reference',OUT/'sources/gc-runtime-audit.py');reference=importlib.util.module_from_spec(s);s.loader.exec_module(reference)
exe=pathlib.Path(sys.executable).resolve();identity={'executable':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'version':sys.version}
reports=[]
for case in ('source-phrase-1000-native-r1','source-phrase-1000-source-r1'):
 for role in ('producer','receiver'):
  cpp=OUT/f'cohort-window-{case}-{role}.json';r=json.loads(cpp.read_text());started=time.time();p=reference.audit(r['path'],r['maxStreamMiB'])
  for key in ('bytes','sha256','events','valid','independentReplay','summary','maxStreamMiB'):assert p[key]==r[key],(case,role,key)
  assert {str(k):v for k,v in p['marks'].items()}==r['marks']
  p.update(case=case,role=role,cppReport=str(cpp),bothAgree=True,elapsedSeconds=time.time()-started,python=identity,scope='Representative firstrepetition1k operation/configuration; laterrepetitions receive completeC++replay, not unnecessaryPythonduplicates.')
  path=OUT/f'cohort-python312-{case}-{role}.json'
  with path.open('x') as f:json.dump(p,f,indent=2);f.write('\n')
  reports.append(str(path));print(case,role,p['events'],round(p['elapsedSeconds'],2),flush=True)
with (OUT/'cohort-python312-representatives-complete.json').open('x') as f:json.dump({'python':identity,'reports':reports,'scope':'Fourremainingfirstrep1k operations; initial3.9positionspair separate.'},f,indent=2);f.write('\n')
