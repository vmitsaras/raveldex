"""Aggregate completed offline receipts; preserves every actualattempt/profile."""
import collections,hashlib,itertools,json,pathlib,re
ROOT=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');OUT=ROOT/'audit'
def read(p):return json.loads(p.read_text())
def bind(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
assert (OUT/'cohort-fast-complete.json').exists() and (OUT/'cohort-resumed-fast-complete.json').exists() and (OUT/'cohort-v6-fast-complete.json').exists()
configs=[('source-phrase',10000,'native'),('source-phrase',1000,'native'),('positions-offsets',1000,'native'),('source-phrase',1000,'source'),('source-phrase',10000,'source'),('positions-offsets',10000,'native')]
expected={(mode,size,fmt,rep,role) for (mode,size,fmt),rep,role in itertools.product(configs,range(1,4),('producer','receiver'))}
actual=[];selected={};exports={};hostbindings=[]
for pattern in ('cohort-host-*.json','cohort-resumed-host-*.json','cohort-v6-host-*.json'):
 for p in sorted(OUT.glob(pattern)):
  h=read(p);rawhost=read(pathlib.Path(h['host']));assert h['hostSha256']==hashlib.sha256(pathlib.Path(h['host']).read_bytes()).hexdigest()
  hostbindings.append(bind(p));rep=int(re.search(r'-r(\d+)',h['case']).group(1))
  literal=h.get('literalExport')
  if literal:exports[str(pathlib.Path(literal['path']).resolve())]=literal
  for window in h['windows']:
   q=pathlib.Path(window);w=read(q);key=(w['mode'],w['size'],w['format'],rep,w['role']);assert key in expected
   if w['valid']:
    assert w['markerBoundaryChecks']=='Pass' and w['marks']['100']=={'count':1,'firstSequence':1,'lastSequence':1} and w['marks']['101']=={'count':1,'firstSequence':w['events'],'lastSequence':w['events']}
    assert w['summary']['errors']==w['summary']['dropped_events']==0
   else:assert all(w['summary'][k] is None for k in ('gross_birth_bytes','mutator_occupied_high_water_bytes','occupied_at_stop_bytes','trimmed_bytes','gc_removed_bytes'))
   row={'key':key,'case':w['case'],'role':w['role'],'runtimeSha256':h['runtimeSha256'],'profileId':'rx4002-gc-'+h['runtimeSha256'][:12]+'-ascii-v2','valid':w['valid'],'publicOutcome':w['publicOutcome'],'publicError':w['publicError'],'events':w['events'],'bytes':w['bytes'],'sha256':w['sha256'],'summary':w['summary'],'fullReplayReceipt':bind(q),'extentCap':next(x['child'].get('extentCap',1000000) for x in rawhost['processes'] if x['role']==w['role']),'streamMiB':w['maxStreamMiB'],'sourceIdentityVerified':w['sourceIdentityVerified'],'disposed':w['disposed']}
   actual.append(row)
   priority=3 if pattern=='cohort-v6-host-*.json' else 2 if h.get('reusedProducer') else 1 if pattern=='cohort-host-*.json' else 0
   row['selectionPriority']=priority
   if key not in selected or priority>selected[key]['selectionPriority']:selected[key]=row
assert len({x['fullReplayReceipt']['path'] for x in actual})==len(actual)
missing=sorted(expected-set(selected));invalidselected=[x for x in selected.values() if not x['valid']]
representatives=[]
for case,role,choices in [
 ('positions-offsets-1000-native-r1','producer',['cohort-python-positions-offsets-1000-native-r1-producer.json']),
 ('positions-offsets-1000-native-r1','receiver',['cohort-python312-positions-offsets-1000-native-r1-receiver.json']),
 ('source-phrase-1000-native-r1','producer',['cohort-python-source-phrase-1000-native-r1-producer.json','cohort-python312-source-phrase-1000-native-r1-producer.json']),
 ('source-phrase-1000-native-r1','receiver',['cohort-python-source-phrase-1000-native-r1-receiver.json','cohort-python312-source-phrase-1000-native-r1-receiver.json']),
 ('source-phrase-1000-source-r1','producer',['cohort-python312-source-phrase-1000-source-r1-producer.json']),
 ('source-phrase-1000-source-r1','receiver',['cohort-python312-source-phrase-1000-source-r1-receiver.json'])]:
 paths=[OUT/n for n in choices if (OUT/n).exists()];assert paths,(case,role)
 for p in paths:assert read(p)['bothAgree']
 representatives.append({'case':case,'role':role,'reports':[bind(p) for p in paths]})
groups=collections.defaultdict(list)
for row in selected.values():
 k=(row['runtimeSha256'],*row['key'][:3],row['role'],row['extentCap'],row['streamMiB']);groups[k].append(row)
result={'schema':'raveldex-independent-codec-cohort-review-v1','status':'Pass for bounded complete recorded cohort' if not missing and not invalidselected else 'Incomplete: recorded terminal attempts preserved','actualWindows':len(actual),'actualRawBytes':sum(x['bytes'] for x in actual),'actualEvents':sum(x['events'] for x in actual),'selectedRawBytes':sum(x['bytes'] for x in selected.values()),'selectedEvents':sum(x['events'] for x in selected.values()),'validActualWindows':sum(x['valid'] for x in actual),'invalidActualWindows':sum(not x['valid'] for x in actual),'expectedLogicalWindows':36,'selectedLogicalWindows':len(selected),'missingLogicalWindows':missing,'selectedInvalidWindows':invalidselected,'publicActualOutcomeCounts':dict(collections.Counter(x['publicOutcome'] for x in actual)),'publicSelectedOutcomeCounts':dict(collections.Counter(x['publicOutcome'] for x in selected.values())),'allLaunchedDisposed':all(x['disposed'] for x in actual),'allFullReplayIdentityChecks':all(x['sourceIdentityVerified'] for x in actual),'distinctLiteralCheckedExports':len(exports),'literalExports':list(exports.values()),'representativePythonCppDifferential':representatives,'selectedGroups':[{'runtimeSha256':k[0],'mode':k[1],'size':k[2],'format':k[3],'role':k[4],'extentCap':k[5],'streamMiB':k[6],'samples':sorted(v,key=lambda x:x['key'][3])} for k,v in groups.items()],'actualAttemptWindows':actual,'hostReviewBindings':hostbindings,'matrixBindings':[bind(ROOT/n) for n in ('matrix-progress.json','matrix-progress-v2.json','matrix-progress-v3.json')],'scope':'Every actual raw stream receives full C++ framing, footer, hash, metric, counter and marker replay, with unchanged 208 production files, package, staged sources and public reports checked. Six first-repetition 1,000-record configuration/operation cells receive full Python comparison. Runtime SHA, profile and capacity groups remain separate. No three-uniform-binary, full ranking, physical-memory, default-runtime latency, universal Unicode, cross-host or full AC03 qualification is claimed. Public refusals remain explicit even when the measurement is valid. Failed startup without a trace is excluded from window counts and preserved separately.'}
with (OUT/'cohort-v6-terminal-independent-review.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:result[k] for k in ('status','actualWindows','validActualWindows','invalidActualWindows','expectedLogicalWindows','selectedLogicalWindows','distinctLiteralCheckedExports','publicSelectedOutcomeCounts')},indent=2))
