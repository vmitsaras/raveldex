"""Archive finalized exact raw streams; no trimming, conversion or data selection."""
from pathlib import Path
import hashlib,json,tarfile,io,subprocess,sys,os,signal,time,importlib.util
R=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');D=Path('/Users/vasilis/Documents/GitHub/raveldex/docs/evidence');repo=D.parents[1]
spec=importlib.util.spec_from_file_location('verify',repo/'bench/memory/runtime-archive.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
class Slice:
 def __init__(self,path,offset,n):self.f=path.open('rb');self.f.seek(offset);self.n=n
 def read(self,n):
  b=self.f.read(min(n,self.n));self.n-=len(b);return b
 def close(self):self.f.close()
streams=[];parts=[];pending=[];archives=[];seen=set();started=time.time()
def save():
 index={'schema':'raveldex-raw-parts-v1','scope':'Byte-exact contiguous raw parts; no event dropping, conversion or prefix qualification','archives':archives,'streams':[{**{k:x[k]for k in ('name','bytes','sha256')},'parts':[{k:p[k]for k in ('name','bytes','sha256','offset','archive')if k in p}for p in x['parts']]}for x in streams]}
 (R/'raw-index-progress.json').write_text(json.dumps(index,indent=2)+'\n')
def package(group):
 ordinal=len(archives)+1;name=f'RX-4002-gc-shrink-raw-{ordinal:03}-20261028.tar.xz';target=D/name;assert not target.exists()
 manifest=json.dumps({'schema':'raveldex-ac03-workload-archive-v1','members':[{k:x[k]for k in ('name','bytes','sha256')}for x in group]},indent=2).encode()
 for x in group:x['archive']=name
 cmd=['/usr/bin/nice','-n','10','/opt/homebrew/bin/xz','-T2','--memlimit-compress=512MiB','-6','-c']
 stderr=R/f'archive-{ordinal:03}.stderr';before=time.time()
 with target.open('xb')as out,stderr.open('xb')as err:
  p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=out,stderr=err,start_new_session=True)
  try:
   with tarfile.open(fileobj=p.stdin,mode='w|')as tar:
    info=tarfile.TarInfo('MANIFEST.json');info.size=len(manifest);tar.addfile(info,io.BytesIO(manifest))
    for x in group:
     info=tarfile.TarInfo(x['name']);info.size=x['bytes'];info.mode=0o600;f=Slice(x['path'],x['offset'],x['bytes'])
     try:tar.addfile(info,f)
     finally:f.close()
   p.stdin.close();code=p.wait(timeout=600);assert code==0,code
  except BaseException:
   if p.poll()is None:
    os.killpg(os.getpgid(p.pid),signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(os.getpgid(p.pid),signal.SIGKILL);p.wait(timeout=5)
   raise
 assert target.stat().st_size<100*1024**2
 receipt=v.verify(target);row={'path':str(target.relative_to(repo)),'bytes':target.stat().st_size,'sha256':sha(target),'verification':receipt,'compression':{'command':cmd,'stderrSha256':sha(stderr),'elapsedSeconds':time.time()-before,'scope':'Offline archive storage only'}};archives.append(row);save();print(json.dumps({k:row[k]for k in ('path','bytes','sha256')}),flush=True)
while time.time()-started<7200:
 for hostp in sorted((R/'codecs').glob('*/host.json')):
  try:h=json.loads(hostp.read_text())
  except json.JSONDecodeError:continue
  for child in h['processes']:
   if child.get('exitCode')!=0 or not child.get('child'):continue
   raw=Path(child['child']['operation']['file']);key=str(raw.resolve())
   if key in seen:continue
   artifact=next(x for x in child['artifacts']if x['name']==raw.name);assert raw.stat().st_size==artifact['bytes']and sha(raw)==artifact['sha256']
   row={'name':str(raw.relative_to(R)),'bytes':raw.stat().st_size,'sha256':artifact['sha256'],'parts':[]};offset=0
   with raw.open('rb')as f:
    while offset<row['bytes']:
     n=min(128*1024**2,row['bytes']-offset);left=n;digest=hashlib.sha256()
     while left:
      b=f.read(min(left,1048576));assert b;digest.update(b);left-=len(b)
     part={'name':'raw/'+row['name']+'.part-'+str(len(row['parts'])).zfill(3),'bytes':n,'sha256':digest.hexdigest(),'offset':offset,'path':raw};row['parts'].append(part);parts.append(part);pending.append(part);offset+=n
   streams.append(row);seen.add(key);save()
   while sum(x['bytes']for x in pending)>=512*1024**2:
    group=[];size=0
    while pending and size+pending[0]['bytes']<=512*1024**2:
     x=pending.pop(0);group.append(x);size+=x['bytes']
    package(group)
 terminal=json.loads((R/'matrix-progress-v3.json').read_text())
 if 'finishedUnix'in terminal or terminal.get('stopped'):
  active=False
  for hostp in (R/'codecs').glob('*/host.json'):
   h=json.loads(hostp.read_text());active=active or 'finished'not in h
  if not active:
   if pending:package(pending);pending=[]
   save();shutil=None;(R/'raw-index.json').write_bytes((R/'raw-index-progress.json').read_bytes());print(json.dumps({'outcome':'All finalized streams byte-verified and archived','streams':len(streams),'archives':len(archives),'rawBytes':sum(x['bytes']for x in streams)}));break
 time.sleep(10)
else:raise TimeoutError('Bounded raw archiver waiting for finalized cohort')
