import pathlib,hashlib,json,subprocess,tempfile,shutil,os,time,sys
root=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H'); repo=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex'); consumer=pathlib.Path('/private/var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-core-consumer-6KPcoz'); runtime=pathlib.Path(sys.argv[1])
expected_runtime_sha=sys.argv[2]
mode,rawsize,format,runid=sys.argv[3:7]
receiver_only=len(sys.argv)>7 and sys.argv[7]=='receiver'
prior_input=pathlib.Path(sys.argv[8]).resolve() if receiver_only else None
if receiver_only:
 assert prior_input.is_file() and prior_input.name=='encoded.json'
 prior_host=json.loads((prior_input.parent.parent/'host.json').read_text())
 assert (prior_host['runtimeSha256'],prior_host['mode'],prior_host['size'],prior_host['format'])==(expected_runtime_sha,mode,int(rawsize),format)
 assert prior_host['processes'][0]['child']['operation']['publicOutcome']=='Pass' and prior_host['processes'][0]['child']['traceStatus']==0; size=int(rawsize)
assert mode in ('source-phrase','positions-offsets') and size in (1000,10000) and format in ('native','source') and (format!='source' or mode=='source-phrase')
out=root/'codecs'/runid;out.mkdir(parents=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
assert len(expected_runtime_sha)==64 and sha(runtime)==expected_runtime_sha
assert sha(consumer/'vmitsaras-raveldex-0.0.0.tgz')=='6ff6e90128f60af39bb8f47800c61ed83d85d4ded7a8e3c96d2bd34467f9c437'
installed=consumer/'node_modules/@vmitsaras/raveldex';files=[]
for p in sorted((installed/'dist').rglob('*')):
 if p.is_file():
  rel=p.relative_to(installed); digest=sha(p); assert digest==sha(repo/rel); files.append({'path':str(rel),'sha256':digest})
assert len(files)==208
staged=pathlib.Path(tempfile.mkdtemp(prefix='gc-codec-matrix-',dir=consumer));sources=[]
for source,name in [('bench/memory/gc-codec-matrix-child.mjs','child.mjs'),('bench/cost-common.mjs','cost-fixture.mjs')]:
 target=staged/name;shutil.copyfile(repo/source,target);sources.append({'path':source,'target':str(target),'sha256':sha(target)})
flags=['--expose-internals','--expose-gc','--no-inline-new','--no-turbo-allocation-folding','--single-threaded','--no-incremental-marking','--min-semi-space-size=16','--max-semi-space-size=16']
record={'schema':'raveldex-gc-codec-matrix-host-v1','mode':mode,'size':size,'format':format,'repetition':runid,'runtimeSha256':sha(runtime),'packageSha256':sha(consumer/'vmitsaras-raveldex-0.0.0.tgz'),'productionFiles':files,'sources':sources,'started':time.time(),'processes':[]}
def save(): (out/'host.json').write_text(json.dumps(record,indent=2)+'\n')
if receiver_only:record['reusedProducer']={'host':str(prior_input.parent.parent/'host.json'),'hostSha256':sha(prior_input.parent.parent/'host.json'),'encoded':str(prior_input),'encodedSha256':sha(prior_input),'scope':'Existing valid export reused; no new producer operation or duplicate export metric'}
for role in (['receiver'] if receiver_only else ['producer','receiver']):
 folder=out/role;folder.mkdir();input=str(prior_input if receiver_only else out/'producer/encoded.json') if role=='receiver' else ''
 argv=[str(runtime),*flags,str(staged/'child.mjs'),mode,str(size),role,format,str(folder),input,'512' if size==1000 else '4096',expected_runtime_sha]
 row={'role':role,'argv':argv,'cwd':str(consumer),'timeoutSeconds':240 if role=='producer' else 180,'started':time.time()};record['processes'].append(row);save()
 try:
  p=subprocess.run(argv,cwd=consumer,env={k:os.environ[k] for k in ['PATH','TMPDIR','LANG','LC_ALL'] if k in os.environ},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=row['timeoutSeconds'])
  (folder/'stdout.log').write_bytes(p.stdout);(folder/'stderr.log').write_bytes(p.stderr);row['exitCode']=p.returncode
 except subprocess.TimeoutExpired as e:
  (folder/'stdout.log').write_bytes(e.stdout or b'');(folder/'stderr.log').write_bytes(e.stderr or b'');row['timedOut']=True
 finally:
  row['finished']=time.time();row['runtimeUnchanged']=sha(runtime)==record['runtimeSha256'];row['productionUnchanged']=all(sha(installed/x['path'])==x['sha256'] and sha(repo/x['path'])==x['sha256'] for x in files);row['sourcesUnchanged']=all(sha(repo/x['path'])==x['sha256'] and sha(pathlib.Path(x['target']))==x['sha256'] for x in sources)
  try:row['child']=json.loads((folder/'report.json').read_text())
  except Exception as e:row['reportError']=str(e)
  row['artifacts']=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(folder.iterdir()) if p.is_file()]
  save(); print(json.dumps({'run':runid,'role':role,'exitCode':row.get('exitCode'),'outcome':row.get('child',{}).get('outcome'),'traceStatus':row.get('child',{}).get('traceStatus'),'publicOutcome':row.get('child',{}).get('operation',{}).get('publicOutcome')}),flush=True)
 if row.get('exitCode')!=0 or not all(row[x] for x in ['runtimeUnchanged','productionUnchanged','sourcesUnchanged']):break
 if role=='producer' and not (folder/'encoded.json').exists(): row['receiverNotRun']='Producer rejected without snapshot';save();break
record['finished']=time.time();save()
assert all(x.get('exitCode')==0 and x.get('child',{}).get('disposed') and x['runtimeUnchanged'] and x['productionUnchanged'] and x['sourcesUnchanged'] for x in record['processes'])
