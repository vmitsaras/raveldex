"""Serial unchanged public-codec cohort; run only after separate calibration review."""
import json,sys,time,subprocess,pathlib,hashlib,os,signal
root=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H')
runtime=pathlib.Path(sys.argv[1]).resolve();expected=sys.argv[2]
assert hashlib.sha256(runtime.read_bytes()).hexdigest()==expected
# First revisit the concrete formerly invalid operation, then all remaining cells.
cases=[('source-phrase',10000,'native'),('source-phrase',1000,'native'),('positions-offsets',1000,'native'),('source-phrase',1000,'source'),('source-phrase',10000,'source'),('positions-offsets',10000,'native')]
report={'schema':'raveldex-gc-shrink-codec-cohort-v1','runtimePath':str(runtime),'runtimeSha256':expected,'repetitions':3,'cases':cases,'processes':[],'startedUnix':time.time(),'scope':'Serial fresh producer/receiver; unchanged literal ASCII corpus,256-record batches,public production defaults,60000ms deadline; instrumented runtime variant only; no latency/physical memory claim.'}
def save(): (root/'matrix-progress.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for rep in range(3):
 for mode,size,fmt in cases:
  name=f'{mode}-{size}-{fmt}-r{rep+1}'
  row={'case':name,'mode':mode,'size':size,'format':fmt,'repetition':rep+1,'startedUnix':time.time()};report['processes'].append(row);save()
  args=[sys.executable,str(root/'run-codecs.py'),str(runtime),expected,mode,str(size),fmt,name]
  row['command']=args
  with (root/(name+'.host.log')).open('xb') as log:
   try:
    child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['pid']=child.pid;row['processGroup']=os.getpgid(child.pid);save();row['exitCode']=child.wait(timeout=480)
   except subprocess.TimeoutExpired:
    row['outcome']='Host timeout';row['timedOut']=True
    os.killpg(row['processGroup'],signal.SIGTERM)
    try:row['exitCode']=child.wait(timeout=5)
    except subprocess.TimeoutExpired:
     os.killpg(row['processGroup'],signal.SIGKILL);row['exitCode']=child.wait(timeout=5)
  row['finishedUnix']=time.time();save();print(json.dumps(row),flush=True)
  if row['exitCode']!=0:report['stopped']='Concrete host failure; preserve and diagnose before continuing';save();sys.exit(1)
  host=json.loads((root/'codecs'/name/'host.json').read_text())
  roles=[p['role'] for p in host['processes']]
  assert roles in (['producer'],['producer','receiver'])
  row['roles']=roles;row['publicOutcomes']=[p['child']['operation']['publicOutcome'] for p in host['processes']]
  row['receiverNotRun']=len(roles)!=2
  if row['receiverNotRun']:assert host['processes'][0]['child']['operation']['publicOutcome']=='Rejected' and host['processes'][0].get('receiverNotRun')
  row['successfulRoundTrip']=roles==['producer','receiver'] and row['publicOutcomes']==['Pass','Pass'];save()
  bad=[p for p in host['processes'] if p.get('child',{}).get('traceStatus')!=0]
  if bad:
   report['stopped']='Concrete unsupported or invalid measurement; remaining cohort awaits diagnosis';row['invalidRoles']=[p['role'] for p in bad];save();sys.exit(2)
report['finishedUnix']=time.time();report['outcome']='All planned cells attempted; launched windows guarded. Public refusals and unrun receivers remain explicit; independent replay still required';save()
