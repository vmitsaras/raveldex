from pathlib import Path
import lzma,json,hashlib,time
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');p=r/'codecs/source-phrase-10000-native-r1/producer/export-native.rdxgc';q=r/'compression-control.xz';n=128*1024**2;h=hashlib.sha256();started=time.time();left=n
with p.open('rb')as f,lzma.open(q,'xb',preset=0)as out:
 while left:
  b=f.read(min(left,1048576));assert b;h.update(b);out.write(b);left-=len(b)
compressed_seconds=time.time()-started;h2=hashlib.sha256();count=0
with lzma.open(q,'rb')as f:
 for b in iter(lambda:f.read(1048576),b''):h2.update(b);count+=len(b)
assert count==n and h.hexdigest()==h2.hexdigest()
(r/'compression-control.json').write_text(json.dumps({'schema':'raveldex-lossless-xz-storage-control-v1','source':str(p),'prefixBytes':n,'sourcePrefixSha256':h.hexdigest(),'compressedBytes':q.stat().st_size,'preset':0,'compressedSeconds':compressed_seconds,'decompressedByteIdentity':'Pass','scope':'Offline lossless archive storage; no engine latency/memory observation'},indent=2)+'\n')
print((r/'compression-control.json').read_text())
