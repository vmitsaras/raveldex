"""Package only finalized task-owned sources/controls/reports; not build/profile trees."""
from pathlib import Path
import hashlib,json,tarfile,io,importlib.util,time
R=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');repo=Path('/Users/vasilis/Documents/GitHub/raveldex');D=repo/'docs/evidence'
spec=importlib.util.spec_from_file_location('verify',repo/'bench/memory/runtime-archive.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
excluded={'SESSION-CHECKPOINT.md','EVIDENCE-draft.md','EVIDENCE-ready.md','compression-control.xz','metadata-packaging-index.json','metadata-packaging.log','metadata-inventory.json'}
rows=[]
for p in sorted(R.rglob('*')):
 if p.is_symlink()or not p.is_file():continue
 rel=p.relative_to(R);parts=rel.parts
 if any(x in ('node-v24.21.0','node_modules','tmp','__pycache__')or x.startswith('pycache')for x in parts):continue
 if str(rel)in excluded or p.suffix=='.pyc':continue
 if parts[0]=='codecs'and p.suffix=='.rdxgc':continue
 with p.open('rb')as f:magic=f.read(4)
 if magic in (bytes.fromhex('cffaedfe'),bytes.fromhex('feedfacf'),b'\x7fELF'):continue
 assert p.stat().st_size<=256*1024**2,rel
 rows.append({'name':str(rel),'path':p,'bytes':p.stat().st_size,'sha256':sha(p)})
manifest=json.dumps({'schema':'raveldex-ac03-workload-archive-v1','members':[{k:x[k]for k in ('name','bytes','sha256')}for x in rows]},indent=2).encode();assert len(manifest)<=8*1024**2
assert sum(x['bytes']for x in rows)+len(manifest)<1024**3
name='RX-4002-gc-shrink-20261028.tar.xz';target=D/name;assert not target.exists();started=time.time()
with tarfile.open(target,'w:xz',preset=6)as tar:
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(manifest);tar.addfile(info,io.BytesIO(manifest))
 for row in rows:
  assert row['path'].stat().st_size==row['bytes']and sha(row['path'])==row['sha256'],'Mutable metadata before archive: '+row['name']
  info=tarfile.TarInfo(row['name']);info.size=row['bytes'];info.mode=0o600
  with row['path'].open('rb')as f:tar.addfile(info,f)
  assert sha(row['path'])==row['sha256'],'Mutable metadata during archive: '+row['name']
assert target.stat().st_size<100*1024**2
receipt=v.verify(target);record={'schema':'raveldex-ac03-metadata-archive-v1','path':str(target.relative_to(repo)),'bytes':target.stat().st_size,'sha256':sha(target),'verification':receipt,'members':[{k:x[k]for k in ('name','bytes','sha256')}for x in rows],'elapsedSeconds':time.time()-started,'exclusions':'Full19GBbuildtree/executables, node_modules, newChromeprofiles/cache, pycache, already independently preserved codecrawstreams, draftprose/checkpoint and storage-onlyduplicatecompressioncontrol. No accepted observation raw/source/alias/report omitted.'}
(R/'metadata-packaging-index.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ('path','bytes','sha256','verification')}))
