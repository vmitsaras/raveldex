"""Verify/extract closed archives, then byte-exactly reassemble39 NEW files."""
import pathlib,importlib.util,json,tempfile,subprocess,time,hashlib,shutil,sys
repo=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex');r=pathlib.Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H');out=pathlib.Path(tempfile.mkdtemp(prefix='raveldex-shrink-verified-20261028.'));started=time.time()
spec=importlib.util.spec_from_file_location('archive',repo/'bench/memory/runtime-archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
receipts=[];seen=set()
def save():
 (r/'reconstruction-progress.json').write_text(json.dumps({'root':str(out),'archives':receipts,'startedUnix':started},indent=2)+'\n')
save()
while time.time()-started<7200:
 index=json.loads((r/'raw-index-progress-v3.json').read_text())
 for row in index['archives']:
  if row['path']in seen:continue
  p=repo/row['path'];assert p.stat().st_size==row['bytes']and sha(p)==row['sha256'];dest=out/'parts'/p.name[:-7];dest.mkdir(parents=True)
  result=m.verify(p,dest);assert result==row['verification'];receipts.append({'archive':row['path'],'sha256':row['sha256'],'extractedTo':str(dest),'verification':result});seen.add(row['path']);save()
 if (r/'raw-index.json').exists():
  final=json.loads((r/'raw-index.json').read_text())
  if len(seen)==len(final['archives']):break
 time.sleep(10)
else:raise TimeoutError('Archive extraction timeout')
assert len(final['streams'])==39 and sum(x['bytes']for x in final['streams'])==49385850374
(out/'metadata').mkdir();shutil.copyfile(r/'raw-index.json',out/'metadata/raw-index.json');shutil.copyfile(r/'reassemble.py',out/'metadata/reassemble.py')
argv=[sys.executable,str(out/'metadata/reassemble.py'),str(out/'parts'),str(out/'assembled')]
p=subprocess.run(argv,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=1200)
assert p.returncode==0,p.stderr;streams=json.loads(p.stdout);assert len(streams)==39 and sum(x['bytes']for x in streams)==49385850374
record={'schema':'raveldex-archive-reconstruction-v2','outcome':'Pass','root':str(out),'archiveVerifications':receipts,'streams':streams,'command':argv,'reassemblerSha256':sha(out/'metadata/reassemble.py'),'rawIndexSha256':sha(out/'metadata/raw-index.json'),'archiveVerifierSha256':sha(repo/'bench/memory/runtime-archive.py'),'statement':'All39 byte-exact streams reconstructed from verified regular archive members. Numeric/native evidence is separately bound by identicalSHA256.'}
(r/'reconstruction.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'outcome':'Pass','root':str(out),'streams':len(streams),'bytes':sum(x['bytes']for x in streams)}))
