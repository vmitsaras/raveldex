from pathlib import Path
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime')
t=(r/'run-controls.py').read_text().replace("node=r/'node-gc-shrink-v4'","node=r/'node-gc-shrink-v5'").replace("out=r/'native-controls'","out=r/'native-controls-v5'").replace("*([] if mode=='flag-guard' else flags)","*(['--expose-internals'] if mode=='flag-guard' else flags)").replace("r/'native-controls-report.json'","r/'native-controls-v5-report.json'")
exec(compile(t,str(r/'run-controls.py'),'exec'))
