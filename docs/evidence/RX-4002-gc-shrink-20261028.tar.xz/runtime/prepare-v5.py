from pathlib import Path
import difflib
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime');p=r/'node-v24.21.0/deps/v8/src/heap/raveldex-gc-trace.inc';old=p.read_text();t=old.replace('    uint64_t before=current_;','    gc_layout_locked_=true;  // Census phase starts before iterator setup.\n    uint64_t before=current_;');assert t!=old;p.write_text(t);(r/'recorder-v5.inc').write_text(t)
(r/'v4-to-v5.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),t.splitlines(True),fromfile='a/deps/v8/src/heap/raveldex-gc-trace.inc',tofile='b/deps/v8/src/heap/raveldex-gc-trace.inc')))
b=(r/'recorder-v3.inc').read_text();(r/'shrink-v5.patch').write_text(''.join(difflib.unified_diff(b.splitlines(True),t.splitlines(True),fromfile='a/deps/v8/src/heap/raveldex-gc-trace.inc',tofile='b/deps/v8/src/heap/raveldex-gc-trace.inc')))
b=(r/'run-build.py').read_text().replace("phase = 'gc-shrink-v4'","phase = 'gc-shrink-v5'");(r/'run-build-v5.py').write_text(b)
