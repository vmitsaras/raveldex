from pathlib import Path
import json,os,signal,subprocess,time,hashlib,shutil
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime');node=r/'node-gc-shrink-v6';flags=['--expose-internals','--expose-gc','--no-inline-new','--no-turbo-allocation-folding','--single-threaded','--no-incremental-marking','--min-semi-space-size=16','--max-semi-space-size=16'];out=r/'native-controls-v6';out.mkdir()
shutil.copy2('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc/control-v3.cjs',r/'legacy-control-v3.cjs')
commands=[('native-shrink',[str(node),*flags,str(r/'native-shrink-control.cjs'),str(out/'native-shrink.rdxgc')])]
for mode in ['basic','gc','negative','async','aborted','flag-guard']:
 dest=out/mode;dest.mkdir();commands.append((mode,[str(node),*(['--expose-internals'] if mode=='flag-guard' else flags),str(r/'legacy-control-v3.cjs'),mode,str(dest)]))
commands.append(('capacity-2m',[str(node),*flags,str(r/'capacity-2m-control.cjs'),str(out)]))
reports=[]
for name,cmd in commands:
 start=time.time();report={'name':name,'command':cmd,'timeoutSeconds':120,'startedUnix':start}
 with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
  p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True);report['pid']=p.pid;report['pgid']=os.getpgid(p.pid)
  try:report['exitCode']=p.wait(timeout=120);report['timedOut']=False
  except subprocess.TimeoutExpired:
   report['timedOut']=True;os.killpg(p.pid,signal.SIGTERM)
   try:report['exitCode']=p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);report['exitCode']=p.wait(timeout=5)
 report['elapsedSeconds']=time.time()-start;reports.append(report);print(json.dumps(report),flush=True)
(r/'native-controls-v6-report.json').write_text(json.dumps({'runtimeSha256':hashlib.sha256(node.read_bytes()).hexdigest(),'runs':reports},indent=2)+'\n')
