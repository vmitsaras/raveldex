from pathlib import Path
import hashlib,json,os,subprocess,time,difflib
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime');old=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc/node-v24.21.0');s=r/'node-v24.21.0'
def fingerprint():
 rows=[]
 for p in old.rglob('*'):
  if p.is_file() and not p.is_symlink():
   st=p.stat();rows.append([str(p.relative_to(old)),st.st_size,st.st_mtime_ns,hashlib.sha256(p.read_bytes()).hexdigest()])
 immutable=old.parent/'node-gc-v3';return {'files':rows,'immutableSha256':hashlib.sha256(immutable.read_bytes()).hexdigest()}
f=fingerprint();assert f['immutableSha256']=='ad443b2a6fc8092abeeb3ae8c6405e101cf15fc531f05eb769da4707d5154ae0';(r/'old-tree-before.json').write_text(json.dumps(f))
subprocess.run(['cp','-cR',str(old),str(s)],check=True)
# Relocate every build metadata reference, preserving times so only changed source recompiles.
a=str(old.resolve()).encode();b=str(s.resolve()).encode();relocated=[]
for p in (s/'out').rglob('*'):
 if p.is_file() and not p.is_symlink() and (p.suffix in ('.mk','.d') or p.name=='Makefile'):
  data=p.read_bytes()
  if a not in data:continue
  st=p.stat();p.write_bytes(data.replace(a,b));os.utime(p,ns=(st.st_atime_ns,st.st_mtime_ns));relocated.append(str(p.relative_to(s)))
olddep=s/'out/Release/.deps'/str(old.resolve()).lstrip('/');newdep=s/'out/Release/.deps'/str(s.resolve()).lstrip('/')
if olddep.exists():newdep.parent.mkdir(parents=True,exist_ok=True);olddep.rename(newdep)
(r/'clone-report.json').write_text(json.dumps({'command':['cp','-cR',str(old),str(s)],'source':str(old),'clone':str(s),'oldPrefix':a.decode(),'newPrefix':b.decode(),'relocatedFiles':relocated,'builddirOverride':str(s.resolve()/'out')},indent=2)+'\n')
p=s/'deps/v8/src/heap/raveldex-gc-trace.inc';before=p.read_text();(r/'recorder-v3.inc').write_text(before)
start=before.index('      // GC may compact a preexisting WeakArrayList.')
end=before.index('      return;\n    }',start)
after=before[:start]+'''      // GC right trims are supported only before ANY move/census in this GC.
      // Full old coverage is required; never infer an object type from its size.
      Address e; if(!End(a,old_n,&e)||n<=0||n>old_n){Error("invalid_gc_size_change");return;}
      uint64_t coverage=0;
      Intersections(extents_,a,e,[&](Address x,Address y){coverage+=y-x;});
      bool moved=false;Intersections(moved_,a,e,[&](Address,Address){moved=true;});
      if(coverage || moved) {
        if(gc_layout_locked_) {Error("tracked_gc_size_change_after_move_or_census");return;}
        if(coverage!=uint64_t(old_n)) {Error("partial_gc_size_change");return;}
        if(n>=old_n) {Error("nonshrinking_tracked_gc_size_change");return;}
        auto d=Remove(extents_,a+n,e);
        if(d!=uint64_t(old_n-n)||d>current_) {Error("gc_shrink_accounting_mismatch");return;}
        current_-=d;trimmed_+=d;++gc_shrinks_;
      } else ++unmonitored_;
''' + before[end:]
after=after.replace('    // All copy sources resolve', '    gc_layout_locked_=true;\n    // All copy sources resolve')
after=after.replace('    in_gc_=true; ++gcs_;','    in_gc_=true; gc_layout_locked_=false; ++gcs_;')
after=after.replace('        Emit(10,a,0,b-a,0,0);','        gc_layout_locked_=true;\n        Emit(10,a,0,b-a,0,0);')
after=after.replace('bool in_gc_=false,stream_full_', 'bool in_gc_=false,gc_layout_locked_=false,stream_full_')
after=after.replace('moves_=0,census_objects_', 'moves_=0,gc_shrinks_=0,census_objects_')
after=after.replace('\\"gc_moves\\":%" PRIu64 ",', '\\"gc_moves\\":%" PRIu64 ",\\"gc_pre_move_shrinks\\":%" PRIu64 ",')
after=after.replace('heap_->gc_count(),moves_,census_objects_', 'heap_->gc_count(),moves_,gc_shrinks_,census_objects_')
after=after.replace('raveldex-gc-extents-varint-v1','raveldex-gc-extents-varint-v2')
after=after.replace('\\"fields\\":[','\\"gc_tracked_shrink_mode\\":\\"pre-move-full-coverage-right-trim-v1\\",\\"fields\\":[')
p.write_text(after);(r/'recorder-v4.inc').write_text(after)
(r/'shrink-v4.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/deps/v8/src/heap/raveldex-gc-trace.inc',tofile='b/deps/v8/src/heap/raveldex-gc-trace.inc')))
# Save exact implementation and inherited relevant sources.
for name in ['src/node_v8.cc','deps/v8/src/heap/heap.cc','deps/v8/src/heap/heap.h','deps/v8/src/codegen/optimized-compilation-info.cc']:
 target=r/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((s/name).read_bytes())
print(json.dumps({'cloned':str(s),'oldFiles':len(f['files']),'relocated':len(relocated),'patch':str(r/'shrink-v4.patch')}))
