# Task-owned GC pre-move right-trim calibration

Final runtime: `node-gc-shrink-v5`, SHA-256 `5f9567dbd6d6cf10c0deafa7f6779f81b68265831e14edd7049a86f211fbd843`. Node 24.21.0 / V8 13.6.233.17-node.53. V4 is preserved as an initial candidate; it is superseded by V5's census-entry lock. No repository files were edited here.

`prepare.py` hashes the old entire regular-file tree, verifies immutable old executable `ad443b2a6fc8092abeeb3ae8c6405e101cf15fc531f05eb769da4707d5154ae0`, then APFS-clones using `cp -cR`. Only clone build metadata is relocated. Both builds supply `builddir_name` explicitly pointing inside this runtime's clone. `finalize.py` verifies all 40,880 old regular files by relative-set, size, mtime and SHA-256 after both builds; no old source/build artifact changed. Symlinks are inventoried afterward, not independently hash-bound before clone.

## Exact contract

Header schema is `raveldex-gc-extents-varint-v2`; method token is `gc_tracked_shrink_mode=pre-move-full-coverage-right-trim-v1`. Six unsigned-varint event fields and existing event kinds remain unchanged. Every v2 summary adds `gc_pre_move_shrinks`. V1 does not opt into this support.

Every in-GC size-change callback must precede any move and census phase. The phase locks on the first MoveEvent, and conservatively at GCEnd entry before capturing the baseline or constructing the iterator. Any later GC size change invalidates, including disjoint/preexisting changes. A tracked accepted change requires a valid old range, strict `0 < new < old`, complete monitored coverage of the old extent, and no moved-tag intersection. Its tail is removed from the frozen source map immediately, occupied bytes decrease by exactly old-minus-new, and trim bytes increase by the same amount. The next emitted callback must be kind4 at the same address and new size. Missing/mismatched pairs invalidate. An update-only callback touching monitored/moved extents also invalidates. Disjoint preexisting size changes before phase lock preserve prior semantics.

GCEnd's `old_bytes` is current occupied bytes at GCEnd entry, after accepted GC trims. `gc_removed_bytes` counts this post-trim baseline minus completed-census survivors; it excludes bytes already counted as trims. Frozen-source movement and destination overwrite handling remain intact. Error/loss/abort retain null derived metrics for the entire window.

`recorder-v5.inc` is the exact compiled class; `shrink-v5.patch` is its diff against old V3; `v4-to-v5.patch` preserves the sole review repair. Inherited relevant sources are under `sources/`. Exact build commands/deadlines/PIDs/status/stderr are in both `gc-shrink-v*-build-report.json` and `.log`. Both builds exit 0. Snapshot build preserves no-inline-new and no-turbo-allocation-folding.

## Actual GC controls

`run-v5-controls.py` uses serial finite process groups, 120-second child deadlines, SIGTERM/SIGKILL fallback and child waits. All seven final child invocations exit 0 with no timeout. Required allocation flags are expose-internals, expose-gc, no-inline-new, no-turbo-allocation-folding, single-threaded, no-incremental-marking, min/max semi-space16. `native-controls-v5-report.json` records exact arguments; correction flagguard intentionally omits guarded allocation flags but preserves expose-internals.

`native-shrink-control.cjs` creates branch shapes, releases most branches, invokes real full GC, retains selected objects and subsequently creates/collects arrays. No task test hook is installed in the runtime. Raw `native-controls-v5/native-shrink.rdxgc` records 825,610 events, 16 completed GCs, 173 moves, 35 accepted tracked shrinks, 41,648 trimmed bytes, zero errors/loss and valid status. `actual-native-shrink-exact-witnesses.json` finds for all35 an exact old extent birth or prior census, immediate matching size update, any movement chain and an exact new extent census in the same GC. Preliminary scanning finds13 later destinations overlapping removed tails, including sameGC reuse. This scan is distinct from independent interval replay.

A source-wide search finds the sole concrete `tracker->UpdateObjectSizeEvent` emission at `Heap::RightTrimArray`, heap.cc3555; its callback follows SizeChangeEvent and capacity change. Paired actual callbacks establish this route in this exact source. No concrete array type is inferred from sizes, and WeakArrayList-specific support is not claimed. Read `right-trim-route-source.txt` for source references.

Legacy controls cover empty trace, mutator right/left trims including large arrays, real GC movements and death, preexisting young allocations crossing Start, address reuse, async, extent/stream caps, existing-file refusal, abort cleanup and allocation-flag refusal. Raw streams, stdout and stderr are preserved. Initial V4 flagguard invocation omitted expose-internals and failed before tracing with MODULE_NOT_FOUND; preserved in native-controls/flag-guard.stderr and report. Corrected V5 flagguard passes with no output file created. That runner failure was not a recorder failure.

## Synthetic recorder controls

`make-recorder-harness-v5.py` extracts the exact candidate class verbatim into `recorder-control-harness-v5.cc`; the hash receipt binds it. Fake Heap/iterator/V8 type shims exist only to compile and feed deterministic census rows. The compiled harness has13 cases: 376→264 and968→760, a successful census, removed-tail destination reuse, movement/death, preexisting change, partial coverage refusal, tracked/disjoint post-move refusal, post-census refusal, census-constructor callback refusal, dangling/mismatched pair, update-only, nonshrinking/growth refusal, mutator shrink. Every synthetic stream includes `synthetic_control:true`. Successful accepted case is synthetic replay, not evidence of product behavior or actual GC selection.

Compile: `clang++ -std=c++20 -Wall -Wextra recorder-control-harness-v5.cc -o recorder-control-harness-v5`; execute with a new synthetic-controls directory. V5 stdout/stderr and all13 raw streams are preserved. Two unused-shim warnings are recorded. Initial V4 shim compilation required a missing Local dereference operator; corrected before producing synthetic results. No runtime source change resulted from that harness defect.

## Limits

This is a bounded managed occupied-extent recorder, not physical/process/engine-exclusive peak memory. Native recorder maps, external backing and GC copying overlap remain outside its numerical metric. Same-runtime flags/census cost/IO perturb execution. Concrete array types and arbitrary in-GC layouts are not qualified. No product codec window is executed by this subtask. Parent owns independent Python/C++ replay, qualification review and later workload cohort. Native return0 alone does not establish calibration.
