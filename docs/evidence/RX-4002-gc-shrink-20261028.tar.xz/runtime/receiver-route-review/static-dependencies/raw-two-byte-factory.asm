
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100004000 <__text>:
1000193cc: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
1000193d0: a9014ff4    	stp	x20, x19, [sp, #0x10]
1000193d4: a9027bfd    	stp	x29, x30, [sp, #0x20]
1000193d8: 910083fd    	add	x29, sp, #0x20
1000193dc: aa0103f4    	mov	x20, x1
1000193e0: aa0003f3    	mov	x19, x0
1000193e4: 7100045f    	cmp	w2, #0x1
1000193e8: 54000420    	b.eq	0x10001946c <__text+0x1546c>
1000193ec: 529ffd28    	mov	w8, #0xffe9             ; =65513
1000193f0: 72a3ffe8    	movk	w8, #0x1fff, lsl #16
1000193f4: 6b08029f    	cmp	w20, w8
1000193f8: 540004c2    	b.hs	0x100019490 <__text+0x15490>
1000193fc: 531f7a88    	lsl	w8, w20, #1
100019400: 11003908    	add	w8, w8, #0xe
100019404: 121e7115    	and	w21, w8, #0x7ffffffc
100019408: 92401c64    	and	x4, x3, #0xff
10001940c: aa1303e0    	mov	x0, x19
100019410: aa1503e1    	mov	x1, x21
100019414: 52800003    	mov	w3, #0x0                ; =0
100019418: 940083fa    	bl	0x10003a400 <_cxxbridge1$str$ptr+0x814>
10001941c: aa0003e1    	mov	x1, x0
100019420: d1000408    	sub	x8, x0, #0x1
100019424: 52801ba9    	mov	w9, #0xdd               ; =221
100019428: b81ff009    	stur	w9, [x0, #-0x1]
10001942c: 8b150108    	add	x8, x8, x21
100019430: b81fc11f    	stur	wzr, [x8, #-0x4]
100019434: b8007014    	stur	w20, [x0, #0x7]
100019438: 52800068    	mov	w8, #0x3                ; =3
10001943c: b8003008    	stur	w8, [x0, #0x3]
100019440: f9411660    	ldr	x0, [x19, #0x228]
100019444: f9411a68    	ldr	x8, [x19, #0x230]
100019448: eb08001f    	cmp	x0, x8
10001944c: 540001c0    	b.eq	0x100019484 <__text+0x15484>
100019450: 91002008    	add	x8, x0, #0x8
100019454: f9011668    	str	x8, [x19, #0x228]
100019458: f9000001    	str	x1, [x0]
10001945c: a9427bfd    	ldp	x29, x30, [sp, #0x20]
100019460: a9414ff4    	ldp	x20, x19, [sp, #0x10]
100019464: a8c357f6    	ldp	x22, x21, [sp], #0x30
100019468: d65f03c0    	ret
10001946c: aa1303e0    	mov	x0, x19
100019470: aa0303f5    	mov	x21, x3
100019474: 9403144f    	bl	0x1000de5b0 <_cxxbridge1$slice$new+0x98ad4>
100019478: aa1503e3    	mov	x3, x21
10001947c: aa0003e2    	mov	x2, x0
100019480: 17ffffdb    	b	0x1000193ec <__text+0x153ec>
100019484: aa1303e0    	mov	x0, x19
100019488: 94014508    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
10001948c: 17fffff4    	b	0x10001945c <__text+0x1545c>
100019490: aa1303e0    	mov	x0, x19
100019494: 94f1bc1c    	bl	0x103c88504 <__v8_internal_Print_TransitionTree+0x3fb1c>
100019498: f9400001    	ldr	x1, [x0]
10001949c: aa1303e0    	mov	x0, x19
1000194a0: d2800002    	mov	x2, #0x0                ; =0
1000194a4: 52800003    	mov	w3, #0x0                ; =0
1000194a8: 9425563a    	bl	0x10096ed90 <_rust_png$cxxbridge1$199$Reader$interlaced+0xb6b50>
1000194ac: d2800000    	mov	x0, #0x0                ; =0
1000194b0: 17ffffeb    	b	0x10001945c <__text+0x1545c>
		...
1000194c0: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
1000194c4: a9014ff4    	stp	x20, x19, [sp, #0x10]
1000194c8: a9027bfd    	stp	x29, x30, [sp, #0x20]
1000194cc: 910083fd    	add	x29, sp, #0x20
1000194d0: b40001c1    	cbz	x1, 0x100019508 <__text+0x15508>
1000194d4: aa0103f4    	mov	x20, x1
1000194d8: aa0003f3    	mov	x19, x0
1000194dc: f9400281    	ldr	x1, [x20]
1000194e0: aa1303e0    	mov	x0, x19
1000194e4: 97fffff7    	bl	0x1000194c0 <__text+0x154c0>
1000194e8: b100829f    	cmn	x20, #0x20
1000194ec: 54000160    	b.eq	0x100019518 <__text+0x15518>
1000194f0: f9400695    	ldr	x21, [x20, #0x8]
1000194f4: aa1403e0    	mov	x0, x20
1000194f8: 52800801    	mov	w1, #0x40               ; =64
1000194fc: 97ffb847    	bl	0x100007618 <__text+0x3618>
100019500: aa1503f4    	mov	x20, x21
100019504: b5fffed5    	cbnz	x21, 0x1000194dc <__text+0x154dc>
100019508: a9427bfd    	ldp	x29, x30, [sp, #0x20]
10001950c: a9414ff4    	ldp	x20, x19, [sp, #0x10]
100019510: a8c357f6    	ldp	x22, x21, [sp], #0x30
100019514: d65f03c0    	ret
100019518: d4200020    	brk	#0x1
10001951c: f004fa28    	adrp	x8, 0x109f60000 <dyld_stub_binder+0x109f60000>
100019520: f9467d08    	ldr	x8, [x8, #0xcf8]
100019524: f9402103    	ldr	x3, [x8, #0x40]
100019528: b0017108    	adrp	x8, 0x102e3a000 <_media$cxxbridge1$199$init_symphonia_decoder+0x2435b0>
10001952c: 91258108    	add	x8, x8, #0x960
100019530: eb08007f    	cmp	x3, x8
100019534: 540001a1    	b.ne	0x100019568 <__text+0x15568>
100019538: b4000140    	cbz	x0, 0x100019560 <__text+0x15560>
10001953c: 925d7008    	and	x8, x0, #0xfffffff800000000
100019540: f004f9c9    	adrp	x9, 0x109f54000 <dyld_stub_binder+0x109f54000>
100019544: 912e0129    	add	x9, x9, #0xb80
100019548: f940012a    	ldr	x10, [x9]
10001954c: a9412d29    	ldp	x9, x11, [x9, #0x10]
100019550: 8a00016b    	and	x11, x11, x0
100019554: eb0a011f    	cmp	x8, x10
100019558: fa491164    	ccmp	x11, x9, #0x4, ne
10001955c: 54000241    	b.ne	0x1000195a4 <__text+0x155a4>
100019560: 14000012    	b	0x1000195a8 <__text+0x155a8>
100019564: d61f0060    	br	x3
100019568: b0017108    	adrp	x8, 0x102e3a000 <_media$cxxbridge1$199$init_symphonia_decoder+0x2435b0>
10001956c: 912e4108    	add	x8, x8, #0xb90
100019570: eb08007f    	cmp	x3, x8
100019574: 54ffff81    	b.ne	0x100019564 <__text+0x15564>
100019578: b4000140    	cbz	x0, 0x1000195a0 <__text+0x155a0>
10001957c: 925d7008    	and	x8, x0, #0xfffffff800000000
100019580: f004f9c9    	adrp	x9, 0x109f54000 <dyld_stub_binder+0x109f54000>
100019584: 912e0129    	add	x9, x9, #0xb80
100019588: f940012a    	ldr	x10, [x9]
10001958c: a9412d29    	ldp	x9, x11, [x9, #0x10]
100019590: 8a00016b    	and	x11, x11, x0
100019594: eb0a011f    	cmp	x8, x10
100019598: fa491164    	ccmp	x11, x9, #0x4, ne
10001959c: 54000041    	b.ne	0x1000195a4 <__text+0x155a4>
1000195a0: 14000021    	b	0x100019624 <__text+0x15624>
1000195a4: 15ffb314    	b	0x1080061f4 <__Z23_v8_internal_Node_PrintPv+0x3ef6bc8>
1000195a8: b40002c0    	cbz	x0, 0x100019600 <__text+0x15600>
1000195ac: aa0103e2    	mov	x2, x1
1000195b0: aa0003e1    	mov	x1, x0
1000195b4: 926ba808    	and	x8, x0, #0xffffffffffe00000
1000195b8: 925e7409    	and	x9, x0, #0xfffffffc00000000
1000195bc: f004f9ca    	adrp	x10, 0x109f54000 <dyld_stub_binder+0x109f54000>
1000195c0: f945c54a    	ldr	x10, [x10, #0xb88]
1000195c4: eb0a013f    	cmp	x9, x10
1000195c8: 54000101    	b.ne	0x1000195e8 <__text+0x155e8>
1000195cc: 52800049    	mov	w9, #0x2                ; =2
1000195d0: f004f9ca    	adrp	x10, 0x109f54000 <dyld_stub_binder+0x109f54000>
1000195d4: 912e014a    	add	x10, x10, #0xb80
1000195d8: 8b090d49    	add	x9, x10, x9, lsl #3
1000195dc: f9401129    	ldr	x9, [x9, #0x20]
1000195e0: f8686920    	ldr	x0, [x9, x8]
1000195e4: 1400002f    	b	0x1000196a0 <__text+0x156a0>
1000195e8: f004f9ca    	adrp	x10, 0x109f54000 <dyld_stub_binder+0x109f54000>
1000195ec: f945c14a    	ldr	x10, [x10, #0xb80]
1000195f0: eb0a013f    	cmp	x9, x10
1000195f4: 54000081    	b.ne	0x100019604 <__text+0x15604>
1000195f8: 52800029    	mov	w9, #0x1                ; =1
1000195fc: 17fffff5    	b	0x1000195d0 <__text+0x155d0>
100019600: d65f03c0    	ret
100019604: f004f9c9    	adrp	x9, 0x109f54000 <dyld_stub_binder+0x109f54000>
100019608: 912e4129    	add	x9, x9, #0xb90
10001960c: a9402929    	ldp	x9, x10, [x9]
100019610: 8a08014a    	and	x10, x10, x8
100019614: 5280006b    	mov	w11, #0x3               ; =3
100019618: eb09015f    	cmp	x10, x9
10001961c: 9a9f0169    	csel	x9, x11, xzr, eq
