
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101733544 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action>:
1017a1190: d10303ff    	sub	sp, sp, #0xc0
1017a1194: a9066ffc    	stp	x28, x27, [sp, #0x60]
1017a1198: a90767fa    	stp	x26, x25, [sp, #0x70]
1017a119c: a9085ff8    	stp	x24, x23, [sp, #0x80]
1017a11a0: a90957f6    	stp	x22, x21, [sp, #0x90]
1017a11a4: a90a4ff4    	stp	x20, x19, [sp, #0xa0]
1017a11a8: a90b7bfd    	stp	x29, x30, [sp, #0xb0]
1017a11ac: 9102c3fd    	add	x29, sp, #0xb0
1017a11b0: aa0203f5    	mov	x21, x2
1017a11b4: aa0003f3    	mov	x19, x0
1017a11b8: f0040c88    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
1017a11bc: f9401108    	ldr	x8, [x8, #0x20]
1017a11c0: f9400108    	ldr	x8, [x8]
1017a11c4: f9002fe8    	str	x8, [sp, #0x58]
1017a11c8: b5001341    	cbnz	x1, 0x1017a1430 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6deec>
1017a11cc: f10006bf    	cmp	x21, #0x1
1017a11d0: 9a9f86a8    	csinc	x8, x21, xzr, hi
1017a11d4: b9408269    	ldr	w9, [x19, #0x80]
1017a11d8: 8b090116    	add	x22, x8, x9
1017a11dc: eb1502df    	cmp	x22, x21
1017a11e0: 540042e3    	b.lo	0x1017a1a3c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e4f8>
1017a11e4: f0040c99    	adrp	x25, 0x109934000 <dyld_stub_binder+0x109934000>
1017a11e8: f9406339    	ldr	x25, [x25, #0xc0]
1017a11ec: b9400328    	ldr	w8, [x25]
1017a11f0: 39400269    	ldrb	w9, [x19]
1017a11f4: 350065a9    	cbnz	w9, 0x1017a1ea8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e964>
1017a11f8: 510006c9    	sub	w9, w22, #0x1
1017a11fc: 53047d29    	lsr	w9, w9, #4
1017a1200: dac012ca    	clz	x10, x22
1017a1204: 5280078b    	mov	w11, #0x3c              ; =60
1017a1208: 4b0a016b    	sub	w11, w11, w10
1017a120c: 9acb2ecb    	ror	x11, x22, x11
1017a1210: 9240096c    	and	x12, x11, #0x7
1017a1214: cb0a0d8a    	sub	x10, x12, x10, lsl #3
1017a1218: f1003d7f    	cmp	x11, #0xf
1017a121c: 9a8a954a    	cinc	x10, x10, hi
1017a1220: 91071d4a    	add	x10, x10, #0x1c7
1017a1224: 52800deb    	mov	w11, #0x6f              ; =111
1017a1228: f101bd5f    	cmp	x10, #0x6f
1017a122c: 9a8b314a    	csel	x10, x10, x11, lo
1017a1230: f10002df    	cmp	x22, #0x0
1017a1234: 1a8903e9    	csel	w9, wzr, w9, eq
1017a1238: f10406df    	cmp	x22, #0x101
1017a123c: 1a8a3129    	csel	w9, w9, w10, lo
1017a1240: 12003d2a    	and	w10, w9, #0xffff
1017a1244: f103fedf    	cmp	x22, #0xff
1017a1248: 52800dcb    	mov	w11, #0x6e              ; =110
1017a124c: 7a4b8142    	ccmp	w10, w11, #0x2, hi
1017a1250: 1a9f27ea    	cset	w10, lo
1017a1254: 2a090154    	orr	w20, w10, w9
1017a1258: 11000908    	add	w8, w8, #0x2
1017a125c: 52800029    	mov	w9, #0x1                ; =1
1017a1260: 1ac82128    	lsl	w8, w9, w8
1017a1264: 93407d17    	sxtw	x23, w8
1017a1268: 39009fff    	strb	wzr, [sp, #0x27]
1017a126c: 39400668    	ldrb	w8, [x19, #0x1]
1017a1270: 35003328    	cbnz	w8, 0x1017a18d4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e390>
1017a1274: d2800015    	mov	x21, #0x0               ; =0
1017a1278: 5280003a    	mov	w26, #0x1               ; =1
1017a127c: 12003e88    	and	w8, w20, #0xffff
1017a1280: 7101bd1f    	cmp	w8, #0x6f
1017a1284: 54004d48    	b.hi	0x1017a1c2c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6e8>
1017a1288: 92403e88    	and	x8, x20, #0xffff
1017a128c: 52800609    	mov	w9, #0x30               ; =48
1017a1290: 9ba94d08    	umaddl	x8, w8, w9, x19
1017a1294: 91042118    	add	x24, x8, #0x108
1017a1298: 91040260    	add	x0, x19, #0x100
1017a129c: 95d2dbcf    	bl	0x108c581d8 <dyld_stub_binder+0x108c581d8>
1017a12a0: 36003000    	tbz	w0, #0x0, 0x1017a18a0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e35c>
1017a12a4: f9400308    	ldr	x8, [x24]
1017a12a8: f90017e8    	str	x8, [sp, #0x28]
1017a12ac: b9400329    	ldr	w9, [x25]
1017a12b0: 11000929    	add	w9, w9, #0x2
1017a12b4: 5280002a    	mov	w10, #0x1               ; =1
1017a12b8: 1ac92149    	lsl	w9, w10, w9
1017a12bc: 6b0902ff    	cmp	w23, w9
1017a12c0: 54002b88    	b.hi	0x1017a1830 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e2ec>
1017a12c4: f9400114    	ldr	x20, [x8]
1017a12c8: b4002b54    	cbz	x20, 0x1017a1830 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e2ec>
1017a12cc: 39009fff    	strb	wzr, [sp, #0x27]
1017a12d0: f0040c8a    	adrp	x10, 0x109934000 <dyld_stub_binder+0x109934000>
1017a12d4: f940694a    	ldr	x10, [x10, #0xd0]
1017a12d8: f940014a    	ldr	x10, [x10]
1017a12dc: cb0a03ea    	neg	x10, x10
1017a12e0: 8a08014a    	and	x10, x10, x8
1017a12e4: f940014a    	ldr	x10, [x10]
1017a12e8: f95b5d4b    	ldr	x11, [x10, #0x36b8]
1017a12ec: ca0a016a    	eor	x10, x11, x10
1017a12f0: b100055f    	cmn	x10, #0x1
1017a12f4: 54004a61    	b.ne	0x1017a1c40 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6fc>
1017a12f8: b9401b16    	ldr	w22, [x24, #0x18]
1017a12fc: b940826a    	ldr	w10, [x19, #0x80]
1017a1300: f9400282    	ldr	x2, [x20]
1017a1304: b4000922    	cbz	x2, 0x1017a1428 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dee4>
1017a1308: 925e768b    	and	x11, x20, #0xfffffffc00000000
1017a130c: f0043d8c    	adrp	x12, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1310: f945c58c    	ldr	x12, [x12, #0xb88]
1017a1314: eb0c017f    	cmp	x11, x12
1017a1318: 54004c41    	b.ne	0x1017a1ca0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e75c>
1017a131c: b25e77ec    	mov	x12, #-0x400000000      ; =-17179869184
1017a1320: dac00c4d    	rev	x13, x2
1017a1324: ea0d019f    	tst	x12, x13
1017a1328: 540046e1    	b.ne	0x1017a1c04 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6c0>
1017a132c: aa0d016b    	orr	x11, x11, x13
1017a1330: f940068c    	ldr	x12, [x20, #0x8]
1017a1334: ca02018c    	eor	x12, x12, x2
1017a1338: 9240516d    	and	x13, x11, #0x1fffff
1017a133c: ca14016e    	eor	x14, x11, x20
1017a1340: eb29c1bf    	cmp	x13, w9, sxtw
1017a1344: d355fdc9    	lsr	x9, x14, #21
1017a1348: fa402920    	ccmp	x9, #0x0, #0x0, hs
1017a134c: ba410980    	ccmn	x12, #0x1, #0x0, eq
1017a1350: 540043c1    	b.ne	0x1017a1bc8 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e684>
1017a1354: f9800160    	prfm	pldl1keep, [x11]
1017a1358: cb0a02d7    	sub	x23, x22, x10
1017a135c: f900010b    	str	x11, [x8]
1017a1360: b9401909    	ldr	w9, [x8, #0x18]
1017a1364: 1100052a    	add	w10, w9, #0x1
1017a1368: 33003949    	bfxil	w9, w10, #0, #15
1017a136c: b9001909    	str	w9, [x8, #0x18]
1017a1370: f9400908    	ldr	x8, [x8, #0x10]
1017a1374: b9401916    	ldr	w22, [x8, #0x18]
1017a1378: 91040260    	add	x0, x19, #0x100
1017a137c: 95d2db94    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a1380: b4000374    	cbz	x20, 0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a1384: 5282c608    	mov	w8, #0x1630             ; =5680
1017a1388: 8b080268    	add	x8, x19, x8
1017a138c: f8360108    	ldadd	x22, x8, [x8]
1017a1390: 8b160108    	add	x8, x8, x22
1017a1394: 5282c709    	mov	w9, #0x1638             ; =5688
1017a1398: 8b090269    	add	x9, x19, x9
1017a139c: f94b1e6a    	ldr	x10, [x19, #0x1638]
1017a13a0: eb08015f    	cmp	x10, x8
1017a13a4: 9a88814b    	csel	x11, x10, x8, hi
1017a13a8: aa0a03ec    	mov	x12, x10
1017a13ac: c8ac7d2b    	cas	x12, x11, [x9]
1017a13b0: eb0a019f    	cmp	x12, x10
1017a13b4: 54ffff41    	b.ne	0x1017a139c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6de58>
1017a13b8: 360030fa    	tbz	w26, #0x0, 0x1017a19d4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e490>
1017a13bc: 39404268    	ldrb	w8, [x19, #0x10]
1017a13c0: 34000168    	cbz	w8, 0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a13c4: f0040c88    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
1017a13c8: f9406908    	ldr	x8, [x8, #0xd0]
1017a13cc: f9400108    	ldr	x8, [x8]
1017a13d0: d1000509    	sub	x9, x8, #0x1
1017a13d4: ea14013f    	tst	x9, x20
1017a13d8: 540026a0    	b.eq	0x1017a18ac <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e368>
1017a13dc: 8b160288    	add	x8, x20, x22
1017a13e0: d1001108    	sub	x8, x8, #0x4
1017a13e4: 52800029    	mov	w9, #0x1                ; =1
1017a13e8: b9000109    	str	w9, [x8]
1017a13ec: f9402fe8    	ldr	x8, [sp, #0x58]
1017a13f0: f0040c89    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
1017a13f4: f9401129    	ldr	x9, [x9, #0x20]
1017a13f8: f9400129    	ldr	x9, [x9]
1017a13fc: eb08013f    	cmp	x9, x8
1017a1400: 540031c1    	b.ne	0x1017a1a38 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e4f4>
1017a1404: aa1403e0    	mov	x0, x20
1017a1408: a94b7bfd    	ldp	x29, x30, [sp, #0xb0]
1017a140c: a94a4ff4    	ldp	x20, x19, [sp, #0xa0]
1017a1410: a94957f6    	ldp	x22, x21, [sp, #0x90]
1017a1414: a9485ff8    	ldp	x24, x23, [sp, #0x80]
1017a1418: a94767fa    	ldp	x26, x25, [sp, #0x70]
1017a141c: a9466ffc    	ldp	x28, x27, [sp, #0x60]
1017a1420: 910303ff    	add	sp, sp, #0xc0
1017a1424: d65f03c0    	ret
1017a1428: d280000b    	mov	x11, #0x0               ; =0
1017a142c: 17ffffcb    	b	0x1017a1358 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6de14>
1017a1430: aa0103f4    	mov	x20, x1
1017a1434: b4003ff5    	cbz	x21, 0x1017a1c30 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6ec>
1017a1438: 52affc08    	mov	w8, #0x7fe00000         ; =2145386496
1017a143c: eb0802bf    	cmp	x21, x8
1017a1440: 54003fc8    	b.hi	0x1017a1c38 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6f4>
1017a1444: 925e7688    	and	x8, x20, #0xfffffffc00000000
1017a1448: f0043d9c    	adrp	x28, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a144c: f945c789    	ldr	x9, [x28, #0xb88]
1017a1450: eb09011f    	cmp	x8, x9
1017a1454: 54004141    	b.ne	0x1017a1c7c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e738>
1017a1458: 52800048    	mov	w8, #0x2                ; =2
1017a145c: f0043d9b    	adrp	x27, 0x109f54000 <dyld_stub_binder+0x109f54000>
1017a1460: 912e037b    	add	x27, x27, #0xb80
1017a1464: 8b080f68    	add	x8, x27, x8, lsl #3
1017a1468: f9401108    	ldr	x8, [x8, #0x20]
1017a146c: 926baa89    	and	x9, x20, #0xffffffffffe00000
1017a1470: 9240528a    	and	x10, x20, #0x1fffff
1017a1474: f0040c98    	adrp	x24, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1478: f9406318    	ldr	x24, [x24, #0xc0]
1017a147c: b980030b    	ldrsw	x11, [x24]
1017a1480: 9100096b    	add	x11, x11, #0x2
1017a1484: 9acb254a    	lsr	x10, x10, x11
1017a1488: 8b090108    	add	x8, x8, x9
1017a148c: 8b0a1508    	add	x8, x8, x10, lsl #5
1017a1490: 39407909    	ldrb	w9, [x8, #0x1e]
1017a1494: 92401529    	and	x9, x9, #0x3f
1017a1498: cb091516    	sub	x22, x8, x9, lsl #5
1017a149c: f0040c99    	adrp	x25, 0x109934000 <dyld_stub_binder+0x109934000>
1017a14a0: f9406b39    	ldr	x25, [x25, #0xd0]
1017a14a4: f9400328    	ldr	x8, [x25]
1017a14a8: cb0803e8    	neg	x8, x8
1017a14ac: 8a0802c8    	and	x8, x22, x8
1017a14b0: f9400117    	ldr	x23, [x8]
1017a14b4: 910402e0    	add	x0, x23, #0x100
1017a14b8: 95d2db48    	bl	0x108c581d8 <dyld_stub_binder+0x108c581d8>
1017a14bc: 36003c80    	tbz	w0, #0x0, 0x1017a1c4c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e708>
1017a14c0: f9400328    	ldr	x8, [x25]
1017a14c4: cb0803e8    	neg	x8, x8
1017a14c8: 8a160108    	and	x8, x8, x22
1017a14cc: f9400108    	ldr	x8, [x8]
1017a14d0: f95b5d09    	ldr	x9, [x8, #0x36b8]
1017a14d4: ca080128    	eor	x8, x9, x8
1017a14d8: b100051f    	cmn	x8, #0x1
1017a14dc: 54003be1    	b.ne	0x1017a1c58 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e714>
1017a14e0: b9401ac8    	ldr	w8, [x22, #0x18]
1017a14e4: 37f83c08    	tbnz	w8, #0x1f, 0x1017a1c64 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e720>
1017a14e8: f9400ac8    	ldr	x8, [x22, #0x10]
1017a14ec: b9401919    	ldr	w25, [x8, #0x18]
1017a14f0: b94082e9    	ldr	w9, [x23, #0x80]
1017a14f4: f9000be9    	str	x9, [sp, #0x10]
1017a14f8: 39407108    	ldrb	w8, [x8, #0x1c]
1017a14fc: 34005088    	cbz	w8, 0x1017a1f0c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e9c8>
1017a1500: 910402e0    	add	x0, x23, #0x100
1017a1504: 95d2db32    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a1508: aa1703e0    	mov	x0, x23
1017a150c: aa1403e1    	mov	x1, x20
1017a1510: aa1603e2    	mov	x2, x22
1017a1514: aa1503e3    	mov	x3, x21
1017a1518: 94000376    	bl	0x1017a22f0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6edac>
1017a151c: 3707f680    	tbnz	w0, #0x0, 0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
1017a1520: b9400308    	ldr	w8, [x24]
1017a1524: b9408269    	ldr	w9, [x19, #0x80]
1017a1528: 8b0902b8    	add	x24, x21, x9
1017a152c: 39400269    	ldrb	w9, [x19]
1017a1530: f9000ff9    	str	x25, [sp, #0x18]
1017a1534: 35005189    	cbnz	w9, 0x1017a1f64 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ea20>
1017a1538: 51000709    	sub	w9, w24, #0x1
1017a153c: 53047d29    	lsr	w9, w9, #4
1017a1540: dac0130a    	clz	x10, x24
1017a1544: 5280078b    	mov	w11, #0x3c              ; =60
1017a1548: 4b0a016b    	sub	w11, w11, w10
1017a154c: 9acb2f0b    	ror	x11, x24, x11
1017a1550: 9240096c    	and	x12, x11, #0x7
1017a1554: cb0a0d8a    	sub	x10, x12, x10, lsl #3
1017a1558: f1003d7f    	cmp	x11, #0xf
1017a155c: 9a8a954a    	cinc	x10, x10, hi
1017a1560: 91071d4a    	add	x10, x10, #0x1c7
1017a1564: 52800deb    	mov	w11, #0x6f              ; =111
1017a1568: f101bd5f    	cmp	x10, #0x6f
1017a156c: 9a8b314a    	csel	x10, x10, x11, lo
1017a1570: f104071f    	cmp	x24, #0x101
1017a1574: 1a8a3129    	csel	w9, w9, w10, lo
1017a1578: 12003d2a    	and	w10, w9, #0xffff
1017a157c: f103ff1f    	cmp	x24, #0xff
1017a1580: 52800dcb    	mov	w11, #0x6e              ; =110
1017a1584: 7a4b8142    	ccmp	w10, w11, #0x2, hi
1017a1588: 1a9f27ea    	cset	w10, lo
1017a158c: 2a090157    	orr	w23, w10, w9
1017a1590: 11000908    	add	w8, w8, #0x2
1017a1594: 52800029    	mov	w9, #0x1                ; =1
1017a1598: 1ac82128    	lsl	w8, w9, w8
1017a159c: 93407d19    	sxtw	x25, w8
1017a15a0: 39009fff    	strb	wzr, [sp, #0x27]
1017a15a4: 39400668    	ldrb	w8, [x19, #0x1]
1017a15a8: 35003968    	cbnz	w8, 0x1017a1cd4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e790>
1017a15ac: f90007ff    	str	xzr, [sp, #0x8]
1017a15b0: 52800036    	mov	w22, #0x1               ; =1
1017a15b4: 12003ee8    	and	w8, w23, #0xffff
1017a15b8: 7101bd1f    	cmp	w8, #0x6f
1017a15bc: 54003388    	b.hi	0x1017a1c2c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6e8>
1017a15c0: 92403ee8    	and	x8, x23, #0xffff
1017a15c4: 52800609    	mov	w9, #0x30               ; =48
1017a15c8: 9ba94d08    	umaddl	x8, w8, w9, x19
1017a15cc: 9104211b    	add	x27, x8, #0x108
1017a15d0: 9104027a    	add	x26, x19, #0x100
1017a15d4: 91040260    	add	x0, x19, #0x100
1017a15d8: 95d2db00    	bl	0x108c581d8 <dyld_stub_binder+0x108c581d8>
1017a15dc: 360034a0    	tbz	w0, #0x0, 0x1017a1c70 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e72c>
1017a15e0: f9400368    	ldr	x8, [x27]
1017a15e4: f90017e8    	str	x8, [sp, #0x28]
1017a15e8: f0040c89    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
1017a15ec: f9406129    	ldr	x9, [x9, #0xc0]
1017a15f0: b9400129    	ldr	w9, [x9]
1017a15f4: 11000929    	add	w9, w9, #0x2
1017a15f8: 5280002a    	mov	w10, #0x1               ; =1
1017a15fc: 1ac92149    	lsl	w9, w10, w9
1017a1600: 6b09033f    	cmp	w25, w9
1017a1604: 54000aa8    	b.hi	0x1017a1758 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e214>
1017a1608: f9400117    	ldr	x23, [x8]
1017a160c: b4000a77    	cbz	x23, 0x1017a1758 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e214>
1017a1610: 39009fff    	strb	wzr, [sp, #0x27]
1017a1614: f0040c9a    	adrp	x26, 0x109934000 <dyld_stub_binder+0x109934000>
1017a1618: f9406b5a    	ldr	x26, [x26, #0xd0]
1017a161c: f940034a    	ldr	x10, [x26]
1017a1620: cb0a03ea    	neg	x10, x10
1017a1624: 8a08014a    	and	x10, x10, x8
1017a1628: f940014a    	ldr	x10, [x10]
1017a162c: f95b5d4b    	ldr	x11, [x10, #0x36b8]
1017a1630: ca0a016a    	eor	x10, x11, x10
1017a1634: b100055f    	cmn	x10, #0x1
1017a1638: 540032e1    	b.ne	0x1017a1c94 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e750>
1017a163c: b9401b78    	ldr	w24, [x27, #0x18]
1017a1640: b940826a    	ldr	w10, [x19, #0x80]
1017a1644: f94002e2    	ldr	x2, [x23]
1017a1648: b4000842    	cbz	x2, 0x1017a1750 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e20c>
1017a164c: 925e76eb    	and	x11, x23, #0xfffffffc00000000
1017a1650: f945c78c    	ldr	x12, [x28, #0xb88]
1017a1654: eb0c017f    	cmp	x11, x12
1017a1658: 540046c1    	b.ne	0x1017a1f30 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e9ec>
1017a165c: b25e77ec    	mov	x12, #-0x400000000      ; =-17179869184
1017a1660: dac00c4d    	rev	x13, x2
1017a1664: ea0d019f    	tst	x12, x13
1017a1668: 540041c1    	b.ne	0x1017a1ea0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e95c>
1017a166c: aa0d016b    	orr	x11, x11, x13
1017a1670: f94006ec    	ldr	x12, [x23, #0x8]
1017a1674: ca02018c    	eor	x12, x12, x2
1017a1678: 9240516d    	and	x13, x11, #0x1fffff
1017a167c: ca17016e    	eor	x14, x11, x23
1017a1680: eb29c1bf    	cmp	x13, w9, sxtw
1017a1684: d355fdc9    	lsr	x9, x14, #21
1017a1688: fa402920    	ccmp	x9, #0x0, #0x0, hs
1017a168c: ba410980    	ccmn	x12, #0x1, #0x0, eq
1017a1690: 54003ea1    	b.ne	0x1017a1e64 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e920>
1017a1694: f9800160    	prfm	pldl1keep, [x11]
1017a1698: cb0a0319    	sub	x25, x24, x10
1017a169c: f900010b    	str	x11, [x8]
1017a16a0: b9401909    	ldr	w9, [x8, #0x18]
1017a16a4: 1100052a    	add	w10, w9, #0x1
1017a16a8: 33003949    	bfxil	w9, w10, #0, #15
1017a16ac: b9001909    	str	w9, [x8, #0x18]
1017a16b0: f9400908    	ldr	x8, [x8, #0x10]
1017a16b4: b9401918    	ldr	w24, [x8, #0x18]
1017a16b8: 91040260    	add	x0, x19, #0x100
1017a16bc: 95d2dac4    	bl	0x108c581cc <dyld_stub_binder+0x108c581cc>
1017a16c0: b4002bd7    	cbz	x23, 0x1017a1c38 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e6f4>
1017a16c4: 5282c608    	mov	w8, #0x1630             ; =5680
1017a16c8: 8b080268    	add	x8, x19, x8
1017a16cc: f8380108    	ldadd	x24, x8, [x8]
1017a16d0: 8b180108    	add	x8, x8, x24
1017a16d4: 5282c709    	mov	w9, #0x1638             ; =5688
1017a16d8: 8b090269    	add	x9, x19, x9
1017a16dc: f94b1e6a    	ldr	x10, [x19, #0x1638]
1017a16e0: eb08015f    	cmp	x10, x8
1017a16e4: 9a88814b    	csel	x11, x10, x8, hi
1017a16e8: aa0a03ec    	mov	x12, x10
1017a16ec: c8ac7d2b    	cas	x12, x11, [x9]
1017a16f0: eb0a019f    	cmp	x12, x10
1017a16f4: 54ffff41    	b.ne	0x1017a16dc <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e198>
1017a16f8: 36003996    	tbz	w22, #0x0, 0x1017a1e28 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e8e4>
1017a16fc: a94123e9    	ldp	x9, x8, [sp, #0x10]
1017a1700: cb090108    	sub	x8, x8, x9
1017a1704: 39404269    	ldrb	w9, [x19, #0x10]
1017a1708: 34000129    	cbz	w9, 0x1017a172c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e1e8>
1017a170c: f9400349    	ldr	x9, [x26]
1017a1710: d100052a    	sub	x10, x9, #0x1
1017a1714: ea17015f    	tst	x10, x23
1017a1718: 54000740    	b.eq	0x1017a1800 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6e2bc>
1017a171c: 8b1802e9    	add	x9, x23, x24
1017a1720: d1001129    	sub	x9, x9, #0x4
1017a1724: 5280002a    	mov	w10, #0x1               ; =1
1017a1728: b900012a    	str	w10, [x9]
1017a172c: eb0802bf    	cmp	x21, x8
1017a1730: 9a8832a2    	csel	x2, x21, x8, lo
1017a1734: aa1703e0    	mov	x0, x23
1017a1738: aa1403e1    	mov	x1, x20
1017a173c: 95d2da9b    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
1017a1740: aa1403e0    	mov	x0, x20
1017a1744: 94000342    	bl	0x1017a244c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ef08>
1017a1748: aa1703f4    	mov	x20, x23
1017a174c: 17ffff28    	b	0x1017a13ec <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dea8>
