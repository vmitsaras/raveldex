"""Explicit host observations of real stopped frames; never invokes tap callbacks.
No target expression/continue runs inside this module. Native execution stays at
LLDB prompt. Callback suppression is recorded rather than disguised.
"""
import hashlib,json,pathlib,time
import lldb
import lldb_native_tap as rx
ROOT=pathlib.Path(__file__).resolve().parent
OFFSET=0x9f734
CONTROL=None
ENTRY_BP=None
RETURN_BP=None

class Manual:
 def __init__(self,pid,tid,base,root):
  if any(type(v) is not int or not 0<v<2**53 for v in (pid,tid,base,root)):raise ValueError('Invalid exact context')
  self.pid,self.tid,self.base,self.root=pid,tid,base,root;self.phase='Armed';self.rows=[];self.entry=None;self.returned=None;self.continues=0;self.reason=None;self.origin=None;self.registerReadback=None
 def record(self,kind,**values):
  if len(self.rows)>=16:raise ValueError('Manual event bound')
  self.rows.append(dict(seq=len(self.rows)+1,kind=kind,observationSource='Explicit host read of debugger-stopped frame; no native callback invoked',**values))
 def observe_entry(self,c):
  if self.phase!='Armed':raise ValueError('Unexpected entry state')
  if any(c[k]!=v for k,v in dict(pid=self.pid,tid=self.tid,pc=self.base+OFFSET,root=self.root,size=129).items()):raise ValueError('Entry identity mismatch')
  if not c['ownBreakpointHit'] or c['sp']<=0 or c['sp']%16 or not 0<c['lr']<2**53 or c['lr']%4:raise ValueError('Invalid exact entry stop')
  self.entry=dict(c);self.record('manual-native-entry',**c);self.phase='EntryVerified'
 def authorize(self,c):
  if self.phase!='EntryVerified' or self.continues:raise ValueError('Only one continuation allowed')
  if any(c[k]!=self.entry[k] for k in ('pid','tid','pc','sp','lr')) or not c['ownBreakpointHit']:raise ValueError('Entry stop changed')
  self.continues=1;self.phase='OneContinueAuthorized';self.record('one-top-level-continue-authorized')
 def observe_return(self,c):
  if self.phase!='OneContinueAuthorized':raise ValueError('Return before guarded continuation')
  if any(c[k]!=v for k,v in dict(pid=self.pid,tid=self.tid,pc=self.entry['lr'],sp=self.entry['sp']).items()) or not c['ownBreakpointHit']:raise ValueError('Return frame mismatch')
  if not 130<=c['value']<=4096:raise ValueError('Quantizer returned outside admitted range')
  self.returned=dict(c);self.record('manual-native-return',**c);self.phase='ReturnVerified'
 def register_readback(self,value):
  if self.phase!='ReturnVerified' or type(value) is not int or value!=self.returned['value']:raise ValueError('Static register expression readback mismatch')
  self.record('static-register-expression-readback',value=value,originalPersistentExpressionResultMaterialized=False)
  self.registerReadback=value
 def authorize_completion(self,c):
  if self.phase!='ReturnVerified' or self.continues!=1 or self.registerReadback!=self.returned['value']:raise ValueError('Completion requires witnessed native return and register readback')
  if any(c[k]!=self.returned[k] for k in ('pid','tid','pc','sp')) or not c['ownBreakpointHit']:raise ValueError('Return stop changed before JIT completion')
  self.continues=2;self.phase='JITCompletionAuthorized';self.record('second-top-level-continue-for-JIT-only-authorized')
 def completion(self,c):
  if self.phase!='JITCompletionAuthorized' or not self.origin or any(c[k]!=self.origin[k] for k in ('pid','tid','pc','sp')):raise ValueError('Original stopped context not restored')
  self.record('original-stopped-context-restored',**c);self.phase='OriginalContextRestored'
 def readback(self,value):
  if self.phase!='OriginalContextRestored' or type(value) is not int or value!=self.returned['value']:raise ValueError('Persistent expression result mismatch')
  self.record('original-persistent-expression-result-readback',value=value);self.phase='Pass'
 def refuse(self,reason):self.phase='Refused';self.reason=str(reason)
 def report(self):return dict(schema='raveldex-manual-expression-frame-capability-v1',phase=self.phase,reason=self.reason,pid=self.pid,tid=self.tid,base=self.base,root=self.root,continues=self.continues,entry=self.entry,returned=self.returned,rows=self.rows,autoTapEventsAdded=False,selectedControlAllocatorCalled=False,originalPersistentExpressionCompletionQualified=self.phase=='Pass',scope='Actual quantizer entry/native return and completed original expression result, with manual frame guards and at most two guarded continuations. No allocator/in-place/auto-tap/physical memory claim.')

def frame(debugger):return debugger.GetSelectedTarget().GetProcess().GetSelectedThread().GetFrameAtIndex(0)
def paused(debugger):
 if not rx.INSTALLED or not rx.ACTIVE or rx.INVALID or rx.DROPPED or rx.LABEL!='manual-capability' or any(rx.CALLS.values()) or rx.LIVE:raise RuntimeError('Require active valid drained dedicated observer')
 process=debugger.GetSelectedTarget().GetProcess()
 if process.GetProcessID()!=rx.CONFIG['pid'] or process.GetState()!=lldb.eStateStopped:raise RuntimeError('Wrong paused owned renderer')
 f=frame(debugger)
 if f.GetThread().GetThreadID()!=rx.CONFIG['mainTid']:raise RuntimeError('Wrong trace-proven main thread')
 return f
def context(f,bp):
 t=f.GetThread();data=[t.GetStopReasonDataAtIndex(i) for i in range(t.GetStopReasonDataCount())]
 return dict(pid=t.GetProcess().GetProcessID(),tid=t.GetThreadID(),pc=f.GetPC(),sp=rx.reg(f,'sp'),lr=rx.reg(f,'lr'),stopReason=t.GetStopReason(),stopReasonData=data,ownBreakpointHit=t.GetStopReason()==lldb.eStopReasonBreakpoint and any(data[i]==bp.GetID() for i in range(0,len(data),2)))
def arm(debugger,command,result,_):
 global CONTROL,ENTRY_BP
 try:
  if command.strip()!='prepare-owned-quantizer129' or CONTROL is not None:raise RuntimeError('One explicit fresh manual control only')
  initial=paused(debugger);roots={r['root'] for r in rx.ROWS if r['kind']=='realloc-enter'}
  if len(roots)!=1:raise RuntimeError('Require one freshly observed allocator root')
  site=json.loads((ROOT/'hook-manifest.json').read_text())['sites']['pa_quantize'];expected=bytes.fromhex(site['bytes_hex']);error=lldb.SBError();actual=rx.TARGET.GetProcess().ReadMemory(rx.BASE+OFFSET,len(expected),error)
  if error.Fail() or actual!=expected:raise RuntimeError('Quantizer code fingerprint mismatch')
  CONTROL=Manual(rx.CONFIG['pid'],rx.CONFIG['mainTid'],rx.BASE,roots.pop());CONTROL.origin=dict(pid=rx.CONFIG['pid'],tid=rx.CONFIG['mainTid'],pc=initial.GetPC(),sp=rx.reg(initial,'sp'));ENTRY_BP=rx.TARGET.BreakpointCreateByAddress(rx.BASE+OFFSET);ENTRY_BP.SetThreadID(CONTROL.tid)
  if ENTRY_BP.GetNumLocations()!=1 or ENTRY_BP.GetThreadID()!=CONTROL.tid:raise RuntimeError('Entry breakpoint/thread unresolved')
  expression='expression --ignore-breakpoints false --unwind-on-error false --all-threads false --timeout 5000000 --language c++ -- unsigned long $rx_manual129 = ((unsigned long(*)(unsigned long,unsigned long))%d)(%d,129)'%(CONTROL.base+OFFSET,CONTROL.root)
  result.PutCString(json.dumps(dict(action='Exactly one top-level native expression',expression=expression,entryBreakpointId=ENTRY_BP.GetID(),state=CONTROL.report())))
 except Exception as error:refused(error,result)
def observe_entry(debugger,command,result,_):
 global RETURN_BP
 try:
  if command.strip()!='actual-stopped-entry':raise RuntimeError('Explicit actual-stopped-entry required')
  f=paused(debugger);c=context(f,ENTRY_BP);c.update(root=rx.reg(f,'x0'),size=rx.reg(f,'x1'));CONTROL.observe_entry(c)
  RETURN_BP=rx.TARGET.BreakpointCreateByAddress(c['lr']);RETURN_BP.SetThreadID(CONTROL.tid)
  if RETURN_BP.GetNumLocations()!=1 or RETURN_BP.GetThreadID()!=CONTROL.tid:raise RuntimeError('Return breakpoint/thread unresolved')
  result.PutCString(json.dumps(dict(returnBreakpointId=RETURN_BP.GetID(),state=CONTROL.report())))
 except Exception as error:refused(error,result)
def authorize(debugger,command,result,_):
 try:
  if command.strip()!='one-top-level-continue':raise RuntimeError('Explicit one-top-level-continue required')
  CONTROL.authorize(context(paused(debugger),ENTRY_BP));result.PutCString(json.dumps(CONTROL.report()))
 except Exception as error:refused(error,result)
def observe_return(debugger,command,result,_):
 try:
  if command.strip()!='actual-stopped-return':raise RuntimeError('Explicit actual-stopped-return required')
  f=paused(debugger);c=context(f,RETURN_BP);c['value']=rx.reg(f,'x0');CONTROL.observe_return(c)
  result.PutCString(json.dumps(dict(state=CONTROL.report(),readback='expression --allow-jit false --language c++ -- (unsigned long)$x0')))
 except Exception as error:refused(error,result)
def register_readback(debugger,command,result,_):
 try:
  paused(debugger)
  if not command.strip().isdecimal():raise RuntimeError('Literal unsigned result from no-JIT static register expression required')
  CONTROL.register_readback(int(command));result.PutCString(json.dumps(CONTROL.report()))
 except Exception as error:refused(error,result)
def authorize_completion(debugger,command,result,_):
 global RETURN_BP
 try:
  if command.strip()!='one-jit-completion-continue':raise RuntimeError('Explicit one-jit-completion-continue required')
  CONTROL.authorize_completion(context(paused(debugger),RETURN_BP))
  rx.TARGET.BreakpointDelete(RETURN_BP.GetID());RETURN_BP=None
  result.PutCString(json.dumps(CONTROL.report()))
 except Exception as error:refused(error,result)
def completion(debugger,command,result,_):
 try:
  if command.strip()!='actual-original-context':raise RuntimeError('Explicit actual-original-context required')
  f=paused(debugger);CONTROL.completion(dict(pid=f.GetThread().GetProcess().GetProcessID(),tid=f.GetThread().GetThreadID(),pc=f.GetPC(),sp=rx.reg(f,'sp')));result.PutCString(json.dumps(CONTROL.report()))
 except Exception as error:refused(error,result)
def readback(debugger,command,result,_):
 try:
  paused(debugger)
  if not command.strip().isdecimal():raise RuntimeError('Literal value from no-JIT original persistent-variable expression required')
  CONTROL.readback(int(command));result.PutCString(json.dumps(CONTROL.report()))
 except Exception as error:refused(error,result)
def refused(error,result):
 if CONTROL:CONTROL.refuse(error)
 result.SetError(str(error))
def status(debugger,command,result,_):result.PutCString(json.dumps(CONTROL.report() if CONTROL else {'phase':'Not armed'}))
def save(debugger,command,result,_):
 try:
  if command.strip()!='new-receipt' or CONTROL is None:raise RuntimeError('Explicit new-receipt required')
  value=CONTROL.report();value.update(sourceSha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),observerSha256=hashlib.sha256((ROOT/'lldb_native_tap.py').read_bytes()).hexdigest(),savedUnix=time.time())
  p=rx.OUT/'manual-capability.json'
  with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
  result.PutCString('RX_MANUAL_SAVED '+str(p))
 except Exception as error:result.SetError(str(error))
def cleanup(debugger,command,result,_):
 global ENTRY_BP,RETURN_BP
 for bp in [ENTRY_BP,RETURN_BP]:
  if bp is not None:rx.TARGET.BreakpointDelete(bp.GetID())
 ENTRY_BP=RETURN_BP=None;result.PutCString('RX_MANUAL_PROBE_HOOKS_REMOVED')
def __lldb_init_module(debugger,_):
 for n,f in [('rx-manual-arm','arm'),('rx-manual-entry','observe_entry'),('rx-manual-authorize','authorize'),('rx-manual-return','observe_return'),('rx-manual-register-readback','register_readback'),('rx-manual-complete-authorize','authorize_completion'),('rx-manual-completion','completion'),('rx-manual-readback','readback'),('rx-manual-status','status'),('rx-manual-save','save'),('rx-manual-cleanup','cleanup')]:debugger.HandleCommand('command script add -f manual_capability.'+f+' '+n)
