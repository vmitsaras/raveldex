
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001003cf180 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk>:
1005212c8: d35ffc48    	lsr	x8, x2, #31
1005212cc: b5000f08    	cbnz	x8, 0x1005214ac <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x15232c>
1005212d0: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
1005212d4: a9014ff4    	stp	x20, x19, [sp, #0x10]
1005212d8: a9027bfd    	stp	x29, x30, [sp, #0x20]
1005212dc: 910083fd    	add	x29, sp, #0x20
1005212e0: aa0203f3    	mov	x19, x2
1005212e4: aa0103f4    	mov	x20, x1
1005212e8: aa0003f5    	mov	x21, x0
1005212ec: f100045f    	cmp	x2, #0x1
1005212f0: 54000b60    	b.eq	0x10052145c <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x1522dc>
1005212f4: 34000d33    	cbz	w19, 0x100521498 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152318>
1005212f8: 7100047f    	cmp	w3, #0x1
1005212fc: 54000081    	b.ne	0x10052130c <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x15218c>
100521300: aa1503e0    	mov	x0, x21
100521304: 97eef4ab    	bl	0x1000de5b0 <_cxxbridge1$slice$new+0x98ad4>
100521308: aa0003e3    	mov	x3, x0
10052130c: 529ffd28    	mov	w8, #0xffe9             ; =65513
100521310: 72a3ffe8    	movk	w8, #0x1fff, lsl #16
100521314: eb08027f    	cmp	x19, x8
100521318: 54000d02    	b.hs	0x1005214b8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152338>
10052131c: 11003e68    	add	w8, w19, #0xf
100521320: 121e6d16    	and	w22, w8, #0x3ffffffc
100521324: aa1503e0    	mov	x0, x21
100521328: aa1603e1    	mov	x1, x22
10052132c: aa0303e2    	mov	x2, x3
100521330: 52800003    	mov	w3, #0x0                ; =0
100521334: d2800004    	mov	x4, #0x0                ; =0
100521338: 97ec6432    	bl	0x10003a400 <_cxxbridge1$str$ptr+0x814>
10052133c: aa0003e1    	mov	x1, x0
100521340: d1000408    	sub	x8, x0, #0x1
100521344: 528020a9    	mov	w9, #0x105              ; =261
100521348: b81ff009    	stur	w9, [x0, #-0x1]
10052134c: 8b160108    	add	x8, x8, x22
100521350: b81fc11f    	stur	wzr, [x8, #-0x4]
100521354: b8007013    	stur	w19, [x0, #0x7]
100521358: 52800068    	mov	w8, #0x3                ; =3
10052135c: b8003008    	stur	w8, [x0, #0x3]
100521360: f94116a0    	ldr	x0, [x21, #0x228]
100521364: f9411aa8    	ldr	x8, [x21, #0x230]
100521368: eb08001f    	cmp	x0, x8
10052136c: 540009a0    	b.eq	0x1005214a0 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152320>
100521370: 91002008    	add	x8, x0, #0x8
100521374: f90116a8    	str	x8, [x21, #0x228]
100521378: f9000001    	str	x1, [x0]
10052137c: b4000360    	cbz	x0, 0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
100521380: f9400008    	ldr	x8, [x0]
100521384: 91002d08    	add	x8, x8, #0xb
100521388: f1000669    	subs	x9, x19, #0x1
10052138c: 540002a0    	b.eq	0x1005213e0 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152260>
100521390: b40002d3    	cbz	x19, 0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
100521394: dac01129    	clz	x9, x9
100521398: f100f13f    	cmp	x9, #0x3c
10052139c: 540002ed    	b.le	0x1005213f8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152278>
1005213a0: 7100f53f    	cmp	w9, #0x3d
1005213a4: 54000100    	b.eq	0x1005213c4 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152244>
1005213a8: 7100f93f    	cmp	w9, #0x3e
1005213ac: 54000380    	b.eq	0x10052141c <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x15229c>
1005213b0: 7100fd3f    	cmp	w9, #0x3f
1005213b4: 540005c1    	b.ne	0x10052146c <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x1522ec>
1005213b8: 79400289    	ldrh	w9, [x20]
1005213bc: 79000109    	strh	w9, [x8]
1005213c0: 1400000a    	b	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
1005213c4: b9400289    	ldr	w9, [x20]
1005213c8: b9000109    	str	w9, [x8]
1005213cc: 8b130289    	add	x9, x20, x19
1005213d0: b85fc129    	ldur	w9, [x9, #-0x4]
1005213d4: 8b130108    	add	x8, x8, x19
1005213d8: b81fc109    	stur	w9, [x8, #-0x4]
1005213dc: 14000003    	b	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
1005213e0: 39400289    	ldrb	w9, [x20]
1005213e4: 39000109    	strb	w9, [x8]
1005213e8: a9427bfd    	ldp	x29, x30, [sp, #0x20]
1005213ec: a9414ff4    	ldp	x20, x19, [sp, #0x10]
1005213f0: a8c357f6    	ldp	x22, x21, [sp], #0x30
1005213f4: d65f03c0    	ret
1005213f8: 7100ed3f    	cmp	w9, #0x3b
1005213fc: 540001e1    	b.ne	0x100521438 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x1522b8>
100521400: 3dc00280    	ldr	q0, [x20]
100521404: 3d800100    	str	q0, [x8]
100521408: 8b130289    	add	x9, x20, x19
10052140c: 3cdf0120    	ldur	q0, [x9, #-0x10]
100521410: 8b130108    	add	x8, x8, x19
100521414: 3c9f0100    	stur	q0, [x8, #-0x10]
100521418: 17fffff4    	b	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
10052141c: 79400289    	ldrh	w9, [x20]
100521420: 79000109    	strh	w9, [x8]
100521424: 8b130289    	add	x9, x20, x19
100521428: 785fe129    	ldurh	w9, [x9, #-0x2]
10052142c: 8b130108    	add	x8, x8, x19
100521430: 781fe109    	sturh	w9, [x8, #-0x2]
100521434: 17ffffed    	b	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
100521438: 7100f13f    	cmp	w9, #0x3c
10052143c: 54000181    	b.ne	0x10052146c <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x1522ec>
100521440: f9400289    	ldr	x9, [x20]
100521444: f9000109    	str	x9, [x8]
100521448: 8b130289    	add	x9, x20, x19
10052144c: f85f8129    	ldur	x9, [x9, #-0x8]
100521450: 8b130108    	add	x8, x8, x19
100521454: f81f8109    	stur	x9, [x8, #-0x8]
100521458: 17ffffe4    	b	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
10052145c: 39400288    	ldrb	w8, [x20]
100521460: 8b080ea8    	add	x8, x21, x8, lsl #3
100521464: 9139e100    	add	x0, x8, #0xe78
100521468: 17ffffe0    	b	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
10052146c: 3dc00280    	ldr	q0, [x20]
100521470: 3d800100    	str	q0, [x8]
100521474: f100427f    	cmp	x19, #0x10
100521478: 54fffb83    	b.lo	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
10052147c: 92400e69    	and	x9, x19, #0xf
100521480: 3ce96a80    	ldr	q0, [x20, x9]
100521484: 3ca96900    	str	q0, [x8, x9]
100521488: 91004129    	add	x9, x9, #0x10
10052148c: eb13013f    	cmp	x9, x19
100521490: 54ffff83    	b.lo	0x100521480 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152300>
100521494: 17ffffd5    	b	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
100521498: 910e82a0    	add	x0, x21, #0x3a0
10052149c: 17ffffd3    	b	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
1005214a0: aa1503e0    	mov	x0, x21
1005214a4: 97ed2501    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
1005214a8: 17ffffb5    	b	0x10052137c <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x1521fc>
1005214ac: d4200000    	brk	#0
1005214b0: d4400000    	hlt	#0
1005214b4: d4200020    	brk	#0x1
1005214b8: aa1503e0    	mov	x0, x21
1005214bc: 94dd9c12    	bl	0x103c88504 <__v8_internal_Print_TransitionTree+0x3fb1c>
1005214c0: f9400001    	ldr	x1, [x0]
1005214c4: aa1503e0    	mov	x0, x21
1005214c8: d2800002    	mov	x2, #0x0                ; =0
1005214cc: 52800003    	mov	w3, #0x0                ; =0
1005214d0: 94113630    	bl	0x10096ed90 <_rust_png$cxxbridge1$199$Reader$interlaced+0xb6b50>
1005214d4: d2800000    	mov	x0, #0x0                ; =0
1005214d8: 17ffffc4    	b	0x1005213e8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152268>
