"""Bounded manual native control. No target calls or continues inside Python.
Each row is read from an actual stopped frame, never fabricated as tap telemetry.
"""
import hashlib,json,pathlib,time
import lldb
import lldb_native_tap as rx
ROOT=pathlib.Path(__file__).resolve().parent
KINDS=('q129','q130','alloc','realloc','free')
OFFSETS=dict(q129=0x9f734,q130=0x9f734,alloc=0x1c36c,realloc=0x17a1190,free=0x1d6d0)
BRANCH=0x17a151c
CONTROL=None
ENTRY_BP=RETURN_BP=BRANCH_BP=None

class Call:
 def __init__(self,kind,pid,tid,base,root,typeptr,pointer,origin):
  if kind not in KINDS or any(type(x) is not int or not 0<x<2**53 for x in (pid,tid,base,root,typeptr)):raise ValueError('Bad bounded call identity')
  if kind in ('realloc','free') and (type(pointer) is not int or not 0<pointer<2**53):raise ValueError('No qualified owned pointer')
  self.kind,self.pid,self.tid,self.base,self.root,self.typeptr,self.pointer=kind,pid,tid,base,root,typeptr,pointer
  self.origin=dict(origin);self.phase='Armed';self.entry=self.branch=self.returned=None;self.continues=0;self.rows=[];self.reason=None;self.nativeReadback=None
 def args(self):
  return {'q129':[self.root,129],'q130':[self.root,130],'alloc':[self.root,129,self.typeptr],'realloc':[self.root,self.pointer,130,self.typeptr],'free':[self.root,self.pointer]}[self.kind]
 def record(self,kind,**fields):
  if len(self.rows)>=16:raise ValueError('Per-call row bound')
  self.rows.append(dict(seq=len(self.rows)+1,kind=kind,observationSource='Manual actual stopped native frame; not auto tap',**fields))
 def require_frame(self,c,pc,sp=None):
  if c['pid']!=self.pid or c['tid']!=self.tid or c['pc']!=pc or not c['ownBreakpointHit'] or (sp is not None and c['sp']!=sp):raise ValueError('Exact stopped frame/own breakpoint mismatch')
 def entry_at(self,c):
  if self.phase!='Armed':raise ValueError('Unexpected entry')
  self.require_frame(c,self.base+OFFSETS[self.kind])
  if c['args']!=self.args() or not 0<c['lr']<2**53 or c['lr']%4 or c['sp']<=0 or c['sp']%16:raise ValueError('Entry args/SP/LR mismatch')
  self.entry=dict(c);self.phase='Entry';self.record('native-entry',**c)
 def authorize(self,c,phase):
  if phase=='native':
   if self.phase!='Entry' or self.continues!=0:raise ValueError('Native continue out of order')
   self.require_frame(c,self.entry['pc'],self.entry['sp'])
   if c['lr']!=self.entry['lr'] or c['args']!=self.entry['args']:raise ValueError('Entry changed')
   self.phase='NativeRunning'
  elif phase=='branch':
   if self.kind!='realloc' or self.phase!='Branch' or self.continues!=1:raise ValueError('Branch continue out of order')
   self.require_frame(c,self.branch['pc'],self.branch['sp'])
   if c['branchArgs']!=self.branch['branchArgs']:raise ValueError('Branch state changed')
   self.phase='NativeRunningAfterBranch'
  elif phase=='jit':
   want=2 if self.kind=='realloc' else 1
   if self.phase!='Return' or self.continues!=want or self.nativeReadback!=self.returned['value']:raise ValueError('JIT completion before real returned witness/readback')
   self.require_frame(c,self.returned['pc'],self.returned['sp']);self.phase='JITRunning'
  else:raise ValueError('Unknown bounded continuation')
  self.continues+=1
  if self.continues>(3 if self.kind=='realloc' else 2):raise ValueError('Continuation cap')
  self.record('top-level-continue-authorized',purpose=phase,count=self.continues)
 def branch_at(self,c):
  if self.kind!='realloc' or self.phase!='NativeRunning':raise ValueError('Unexpected branch stop')
  self.require_frame(c,self.base+BRANCH,self.entry['sp']-192)
  expected=dict(result=1,old=self.pointer,requested=130,callerRoot=self.root,slotRoot=self.root)
  if c['branchArgs']!=expected:raise ValueError('In-place helper did not return true with known root/pointer/request')
  self.branch=dict(c);self.phase='Branch';self.record('inplace-helper-success-branch',**c)
 def return_at(self,c):
  if self.phase!=('NativeRunningAfterBranch' if self.kind=='realloc' else 'NativeRunning'):raise ValueError('Unexpected native return')
  self.require_frame(c,self.entry['lr'],self.entry['sp'])
  if self.kind in ('q129','q130') and c['value']!=136:raise ValueError('Fresh quantization is not136')
  if self.kind=='alloc' and (not 0<c['value']<2**53-130 or c['value']%8):raise ValueError('Allocation pointer outside admitted range/alignment')
  if self.kind=='realloc' and c['value']!=self.pointer:raise ValueError('Reallocation moved or failed; in-place unqualified')
  self.returned=dict(c);self.phase='Return';self.record('native-return',**c)
 def native_readback(self,value):
  if self.phase!='Return' or type(value) is not int or value!=self.returned['value']:raise ValueError('Actual returned register/no-JIT readback mismatch')
  self.nativeReadback=value;self.record('static-return-register-readback',value=value)
 def complete_at(self,c):
  if self.phase!='JITRunning' or any(c[k]!=self.origin[k] for k in ('pid','tid','pc','sp')) or not c['expressionPlanComplete']:raise ValueError('Original context/plan not restored')
  self.phase='OriginalContext';self.record('original-context-and-expression-plan-complete',**c)
 def persistent_readback(self,value):
  expected=1 if self.kind=='free' else self.returned['value']
  if self.phase!='OriginalContext' or type(value) is not int or value!=expected:raise ValueError('Original persistent expression result mismatch')
  self.phase='Pass';self.record('original-persistent-result',value=value)
 def report(self):return dict(kind=self.kind,phase=self.phase,reason=self.reason,pid=self.pid,tid=self.tid,base=self.base,root=self.root,typePointer=self.typeptr,ownedPointerBeforeCall=self.pointer,origin=self.origin,entry=self.entry,branch=self.branch,returned=self.returned,continues=self.continues,rows=self.rows)

class Suite:
 def __init__(self,pid,tid,base,root):
  self.pid,self.tid,self.base,self.root=pid,tid,base,root;self.pointer=None;self.calls=[];self.phase='Ready';self.reason=None;self.generation=0
 def new(self,kind,origin):
  if self.phase!='Ready' or len(self.calls)>=5 or kind!=KINDS[len(self.calls)]:raise ValueError('Only five ordered native calls permitted')
  c=Call(kind,self.pid,self.tid,self.base,self.root,self.base+0x974695b,self.pointer,origin);self.calls.append(c);self.phase='CallRunning';return c
 @property
 def current(self):return self.calls[-1]
 def finish(self,value):
  c=self.current;c.persistent_readback(value)
  if c.kind=='alloc':self.pointer=c.returned['value'];self.generation=1
  if c.kind=='free':self.pointer=None
  self.phase='Pass' if len(self.calls)==5 else 'Ready'
 def report(self):return dict(schema='raveldex-manual-inplace-control-v1',phase=self.phase,reason=self.reason,pid=self.pid,tid=self.tid,base=self.base,root=self.root,pointer=self.pointer,generation=self.generation,totalContinues=sum(c.continues for c in self.calls),calls=[c.report() for c in self.calls],autoObserverCallbackQualification=False,scope='Manual actual native entry/branch/return and original expression result for one separately allocated129→130 requested-byte control, plus explicit free. No product buffer change, global/physical/copy-total claim or synthetic auto tap events.')

def f(debugger):return debugger.GetSelectedTarget().GetProcess().GetSelectedThread().GetFrameAtIndex(0)
def paused(debugger):
 if not rx.INSTALLED or not rx.ACTIVE or rx.INVALID or rx.DROPPED or rx.LABEL!='manual-inplace' or any(rx.CALLS.values()) or rx.LIVE:raise RuntimeError('Require valid active drained manual-inplace window')
 p=debugger.GetSelectedTarget().GetProcess()
 if p.GetProcessID()!=rx.CONFIG['pid'] or p.GetState()!=lldb.eStateStopped:raise RuntimeError('Wrong paused owned process')
 frame=f(debugger)
 if frame.GetThread().GetThreadID()!=rx.CONFIG['mainTid']:raise RuntimeError('Wrong trace-proven main thread')
 return frame
def ctx(frame,bp):
 t=frame.GetThread();data=[t.GetStopReasonDataAtIndex(i) for i in range(t.GetStopReasonDataCount())]
 return dict(pid=t.GetProcess().GetProcessID(),tid=t.GetThreadID(),pc=frame.GetPC(),sp=rx.reg(frame,'sp'),lr=rx.reg(frame,'lr'),stopReason=t.GetStopReason(),stopReasonData=data,ownBreakpointHit=t.GetStopReason()==lldb.eStopReasonBreakpoint and any(data[i]==bp.GetID() for i in range(0,len(data),2)))
def bp(address):
 b=rx.TARGET.BreakpointCreateByAddress(address);b.SetThreadID(CONTROL.tid)
 if b.GetNumLocations()!=1 or b.GetThreadID()!=CONTROL.tid:raise RuntimeError('Unresolved exact TID breakpoint')
 return b
def args(frame):return [rx.reg(frame,'x'+str(i)) for i in range(len(CONTROL.current.args()))]
def branch_args(frame):return dict(result=rx.reg(frame,'x0')&1,old=rx.reg(frame,'x20'),requested=rx.reg(frame,'x21'),callerRoot=rx.reg(frame,'x19'),slotRoot=rx.reg(frame,'x23'))
def refuse(error,result):
 if CONTROL:
  CONTROL.phase='Refused';CONTROL.reason=str(error)
  if CONTROL.calls:CONTROL.current.phase='Refused';CONTROL.current.reason=str(error)
 result.SetError(str(error))
def start(debugger,command,result,_):
 global CONTROL,ENTRY_BP
 try:
  frame=paused(debugger);kind=command.strip()
  if CONTROL is None:
   if kind!='q129':raise RuntimeError('First call must q129')
   roots={r['root'] for r in rx.ROWS if r['kind']=='realloc-enter'}
   if len(roots)!=1:raise RuntimeError('One freshly observed serializer root required')
   CONTROL=Suite(rx.CONFIG['pid'],rx.CONFIG['mainTid'],rx.BASE,roots.pop())
  if ENTRY_BP is not None:raise RuntimeError('Prior owned probe not removed')
  manifest=json.loads((ROOT/'inplace-manifest.json').read_text());process=rx.TARGET.GetProcess()
  for site in manifest['sites']:
   expected=bytes.fromhex(site['bytes']);error=lldb.SBError();raw=process.ReadMemory(CONTROL.base+site['offset'],len(expected),error)
   if error.Fail() or raw!=expected:raise RuntimeError('In-place code fingerprint mismatch')
  origin=dict(pid=CONTROL.pid,tid=CONTROL.tid,pc=frame.GetPC(),sp=rx.reg(frame,'sp'));call=CONTROL.new(kind,origin);ENTRY_BP=bp(CONTROL.base+OFFSETS[kind])
  values=','.join(str(x) for x in call.args());types=','.join('unsigned long' for _ in call.args());resultType='void' if kind=='free' else 'unsigned long';invoke='((%s(*)(%s))%d)(%s)'%(resultType,types,CONTROL.base+OFFSETS[kind],values)
  expression='unsigned long $rx_control_%s = %s'%(kind,('('+invoke+',1UL)') if kind=='free' else invoke)
  result.PutCString(json.dumps(dict(command='expression --ignore-breakpoints false --unwind-on-error false --all-threads false --timeout 5000000 --language c++ -- '+expression,entryBreakpointId=ENTRY_BP.GetID(),state=CONTROL.report())))
 except Exception as error:refuse(error,result)
def entry(debugger,command,result,_):
 global RETURN_BP,BRANCH_BP
 try:
  if command.strip()!='actual':raise RuntimeError('Require actual stopped entry')
  frame=paused(debugger);c=ctx(frame,ENTRY_BP);c['args']=args(frame);CONTROL.current.entry_at(c);RETURN_BP=bp(c['lr'])
  if CONTROL.current.kind=='realloc':BRANCH_BP=bp(CONTROL.base+BRANCH)
  result.PutCString(json.dumps(CONTROL.current.report()))
 except Exception as error:refuse(error,result)
def authorize(debugger,command,result,_):
 global RETURN_BP,BRANCH_BP
 try:
  phase=command.strip();frame=paused(debugger);which=ENTRY_BP if phase=='native' else BRANCH_BP if phase=='branch' else RETURN_BP;c=ctx(frame,which)
  if phase=='native':c['args']=args(frame)
  elif phase=='branch':c['branchArgs']=branch_args(frame)
  CONTROL.current.authorize(c,phase)
  if phase=='branch':rx.TARGET.BreakpointDelete(BRANCH_BP.GetID());BRANCH_BP=None
  if phase=='jit':rx.TARGET.BreakpointDelete(RETURN_BP.GetID());RETURN_BP=None
  result.PutCString(json.dumps(CONTROL.current.report()))
 except Exception as error:refuse(error,result)
def branch(debugger,command,result,_):
 try:
  if command.strip()!='actual':raise RuntimeError('Require actual branch stop')
  frame=paused(debugger);c=ctx(frame,BRANCH_BP);c['branchArgs']=branch_args(frame);CONTROL.current.branch_at(c);result.PutCString(json.dumps(CONTROL.current.report()))
 except Exception as error:refuse(error,result)
def returned(debugger,command,result,_):
 try:
  if command.strip()!='actual':raise RuntimeError('Require actual native return')
  frame=paused(debugger);c=ctx(frame,RETURN_BP);c['value']=rx.reg(frame,'x0');CONTROL.current.return_at(c);result.PutCString(json.dumps(CONTROL.current.report()))
 except Exception as error:refuse(error,result)
def register_readback(debugger,command,result,_):
 try:paused(debugger);CONTROL.current.native_readback(int(command));result.PutCString('RX_CONTROL_RETURN_READBACK_VERIFIED')
 except Exception as error:refuse(error,result)
def completion(debugger,command,result,_):
 try:
  if command.strip()!='actual':raise RuntimeError('Require actual completed original context')
  frame=paused(debugger);t=frame.GetThread();CONTROL.current.complete_at(dict(pid=t.GetProcess().GetProcessID(),tid=t.GetThreadID(),pc=frame.GetPC(),sp=rx.reg(frame,'sp'),expressionPlanComplete=t.GetStopReason()==lldb.eStopReasonPlanComplete));result.PutCString(json.dumps(CONTROL.current.report()))
 except Exception as error:refuse(error,result)
def persistent_readback(debugger,command,result,_):
 global ENTRY_BP
 try:
  paused(debugger);CONTROL.finish(int(command));rx.TARGET.BreakpointDelete(ENTRY_BP.GetID());ENTRY_BP=None;result.PutCString(json.dumps(CONTROL.report()))
 except Exception as error:refuse(error,result)
def status(debugger,command,result,_):result.PutCString(json.dumps(CONTROL.report() if CONTROL else {'phase':'Not initialized'}))
def save(debugger,command,result,_):
 try:
  if command.strip()!='new-receipt' or CONTROL is None:raise RuntimeError('Require explicit new-receipt')
  data=CONTROL.report();data.update(sourceSha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),observerSha256=hashlib.sha256((ROOT/'lldb_native_tap.py').read_bytes()).hexdigest(),manifestSha256=hashlib.sha256((ROOT/'inplace-manifest.json').read_bytes()).hexdigest(),savedUnix=time.time())
  path=rx.OUT/'manual-inplace.json'
  with path.open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
  result.PutCString('RX_CONTROL_SAVED '+str(path))
 except Exception as error:result.SetError(str(error))
def cleanup(debugger,command,result,_):
 global ENTRY_BP,RETURN_BP,BRANCH_BP
 for b in (ENTRY_BP,RETURN_BP,BRANCH_BP):
  if b is not None:rx.TARGET.BreakpointDelete(b.GetID())
 ENTRY_BP=RETURN_BP=BRANCH_BP=None;result.PutCString('RX_CONTROL_PROBE_HOOKS_REMOVED')
def __lldb_init_module(debugger,_):
 for name,fn in [('start','start'),('entry','entry'),('authorize','authorize'),('branch','branch'),('return','returned'),('register','register_readback'),('completion','completion'),('readback','persistent_readback'),('status','status'),('save','save'),('cleanup','cleanup')]:debugger.HandleCommand('command script add -f manual_inplace.'+fn+' rx-control-'+name)
