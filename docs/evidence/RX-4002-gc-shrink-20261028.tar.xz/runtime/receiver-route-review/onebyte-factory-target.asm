
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100045adc <_cxxbridge1$slice$new>:
10037dd00: d10143ff    	sub	sp, sp, #0x50
10037dd04: a9015ff8    	stp	x24, x23, [sp, #0x10]
10037dd08: a90257f6    	stp	x22, x21, [sp, #0x20]
10037dd0c: a9034ff4    	stp	x20, x19, [sp, #0x30]
10037dd10: a9047bfd    	stp	x29, x30, [sp, #0x40]
10037dd14: 910103fd    	add	x29, sp, #0x40
10037dd18: aa0003f5    	mov	x21, x0
10037dd1c: d35ffc48    	lsr	x8, x2, #31
10037dd20: b50006c8    	cbnz	x8, 0x10037ddf8 <_cxxbridge1$slice$new+0x33831c>
10037dd24: aa0303f6    	mov	x22, x3
10037dd28: aa0203f3    	mov	x19, x2
10037dd2c: aa0103f4    	mov	x20, x1
10037dd30: 910013e0    	add	x0, sp, #0x4
10037dd34: 94000045    	bl	0x10037de48 <_cxxbridge1$slice$new+0x33836c>
10037dd38: b9400fe1    	ldr	w1, [sp, #0xc]
10037dd3c: 340003a1    	cbz	w1, 0x10037ddb0 <_cxxbridge1$slice$new+0x3382d4>
10037dd40: 394013e8    	ldrb	w8, [sp, #0x4]
10037dd44: 7100051f    	cmp	w8, #0x1
10037dd48: 540003c8    	b.hi	0x10037ddc0 <_cxxbridge1$slice$new+0x3382e4>
10037dd4c: 7100043f    	cmp	w1, #0x1
10037dd50: 54000660    	b.eq	0x10037de1c <_cxxbridge1$slice$new+0x338340>
10037dd54: 510016d7    	sub	w23, w22, #0x5
10037dd58: aa1503e0    	mov	x0, x21
10037dd5c: aa1603e2    	mov	x2, x22
10037dd60: d2800003    	mov	x3, #0x0                ; =0
10037dd64: 97fab160    	bl	0x10022a2e4 <_cxxbridge1$slice$new+0x1e4808>
10037dd68: aa0003f5    	mov	x21, x0
10037dd6c: b40000e0    	cbz	x0, 0x10037dd88 <_cxxbridge1$slice$new+0x3382ac>
10037dd70: f94002a8    	ldr	x8, [x21]
10037dd74: 910013e0    	add	x0, sp, #0x4
10037dd78: 91002d01    	add	x1, x8, #0xb
10037dd7c: aa1403e2    	mov	x2, x20
10037dd80: aa1303e3    	mov	x3, x19
10037dd84: 940000ef    	bl	0x10037e140 <_cxxbridge1$slice$new+0x338664>
10037dd88: 12001ee8    	and	w8, w23, #0xff
10037dd8c: 7100091f    	cmp	w8, #0x2
10037dd90: 54000149    	b.ls	0x10037ddb8 <_cxxbridge1$slice$new+0x3382dc>
10037dd94: aa1503e0    	mov	x0, x21
10037dd98: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10037dd9c: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10037dda0: a94257f6    	ldp	x22, x21, [sp, #0x20]
10037dda4: a9415ff8    	ldp	x24, x23, [sp, #0x10]
10037dda8: 910143ff    	add	sp, sp, #0x50
10037ddac: d65f03c0    	ret
10037ddb0: 910e82b5    	add	x21, x21, #0x3a0
10037ddb4: 17fffff8    	b	0x10037dd94 <_cxxbridge1$slice$new+0x3382b8>
10037ddb8: d5033bbf    	dmb	ish
10037ddbc: 17fffff6    	b	0x10037dd94 <_cxxbridge1$slice$new+0x3382b8>
10037ddc0: 510016d7    	sub	w23, w22, #0x5
10037ddc4: aa1503e0    	mov	x0, x21
10037ddc8: aa1603e2    	mov	x2, x22
10037ddcc: d2800003    	mov	x3, #0x0                ; =0
10037ddd0: 97f26d7f    	bl	0x1000193cc <__text+0x153cc>
10037ddd4: aa0003f5    	mov	x21, x0
10037ddd8: b4fffd80    	cbz	x0, 0x10037dd88 <_cxxbridge1$slice$new+0x3382ac>
10037dddc: f94002a8    	ldr	x8, [x21]
10037dde0: 910013e0    	add	x0, sp, #0x4
10037dde4: 91002d01    	add	x1, x8, #0xb
10037dde8: aa1403e2    	mov	x2, x20
10037ddec: aa1303e3    	mov	x3, x19
10037ddf0: 94d9cd88    	bl	0x1039f1410 <_llg_tokenize_bytes+0x51574>
10037ddf4: 17ffffe5    	b	0x10037dd88 <_cxxbridge1$slice$new+0x3382ac>
10037ddf8: aa1503e0    	mov	x0, x21
10037ddfc: 94e429c2    	bl	0x103c88504 <__v8_internal_Print_TransitionTree+0x3fb1c>
10037de00: f9400001    	ldr	x1, [x0]
10037de04: aa1503e0    	mov	x0, x21
10037de08: d2800002    	mov	x2, #0x0                ; =0
10037de0c: 52800003    	mov	w3, #0x0                ; =0
10037de10: 9417c3e0    	bl	0x10096ed90 <_rust_png$cxxbridge1$199$Reader$interlaced+0xb6b50>
10037de14: d2800015    	mov	x21, #0x0               ; =0
10037de18: 17ffffdf    	b	0x10037dd94 <_cxxbridge1$slice$new+0x3382b8>
10037de1c: 910013e0    	add	x0, sp, #0x4
10037de20: 91000fe1    	add	x1, sp, #0x3
10037de24: aa1403e2    	mov	x2, x20
10037de28: aa1303e3    	mov	x3, x19
10037de2c: 940000c5    	bl	0x10037e140 <_cxxbridge1$slice$new+0x338664>
10037de30: 39400fe1    	ldrb	w1, [sp, #0x3]
10037de34: aa1503e0    	mov	x0, x21
10037de38: 97f9fe04    	bl	0x1001fd648 <_cxxbridge1$slice$new+0x1b7b6c>
10037de3c: aa0003f5    	mov	x21, x0
10037de40: 17ffffd5    	b	0x10037dd94 <_cxxbridge1$slice$new+0x3382b8>
10037de44: 00000000    	udf	#0x0
10037de48: 3900001f    	strb	wzr, [x0]
10037de4c: d35ffc48    	lsr	x8, x2, #31
10037de50: b5000de8    	cbnz	x8, 0x10037e00c <_cxxbridge1$slice$new+0x338530>
10037de54: 8b020028    	add	x8, x1, x2
10037de58: aa0103e9    	mov	x9, x1
10037de5c: f100205f    	cmp	x2, #0x8
10037de60: 54000202    	b.hs	0x10037dea0 <_cxxbridge1$slice$new+0x3383c4>
10037de64: eb08013f    	cmp	x9, x8
10037de68: 54000122    	b.hs	0x10037de8c <_cxxbridge1$slice$new+0x3383b0>
10037de6c: 8b01004a    	add	x10, x2, x1
10037de70: cb09014a    	sub	x10, x10, x9
10037de74: 39c0012b    	ldrsb	w11, [x9]
10037de78: 37f800ab    	tbnz	w11, #0x1f, 0x10037de8c <_cxxbridge1$slice$new+0x3383b0>
10037de7c: 91000529    	add	x9, x9, #0x1
10037de80: f100054a    	subs	x10, x10, #0x1
10037de84: 54ffff81    	b.ne	0x10037de74 <_cxxbridge1$slice$new+0x338398>
10037de88: 8b010049    	add	x9, x2, x1
10037de8c: cb010129    	sub	x9, x9, x1
10037de90: 6b02013f    	cmp	w9, w2
10037de94: 2900a409    	stp	w9, w9, [x0, #0x4]
10037de98: 540006e1    	b.ne	0x10037df74 <_cxxbridge1$slice$new+0x338498>
10037de9c: d65f03c0    	ret
10037dea0: f240082a    	ands	x10, x1, #0x7
10037dea4: 54000640    	b.eq	0x10037df6c <_cxxbridge1$slice$new+0x338490>
10037dea8: 39c0002b    	ldrsb	w11, [x1]
10037deac: aa0103e9    	mov	x9, x1
10037deb0: 37fffeeb    	tbnz	w11, #0x1f, 0x10037de8c <_cxxbridge1$slice$new+0x3383b0>
10037deb4: cb0a0029    	sub	x9, x1, x10
10037deb8: 91002129    	add	x9, x9, #0x8
10037debc: 9100042a    	add	x10, x1, #0x1
10037dec0: f240095f    	tst	x10, #0x7
10037dec4: 54000420    	b.eq	0x10037df48 <_cxxbridge1$slice$new+0x33846c>
10037dec8: 39c0014a    	ldrsb	w10, [x10]
10037decc: 37f80a6a    	tbnz	w10, #0x1f, 0x10037e018 <_cxxbridge1$slice$new+0x33853c>
10037ded0: 9100082a    	add	x10, x1, #0x2
10037ded4: f240095f    	tst	x10, #0x7
10037ded8: 54000380    	b.eq	0x10037df48 <_cxxbridge1$slice$new+0x33846c>
10037dedc: 39c0014a    	ldrsb	w10, [x10]
10037dee0: 37f80a0a    	tbnz	w10, #0x1f, 0x10037e020 <_cxxbridge1$slice$new+0x338544>
10037dee4: 91000c2a    	add	x10, x1, #0x3
10037dee8: f240095f    	tst	x10, #0x7
10037deec: 540002e0    	b.eq	0x10037df48 <_cxxbridge1$slice$new+0x33846c>
10037def0: 39c0014a    	ldrsb	w10, [x10]
10037def4: 37f809aa    	tbnz	w10, #0x1f, 0x10037e028 <_cxxbridge1$slice$new+0x33854c>
10037def8: 9100102a    	add	x10, x1, #0x4
10037defc: f240095f    	tst	x10, #0x7
10037df00: 54000240    	b.eq	0x10037df48 <_cxxbridge1$slice$new+0x33846c>
10037df04: 39c0014a    	ldrsb	w10, [x10]
10037df08: 37f8094a    	tbnz	w10, #0x1f, 0x10037e030 <_cxxbridge1$slice$new+0x338554>
10037df0c: 9100142a    	add	x10, x1, #0x5
10037df10: f240095f    	tst	x10, #0x7
10037df14: 540001a0    	b.eq	0x10037df48 <_cxxbridge1$slice$new+0x33846c>
10037df18: 39c0014a    	ldrsb	w10, [x10]
10037df1c: 37f808ea    	tbnz	w10, #0x1f, 0x10037e038 <_cxxbridge1$slice$new+0x33855c>
10037df20: 9100182a    	add	x10, x1, #0x6
10037df24: f240095f    	tst	x10, #0x7
10037df28: 54000100    	b.eq	0x10037df48 <_cxxbridge1$slice$new+0x33846c>
10037df2c: 39c0014a    	ldrsb	w10, [x10]
10037df30: 37f8088a    	tbnz	w10, #0x1f, 0x10037e040 <_cxxbridge1$slice$new+0x338564>
10037df34: 91001c2a    	add	x10, x1, #0x7
10037df38: f240095f    	tst	x10, #0x7
10037df3c: 54000060    	b.eq	0x10037df48 <_cxxbridge1$slice$new+0x33846c>
10037df40: 39c0014a    	ldrsb	w10, [x10]
10037df44: 37f8082a    	tbnz	w10, #0x1f, 0x10037e048 <_cxxbridge1$slice$new+0x33856c>
10037df48: 9100212a    	add	x10, x9, #0x8
10037df4c: eb08015f    	cmp	x10, x8
10037df50: 54fff8a8    	b.hi	0x10037de64 <_cxxbridge1$slice$new+0x338388>
10037df54: f940012b    	ldr	x11, [x9]
10037df58: aa0a03e9    	mov	x9, x10
10037df5c: 9201c16b    	and	x11, x11, #0x8080808080808080
