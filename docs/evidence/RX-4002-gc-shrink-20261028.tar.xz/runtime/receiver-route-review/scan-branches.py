from pathlib import Path
import struct,json,hashlib,time
b=Path('/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell');raw=b.read_bytes();magic,cpu,sub,typ,ncmd,sz,flags,res=struct.unpack_from('<8I',raw);assert magic==0xfeedfacf;pos=32;sections=[]
for _ in range(ncmd):
 cmd,size=struct.unpack_from('<2I',raw,pos)
 if cmd==0x19:
  seg=struct.unpack_from('<II16sQQQQIIII',raw,pos);sectpos=pos+72
  for i in range(seg[9]):
   s=struct.unpack_from('<16s16sQQIIIIIIII',raw,sectpos+80*i);sections.append({'name':s[0].rstrip(b'\0').decode(),'seg':s[1].rstrip(b'\0').decode(),'vma':s[2],'size':s[3],'fileOffset':s[4]})
 pos+=size
text=next(s for s in sections if s['name']=='__text');targets={0x103de2aa8:'two-byte-source-candidate',0x103de29a8:'utf8-source-candidate'};hits=[];v=memoryview(raw)[text['fileOffset']:text['fileOffset']+text['size']].cast('I');start=time.time()
for i,w in enumerate(v):
 if w&0x7c000000==0x14000000:
  imm=w&0x3ffffff
  if imm&0x2000000:imm-=0x4000000
  pc=text['vma']+4*i;dest=pc+imm*4
  if dest in targets:hits.append({'pc':hex(pc),'moduleOffset':hex(pc-0x100000000),'target':hex(dest),'kind':'BL' if w&0x80000000 else 'B','instruction':hex(w),'label':targets[dest]})
p=Path(__file__).parent/'branch-xrefs.json';p.write_text(json.dumps({'binarySha256':hashlib.sha256(raw).hexdigest(),'textSection':text,'method':'Exhaustive alignedAArch64B/BLimmediate decoding over declared__textsection; no indirect/jumptablexrefcoverage','elapsedSeconds':time.time()-start,'hits':hits},indent=2)+'\n');print(json.dumps(hits))
