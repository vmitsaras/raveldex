# Proposed read-only two-byte receiver hook

Static packet: `receiver-route-proof.json`; selected route is tag99 `c` → dispatch module166c968 → call166c96c → function3de2aa8 → memcpy call3de2b48 / return3de2b4c. Fingerprints include exact352-byte readfunction and48-byte copy neighborhood. No live coverage is established here.

Prefer three bounded callback points:

1. Function entry `base+0x3de2aa8`: accept only owned renderer, trace-proven main/worker TID, and actual LR `base+0x166c970`. Save this=x0, entrySP/LR, incoming position/end from bounded16-byte read at this+16. Keep one bounded stack record per TID; refuse duplicates/overflow. Other contexts remain explicitly unqualified.
2. Copy CALL instruction `base+0x3de2b48`: match pending function/TID and SP=entrySP-64; x19=this; x1=x23; x2=x21>0 and even; source slice fits current known wire allocation/generation with an already decoded protocol binding. Check deserializerposition==src+n<=end using bounded header reads. Destination=x0=(*x22)+11, where x22 is the successful factory handle. Read only handle/header metadata, never string content. A source without a known live wire generation/binding is Unbound and cannot be attributed to product operation/message. Do not create fake source births.
3. Copy return `base+0x3de2b4c`: sameTID/SP, exact expected call/returnPC/LR and x0==savedDest. Record a selected actual receiver string copy, binding its source generation/session/id/operation/direction. Track a function return to actual saved LR166c970 / entrySP to verify returned factory handle if that additional check is enabled. No target expression or manual continuation is necessary; callbacks returnFalse under ordinary publicJS execution.

Keep these receiver observations separate from native serializer `LIVE` destination allocations. A managed string destination is not a native wire buffer. Without a calibrated heap/header interpretation, record its actual pointer/copy count only, not a new managed occupied extent or physical allocation. RawTwoByteString source/controlflow explains expected representation but concrete live type/map still needs corroboration before richer assertions.

Pairing and pending registries need their own finite bounds (or reuse existing bounded per-TID call stacks with distinct kinds), and every unmatched frame, overflow or dropped row invalidates the selected observation window. Existing hooks remain armed. Do not treat a zero-hit run as a successful two-byte calibration, and do not change the ASCII product corpus merely to force a string path. A separately labeled ordinaryJS Unicode control can prove this route under existing user authorization; its result stays separate from product matrix evidence.

The one-byte route is different: tag34 → call166c22c → factory5212c8; larger strings copy inline from copyfrontier521388. Empty and single-character routes bypass that copy. This packet does not propose adding that second hook in the first receiver slice.
