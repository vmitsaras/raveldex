
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100e59aa8 <_fontations_ffi$cxxbridge1$199$num_color_stops>:
10166bff0: f900967f    	str	xzr, [x19, #0x128]
10166bff4: f94006a8    	ldr	x8, [x21, #0x8]
10166bff8: aa1503e0    	mov	x0, x21
10166bffc: aa1403e1    	mov	x1, x20
10166c000: d63f0100    	blr	x8
10166c004: 12800008    	mov	w8, #-0x1               ; =-1
10166c008: b8e802a8    	ldaddal	w8, w8, [x21]
10166c00c: 7100051f    	cmp	w8, #0x1
10166c010: 54000081    	b.ne	0x10166c020 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812578>
10166c014: f9400aa8    	ldr	x8, [x21, #0x10]
10166c018: aa1503e0    	mov	x0, x21
10166c01c: d63f0100    	blr	x8
10166c020: a9437bfd    	ldp	x29, x30, [sp, #0x30]
10166c024: a9424ff4    	ldp	x20, x19, [sp, #0x20]
10166c028: a94157f6    	ldp	x22, x21, [sp, #0x10]
10166c02c: 910103ff    	add	sp, sp, #0x40
10166c030: d65f03c0    	ret
10166c034: 12801134    	mov	w20, #-0x8a             ; =-138
10166c038: 17ffffde    	b	0x10166bfb0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812508>
10166c03c: 12800eb4    	mov	w20, #-0x76             ; =-118
10166c040: 17ffffdc    	b	0x10166bfb0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812508>
10166c044: 12800cf4    	mov	w20, #-0x68             ; =-104
10166c048: 17ffffda    	b	0x10166bfb0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812508>
10166c04c: d4200000    	brk	#0
10166c050: d4400000    	hlt	#0
10166c054: d4200020    	brk	#0x1
10166c058: d4200000    	brk	#0
10166c05c: d4400000    	hlt	#0
10166c060: d4200020    	brk	#0x1
10166c064: a9412808    	ldp	x8, x10, [x0, #0x10]
10166c068: eb0a011f    	cmp	x8, x10
10166c06c: 540010c2    	b.hs	0x10166c284 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8127dc>
10166c070: d10283ff    	sub	sp, sp, #0xa0
10166c074: 6d0323e9    	stp	d9, d8, [sp, #0x30]
10166c078: a9046ffc    	stp	x28, x27, [sp, #0x40]
10166c07c: a90567fa    	stp	x26, x25, [sp, #0x50]
10166c080: a9065ff8    	stp	x24, x23, [sp, #0x60]
10166c084: a90757f6    	stp	x22, x21, [sp, #0x70]
10166c088: a9084ff4    	stp	x20, x19, [sp, #0x80]
10166c08c: a9097bfd    	stp	x29, x30, [sp, #0x90]
10166c090: 910243fd    	add	x29, sp, #0x90
10166c094: aa0003f3    	mov	x19, x0
10166c098: d2800009    	mov	x9, #0x0                ; =0
10166c09c: 8b09010b    	add	x11, x8, x9
10166c0a0: 38401561    	ldrb	w1, [x11], #0x1
10166c0a4: f9000a6b    	str	x11, [x19, #0x10]
10166c0a8: 7100bc3f    	cmp	w1, #0x2f
10166c0ac: 5400094d    	b.le	0x10166c1d4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81272c>
10166c0b0: 5100c02b    	sub	w11, w1, #0x30
10166c0b4: 7101397f    	cmp	w11, #0x4e
10166c0b8: 54005088    	b.hi	0x10166cac8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813020>
10166c0bc: b003b96c    	adrp	x12, 0x108d99000 <dyld_stub_binder+0x108d99000>
10166c0c0: 9117718c    	add	x12, x12, #0x5dc
10166c0c4: 1000008d    	adr	x13, 0x10166c0d4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81262c>
10166c0c8: 786b798e    	ldrh	w14, [x12, x11, lsl #1]
10166c0cc: 8b0e09ad    	add	x13, x13, x14, lsl #2
10166c0d0: d61f01a0    	br	x13
10166c0d4: 2a2803eb    	mvn	w11, w8
10166c0d8: 0b0a016a    	add	w10, w11, w10
10166c0dc: 4b09014a    	sub	w10, w10, w9
10166c0e0: f27d715f    	tst	x10, #0xfffffff8
10166c0e4: 54004660    	b.eq	0x10166c9b0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812f08>
10166c0e8: 8b090108    	add	x8, x8, x9
10166c0ec: fc401100    	ldur	d0, [x8, #0x1]
10166c0f0: 91002508    	add	x8, x8, #0x9
10166c0f4: f9000a68    	str	x8, [x19, #0x10]
10166c0f8: 1e602000    	fcmp	d0, d0
10166c0fc: 9e660008    	fmov	x8, d0
10166c100: d2efff09    	mov	x9, #0x7ff8000000000000 ; =9221120237041090560
10166c104: 9a886134    	csel	x20, x9, x8, vs
10166c108: 52800028    	mov	w8, #0x1                ; =1
10166c10c: 36004e48    	tbz	w8, #0x0, 0x10166cad4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81302c>
10166c110: 9e670280    	fmov	d0, x20
10166c114: f9400268    	ldr	x8, [x19]
10166c118: d2f83a09    	mov	x9, #-0x3e30000000000000 ; =-4481081629233643520
10166c11c: 9e670121    	fmov	d1, x9
10166c120: 1e612000    	fcmp	d0, d1
10166c124: 5400014b    	b.lt	0x10166c14c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126a4>
10166c128: b0041129    	adrp	x9, 0x109891000 <dyld_stub_binder+0x109891000>
10166c12c: fd408921    	ldr	d1, [x9, #0x110]
10166c130: 1e612000    	fcmp	d0, d1
10166c134: d2f00009    	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
10166c138: fa499284    	ccmp	x20, x9, #0x4, ls
10166c13c: 1e780009    	fcvtzs	w9, d0
10166c140: 1e620121    	scvtf	d1, w9
10166c144: 1e611400    	fccmp	d0, d1, #0x0, ne
10166c148: 54003980    	b.eq	0x10166c878 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812dd0>
10166c14c: aa0803e0    	mov	x0, x8
10166c150: 97a7388c    	bl	0x10003a380 <_cxxbridge1$str$ptr+0x794>
10166c154: f9400008    	ldr	x8, [x0]
10166c158: f8003114    	stur	x20, [x8, #0x3]
10166c15c: a9497bfd    	ldp	x29, x30, [sp, #0x90]
10166c160: a9484ff4    	ldp	x20, x19, [sp, #0x80]
10166c164: a94757f6    	ldp	x22, x21, [sp, #0x70]
10166c168: a9465ff8    	ldp	x24, x23, [sp, #0x60]
10166c16c: a94567fa    	ldp	x26, x25, [sp, #0x50]
10166c170: a9446ffc    	ldp	x28, x27, [sp, #0x40]
10166c174: 6d4323e9    	ldp	d9, d8, [sp, #0x30]
10166c178: 910283ff    	add	sp, sp, #0xa0
10166c17c: d65f03c0    	ret
10166c180: aa1303e0    	mov	x0, x19
10166c184: 94000393    	bl	0x10166cfd0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813528>
10166c188: 36004a60    	tbz	w0, #0x0, 0x10166cad4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81302c>
10166c18c: f9400268    	ldr	x8, [x19]
10166c190: 52a80009    	mov	w9, #0x40000000         ; =1073741824
10166c194: 8b808129    	add	x9, x9, x0, asr #32
10166c198: d35ffd29    	lsr	x9, x9, #31
10166c19c: b50050c9    	cbnz	x9, 0x10166cbb4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81310c>
10166c1a0: 9360fc09    	asr	x9, x0, #32
10166c1a4: d37ff921    	lsl	x1, x9, #1
10166c1a8: f9411500    	ldr	x0, [x8, #0x228]
10166c1ac: f9411909    	ldr	x9, [x8, #0x230]
10166c1b0: eb09001f    	cmp	x0, x9
10166c1b4: 54003660    	b.eq	0x10166c880 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812dd8>
10166c1b8: 91002009    	add	x9, x0, #0x8
10166c1bc: f9011509    	str	x9, [x8, #0x228]
10166c1c0: f9000001    	str	x1, [x0]
10166c1c4: 17ffffe6    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c1c8: f9400268    	ldr	x8, [x19]
10166c1cc: 910e2100    	add	x0, x8, #0x388
10166c1d0: 17ffffe3    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c1d4: 7100883f    	cmp	w1, #0x22
10166c1d8: 54003fa1    	b.ne	0x10166c9cc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812f24>
10166c1dc: 8b09010c    	add	x12, x8, x9
10166c1e0: 9100198b    	add	x11, x12, #0x6
10166c1e4: eb0a017f    	cmp	x11, x10
10166c1e8: 54000262    	b.hs	0x10166c234 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81278c>
10166c1ec: 3940058a    	ldrb	w10, [x12, #0x1]
10166c1f0: 9100098c    	add	x12, x12, #0x2
10166c1f4: f9000a6c    	str	x12, [x19, #0x10]
10166c1f8: 3738024a    	tbnz	w10, #0x7, 0x10166c240 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812798>
10166c1fc: 52800028    	mov	w8, #0x1                ; =1
10166c200: aa0a8100    	orr	x0, x8, x10, lsl #32
10166c204: 36004680    	tbz	w0, #0x0, 0x10166cad4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81302c>
10166c208: d360fc02    	lsr	x2, x0, #32
10166c20c: a9412261    	ldp	x1, x8, [x19, #0x10]
10166c210: cb010108    	sub	x8, x8, x1
10166c214: eb08005f    	cmp	x2, x8
10166c218: 540045e8    	b.hi	0x10166cad4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81302c>
10166c21c: 8b020028    	add	x8, x1, x2
10166c220: f9000a68    	str	x8, [x19, #0x10]
10166c224: f9400260    	ldr	x0, [x19]
10166c228: 52800003    	mov	w3, #0x0                ; =0
10166c22c: 97bad427    	bl	0x1005212c8 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x152148>
10166c230: 17ffffcb    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c234: aa1303e0    	mov	x0, x19
10166c238: 97fb2832    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
10166c23c: 17fffff2    	b	0x10166c204 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81275c>
10166c240: 1200194a    	and	w10, w10, #0x7f
10166c244: 39c0018f    	ldrsb	w15, [x12]
10166c248: 8b09010c    	add	x12, x8, x9
10166c24c: 91000d8d    	add	x13, x12, #0x3
