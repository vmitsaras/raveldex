
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100e59aa8 <_fontations_ffi$cxxbridge1$199$num_color_stops>:
10166c500: 71203d1f    	cmp	w8, #0x80f
10166c504: 54001e60    	b.eq	0x10166c8d0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812e28>
10166c508: b4003ce9    	cbz	x9, 0x10166cca4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8131fc>
10166c50c: 383b6a98    	strb	w24, [x20, x27]
10166c510: b9402268    	ldr	w8, [x19, #0x20]
10166c514: 7100291f    	cmp	w8, #0xa
10166c518: 54003be9    	b.ls	0x10166cc94 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8131ec>
10166c51c: eb1a02df    	cmp	x22, x26
10166c520: 54003ea2    	b.hs	0x10166ccf4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81324c>
10166c524: f94002e8    	ldr	x8, [x23]
10166c528: d1000508    	sub	x8, x8, #0x1
10166c52c: f9400123    	ldr	x3, [x9]
10166c530: 8b160909    	add	x9, x8, x22, lsl #2
10166c534: b9000923    	str	w3, [x9, #0x8]
10166c538: 3607fa43    	tbz	w3, #0x0, 0x10166c480 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8129d8>
10166c53c: 926eb501    	and	x1, x8, #0xfffffffffffc0000
10166c540: 3940002a    	ldrb	w10, [x1]
10166c544: 3617f9ea    	tbz	w10, #0x2, 0x10166c480 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8129d8>
10166c548: 926eb464    	and	x4, x3, #0xfffffffffffc0000
10166c54c: 3940008a    	ldrb	w10, [x4]
10166c550: 360ff98a    	tbz	w10, #0x1, 0x10166c480 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8129d8>
10166c554: b2400100    	orr	x0, x8, #0x1
10166c558: 91002122    	add	x2, x9, #0x8
10166c55c: 97a79619    	bl	0x100051dc0 <_cxxbridge1$slice$new+0xc2e4>
10166c560: 17ffffc8    	b	0x10166c480 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8129d8>
10166c564: f9400268    	ldr	x8, [x19]
10166c568: 910de100    	add	x0, x8, #0x378
10166c56c: 17fffefc    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c570: 1200194a    	and	w10, w10, #0x7f
10166c574: 39c0052c    	ldrsb	w12, [x9, #0x1]
10166c578: 9100092b    	add	x11, x9, #0x2
10166c57c: f9000a6b    	str	x11, [x19, #0x10]
10166c580: 53191d8b    	ubfiz	w11, w12, #7, #8
10166c584: 37f84d4c    	tbnz	w12, #0x1f, 0x10166cf2c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813484>
10166c588: 2a0a0168    	orr	w8, w11, w10
10166c58c: 52800029    	mov	w9, #0x1                ; =1
10166c590: aa088128    	orr	x8, x9, x8, lsl #32
10166c594: 14000011    	b	0x10166c5d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812b30>
10166c598: f9400274    	ldr	x20, [x19]
10166c59c: f90017f4    	str	x20, [sp, #0x28]
10166c5a0: 97a6ac53    	bl	0x1000176ec <__text+0x136ec>
10166c5a4: f9401288    	ldr	x8, [x20, #0x20]
10166c5a8: eb08001f    	cmp	x0, x8
10166c5ac: 54004143    	b.lo	0x10166cdd4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81332c>
10166c5b0: a9412a69    	ldp	x9, x10, [x19, #0x10]
10166c5b4: 91001528    	add	x8, x9, #0x5
10166c5b8: eb0a011f    	cmp	x8, x10
10166c5bc: 54004142    	b.hs	0x10166cde4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81333c>
10166c5c0: aa0903eb    	mov	x11, x9
10166c5c4: 3840156a    	ldrb	w10, [x11], #0x1
10166c5c8: f9000a6b    	str	x11, [x19, #0x10]
10166c5cc: 373ffd2a    	tbnz	w10, #0x7, 0x10166c570 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812ac8>
10166c5d0: 52800028    	mov	w8, #0x1                ; =1
10166c5d4: aa0a8108    	orr	x8, x8, x10, lsl #32
10166c5d8: d2800000    	mov	x0, #0x0                ; =0
10166c5dc: 92dfffe9    	mov	x9, #-0xffff00000001    ; =-281470681743361
10166c5e0: f2e10009    	movk	x9, #0x800, lsl #48
10166c5e4: eb09011f    	cmp	x8, x9
10166c5e8: 54ffdba8    	b.hi	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c5ec: 3607db88    	tbz	w8, #0x0, 0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c5f0: d360fd15    	lsr	x21, x8, #32
10166c5f4: a9412269    	ldp	x9, x8, [x19, #0x10]
10166c5f8: cb090108    	sub	x8, x8, x9
10166c5fc: eb15011f    	cmp	x8, x21
10166c600: 540026a3    	b.lo	0x10166cad4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81302c>
10166c604: b9402677    	ldr	w23, [x19, #0x24]
10166c608: 110006e8    	add	w8, w23, #0x1
10166c60c: b9002668    	str	w8, [x19, #0x24]
10166c610: f9400269    	ldr	x9, [x19]
10166c614: f941152a    	ldr	x10, [x9, #0x228]
10166c618: f9411928    	ldr	x8, [x9, #0x230]
10166c61c: a9012be8    	stp	x8, x10, [sp, #0x10]
10166c620: b9423928    	ldr	w8, [x9, #0x238]
10166c624: 11000508    	add	w8, w8, #0x1
10166c628: f90013e9    	str	x9, [sp, #0x20]
10166c62c: b9023928    	str	w8, [x9, #0x238]
10166c630: f9400260    	ldr	x0, [x19]
10166c634: 52800061    	mov	w1, #0x3                ; =3
10166c638: aa1503e2    	mov	x2, x21
10166c63c: aa1503e3    	mov	x3, x21
10166c640: 52800024    	mov	w4, #0x1                ; =1
10166c644: 52800005    	mov	w5, #0x0                ; =0
10166c648: 97ab1e5e    	bl	0x100133fc0 <_cxxbridge1$slice$new+0xee4e4>
10166c64c: aa0003f4    	mov	x20, x0
10166c650: f9400260    	ldr	x0, [x19]
10166c654: f9401a61    	ldr	x1, [x19, #0x30]
10166c658: aa1703e2    	mov	x2, x23
10166c65c: aa1403e3    	mov	x3, x20
10166c660: 97d1b848    	bl	0x100ada780 <_sfv$cxxbridge1$199$decode_item+0x25ebc>
10166c664: aa0003f7    	mov	x23, x0
10166c668: f9401a60    	ldr	x0, [x19, #0x30]
10166c66c: eb17001f    	cmp	x0, x23
10166c670: 540001c0    	b.eq	0x10166c6a8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812c00>
10166c674: b40000d7    	cbz	x23, 0x10166c68c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812be4>
10166c678: b40000a0    	cbz	x0, 0x10166c68c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812be4>
10166c67c: b94002e8    	ldr	w8, [x23]
10166c680: b9400009    	ldr	w9, [x0]
10166c684: 6b09011f    	cmp	w8, w9
10166c688: 54000100    	b.eq	0x10166c6a8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812c00>
10166c68c: 97a92d1c    	bl	0x1000b7afc <_cxxbridge1$slice$new+0x72020>
10166c690: f9400268    	ldr	x8, [x19]
10166c694: 91404109    	add	x9, x8, #0x10, lsl #12  ; =0x10000
10166c698: f945e920    	ldr	x0, [x9, #0xbd0]
10166c69c: f94002e1    	ldr	x1, [x23]
10166c6a0: 97f57803    	bl	0x1013ca6ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x570c04>
10166c6a4: f9001a60    	str	x0, [x19, #0x30]
10166c6a8: f9400288    	ldr	x8, [x20]
10166c6ac: b8407108    	ldur	w8, [x8, #0x7]
10166c6b0: d00458fc    	adrp	x28, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
10166c6b4: f940ab89    	ldr	x9, [x28, #0x150]
10166c6b8: aa080121    	orr	x1, x9, x8
10166c6bc: f9400260    	ldr	x0, [x19]
10166c6c0: f9411417    	ldr	x23, [x0, #0x228]
10166c6c4: f9411808    	ldr	x8, [x0, #0x230]
10166c6c8: eb0802ff    	cmp	x23, x8
10166c6cc: f90007f4    	str	x20, [sp, #0x8]
10166c6d0: 54003920    	b.eq	0x10166cdf4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81334c>
10166c6d4: 910022e8    	add	x8, x23, #0x8
10166c6d8: f9011408    	str	x8, [x0, #0x228]
10166c6dc: f90002e1    	str	x1, [x23]
10166c6e0: b4000155    	cbz	x21, 0x10166c708 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812c60>
10166c6e4: d2800016    	mov	x22, #0x0               ; =0
10166c6e8: b840303a    	ldur	w26, [x1, #0x3]
10166c6ec: 5281f31b    	mov	w27, #0xf98             ; =3992
10166c6f0: 72a0003b    	movk	w27, #0x1, lsl #16
10166c6f4: 17ffff66    	b	0x10166c48c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8129e4>
10166c6f8: aa1303e0    	mov	x0, x19
10166c6fc: 97fb2701    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
10166c700: aa0003f8    	mov	x24, x0
10166c704: 14000013    	b	0x10166c750 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812ca8>
10166c708: aa1303e0    	mov	x0, x19
10166c70c: f94007f4    	ldr	x20, [sp, #0x8]
10166c710: aa1403e1    	mov	x1, x20
10166c714: 52800482    	mov	w2, #0x24               ; =36
10166c718: 52800003    	mov	w3, #0x0                ; =0
10166c71c: 94000262    	bl	0x10166d0a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8135fc>
10166c720: aa0003f7    	mov	x23, x0
10166c724: 36002e97    	tbz	w23, #0x0, 0x10166ccf4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81324c>
10166c728: a9412a69    	ldp	x9, x10, [x19, #0x10]
10166c72c: 91001528    	add	x8, x9, #0x5
10166c730: eb0a011f    	cmp	x8, x10
10166c734: 54fffe22    	b.hs	0x10166c6f8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812c50>
10166c738: aa0903eb    	mov	x11, x9
10166c73c: 3840156a    	ldrb	w10, [x11], #0x1
10166c740: f9000a6b    	str	x11, [x19, #0x10]
10166c744: 37383b8a    	tbnz	w10, #0x7, 0x10166ceb4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81340c>
10166c748: 52800028    	mov	w8, #0x1                ; =1
10166c74c: aa0a8118    	orr	x24, x8, x10, lsl #32
10166c750: 36002d38    	tbz	w24, #0x0, 0x10166ccf4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81324c>
10166c754: a9412a69    	ldp	x9, x10, [x19, #0x10]
10166c758: 91001528    	add	x8, x9, #0x5
10166c75c: eb0a011f    	cmp	x8, x10
10166c760: 540001e2    	b.hs	0x10166c79c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812cf4>
10166c764: aa0903eb    	mov	x11, x9
10166c768: 3840156a    	ldrb	w10, [x11], #0x1
10166c76c: f9000a6b    	str	x11, [x19, #0x10]
10166c770: 363801ea    	tbz	w10, #0x7, 0x10166c7ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812d04>
10166c774: 1200194a    	and	w10, w10, #0x7f
10166c778: 39c0052c    	ldrsb	w12, [x9, #0x1]
10166c77c: 9100092b    	add	x11, x9, #0x2
10166c780: f9000a6b    	str	x11, [x19, #0x10]
10166c784: 53191d8b    	ubfiz	w11, w12, #7, #8
10166c788: 37f83fac    	tbnz	w12, #0x1f, 0x10166cf7c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8134d4>
10166c78c: 2a0a0168    	orr	w8, w11, w10
10166c790: 52800029    	mov	w9, #0x1                ; =1
10166c794: aa088128    	orr	x8, x9, x8, lsl #32
10166c798: 14000007    	b	0x10166c7b4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812d0c>
10166c79c: aa1303e0    	mov	x0, x19
10166c7a0: 97fb26d8    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
10166c7a4: aa0003e8    	mov	x8, x0
10166c7a8: 14000003    	b	0x10166c7b4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812d0c>
10166c7ac: 52800028    	mov	w8, #0x1                ; =1
10166c7b0: aa0a8108    	orr	x8, x8, x10, lsl #32
10166c7b4: d2800000    	mov	x0, #0x0                ; =0
10166c7b8: ca170309    	eor	x9, x24, x23
10166c7bc: d360fd29    	lsr	x9, x9, #32
10166c7c0: b50029c9    	cbnz	x9, 0x10166ccf8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813250>
10166c7c4: 360029a8    	tbz	w8, #0x0, 0x10166ccf8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813250>
10166c7c8: d360fd08    	lsr	x8, x8, #32
10166c7cc: eb0802bf    	cmp	x21, x8
10166c7d0: 54002941    	b.ne	0x10166ccf8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813250>
10166c7d4: f9400293    	ldr	x19, [x20]
10166c7d8: a941d3e0    	ldp	x0, x20, [sp, #0x18]
10166c7dc: f9011680    	str	x0, [x20, #0x228]
10166c7e0: b9423a88    	ldr	w8, [x20, #0x238]
10166c7e4: 51000508    	sub	w8, w8, #0x1
10166c7e8: b9023a88    	str	w8, [x20, #0x238]
10166c7ec: f9411a88    	ldr	x8, [x20, #0x230]
10166c7f0: f9400be9    	ldr	x9, [sp, #0x10]
10166c7f4: eb09011f    	cmp	x8, x9
10166c7f8: 540000c0    	b.eq	0x10166c810 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812d68>
10166c7fc: f9011a89    	str	x9, [x20, #0x230]
10166c800: aa1403e0    	mov	x0, x20
10166c804: 97b37868    	bl	0x10034a9a4 <_cxxbridge1$slice$new+0x304ec8>
10166c808: f9411680    	ldr	x0, [x20, #0x228]
10166c80c: f9411a89    	ldr	x9, [x20, #0x230]
10166c810: eb09001f    	cmp	x0, x9
10166c814: 54002f80    	b.eq	0x10166ce04 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81335c>
10166c818: 91002008    	add	x8, x0, #0x8
10166c81c: f9011688    	str	x8, [x20, #0x228]
10166c820: f9000013    	str	x19, [x0]
10166c824: f9411689    	ldr	x9, [x20, #0x228]
10166c828: f9411a8a    	ldr	x10, [x20, #0x230]
10166c82c: b9423a88    	ldr	w8, [x20, #0x238]
10166c830: 11000508    	add	w8, w8, #0x1
10166c834: b9023a88    	str	w8, [x20, #0x238]
10166c838: b4ffc934    	cbz	x20, 0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c83c: f9011689    	str	x9, [x20, #0x228]
10166c840: b9423a88    	ldr	w8, [x20, #0x238]
10166c844: 51000508    	sub	w8, w8, #0x1
10166c848: b9023a88    	str	w8, [x20, #0x238]
10166c84c: f9411a88    	ldr	x8, [x20, #0x230]
10166c850: eb0a011f    	cmp	x8, x10
10166c854: 54ffc840    	b.eq	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c858: f9011a8a    	str	x10, [x20, #0x230]
10166c85c: 14000002    	b	0x10166c864 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812dbc>
10166c860: f9011a98    	str	x24, [x20, #0x230]
10166c864: aa0003f3    	mov	x19, x0
10166c868: aa1403e0    	mov	x0, x20
10166c86c: 97b3784e    	bl	0x10034a9a4 <_cxxbridge1$slice$new+0x304ec8>
10166c870: aa1303e0    	mov	x0, x19
10166c874: 17fffe3a    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c878: 937f7d21    	sbfiz	x1, x9, #1, #32
10166c87c: 17fffe4b    	b	0x10166c1a8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812700>
10166c880: aa0803e0    	mov	x0, x8
10166c884: 97a7f809    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
10166c888: 17fffe35    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c88c: 9100a3e0    	add	x0, sp, #0x28
10166c890: 941ae92c    	bl	0x101d26d40 <_crabby_avifPeekCompatibleFileType+0x93034>
10166c894: 350022a0    	cbnz	w0, 0x10166cce8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813240>
10166c898: 17ffff10    	b	0x10166c4d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812a30>
10166c89c: aa1303e0    	mov	x0, x19
10166c8a0: d2800001    	mov	x1, #0x0                ; =0
10166c8a4: 52800022    	mov	w2, #0x1                ; =1
10166c8a8: 14000007    	b	0x10166c8c4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812e1c>
10166c8ac: aa1303e0    	mov	x0, x19
10166c8b0: d2800001    	mov	x1, #0x0                ; =0
10166c8b4: 14000003    	b	0x10166c8c0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812e18>
10166c8b8: aa1303e0    	mov	x0, x19
10166c8bc: 52800021    	mov	w1, #0x1                ; =1
10166c8c0: d2800002    	mov	x2, #0x0                ; =0
10166c8c4: 52800003    	mov	w3, #0x0                ; =0
10166c8c8: 949ddd10    	bl	0x103de3d08 <__v8_internal_Print_TransitionTree+0x19b320>
10166c8cc: 17fffe24    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c8d0: a9412a68    	ldp	x8, x10, [x19, #0x10]
10166c8d4: aa0803eb    	mov	x11, x8
10166c8d8: eb0a011f    	cmp	x8, x10
10166c8dc: 54ffe162    	b.hs	0x10166c508 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812a60>
10166c8e0: 3840156c    	ldrb	w12, [x11], #0x1
10166c8e4: 3500008c    	cbnz	w12, 0x10166c8f4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812e4c>
10166c8e8: eb0a017f    	cmp	x11, x10
10166c8ec: 54ffe0e2    	b.hs	0x10166c508 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812a60>
10166c8f0: 17fffffc    	b	0x10166c8e0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812e38>
10166c8f4: 7101599f    	cmp	w12, #0x56
10166c8f8: 54ffe081    	b.ne	0x10166c508 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812a60>
10166c8fc: eb0a011f    	cmp	x8, x10
10166c900: 54002562    	b.hs	0x10166cdac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813304>
10166c904: 3840150b    	ldrb	w11, [x8], #0x1
10166c908: f9000a68    	str	x8, [x19, #0x10]
10166c90c: 34ffff8b    	cbz	w11, 0x10166c8fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812e54>
10166c910: 1400012c    	b	0x10166cdc0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813318>
10166c914: aa1303e0    	mov	x0, x19
10166c918: 949ddedd    	bl	0x103de448c <__v8_internal_Print_TransitionTree+0x19baa4>
10166c91c: 17fffe10    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c920: aa1303e0    	mov	x0, x19
10166c924: 949dde5b    	bl	0x103de4290 <__v8_internal_Print_TransitionTree+0x19b8a8>
10166c928: 17fffe0d    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c92c: aa1303e0    	mov	x0, x19
10166c930: 949ddfa5    	bl	0x103de47c4 <__v8_internal_Print_TransitionTree+0x19bddc>
10166c934: 17fffe0a    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c938: aa1303e0    	mov	x0, x19
10166c93c: 949dd9b7    	bl	0x103de3018 <__v8_internal_Print_TransitionTree+0x19a630>
10166c940: 17fffe07    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c944: aa1303e0    	mov	x0, x19
10166c948: 949ddded    	bl	0x103de40fc <__v8_internal_Print_TransitionTree+0x19b714>
10166c94c: 17fffe04    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c950: aa1303e0    	mov	x0, x19
10166c954: 949ddb70    	bl	0x103de3714 <__v8_internal_Print_TransitionTree+0x19ad2c>
10166c958: 17fffe01    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c95c: aa1303e0    	mov	x0, x19
10166c960: 949dd8c9    	bl	0x103de2c84 <__v8_internal_Print_TransitionTree+0x19a29c>
10166c964: 17fffdfe    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c968: aa1303e0    	mov	x0, x19
10166c96c: 949dd84f    	bl	0x103de2aa8 <__v8_internal_Print_TransitionTree+0x19a0c0>
10166c970: 17fffdfb    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c974: aa1303e0    	mov	x0, x19
10166c978: 949ddfd9    	bl	0x103de48dc <__v8_internal_Print_TransitionTree+0x19bef4>
10166c97c: 17fffdf8    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c980: aa1303e0    	mov	x0, x19
10166c984: 949dd9f9    	bl	0x103de3168 <__v8_internal_Print_TransitionTree+0x19a780>
10166c988: 17fffdf5    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c98c: aa1303e0    	mov	x0, x19
10166c990: 949dd7c2    	bl	0x103de2898 <__v8_internal_Print_TransitionTree+0x199eb0>
10166c994: 17fffdf2    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c998: aa1303e0    	mov	x0, x19
10166c99c: 949ddb09    	bl	0x103de35c0 <__v8_internal_Print_TransitionTree+0x19abd8>
10166c9a0: 17fffdef    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c9a4: aa1303e0    	mov	x0, x19
10166c9a8: 949dd800    	bl	0x103de29a8 <__v8_internal_Print_TransitionTree+0x199fc0>
10166c9ac: 17fffdec    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166c9b0: d2800008    	mov	x8, #0x0                ; =0
10166c9b4: d2800014    	mov	x20, #0x0               ; =0
10166c9b8: 17fffdd5    	b	0x10166c10c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812664>
10166c9bc: 9100a3e0    	add	x0, sp, #0x28
10166c9c0: 941ae8e0    	bl	0x101d26d40 <_crabby_avifPeekCompatibleFileType+0x93034>
10166c9c4: 34ffc700    	cbz	w0, 0x10166c2a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8127fc>
10166c9c8: 14000043    	b	0x10166cad4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81302c>
10166c9cc: 35000881    	cbnz	w1, 0x10166cadc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813034>
10166c9d0: 91000529    	add	x9, x9, #0x1
10166c9d4: 8b09010b    	add	x11, x8, x9
10166c9d8: eb0a017f    	cmp	x11, x10
10166c9dc: 54ffb603    	b.lo	0x10166c09c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8125f4>
10166c9e0: 1400003d    	b	0x10166cad4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81302c>
10166c9e4: 120b1929    	and	w9, w9, #0xfe00000
10166c9e8: 39400108    	ldrb	w8, [x8]
10166c9ec: f9000a6b    	str	x11, [x19, #0x10]
10166c9f0: 2a087128    	orr	w8, w9, w8, lsl #28
10166c9f4: 2a0a0108    	orr	w8, w8, w10
10166c9f8: 1400001c    	b	0x10166ca68 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812fc0>
10166c9fc: 121219ad    	and	w13, w13, #0x1fc000
10166ca00: 2a0a01aa    	orr	w10, w13, w10
10166ca04: 39c0018c    	ldrsb	w12, [x12]
10166ca08: 8b090108    	add	x8, x8, x9
10166ca0c: 91001508    	add	x8, x8, #0x5
10166ca10: f9000a68    	str	x8, [x19, #0x10]
10166ca14: 530b1d89    	ubfiz	w9, w12, #21, #8
10166ca18: 37fffe6c    	tbnz	w12, #0x1f, 0x10166c9e4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812f3c>
10166ca1c: 2a0a0128    	orr	w8, w9, w10
10166ca20: 14000012    	b	0x10166ca68 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812fc0>
10166ca24: 121919ce    	and	w14, w14, #0x3f80
10166ca28: 2a0a01ca    	orr	w10, w14, w10
10166ca2c: 39c001ae    	ldrsb	w14, [x13]
10166ca30: 9100118c    	add	x12, x12, #0x4
10166ca34: f9000a6c    	str	x12, [x19, #0x10]
10166ca38: 53121dcd    	ubfiz	w13, w14, #14, #8
10166ca3c: 37fffe0e    	tbnz	w14, #0x1f, 0x10166c9fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812f54>
10166ca40: 2a0a01a8    	orr	w8, w13, w10
10166ca44: 14000009    	b	0x10166ca68 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812fc0>
10166ca48: 1200194a    	and	w10, w10, #0x7f
10166ca4c: 39c0018f    	ldrsb	w15, [x12]
10166ca50: 8b09010c    	add	x12, x8, x9
10166ca54: 91000d8d    	add	x13, x12, #0x3
10166ca58: f9000a6d    	str	x13, [x19, #0x10]
10166ca5c: 53191dee    	ubfiz	w14, w15, #7, #8
10166ca60: 37fffe2f    	tbnz	w15, #0x1f, 0x10166ca24 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812f7c>
10166ca64: 2a0a01c8    	orr	w8, w14, w10
10166ca68: 52800029    	mov	w9, #0x1                ; =1
10166ca6c: aa088120    	orr	x0, x9, x8, lsl #32
10166ca70: 1400000b    	b	0x10166ca9c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812ff4>
10166ca74: 8b09010c    	add	x12, x8, x9
10166ca78: 9100198b    	add	x11, x12, #0x6
10166ca7c: eb0a017f    	cmp	x11, x10
10166ca80: 540020c2    	b.hs	0x10166ce98 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8133f0>
10166ca84: 3940058a    	ldrb	w10, [x12, #0x1]
10166ca88: 9100098c    	add	x12, x12, #0x2
10166ca8c: f9000a6c    	str	x12, [x19, #0x10]
10166ca90: 373ffdca    	tbnz	w10, #0x7, 0x10166ca48 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x812fa0>
10166ca94: 52800028    	mov	w8, #0x1                ; =1
10166ca98: aa0a8100    	orr	x0, x8, x10, lsl #32
10166ca9c: 360001c0    	tbz	w0, #0x0, 0x10166cad4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x81302c>
10166caa0: d360fc01    	lsr	x1, x0, #32
10166caa4: aa1303e0    	mov	x0, x19
10166caa8: 949dd858    	bl	0x103de2c08 <__v8_internal_Print_TransitionTree+0x19a220>
10166caac: 17fffdac    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166cab0: b940226a    	ldr	w10, [x19, #0x20]
10166cab4: 71003d5f    	cmp	w10, #0xf
10166cab8: 540000a3    	b.lo	0x10166cacc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813024>
10166cabc: aa1303e0    	mov	x0, x19
10166cac0: 949de05d    	bl	0x103de4c34 <__v8_internal_Print_TransitionTree+0x19c24c>
10166cac4: 17fffda6    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166cac8: b940226a    	ldr	w10, [x19, #0x20]
10166cacc: 7100315f    	cmp	w10, #0xc
10166cad0: 54000109    	b.ls	0x10166caf0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813048>
10166cad4: d2800000    	mov	x0, #0x0                ; =0
10166cad8: 17fffda1    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166cadc: 71009c3f    	cmp	w1, #0x27
10166cae0: 54ffff41    	b.ne	0x10166cac8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x813020>
10166cae4: aa1303e0    	mov	x0, x19
10166cae8: 949ddbcb    	bl	0x103de3a14 <__v8_internal_Print_TransitionTree+0x19b02c>
10166caec: 17fffd9c    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166caf0: 8b090108    	add	x8, x8, x9
10166caf4: f9000a68    	str	x8, [x19, #0x10]
10166caf8: aa1303e0    	mov	x0, x19
10166cafc: 949de027    	bl	0x103de4b98 <__v8_internal_Print_TransitionTree+0x19c1b0>
10166cb00: 17fffd97    	b	0x10166c15c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8126b4>
10166cb04: 8b09010c    	add	x12, x8, x9
10166cb08: 9100198b    	add	x11, x12, #0x6
10166cb0c: eb0a017f    	cmp	x11, x10
10166cb10: 54001be2    	b.hs	0x10166ce8c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8133e4>
10166cb14: 3940058a    	ldrb	w10, [x12, #0x1]
10166cb18: 9100098c    	add	x12, x12, #0x2
10166cb1c: f9000a6c    	str	x12, [x19, #0x10]
