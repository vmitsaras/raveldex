
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000103c489e8 <__v8_internal_Print_TransitionTree>:
103de0500: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de0504: d65f03c0    	ret
103de0508: aa1403e0    	mov	x0, x20
103de050c: aa1603e1    	mov	x1, x22
103de0510: 97648278    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0514: 529fc028    	mov	w8, #0xfe01             ; =65025
103de0518: 6a08001f    	tst	w0, w8
103de051c: 54fffd61    	b.ne	0x103de04c8 <__v8_internal_Print_TransitionTree+0x197ae0>
103de0520: 17fffff5    	b	0x103de04f4 <__v8_internal_Print_TransitionTree+0x197b0c>
103de0524: d4200000    	brk	#0
103de0528: d4400000    	hlt	#0
103de052c: d4200020    	brk	#0x1
103de0530: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
103de0534: a90157f6    	stp	x22, x21, [sp, #0x10]
103de0538: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de053c: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de0540: 9100c3fd    	add	x29, sp, #0x30
103de0544: aa0003f4    	mov	x20, x0
103de0548: d1000433    	sub	x19, x1, #0x1
103de054c: aa1303e0    	mov	x0, x19
103de0550: 97fd6b6c    	bl	0x103d3b300 <__v8_internal_Print_TransitionTree+0xf2918>
103de0554: aa0003f6    	mov	x22, x0
103de0558: 97fd6b72    	bl	0x103d3b320 <__v8_internal_Print_TransitionTree+0xf2938>
103de055c: aa0003f5    	mov	x21, x0
103de0560: aa1403e0    	mov	x0, x20
103de0564: aa1603e1    	mov	x1, x22
103de0568: 97490806    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de056c: a941a296    	ldp	x22, x8, [x20, #0x18]
103de0570: 8b1502d7    	add	x23, x22, x21
103de0574: eb0802ff    	cmp	x23, x8
103de0578: 54000168    	b.hi	0x103de05a4 <__v8_internal_Print_TransitionTree+0x197bbc>
103de057c: f9000e97    	str	x23, [x20, #0x18]
103de0580: f9400a88    	ldr	x8, [x20, #0x10]
103de0584: 8b160101    	add	x1, x8, x22
103de0588: aa1303e0    	mov	x0, x19
103de058c: aa1503e2    	mov	x2, x21
103de0590: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de0594: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de0598: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de059c: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de05a0: 17fd6b62    	b	0x103d3b328 <__v8_internal_Print_TransitionTree+0xf2940>
103de05a4: 8b1502c1    	add	x1, x22, x21
103de05a8: aa1403e0    	mov	x0, x20
103de05ac: 97648251    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de05b0: 529fc028    	mov	w8, #0xfe01             ; =65025
103de05b4: 6a08001f    	tst	w0, w8
103de05b8: 54fffe21    	b.ne	0x103de057c <__v8_internal_Print_TransitionTree+0x197b94>
103de05bc: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de05c0: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de05c4: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de05c8: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de05cc: d65f03c0    	ret
103de05d0: 14000004    	b	0x103de05e0 <__v8_internal_Print_TransitionTree+0x197bf8>
		...
103de05e0: d10143ff    	sub	sp, sp, #0x50
103de05e4: a90257f6    	stp	x22, x21, [sp, #0x20]
103de05e8: a9034ff4    	stp	x20, x19, [sp, #0x30]
103de05ec: a9047bfd    	stp	x29, x30, [sp, #0x40]
103de05f0: 910103fd    	add	x29, sp, #0x40
103de05f4: aa0003f4    	mov	x20, x0
103de05f8: d2800013    	mov	x19, #0x0               ; =0
103de05fc: 9002daa8    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
103de0600: f9401108    	ldr	x8, [x8, #0x20]
103de0604: f9400108    	ldr	x8, [x8]
103de0608: f9000fe8    	str	x8, [sp, #0x18]
103de060c: 91003be8    	add	x8, sp, #0xe
103de0610: aa0103e9    	mov	x9, x1
103de0614: 3219002a    	orr	w10, w1, #0x80
103de0618: 3833690a    	strb	w10, [x8, x19]
103de061c: d347fc21    	lsr	x1, x1, #7
103de0620: 91000673    	add	x19, x19, #0x1
103de0624: b5ffff61    	cbnz	x1, 0x103de0610 <__v8_internal_Print_TransitionTree+0x197c28>
103de0628: 91003be8    	add	x8, sp, #0xe
103de062c: 8b130108    	add	x8, x8, x19
103de0630: 381ff109    	sturb	w9, [x8, #-0x1]
103de0634: a941a295    	ldp	x21, x8, [x20, #0x18]
103de0638: 8b1302b6    	add	x22, x21, x19
103de063c: eb0802df    	cmp	x22, x8
103de0640: 54000268    	b.hi	0x103de068c <__v8_internal_Print_TransitionTree+0x197ca4>
103de0644: f9000e96    	str	x22, [x20, #0x18]
103de0648: b40000d3    	cbz	x19, 0x103de0660 <__v8_internal_Print_TransitionTree+0x197c78>
103de064c: f9400a88    	ldr	x8, [x20, #0x10]
103de0650: 8b150100    	add	x0, x8, x21
103de0654: 91003be1    	add	x1, sp, #0xe
103de0658: aa1303e2    	mov	x2, x19
103de065c: 9539ded3    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
103de0660: f9400fe8    	ldr	x8, [sp, #0x18]
103de0664: 9002daa9    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
103de0668: f9401129    	ldr	x9, [x9, #0x20]
103de066c: f9400129    	ldr	x9, [x9]
103de0670: eb08013f    	cmp	x9, x8
103de0674: 540001a1    	b.ne	0x103de06a8 <__v8_internal_Print_TransitionTree+0x197cc0>
103de0678: a9447bfd    	ldp	x29, x30, [sp, #0x40]
103de067c: a9434ff4    	ldp	x20, x19, [sp, #0x30]
103de0680: a94257f6    	ldp	x22, x21, [sp, #0x20]
103de0684: 910143ff    	add	sp, sp, #0x50
103de0688: d65f03c0    	ret
103de068c: 8b1302a1    	add	x1, x21, x19
103de0690: aa1403e0    	mov	x0, x20
103de0694: 97648217    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0698: 529fc028    	mov	w8, #0xfe01             ; =65025
103de069c: 6a08001f    	tst	w0, w8
103de06a0: 54fffd21    	b.ne	0x103de0644 <__v8_internal_Print_TransitionTree+0x197c5c>
103de06a4: 17ffffef    	b	0x103de0660 <__v8_internal_Print_TransitionTree+0x197c78>
103de06a8: 9539de93    	bl	0x108c580f4 <dyld_stub_binder+0x108c580f4>
103de06ac: 00000000    	udf	#0x0
103de06b0: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
103de06b4: a9017bfd    	stp	x29, x30, [sp, #0x10]
103de06b8: 910043fd    	add	x29, sp, #0x10
103de06bc: aa0103f3    	mov	x19, x1
103de06c0: f9400041    	ldr	x1, [x2]
103de06c4: 91030000    	add	x0, x0, #0xc0
103de06c8: 970dcb9e    	bl	0x100153540 <_cxxbridge1$slice$new+0x10da64>
103de06cc: b9000013    	str	w19, [x0]
103de06d0: a9417bfd    	ldp	x29, x30, [sp, #0x10]
103de06d4: a8c24ff4    	ldp	x20, x19, [sp], #0x20
103de06d8: d65f03c0    	ret
103de06dc: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
103de06e0: a9014ff4    	stp	x20, x19, [sp, #0x10]
103de06e4: a9027bfd    	stp	x29, x30, [sp, #0x20]
103de06e8: 910083fd    	add	x29, sp, #0x20
103de06ec: aa0103f3    	mov	x19, x1
103de06f0: aa0003f4    	mov	x20, x0
103de06f4: a941a015    	ldp	x21, x8, [x0, #0x18]
103de06f8: 910006b6    	add	x22, x21, #0x1
103de06fc: eb0802df    	cmp	x22, x8
103de0700: 54000168    	b.hi	0x103de072c <__v8_internal_Print_TransitionTree+0x197d44>
103de0704: f9000e96    	str	x22, [x20, #0x18]
103de0708: f9400a88    	ldr	x8, [x20, #0x10]
103de070c: 52800b49    	mov	w9, #0x5a               ; =90
103de0710: 38356909    	strb	w9, [x8, x21]
103de0714: aa1403e0    	mov	x0, x20
103de0718: aa1303e1    	mov	x1, x19
103de071c: a9427bfd    	ldp	x29, x30, [sp, #0x20]
103de0720: a9414ff4    	ldp	x20, x19, [sp, #0x10]
103de0724: a8c357f6    	ldp	x22, x21, [sp], #0x30
103de0728: 17ffff82    	b	0x103de0530 <__v8_internal_Print_TransitionTree+0x197b48>
103de072c: 910006a1    	add	x1, x21, #0x1
103de0730: aa1403e0    	mov	x0, x20
103de0734: 976481ef    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0738: 529fc028    	mov	w8, #0xfe01             ; =65025
103de073c: 6a08001f    	tst	w0, w8
103de0740: 54fffe21    	b.ne	0x103de0704 <__v8_internal_Print_TransitionTree+0x197d1c>
103de0744: 17fffff4    	b	0x103de0714 <__v8_internal_Print_TransitionTree+0x197d2c>
103de0748: d100c3ff    	sub	sp, sp, #0x30
103de074c: a9014ff4    	stp	x20, x19, [sp, #0x10]
103de0750: a9027bfd    	stp	x29, x30, [sp, #0x20]
103de0754: 910083fd    	add	x29, sp, #0x20
103de0758: aa0003f3    	mov	x19, x0
103de075c: 9002daa8    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
103de0760: f9401108    	ldr	x8, [x8, #0x20]
103de0764: f9400108    	ldr	x8, [x8]
103de0768: f90007e8    	str	x8, [sp, #0x8]
103de076c: f9400000    	ldr	x0, [x0]
103de0770: f90003e2    	str	x2, [sp]
103de0774: 910003e2    	mov	x2, sp
103de0778: 52800023    	mov	w3, #0x1                ; =1
103de077c: 9749d404    	bl	0x10105578c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1fbce4>
103de0780: aa0003e9    	mov	x9, x0
103de0784: f9400660    	ldr	x0, [x19, #0x8]
103de0788: b50004c0    	cbnz	x0, 0x103de0820 <__v8_internal_Print_TransitionTree+0x197e38>
103de078c: f9400273    	ldr	x19, [x19]
103de0790: f940ae68    	ldr	x8, [x19, #0x158]
103de0794: b85ff108    	ldur	w8, [x8, #-0x1]
103de0798: d0031d4a    	adrp	x10, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
103de079c: f940a94a    	ldr	x10, [x10, #0x150]
103de07a0: aa080148    	orr	x8, x10, x8
103de07a4: b8413108    	ldur	w8, [x8, #0x13]
103de07a8: aa080148    	orr	x8, x10, x8
103de07ac: 91103d08    	add	x8, x8, #0x40f
103de07b0: b9400108    	ldr	w8, [x8]
103de07b4: aa080148    	orr	x8, x10, x8
103de07b8: f9411661    	ldr	x1, [x19, #0x228]
103de07bc: f9411a6a    	ldr	x10, [x19, #0x230]
103de07c0: eb0a003f    	cmp	x1, x10
103de07c4: 54000340    	b.eq	0x103de082c <__v8_internal_Print_TransitionTree+0x197e44>
103de07c8: 9100202a    	add	x10, x1, #0x8
103de07cc: f901166a    	str	x10, [x19, #0x228]
103de07d0: f9000028    	str	x8, [x1]
103de07d4: aa1303e0    	mov	x0, x19
103de07d8: aa0903e2    	mov	x2, x9
103de07dc: d2800003    	mov	x3, #0x0                ; =0
103de07e0: 97815cf0    	bl	0x101e37ba0 <_cxxbridge1$string$new+0x6f0d8>
103de07e4: f9400001    	ldr	x1, [x0]
103de07e8: aa1303e0    	mov	x0, x19
103de07ec: d2800002    	mov	x2, #0x0                ; =0
103de07f0: 52800003    	mov	w3, #0x0                ; =0
103de07f4: 972e3967    	bl	0x10096ed90 <_rust_png$cxxbridge1$199$Reader$interlaced+0xb6b50>
103de07f8: f94007e8    	ldr	x8, [sp, #0x8]
103de07fc: 9002daa9    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
103de0800: f9401129    	ldr	x9, [x9, #0x20]
103de0804: f9400129    	ldr	x9, [x9]
103de0808: eb08013f    	cmp	x9, x8
103de080c: 540001a1    	b.ne	0x103de0840 <__v8_internal_Print_TransitionTree+0x197e58>
103de0810: a9427bfd    	ldp	x29, x30, [sp, #0x20]
103de0814: a9414ff4    	ldp	x20, x19, [sp, #0x10]
103de0818: 9100c3ff    	add	sp, sp, #0x30
103de081c: d65f03c0    	ret
103de0820: aa0903e1    	mov	x1, x9
103de0824: 94ce3e4a    	bl	0x10717014c <__Z23_v8_internal_Node_PrintPv+0x3060b20>
103de0828: 17fffff4    	b	0x103de07f8 <__v8_internal_Print_TransitionTree+0x197e10>
103de082c: aa1303e0    	mov	x0, x19
103de0830: aa0803e1    	mov	x1, x8
103de0834: 970a281d    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de0838: aa0003e1    	mov	x1, x0
103de083c: 17ffffe6    	b	0x103de07d4 <__v8_internal_Print_TransitionTree+0x197dec>
103de0840: 9539de2d    	bl	0x108c580f4 <dyld_stub_binder+0x108c580f4>
		...
103de0850: d10103ff    	sub	sp, sp, #0x40
103de0854: a90157f6    	stp	x22, x21, [sp, #0x10]
103de0858: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de085c: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de0860: 9100c3fd    	add	x29, sp, #0x30
103de0864: aa0103f3    	mov	x19, x1
103de0868: aa0003f5    	mov	x21, x0
103de086c: 9002daa8    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
103de0870: f9401108    	ldr	x8, [x8, #0x20]
103de0874: f9400108    	ldr	x8, [x8]
103de0878: f90007e8    	str	x8, [sp, #0x8]
103de087c: a941a014    	ldp	x20, x8, [x0, #0x18]
103de0880: 91000696    	add	x22, x20, #0x1
103de0884: eb0802df    	cmp	x22, x8
103de0888: 54000888    	b.hi	0x103de0998 <__v8_internal_Print_TransitionTree+0x197fb0>
103de088c: f9000eb6    	str	x22, [x21, #0x18]
103de0890: f9400aa8    	ldr	x8, [x21, #0x10]
103de0894: 52800b89    	mov	w9, #0x5c               ; =92
103de0898: 38346909    	strb	w9, [x8, x20]
103de089c: a94002b4    	ldp	x20, x0, [x21]
103de08a0: b5000520    	cbnz	x0, 0x103de0944 <__v8_internal_Print_TransitionTree+0x197f5c>
103de08a4: f940ae88    	ldr	x8, [x20, #0x158]
103de08a8: b85ff108    	ldur	w8, [x8, #-0x1]
103de08ac: d0031d49    	adrp	x9, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
103de08b0: f940a929    	ldr	x9, [x9, #0x150]
103de08b4: aa080128    	orr	x8, x9, x8
103de08b8: b8413108    	ldur	w8, [x8, #0x13]
103de08bc: aa080128    	orr	x8, x9, x8
103de08c0: 91103d08    	add	x8, x8, #0x40f
103de08c4: b9400108    	ldr	w8, [x8]
103de08c8: aa080128    	orr	x8, x9, x8
103de08cc: f9411681    	ldr	x1, [x20, #0x228]
103de08d0: f9411a89    	ldr	x9, [x20, #0x230]
103de08d4: eb09003f    	cmp	x1, x9
103de08d8: 54000560    	b.eq	0x103de0984 <__v8_internal_Print_TransitionTree+0x197f9c>
103de08dc: 91002029    	add	x9, x1, #0x8
103de08e0: f9011689    	str	x9, [x20, #0x228]
103de08e4: f9000028    	str	x8, [x1]
103de08e8: f90003f3    	str	x19, [sp]
103de08ec: 910003e3    	mov	x3, sp
103de08f0: aa1403e0    	mov	x0, x20
103de08f4: 52803b22    	mov	w2, #0x1d9              ; =473
103de08f8: 52800024    	mov	w4, #0x1                ; =1
103de08fc: 979070e1    	bl	0x1021fcc80 <_logging$internal$cxxbridge1$199$init_rust_logging+0x132f58>
103de0900: f9400001    	ldr	x1, [x0]
103de0904: aa1403e0    	mov	x0, x20
103de0908: d2800002    	mov	x2, #0x0                ; =0
103de090c: 52800003    	mov	w3, #0x0                ; =0
103de0910: 972e3920    	bl	0x10096ed90 <_rust_png$cxxbridge1$199$Reader$interlaced+0xb6b50>
103de0914: 52800000    	mov	w0, #0x0                ; =0
103de0918: f94007e8    	ldr	x8, [sp, #0x8]
103de091c: 9002daa9    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
103de0920: f9401129    	ldr	x9, [x9, #0x20]
103de0924: f9400129    	ldr	x9, [x9]
103de0928: eb08013f    	cmp	x9, x8
103de092c: 54000441    	b.ne	0x103de09b4 <__v8_internal_Print_TransitionTree+0x197fcc>
103de0930: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de0934: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de0938: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de093c: 910103ff    	add	sp, sp, #0x40
103de0940: d65f03c0    	ret
103de0944: aa1403e1    	mov	x1, x20
103de0948: aa1303e2    	mov	x2, x19
103de094c: 94ce3e3d    	bl	0x107170240 <__Z23_v8_internal_Node_PrintPv+0x3060c14>
103de0950: f94002a8    	ldr	x8, [x21]
103de0954: b9417908    	ldr	w8, [x8, #0x178]
103de0958: 5140bd08    	sub	w8, w8, #0x2f, lsl #12  ; =0x2f000
103de095c: 713ff51f    	cmp	w8, #0xffd
103de0960: 54fffda1    	b.ne	0x103de0914 <__v8_internal_Print_TransitionTree+0x197f2c>
103de0964: 3940aaa8    	ldrb	w8, [x21, #0x2a]
103de0968: 35000068    	cbnz	w8, 0x103de0974 <__v8_internal_Print_TransitionTree+0x197f8c>
103de096c: 52802020    	mov	w0, #0x101              ; =257
103de0970: 17ffffea    	b	0x103de0918 <__v8_internal_Print_TransitionTree+0x197f30>
103de0974: aa1503e0    	mov	x0, x21
103de0978: 52803b41    	mov	w1, #0x1da              ; =474
103de097c: 940003cd    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de0980: 17ffffe5    	b	0x103de0914 <__v8_internal_Print_TransitionTree+0x197f2c>
103de0984: aa1403e0    	mov	x0, x20
103de0988: aa0803e1    	mov	x1, x8
103de098c: 970a27c7    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de0990: aa0003e1    	mov	x1, x0
103de0994: 17ffffd5    	b	0x103de08e8 <__v8_internal_Print_TransitionTree+0x197f00>
103de0998: 91000681    	add	x1, x20, #0x1
103de099c: aa1503e0    	mov	x0, x21
103de09a0: 97648154    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de09a4: 529fc028    	mov	w8, #0xfe01             ; =65025
103de09a8: 6a08001f    	tst	w0, w8
103de09ac: 54fff701    	b.ne	0x103de088c <__v8_internal_Print_TransitionTree+0x197ea4>
103de09b0: 17ffffbb    	b	0x103de089c <__v8_internal_Print_TransitionTree+0x197eb4>
103de09b4: 9539ddd0    	bl	0x108c580f4 <dyld_stub_binder+0x108c580f4>
103de09b8: 6dbc23e9    	stp	d9, d8, [sp, #-0x40]!
103de09bc: a90157f6    	stp	x22, x21, [sp, #0x10]
103de09c0: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de09c4: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de09c8: 9100c3fd    	add	x29, sp, #0x30
103de09cc: aa0103f4    	mov	x20, x1
103de09d0: aa0003f3    	mov	x19, x0
103de09d4: a941a015    	ldp	x21, x8, [x0, #0x18]
103de09d8: 910006b6    	add	x22, x21, #0x1
103de09dc: eb0802df    	cmp	x22, x8
103de09e0: 54000248    	b.hi	0x103de0a28 <__v8_internal_Print_TransitionTree+0x198040>
103de09e4: f9000e76    	str	x22, [x19, #0x18]
103de09e8: f9400a68    	ldr	x8, [x19, #0x10]
103de09ec: 52800889    	mov	w9, #0x44               ; =68
103de09f0: 38356909    	strb	w9, [x8, x21]
103de09f4: fc40b288    	ldur	d8, [x20, #0xb]
103de09f8: a941a274    	ldp	x20, x8, [x19, #0x18]
103de09fc: 91002295    	add	x21, x20, #0x8
103de0a00: eb0802bf    	cmp	x21, x8
103de0a04: 54000208    	b.hi	0x103de0a44 <__v8_internal_Print_TransitionTree+0x19805c>
103de0a08: f9000e75    	str	x21, [x19, #0x18]
103de0a0c: f9400a68    	ldr	x8, [x19, #0x10]
103de0a10: fc346908    	str	d8, [x8, x20]
103de0a14: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de0a18: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de0a1c: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de0a20: 6cc423e9    	ldp	d9, d8, [sp], #0x40
103de0a24: d65f03c0    	ret
103de0a28: 910006a1    	add	x1, x21, #0x1
103de0a2c: aa1303e0    	mov	x0, x19
103de0a30: 97648130    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0a34: 529fc028    	mov	w8, #0xfe01             ; =65025
103de0a38: 6a08001f    	tst	w0, w8
103de0a3c: 54fffd41    	b.ne	0x103de09e4 <__v8_internal_Print_TransitionTree+0x197ffc>
103de0a40: 17ffffed    	b	0x103de09f4 <__v8_internal_Print_TransitionTree+0x19800c>
103de0a44: 91002281    	add	x1, x20, #0x8
103de0a48: aa1303e0    	mov	x0, x19
103de0a4c: 97648129    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0a50: 529fc028    	mov	w8, #0xfe01             ; =65025
103de0a54: 6a08001f    	tst	w0, w8
103de0a58: 54fffd81    	b.ne	0x103de0a08 <__v8_internal_Print_TransitionTree+0x198020>
103de0a5c: 17ffffee    	b	0x103de0a14 <__v8_internal_Print_TransitionTree+0x19802c>
		...
103de0a80: d10103ff    	sub	sp, sp, #0x40
103de0a84: a90157f6    	stp	x22, x21, [sp, #0x10]
103de0a88: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de0a8c: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de0a90: 9100c3fd    	add	x29, sp, #0x30
103de0a94: aa0003f3    	mov	x19, x0
103de0a98: f9400028    	ldr	x8, [x1]
103de0a9c: b840b108    	ldur	w8, [x8, #0xb]
103de0aa0: 7101551f    	cmp	w8, #0x55
103de0aa4: 54000160    	b.eq	0x103de0ad0 <__v8_internal_Print_TransitionTree+0x1980e8>
103de0aa8: 7101c51f    	cmp	w8, #0x71
103de0aac: 540003c1    	b.ne	0x103de0b24 <__v8_internal_Print_TransitionTree+0x19813c>
103de0ab0: a941a274    	ldp	x20, x8, [x19, #0x18]
103de0ab4: 91000695    	add	x21, x20, #0x1
103de0ab8: eb0802bf    	cmp	x21, x8
103de0abc: 54000c48    	b.hi	0x103de0c44 <__v8_internal_Print_TransitionTree+0x19825c>
103de0ac0: f9000e75    	str	x21, [x19, #0x18]
103de0ac4: f9400a68    	ldr	x8, [x19, #0x10]
103de0ac8: 52800f29    	mov	w9, #0x79               ; =121
103de0acc: 14000008    	b	0x103de0aec <__v8_internal_Print_TransitionTree+0x198104>
103de0ad0: a941a274    	ldp	x20, x8, [x19, #0x18]
103de0ad4: 91000695    	add	x21, x20, #0x1
103de0ad8: eb0802bf    	cmp	x21, x8
103de0adc: 54000c28    	b.hi	0x103de0c60 <__v8_internal_Print_TransitionTree+0x198278>
103de0ae0: f9000e75    	str	x21, [x19, #0x18]
103de0ae4: f9400a68    	ldr	x8, [x19, #0x10]
103de0ae8: 52800f09    	mov	w9, #0x78               ; =120
103de0aec: 38346909    	strb	w9, [x8, x20]
103de0af0: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de0af4: 350000e8    	cbnz	w8, 0x103de0b10 <__v8_internal_Print_TransitionTree+0x198128>
103de0af8: 52802020    	mov	w0, #0x101              ; =257
103de0afc: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de0b00: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de0b04: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de0b08: 910103ff    	add	sp, sp, #0x40
103de0b0c: d65f03c0    	ret
103de0b10: aa1303e0    	mov	x0, x19
103de0b14: 52803b41    	mov	w1, #0x1da              ; =474
103de0b18: 94000366    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de0b1c: 52800000    	mov	w0, #0x0                ; =0
103de0b20: 17fffff7    	b	0x103de0afc <__v8_internal_Print_TransitionTree+0x198114>
103de0b24: d0031d49    	adrp	x9, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
103de0b28: f940a929    	ldr	x9, [x9, #0x150]
103de0b2c: aa080134    	orr	x20, x9, x8
103de0b30: 36000088    	tbz	w8, #0x0, 0x103de0b40 <__v8_internal_Print_TransitionTree+0x198158>
103de0b34: b85ff28a    	ldur	w10, [x20, #-0x1]
103de0b38: 7114555f    	cmp	w10, #0x515
103de0b3c: 540002c1    	b.ne	0x103de0b94 <__v8_internal_Print_TransitionTree+0x1981ac>
103de0b40: a941aa69    	ldp	x9, x10, [x19, #0x18]
103de0b44: 91000535    	add	x21, x9, #0x1
103de0b48: eb0a02bf    	cmp	x21, x10
103de0b4c: 54000988    	b.hi	0x103de0c7c <__v8_internal_Print_TransitionTree+0x198294>
103de0b50: f9000e75    	str	x21, [x19, #0x18]
103de0b54: f9400a6a    	ldr	x10, [x19, #0x10]
103de0b58: 52800dcb    	mov	w11, #0x6e              ; =110
103de0b5c: 3829694b    	strb	w11, [x10, x9]
103de0b60: 36000068    	tbz	w8, #0x0, 0x103de0b6c <__v8_internal_Print_TransitionTree+0x198184>
103de0b64: fc403280    	ldur	d0, [x20, #0x3]
103de0b68: 14000003    	b	0x103de0b74 <__v8_internal_Print_TransitionTree+0x19818c>
103de0b6c: 13017d08    	asr	w8, w8, #1
103de0b70: 1e620100    	scvtf	d0, w8
103de0b74: a941a274    	ldp	x20, x8, [x19, #0x18]
103de0b78: 91002295    	add	x21, x20, #0x8
103de0b7c: eb0802bf    	cmp	x21, x8
103de0b80: 54000908    	b.hi	0x103de0ca0 <__v8_internal_Print_TransitionTree+0x1982b8>
103de0b84: f9000e75    	str	x21, [x19, #0x18]
103de0b88: f9400a68    	ldr	x8, [x19, #0x10]
103de0b8c: fc346900    	str	d0, [x8, x20]
103de0b90: 17ffffd8    	b	0x103de0af0 <__v8_internal_Print_TransitionTree+0x198108>
103de0b94: b85ff288    	ldur	w8, [x20, #-0x1]
103de0b98: aa080128    	orr	x8, x9, x8
103de0b9c: 78407108    	ldurh	w8, [x8, #0x7]
103de0ba0: 7102051f    	cmp	w8, #0x81
103de0ba4: 54000380    	b.eq	0x103de0c14 <__v8_internal_Print_TransitionTree+0x19822c>
103de0ba8: b85ff288    	ldur	w8, [x20, #-0x1]
103de0bac: 7111311f    	cmp	w8, #0x44c
103de0bb0: 54000288    	b.hi	0x103de0c00 <__v8_internal_Print_TransitionTree+0x198218>
103de0bb4: a941a668    	ldp	x8, x9, [x19, #0x18]
103de0bb8: 91000515    	add	x21, x8, #0x1
103de0bbc: eb0902bf    	cmp	x21, x9
103de0bc0: 540008a8    	b.hi	0x103de0cd4 <__v8_internal_Print_TransitionTree+0x1982ec>
103de0bc4: f9000e75    	str	x21, [x19, #0x18]
103de0bc8: f9400a69    	ldr	x9, [x19, #0x10]
103de0bcc: 52800e6a    	mov	w10, #0x73              ; =115
103de0bd0: 3828692a    	strb	w10, [x9, x8]
103de0bd4: f9400260    	ldr	x0, [x19]
103de0bd8: f9411401    	ldr	x1, [x0, #0x228]
103de0bdc: f9411808    	ldr	x8, [x0, #0x230]
103de0be0: eb08003f    	cmp	x1, x8
103de0be4: 54000700    	b.eq	0x103de0cc4 <__v8_internal_Print_TransitionTree+0x1982dc>
103de0be8: 91002028    	add	x8, x1, #0x8
103de0bec: f9011408    	str	x8, [x0, #0x228]
103de0bf0: f9000034    	str	x20, [x1]
103de0bf4: aa1303e0    	mov	x0, x19
103de0bf8: 97647f08    	bl	0x101700818 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6d70>
103de0bfc: 17ffffbd    	b	0x103de0af0 <__v8_internal_Print_TransitionTree+0x198108>
103de0c00: aa0103e2    	mov	x2, x1
103de0c04: aa1303e0    	mov	x0, x19
103de0c08: 52803b21    	mov	w1, #0x1d9              ; =473
103de0c0c: 97fffecf    	bl	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
103de0c10: 17ffffc3    	b	0x103de0b1c <__v8_internal_Print_TransitionTree+0x198134>
103de0c14: a941a668    	ldp	x8, x9, [x19, #0x18]
103de0c18: 91000515    	add	x21, x8, #0x1
103de0c1c: eb0902bf    	cmp	x21, x9
103de0c20: 540006c8    	b.hi	0x103de0cf8 <__v8_internal_Print_TransitionTree+0x198310>
103de0c24: f9000e75    	str	x21, [x19, #0x18]
103de0c28: f9400a69    	ldr	x9, [x19, #0x10]
103de0c2c: 52800f4a    	mov	w10, #0x7a              ; =122
103de0c30: 3828692a    	strb	w10, [x9, x8]
103de0c34: aa1303e0    	mov	x0, x19
103de0c38: aa1403e1    	mov	x1, x20
103de0c3c: 97fffe3d    	bl	0x103de0530 <__v8_internal_Print_TransitionTree+0x197b48>
103de0c40: 17ffffac    	b	0x103de0af0 <__v8_internal_Print_TransitionTree+0x198108>
103de0c44: 91000681    	add	x1, x20, #0x1
103de0c48: aa1303e0    	mov	x0, x19
103de0c4c: 976480a9    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0c50: 529fc028    	mov	w8, #0xfe01             ; =65025
103de0c54: 6a08001f    	tst	w0, w8
103de0c58: 54fff341    	b.ne	0x103de0ac0 <__v8_internal_Print_TransitionTree+0x1980d8>
103de0c5c: 17ffffa5    	b	0x103de0af0 <__v8_internal_Print_TransitionTree+0x198108>
103de0c60: 91000681    	add	x1, x20, #0x1
103de0c64: aa1303e0    	mov	x0, x19
103de0c68: 976480a2    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0c6c: 529fc028    	mov	w8, #0xfe01             ; =65025
103de0c70: 6a08001f    	tst	w0, w8
103de0c74: 54fff361    	b.ne	0x103de0ae0 <__v8_internal_Print_TransitionTree+0x1980f8>
103de0c78: 17ffff9e    	b	0x103de0af0 <__v8_internal_Print_TransitionTree+0x198108>
103de0c7c: 91000521    	add	x1, x9, #0x1
103de0c80: aa1303e0    	mov	x0, x19
103de0c84: a90023e9    	stp	x9, x8, [sp]
103de0c88: 9764809a    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0c8c: a94023e9    	ldp	x9, x8, [sp]
103de0c90: 529fc02a    	mov	w10, #0xfe01            ; =65025
103de0c94: 6a0a001f    	tst	w0, w10
103de0c98: 54fff5c1    	b.ne	0x103de0b50 <__v8_internal_Print_TransitionTree+0x198168>
103de0c9c: 17ffffb1    	b	0x103de0b60 <__v8_internal_Print_TransitionTree+0x198178>
103de0ca0: 91002281    	add	x1, x20, #0x8
103de0ca4: aa1303e0    	mov	x0, x19
103de0ca8: fd0007e0    	str	d0, [sp, #0x8]
103de0cac: 97648091    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0cb0: fd4007e0    	ldr	d0, [sp, #0x8]
103de0cb4: 529fc028    	mov	w8, #0xfe01             ; =65025
103de0cb8: 6a08001f    	tst	w0, w8
103de0cbc: 54fff1a0    	b.eq	0x103de0af0 <__v8_internal_Print_TransitionTree+0x198108>
103de0cc0: 17ffffb1    	b	0x103de0b84 <__v8_internal_Print_TransitionTree+0x19819c>
103de0cc4: aa1403e1    	mov	x1, x20
103de0cc8: 970a26f8    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de0ccc: aa0003e1    	mov	x1, x0
103de0cd0: 17ffffc9    	b	0x103de0bf4 <__v8_internal_Print_TransitionTree+0x19820c>
103de0cd4: 91000501    	add	x1, x8, #0x1
103de0cd8: aa1303e0    	mov	x0, x19
103de0cdc: f90007e8    	str	x8, [sp, #0x8]
103de0ce0: 97648084    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0ce4: f94007e8    	ldr	x8, [sp, #0x8]
103de0ce8: 529fc029    	mov	w9, #0xfe01             ; =65025
103de0cec: 6a09001f    	tst	w0, w9
103de0cf0: 54fff6a1    	b.ne	0x103de0bc4 <__v8_internal_Print_TransitionTree+0x1981dc>
103de0cf4: 17ffffb8    	b	0x103de0bd4 <__v8_internal_Print_TransitionTree+0x1981ec>
103de0cf8: 91000501    	add	x1, x8, #0x1
103de0cfc: aa1303e0    	mov	x0, x19
103de0d00: f90007e8    	str	x8, [sp, #0x8]
103de0d04: 9764807b    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0d08: f94007e8    	ldr	x8, [sp, #0x8]
103de0d0c: 529fc029    	mov	w9, #0xfe01             ; =65025
103de0d10: 6a09001f    	tst	w0, w9
103de0d14: 54fff881    	b.ne	0x103de0c24 <__v8_internal_Print_TransitionTree+0x19823c>
103de0d18: 17ffffc7    	b	0x103de0c34 <__v8_internal_Print_TransitionTree+0x19824c>
103de0d1c: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
103de0d20: a9014ff4    	stp	x20, x19, [sp, #0x10]
103de0d24: a9027bfd    	stp	x29, x30, [sp, #0x20]
103de0d28: 910083fd    	add	x29, sp, #0x20
103de0d2c: aa0103f4    	mov	x20, x1
103de0d30: aa0003f3    	mov	x19, x0
103de0d34: a941a015    	ldp	x21, x8, [x0, #0x18]
103de0d38: 910006b6    	add	x22, x21, #0x1
103de0d3c: eb0802df    	cmp	x22, x8
103de0d40: 54000568    	b.hi	0x103de0dec <__v8_internal_Print_TransitionTree+0x198404>
103de0d44: f9000e76    	str	x22, [x19, #0x18]
103de0d48: f9400a68    	ldr	x8, [x19, #0x10]
103de0d4c: 52800a49    	mov	w9, #0x52               ; =82
103de0d50: 38356909    	strb	w9, [x8, x21]
103de0d54: f9400288    	ldr	x8, [x20]
103de0d58: f9400269    	ldr	x9, [x19]
103de0d5c: 9940b108    	ldapur	w8, [x8, #0xb]
103de0d60: 53067d08    	lsr	w8, w8, #6
103de0d64: f9418929    	ldr	x9, [x9, #0x310]
103de0d68: 927d5908    	and	x8, x8, #0x3fffff8
103de0d6c: 8b080128    	add	x8, x9, x8
103de0d70: f8bfc108    	ldapr	x8, [x8]
103de0d74: d371fd09    	lsr	x9, x8, #49
103de0d78: f100253f    	cmp	x9, #0x9
103de0d7c: 54000461    	b.ne	0x103de0e08 <__v8_internal_Print_TransitionTree+0x198420>
103de0d80: 9240bd08    	and	x8, x8, #0xffffffffffff
103de0d84: b840f108    	ldur	w8, [x8, #0xf]
103de0d88: d0031d49    	adrp	x9, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
103de0d8c: f940a929    	ldr	x9, [x9, #0x150]
103de0d90: aa080128    	orr	x8, x9, x8
103de0d94: f9400260    	ldr	x0, [x19]
103de0d98: f9411401    	ldr	x1, [x0, #0x228]
103de0d9c: f9411809    	ldr	x9, [x0, #0x230]
103de0da0: eb09003f    	cmp	x1, x9
103de0da4: 540001c0    	b.eq	0x103de0ddc <__v8_internal_Print_TransitionTree+0x1983f4>
103de0da8: 91002029    	add	x9, x1, #0x8
103de0dac: f9011409    	str	x9, [x0, #0x228]
103de0db0: f9000028    	str	x8, [x1]
103de0db4: aa1303e0    	mov	x0, x19
103de0db8: 97647e98    	bl	0x101700818 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6d70>
103de0dbc: f9400288    	ldr	x8, [x20]
103de0dc0: b840f108    	ldur	w8, [x8, #0xf]
103de0dc4: 13017d01    	asr	w1, w8, #1
103de0dc8: aa1303e0    	mov	x0, x19
103de0dcc: a9427bfd    	ldp	x29, x30, [sp, #0x20]
103de0dd0: a9414ff4    	ldp	x20, x19, [sp, #0x10]
103de0dd4: a8c357f6    	ldp	x22, x21, [sp], #0x30
103de0dd8: 174905ea    	b	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de0ddc: aa0803e1    	mov	x1, x8
103de0de0: 970a26b2    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de0de4: aa0003e1    	mov	x1, x0
103de0de8: 17fffff3    	b	0x103de0db4 <__v8_internal_Print_TransitionTree+0x1983cc>
103de0dec: 910006a1    	add	x1, x21, #0x1
103de0df0: aa1303e0    	mov	x0, x19
103de0df4: 9764803f    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0df8: 529fc028    	mov	w8, #0xfe01             ; =65025
103de0dfc: 6a08001f    	tst	w0, w8
103de0e00: 54fffa21    	b.ne	0x103de0d44 <__v8_internal_Print_TransitionTree+0x19835c>
103de0e04: 17ffffd4    	b	0x103de0d54 <__v8_internal_Print_TransitionTree+0x19836c>
103de0e08: d4200000    	brk	#0
103de0e0c: d4400000    	hlt	#0
103de0e10: d4200020    	brk	#0x1
103de0e14: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
103de0e18: a9015ff8    	stp	x24, x23, [sp, #0x10]
103de0e1c: a90257f6    	stp	x22, x21, [sp, #0x20]
103de0e20: a9034ff4    	stp	x20, x19, [sp, #0x30]
103de0e24: a9047bfd    	stp	x29, x30, [sp, #0x40]
103de0e28: 910103fd    	add	x29, sp, #0x40
103de0e2c: aa0003f3    	mov	x19, x0
103de0e30: f9400028    	ldr	x8, [x1]
103de0e34: b840b108    	ldur	w8, [x8, #0xb]
103de0e38: d0031d57    	adrp	x23, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
103de0e3c: f940aae9    	ldr	x9, [x23, #0x150]
103de0e40: aa080121    	orr	x1, x9, x8
103de0e44: f9400000    	ldr	x0, [x0]
103de0e48: f9411416    	ldr	x22, [x0, #0x228]
103de0e4c: f9411808    	ldr	x8, [x0, #0x230]
103de0e50: eb0802df    	cmp	x22, x8
103de0e54: 540010e0    	b.eq	0x103de1070 <__v8_internal_Print_TransitionTree+0x198688>
103de0e58: 910022c8    	add	x8, x22, #0x8
103de0e5c: f9011408    	str	x8, [x0, #0x228]
103de0e60: f90002c1    	str	x1, [x22]
103de0e64: b8407038    	ldur	w24, [x1, #0x7]
103de0e68: 927f7b14    	and	x20, x24, #0xfffffffe
103de0e6c: f9400260    	ldr	x0, [x19]
103de0e70: 927f7b01    	and	x1, x24, #0xfffffffe
103de0e74: 52800002    	mov	w2, #0x0                ; =0
103de0e78: d2800003    	mov	x3, #0x0                ; =0
103de0e7c: 970d506e    	bl	0x100135034 <_cxxbridge1$slice$new+0xef558>
103de0e80: aa0003f5    	mov	x21, x0
103de0e84: f94002cb    	ldr	x11, [x22]
103de0e88: f9400008    	ldr	x8, [x0]
103de0e8c: b8407169    	ldur	w9, [x11, #0x7]
103de0e90: b840b16a    	ldur	w10, [x11, #0xb]
103de0e94: 13017d4a    	asr	w10, w10, #1
103de0e98: 2b89054c    	adds	w12, w10, w9, asr #1
103de0e9c: 540004e0    	b.eq	0x103de0f38 <__v8_internal_Print_TransitionTree+0x198550>
103de0ea0: 52800009    	mov	w9, #0x0                ; =0
103de0ea4: d100056a    	sub	x10, x11, #0x1
103de0ea8: 91001d6b    	add	x11, x11, #0x7
103de0eac: 93407d8c    	sxtw	x12, w12
103de0eb0: d100050d    	sub	x13, x8, #0x1
103de0eb4: 91001d0e    	add	x14, x8, #0x7
103de0eb8: 926eb5af    	and	x15, x13, #0xfffffffffffc0000
103de0ebc: 52800096    	mov	w22, #0x4               ; =4
103de0ec0: 529fffb9    	mov	w25, #0xfffd            ; =65533
103de0ec4: 72a000d9    	movk	w25, #0x6, lsl #16
103de0ec8: 1400000f    	b	0x103de0f04 <__v8_internal_Print_TransitionTree+0x19851c>
103de0ecc: 11000531    	add	w17, w9, #0x1
103de0ed0: 11000929    	add	w9, w9, #0x2
103de0ed4: b9401150    	ldr	w16, [x10, #0x10]
103de0ed8: f940aae8    	ldr	x8, [x23, #0x150]
103de0edc: 0b9006d0    	add	w16, w22, w16, asr #1
103de0ee0: b8705970    	ldr	w16, [x11, w16, uxtw #2]
103de0ee4: 8b3149c2    	add	x2, x14, w17, uxtw #2
103de0ee8: b9000050    	str	w16, [x2]
103de0eec: 36000070    	tbz	w16, #0x0, 0x103de0ef8 <__v8_internal_Print_TransitionTree+0x198510>
103de0ef0: 394001f1    	ldrb	w17, [x15]
103de0ef4: 371009f1    	tbnz	w17, #0x2, 0x103de1030 <__v8_internal_Print_TransitionTree+0x198648>
103de0ef8: 11000ed6    	add	w22, w22, #0x3
103de0efc: f100058c    	subs	x12, x12, #0x1
103de0f00: 540001c0    	b.eq	0x103de0f38 <__v8_internal_Print_TransitionTree+0x198550>
103de0f04: b9401150    	ldr	w16, [x10, #0x10]
103de0f08: f940aae8    	ldr	x8, [x23, #0x150]
103de0f0c: 0b9006d0    	add	w16, w22, w16, asr #1
103de0f10: 51000610    	sub	w16, w16, #0x1
103de0f14: b8705970    	ldr	w16, [x11, w16, uxtw #2]
103de0f18: 6b19021f    	cmp	w16, w25
103de0f1c: 54fffee0    	b.eq	0x103de0ef8 <__v8_internal_Print_TransitionTree+0x198510>
103de0f20: 8b2949c2    	add	x2, x14, w9, uxtw #2
103de0f24: b9000050    	str	w16, [x2]
103de0f28: 3607fd30    	tbz	w16, #0x0, 0x103de0ecc <__v8_internal_Print_TransitionTree+0x1984e4>
103de0f2c: 394001f1    	ldrb	w17, [x15]
103de0f30: 37100911    	tbnz	w17, #0x2, 0x103de1050 <__v8_internal_Print_TransitionTree+0x198668>
103de0f34: 17ffffe6    	b	0x103de0ecc <__v8_internal_Print_TransitionTree+0x1984e4>
103de0f38: a941a276    	ldp	x22, x8, [x19, #0x18]
103de0f3c: 910006d9    	add	x25, x22, #0x1
103de0f40: eb08033f    	cmp	x25, x8
103de0f44: 540009e8    	b.hi	0x103de1080 <__v8_internal_Print_TransitionTree+0x198698>
103de0f48: f9000e79    	str	x25, [x19, #0x18]
103de0f4c: f9400a68    	ldr	x8, [x19, #0x10]
103de0f50: 52800769    	mov	w9, #0x3b               ; =59
103de0f54: 38366909    	strb	w9, [x8, x22]
103de0f58: 71000b1f    	cmp	w24, #0x2
103de0f5c: 5400030b    	b.lt	0x103de0fbc <__v8_internal_Print_TransitionTree+0x1985d4>
103de0f60: 52800116    	mov	w22, #0x8               ; =8
103de0f64: 52802038    	mov	w24, #0x101             ; =257
103de0f68: aa1403f9    	mov	x25, x20
103de0f6c: f94002a8    	ldr	x8, [x21]
103de0f70: 8b160108    	add	x8, x8, x22
103de0f74: b85ff108    	ldur	w8, [x8, #-0x1]
103de0f78: f940aae9    	ldr	x9, [x23, #0x150]
103de0f7c: aa080128    	orr	x8, x9, x8
103de0f80: f9400260    	ldr	x0, [x19]
103de0f84: f9411401    	ldr	x1, [x0, #0x228]
103de0f88: f9411809    	ldr	x9, [x0, #0x230]
103de0f8c: eb09003f    	cmp	x1, x9
103de0f90: 54000480    	b.eq	0x103de1020 <__v8_internal_Print_TransitionTree+0x198638>
103de0f94: 91002029    	add	x9, x1, #0x8
103de0f98: f9011409    	str	x9, [x0, #0x228]
103de0f9c: f9000028    	str	x8, [x1]
103de0fa0: aa1303e0    	mov	x0, x19
103de0fa4: 97647d56    	bl	0x1017004fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a54>
103de0fa8: 6a20031f    	bics	wzr, w24, w0
103de0fac: 54000361    	b.ne	0x103de1018 <__v8_internal_Print_TransitionTree+0x198630>
103de0fb0: 910012d6    	add	x22, x22, #0x4
103de0fb4: f1000739    	subs	x25, x25, #0x1
103de0fb8: 54fffda1    	b.ne	0x103de0f6c <__v8_internal_Print_TransitionTree+0x198584>
103de0fbc: a941a275    	ldp	x21, x8, [x19, #0x18]
103de0fc0: 910006b6    	add	x22, x21, #0x1
103de0fc4: eb0802df    	cmp	x22, x8
103de0fc8: 540006a8    	b.hi	0x103de109c <__v8_internal_Print_TransitionTree+0x1986b4>
103de0fcc: f9000e76    	str	x22, [x19, #0x18]
103de0fd0: f9400a68    	ldr	x8, [x19, #0x10]
103de0fd4: 52800749    	mov	w9, #0x3a               ; =58
103de0fd8: 38356909    	strb	w9, [x8, x21]
103de0fdc: aa1303e0    	mov	x0, x19
103de0fe0: aa1403e1    	mov	x1, x20
103de0fe4: 97490567    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de0fe8: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de0fec: 35000108    	cbnz	w8, 0x103de100c <__v8_internal_Print_TransitionTree+0x198624>
103de0ff0: 52802020    	mov	w0, #0x101              ; =257
103de0ff4: a9447bfd    	ldp	x29, x30, [sp, #0x40]
103de0ff8: a9434ff4    	ldp	x20, x19, [sp, #0x30]
103de0ffc: a94257f6    	ldp	x22, x21, [sp, #0x20]
103de1000: a9415ff8    	ldp	x24, x23, [sp, #0x10]
103de1004: a8c567fa    	ldp	x26, x25, [sp], #0x50
103de1008: d65f03c0    	ret
103de100c: aa1303e0    	mov	x0, x19
103de1010: 52803b41    	mov	w1, #0x1da              ; =474
103de1014: 94000227    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de1018: 52800000    	mov	w0, #0x0                ; =0
103de101c: 17fffff6    	b	0x103de0ff4 <__v8_internal_Print_TransitionTree+0x19860c>
103de1020: aa0803e1    	mov	x1, x8
103de1024: 970a2621    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de1028: aa0003e1    	mov	x1, x0
103de102c: 17ffffdd    	b	0x103de0fa0 <__v8_internal_Print_TransitionTree+0x1985b8>
103de1030: aa100103    	orr	x3, x8, x16
103de1034: 926eb464    	and	x4, x3, #0xfffffffffffc0000
103de1038: 39400088    	ldrb	w8, [x4]
103de103c: 360ff5e8    	tbz	w8, #0x1, 0x103de0ef8 <__v8_internal_Print_TransitionTree+0x198510>
103de1040: b24001a0    	orr	x0, x13, #0x1
103de1044: 926eb5a1    	and	x1, x13, #0xfffffffffffc0000
103de1048: 9709c35e    	bl	0x100051dc0 <_cxxbridge1$slice$new+0xc2e4>
103de104c: 17ffffab    	b	0x103de0ef8 <__v8_internal_Print_TransitionTree+0x198510>
103de1050: aa100103    	orr	x3, x8, x16
103de1054: 926eb464    	and	x4, x3, #0xfffffffffffc0000
103de1058: 39400088    	ldrb	w8, [x4]
103de105c: 360ff388    	tbz	w8, #0x1, 0x103de0ecc <__v8_internal_Print_TransitionTree+0x1984e4>
103de1060: b24001a0    	orr	x0, x13, #0x1
103de1064: 926eb5a1    	and	x1, x13, #0xfffffffffffc0000
103de1068: 9709c356    	bl	0x100051dc0 <_cxxbridge1$slice$new+0xc2e4>
103de106c: 17ffff98    	b	0x103de0ecc <__v8_internal_Print_TransitionTree+0x1984e4>
103de1070: 970a260e    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de1074: aa0003f6    	mov	x22, x0
103de1078: f9400001    	ldr	x1, [x0]
103de107c: 17ffff7a    	b	0x103de0e64 <__v8_internal_Print_TransitionTree+0x19847c>
103de1080: 910006c1    	add	x1, x22, #0x1
103de1084: aa1303e0    	mov	x0, x19
103de1088: 97647f9a    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de108c: 529fc028    	mov	w8, #0xfe01             ; =65025
103de1090: 6a08001f    	tst	w0, w8
103de1094: 54fff5a1    	b.ne	0x103de0f48 <__v8_internal_Print_TransitionTree+0x198560>
103de1098: 17ffffb0    	b	0x103de0f58 <__v8_internal_Print_TransitionTree+0x198570>
103de109c: 910006a1    	add	x1, x21, #0x1
103de10a0: aa1303e0    	mov	x0, x19
103de10a4: 97647f93    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de10a8: 529fc028    	mov	w8, #0xfe01             ; =65025
103de10ac: 6a08001f    	tst	w0, w8
103de10b0: 54fff8e1    	b.ne	0x103de0fcc <__v8_internal_Print_TransitionTree+0x1985e4>
103de10b4: 17ffffca    	b	0x103de0fdc <__v8_internal_Print_TransitionTree+0x1985f4>
103de10b8: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
103de10bc: a9015ff8    	stp	x24, x23, [sp, #0x10]
103de10c0: a90257f6    	stp	x22, x21, [sp, #0x20]
103de10c4: a9034ff4    	stp	x20, x19, [sp, #0x30]
103de10c8: a9047bfd    	stp	x29, x30, [sp, #0x40]
103de10cc: 910103fd    	add	x29, sp, #0x40
103de10d0: aa0003f3    	mov	x19, x0
103de10d4: f9400028    	ldr	x8, [x1]
103de10d8: b840b108    	ldur	w8, [x8, #0xb]
103de10dc: b0031d57    	adrp	x23, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
103de10e0: f940aae9    	ldr	x9, [x23, #0x150]
103de10e4: aa080121    	orr	x1, x9, x8
103de10e8: f9400000    	ldr	x0, [x0]
103de10ec: f9411416    	ldr	x22, [x0, #0x228]
103de10f0: f9411808    	ldr	x8, [x0, #0x230]
103de10f4: eb0802df    	cmp	x22, x8
103de10f8: 54000ec0    	b.eq	0x103de12d0 <__v8_internal_Print_TransitionTree+0x1988e8>
103de10fc: 910022c8    	add	x8, x22, #0x8
103de1100: f9011408    	str	x8, [x0, #0x228]
103de1104: f90002c1    	str	x1, [x22]
103de1108: b8407028    	ldur	w8, [x1, #0x7]
103de110c: 13017d14    	asr	w20, w8, #1
103de1110: f9400260    	ldr	x0, [x19]
103de1114: aa1403e1    	mov	x1, x20
103de1118: 52800002    	mov	w2, #0x0                ; =0
103de111c: d2800003    	mov	x3, #0x0                ; =0
103de1120: 970d4fc5    	bl	0x100135034 <_cxxbridge1$slice$new+0xef558>
103de1124: aa0003f5    	mov	x21, x0
103de1128: f94002ca    	ldr	x10, [x22]
103de112c: f940000d    	ldr	x13, [x0]
103de1130: b8407148    	ldur	w8, [x10, #0x7]
103de1134: b840b149    	ldur	w9, [x10, #0xb]
103de1138: 13017d29    	asr	w9, w9, #1
103de113c: 2b88052b    	adds	w11, w9, w8, asr #1
103de1140: 540003c0    	b.eq	0x103de11b8 <__v8_internal_Print_TransitionTree+0x1987d0>
103de1144: 52800008    	mov	w8, #0x0                ; =0
103de1148: d1000549    	sub	x9, x10, #0x1
103de114c: 91001d4a    	add	x10, x10, #0x7
103de1150: 93407d6b    	sxtw	x11, w11
103de1154: d10005ac    	sub	x12, x13, #0x1
103de1158: 91001dad    	add	x13, x13, #0x7
103de115c: 926eb58e    	and	x14, x12, #0xfffffffffffc0000
103de1160: 5280006f    	mov	w15, #0x3               ; =3
103de1164: 529fffb6    	mov	w22, #0xfffd            ; =65533
103de1168: 72a000d6    	movk	w22, #0x6, lsl #16
103de116c: 14000006    	b	0x103de1184 <__v8_internal_Print_TransitionTree+0x19879c>
103de1170: aa0803f8    	mov	x24, x8
103de1174: 110009ef    	add	w15, w15, #0x2
103de1178: aa1803e8    	mov	x8, x24
103de117c: f100056b    	subs	x11, x11, #0x1
103de1180: 540001c0    	b.eq	0x103de11b8 <__v8_internal_Print_TransitionTree+0x1987d0>
103de1184: b9401131    	ldr	w17, [x9, #0x10]
103de1188: f940aaf0    	ldr	x16, [x23, #0x150]
103de118c: 0b9105f1    	add	w17, w15, w17, asr #1
103de1190: b8715951    	ldr	w17, [x10, w17, uxtw #2]
103de1194: 6b16023f    	cmp	w17, w22
103de1198: 54fffec0    	b.eq	0x103de1170 <__v8_internal_Print_TransitionTree+0x198788>
103de119c: 11000518    	add	w24, w8, #0x1
103de11a0: 8b2849a2    	add	x2, x13, w8, uxtw #2
103de11a4: b9000051    	str	w17, [x2]
103de11a8: 3607fe71    	tbz	w17, #0x0, 0x103de1174 <__v8_internal_Print_TransitionTree+0x19878c>
103de11ac: 394001c8    	ldrb	w8, [x14]
103de11b0: 3617fe28    	tbz	w8, #0x2, 0x103de1174 <__v8_internal_Print_TransitionTree+0x19878c>
103de11b4: 1400003f    	b	0x103de12b0 <__v8_internal_Print_TransitionTree+0x1988c8>
103de11b8: a941a276    	ldp	x22, x8, [x19, #0x18]
103de11bc: 910006d8    	add	x24, x22, #0x1
103de11c0: eb08031f    	cmp	x24, x8
103de11c4: 540008e8    	b.hi	0x103de12e0 <__v8_internal_Print_TransitionTree+0x1988f8>
103de11c8: f9000e78    	str	x24, [x19, #0x18]
103de11cc: f9400a68    	ldr	x8, [x19, #0x10]
103de11d0: 528004e9    	mov	w9, #0x27               ; =39
103de11d4: 38366909    	strb	w9, [x8, x22]
103de11d8: 7100069f    	cmp	w20, #0x1
103de11dc: 5400030b    	b.lt	0x103de123c <__v8_internal_Print_TransitionTree+0x198854>
103de11e0: 52800116    	mov	w22, #0x8               ; =8
103de11e4: 52802038    	mov	w24, #0x101             ; =257
103de11e8: aa1403f9    	mov	x25, x20
103de11ec: f94002a8    	ldr	x8, [x21]
103de11f0: 8b160108    	add	x8, x8, x22
103de11f4: b85ff108    	ldur	w8, [x8, #-0x1]
103de11f8: f940aae9    	ldr	x9, [x23, #0x150]
103de11fc: aa080128    	orr	x8, x9, x8
103de1200: f9400260    	ldr	x0, [x19]
103de1204: f9411401    	ldr	x1, [x0, #0x228]
103de1208: f9411809    	ldr	x9, [x0, #0x230]
103de120c: eb09003f    	cmp	x1, x9
103de1210: 54000480    	b.eq	0x103de12a0 <__v8_internal_Print_TransitionTree+0x1988b8>
103de1214: 91002029    	add	x9, x1, #0x8
103de1218: f9011409    	str	x9, [x0, #0x228]
103de121c: f9000028    	str	x8, [x1]
103de1220: aa1303e0    	mov	x0, x19
103de1224: 97647cb6    	bl	0x1017004fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a54>
103de1228: 6a20031f    	bics	wzr, w24, w0
103de122c: 54000361    	b.ne	0x103de1298 <__v8_internal_Print_TransitionTree+0x1988b0>
103de1230: 910012d6    	add	x22, x22, #0x4
103de1234: f1000739    	subs	x25, x25, #0x1
103de1238: 54fffda1    	b.ne	0x103de11ec <__v8_internal_Print_TransitionTree+0x198804>
103de123c: a941a275    	ldp	x21, x8, [x19, #0x18]
103de1240: 910006b6    	add	x22, x21, #0x1
103de1244: eb0802df    	cmp	x22, x8
103de1248: 540005a8    	b.hi	0x103de12fc <__v8_internal_Print_TransitionTree+0x198914>
103de124c: f9000e76    	str	x22, [x19, #0x18]
103de1250: f9400a68    	ldr	x8, [x19, #0x10]
103de1254: 52800589    	mov	w9, #0x2c               ; =44
103de1258: 38356909    	strb	w9, [x8, x21]
103de125c: aa1303e0    	mov	x0, x19
103de1260: aa1403e1    	mov	x1, x20
103de1264: 974904c7    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de1268: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de126c: 35000108    	cbnz	w8, 0x103de128c <__v8_internal_Print_TransitionTree+0x1988a4>
103de1270: 52802020    	mov	w0, #0x101              ; =257
103de1274: a9447bfd    	ldp	x29, x30, [sp, #0x40]
103de1278: a9434ff4    	ldp	x20, x19, [sp, #0x30]
103de127c: a94257f6    	ldp	x22, x21, [sp, #0x20]
103de1280: a9415ff8    	ldp	x24, x23, [sp, #0x10]
103de1284: a8c567fa    	ldp	x26, x25, [sp], #0x50
103de1288: d65f03c0    	ret
103de128c: aa1303e0    	mov	x0, x19
103de1290: 52803b41    	mov	w1, #0x1da              ; =474
103de1294: 94000187    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de1298: 52800000    	mov	w0, #0x0                ; =0
103de129c: 17fffff6    	b	0x103de1274 <__v8_internal_Print_TransitionTree+0x19888c>
103de12a0: aa0803e1    	mov	x1, x8
103de12a4: 970a2581    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de12a8: aa0003e1    	mov	x1, x0
103de12ac: 17ffffdd    	b	0x103de1220 <__v8_internal_Print_TransitionTree+0x198838>
103de12b0: aa110203    	orr	x3, x16, x17
103de12b4: 926eb464    	and	x4, x3, #0xfffffffffffc0000
103de12b8: 39400088    	ldrb	w8, [x4]
103de12bc: 360ff5c8    	tbz	w8, #0x1, 0x103de1174 <__v8_internal_Print_TransitionTree+0x19878c>
103de12c0: b2400180    	orr	x0, x12, #0x1
103de12c4: 926eb581    	and	x1, x12, #0xfffffffffffc0000
103de12c8: 9709c2be    	bl	0x100051dc0 <_cxxbridge1$slice$new+0xc2e4>
103de12cc: 17ffffaa    	b	0x103de1174 <__v8_internal_Print_TransitionTree+0x19878c>
103de12d0: 970a2576    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de12d4: aa0003f6    	mov	x22, x0
103de12d8: f9400001    	ldr	x1, [x0]
103de12dc: 17ffff8b    	b	0x103de1108 <__v8_internal_Print_TransitionTree+0x198720>
103de12e0: 910006c1    	add	x1, x22, #0x1
103de12e4: aa1303e0    	mov	x0, x19
103de12e8: 97647f02    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de12ec: 529fc028    	mov	w8, #0xfe01             ; =65025
103de12f0: 6a08001f    	tst	w0, w8
103de12f4: 54fff6a1    	b.ne	0x103de11c8 <__v8_internal_Print_TransitionTree+0x1987e0>
103de12f8: 17ffffb8    	b	0x103de11d8 <__v8_internal_Print_TransitionTree+0x1987f0>
103de12fc: 910006a1    	add	x1, x21, #0x1
103de1300: aa1303e0    	mov	x0, x19
103de1304: 97647efb    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de1308: 529fc028    	mov	w8, #0xfe01             ; =65025
103de130c: 6a08001f    	tst	w0, w8
103de1310: 54fff9e1    	b.ne	0x103de124c <__v8_internal_Print_TransitionTree+0x198864>
103de1314: 17ffffd2    	b	0x103de125c <__v8_internal_Print_TransitionTree+0x198874>
103de1318: d10143ff    	sub	sp, sp, #0x50
103de131c: a9015ff8    	stp	x24, x23, [sp, #0x10]
103de1320: a90257f6    	stp	x22, x21, [sp, #0x20]
103de1324: a9034ff4    	stp	x20, x19, [sp, #0x30]
103de1328: a9047bfd    	stp	x29, x30, [sp, #0x40]
103de132c: 910103fd    	add	x29, sp, #0x40
103de1330: aa0103f4    	mov	x20, x1
103de1334: aa0003f3    	mov	x19, x0
103de1338: f9400021    	ldr	x1, [x1]
103de133c: b842f028    	ldur	w8, [x1, #0x2f]
103de1340: 371803e8    	tbnz	w8, #0x3, 0x103de13bc <__v8_internal_Print_TransitionTree+0x1989d4>
103de1344: 91030260    	add	x0, x19, #0xc0
103de1348: 970dbeae    	bl	0x100150e00 <_cxxbridge1$slice$new+0x10b324>
103de134c: b40004c0    	cbz	x0, 0x103de13e4 <__v8_internal_Print_TransitionTree+0x1989fc>
103de1350: aa0003f5    	mov	x21, x0
103de1354: a941a274    	ldp	x20, x8, [x19, #0x18]
103de1358: 91000696    	add	x22, x20, #0x1
103de135c: eb0802df    	cmp	x22, x8
103de1360: 540022c8    	b.hi	0x103de17b8 <__v8_internal_Print_TransitionTree+0x198dd0>
103de1364: f9000e76    	str	x22, [x19, #0x18]
103de1368: f9400a68    	ldr	x8, [x19, #0x10]
103de136c: 52800e89    	mov	w9, #0x74               ; =116
103de1370: 38346909    	strb	w9, [x8, x20]
103de1374: b94002a1    	ldr	w1, [x21]
103de1378: aa1303e0    	mov	x0, x19
103de137c: 97490481    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de1380: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de1384: 35000128    	cbnz	w8, 0x103de13a8 <__v8_internal_Print_TransitionTree+0x1989c0>
103de1388: 52802036    	mov	w22, #0x101             ; =257
103de138c: aa1603e0    	mov	x0, x22
103de1390: a9447bfd    	ldp	x29, x30, [sp, #0x40]
103de1394: a9434ff4    	ldp	x20, x19, [sp, #0x30]
103de1398: a94257f6    	ldp	x22, x21, [sp, #0x20]
103de139c: a9415ff8    	ldp	x24, x23, [sp, #0x10]
103de13a0: 910143ff    	add	sp, sp, #0x50
103de13a4: d65f03c0    	ret
103de13a8: aa1303e0    	mov	x0, x19
103de13ac: 52803b41    	mov	w1, #0x1da              ; =474
103de13b0: 94000140    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de13b4: 52800016    	mov	w22, #0x0               ; =0
103de13b8: 17fffff5    	b	0x103de138c <__v8_internal_Print_TransitionTree+0x1989a4>
103de13bc: f9400660    	ldr	x0, [x19, #0x8]
103de13c0: b5001280    	cbnz	x0, 0x103de1610 <__v8_internal_Print_TransitionTree+0x198c28>
103de13c4: aa1303e0    	mov	x0, x19
103de13c8: 52803b21    	mov	w1, #0x1d9              ; =473
103de13cc: aa1403e2    	mov	x2, x20
103de13d0: 97fffcde    	bl	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
103de13d4: 17fffff8    	b	0x103de13b4 <__v8_internal_Print_TransitionTree+0x1989cc>
103de13d8: aa1303e0    	mov	x0, x19
103de13dc: 52803b61    	mov	w1, #0x1db              ; =475
103de13e0: 17fffff4    	b	0x103de13b0 <__v8_internal_Print_TransitionTree+0x1989c8>
103de13e4: f9400288    	ldr	x8, [x20]
103de13e8: b842f109    	ldur	w9, [x8, #0x2f]
103de13ec: 3717ff69    	tbnz	w9, #0x2, 0x103de13d8 <__v8_internal_Print_TransitionTree+0x1989f0>
103de13f0: f8413109    	ldur	x9, [x8, #0x13]
103de13f4: d37dfd2a    	lsr	x10, x9, #61
103de13f8: b5fffe6a    	cbnz	x10, 0x103de13c4 <__v8_internal_Print_TransitionTree+0x1989dc>
103de13fc: d35dfd35    	lsr	x21, x9, #29
103de1400: b842f109    	ldur	w9, [x8, #0x2f]
103de1404: 37200e69    	tbnz	w9, #0x4, 0x103de15d0 <__v8_internal_Print_TransitionTree+0x198be8>
103de1408: b842f109    	ldur	w9, [x8, #0x2f]
103de140c: 36280ca9    	tbz	w9, #0x5, 0x103de15a0 <__v8_internal_Print_TransitionTree+0x198bb8>
103de1410: b9411269    	ldr	w9, [x19, #0x110]
103de1414: 7100053f    	cmp	w9, #0x1
103de1418: 540008e1    	b.ne	0x103de1534 <__v8_internal_Print_TransitionTree+0x198b4c>
103de141c: f0030ae9    	adrp	x9, 0x109f40000 <dyld_stub_binder+0x109f40000>
103de1420: 3940cd29    	ldrb	w9, [x9, #0x33]
103de1424: 36000889    	tbz	w9, #0x0, 0x103de1534 <__v8_internal_Print_TransitionTree+0x198b4c>
103de1428: f0030f80    	adrp	x0, 0x109fd4000 <dyld_stub_binder+0x109fd4000>
103de142c: 9129a000    	add	x0, x0, #0xa68
103de1430: f9400009    	ldr	x9, [x0]
103de1434: d63f0120    	blr	x9
103de1438: f9400009    	ldr	x9, [x0]
103de143c: b842b108    	ldur	w8, [x8, #0x2b]
103de1440: 53037d08    	lsr	w8, w8, #3
103de1444: f9416929    	ldr	x9, [x9, #0x2d0]
103de1448: 927d6508    	and	x8, x8, #0x1ffffff8
103de144c: f8686928    	ldr	x8, [x9, x8]
103de1450: 924f1909    	and	x9, x8, #0xfe000000000000
103de1454: 9248dd08    	and	x8, x8, #0xff00ffffffffffff
103de1458: d2e016ca    	mov	x10, #0xb6000000000000  ; =51228445761339392
103de145c: eb0a013f    	cmp	x9, x10
103de1460: fa400904    	ccmp	x8, #0x0, #0x4, eq
103de1464: 54000680    	b.eq	0x103de1534 <__v8_internal_Print_TransitionTree+0x198b4c>
103de1468: a9415d18    	ldp	x24, x23, [x8, #0x10]
103de146c: b4000097    	cbz	x23, 0x103de147c <__v8_internal_Print_TransitionTree+0x198a94>
103de1470: 910022e8    	add	x8, x23, #0x8
103de1474: 52800029    	mov	w9, #0x1                ; =1
103de1478: f8290108    	ldadd	x9, x8, [x8]
103de147c: a9005ff8    	stp	x24, x23, [sp]
103de1480: b4000218    	cbz	x24, 0x103de14c0 <__v8_internal_Print_TransitionTree+0x198ad8>
103de1484: f9409276    	ldr	x22, [x19, #0x120]
103de1488: d37ceec8    	lsl	x8, x22, #4
103de148c: b4000128    	cbz	x8, 0x103de14b0 <__v8_internal_Print_TransitionTree+0x198ac8>
103de1490: d2800009    	mov	x9, #0x0                ; =0
103de1494: f9408e6a    	ldr	x10, [x19, #0x118]
103de1498: f869694b    	ldr	x11, [x10, x9]
103de149c: eb18017f    	cmp	x11, x24
103de14a0: 54000120    	b.eq	0x103de14c4 <__v8_internal_Print_TransitionTree+0x198adc>
103de14a4: 91004129    	add	x9, x9, #0x10
103de14a8: eb09011f    	cmp	x8, x9
103de14ac: 54ffff61    	b.ne	0x103de1498 <__v8_internal_Print_TransitionTree+0x198ab0>
103de14b0: 91046260    	add	x0, x19, #0x118
103de14b4: 910003e1    	mov	x1, sp
103de14b8: 94001053    	bl	0x103de5604 <__v8_internal_Print_TransitionTree+0x19cc1c>
103de14bc: 14000003    	b	0x103de14c8 <__v8_internal_Print_TransitionTree+0x198ae0>
103de14c0: 14000011    	b	0x103de1504 <__v8_internal_Print_TransitionTree+0x198b1c>
103de14c4: 9344fd36    	asr	x22, x9, #4
103de14c8: a941a677    	ldp	x23, x9, [x19, #0x18]
103de14cc: 910006e8    	add	x8, x23, #0x1
103de14d0: eb09011f    	cmp	x8, x9
103de14d4: 54001808    	b.hi	0x103de17d4 <__v8_internal_Print_TransitionTree+0x198dec>
103de14d8: f9000e68    	str	x8, [x19, #0x18]
103de14dc: f9400a68    	ldr	x8, [x19, #0x10]
103de14e0: 528008a9    	mov	w9, #0x45               ; =69
103de14e4: 38376909    	strb	w9, [x8, x23]
103de14e8: aa1303e0    	mov	x0, x19
103de14ec: aa1603e1    	mov	x1, x22
103de14f0: 97490424    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de14f4: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de14f8: 35000628    	cbnz	w8, 0x103de15bc <__v8_internal_Print_TransitionTree+0x198bd4>
103de14fc: 52802036    	mov	w22, #0x101             ; =257
103de1500: f94007f7    	ldr	x23, [sp, #0x8]
103de1504: b4000177    	cbz	x23, 0x103de1530 <__v8_internal_Print_TransitionTree+0x198b48>
103de1508: 910022e8    	add	x8, x23, #0x8
103de150c: 92800009    	mov	x9, #-0x1               ; =-1
103de1510: f8e90108    	ldaddal	x9, x8, [x8]
103de1514: b50000e8    	cbnz	x8, 0x103de1530 <__v8_internal_Print_TransitionTree+0x198b48>
103de1518: f94002e8    	ldr	x8, [x23]
103de151c: f9400908    	ldr	x8, [x8, #0x10]
103de1520: aa1703e0    	mov	x0, x23
103de1524: d63f0100    	blr	x8
103de1528: aa1703e0    	mov	x0, x23
103de152c: 9786babd    	bl	0x101f90020 <_rust_png$cxxbridge1$199$Reader$has_trns_chunk+0x4800>
103de1530: b5fff2f8    	cbnz	x24, 0x103de138c <__v8_internal_Print_TransitionTree+0x1989a4>
103de1534: a941a276    	ldp	x22, x8, [x19, #0x18]
103de1538: 910006d7    	add	x23, x22, #0x1
103de153c: eb0802ff    	cmp	x23, x8
103de1540: 54001688    	b.hi	0x103de1810 <__v8_internal_Print_TransitionTree+0x198e28>
103de1544: f9000e77    	str	x23, [x19, #0x18]
103de1548: 52800868    	mov	w8, #0x43               ; =67
103de154c: f9400a69    	ldr	x9, [x19, #0x10]
103de1550: 38366928    	strb	w8, [x9, x22]
103de1554: aa1303e0    	mov	x0, x19
103de1558: aa1503e1    	mov	x1, x21
103de155c: 97fffc21    	bl	0x103de05e0 <__v8_internal_Print_TransitionTree+0x197bf8>
103de1560: f9400297    	ldr	x23, [x20]
103de1564: f84232f6    	ldur	x22, [x23, #0x23]
103de1568: a941a274    	ldp	x20, x8, [x19, #0x18]
103de156c: 8b150298    	add	x24, x20, x21
103de1570: eb08031f    	cmp	x24, x8
103de1574: 54001408    	b.hi	0x103de17f4 <__v8_internal_Print_TransitionTree+0x198e0c>
103de1578: f9000e78    	str	x24, [x19, #0x18]
103de157c: b4fff035    	cbz	x21, 0x103de1380 <__v8_internal_Print_TransitionTree+0x198998>
103de1580: d10006e8    	sub	x8, x23, #0x1
103de1584: 92607d08    	and	x8, x8, #0xffffffff00000000
103de1588: 8b566101    	add	x1, x8, x22, lsr #24
103de158c: f9400a68    	ldr	x8, [x19, #0x10]
103de1590: 8b140100    	add	x0, x8, x20
103de1594: aa1503e2    	mov	x2, x21
103de1598: 9539db04    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
103de159c: 17ffff79    	b	0x103de1380 <__v8_internal_Print_TransitionTree+0x198998>
103de15a0: a941a276    	ldp	x22, x8, [x19, #0x18]
103de15a4: 910006d7    	add	x23, x22, #0x1
103de15a8: eb0802ff    	cmp	x23, x8
103de15ac: 540014e8    	b.hi	0x103de1848 <__v8_internal_Print_TransitionTree+0x198e60>
103de15b0: f9000e77    	str	x23, [x19, #0x18]
103de15b4: 52800848    	mov	w8, #0x42               ; =66
103de15b8: 17ffffe5    	b	0x103de154c <__v8_internal_Print_TransitionTree+0x198b64>
103de15bc: aa1303e0    	mov	x0, x19
103de15c0: 52803b41    	mov	w1, #0x1da              ; =474
103de15c4: 940000bb    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de15c8: 52800016    	mov	w22, #0x0               ; =0
103de15cc: 17ffffcd    	b	0x103de1500 <__v8_internal_Print_TransitionTree+0x198b18>
103de15d0: a941a276    	ldp	x22, x8, [x19, #0x18]
103de15d4: 910006d7    	add	x23, x22, #0x1
103de15d8: eb0802ff    	cmp	x23, x8
103de15dc: 54001288    	b.hi	0x103de182c <__v8_internal_Print_TransitionTree+0x198e44>
103de15e0: f9000e77    	str	x23, [x19, #0x18]
103de15e4: f9400a68    	ldr	x8, [x19, #0x10]
103de15e8: 52800fc9    	mov	w9, #0x7e               ; =126
103de15ec: 38366909    	strb	w9, [x8, x22]
103de15f0: aa1303e0    	mov	x0, x19
103de15f4: aa1503e1    	mov	x1, x21
103de15f8: 97fffbfa    	bl	0x103de05e0 <__v8_internal_Print_TransitionTree+0x197bf8>
103de15fc: f9400288    	ldr	x8, [x20]
103de1600: f841b108    	ldur	x8, [x8, #0x1b]
103de1604: d35dfd01    	lsr	x1, x8, #29
103de1608: aa1303e0    	mov	x0, x19
103de160c: 17ffffd4    	b	0x103de155c <__v8_internal_Print_TransitionTree+0x198b74>
103de1610: f9400261    	ldr	x1, [x19]
103de1614: aa1403e2    	mov	x2, x20
103de1618: 94ce3b78    	bl	0x1071703f8 <__Z23_v8_internal_Node_PrintPv+0x3060dcc>
103de161c: f9400268    	ldr	x8, [x19]
103de1620: b9417908    	ldr	w8, [x8, #0x178]
103de1624: 5140bd08    	sub	w8, w8, #0x2f, lsl #12  ; =0x2f000
103de1628: 713ff51f    	cmp	w8, #0xffd
103de162c: 54ffec41    	b.ne	0x103de13b4 <__v8_internal_Print_TransitionTree+0x1989cc>
103de1630: aa0003f6    	mov	x22, x0
103de1634: d360fc15    	lsr	x21, x0, #32
103de1638: a941a277    	ldp	x23, x8, [x19, #0x18]
103de163c: 910006f8    	add	x24, x23, #0x1
103de1640: eb08031f    	cmp	x24, x8
103de1644: 540011c8    	b.hi	0x103de187c <__v8_internal_Print_TransitionTree+0x198e94>
103de1648: f9000e78    	str	x24, [x19, #0x18]
103de164c: f9400a68    	ldr	x8, [x19, #0x10]
103de1650: 52800ea9    	mov	w9, #0x75               ; =117
103de1654: 38376909    	strb	w9, [x8, x23]
103de1658: 36001076    	tbz	w22, #0x0, 0x103de1864 <__v8_internal_Print_TransitionTree+0x198e7c>
103de165c: aa1303e0    	mov	x0, x19
103de1660: aa1503e1    	mov	x1, x21
103de1664: 974903c7    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de1668: f9400288    	ldr	x8, [x20]
103de166c: f0030f80    	adrp	x0, 0x109fd4000 <dyld_stub_binder+0x109fd4000>
103de1670: 9129a000    	add	x0, x0, #0xa68
103de1674: f9400009    	ldr	x9, [x0]
103de1678: d63f0120    	blr	x9
103de167c: f9400009    	ldr	x9, [x0]
103de1680: b842b108    	ldur	w8, [x8, #0x2b]
103de1684: 53037d08    	lsr	w8, w8, #3
103de1688: f9416929    	ldr	x9, [x9, #0x2d0]
103de168c: 927d6508    	and	x8, x8, #0x1ffffff8
103de1690: f8686928    	ldr	x8, [x9, x8]
103de1694: 924f190a    	and	x10, x8, #0xfe000000000000
103de1698: f248dd09    	ands	x9, x8, #0xff00ffffffffffff
103de169c: d2e016c8    	mov	x8, #0xb6000000000000   ; =51228445761339392
103de16a0: fa481140    	ccmp	x10, x8, #0x0, ne
103de16a4: 54000141    	b.ne	0x103de16cc <__v8_internal_Print_TransitionTree+0x198ce4>
103de16a8: a9415528    	ldp	x8, x21, [x9, #0x10]
103de16ac: b4000095    	cbz	x21, 0x103de16bc <__v8_internal_Print_TransitionTree+0x198cd4>
103de16b0: 910022a9    	add	x9, x21, #0x8
103de16b4: 5280002a    	mov	w10, #0x1               ; =1
103de16b8: f82a0129    	ldadd	x10, x9, [x9]
103de16bc: b40000a8    	cbz	x8, 0x103de16d0 <__v8_internal_Print_TransitionTree+0x198ce8>
103de16c0: 79409108    	ldrh	w8, [x8, #0x48]
103de16c4: 36180068    	tbz	w8, #0x3, 0x103de16d0 <__v8_internal_Print_TransitionTree+0x198ce8>
103de16c8: 14000011    	b	0x103de170c <__v8_internal_Print_TransitionTree+0x198d24>
103de16cc: d2800015    	mov	x21, #0x0               ; =0
103de16d0: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de16d4: 35000688    	cbnz	w8, 0x103de17a4 <__v8_internal_Print_TransitionTree+0x198dbc>
103de16d8: 52802036    	mov	w22, #0x101             ; =257
103de16dc: b4ffe595    	cbz	x21, 0x103de138c <__v8_internal_Print_TransitionTree+0x1989a4>
103de16e0: 910022a8    	add	x8, x21, #0x8
103de16e4: 92800009    	mov	x9, #-0x1               ; =-1
103de16e8: f8e90108    	ldaddal	x9, x8, [x8]
103de16ec: b5ffe508    	cbnz	x8, 0x103de138c <__v8_internal_Print_TransitionTree+0x1989a4>
103de16f0: f94002a8    	ldr	x8, [x21]
103de16f4: f9400908    	ldr	x8, [x8, #0x10]
103de16f8: aa1503e0    	mov	x0, x21
103de16fc: d63f0100    	blr	x8
103de1700: aa1503e0    	mov	x0, x21
103de1704: 9786ba47    	bl	0x101f90020 <_rust_png$cxxbridge1$199$Reader$has_trns_chunk+0x4800>
103de1708: 17ffff21    	b	0x103de138c <__v8_internal_Print_TransitionTree+0x1989a4>
103de170c: f9400288    	ldr	x8, [x20]
103de1710: b842f108    	ldur	w8, [x8, #0x2f]
103de1714: 37200148    	tbnz	w8, #0x4, 0x103de173c <__v8_internal_Print_TransitionTree+0x198d54>
103de1718: aa1303e0    	mov	x0, x19
103de171c: 52800cc1    	mov	w1, #0x66               ; =102
103de1720: 94000294    	bl	0x103de2170 <__v8_internal_Print_TransitionTree+0x199788>
103de1724: f9400288    	ldr	x8, [x20]
103de1728: f8413108    	ldur	x8, [x8, #0x13]
103de172c: d35dfd01    	lsr	x1, x8, #29
103de1730: aa1303e0    	mov	x0, x19
103de1734: 97fffbab    	bl	0x103de05e0 <__v8_internal_Print_TransitionTree+0x197bf8>
103de1738: 17ffffe6    	b	0x103de16d0 <__v8_internal_Print_TransitionTree+0x198ce8>
103de173c: f9400260    	ldr	x0, [x19]
103de1740: 52841508    	mov	w8, #0x20a8             ; =8360
103de1744: 8b080002    	add	x2, x0, x8
103de1748: aa1403e1    	mov	x1, x20
103de174c: 97b50886    	bl	0x102b23964 <_rust_png$cxxbridge1$199$new_writer+0x1b71e4>
103de1750: b4000aa0    	cbz	x0, 0x103de18a4 <__v8_internal_Print_TransitionTree+0x198ebc>
103de1754: aa0003f4    	mov	x20, x0
103de1758: f9400008    	ldr	x8, [x0]
103de175c: 360009e8    	tbz	w8, #0x0, 0x103de1898 <__v8_internal_Print_TransitionTree+0x198eb0>
103de1760: b85ff108    	ldur	w8, [x8, #-0x1]
103de1764: b0031d49    	adrp	x9, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
103de1768: f940a929    	ldr	x9, [x9, #0x150]
103de176c: aa080128    	orr	x8, x9, x8
103de1770: 78407108    	ldurh	w8, [x8, #0x7]
103de1774: 7121d11f    	cmp	w8, #0x874
103de1778: 54000901    	b.ne	0x103de1898 <__v8_internal_Print_TransitionTree+0x198eb0>
103de177c: aa1303e0    	mov	x0, x19
103de1780: 52800e41    	mov	w1, #0x72               ; =114
103de1784: 9400027b    	bl	0x103de2170 <__v8_internal_Print_TransitionTree+0x199788>
103de1788: aa1303e0    	mov	x0, x19
103de178c: aa1403e1    	mov	x1, x20
103de1790: 976475e8    	bl	0x1016fef30 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5488>
103de1794: 52802028    	mov	w8, #0x101              ; =257
103de1798: 6a20011f    	bics	wzr, w8, w0
103de179c: 54fff9a0    	b.eq	0x103de16d0 <__v8_internal_Print_TransitionTree+0x198ce8>
103de17a0: 14000004    	b	0x103de17b0 <__v8_internal_Print_TransitionTree+0x198dc8>
103de17a4: aa1303e0    	mov	x0, x19
103de17a8: 52803b41    	mov	w1, #0x1da              ; =474
103de17ac: 94000041    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de17b0: 52800016    	mov	w22, #0x0               ; =0
103de17b4: 17ffffca    	b	0x103de16dc <__v8_internal_Print_TransitionTree+0x198cf4>
103de17b8: 91000681    	add	x1, x20, #0x1
103de17bc: aa1303e0    	mov	x0, x19
103de17c0: 97647dcc    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de17c4: 529fc028    	mov	w8, #0xfe01             ; =65025
103de17c8: 6a08001f    	tst	w0, w8
103de17cc: 54ffdcc1    	b.ne	0x103de1364 <__v8_internal_Print_TransitionTree+0x19897c>
103de17d0: 17fffee9    	b	0x103de1374 <__v8_internal_Print_TransitionTree+0x19898c>
103de17d4: 910006e1    	add	x1, x23, #0x1
103de17d8: aa1303e0    	mov	x0, x19
103de17dc: 97647dc5    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de17e0: 910006e8    	add	x8, x23, #0x1
103de17e4: 529fc029    	mov	w9, #0xfe01             ; =65025
103de17e8: 6a09001f    	tst	w0, w9
103de17ec: 54ffe761    	b.ne	0x103de14d8 <__v8_internal_Print_TransitionTree+0x198af0>
103de17f0: 17ffff3e    	b	0x103de14e8 <__v8_internal_Print_TransitionTree+0x198b00>
103de17f4: 8b150281    	add	x1, x20, x21
103de17f8: aa1303e0    	mov	x0, x19
103de17fc: 97647dbd    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de1800: 529fc028    	mov	w8, #0xfe01             ; =65025
103de1804: 6a08001f    	tst	w0, w8
103de1808: 54ffdbc0    	b.eq	0x103de1380 <__v8_internal_Print_TransitionTree+0x198998>
103de180c: 17ffff5b    	b	0x103de1578 <__v8_internal_Print_TransitionTree+0x198b90>
103de1810: 910006c1    	add	x1, x22, #0x1
103de1814: aa1303e0    	mov	x0, x19
103de1818: 97647db6    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de181c: 529fc028    	mov	w8, #0xfe01             ; =65025
103de1820: 6a08001f    	tst	w0, w8
103de1824: 54ffe901    	b.ne	0x103de1544 <__v8_internal_Print_TransitionTree+0x198b5c>
103de1828: 17ffff4b    	b	0x103de1554 <__v8_internal_Print_TransitionTree+0x198b6c>
103de182c: 910006c1    	add	x1, x22, #0x1
103de1830: aa1303e0    	mov	x0, x19
103de1834: 97647daf    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de1838: 529fc028    	mov	w8, #0xfe01             ; =65025
103de183c: 6a08001f    	tst	w0, w8
103de1840: 54ffed01    	b.ne	0x103de15e0 <__v8_internal_Print_TransitionTree+0x198bf8>
103de1844: 17ffff6b    	b	0x103de15f0 <__v8_internal_Print_TransitionTree+0x198c08>
103de1848: 910006c1    	add	x1, x22, #0x1
103de184c: aa1303e0    	mov	x0, x19
103de1850: 97647da8    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de1854: 529fc028    	mov	w8, #0xfe01             ; =65025
103de1858: 6a08001f    	tst	w0, w8
103de185c: 54ffe7c0    	b.eq	0x103de1554 <__v8_internal_Print_TransitionTree+0x198b6c>
103de1860: 17ffff54    	b	0x103de15b0 <__v8_internal_Print_TransitionTree+0x198bc8>
103de1864: b002b020    	adrp	x0, 0x1093e6000 <dyld_stub_binder+0x1093e6000>
103de1868: 91334400    	add	x0, x0, #0xcd1
103de186c: b002b021    	adrp	x1, 0x1093e6000 <dyld_stub_binder+0x1093e6000>
103de1870: 91337821    	add	x1, x1, #0xcde
103de1874: 97f7a1cc    	bl	0x103bc9fa4 <_llg_tokenize_bytes+0x22a108>
103de1878: 17ffff79    	b	0x103de165c <__v8_internal_Print_TransitionTree+0x198c74>
103de187c: 910006e1    	add	x1, x23, #0x1
103de1880: aa1303e0    	mov	x0, x19
103de1884: 97647d9b    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de1888: 529fc028    	mov	w8, #0xfe01             ; =65025
103de188c: 6a08001f    	tst	w0, w8
103de1890: 54ffedc1    	b.ne	0x103de1648 <__v8_internal_Print_TransitionTree+0x198c60>
103de1894: 17ffff71    	b	0x103de1658 <__v8_internal_Print_TransitionTree+0x198c70>
103de1898: d4200000    	brk	#0
103de189c: d4400000    	hlt	#0
103de18a0: d4200020    	brk	#0x1
103de18a4: d4200000    	brk	#0
103de18a8: d4400000    	hlt	#0
103de18ac: d4200020    	brk	#0x1
103de18b0: f9400008    	ldr	x8, [x0]
103de18b4: 910e8102    	add	x2, x8, #0x3a0
103de18b8: 17fffba4    	b	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
103de18bc: d10103ff    	sub	sp, sp, #0x40
103de18c0: a90157f6    	stp	x22, x21, [sp, #0x10]
103de18c4: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de18c8: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de18cc: 9100c3fd    	add	x29, sp, #0x30
103de18d0: aa0103f4    	mov	x20, x1
103de18d4: aa0003f3    	mov	x19, x0
103de18d8: 3940a408    	ldrb	w8, [x0, #0x29]
103de18dc: 340001e8    	cbz	w8, 0x103de1918 <__v8_internal_Print_TransitionTree+0x198f30>
103de18e0: f9400260    	ldr	x0, [x19]
103de18e4: f9411401    	ldr	x1, [x0, #0x228]
103de18e8: f9411808    	ldr	x8, [x0, #0x230]
103de18ec: eb08003f    	cmp	x1, x8
103de18f0: 54000d00    	b.eq	0x103de1a90 <__v8_internal_Print_TransitionTree+0x1990a8>
103de18f4: 91002028    	add	x8, x1, #0x8
103de18f8: f9011408    	str	x8, [x0, #0x228]
103de18fc: f9000034    	str	x20, [x1]
103de1900: aa1303e0    	mov	x0, x19
103de1904: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de1908: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de190c: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de1910: 910103ff    	add	sp, sp, #0x40
103de1914: 17fffbcf    	b	0x103de0850 <__v8_internal_Print_TransitionTree+0x197e68>
103de1918: a941a275    	ldp	x21, x8, [x19, #0x18]
103de191c: 910006b6    	add	x22, x21, #0x1
103de1920: eb0802df    	cmp	x22, x8
103de1924: 54000be8    	b.hi	0x103de1aa0 <__v8_internal_Print_TransitionTree+0x1990b8>
103de1928: f9000e76    	str	x22, [x19, #0x18]
103de192c: f9400a68    	ldr	x8, [x19, #0x10]
103de1930: 52800ac9    	mov	w9, #0x56               ; =86
103de1934: 38356909    	strb	w9, [x8, x21]
103de1938: d1000688    	sub	x8, x20, #0x1
103de193c: b85ff28a    	ldur	w10, [x20, #-0x1]
103de1940: b0031d49    	adrp	x9, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
103de1944: f940a929    	ldr	x9, [x9, #0x150]
103de1948: aa0a012a    	orr	x10, x9, x10
103de194c: 7840714a    	ldurh	w10, [x10, #0x7]
103de1950: 5120354a    	sub	w10, w10, #0x80d
103de1954: 7100055f    	cmp	w10, #0x1
103de1958: 54000528    	b.hi	0x103de19fc <__v8_internal_Print_TransitionTree+0x199014>
103de195c: 39003fff    	strb	wzr, [sp, #0xf]
103de1960: b940110a    	ldr	w10, [x8, #0x10]
103de1964: aa0a0129    	orr	x9, x9, x10
103de1968: b842f129    	ldur	w9, [x9, #0x2f]
103de196c: 371000e9    	tbnz	w9, #0x2, 0x103de1988 <__v8_internal_Print_TransitionTree+0x198fa0>
103de1970: b9401509    	ldr	w9, [x8, #0x14]
103de1974: 37000209    	tbnz	w9, #0x0, 0x103de19b4 <__v8_internal_Print_TransitionTree+0x198fcc>
103de1978: b9401508    	ldr	w8, [x8, #0x14]
103de197c: 370801c8    	tbnz	w8, #0x1, 0x103de19b4 <__v8_internal_Print_TransitionTree+0x198fcc>
103de1980: d1000680    	sub	x0, x20, #0x1
103de1984: 97114980    	bl	0x100233f84 <_cxxbridge1$slice$new+0x1ee4a8>
103de1988: d1000680    	sub	x0, x20, #0x1
103de198c: 97aa4149    	bl	0x102871eb0 <_cxxbridge1$box$media$SymphoniaDecoder$drop+0x12b940>
103de1990: 51000808    	sub	w8, w0, #0x2
103de1994: 71002d1f    	cmp	w8, #0xb
103de1998: 54000063    	b.lo	0x103de19a4 <__v8_internal_Print_TransitionTree+0x198fbc>
103de199c: 52800c41    	mov	w1, #0x62               ; =98
103de19a0: 14000020    	b	0x103de1a20 <__v8_internal_Print_TransitionTree+0x199038>
103de19a4: 90027dc9    	adrp	x9, 0x108d99000 <dyld_stub_binder+0x108d99000>
103de19a8: 911a7529    	add	x9, x9, #0x69d
103de19ac: 38684921    	ldrb	w1, [x9, w8, uxtw]
103de19b0: 1400001c    	b	0x103de1a20 <__v8_internal_Print_TransitionTree+0x199038>
103de19b4: d1000680    	sub	x0, x20, #0x1
103de19b8: 91003fe1    	add	x1, sp, #0xf
103de19bc: 97fed417    	bl	0x103d96a18 <__v8_internal_Print_TransitionTree+0x14e030>
103de19c0: 39403fe8    	ldrb	w8, [sp, #0xf]
103de19c4: 34fffe28    	cbz	w8, 0x103de1988 <__v8_internal_Print_TransitionTree+0x198fa0>
103de19c8: f9400260    	ldr	x0, [x19]
103de19cc: f9411402    	ldr	x2, [x0, #0x228]
103de19d0: f9411808    	ldr	x8, [x0, #0x230]
103de19d4: eb08005f    	cmp	x2, x8
103de19d8: 54000720    	b.eq	0x103de1abc <__v8_internal_Print_TransitionTree+0x1990d4>
103de19dc: 91002048    	add	x8, x2, #0x8
103de19e0: f9011408    	str	x8, [x0, #0x228]
103de19e4: f9000054    	str	x20, [x2]
103de19e8: aa1303e0    	mov	x0, x19
103de19ec: 52803b21    	mov	w1, #0x1d9              ; =473
103de19f0: 97fffb56    	bl	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
103de19f4: 52800000    	mov	w0, #0x0                ; =0
103de19f8: 1400001d    	b	0x103de1a6c <__v8_internal_Print_TransitionTree+0x199084>
103de19fc: b9400108    	ldr	w8, [x8]
103de1a00: aa080128    	orr	x8, x9, x8
103de1a04: 78407108    	ldurh	w8, [x8, #0x7]
103de1a08: 7120311f    	cmp	w8, #0x80c
103de1a0c: 54000081    	b.ne	0x103de1a1c <__v8_internal_Print_TransitionTree+0x199034>
103de1a10: d1000680    	sub	x0, x20, #0x1
103de1a14: 97f7d6ca    	bl	0x103bd753c <_llg_tokenize_bytes+0x2376a0>
103de1a18: 35fffd80    	cbnz	w0, 0x103de19c8 <__v8_internal_Print_TransitionTree+0x198fe0>
103de1a1c: 528007e1    	mov	w1, #0x3f               ; =63
103de1a20: aa1303e0    	mov	x0, x19
103de1a24: 940001d3    	bl	0x103de2170 <__v8_internal_Print_TransitionTree+0x199788>
103de1a28: f8417288    	ldur	x8, [x20, #0x17]
103de1a2c: d35dfd01    	lsr	x1, x8, #29
103de1a30: aa1303e0    	mov	x0, x19
103de1a34: 97fffaeb    	bl	0x103de05e0 <__v8_internal_Print_TransitionTree+0x197bf8>
103de1a38: f841f288    	ldur	x8, [x20, #0x1f]
103de1a3c: d35dfd01    	lsr	x1, x8, #29
103de1a40: aa1303e0    	mov	x0, x19
103de1a44: 97fffae7    	bl	0x103de05e0 <__v8_internal_Print_TransitionTree+0x197bf8>
103de1a48: b8413288    	ldur	w8, [x20, #0x13]
103de1a4c: b8413289    	ldur	w9, [x20, #0x13]
103de1a50: 121f0121    	and	w1, w9, #0x2
103de1a54: 33000101    	bfxil	w1, w8, #0, #1
103de1a58: aa1303e0    	mov	x0, x19
103de1a5c: 974902c9    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de1a60: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de1a64: 350000e8    	cbnz	w8, 0x103de1a80 <__v8_internal_Print_TransitionTree+0x199098>
103de1a68: 52802020    	mov	w0, #0x101              ; =257
103de1a6c: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de1a70: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de1a74: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de1a78: 910103ff    	add	sp, sp, #0x40
103de1a7c: d65f03c0    	ret
103de1a80: aa1303e0    	mov	x0, x19
103de1a84: 52803b41    	mov	w1, #0x1da              ; =474
103de1a88: 97ffff8a    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de1a8c: 17ffffda    	b	0x103de19f4 <__v8_internal_Print_TransitionTree+0x19900c>
103de1a90: aa1403e1    	mov	x1, x20
103de1a94: 970a2385    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de1a98: aa0003e1    	mov	x1, x0
103de1a9c: 17ffff99    	b	0x103de1900 <__v8_internal_Print_TransitionTree+0x198f18>
103de1aa0: 910006a1    	add	x1, x21, #0x1
103de1aa4: aa1303e0    	mov	x0, x19
103de1aa8: 97647d12    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de1aac: 529fc028    	mov	w8, #0xfe01             ; =65025
103de1ab0: 6a08001f    	tst	w0, w8
103de1ab4: 54fff3a1    	b.ne	0x103de1928 <__v8_internal_Print_TransitionTree+0x198f40>
103de1ab8: 17ffffa0    	b	0x103de1938 <__v8_internal_Print_TransitionTree+0x198f50>
103de1abc: aa1403e1    	mov	x1, x20
103de1ac0: 970a237a    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de1ac4: aa0003e2    	mov	x2, x0
103de1ac8: 17ffffc8    	b	0x103de19e8 <__v8_internal_Print_TransitionTree+0x199000>
103de1acc: d10243ff    	sub	sp, sp, #0x90
103de1ad0: a9055ff8    	stp	x24, x23, [sp, #0x50]
103de1ad4: a90657f6    	stp	x22, x21, [sp, #0x60]
103de1ad8: a9074ff4    	stp	x20, x19, [sp, #0x70]
103de1adc: a9087bfd    	stp	x29, x30, [sp, #0x80]
103de1ae0: 910203fd    	add	x29, sp, #0x80
103de1ae4: aa0103f4    	mov	x20, x1
103de1ae8: aa0003f3    	mov	x19, x0
103de1aec: 3900a3ff    	strb	wzr, [sp, #0x28]
103de1af0: 6f00e400    	movi.2d	v0, #0000000000000000
103de1af4: ad0183e0    	stp	q0, q0, [sp, #0x30]
103de1af8: f9400000    	ldr	x0, [x0]
103de1afc: 52837b08    	mov	w8, #0x1bd8             ; =7128
103de1b00: 8b080002    	add	x2, x0, x8
103de1b04: 9100a3e3    	add	x3, sp, #0x28
103de1b08: 971c4e6e    	bl	0x1004f54c0 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x126340>
103de1b0c: aa0003f6    	mov	x22, x0
103de1b10: 52800000    	mov	w0, #0x0                ; =0
103de1b14: 36000536    	tbz	w22, #0x0, 0x103de1bb8 <__v8_internal_Print_TransitionTree+0x1991d0>
103de1b18: 390003ff    	strb	wzr, [sp]
103de1b1c: 6f00e400    	movi.2d	v0, #0000000000000000
103de1b20: 3c8083e0    	stur	q0, [sp, #0x8]
103de1b24: 3c8183e0    	stur	q0, [sp, #0x18]
103de1b28: 5282f408    	mov	w8, #0x17a0             ; =6048
103de1b2c: f9400260    	ldr	x0, [x19]
103de1b30: 8b080002    	add	x2, x0, x8
103de1b34: 910003e3    	mov	x3, sp
103de1b38: aa1403e1    	mov	x1, x20
103de1b3c: 971c4e61    	bl	0x1004f54c0 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x126340>
103de1b40: aa0003f5    	mov	x21, x0
103de1b44: a941a277    	ldp	x23, x8, [x19, #0x18]
103de1b48: 910006f8    	add	x24, x23, #0x1
103de1b4c: eb08031f    	cmp	x24, x8
103de1b50: 54001348    	b.hi	0x103de1db8 <__v8_internal_Print_TransitionTree+0x1993d0>
103de1b54: f9000e78    	str	x24, [x19, #0x18]
103de1b58: f9400a68    	ldr	x8, [x19, #0x10]
103de1b5c: 52800e49    	mov	w9, #0x72               ; =114
103de1b60: 38376909    	strb	w9, [x8, x23]
103de1b64: f9400277    	ldr	x23, [x19]
103de1b68: b002af81    	adrp	x1, 0x1093d2000 <dyld_stub_binder+0x1093d2000>
103de1b6c: 9126b821    	add	x1, x1, #0x9ae
103de1b70: aa1703e0    	mov	x0, x23
103de1b74: 52800082    	mov	w2, #0x4                ; =4
103de1b78: 971ebb89    	bl	0x10059099c <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x1c181c>
103de1b7c: aa0003e2    	mov	x2, x0
103de1b80: aa1703e0    	mov	x0, x23
103de1b84: aa1403e1    	mov	x1, x20
103de1b88: 97bc1ef9    	bl	0x102ce976c <_media$cxxbridge1$199$init_symphonia_decoder+0xf2d1c>
103de1b8c: b4000160    	cbz	x0, 0x103de1bb8 <__v8_internal_Print_TransitionTree+0x1991d0>
103de1b90: aa0003f7    	mov	x23, x0
103de1b94: f9400260    	ldr	x0, [x19]
103de1b98: f94002e8    	ldr	x8, [x23]
103de1b9c: 36000088    	tbz	w8, #0x0, 0x103de1bac <__v8_internal_Print_TransitionTree+0x1991c4>
103de1ba0: b85ff109    	ldur	w9, [x8, #-0x1]
103de1ba4: 7111353f    	cmp	w9, #0x44d
103de1ba8: 54000183    	b.lo	0x103de1bd8 <__v8_internal_Print_TransitionTree+0x1991f0>
103de1bac: aa1703e1    	mov	x1, x23
103de1bb0: 970beed4    	bl	0x1000dd700 <_cxxbridge1$slice$new+0x97c24>
103de1bb4: b50000e0    	cbnz	x0, 0x103de1bd0 <__v8_internal_Print_TransitionTree+0x1991e8>
103de1bb8: a9487bfd    	ldp	x29, x30, [sp, #0x80]
103de1bbc: a9474ff4    	ldp	x20, x19, [sp, #0x70]
103de1bc0: a94657f6    	ldp	x22, x21, [sp, #0x60]
103de1bc4: a9455ff8    	ldp	x24, x23, [sp, #0x50]
103de1bc8: 910243ff    	add	sp, sp, #0x90
103de1bcc: d65f03c0    	ret
103de1bd0: aa0003f7    	mov	x23, x0
103de1bd4: f9400008    	ldr	x8, [x0]
103de1bd8: d1000500    	sub	x0, x8, #0x1
103de1bdc: 9002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de1be0: 911ec021    	add	x1, x1, #0x7b0
103de1be4: 52800122    	mov	w2, #0x9                ; =9
103de1be8: 97f9dc79    	bl	0x103c58dcc <__v8_internal_Print_TransitionTree+0x103e4>
103de1bec: 37000140    	tbnz	w0, #0x0, 0x103de1c14 <__v8_internal_Print_TransitionTree+0x19922c>
103de1bf0: f94002e8    	ldr	x8, [x23]
103de1bf4: d1000500    	sub	x0, x8, #0x1
103de1bf8: 9002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de1bfc: 911ee821    	add	x1, x1, #0x7ba
103de1c00: 52800142    	mov	w2, #0xa                ; =10
103de1c04: 97f9dc72    	bl	0x103c58dcc <__v8_internal_Print_TransitionTree+0x103e4>
103de1c08: 36000520    	tbz	w0, #0x0, 0x103de1cac <__v8_internal_Print_TransitionTree+0x1992c4>
103de1c0c: 52800a41    	mov	w1, #0x52               ; =82
103de1c10: 14000002    	b	0x103de1c18 <__v8_internal_Print_TransitionTree+0x199230>
103de1c14: 528008a1    	mov	w1, #0x45               ; =69
103de1c18: aa1303e0    	mov	x0, x19
103de1c1c: 94000155    	bl	0x103de2170 <__v8_internal_Print_TransitionTree+0x199788>
103de1c20: 364000b6    	tbz	w22, #0x8, 0x103de1c34 <__v8_internal_Print_TransitionTree+0x19924c>
103de1c24: f9401bf6    	ldr	x22, [sp, #0x30]
103de1c28: b50002b6    	cbnz	x22, 0x103de1c7c <__v8_internal_Print_TransitionTree+0x199294>
103de1c2c: 3940a3e8    	ldrb	w8, [sp, #0x28]
103de1c30: 37280268    	tbnz	w8, #0x5, 0x103de1c7c <__v8_internal_Print_TransitionTree+0x199294>
103de1c34: f9400260    	ldr	x0, [x19]
103de1c38: 5283d608    	mov	w8, #0x1eb0             ; =7856
103de1c3c: 8b080002    	add	x2, x0, x8
103de1c40: aa1403e1    	mov	x1, x20
103de1c44: 97b50748    	bl	0x102b23964 <_rust_png$cxxbridge1$199$new_writer+0x1b71e4>
103de1c48: b4fffb80    	cbz	x0, 0x103de1bb8 <__v8_internal_Print_TransitionTree+0x1991d0>
103de1c4c: aa0003f4    	mov	x20, x0
103de1c50: f9400008    	ldr	x8, [x0]
103de1c54: 37000748    	tbnz	w8, #0x0, 0x103de1d3c <__v8_internal_Print_TransitionTree+0x199354>
103de1c58: 36000c75    	tbz	w21, #0x0, 0x103de1de4 <__v8_internal_Print_TransitionTree+0x1993fc>
103de1c5c: 37400855    	tbnz	w21, #0x8, 0x103de1d64 <__v8_internal_Print_TransitionTree+0x19937c>
103de1c60: aa1303e0    	mov	x0, x19
103de1c64: 528005c1    	mov	w1, #0x2e               ; =46
103de1c68: 94000142    	bl	0x103de2170 <__v8_internal_Print_TransitionTree+0x199788>
103de1c6c: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de1c70: 35000b28    	cbnz	w8, 0x103de1dd4 <__v8_internal_Print_TransitionTree+0x1993ec>
103de1c74: 52802020    	mov	w0, #0x101              ; =257
103de1c78: 17ffffd0    	b	0x103de1bb8 <__v8_internal_Print_TransitionTree+0x1991d0>
103de1c7c: f9400260    	ldr	x0, [x19]
103de1c80: f94002c8    	ldr	x8, [x22]
103de1c84: 36000088    	tbz	w8, #0x0, 0x103de1c94 <__v8_internal_Print_TransitionTree+0x1992ac>
103de1c88: b85ff108    	ldur	w8, [x8, #-0x1]
103de1c8c: 7111351f    	cmp	w8, #0x44d
103de1c90: 54000083    	b.lo	0x103de1ca0 <__v8_internal_Print_TransitionTree+0x1992b8>
103de1c94: aa1603e1    	mov	x1, x22
103de1c98: 974c8d26    	bl	0x101105130 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x2ab688>
103de1c9c: aa0003f6    	mov	x22, x0
103de1ca0: b50007f6    	cbnz	x22, 0x103de1d9c <__v8_internal_Print_TransitionTree+0x1993b4>
103de1ca4: 52800000    	mov	w0, #0x0                ; =0
103de1ca8: 17ffffc4    	b	0x103de1bb8 <__v8_internal_Print_TransitionTree+0x1991d0>
103de1cac: f94002e8    	ldr	x8, [x23]
103de1cb0: d1000500    	sub	x0, x8, #0x1
103de1cb4: 9002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de1cb8: 911f1421    	add	x1, x1, #0x7c5
103de1cbc: 528001c2    	mov	w2, #0xe                ; =14
103de1cc0: 97f9dc43    	bl	0x103c58dcc <__v8_internal_Print_TransitionTree+0x103e4>
103de1cc4: 36000060    	tbz	w0, #0x0, 0x103de1cd0 <__v8_internal_Print_TransitionTree+0x1992e8>
103de1cc8: 528008c1    	mov	w1, #0x46               ; =70
103de1ccc: 17ffffd3    	b	0x103de1c18 <__v8_internal_Print_TransitionTree+0x199230>
103de1cd0: f94002e8    	ldr	x8, [x23]
103de1cd4: d1000500    	sub	x0, x8, #0x1
103de1cd8: 9002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de1cdc: 911f5021    	add	x1, x1, #0x7d4
103de1ce0: 52800162    	mov	w2, #0xb                ; =11
103de1ce4: 97f9dc3a    	bl	0x103c58dcc <__v8_internal_Print_TransitionTree+0x103e4>
103de1ce8: 36000060    	tbz	w0, #0x0, 0x103de1cf4 <__v8_internal_Print_TransitionTree+0x19930c>
103de1cec: 52800a61    	mov	w1, #0x53               ; =83
103de1cf0: 17ffffca    	b	0x103de1c18 <__v8_internal_Print_TransitionTree+0x199230>
103de1cf4: f94002e8    	ldr	x8, [x23]
103de1cf8: d1000500    	sub	x0, x8, #0x1
103de1cfc: 9002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de1d00: 911f8021    	add	x1, x1, #0x7e0
103de1d04: 52800122    	mov	w2, #0x9                ; =9
103de1d08: 97f9dc31    	bl	0x103c58dcc <__v8_internal_Print_TransitionTree+0x103e4>
103de1d0c: 36000060    	tbz	w0, #0x0, 0x103de1d18 <__v8_internal_Print_TransitionTree+0x199330>
103de1d10: 52800a81    	mov	w1, #0x54               ; =84
103de1d14: 17ffffc1    	b	0x103de1c18 <__v8_internal_Print_TransitionTree+0x199230>
103de1d18: f94002e8    	ldr	x8, [x23]
103de1d1c: d1000500    	sub	x0, x8, #0x1
103de1d20: 9002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de1d24: 911fa821    	add	x1, x1, #0x7ea
103de1d28: 52800102    	mov	w2, #0x8                ; =8
103de1d2c: 97f9dc28    	bl	0x103c58dcc <__v8_internal_Print_TransitionTree+0x103e4>
103de1d30: 34fff780    	cbz	w0, 0x103de1c20 <__v8_internal_Print_TransitionTree+0x199238>
103de1d34: 52800aa1    	mov	w1, #0x55               ; =85
103de1d38: 17ffffb8    	b	0x103de1c18 <__v8_internal_Print_TransitionTree+0x199230>
103de1d3c: b85ff108    	ldur	w8, [x8, #-0x1]
103de1d40: 7111311f    	cmp	w8, #0x44c
103de1d44: 54fff8a8    	b.hi	0x103de1c58 <__v8_internal_Print_TransitionTree+0x199270>
103de1d48: aa1303e0    	mov	x0, x19
103de1d4c: 52800e61    	mov	w1, #0x73               ; =115
103de1d50: 94000108    	bl	0x103de2170 <__v8_internal_Print_TransitionTree+0x199788>
103de1d54: aa1303e0    	mov	x0, x19
103de1d58: aa1403e1    	mov	x1, x20
103de1d5c: 97647aaf    	bl	0x101700818 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6d70>
103de1d60: 17ffffbe    	b	0x103de1c58 <__v8_internal_Print_TransitionTree+0x199270>
103de1d64: f94007f4    	ldr	x20, [sp, #0x8]
103de1d68: b5000074    	cbnz	x20, 0x103de1d74 <__v8_internal_Print_TransitionTree+0x19938c>
103de1d6c: 394003e8    	ldrb	w8, [sp]
103de1d70: 362ff788    	tbz	w8, #0x5, 0x103de1c60 <__v8_internal_Print_TransitionTree+0x199278>
103de1d74: aa1303e0    	mov	x0, x19
103de1d78: 52800c61    	mov	w1, #0x63               ; =99
103de1d7c: 940000fd    	bl	0x103de2170 <__v8_internal_Print_TransitionTree+0x199788>
103de1d80: aa1303e0    	mov	x0, x19
103de1d84: aa1403e1    	mov	x1, x20
103de1d88: 976479dd    	bl	0x1017004fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a54>
103de1d8c: 52802028    	mov	w8, #0x101              ; =257
103de1d90: 6a20011f    	bics	wzr, w8, w0
103de1d94: 54fff660    	b.eq	0x103de1c60 <__v8_internal_Print_TransitionTree+0x199278>
103de1d98: 17ffffc3    	b	0x103de1ca4 <__v8_internal_Print_TransitionTree+0x1992bc>
103de1d9c: aa1303e0    	mov	x0, x19
103de1da0: 52800da1    	mov	w1, #0x6d               ; =109
103de1da4: 940000f3    	bl	0x103de2170 <__v8_internal_Print_TransitionTree+0x199788>
103de1da8: aa1303e0    	mov	x0, x19
103de1dac: aa1603e1    	mov	x1, x22
103de1db0: 97647a9a    	bl	0x101700818 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6d70>
103de1db4: 17ffffa0    	b	0x103de1c34 <__v8_internal_Print_TransitionTree+0x19924c>
103de1db8: 910006e1    	add	x1, x23, #0x1
103de1dbc: aa1303e0    	mov	x0, x19
103de1dc0: 97647c4c    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de1dc4: 529fc028    	mov	w8, #0xfe01             ; =65025
103de1dc8: 6a08001f    	tst	w0, w8
103de1dcc: 54ffec41    	b.ne	0x103de1b54 <__v8_internal_Print_TransitionTree+0x19916c>
103de1dd0: 17ffff65    	b	0x103de1b64 <__v8_internal_Print_TransitionTree+0x19917c>
103de1dd4: aa1303e0    	mov	x0, x19
103de1dd8: 52803b41    	mov	w1, #0x1da              ; =474
103de1ddc: 97fffeb5    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de1de0: 17ffffb1    	b	0x103de1ca4 <__v8_internal_Print_TransitionTree+0x1992bc>
103de1de4: b002b020    	adrp	x0, 0x1093e6000 <dyld_stub_binder+0x1093e6000>
103de1de8: 91334400    	add	x0, x0, #0xcd1
103de1dec: b002b021    	adrp	x1, 0x1093e6000 <dyld_stub_binder+0x1093e6000>
103de1df0: 91337821    	add	x1, x1, #0xcde
103de1df4: 97f7a06c    	bl	0x103bc9fa4 <_llg_tokenize_bytes+0x22a108>
103de1df8: 17ffff99    	b	0x103de1c5c <__v8_internal_Print_TransitionTree+0x199274>
103de1dfc: d10103ff    	sub	sp, sp, #0x40
103de1e00: a90157f6    	stp	x22, x21, [sp, #0x10]
103de1e04: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de1e08: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de1e0c: 9100c3fd    	add	x29, sp, #0x30
103de1e10: aa0103f4    	mov	x20, x1
103de1e14: aa0003f3    	mov	x19, x0
103de1e18: f9400408    	ldr	x8, [x0, #0x8]
103de1e1c: b40003e8    	cbz	x8, 0x103de1e98 <__v8_internal_Print_TransitionTree+0x1994b0>
103de1e20: f9400275    	ldr	x21, [x19]
103de1e24: 91404aa8    	add	x8, x21, #0x12, lsl #12 ; =0x12000
103de1e28: 39402109    	ldrb	w9, [x8, #0x8]
103de1e2c: 360007a9    	tbz	w9, #0x0, 0x103de1f20 <__v8_internal_Print_TransitionTree+0x199538>
103de1e30: f9400108    	ldr	x8, [x8]
103de1e34: b4000328    	cbz	x8, 0x103de1e98 <__v8_internal_Print_TransitionTree+0x1994b0>
103de1e38: f9408668    	ldr	x8, [x19, #0x108]
103de1e3c: b4000428    	cbz	x8, 0x103de1ec0 <__v8_internal_Print_TransitionTree+0x1994d8>
103de1e40: a941a275    	ldp	x21, x8, [x19, #0x18]
103de1e44: 910006b6    	add	x22, x21, #0x1
103de1e48: eb0802df    	cmp	x22, x8
103de1e4c: 540005c8    	b.hi	0x103de1f04 <__v8_internal_Print_TransitionTree+0x19951c>
103de1e50: f9000e76    	str	x22, [x19, #0x18]
103de1e54: f9400a68    	ldr	x8, [x19, #0x10]
103de1e58: 52800e09    	mov	w9, #0x70               ; =112
103de1e5c: 38356909    	strb	w9, [x8, x21]
103de1e60: f9408660    	ldr	x0, [x19, #0x108]
103de1e64: f9400281    	ldr	x1, [x20]
103de1e68: 97f9fc9d    	bl	0x103c610dc <__v8_internal_Print_TransitionTree+0x186f4>
103de1e6c: aa0003e1    	mov	x1, x0
103de1e70: aa1303e0    	mov	x0, x19
103de1e74: 974901c3    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de1e78: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de1e7c: 350001a8    	cbnz	w8, 0x103de1eb0 <__v8_internal_Print_TransitionTree+0x1994c8>
103de1e80: 52802020    	mov	w0, #0x101              ; =257
103de1e84: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de1e88: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de1e8c: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de1e90: 910103ff    	add	sp, sp, #0x40
103de1e94: d65f03c0    	ret
103de1e98: aa1303e0    	mov	x0, x19
103de1e9c: 52803b21    	mov	w1, #0x1d9              ; =473
103de1ea0: aa1403e2    	mov	x2, x20
103de1ea4: 97fffa29    	bl	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
103de1ea8: 52800000    	mov	w0, #0x0                ; =0
103de1eac: 17fffff6    	b	0x103de1e84 <__v8_internal_Print_TransitionTree+0x19949c>
103de1eb0: aa1303e0    	mov	x0, x19
103de1eb4: 52803b41    	mov	w1, #0x1da              ; =474
103de1eb8: 97fffe7e    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de1ebc: 17fffffb    	b	0x103de1ea8 <__v8_internal_Print_TransitionTree+0x1994c0>
103de1ec0: 910023e0    	add	x0, sp, #0x8
103de1ec4: aa1503e1    	mov	x1, x21
103de1ec8: 97f7a5d5    	bl	0x103bcb61c <_llg_tokenize_bytes+0x22b780>
103de1ecc: f94007e8    	ldr	x8, [sp, #0x8]
103de1ed0: f9008668    	str	x8, [x19, #0x108]
103de1ed4: f9400660    	ldr	x0, [x19, #0x8]
103de1ed8: 910023e2    	add	x2, sp, #0x8
103de1edc: aa1503e1    	mov	x1, x21
103de1ee0: 94ce3a65    	bl	0x107170874 <__Z23_v8_internal_Node_PrintPv+0x3061248>
103de1ee4: 36000080    	tbz	w0, #0x0, 0x103de1ef4 <__v8_internal_Print_TransitionTree+0x19950c>
103de1ee8: 910023e0    	add	x0, sp, #0x8
103de1eec: 97f7a5bf    	bl	0x103bcb5e8 <_llg_tokenize_bytes+0x22b74c>
103de1ef0: 17ffffd4    	b	0x103de1e40 <__v8_internal_Print_TransitionTree+0x199458>
103de1ef4: f900867f    	str	xzr, [x19, #0x108]
103de1ef8: 910023e0    	add	x0, sp, #0x8
103de1efc: 97f7a5bb    	bl	0x103bcb5e8 <_llg_tokenize_bytes+0x22b74c>
103de1f00: 17ffffea    	b	0x103de1ea8 <__v8_internal_Print_TransitionTree+0x1994c0>
103de1f04: 910006a1    	add	x1, x21, #0x1
103de1f08: aa1303e0    	mov	x0, x19
103de1f0c: 97647bf9    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de1f10: 529fc028    	mov	w8, #0xfe01             ; =65025
103de1f14: 6a08001f    	tst	w0, w8
103de1f18: 54fff9c1    	b.ne	0x103de1e50 <__v8_internal_Print_TransitionTree+0x199468>
103de1f1c: 17ffffd1    	b	0x103de1e60 <__v8_internal_Print_TransitionTree+0x199478>
103de1f20: 97f10d06    	bl	0x103a25338 <_llg_tokenize_bytes+0x8549c>
103de1f24: d10103ff    	sub	sp, sp, #0x40
103de1f28: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de1f2c: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de1f30: 9100c3fd    	add	x29, sp, #0x30
103de1f34: aa0103e2    	mov	x2, x1
103de1f38: aa0003f3    	mov	x19, x0
103de1f3c: f9400400    	ldr	x0, [x0, #0x8]
103de1f40: b4000380    	cbz	x0, 0x103de1fb0 <__v8_internal_Print_TransitionTree+0x1995c8>
103de1f44: f9400261    	ldr	x1, [x19]
103de1f48: 94ce39a9    	bl	0x1071705ec <__Z23_v8_internal_Node_PrintPv+0x3060fc0>
103de1f4c: f9400268    	ldr	x8, [x19]
103de1f50: b9417908    	ldr	w8, [x8, #0x178]
103de1f54: 5140bd08    	sub	w8, w8, #0x2f, lsl #12  ; =0x2f000
103de1f58: 713ff51f    	cmp	w8, #0xffd
103de1f5c: 54000301    	b.ne	0x103de1fbc <__v8_internal_Print_TransitionTree+0x1995d4>
103de1f60: 370000e0    	tbnz	w0, #0x0, 0x103de1f7c <__v8_internal_Print_TransitionTree+0x199594>
103de1f64: 3940aa68    	ldrb	w8, [x19, #0x2a]
103de1f68: 34000208    	cbz	w8, 0x103de1fa8 <__v8_internal_Print_TransitionTree+0x1995c0>
103de1f6c: aa1303e0    	mov	x0, x19
103de1f70: 52803b41    	mov	w1, #0x1da              ; =474
103de1f74: 97fffe4f    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
103de1f78: 14000011    	b	0x103de1fbc <__v8_internal_Print_TransitionTree+0x1995d4>
103de1f7c: d360fc01    	lsr	x1, x0, #32
103de1f80: a941aa68    	ldp	x8, x10, [x19, #0x18]
103de1f84: 91000509    	add	x9, x8, #0x1
103de1f88: eb0a013f    	cmp	x9, x10
103de1f8c: 54000228    	b.hi	0x103de1fd0 <__v8_internal_Print_TransitionTree+0x1995e8>
103de1f90: f9000e69    	str	x9, [x19, #0x18]
103de1f94: f9400a69    	ldr	x9, [x19, #0x10]
103de1f98: 52800eea    	mov	w10, #0x77              ; =119
103de1f9c: 3828692a    	strb	w10, [x9, x8]
103de1fa0: aa1303e0    	mov	x0, x19
103de1fa4: 97490177    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de1fa8: 52802020    	mov	w0, #0x101              ; =257
103de1fac: 14000005    	b	0x103de1fc0 <__v8_internal_Print_TransitionTree+0x1995d8>
103de1fb0: aa1303e0    	mov	x0, x19
103de1fb4: 52803b21    	mov	w1, #0x1d9              ; =473
103de1fb8: 97fff9e4    	bl	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
103de1fbc: 52800000    	mov	w0, #0x0                ; =0
103de1fc0: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de1fc4: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de1fc8: 910103ff    	add	sp, sp, #0x40
103de1fcc: d65f03c0    	ret
103de1fd0: a90107e8    	stp	x8, x1, [sp, #0x10]
103de1fd4: 91000501    	add	x1, x8, #0x1
103de1fd8: aa1303e0    	mov	x0, x19
103de1fdc: f90007e9    	str	x9, [sp, #0x8]
103de1fe0: 97647bc4    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de1fe4: a940a3e9    	ldp	x9, x8, [sp, #0x8]
103de1fe8: f9400fe1    	ldr	x1, [sp, #0x18]
103de1fec: 529fc02a    	mov	w10, #0xfe01            ; =65025
103de1ff0: 6a0a001f    	tst	w0, w10
103de1ff4: 54fffce1    	b.ne	0x103de1f90 <__v8_internal_Print_TransitionTree+0x1995a8>
103de1ff8: 17ffffea    	b	0x103de1fa0 <__v8_internal_Print_TransitionTree+0x1995b8>
103de1ffc: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
103de2000: a90157f6    	stp	x22, x21, [sp, #0x10]
103de2004: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de2008: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de200c: 9100c3fd    	add	x29, sp, #0x30
103de2010: aa0103f5    	mov	x21, x1
103de2014: aa0003f3    	mov	x19, x0
103de2018: f9400000    	ldr	x0, [x0]
103de201c: 9409683c    	bl	0x10403c10c <__v8_internal_Print_TransitionTree+0x3f3724>
103de2020: f9400008    	ldr	x8, [x0]
103de2024: b842f109    	ldur	w9, [x8, #0x2f]
103de2028: 36180749    	tbz	w9, #0x3, 0x103de2110 <__v8_internal_Print_TransitionTree+0x199728>
103de202c: aa0003f4    	mov	x20, x0
103de2030: d0030f80    	adrp	x0, 0x109fd4000 <dyld_stub_binder+0x109fd4000>
103de2034: 9129a000    	add	x0, x0, #0xa68
103de2038: f9400009    	ldr	x9, [x0]
103de203c: d63f0120    	blr	x9
103de2040: f9400009    	ldr	x9, [x0]
103de2044: b842b108    	ldur	w8, [x8, #0x2b]
103de2048: 53037d08    	lsr	w8, w8, #3
103de204c: f9416929    	ldr	x9, [x9, #0x2d0]
103de2050: 927d6508    	and	x8, x8, #0x1ffffff8
103de2054: f8686928    	ldr	x8, [x9, x8]
103de2058: 924f1909    	and	x9, x8, #0xfe000000000000
103de205c: f248dd08    	ands	x8, x8, #0xff00ffffffffffff
103de2060: d2e016ca    	mov	x10, #0xb6000000000000  ; =51228445761339392
103de2064: fa4a1120    	ccmp	x9, x10, #0x0, ne
103de2068: 540000e1    	b.ne	0x103de2084 <__v8_internal_Print_TransitionTree+0x19969c>
103de206c: a9410500    	ldp	x0, x1, [x8, #0x10]
103de2070: b40000e1    	cbz	x1, 0x103de208c <__v8_internal_Print_TransitionTree+0x1996a4>
103de2074: 91002028    	add	x8, x1, #0x8
103de2078: 52800029    	mov	w9, #0x1                ; =1
103de207c: f8290108    	ldadd	x9, x8, [x8]
103de2080: 14000003    	b	0x103de208c <__v8_internal_Print_TransitionTree+0x1996a4>
103de2084: d2800001    	mov	x1, #0x0                ; =0
103de2088: d2800000    	mov	x0, #0x0                ; =0
103de208c: 97fd5af5    	bl	0x103d38c60 <__v8_internal_Print_TransitionTree+0xf0278>
103de2090: a941a276    	ldp	x22, x8, [x19, #0x18]
103de2094: 910006d7    	add	x23, x22, #0x1
103de2098: eb0802ff    	cmp	x23, x8
103de209c: 540004e8    	b.hi	0x103de2138 <__v8_internal_Print_TransitionTree+0x199750>
103de20a0: f9000e77    	str	x23, [x19, #0x18]
103de20a4: f9400a68    	ldr	x8, [x19, #0x10]
103de20a8: 52800da9    	mov	w9, #0x6d               ; =109
103de20ac: 38366909    	strb	w9, [x8, x22]
103de20b0: f94002a8    	ldr	x8, [x21]
103de20b4: b8413108    	ldur	w8, [x8, #0x13]
103de20b8: 121f7909    	and	w9, w8, #0xfffffffe
103de20bc: 4a887d21    	eor	w1, w9, w8, asr #31
103de20c0: aa1303e0    	mov	x0, x19
103de20c4: 9749012f    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de20c8: f94002a8    	ldr	x8, [x21]
103de20cc: 39406d08    	ldrb	w8, [x8, #0x1b]
103de20d0: 7100051f    	cmp	w8, #0x1
103de20d4: 1a9f17f5    	cset	w21, eq
103de20d8: a941a276    	ldp	x22, x8, [x19, #0x18]
103de20dc: 910006d7    	add	x23, x22, #0x1
103de20e0: eb0802ff    	cmp	x23, x8
103de20e4: 54000388    	b.hi	0x103de2154 <__v8_internal_Print_TransitionTree+0x19976c>
103de20e8: f9000e77    	str	x23, [x19, #0x18]
103de20ec: f9400a68    	ldr	x8, [x19, #0x10]
103de20f0: 38366915    	strb	w21, [x8, x22]
103de20f4: aa1303e0    	mov	x0, x19
103de20f8: aa1403e1    	mov	x1, x20
103de20fc: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de2100: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de2104: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de2108: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de210c: 17647389    	b	0x1016fef30 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5488>
103de2110: aa1303e0    	mov	x0, x19
103de2114: 52803b21    	mov	w1, #0x1d9              ; =473
103de2118: aa1503e2    	mov	x2, x21
103de211c: 97fff98b    	bl	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
103de2120: 52800000    	mov	w0, #0x0                ; =0
103de2124: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de2128: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de212c: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de2130: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de2134: d65f03c0    	ret
103de2138: 910006c1    	add	x1, x22, #0x1
103de213c: aa1303e0    	mov	x0, x19
103de2140: 97647b6c    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de2144: 529fc028    	mov	w8, #0xfe01             ; =65025
103de2148: 6a08001f    	tst	w0, w8
103de214c: 54fffaa1    	b.ne	0x103de20a0 <__v8_internal_Print_TransitionTree+0x1996b8>
103de2150: 17ffffd8    	b	0x103de20b0 <__v8_internal_Print_TransitionTree+0x1996c8>
103de2154: 910006c1    	add	x1, x22, #0x1
103de2158: aa1303e0    	mov	x0, x19
103de215c: 97647b65    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de2160: 529fc028    	mov	w8, #0xfe01             ; =65025
103de2164: 6a08001f    	tst	w0, w8
103de2168: 54fffc01    	b.ne	0x103de20e8 <__v8_internal_Print_TransitionTree+0x199700>
103de216c: 17ffffe2    	b	0x103de20f4 <__v8_internal_Print_TransitionTree+0x19970c>
103de2170: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
103de2174: a9014ff4    	stp	x20, x19, [sp, #0x10]
103de2178: a9027bfd    	stp	x29, x30, [sp, #0x20]
103de217c: 910083fd    	add	x29, sp, #0x20
103de2180: aa0103f3    	mov	x19, x1
103de2184: aa0003f4    	mov	x20, x0
103de2188: a941a015    	ldp	x21, x8, [x0, #0x18]
103de218c: 910006b6    	add	x22, x21, #0x1
103de2190: eb0802df    	cmp	x22, x8
103de2194: 54000108    	b.hi	0x103de21b4 <__v8_internal_Print_TransitionTree+0x1997cc>
103de2198: f9000e96    	str	x22, [x20, #0x18]
103de219c: f9400a88    	ldr	x8, [x20, #0x10]
103de21a0: 38356913    	strb	w19, [x8, x21]
103de21a4: a9427bfd    	ldp	x29, x30, [sp, #0x20]
103de21a8: a9414ff4    	ldp	x20, x19, [sp, #0x10]
103de21ac: a8c357f6    	ldp	x22, x21, [sp], #0x30
103de21b0: d65f03c0    	ret
103de21b4: 910006a1    	add	x1, x21, #0x1
103de21b8: aa1403e0    	mov	x0, x20
103de21bc: 97647b4d    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de21c0: 529fc028    	mov	w8, #0xfe01             ; =65025
103de21c4: 6a08001f    	tst	w0, w8
103de21c8: 54fffe81    	b.ne	0x103de2198 <__v8_internal_Print_TransitionTree+0x1997b0>
103de21cc: 17fffff6    	b	0x103de21a4 <__v8_internal_Print_TransitionTree+0x1997bc>
103de21d0: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
103de21d4: a9017bfd    	stp	x29, x30, [sp, #0x10]
103de21d8: 910043fd    	add	x29, sp, #0x10
103de21dc: aa0103f3    	mov	x19, x1
103de21e0: a9412809    	ldp	x9, x10, [x0, #0x10]
103de21e4: 91001528    	add	x8, x9, #0x5
103de21e8: eb0a011f    	cmp	x8, x10
103de21ec: 54000582    	b.hs	0x103de229c <__v8_internal_Print_TransitionTree+0x1998b4>
103de21f0: aa0903eb    	mov	x11, x9
103de21f4: 3840156a    	ldrb	w10, [x11], #0x1
103de21f8: f900080b    	str	x11, [x0, #0x10]
103de21fc: 3738014a    	tbnz	w10, #0x7, 0x103de2224 <__v8_internal_Print_TransitionTree+0x19983c>
103de2200: 52800028    	mov	w8, #0x1                ; =1
103de2204: aa0a8100    	orr	x0, x8, x10, lsl #32
103de2208: 36000060    	tbz	w0, #0x0, 0x103de2214 <__v8_internal_Print_TransitionTree+0x19982c>
103de220c: d360fc08    	lsr	x8, x0, #32
103de2210: b9000268    	str	w8, [x19]
103de2214: 12000000    	and	w0, w0, #0x1
103de2218: a9417bfd    	ldp	x29, x30, [sp, #0x10]
103de221c: a8c24ff4    	ldp	x20, x19, [sp], #0x20
103de2220: d65f03c0    	ret
103de2224: 1200194a    	and	w10, w10, #0x7f
103de2228: 39c0052c    	ldrsb	w12, [x9, #0x1]
103de222c: 9100092b    	add	x11, x9, #0x2
103de2230: f900080b    	str	x11, [x0, #0x10]
103de2234: 53191d8b    	ubfiz	w11, w12, #7, #8
103de2238: 37f800ac    	tbnz	w12, #0x1f, 0x103de224c <__v8_internal_Print_TransitionTree+0x199864>
103de223c: 2a0a0168    	orr	w8, w11, w10
103de2240: 52800029    	mov	w9, #0x1                ; =1
103de2244: aa088120    	orr	x0, x9, x8, lsl #32
103de2248: 17fffff0    	b	0x103de2208 <__v8_internal_Print_TransitionTree+0x199820>
103de224c: 1219196b    	and	w11, w11, #0x3f80
103de2250: 2a0a016a    	orr	w10, w11, w10
103de2254: 39c0092c    	ldrsb	w12, [x9, #0x2]
103de2258: 91000d2b    	add	x11, x9, #0x3
103de225c: f900080b    	str	x11, [x0, #0x10]
103de2260: 53121d8b    	ubfiz	w11, w12, #14, #8
103de2264: 36fffecc    	tbz	w12, #0x1f, 0x103de223c <__v8_internal_Print_TransitionTree+0x199854>
103de2268: 1212196b    	and	w11, w11, #0x1fc000
103de226c: 2a0a016a    	orr	w10, w11, w10
103de2270: 39c00d2c    	ldrsb	w12, [x9, #0x3]
103de2274: 91001129    	add	x9, x9, #0x4
103de2278: f9000809    	str	x9, [x0, #0x10]
103de227c: 530b1d8b    	ubfiz	w11, w12, #21, #8
103de2280: 36fffdec    	tbz	w12, #0x1f, 0x103de223c <__v8_internal_Print_TransitionTree+0x199854>
103de2284: 120b196b    	and	w11, w11, #0xfe00000
103de2288: 39400129    	ldrb	w9, [x9]
103de228c: f9000808    	str	x8, [x0, #0x10]
103de2290: 2a097168    	orr	w8, w11, w9, lsl #28
103de2294: 2a0a0108    	orr	w8, w8, w10
103de2298: 17ffffea    	b	0x103de2240 <__v8_internal_Print_TransitionTree+0x199858>
103de229c: 975d5019    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
103de22a0: 17ffffda    	b	0x103de2208 <__v8_internal_Print_TransitionTree+0x199820>
		...
103de22c0: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
103de22c4: a9017bfd    	stp	x29, x30, [sp, #0x10]
103de22c8: 910043fd    	add	x29, sp, #0x10
103de22cc: aa0103f3    	mov	x19, x1
103de22d0: 94000d60    	bl	0x103de5850 <__v8_internal_Print_TransitionTree+0x19ce68>
103de22d4: 36000040    	tbz	w0, #0x0, 0x103de22dc <__v8_internal_Print_TransitionTree+0x1998f4>
103de22d8: f9000261    	str	x1, [x19]
103de22dc: 12000000    	and	w0, w0, #0x1
103de22e0: a9417bfd    	ldp	x29, x30, [sp, #0x10]
103de22e4: a8c24ff4    	ldp	x20, x19, [sp], #0x20
103de22e8: d65f03c0    	ret
103de22ec: b9401809    	ldr	w9, [x0, #0x18]
103de22f0: f9400808    	ldr	x8, [x0, #0x10]
103de22f4: 4b080129    	sub	w9, w9, w8
103de22f8: f27d713f    	tst	x9, #0xfffffff8
103de22fc: 54000180    	b.eq	0x103de232c <__v8_internal_Print_TransitionTree+0x199944>
103de2300: fc408500    	ldr	d0, [x8], #0x8
103de2304: f9000808    	str	x8, [x0, #0x10]
103de2308: 1e602000    	fcmp	d0, d0
103de230c: 9e660008    	fmov	x8, d0
103de2310: d2efff09    	mov	x9, #0x7ff8000000000000 ; =9221120237041090560
103de2314: 9a886129    	csel	x9, x9, x8, vs
103de2318: 52800028    	mov	w8, #0x1                ; =1
103de231c: 36000048    	tbz	w8, #0x0, 0x103de2324 <__v8_internal_Print_TransitionTree+0x19993c>
103de2320: f9000029    	str	x9, [x1]
103de2324: 12000100    	and	w0, w8, #0x1
103de2328: d65f03c0    	ret
103de232c: d2800008    	mov	x8, #0x0                ; =0
103de2330: d2800009    	mov	x9, #0x0                ; =0
103de2334: 17fffffa    	b	0x103de231c <__v8_internal_Print_TransitionTree+0x199934>
103de2338: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
103de233c: a9014ff4    	stp	x20, x19, [sp, #0x10]
103de2340: a9027bfd    	stp	x29, x30, [sp, #0x20]
103de2344: 910083fd    	add	x29, sp, #0x20
103de2348: aa0203f4    	mov	x20, x2
103de234c: aa0103f5    	mov	x21, x1
103de2350: aa0003f3    	mov	x19, x0
103de2354: f9401c16    	ldr	x22, [x0, #0x38]
103de2358: b50001d6    	cbnz	x22, 0x103de2390 <__v8_internal_Print_TransitionTree+0x1999a8>
103de235c: f9400260    	ldr	x0, [x19]
103de2360: 91404008    	add	x8, x0, #0x10, lsl #12  ; =0x10000
103de2364: f945e916    	ldr	x22, [x8, #0xbd0]
103de2368: 52800001    	mov	w1, #0x0                ; =0
103de236c: 52800002    	mov	w2, #0x0                ; =0
103de2370: 52800003    	mov	w3, #0x0                ; =0
103de2374: 97ffabe8    	bl	0x103dcd314 <__v8_internal_Print_TransitionTree+0x18492c>
103de2378: f9400001    	ldr	x1, [x0]
103de237c: aa1603e0    	mov	x0, x22
103de2380: 9757a0cb    	bl	0x1013ca6ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x570c04>
103de2384: aa0003f6    	mov	x22, x0
103de2388: f9001e60    	str	x0, [x19, #0x38]
103de238c: b4000340    	cbz	x0, 0x103de23f4 <__v8_internal_Print_TransitionTree+0x199a0c>
103de2390: f9400260    	ldr	x0, [x19]
103de2394: aa1603e1    	mov	x1, x22
103de2398: aa1503e2    	mov	x2, x21
103de239c: aa1403e3    	mov	x3, x20
103de23a0: 97ffc538    	bl	0x103dd3880 <__v8_internal_Print_TransitionTree+0x18ae98>
103de23a4: eb0002df    	cmp	x22, x0
103de23a8: 540001e0    	b.eq	0x103de23e4 <__v8_internal_Print_TransitionTree+0x1999fc>
103de23ac: aa0003f4    	mov	x20, x0
103de23b0: b40000a0    	cbz	x0, 0x103de23c4 <__v8_internal_Print_TransitionTree+0x1999dc>
103de23b4: b9400288    	ldr	w8, [x20]
103de23b8: b94002c9    	ldr	w9, [x22]
103de23bc: 6b09011f    	cmp	w8, w9
103de23c0: 54000120    	b.eq	0x103de23e4 <__v8_internal_Print_TransitionTree+0x1999fc>
103de23c4: aa1603e0    	mov	x0, x22
103de23c8: 970b55cd    	bl	0x1000b7afc <_cxxbridge1$slice$new+0x72020>
103de23cc: f9400268    	ldr	x8, [x19]
103de23d0: 91404109    	add	x9, x8, #0x10, lsl #12  ; =0x10000
103de23d4: f945e920    	ldr	x0, [x9, #0xbd0]
103de23d8: f9400281    	ldr	x1, [x20]
103de23dc: 9757a0b4    	bl	0x1013ca6ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x570c04>
103de23e0: f9001e60    	str	x0, [x19, #0x38]
103de23e4: a9427bfd    	ldp	x29, x30, [sp, #0x20]
103de23e8: a9414ff4    	ldp	x20, x19, [sp, #0x10]
103de23ec: a8c357f6    	ldp	x22, x21, [sp], #0x30
103de23f0: d65f03c0    	ret
103de23f4: d4200000    	brk	#0
103de23f8: d4400000    	hlt	#0
103de23fc: d4200020    	brk	#0x1
103de2400: d10183ff    	sub	sp, sp, #0x60
103de2404: a90167fa    	stp	x26, x25, [sp, #0x10]
103de2408: a9025ff8    	stp	x24, x23, [sp, #0x20]
103de240c: a90357f6    	stp	x22, x21, [sp, #0x30]
103de2410: a9044ff4    	stp	x20, x19, [sp, #0x40]
103de2414: a9057bfd    	stp	x29, x30, [sp, #0x50]
103de2418: 910143fd    	add	x29, sp, #0x50
103de241c: aa0103f4    	mov	x20, x1
103de2420: aa0003f3    	mov	x19, x0
103de2424: f9400028    	ldr	x8, [x1]
103de2428: b842f10b    	ldur	w11, [x8, #0x2f]
103de242c: b842f109    	ldur	w9, [x8, #0x2f]
103de2430: d0030f80    	adrp	x0, 0x109fd4000 <dyld_stub_binder+0x109fd4000>
103de2434: 9129a000    	add	x0, x0, #0xa68
103de2438: f940000a    	ldr	x10, [x0]
103de243c: d63f0140    	blr	x10
103de2440: f940000a    	ldr	x10, [x0]
103de2444: b842b10c    	ldur	w12, [x8, #0x2b]
103de2448: 53037d8c    	lsr	w12, w12, #3
103de244c: f941694a    	ldr	x10, [x10, #0x2d0]
103de2450: 927d658c    	and	x12, x12, #0x1ffffff8
103de2454: f86c694a    	ldr	x10, [x10, x12]
103de2458: 924f194c    	and	x12, x10, #0xfe000000000000
103de245c: 9248dd4a    	and	x10, x10, #0xff00ffffffffffff
103de2460: d2e016cd    	mov	x13, #0xb6000000000000  ; =51228445761339392
103de2464: eb0d019f    	cmp	x12, x13
103de2468: 9a9f014a    	csel	x10, x10, xzr, eq
103de246c: 3618004b    	tbz	w11, #0x3, 0x103de2474 <__v8_internal_Print_TransitionTree+0x199a8c>
103de2470: 37201ba9    	tbnz	w9, #0x4, 0x103de27e4 <__v8_internal_Print_TransitionTree+0x199dfc>
103de2474: f8413108    	ldur	x8, [x8, #0x13]
103de2478: d35dfd17    	lsr	x23, x8, #29
103de247c: a9412a68    	ldp	x8, x10, [x19, #0x10]
103de2480: 91000909    	add	x9, x8, #0x2
103de2484: eb0a013f    	cmp	x9, x10
103de2488: 54001302    	b.hs	0x103de26e8 <__v8_internal_Print_TransitionTree+0x199d00>
103de248c: 38c01519    	ldrsb	w25, [x8], #0x1
103de2490: f9000a68    	str	x8, [x19, #0x10]
103de2494: 36f80099    	tbz	w25, #0x1f, 0x103de24a4 <__v8_internal_Print_TransitionTree+0x199abc>
103de2498: 39400108    	ldrb	w8, [x8]
103de249c: f9000a69    	str	x9, [x19, #0x10]
103de24a0: 33196119    	bfi	w25, w8, #7, #25
103de24a4: aa1303e0    	mov	x0, x19
103de24a8: 94000cea    	bl	0x103de5850 <__v8_internal_Print_TransitionTree+0x19ce68>
103de24ac: 37000140    	tbnz	w0, #0x0, 0x103de24d4 <__v8_internal_Print_TransitionTree+0x199aec>
103de24b0: d2800018    	mov	x24, #0x0               ; =0
103de24b4: aa1803e0    	mov	x0, x24
103de24b8: a9457bfd    	ldp	x29, x30, [sp, #0x50]
103de24bc: a9444ff4    	ldp	x20, x19, [sp, #0x40]
103de24c0: a94357f6    	ldp	x22, x21, [sp, #0x30]
103de24c4: a9425ff8    	ldp	x24, x23, [sp, #0x20]
103de24c8: a94167fa    	ldp	x26, x25, [sp, #0x10]
103de24cc: 910183ff    	add	sp, sp, #0x60
103de24d0: d65f03c0    	ret
103de24d4: aa0103f5    	mov	x21, x1
103de24d8: aa1303e0    	mov	x0, x19
103de24dc: 94000cdd    	bl	0x103de5850 <__v8_internal_Print_TransitionTree+0x19ce68>
103de24e0: 7200001f    	tst	w0, #0x1
103de24e4: 9a9f1036    	csel	x22, x1, xzr, ne
103de24e8: eb1502e8    	subs	x8, x23, x21
103de24ec: 1a9f27e9    	cset	w9, lo
103de24f0: 2a200129    	orn	w9, w9, w0
103de24f4: eb0802df    	cmp	x22, x8
103de24f8: 1a9f97e8    	cset	w8, hi
103de24fc: 2a080128    	orr	w8, w9, w8
103de2500: 3707fd88    	tbnz	w8, #0x0, 0x103de24b0 <__v8_internal_Print_TransitionTree+0x199ac8>
103de2504: b9402268    	ldr	w8, [x19, #0x20]
103de2508: 7100351f    	cmp	w8, #0xd
103de250c: 540001e8    	b.hi	0x103de2548 <__v8_internal_Print_TransitionTree+0x199b60>
103de2510: 3940a268    	ldrb	w8, [x19, #0x28]
103de2514: 350001a8    	cbnz	w8, 0x103de2548 <__v8_internal_Print_TransitionTree+0x199b60>
103de2518: 52800001    	mov	w1, #0x0                ; =0
103de251c: 14000017    	b	0x103de2578 <__v8_internal_Print_TransitionTree+0x199b90>
103de2520: 52800138    	mov	w24, #0x9               ; =9
103de2524: 52800119    	mov	w25, #0x8               ; =8
103de2528: d1000728    	sub	x8, x25, #0x1
103de252c: aa1602a9    	orr	x9, x21, x22
103de2530: ea09011f    	tst	x8, x9
103de2534: 54fffbe1    	b.ne	0x103de24b0 <__v8_internal_Print_TransitionTree+0x199ac8>
103de2538: 1400008b    	b	0x103de2764 <__v8_internal_Print_TransitionTree+0x199d7c>
103de253c: 52800158    	mov	w24, #0xa               ; =10
103de2540: 52800039    	mov	w25, #0x1               ; =1
103de2544: 17fffff9    	b	0x103de2528 <__v8_internal_Print_TransitionTree+0x199b40>
103de2548: a9412a69    	ldp	x9, x10, [x19, #0x10]
103de254c: 91001528    	add	x8, x9, #0x5
103de2550: eb0a011f    	cmp	x8, x10
103de2554: 540017e2    	b.hs	0x103de2850 <__v8_internal_Print_TransitionTree+0x199e68>
103de2558: aa0903eb    	mov	x11, x9
103de255c: 3840156a    	ldrb	w10, [x11], #0x1
103de2560: f9000a6b    	str	x11, [x19, #0x10]
103de2564: 373802ea    	tbnz	w10, #0x7, 0x103de25c0 <__v8_internal_Print_TransitionTree+0x199bd8>
103de2568: 52800028    	mov	w8, #0x1                ; =1
103de256c: aa0a8100    	orr	x0, x8, x10, lsl #32
103de2570: 3607fa00    	tbz	w0, #0x0, 0x103de24b0 <__v8_internal_Print_TransitionTree+0x199ac8>
103de2574: d360fc01    	lsr	x1, x0, #32
103de2578: d2800018    	mov	x24, #0x0               ; =0
103de257c: b9402677    	ldr	w23, [x19, #0x24]
103de2580: 110006e8    	add	w8, w23, #0x1
103de2584: b9002668    	str	w8, [x19, #0x24]
103de2588: 12001f28    	and	w8, w25, #0xff
103de258c: 7101851f    	cmp	w8, #0x61
103de2590: 540004cc    	b.gt	0x103de2628 <__v8_internal_Print_TransitionTree+0x199c40>
103de2594: 7101151f    	cmp	w8, #0x45
103de2598: 540002ec    	b.gt	0x103de25f4 <__v8_internal_Print_TransitionTree+0x199c0c>
103de259c: 7101091f    	cmp	w8, #0x42
103de25a0: 5400024d    	b.le	0x103de25e8 <__v8_internal_Print_TransitionTree+0x199c00>
103de25a4: 71010d1f    	cmp	w8, #0x43
103de25a8: 54fffca0    	b.eq	0x103de253c <__v8_internal_Print_TransitionTree+0x199b54>
103de25ac: 7101111f    	cmp	w8, #0x44
103de25b0: 54fff821    	b.ne	0x103de24b4 <__v8_internal_Print_TransitionTree+0x199acc>
103de25b4: 528000d8    	mov	w24, #0x6               ; =6
103de25b8: 52800099    	mov	w25, #0x4               ; =4
103de25bc: 17ffffdb    	b	0x103de2528 <__v8_internal_Print_TransitionTree+0x199b40>
103de25c0: 1200194a    	and	w10, w10, #0x7f
103de25c4: 39c0052c    	ldrsb	w12, [x9, #0x1]
103de25c8: 9100092b    	add	x11, x9, #0x2
103de25cc: f9000a6b    	str	x11, [x19, #0x10]
103de25d0: 53191d8b    	ubfiz	w11, w12, #7, #8
103de25d4: 37f8062c    	tbnz	w12, #0x1f, 0x103de2698 <__v8_internal_Print_TransitionTree+0x199cb0>
103de25d8: 2a0a0168    	orr	w8, w11, w10
103de25dc: 52800029    	mov	w9, #0x1                ; =1
103de25e0: aa088120    	orr	x0, x9, x8, lsl #32
103de25e4: 17ffffe3    	b	0x103de2570 <__v8_internal_Print_TransitionTree+0x199b88>
103de25e8: 540008a1    	b.ne	0x103de26fc <__v8_internal_Print_TransitionTree+0x199d14>
103de25ec: 52800058    	mov	w24, #0x2               ; =2
103de25f0: 17ffffd4    	b	0x103de2540 <__v8_internal_Print_TransitionTree+0x199b58>
103de25f4: 7101191f    	cmp	w8, #0x46
103de25f8: 54fff940    	b.eq	0x103de2520 <__v8_internal_Print_TransitionTree+0x199b38>
103de25fc: 7101451f    	cmp	w8, #0x51
103de2600: 540000c0    	b.eq	0x103de2618 <__v8_internal_Print_TransitionTree+0x199c30>
103de2604: 71015d1f    	cmp	w8, #0x57
103de2608: 54fff561    	b.ne	0x103de24b4 <__v8_internal_Print_TransitionTree+0x199acc>
103de260c: 52800098    	mov	w24, #0x4               ; =4
103de2610: 52800059    	mov	w25, #0x2               ; =2
103de2614: 17ffffc5    	b	0x103de2528 <__v8_internal_Print_TransitionTree+0x199b40>
103de2618: 52800198    	mov	w24, #0xc               ; =12
103de261c: 17ffffc2    	b	0x103de2524 <__v8_internal_Print_TransitionTree+0x199b3c>
103de2620: 52800178    	mov	w24, #0xb               ; =11
103de2624: 17ffffc0    	b	0x103de2524 <__v8_internal_Print_TransitionTree+0x199b3c>
103de2628: 71019d1f    	cmp	w8, #0x67
103de262c: 5400016d    	b.le	0x103de2658 <__v8_internal_Print_TransitionTree+0x199c70>
103de2630: 7101a11f    	cmp	w8, #0x68
103de2634: 54000280    	b.eq	0x103de2684 <__v8_internal_Print_TransitionTree+0x199c9c>
103de2638: 7101c51f    	cmp	w8, #0x71
103de263c: 54ffff20    	b.eq	0x103de2620 <__v8_internal_Print_TransitionTree+0x199c38>
103de2640: 7101dd1f    	cmp	w8, #0x77
103de2644: 54fff381    	b.ne	0x103de24b4 <__v8_internal_Print_TransitionTree+0x199acc>
103de2648: 52800078    	mov	w24, #0x3               ; =3
103de264c: 17fffff1    	b	0x103de2610 <__v8_internal_Print_TransitionTree+0x199c28>
103de2650: 528000b8    	mov	w24, #0x5               ; =5
103de2654: 17ffffd9    	b	0x103de25b8 <__v8_internal_Print_TransitionTree+0x199bd0>
103de2658: 7101891f    	cmp	w8, #0x62
103de265c: 540000e0    	b.eq	0x103de2678 <__v8_internal_Print_TransitionTree+0x199c90>
103de2660: 7101911f    	cmp	w8, #0x64
103de2664: 54ffff60    	b.eq	0x103de2650 <__v8_internal_Print_TransitionTree+0x199c68>
103de2668: 7101991f    	cmp	w8, #0x66
103de266c: 54fff241    	b.ne	0x103de24b4 <__v8_internal_Print_TransitionTree+0x199acc>
103de2670: 52800118    	mov	w24, #0x8               ; =8
103de2674: 17ffffd1    	b	0x103de25b8 <__v8_internal_Print_TransitionTree+0x199bd0>
103de2678: 52800039    	mov	w25, #0x1               ; =1
103de267c: 52800038    	mov	w24, #0x1               ; =1
103de2680: 17ffffaa    	b	0x103de2528 <__v8_internal_Print_TransitionTree+0x199b40>
103de2684: d0030ae8    	adrp	x8, 0x109f40000 <dyld_stub_binder+0x109f40000>
103de2688: 3940a108    	ldrb	w8, [x8, #0x28]
103de268c: 34fff128    	cbz	w8, 0x103de24b0 <__v8_internal_Print_TransitionTree+0x199ac8>
103de2690: 528000f8    	mov	w24, #0x7               ; =7
103de2694: 17ffffdf    	b	0x103de2610 <__v8_internal_Print_TransitionTree+0x199c28>
103de2698: 1219196b    	and	w11, w11, #0x3f80
103de269c: 2a0a016a    	orr	w10, w11, w10
103de26a0: 39c0092c    	ldrsb	w12, [x9, #0x2]
103de26a4: 91000d2b    	add	x11, x9, #0x3
103de26a8: f9000a6b    	str	x11, [x19, #0x10]
103de26ac: 53121d8b    	ubfiz	w11, w12, #14, #8
103de26b0: 36fff94c    	tbz	w12, #0x1f, 0x103de25d8 <__v8_internal_Print_TransitionTree+0x199bf0>
103de26b4: 1212196b    	and	w11, w11, #0x1fc000
103de26b8: 2a0a016a    	orr	w10, w11, w10
103de26bc: 39c00d2c    	ldrsb	w12, [x9, #0x3]
103de26c0: 91001129    	add	x9, x9, #0x4
103de26c4: f9000a69    	str	x9, [x19, #0x10]
103de26c8: 530b1d8b    	ubfiz	w11, w12, #21, #8
103de26cc: 36fff86c    	tbz	w12, #0x1f, 0x103de25d8 <__v8_internal_Print_TransitionTree+0x199bf0>
103de26d0: 120b196b    	and	w11, w11, #0xfe00000
103de26d4: 39400129    	ldrb	w9, [x9]
103de26d8: f9000a68    	str	x8, [x19, #0x10]
103de26dc: 2a097168    	orr	w8, w11, w9, lsl #28
103de26e0: 2a0a0108    	orr	w8, w8, w10
103de26e4: 17ffffbe    	b	0x103de25dc <__v8_internal_Print_TransitionTree+0x199bf4>
103de26e8: aa1303e0    	mov	x0, x19
103de26ec: 94000cb1    	bl	0x103de59b0 <__v8_internal_Print_TransitionTree+0x19cfc8>
103de26f0: 3607ee00    	tbz	w0, #0x0, 0x103de24b0 <__v8_internal_Print_TransitionTree+0x199ac8>
103de26f4: 53083c19    	ubfx	w25, w0, #8, #8
103de26f8: 17ffff6b    	b	0x103de24a4 <__v8_internal_Print_TransitionTree+0x199abc>
103de26fc: 7100fd1f    	cmp	w8, #0x3f
103de2700: 54ffeda1    	b.ne	0x103de24b4 <__v8_internal_Print_TransitionTree+0x199acc>
103de2704: f9400280    	ldr	x0, [x20]
103de2708: 91003fe2    	add	x2, sp, #0xf
103de270c: 91003be3    	add	x3, sp, #0xe
103de2710: 940009cc    	bl	0x103de4e40 <__v8_internal_Print_TransitionTree+0x19c458>
103de2714: 34ffece0    	cbz	w0, 0x103de24b0 <__v8_internal_Print_TransitionTree+0x199ac8>
103de2718: f9400260    	ldr	x0, [x19]
103de271c: 39403ff9    	ldrb	w25, [sp, #0xf]
103de2720: aa1403e1    	mov	x1, x20
103de2724: aa1503e2    	mov	x2, x21
103de2728: aa1603e3    	mov	x3, x22
103de272c: aa1903e4    	mov	x4, x25
103de2730: 97faac14    	bl	0x103c8d780 <__v8_internal_Print_TransitionTree+0x44d98>
103de2734: 39403be9    	ldrb	w9, [sp, #0xe]
103de2738: f9400008    	ldr	x8, [x0]
103de273c: b841310a    	ldur	w10, [x8, #0x13]
103de2740: 721f015f    	tst	w10, #0x2
103de2744: 1a9f17ea    	cset	w10, eq
103de2748: 4a090149    	eor	w9, w10, w9
103de274c: 36000a09    	tbz	w9, #0x0, 0x103de288c <__v8_internal_Print_TransitionTree+0x199ea4>
103de2750: b8413108    	ldur	w8, [x8, #0x13]
103de2754: 12000108    	and	w8, w8, #0x1
103de2758: 6b08033f    	cmp	w25, w8
103de275c: 54000380    	b.eq	0x103de27cc <__v8_internal_Print_TransitionTree+0x199de4>
103de2760: 14000048    	b	0x103de2880 <__v8_internal_Print_TransitionTree+0x199e98>
103de2764: f9400280    	ldr	x0, [x20]
103de2768: 910037e2    	add	x2, sp, #0xd
103de276c: 910033e3    	add	x3, sp, #0xc
103de2770: 940009b4    	bl	0x103de4e40 <__v8_internal_Print_TransitionTree+0x19c458>
103de2774: 34ffe9e0    	cbz	w0, 0x103de24b0 <__v8_internal_Print_TransitionTree+0x199ac8>
103de2778: f9400260    	ldr	x0, [x19]
103de277c: dac00328    	rbit	x8, x25
103de2780: dac01108    	clz	x8, x8
103de2784: 9ac826c4    	lsr	x4, x22, x8
103de2788: 394037f6    	ldrb	w22, [sp, #0xd]
103de278c: aa1803e1    	mov	x1, x24
103de2790: aa1403e2    	mov	x2, x20
103de2794: aa1503e3    	mov	x3, x21
103de2798: aa1603e5    	mov	x5, x22
103de279c: 97285a49    	bl	0x1007f90c0 <_icu4x_Locale_destroy_mv1+0xdbffc>
103de27a0: f9400008    	ldr	x8, [x0]
103de27a4: b8413109    	ldur	w9, [x8, #0x13]
103de27a8: 12000129    	and	w9, w9, #0x1
103de27ac: 6b0902df    	cmp	w22, w9
103de27b0: 54000561    	b.ne	0x103de285c <__v8_internal_Print_TransitionTree+0x199e74>
103de27b4: 394033e9    	ldrb	w9, [sp, #0xc]
103de27b8: b8413108    	ldur	w8, [x8, #0x13]
103de27bc: 721f011f    	tst	w8, #0x2
103de27c0: 1a9f17e8    	cset	w8, eq
103de27c4: 4a090108    	eor	w8, w8, w9
103de27c8: 36000508    	tbz	w8, #0x0, 0x103de2868 <__v8_internal_Print_TransitionTree+0x199e80>
103de27cc: aa0003f8    	mov	x24, x0
103de27d0: aa1303e0    	mov	x0, x19
103de27d4: aa1703e1    	mov	x1, x23
103de27d8: aa1803e2    	mov	x2, x24
103de27dc: 97d436d9    	bl	0x1032f0340 <_media$cxxbridge1$199$init_symphonia_decoder+0x6f98f0>
103de27e0: 17ffff35    	b	0x103de24b4 <__v8_internal_Print_TransitionTree+0x199acc>
103de27e4: b500006a    	cbnz	x10, 0x103de27f0 <__v8_internal_Print_TransitionTree+0x199e08>
103de27e8: d2800017    	mov	x23, #0x0               ; =0
103de27ec: 17ffff24    	b	0x103de247c <__v8_internal_Print_TransitionTree+0x199a94>
103de27f0: 3940cd48    	ldrb	w8, [x10, #0x33]
103de27f4: 36000408    	tbz	w8, #0x0, 0x103de2874 <__v8_internal_Print_TransitionTree+0x199e8c>
103de27f8: 3940d148    	ldrb	w8, [x10, #0x34]
103de27fc: 360003c8    	tbz	w8, #0x0, 0x103de2874 <__v8_internal_Print_TransitionTree+0x199e8c>
103de2800: a9415548    	ldp	x8, x21, [x10, #0x10]
103de2804: b5000095    	cbnz	x21, 0x103de2814 <__v8_internal_Print_TransitionTree+0x199e2c>
103de2808: 91002108    	add	x8, x8, #0x8
103de280c: c8dffd17    	ldar	x23, [x8]
103de2810: 17ffff1b    	b	0x103de247c <__v8_internal_Print_TransitionTree+0x199a94>
103de2814: 910022a9    	add	x9, x21, #0x8
103de2818: 5280002a    	mov	w10, #0x1               ; =1
103de281c: f82a012a    	ldadd	x10, x10, [x9]
103de2820: 91002108    	add	x8, x8, #0x8
103de2824: c8dffd17    	ldar	x23, [x8]
103de2828: 92800008    	mov	x8, #-0x1               ; =-1
103de282c: f8e80128    	ldaddal	x8, x8, [x9]
103de2830: b5ffe268    	cbnz	x8, 0x103de247c <__v8_internal_Print_TransitionTree+0x199a94>
103de2834: f94002a8    	ldr	x8, [x21]
103de2838: f9400908    	ldr	x8, [x8, #0x10]
103de283c: aa1503e0    	mov	x0, x21
103de2840: d63f0100    	blr	x8
103de2844: aa1503e0    	mov	x0, x21
103de2848: 9786b5f6    	bl	0x101f90020 <_rust_png$cxxbridge1$199$Reader$has_trns_chunk+0x4800>
103de284c: 17ffff0c    	b	0x103de247c <__v8_internal_Print_TransitionTree+0x199a94>
103de2850: aa1303e0    	mov	x0, x19
103de2854: 975d4eab    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
103de2858: 17ffff46    	b	0x103de2570 <__v8_internal_Print_TransitionTree+0x199b88>
103de285c: d4200000    	brk	#0
103de2860: d4400000    	hlt	#0
103de2864: d4200020    	brk	#0x1
103de2868: d4200000    	brk	#0
103de286c: d4400000    	hlt	#0
103de2870: d4200020    	brk	#0x1
103de2874: d4200000    	brk	#0
103de2878: d4400000    	hlt	#0
103de287c: d4200020    	brk	#0x1
103de2880: d4200000    	brk	#0
103de2884: d4400000    	hlt	#0
103de2888: d4200020    	brk	#0x1
103de288c: d4200000    	brk	#0
103de2890: d4400000    	hlt	#0
103de2894: d4200020    	brk	#0x1
103de2898: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
103de289c: a9017bfd    	stp	x29, x30, [sp, #0x10]
103de28a0: 910043fd    	add	x29, sp, #0x10
103de28a4: aa0003f3    	mov	x19, x0
103de28a8: a9412809    	ldp	x9, x10, [x0, #0x10]
103de28ac: 91001528    	add	x8, x9, #0x5
103de28b0: eb0a011f    	cmp	x8, x10
103de28b4: 54000722    	b.hs	0x103de2998 <__v8_internal_Print_TransitionTree+0x199fb0>
103de28b8: aa0903eb    	mov	x11, x9
103de28bc: 3840156a    	ldrb	w10, [x11], #0x1
103de28c0: f9000a6b    	str	x11, [x19, #0x10]
103de28c4: 373801ea    	tbnz	w10, #0x7, 0x103de2900 <__v8_internal_Print_TransitionTree+0x199f18>
103de28c8: 52800028    	mov	w8, #0x1                ; =1
103de28cc: aa0a8100    	orr	x0, x8, x10, lsl #32
103de28d0: 36000100    	tbz	w0, #0x0, 0x103de28f0 <__v8_internal_Print_TransitionTree+0x199f08>
103de28d4: d360fc14    	lsr	x20, x0, #32
103de28d8: aa1403e0    	mov	x0, x20
103de28dc: 97fd6291    	bl	0x103d3b320 <__v8_internal_Print_TransitionTree+0xf2938>
103de28e0: a9412262    	ldp	x2, x8, [x19, #0x10]
103de28e4: cb020108    	sub	x8, x8, x2
103de28e8: eb08001f    	cmp	x0, x8
103de28ec: 540001e9    	b.ls	0x103de2928 <__v8_internal_Print_TransitionTree+0x199f40>
103de28f0: d2800000    	mov	x0, #0x0                ; =0
103de28f4: a9417bfd    	ldp	x29, x30, [sp, #0x10]
103de28f8: a8c24ff4    	ldp	x20, x19, [sp], #0x20
103de28fc: d65f03c0    	ret
103de2900: 1200194a    	and	w10, w10, #0x7f
103de2904: 39c0052c    	ldrsb	w12, [x9, #0x1]
103de2908: 9100092b    	add	x11, x9, #0x2
103de290c: f9000a6b    	str	x11, [x19, #0x10]
103de2910: 53191d8b    	ubfiz	w11, w12, #7, #8
103de2914: 37f801ac    	tbnz	w12, #0x1f, 0x103de2948 <__v8_internal_Print_TransitionTree+0x199f60>
103de2918: 2a0a0168    	orr	w8, w11, w10
103de291c: 52800029    	mov	w9, #0x1                ; =1
103de2920: aa088120    	orr	x0, x9, x8, lsl #32
103de2924: 17ffffeb    	b	0x103de28d0 <__v8_internal_Print_TransitionTree+0x199ee8>
103de2928: aa0003e3    	mov	x3, x0
103de292c: 8b000048    	add	x8, x2, x0
103de2930: f9000a68    	str	x8, [x19, #0x10]
103de2934: f9400260    	ldr	x0, [x19]
103de2938: aa1403e1    	mov	x1, x20
103de293c: a9417bfd    	ldp	x29, x30, [sp, #0x10]
103de2940: a8c24ff4    	ldp	x20, x19, [sp], #0x20
103de2944: 17fd627e    	b	0x103d3b33c <__v8_internal_Print_TransitionTree+0xf2954>
103de2948: 1219196b    	and	w11, w11, #0x3f80
103de294c: 2a0a016a    	orr	w10, w11, w10
103de2950: 39c0092c    	ldrsb	w12, [x9, #0x2]
103de2954: 91000d2b    	add	x11, x9, #0x3
103de2958: f9000a6b    	str	x11, [x19, #0x10]
103de295c: 53121d8b    	ubfiz	w11, w12, #14, #8
103de2960: 36fffdcc    	tbz	w12, #0x1f, 0x103de2918 <__v8_internal_Print_TransitionTree+0x199f30>
103de2964: 1212196b    	and	w11, w11, #0x1fc000
103de2968: 2a0a016a    	orr	w10, w11, w10
103de296c: 39c00d2c    	ldrsb	w12, [x9, #0x3]
103de2970: 91001129    	add	x9, x9, #0x4
103de2974: f9000a69    	str	x9, [x19, #0x10]
103de2978: 530b1d8b    	ubfiz	w11, w12, #21, #8
103de297c: 36fffcec    	tbz	w12, #0x1f, 0x103de2918 <__v8_internal_Print_TransitionTree+0x199f30>
103de2980: 120b196b    	and	w11, w11, #0xfe00000
103de2984: 39400129    	ldrb	w9, [x9]
103de2988: f9000a68    	str	x8, [x19, #0x10]
103de298c: 2a097168    	orr	w8, w11, w9, lsl #28
103de2990: 2a0a0108    	orr	w8, w8, w10
103de2994: 17ffffe2    	b	0x103de291c <__v8_internal_Print_TransitionTree+0x199f34>
103de2998: aa1303e0    	mov	x0, x19
103de299c: 975d4e59    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
103de29a0: 17ffffcc    	b	0x103de28d0 <__v8_internal_Print_TransitionTree+0x199ee8>
103de29a4: 00000000    	udf	#0x0
103de29a8: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
103de29ac: a9017bfd    	stp	x29, x30, [sp, #0x10]
103de29b0: 910043fd    	add	x29, sp, #0x10
103de29b4: aa0003f3    	mov	x19, x0
103de29b8: a9412809    	ldp	x9, x10, [x0, #0x10]
103de29bc: 91001528    	add	x8, x9, #0x5
103de29c0: eb0a011f    	cmp	x8, x10
103de29c4: 540006c2    	b.hs	0x103de2a9c <__v8_internal_Print_TransitionTree+0x19a0b4>
103de29c8: aa0903eb    	mov	x11, x9
103de29cc: 3840156a    	ldrb	w10, [x11], #0x1
103de29d0: f9000a6b    	str	x11, [x19, #0x10]
103de29d4: 373801aa    	tbnz	w10, #0x7, 0x103de2a08 <__v8_internal_Print_TransitionTree+0x19a020>
103de29d8: 52800028    	mov	w8, #0x1                ; =1
103de29dc: aa0a8100    	orr	x0, x8, x10, lsl #32
103de29e0: 360000c0    	tbz	w0, #0x0, 0x103de29f8 <__v8_internal_Print_TransitionTree+0x19a010>
103de29e4: d360fc02    	lsr	x2, x0, #32
103de29e8: a9412261    	ldp	x1, x8, [x19, #0x10]
103de29ec: cb010108    	sub	x8, x8, x1
103de29f0: eb08005f    	cmp	x2, x8
103de29f4: 540001e9    	b.ls	0x103de2a30 <__v8_internal_Print_TransitionTree+0x19a048>
103de29f8: d2800000    	mov	x0, #0x0                ; =0
103de29fc: a9417bfd    	ldp	x29, x30, [sp, #0x10]
103de2a00: a8c24ff4    	ldp	x20, x19, [sp], #0x20
103de2a04: d65f03c0    	ret
103de2a08: 1200194a    	and	w10, w10, #0x7f
103de2a0c: 39c0052c    	ldrsb	w12, [x9, #0x1]
103de2a10: 9100092b    	add	x11, x9, #0x2
103de2a14: f9000a6b    	str	x11, [x19, #0x10]
103de2a18: 53191d8b    	ubfiz	w11, w12, #7, #8
103de2a1c: 37f8018c    	tbnz	w12, #0x1f, 0x103de2a4c <__v8_internal_Print_TransitionTree+0x19a064>
103de2a20: 2a0a0168    	orr	w8, w11, w10
103de2a24: 52800029    	mov	w9, #0x1                ; =1
103de2a28: aa088120    	orr	x0, x9, x8, lsl #32
103de2a2c: 17ffffed    	b	0x103de29e0 <__v8_internal_Print_TransitionTree+0x199ff8>
103de2a30: 8b020028    	add	x8, x1, x2
103de2a34: f9000a68    	str	x8, [x19, #0x10]
103de2a38: f9400260    	ldr	x0, [x19]
103de2a3c: 52800003    	mov	w3, #0x0                ; =0
103de2a40: a9417bfd    	ldp	x29, x30, [sp, #0x10]
103de2a44: a8c24ff4    	ldp	x20, x19, [sp], #0x20
103de2a48: 17166cae    	b	0x10037dd00 <_cxxbridge1$slice$new+0x338224>
103de2a4c: 1219196b    	and	w11, w11, #0x3f80
103de2a50: 2a0a016a    	orr	w10, w11, w10
103de2a54: 39c0092c    	ldrsb	w12, [x9, #0x2]
103de2a58: 91000d2b    	add	x11, x9, #0x3
103de2a5c: f9000a6b    	str	x11, [x19, #0x10]
103de2a60: 53121d8b    	ubfiz	w11, w12, #14, #8
103de2a64: 36fffdec    	tbz	w12, #0x1f, 0x103de2a20 <__v8_internal_Print_TransitionTree+0x19a038>
103de2a68: 1212196b    	and	w11, w11, #0x1fc000
103de2a6c: 2a0a016a    	orr	w10, w11, w10
103de2a70: 39c00d2c    	ldrsb	w12, [x9, #0x3]
103de2a74: 91001129    	add	x9, x9, #0x4
103de2a78: f9000a69    	str	x9, [x19, #0x10]
103de2a7c: 530b1d8b    	ubfiz	w11, w12, #21, #8
103de2a80: 36fffd0c    	tbz	w12, #0x1f, 0x103de2a20 <__v8_internal_Print_TransitionTree+0x19a038>
103de2a84: 120b196b    	and	w11, w11, #0xfe00000
103de2a88: 39400129    	ldrb	w9, [x9]
103de2a8c: f9000a68    	str	x8, [x19, #0x10]
103de2a90: 2a097168    	orr	w8, w11, w9, lsl #28
103de2a94: 2a0a0108    	orr	w8, w8, w10
103de2a98: 17ffffe3    	b	0x103de2a24 <__v8_internal_Print_TransitionTree+0x19a03c>
103de2a9c: aa1303e0    	mov	x0, x19
103de2aa0: 975d4e18    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
103de2aa4: 17ffffcf    	b	0x103de29e0 <__v8_internal_Print_TransitionTree+0x199ff8>
103de2aa8: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
103de2aac: a90157f6    	stp	x22, x21, [sp, #0x10]
103de2ab0: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de2ab4: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de2ab8: 9100c3fd    	add	x29, sp, #0x30
103de2abc: aa0003f3    	mov	x19, x0
103de2ac0: a9412809    	ldp	x9, x10, [x0, #0x10]
103de2ac4: 91001528    	add	x8, x9, #0x5
103de2ac8: eb0a011f    	cmp	x8, x10
103de2acc: 540008c2    	b.hs	0x103de2be4 <__v8_internal_Print_TransitionTree+0x19a1fc>
103de2ad0: aa0903eb    	mov	x11, x9
103de2ad4: 3840156a    	ldrb	w10, [x11], #0x1
103de2ad8: f9000a6b    	str	x11, [x19, #0x10]
103de2adc: 3738048a    	tbnz	w10, #0x7, 0x103de2b6c <__v8_internal_Print_TransitionTree+0x19a184>
103de2ae0: 52800028    	mov	w8, #0x1                ; =1
103de2ae4: aa0a8114    	orr	x20, x8, x10, lsl #32
103de2ae8: d2800016    	mov	x22, #0x0               ; =0
103de2aec: 36000314    	tbz	w20, #0x0, 0x103de2b4c <__v8_internal_Print_TransitionTree+0x19a164>
103de2af0: d3608288    	ubfx	x8, x20, #32, #1
103de2af4: 350002c8    	cbnz	w8, 0x103de2b4c <__v8_internal_Print_TransitionTree+0x19a164>
103de2af8: d360fe95    	lsr	x21, x20, #32
103de2afc: a9412277    	ldp	x23, x8, [x19, #0x10]
103de2b00: cb170108    	sub	x8, x8, x23
103de2b04: eb0802bf    	cmp	x21, x8
103de2b08: 54000768    	b.hi	0x103de2bf4 <__v8_internal_Print_TransitionTree+0x19a20c>
103de2b0c: 8b1502e8    	add	x8, x23, x21
103de2b10: f9000a68    	str	x8, [x19, #0x10]
103de2b14: f9400260    	ldr	x0, [x19]
103de2b18: b4000275    	cbz	x21, 0x103de2b64 <__v8_internal_Print_TransitionTree+0x19a17c>
103de2b1c: 53017ea1    	lsr	w1, w21, #1
103de2b20: 52800002    	mov	w2, #0x0                ; =0
103de2b24: d2800003    	mov	x3, #0x0                ; =0
103de2b28: 9708da29    	bl	0x1000193cc <__text+0x153cc>
103de2b2c: aa0003f6    	mov	x22, x0
103de2b30: b40000e0    	cbz	x0, 0x103de2b4c <__v8_internal_Print_TransitionTree+0x19a164>
103de2b34: b7f80654    	tbnz	x20, #0x3f, 0x103de2bfc <__v8_internal_Print_TransitionTree+0x19a214>
103de2b38: f94002c8    	ldr	x8, [x22]
103de2b3c: 91002d00    	add	x0, x8, #0xb
103de2b40: aa1703e1    	mov	x1, x23
103de2b44: aa1503e2    	mov	x2, x21
103de2b48: 9539d598    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
103de2b4c: aa1603e0    	mov	x0, x22
103de2b50: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de2b54: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de2b58: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de2b5c: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de2b60: d65f03c0    	ret
103de2b64: 910e8016    	add	x22, x0, #0x3a0
103de2b68: 17fffff9    	b	0x103de2b4c <__v8_internal_Print_TransitionTree+0x19a164>
103de2b6c: 1200194a    	and	w10, w10, #0x7f
103de2b70: 39c0052c    	ldrsb	w12, [x9, #0x1]
103de2b74: 9100092b    	add	x11, x9, #0x2
103de2b78: f9000a6b    	str	x11, [x19, #0x10]
103de2b7c: 53191d8b    	ubfiz	w11, w12, #7, #8
103de2b80: 37f800ac    	tbnz	w12, #0x1f, 0x103de2b94 <__v8_internal_Print_TransitionTree+0x19a1ac>
103de2b84: 2a0a0168    	orr	w8, w11, w10
103de2b88: 52800029    	mov	w9, #0x1                ; =1
103de2b8c: aa088134    	orr	x20, x9, x8, lsl #32
103de2b90: 17ffffd6    	b	0x103de2ae8 <__v8_internal_Print_TransitionTree+0x19a100>
103de2b94: 1219196b    	and	w11, w11, #0x3f80
103de2b98: 2a0a016a    	orr	w10, w11, w10
103de2b9c: 39c0092c    	ldrsb	w12, [x9, #0x2]
103de2ba0: 91000d2b    	add	x11, x9, #0x3
103de2ba4: f9000a6b    	str	x11, [x19, #0x10]
103de2ba8: 53121d8b    	ubfiz	w11, w12, #14, #8
103de2bac: 36fffecc    	tbz	w12, #0x1f, 0x103de2b84 <__v8_internal_Print_TransitionTree+0x19a19c>
103de2bb0: 1212196b    	and	w11, w11, #0x1fc000
103de2bb4: 2a0a016a    	orr	w10, w11, w10
103de2bb8: 39c00d2c    	ldrsb	w12, [x9, #0x3]
103de2bbc: 91001129    	add	x9, x9, #0x4
103de2bc0: f9000a69    	str	x9, [x19, #0x10]
103de2bc4: 530b1d8b    	ubfiz	w11, w12, #21, #8
103de2bc8: 36fffdec    	tbz	w12, #0x1f, 0x103de2b84 <__v8_internal_Print_TransitionTree+0x19a19c>
103de2bcc: 120b196b    	and	w11, w11, #0xfe00000
103de2bd0: 39400129    	ldrb	w9, [x9]
103de2bd4: f9000a68    	str	x8, [x19, #0x10]
103de2bd8: 2a097168    	orr	w8, w11, w9, lsl #28
103de2bdc: 2a0a0108    	orr	w8, w8, w10
103de2be0: 17ffffea    	b	0x103de2b88 <__v8_internal_Print_TransitionTree+0x19a1a0>
103de2be4: aa1303e0    	mov	x0, x19
103de2be8: 975d4dc6    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
103de2bec: aa0003f4    	mov	x20, x0
103de2bf0: 17ffffbe    	b	0x103de2ae8 <__v8_internal_Print_TransitionTree+0x19a100>
103de2bf4: d2800016    	mov	x22, #0x0               ; =0
103de2bf8: 17ffffd5    	b	0x103de2b4c <__v8_internal_Print_TransitionTree+0x19a164>
103de2bfc: d4200000    	brk	#0
103de2c00: d4400000    	hlt	#0
103de2c04: d4200020    	brk	#0x1
103de2c08: f9401808    	ldr	x8, [x0, #0x30]
103de2c0c: f9400108    	ldr	x8, [x8]
103de2c10: b8403109    	ldur	w9, [x8, #0x3]
103de2c14: 6b09003f    	cmp	w1, w9
103de2c18: 540000e2    	b.hs	0x103de2c34 <__v8_internal_Print_TransitionTree+0x19a24c>
103de2c1c: d1000508    	sub	x8, x8, #0x1
103de2c20: 8b214908    	add	x8, x8, w1, uxtw #2
103de2c24: b9400908    	ldr	w8, [x8, #0x8]
103de2c28: 5140bd09    	sub	w9, w8, #0x2f, lsl #12  ; =0x2f000
103de2c2c: 713ff53f    	cmp	w9, #0xffd
103de2c30: 54000061    	b.ne	0x103de2c3c <__v8_internal_Print_TransitionTree+0x19a254>
103de2c34: d2800000    	mov	x0, #0x0                ; =0
103de2c38: d65f03c0    	ret
103de2c3c: 90031d49    	adrp	x9, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
103de2c40: f940a929    	ldr	x9, [x9, #0x150]
103de2c44: aa080121    	orr	x1, x9, x8
103de2c48: f9400008    	ldr	x8, [x0]
103de2c4c: f9411500    	ldr	x0, [x8, #0x228]
103de2c50: f9411909    	ldr	x9, [x8, #0x230]
103de2c54: eb09001f    	cmp	x0, x9
103de2c58: 540000a0    	b.eq	0x103de2c6c <__v8_internal_Print_TransitionTree+0x19a284>
103de2c5c: 91002009    	add	x9, x0, #0x8
103de2c60: f9011509    	str	x9, [x8, #0x228]
103de2c64: f9000001    	str	x1, [x0]
103de2c68: d65f03c0    	ret
103de2c6c: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
103de2c70: 910003fd    	mov	x29, sp
103de2c74: aa0803e0    	mov	x0, x8
103de2c78: 970a1f0c    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
103de2c7c: a8c17bfd    	ldp	x29, x30, [sp], #0x10
103de2c80: d65f03c0    	ret
103de2c84: d10183ff    	sub	sp, sp, #0x60
103de2c88: a9025ff8    	stp	x24, x23, [sp, #0x20]
103de2c8c: a90357f6    	stp	x22, x21, [sp, #0x30]
103de2c90: a9044ff4    	stp	x20, x19, [sp, #0x40]
103de2c94: a9057bfd    	stp	x29, x30, [sp, #0x50]
103de2c98: 910143fd    	add	x29, sp, #0x50
103de2c9c: aa0003f3    	mov	x19, x0
103de2ca0: f9400014    	ldr	x20, [x0]
103de2ca4: f90007f4    	str	x20, [sp, #0x8]
103de2ca8: 9708d291    	bl	0x1000176ec <__text+0x136ec>
103de2cac: f9401288    	ldr	x8, [x20, #0x20]
103de2cb0: eb08001f    	cmp	x0, x8
103de2cb4: 54001803    	b.lo	0x103de2fb4 <__v8_internal_Print_TransitionTree+0x19a5cc>
103de2cb8: a9412a69    	ldp	x9, x10, [x19, #0x10]
103de2cbc: 91001528    	add	x8, x9, #0x5
103de2cc0: eb0a011f    	cmp	x8, x10
103de2cc4: 54001802    	b.hs	0x103de2fc4 <__v8_internal_Print_TransitionTree+0x19a5dc>
103de2cc8: aa0903eb    	mov	x11, x9
103de2ccc: 3840156a    	ldrb	w10, [x11], #0x1
103de2cd0: f9000a6b    	str	x11, [x19, #0x10]
103de2cd4: 373808aa    	tbnz	w10, #0x7, 0x103de2de8 <__v8_internal_Print_TransitionTree+0x19a400>
103de2cd8: 52800028    	mov	w8, #0x1                ; =1
103de2cdc: aa0a8100    	orr	x0, x8, x10, lsl #32
103de2ce0: 36000740    	tbz	w0, #0x0, 0x103de2dc8 <__v8_internal_Print_TransitionTree+0x19a3e0>
103de2ce4: d360fc15    	lsr	x21, x0, #32
103de2ce8: b9402677    	ldr	w23, [x19, #0x24]
103de2cec: 110006e8    	add	w8, w23, #0x1
103de2cf0: b9002668    	str	w8, [x19, #0x24]
103de2cf4: f9400274    	ldr	x20, [x19]
103de2cf8: 9108a288    	add	x8, x20, #0x228
103de2cfc: f90007f4    	str	x20, [sp, #0x8]
103de2d00: 3dc00100    	ldr	q0, [x8]
103de2d04: 3c8103e0    	stur	q0, [sp, #0x10]
103de2d08: b9423a88    	ldr	w8, [x20, #0x238]
103de2d0c: 11000508    	add	w8, w8, #0x1
103de2d10: b9023a88    	str	w8, [x20, #0x238]
103de2d14: f9400260    	ldr	x0, [x19]
103de2d18: 52800061    	mov	w1, #0x3                ; =3
103de2d1c: 52800002    	mov	w2, #0x0                ; =0
103de2d20: 52800003    	mov	w3, #0x0                ; =0
103de2d24: 52800024    	mov	w4, #0x1                ; =1
103de2d28: 52800005    	mov	w5, #0x0                ; =0
103de2d2c: 970d44a5    	bl	0x100133fc0 <_cxxbridge1$slice$new+0xee4e4>
103de2d30: aa0003f6    	mov	x22, x0
103de2d34: f9400260    	ldr	x0, [x19]
103de2d38: aa1603e1    	mov	x1, x22
103de2d3c: aa1503e2    	mov	x2, x21
103de2d40: 974d8080    	bl	0x101142f40 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x2e9498>
103de2d44: 360002c0    	tbz	w0, #0x0, 0x103de2d9c <__v8_internal_Print_TransitionTree+0x19a3b4>
103de2d48: aa1303e0    	mov	x0, x19
103de2d4c: aa1703e1    	mov	x1, x23
103de2d50: aa1603e2    	mov	x2, x22
103de2d54: 97d4357b    	bl	0x1032f0340 <_media$cxxbridge1$199$init_symphonia_decoder+0x6f98f0>
103de2d58: aa1303e0    	mov	x0, x19
103de2d5c: aa1603e1    	mov	x1, x22
103de2d60: 52800802    	mov	w2, #0x40               ; =64
103de2d64: 52800003    	mov	w3, #0x0                ; =0
103de2d68: 976228cf    	bl	0x10166d0a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8135fc>
103de2d6c: 36000180    	tbz	w0, #0x0, 0x103de2d9c <__v8_internal_Print_TransitionTree+0x19a3b4>
103de2d70: a9412a69    	ldp	x9, x10, [x19, #0x10]
103de2d74: 91001528    	add	x8, x9, #0x5
103de2d78: eb0a011f    	cmp	x8, x10
103de2d7c: 54001322    	b.hs	0x103de2fe0 <__v8_internal_Print_TransitionTree+0x19a5f8>
103de2d80: aa0903eb    	mov	x11, x9
103de2d84: 3840156a    	ldrb	w10, [x11], #0x1
103de2d88: f9000a6b    	str	x11, [x19, #0x10]
103de2d8c: 373806aa    	tbnz	w10, #0x7, 0x103de2e60 <__v8_internal_Print_TransitionTree+0x19a478>
103de2d90: 52800028    	mov	w8, #0x1                ; =1
103de2d94: aa0a8108    	orr	x8, x8, x10, lsl #32
103de2d98: 37000788    	tbnz	w8, #0x0, 0x103de2e88 <__v8_internal_Print_TransitionTree+0x19a4a0>
103de2d9c: d2800013    	mov	x19, #0x0               ; =0
103de2da0: b4000174    	cbz	x20, 0x103de2dcc <__v8_internal_Print_TransitionTree+0x19a3e4>
103de2da4: a94123e9    	ldp	x9, x8, [sp, #0x10]
103de2da8: f9011689    	str	x9, [x20, #0x228]
103de2dac: b9423a89    	ldr	w9, [x20, #0x238]
103de2db0: 51000529    	sub	w9, w9, #0x1
103de2db4: b9023a89    	str	w9, [x20, #0x238]
103de2db8: f9411a89    	ldr	x9, [x20, #0x230]
103de2dbc: eb08013f    	cmp	x9, x8
103de2dc0: 54000060    	b.eq	0x103de2dcc <__v8_internal_Print_TransitionTree+0x19a3e4>
103de2dc4: 14000083    	b	0x103de2fd0 <__v8_internal_Print_TransitionTree+0x19a5e8>
103de2dc8: d2800013    	mov	x19, #0x0               ; =0
103de2dcc: aa1303e0    	mov	x0, x19
103de2dd0: a9457bfd    	ldp	x29, x30, [sp, #0x50]
103de2dd4: a9444ff4    	ldp	x20, x19, [sp, #0x40]
103de2dd8: a94357f6    	ldp	x22, x21, [sp, #0x30]
103de2ddc: a9425ff8    	ldp	x24, x23, [sp, #0x20]
103de2de0: 910183ff    	add	sp, sp, #0x60
103de2de4: d65f03c0    	ret
103de2de8: 1200194a    	and	w10, w10, #0x7f
103de2dec: 39c0052c    	ldrsb	w12, [x9, #0x1]
103de2df0: 9100092b    	add	x11, x9, #0x2
103de2df4: f9000a6b    	str	x11, [x19, #0x10]
103de2df8: 53191d8b    	ubfiz	w11, w12, #7, #8
103de2dfc: 37f800ac    	tbnz	w12, #0x1f, 0x103de2e10 <__v8_internal_Print_TransitionTree+0x19a428>
103de2e00: 2a0a0168    	orr	w8, w11, w10
103de2e04: 52800029    	mov	w9, #0x1                ; =1
103de2e08: aa088120    	orr	x0, x9, x8, lsl #32
103de2e0c: 17ffffb5    	b	0x103de2ce0 <__v8_internal_Print_TransitionTree+0x19a2f8>
103de2e10: 1219196b    	and	w11, w11, #0x3f80
103de2e14: 2a0a016a    	orr	w10, w11, w10
103de2e18: 39c0092c    	ldrsb	w12, [x9, #0x2]
103de2e1c: 91000d2b    	add	x11, x9, #0x3
103de2e20: f9000a6b    	str	x11, [x19, #0x10]
103de2e24: 53121d8b    	ubfiz	w11, w12, #14, #8
103de2e28: 36fffecc    	tbz	w12, #0x1f, 0x103de2e00 <__v8_internal_Print_TransitionTree+0x19a418>
103de2e2c: 1212196b    	and	w11, w11, #0x1fc000
103de2e30: 2a0a016a    	orr	w10, w11, w10
103de2e34: 39c00d2c    	ldrsb	w12, [x9, #0x3]
103de2e38: 91001129    	add	x9, x9, #0x4
103de2e3c: f9000a69    	str	x9, [x19, #0x10]
103de2e40: 530b1d8b    	ubfiz	w11, w12, #21, #8
103de2e44: 36fffdec    	tbz	w12, #0x1f, 0x103de2e00 <__v8_internal_Print_TransitionTree+0x19a418>
103de2e48: 120b196b    	and	w11, w11, #0xfe00000
103de2e4c: 39400129    	ldrb	w9, [x9]
103de2e50: f9000a68    	str	x8, [x19, #0x10]
103de2e54: 2a097168    	orr	w8, w11, w9, lsl #28
103de2e58: 2a0a0108    	orr	w8, w8, w10
103de2e5c: 17ffffea    	b	0x103de2e04 <__v8_internal_Print_TransitionTree+0x19a41c>
103de2e60: 1200194a    	and	w10, w10, #0x7f
103de2e64: 39c0052c    	ldrsb	w12, [x9, #0x1]
103de2e68: 9100092b    	add	x11, x9, #0x2
103de2e6c: f9000a6b    	str	x11, [x19, #0x10]
103de2e70: 53191d8b    	ubfiz	w11, w12, #7, #8
103de2e74: 37f804ec    	tbnz	w12, #0x1f, 0x103de2f10 <__v8_internal_Print_TransitionTree+0x19a528>
103de2e78: 2a0a0168    	orr	w8, w11, w10
103de2e7c: 52800029    	mov	w9, #0x1                ; =1
103de2e80: aa088128    	orr	x8, x9, x8, lsl #32
103de2e84: 17ffffc5    	b	0x103de2d98 <__v8_internal_Print_TransitionTree+0x19a3b0>
103de2e88: a9412e6a    	ldp	x10, x11, [x19, #0x10]
103de2e8c: 91001549    	add	x9, x10, #0x5
103de2e90: eb0b013f    	cmp	x9, x11
103de2e94: 54000b22    	b.hs	0x103de2ff8 <__v8_internal_Print_TransitionTree+0x19a610>
103de2e98: aa0a03ec    	mov	x12, x10
103de2e9c: 3840158b    	ldrb	w11, [x12], #0x1
103de2ea0: f9000a6c    	str	x12, [x19, #0x10]
103de2ea4: 3738022b    	tbnz	w11, #0x7, 0x103de2ee8 <__v8_internal_Print_TransitionTree+0x19a500>
103de2ea8: 52800029    	mov	w9, #0x1                ; =1
103de2eac: aa0b8129    	orr	x9, x9, x11, lsl #32
103de2eb0: d2800013    	mov	x19, #0x0               ; =0
103de2eb4: ca000108    	eor	x8, x8, x0
103de2eb8: d360fd08    	lsr	x8, x8, #32
103de2ebc: b5fff728    	cbnz	x8, 0x103de2da0 <__v8_internal_Print_TransitionTree+0x19a3b8>
103de2ec0: 3607f709    	tbz	w9, #0x0, 0x103de2da0 <__v8_internal_Print_TransitionTree+0x19a3b8>
103de2ec4: d360fd28    	lsr	x8, x9, #32
103de2ec8: eb0802bf    	cmp	x21, x8
103de2ecc: 54fff6a1    	b.ne	0x103de2da0 <__v8_internal_Print_TransitionTree+0x19a3b8>
103de2ed0: 910023e0    	add	x0, sp, #0x8
103de2ed4: aa1603e1    	mov	x1, x22
103de2ed8: 97755277    	bl	0x101b378b4 <_media$cxxbridge1$199$SymphoniaDecoder$decode+0x1907c>
103de2edc: aa0003f3    	mov	x19, x0
103de2ee0: f94007f4    	ldr	x20, [sp, #0x8]
103de2ee4: 17ffffaf    	b	0x103de2da0 <__v8_internal_Print_TransitionTree+0x19a3b8>
103de2ee8: 1200196b    	and	w11, w11, #0x7f
103de2eec: 39c0054d    	ldrsb	w13, [x10, #0x1]
103de2ef0: 9100094c    	add	x12, x10, #0x2
103de2ef4: f9000a6c    	str	x12, [x19, #0x10]
103de2ef8: 53191dac    	ubfiz	w12, w13, #7, #8
103de2efc: 37f8028d    	tbnz	w13, #0x1f, 0x103de2f4c <__v8_internal_Print_TransitionTree+0x19a564>
103de2f00: 2a0b0189    	orr	w9, w12, w11
103de2f04: 5280002a    	mov	w10, #0x1               ; =1
103de2f08: aa098149    	orr	x9, x10, x9, lsl #32
103de2f0c: 17ffffe9    	b	0x103de2eb0 <__v8_internal_Print_TransitionTree+0x19a4c8>
103de2f10: 1219196b    	and	w11, w11, #0x3f80
103de2f14: 2a0a016a    	orr	w10, w11, w10
103de2f18: 39c0092c    	ldrsb	w12, [x9, #0x2]
103de2f1c: 91000d2b    	add	x11, x9, #0x3
103de2f20: f9000a6b    	str	x11, [x19, #0x10]
103de2f24: 53121d8b    	ubfiz	w11, w12, #14, #8
103de2f28: 36fffa8c    	tbz	w12, #0x1f, 0x103de2e78 <__v8_internal_Print_TransitionTree+0x19a490>
103de2f2c: 1212196b    	and	w11, w11, #0x1fc000
103de2f30: 2a0a016a    	orr	w10, w11, w10
103de2f34: 39c00d2c    	ldrsb	w12, [x9, #0x3]
103de2f38: 91001129    	add	x9, x9, #0x4
103de2f3c: f9000a69    	str	x9, [x19, #0x10]
103de2f40: 530b1d8b    	ubfiz	w11, w12, #21, #8
103de2f44: 36fff9ac    	tbz	w12, #0x1f, 0x103de2e78 <__v8_internal_Print_TransitionTree+0x19a490>
103de2f48: 14000015    	b	0x103de2f9c <__v8_internal_Print_TransitionTree+0x19a5b4>
103de2f4c: 1219198c    	and	w12, w12, #0x3f80
103de2f50: 2a0b018b    	orr	w11, w12, w11
103de2f54: 39c0094d    	ldrsb	w13, [x10, #0x2]
103de2f58: 91000d4c    	add	x12, x10, #0x3
103de2f5c: f9000a6c    	str	x12, [x19, #0x10]
103de2f60: 53121dac    	ubfiz	w12, w13, #14, #8
103de2f64: 36fffced    	tbz	w13, #0x1f, 0x103de2f00 <__v8_internal_Print_TransitionTree+0x19a518>
103de2f68: 1212198c    	and	w12, w12, #0x1fc000
103de2f6c: 2a0b018b    	orr	w11, w12, w11
103de2f70: 39c00d4d    	ldrsb	w13, [x10, #0x3]
103de2f74: 9100114a    	add	x10, x10, #0x4
103de2f78: f9000a6a    	str	x10, [x19, #0x10]
103de2f7c: 530b1dac    	ubfiz	w12, w13, #21, #8
103de2f80: 36fffc0d    	tbz	w13, #0x1f, 0x103de2f00 <__v8_internal_Print_TransitionTree+0x19a518>
103de2f84: 120b198c    	and	w12, w12, #0xfe00000
103de2f88: 3940014a    	ldrb	w10, [x10]
103de2f8c: f9000a69    	str	x9, [x19, #0x10]
103de2f90: 2a0a7189    	orr	w9, w12, w10, lsl #28
103de2f94: 2a0b0129    	orr	w9, w9, w11
103de2f98: 17ffffdb    	b	0x103de2f04 <__v8_internal_Print_TransitionTree+0x19a51c>
103de2f9c: 120b196b    	and	w11, w11, #0xfe00000
103de2fa0: 39400129    	ldrb	w9, [x9]
103de2fa4: f9000a68    	str	x8, [x19, #0x10]
103de2fa8: 2a097168    	orr	w8, w11, w9, lsl #28
103de2fac: 2a0a0108    	orr	w8, w8, w10
103de2fb0: 17ffffb3    	b	0x103de2e7c <__v8_internal_Print_TransitionTree+0x19a494>
103de2fb4: 910023e0    	add	x0, sp, #0x8
103de2fb8: 977d0f62    	bl	0x101d26d40 <_crabby_avifPeekCompatibleFileType+0x93034>
103de2fbc: 34ffe7e0    	cbz	w0, 0x103de2cb8 <__v8_internal_Print_TransitionTree+0x19a2d0>
103de2fc0: 17ffff82    	b	0x103de2dc8 <__v8_internal_Print_TransitionTree+0x19a3e0>
103de2fc4: aa1303e0    	mov	x0, x19
103de2fc8: 975d4cce    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
103de2fcc: 17ffff45    	b	0x103de2ce0 <__v8_internal_Print_TransitionTree+0x19a2f8>
103de2fd0: f9011a88    	str	x8, [x20, #0x230]
103de2fd4: aa1403e0    	mov	x0, x20
103de2fd8: 97159e73    	bl	0x10034a9a4 <_cxxbridge1$slice$new+0x304ec8>
103de2fdc: 17ffff7c    	b	0x103de2dcc <__v8_internal_Print_TransitionTree+0x19a3e4>
103de2fe0: aa0003f7    	mov	x23, x0
103de2fe4: aa1303e0    	mov	x0, x19
103de2fe8: 975d4cc6    	bl	0x101536300 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x6dc858>
103de2fec: aa0003e8    	mov	x8, x0
103de2ff0: aa1703e0    	mov	x0, x23
103de2ff4: 17ffff69    	b	0x103de2d98 <__v8_internal_Print_TransitionTree+0x19a3b0>
103de2ff8: aa0003f7    	mov	x23, x0
103de2ffc: aa1303e0    	mov	x0, x19
