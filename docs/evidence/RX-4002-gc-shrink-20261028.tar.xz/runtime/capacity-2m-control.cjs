'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const t=require('internal/test/binding').internalBinding('v8');const out=process.argv[2];gc();
const accepted=path.join(out,'cap-2000000.rdxgc');t.managedAllocationTraceStart(accepted,2000000,1);const status=t.managedAllocationTraceStop();assert.equal(status,0);
const refused=path.join(out,'cap-2000001-refused.rdxgc');assert.throws(()=>t.managedAllocationTraceStart(refused,2000001,1),{code:'EINVAL'});assert.equal(fs.existsSync(refused),false);
console.log(JSON.stringify({acceptedCapacity:2000000,acceptedStatus:status,refusedCapacity:2000001,refusedNoFile:true,scope:'Start parameter admission only; does not allocate two million extents',runtime:{version:process.version,v8:process.versions.v8,execPath:process.execPath,execArgv:process.execArgv,pid:process.pid}}));
