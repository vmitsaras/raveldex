'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict');
const t=require('internal/test/binding').internalBinding('v8');
const [out]=process.argv.slice(2);gc();
t.managedAllocationTraceStart(out,200000,128);t.managedAllocationTraceMark(100);
const roots=[];
for(let round=0;round<12;round++){
 const candidates=[];
 function Root(){this.base=round;}
 for(let j=0;j<128;j++){const o=new Root();o['property_'+round+'_'+j]=j;candidates.push(o);}
 roots.push(candidates[0],candidates[17],candidates[64]);
 candidates.length=0;
 t.managedAllocationTraceMark(200+round);gc();t.managedAllocationTraceMark(300+round);
}
for(let i=0;i<roots.length;i++)assert.equal(roots[i].base,Math.floor(i/3));
for(let round=0;round<4;round++){let a=[];for(let j=0;j<1500;j++)a.push(new Array(16).fill(j));a=null;gc();}
t.managedAllocationTraceMark(101);const status=t.managedAllocationTraceStop();
console.log(JSON.stringify({status,retained:roots.length,runtime:{version:process.version,v8:process.versions.v8,execPath:process.execPath,execArgv:process.execArgv,pid:process.pid}}));assert.equal(status,0);
