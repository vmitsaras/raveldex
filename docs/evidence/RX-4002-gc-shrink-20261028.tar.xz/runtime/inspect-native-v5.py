from pathlib import Path
import json,hashlib
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime')
def read(p):
 b=p.read_bytes();pos=b.index(b'\n')+1;header=json.loads(b[:pos]);rows=[]
 def u():
  nonlocal pos
  n=s=0
  for k in range(10):
   c=b[pos];pos+=1;n|=(c&127)<<s
   if c<128:return n
   s+=7
  raise ValueError('varint')
 while pos<len(b):
  kind=u()
  if not kind:
   n=u();summary=json.loads(b[pos:pos+n]);pos+=n;assert pos==len(b);return header,rows,summary
  rows.append([kind]+[u() for _ in range(5)])
 raise ValueError('footer')
reports=[]
for p in sorted((r/'native-controls-v5').rglob('*.rdxgc')):
 if p.name=='sentinel.rdxgc':continue
 header,rows,summary=read(p);gc=0;in_gc=False;shrinks=[];moves=0;births={};prior_census={};last_shrinks=[];tail_reuses=[]
 for seq,row in enumerate(rows,1):
  k,a,to,n,old,m=row
  if k==1:births[a]=[seq,n]
  if k==8:gc+=1;in_gc=True;moves=0
  if k==9:in_gc=False
  if k==2:
   moves+=1
   for shrink in last_shrinks:
    tail_start=shrink['address']+shrink['new'];tail_end=shrink['address']+shrink['old']
    if to<tail_end and to+n>tail_start:tail_reuses.append({'moveSequence':seq,'gc':gc,'move':row,'shrink':shrink})
  if k==3 and in_gc:
   shrink={'sequence':seq,'gc':gc,'address':a,'old':old,'new':n,'movesBefore':moves,'birthAtSameAddress':births.get(a),'priorExactCensus':prior_census.get(a),'nextRow':rows[seq] if seq<len(rows) else None};shrinks.append(shrink);last_shrinks.append(shrink)
  if k==10:prior_census[a]=[seq,n]
 reports.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'header':header,'summary':summary,'inGcSizeChanges':shrinks,'laterTailDestinationOverlaps':tail_reuses[:100],'laterTailDestinationOverlapCount':len(tail_reuses)})
(r/'native-controls-v5-inspection.json').write_text(json.dumps(reports,indent=2)+'\n')
for x in reports:print(Path(x['file']).name,'valid',x['summary']['valid'],'gcshrink',x['summary']['gc_pre_move_shrinks'],'allGCsizechanges',len(x['inGcSizeChanges']),'tailoverlap',x['laterTailDestinationOverlapCount'])
