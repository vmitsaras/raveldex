from pathlib import Path
import json,hashlib,os
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime');scope={};exec(compile((r/'inspect-native-v5.py').read_text().split('reports=[]')[0],str(r/'inspect-native-v5.py'),'exec'),scope)
p=r/'native-controls-v5/native-shrink.rdxgc';header,rows,summary=scope['read'](p);gc=0;inside=False;witnesses=[];census={};births={}
for i,row in enumerate(rows):
 k,a,b,n,old,m=row
 if k==1:births[a]=[i+1,n]
 if k==8:gc+=1;inside=True
 if k==9:inside=False
 if k==10:census[a]=[i+1,n]
 if k==3 and inside:
  assert rows[i+1]==[4,a,0,n,0,0];oldwitness=births.get(a);prior=census.get(a);assert (oldwitness and oldwitness[1]==old) or (prior and prior[1]==old),(i,row,oldwitness,prior)
  current=a;movechain=[];found=None
  for j in range(i+2,len(rows)):
   z=rows[j]
   if z[0]==2 and z[1]==current:
    assert z[3]==n,(j,z);current=z[2];movechain.append([j+1,z])
   if z[0]==10 and z[1]==current:
    assert z[3]==n,(j,z);found=[j+1,z];break
   if z[0]==9:break
  assert found,(i,row)
  witnesses.append({'shrinkSequence':i+1,'gc':gc,'sizeChange':row,'birthExactOldExtent':oldwitness if oldwitness and oldwitness[1]==old else None,'previousExactOldCensus':prior if prior and prior[1]==old else None,'immediateSizeUpdateSequence':i+2,'moveChain':movechain,'completedGcExactNewCensus':found})
assert len(witnesses)==summary['gc_pre_move_shrinks']==35
receipt={'scope':'actual Node/V8 direct GC control; exact emitted birth/prior-census old-size witness and sameGC post-shrink exact new-size census; independent interval auditor remains separate','raw':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'runtimeSha256':hashlib.sha256((r/'node-gc-shrink-v5').read_bytes()).hexdigest(),'acceptedTrackedShrinks':len(witnesses),'allWitnessesMatched':True,'witnesses':witnesses}
(r/'actual-native-shrink-exact-witnesses.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='witnesses'}))
reports=json.loads((r/'native-controls-v5-report.json').read_text());checks=[]
for row in reports['runs']:
 try:os.kill(row['pid'],0);absent=False
 except ProcessLookupError:absent=True
 checks.append({'pid':row['pid'],'pgid':row['pgid'],'directChildAbsent':absent})
assert all(x['directChildAbsent'] for x in checks)
(r/'owned-native-process-cleanup.json').write_text(json.dumps({'checks':checks,'allDirectChildrenAbsent':True,'note':'bounded runners wait/reap direct children; process groups only killed on timeout; no timeout occurred'},indent=2)+'\n')
