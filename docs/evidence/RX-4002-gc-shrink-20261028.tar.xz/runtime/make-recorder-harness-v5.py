from pathlib import Path
import hashlib
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime');inc=(r/'recorder-v5.inc').read_text();cl=inc[inc.index('using RDXExtents'):inc.index('base::LazyMutex')]
prefix=r'''// Synthetic recorder controls: exact candidate class, fake heap census only.
// No real V8 GC or product workload. Stub types exist only for compiling class.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <climits>
#include <cinttypes>
#include <map>
#include <vector>
#include <string>
#include <functional>
using Address=uintptr_t;
struct Obj { Address a;int n;int Size(){return n;}Obj elements(){return *this;} };
using Object=Obj;using HeapObject=Obj;using JSArray=Obj;
template<class T> struct Tagged {Obj* p=nullptr;bool is_null(){return !p;}Address address(){return p->a;}Obj* operator->(){return p;} };
struct DisallowGarbageCollection {};
namespace v8 {struct Value{};template<class T>struct Local{T operator*(){return {};}};}
struct Utils {static Tagged<Object>* OpenDirectHandle(v8::Value){return nullptr;}template<class T>static Tagged<Object>* OpenDirectHandle(v8::Local<T>){return nullptr;}};
template<class T,class U>Tagged<T> Cast(Tagged<U>o){return {o.p};}
bool IsHeapObject(Tagged<Object>){return false;}bool IsJSArray(Tagged<HeapObject>){return false;}bool IsFreeSpaceOrFiller(Tagged<HeapObject>){return false;}
enum class GarbageCollector {SCAVENGER=0,MARK_COMPACTOR=1};
struct HeapObjectAllocationTracker {virtual ~HeapObjectAllocationTracker(){};virtual void AllocationEvent(Address,int)=0;virtual void MoveEvent(Address,Address,int)=0;virtual void SizeChangeEvent(Address,int,int)=0;virtual void UpdateObjectSizeEvent(Address,int)=0;};
struct Heap {int count=0;std::vector<Obj> census;std::function<void()> after_census;std::function<void()> before_census;int gc_count(){return count;}void AddHeapObjectAllocationTracker(HeapObjectAllocationTracker*){}void RemoveHeapObjectAllocationTracker(HeapObjectAllocationTracker*){}};
struct HeapObjectIterator {static constexpr int kNoFiltering=0;Heap*h;size_t i=0;HeapObjectIterator(Heap*x,int):h(x){if(h->before_census)h->before_census();}Tagged<HeapObject>Next(){if(i==1 && h->after_census){auto f=h->after_census;h->after_census=nullptr;f();}return {i<h->census.size()?&h->census[i++]:nullptr};}};
'''
# JSArray.elements returns an object handle in actual class; stub adapts unused Inspect.
prefix=prefix.replace('Obj elements(){return *this;}','Obj elements(){return *this;} Address address(){return a;}')
# Return by value in Inspect stub only needs ->Size; Obj operator-> provides it.
prefix=prefix.replace('Address address(){return a;}','Address address(){return a;}Obj* operator->(){return this;}')
main=r'''
int main(int argc,char**argv){assert(argc==2);std::string dir=argv[1];
 auto run=[&](const char*name,auto body,int expected){Heap heap;FILE*f=fopen((dir+"/"+name+".rdxgc").c_str(),"wbx");assert(f);RaveldexManagedAllocationTrace t(&heap,f,65536,16*1048576);assert(t.PrepareBuffer());int n=fprintf(f,"{\"record\":\"header\",\"schema\":\"raveldex-gc-extents-varint-v2\",\"gc_tracked_shrink_mode\":\"pre-move-full-coverage-right-trim-v1\",\"synthetic_control\":true,\"fields\":[\"kind\",\"address\",\"to\",\"bytes\",\"old_bytes\",\"marker\"],\"active_extent_cap_per_map\":65536,\"map_count_max\":5,\"stream_byte_cap\":16777216,\"stdio_buffer_bytes\":65536,\"single_threaded\":true,\"incremental_marking\":false,\"inline_new\":false,\"turbo_allocation_folding\":false,\"collector_overlap_measured\":false,\"physical_memory_measured\":false,\"includes_preexisting_objects\":false}\n");t.NoteHeaderBytes(n);t.Start();body(t,heap);int status=t.Stop(false);printf("%s %d\n",name,status);assert(status==expected);};
 auto begin=[](auto&t,auto&h){++h.count;t.GCBegin(GarbageCollector::MARK_COMPACTOR);};
 auto end=[](auto&t,auto&h,std::initializer_list<Obj> rows){h.census=rows;t.GCEnd(GarbageCollector::MARK_COMPACTOR);};
 run("exact-shrinks-tail-reuse-moves-death",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);t.AllocationEvent(0x2000,968);begin(t,h);t.SizeChangeEvent(0x1000,376,264);t.UpdateObjectSizeEvent(0x1000,264);t.SizeChangeEvent(0x2000,968,760);t.UpdateObjectSizeEvent(0x2000,760);end(t,h,{{0x1000,264},{0x2000,760}});t.Mark(1);t.AllocationEvent(0x4000,112);begin(t,h);t.MoveEvent(0x4000,0x1108,112);end(t,h,{{0x1000,264},{0x1108,112},{0x2000,760}});t.Mark(2);begin(t,h);t.MoveEvent(0x1000,0x5000,264);end(t,h,{{0x5000,264}});t.Mark(3);},0);
 run("preexisting-shrink",[&](auto&t,auto&h){t.AllocationEvent(0x2000,100);begin(t,h);t.SizeChangeEvent(0x1000,376,264);t.UpdateObjectSizeEvent(0x1000,264);end(t,h,{{0x1000,264},{0x2000,100}});},0);
 run("partial-refusal",[&](auto&t,auto&h){t.AllocationEvent(0x1000,264);begin(t,h);t.SizeChangeEvent(0x1000,376,264);t.UpdateObjectSizeEvent(0x1000,264);end(t,h,{});},1);
 run("post-move-tracked-refusal",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);begin(t,h);t.MoveEvent(0x8000,0x9000,64);t.SizeChangeEvent(0x1000,376,264);t.UpdateObjectSizeEvent(0x1000,264);end(t,h,{});},1);
 run("post-move-preexisting-refusal",[&](auto&t,auto&h){begin(t,h);t.MoveEvent(0x8000,0x9000,64);t.SizeChangeEvent(0x1000,376,264);t.UpdateObjectSizeEvent(0x1000,264);end(t,h,{});},1);
 run("post-census-refusal",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);begin(t,h);h.after_census=[&](){t.SizeChangeEvent(0x1000,376,264);t.UpdateObjectSizeEvent(0x1000,264);};end(t,h,{{0x1000,376}});},1);
 run("pre-first-census-refusal",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);begin(t,h);h.before_census=[&](){t.SizeChangeEvent(0x1000,376,264);t.UpdateObjectSizeEvent(0x1000,264);};end(t,h,{{0x1000,376}});},1);
 run("missing-pair-refusal",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);begin(t,h);t.SizeChangeEvent(0x1000,376,264);end(t,h,{});},1);
 run("mismatched-pair-refusal",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);begin(t,h);t.SizeChangeEvent(0x1000,376,264);t.UpdateObjectSizeEvent(0x1000,260);end(t,h,{});},1);
 run("update-only-refusal",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);begin(t,h);t.UpdateObjectSizeEvent(0x1000,264);end(t,h,{});},1);
 run("nonshrinking-refusal",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);begin(t,h);t.SizeChangeEvent(0x1000,376,376);end(t,h,{});},1);
 run("grow-refusal",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);begin(t,h);t.SizeChangeEvent(0x1000,376,384);end(t,h,{});},1);
 run("mutator-shrink",[&](auto&t,auto&h){t.AllocationEvent(0x1000,376);t.SizeChangeEvent(0x1000,376,264);t.UpdateObjectSizeEvent(0x1000,264);},0);
}
'''
(r/'recorder-control-harness-v5.cc').write_text(prefix+cl+main)
(r/'recorder-control-v5-source-sha256.txt').write_text(hashlib.sha256(inc.encode()).hexdigest()+'\n')
