from pathlib import Path
import hashlib,json,subprocess,os,time
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime');old=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc/node-v24.21.0')
before=json.loads((r/'old-tree-before.json').read_text());after=[]
for name,size,mtime,digest in before['files']:
 p=old/name;st=p.stat();actual=hashlib.sha256(p.read_bytes()).hexdigest();after.append([name,st.st_size,st.st_mtime_ns,actual]);assert [name,st.st_size,st.st_mtime_ns,actual]==[name,size,mtime,digest],name
actual_names={str(p.relative_to(old)) for p in old.rglob('*') if p.is_file() and not p.is_symlink()};assert actual_names=={x[0] for x in before['files']}
immutable=hashlib.sha256((old.parent/'node-gc-v3').read_bytes()).hexdigest();assert immutable==before['immutableSha256']
(r/'old-tree-after.json').write_text(json.dumps({'files':after,'immutableSha256':immutable}))
report={'allFilesChecked':len(after),'allOldSourceAndBuildArtifactsUnchanged':True,'comparison':'relative regular-file set,size,mtime_ns,SHA256; symlinks separately inventoried below','oldImmutableSha256':immutable,'newRuntime':str(r/'node-gc-shrink-v5'),'newRuntimeSha256':hashlib.sha256((r/'node-gc-shrink-v5').read_bytes()).hexdigest(),'candidateRecorderSha256':hashlib.sha256((r/'recorder-v5.inc').read_bytes()).hexdigest(),'newSourceRecorderSha256':hashlib.sha256((r/'node-v24.21.0/deps/v8/src/heap/raveldex-gc-trace.inc').read_bytes()).hexdigest(),'oldSymlinks':[[str(p.relative_to(old)),os.readlink(p)] for p in old.rglob('*') if p.is_symlink()],'environment':{cmd:subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).stdout for cmd,args in [('uname',['uname','-a']),('macos',['sw_vers']),('clang',['clang++','--version'])]}}
(r/'source-isolation-and-runtime-identity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['oldSymlinks','environment']}))
