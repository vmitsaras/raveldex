// RX-4002 task-owned instrumentation. Intentionally not upstream/product code.
// Requires single-threaded, nonincremental, non-folding allocation mode.
// Stream is lossless variable-length unsigned integers, NOT a growing tape.
// Native map nodes, FILE buffering, census/sweeping and IO perturb execution.
namespace {
using RDXExtents = std::map<Address, Address>;
class RaveldexManagedAllocationTrace final : public HeapObjectAllocationTracker {
 public:
  RaveldexManagedAllocationTrace(Heap* heap, FILE* file, uint32_t cap, uint64_t byte_cap)
      : heap_(heap), file_(file), cap_(cap), byte_cap_(byte_cap) {}
  void Error(const char* why) { if (errors_++ == 0) first_error_ = why; }
  bool End(Address a, uint64_t n, Address* e) {
    if (!a || !n || n > UINTPTR_MAX-a) { Error("invalid_extent"); return false; }
    *e=a+n; return true;
  }
  bool PrepareBuffer() { return std::setvbuf(file_,file_buffer_,_IOFBF,sizeof(file_buffer_))==0; }
  void NoteHeaderBytes(uint64_t n) {stream_bytes_=n;}
  void Start() { gc_start_=heap_->gc_count(); heap_->AddHeapObjectAllocationTracker(this); }
  // A node cap applies separately to each of the five maps. Failed additions
  // invalidate the whole window; never report a plausible prefix measurement.
  bool Insert(RDXExtents& m, Address a, Address b) {
    if (a>=b) { Error("invalid_insert"); return false; }
    auto i=m.lower_bound(a);
    if ((i!=m.end() && i->first<b) || (i!=m.begin() && std::prev(i)->second>a)) {
      Error("extent_overlap"); return false;
    }
    if (m.size()>=cap_) { Error("active_extent_cap"); return false; }
    m.emplace(a,b); max_nodes_=std::max(max_nodes_,m.size()); return true;
  }
  template <typename F> void Intersections(const RDXExtents& m, Address a, Address b, F f) {
    auto i=m.upper_bound(a); if(i!=m.begin()) --i;
    for(;i!=m.end() && i->first<b;++i) if(i->second>a) f(std::max(a,i->first),std::min(b,i->second));
  }
  uint64_t Bytes(const RDXExtents& m) {
    uint64_t n=0; for(auto p:m) { if(p.second-p.first>UINT64_MAX-n) {Error("byte_overflow"); return 0;} n+=p.second-p.first; } return n;
  }
  // Remove overlaps, splitting one coallocated block where necessary.
  uint64_t Remove(RDXExtents& m, Address a, Address b) {
    uint64_t removed=0; auto i=m.upper_bound(a); if(i!=m.begin()) --i;
    while(i!=m.end() && i->first<b) {
      if(i->second<=a) {++i;continue;}
      auto p=*i; i=m.erase(i); removed+=std::min(b,p.second)-std::max(a,p.first);
      if(p.first<a) Insert(m,p.first,a);
      if(b<p.second) {Insert(m,b,p.second);break;}
    } return removed;
  }
  void Frontier() { peak_=std::max(peak_,current_); }
  void AllocationEvent(Address a,int n) final {
    Emit(1,a,0,n,0,0); if(errors_) return;
    if(in_gc_) {Error("allocation_during_gc_unsupported");return;}
    Address e; if(!End(a,n,&e)) return;
    if(uint64_t(n)>UINT64_MAX-gross_ || uint64_t(n)>UINT64_MAX-current_) {Error("byte_overflow");return;}
    if(Insert(extents_,a,e)) {gross_+=n; current_+=n; Frontier();}
  }
  void MoveEvent(Address a,Address b,int n) final {
    Emit(2,a,b,n,0,0); if(errors_) return; Address e,t; if(!End(a,n,&e)||!End(b,n,&t))return;
    if(!in_gc_) {
      if(b<=a || b>a+uint64_t(INT_MAX)-uint64_t(n)) {Error("unsupported_non_gc_move");return;}
      Address old_end; if(!End(a,uint64_t(n)+(b-a),&old_end))return;
      uint64_t coverage=0; Intersections(extents_,a,old_end,[&](Address x,Address y){coverage+=y-x;});
      if(coverage && coverage!=old_end-a) {Error("partial_left_trim");return;}
      if(coverage) {auto d=Remove(extents_,a,b);current_-=d;trimmed_+=d;} else ++unmonitored_;
      return;
    }
    // All copy sources resolve against the frozen PRE-GC address map. Targets
    // may overwrite another old address; never resolve them as new identities.
    if(!Insert(sources_,a,e) || !Insert(destinations_,b,t))return;
    Intersections(extents_,a,e,[&](Address x,Address y){Insert(moved_,b+(x-a),b+(y-a));});
    ++moves_;
  }
  void SizeChangeEvent(Address a,int old_n,int n) final {
    Emit(3,a,0,n,old_n,0); if(errors_)return;
    if(in_gc_) {
      // GC may compact a preexisting WeakArrayList. Ignore only a genuinely
      // disjoint extent; a tracked or partially tracked GC layout change has
      // not been calibrated and still invalidates the complete window.
      Address e; if(!End(a,old_n,&e)||n<=0||n>old_n){Error("invalid_gc_size_change");return;}
      bool tracked=false;
      Intersections(extents_,a,e,[&](Address,Address){tracked=true;});
      Intersections(moved_,a,e,[&](Address,Address){tracked=true;});
      if(tracked) Error("tracked_size_change_during_gc_unsupported");
      else ++unmonitored_;
      return;
    }
    Address e; if(!End(a,old_n,&e)||n<=0||n>old_n) {Error("invalid_size_change");return;}
    uint64_t coverage=0;Intersections(extents_,a,e,[&](Address x,Address y){coverage+=y-x;});
    if(coverage && coverage!=uint64_t(old_n)) {Error("partial_size_change");return;}
    if(coverage) {auto d=Remove(extents_,a+n,e);current_-=d;trimmed_+=d;} else ++unmonitored_;
  }
  void UpdateObjectSizeEvent(Address a,int n) final {Emit(4,a,0,n,0,0);}
  void Mark(uint32_t n) {Emit(5,0,0,current_,peak_,n);}
  void Inspect(v8::Local<v8::Value> value,uint32_t marker) {
    DisallowGarbageCollection no_gc; Tagged<Object> o=*Utils::OpenDirectHandle(*value);
    if(!IsHeapObject(o)) {Emit(6,0,0,0,0,marker);return;}
    auto h=Cast<HeapObject>(o); Emit(6,h.address(),0,h->Size(),0,marker);
    if(IsJSArray(h)) {auto e=Cast<JSArray>(h)->elements();Emit(7,e.address(),0,e->Size(),0,marker);}
  }
  void GCBegin(GarbageCollector collector) {
    Emit(8,0,0,current_,0,static_cast<uint32_t>(collector));
    if(in_gc_) {Error("nested_internal_gc");return;}
    in_gc_=true; ++gcs_;
    if(collector!=GarbageCollector::SCAVENGER && collector!=GarbageCollector::MARK_COMPACTOR) Error("unsupported_collector");
    sources_.clear();destinations_.clear();moved_.clear();
  }
  void GCEnd(GarbageCollector collector) {
    if(!in_gc_) Error("unpaired_internal_gc");
    uint64_t before=current_;
    if(!errors_) {
      // Invalidate stale pre-GC source and every overwritten destination,
      // including moves of PREEXISTING objects into a formerly new address.
      for(auto p:sources_) Remove(extents_,p.first,p.second);
      for(auto p:destinations_) Remove(extents_,p.first,p.second);
      for(auto p:moved_) Insert(extents_,p.first,p.second);
      // MakeHeapIterable completes sweeping, obtains a safepoint and may retire
      // LABs. kNoFiltering measures occupied objects; no root liveness walk.
      // Full census rows let a separate implementation reconstruct intersection.
      RDXExtents survivors;
      HeapObjectIterator it(heap_,HeapObjectIterator::kNoFiltering);
      for(Tagged<HeapObject> o=it.Next();!o.is_null();o=it.Next()) {
        if(IsFreeSpaceOrFiller(o))continue;
        Address a=o.address(),b; if(!End(a,o->Size(),&b))break;
        Emit(10,a,0,b-a,0,0); ++census_objects_;
        Intersections(extents_,a,b,[&](Address x,Address y){Insert(survivors,x,y);});
        if(errors_)break;
      }
      extents_.swap(survivors);current_=Bytes(extents_);
      if(current_>before) Error("gc_occupied_bytes_increased"); else collected_+=before-current_;
    }
    sources_.clear();destinations_.clear();moved_.clear();in_gc_=false;
    Emit(9,0,0,current_,before,static_cast<uint32_t>(collector)); Frontier();
  }
  int Stop(bool aborted) {
    heap_->RemoveHeapObjectAllocationTracker(this);
    if(in_gc_)Error("unfinished_gc");
    if(heap_->gc_count()-gc_start_!=static_cast<int>(gcs_))Error("gc_counter_mismatch");
    if(aborted)Error("aborted");
    if(std::fflush(file_)!=0){io_error_=true;Error("stream_flush_error");}
    bool valid=errors_==0;
    // Terminal frame: kind 0 then unsigned JSON byte length then UTF-8 JSON.
    // We reserve 4112 bytes below the stream cap for this final invalid record.
    char summary[4096];
    int n=std::snprintf(summary,sizeof(summary),
      "{\"record\":\"summary\",\"valid\":%s,\"errors\":%" PRIu64 ",\"first_error\":\"%s\",\"aborted\":%s,\"events\":%" PRIu64 ",\"attempted_events\":%" PRIu64 ",\"dropped_events\":%" PRIu64 ",\"stream_bytes_before_summary\":%" PRIu64 ",\"gc_cycles\":%" PRIu64 ",\"heap_gc_count_start\":%d,\"heap_gc_count_stop\":%d,\"gc_moves\":%" PRIu64 ",\"census_objects\":%" PRIu64 ",\"max_nodes_per_map\":%zu,\"active_extents\":%zu,\"preexisting_or_unmonitored_changes\":%" PRIu64 ",\"gross_birth_bytes\":%s,\"mutator_occupied_high_water_bytes\":%s,\"occupied_at_stop_bytes\":%s,\"trimmed_bytes\":%s,\"gc_removed_bytes\":%s,\"coverage_calibrated_by_runtime\":false}",
      valid?"true":"false",errors_,first_error_,aborted?"true":"false",events_,attempts_,attempts_-events_,stream_bytes_,gcs_,gc_start_,heap_->gc_count(),moves_,census_objects_,max_nodes_,extents_.size(),unmonitored_,
      Number(valid,gross_,0),Number(valid,peak_,1),Number(valid,current_,2),Number(valid,trimmed_,3),Number(valid,collected_,4));
    if(n<=0 || n>=static_cast<int>(sizeof(summary)))return -EOVERFLOW;
    unsigned char terminal[16];size_t k=0;terminal[k++]=0; Put(terminal,&k,n);
    if(std::fwrite(terminal,1,k,file_)!=k || std::fwrite(summary,1,n,file_)!=size_t(n))io_error_=true;
    if(std::fclose(file_)!=0)io_error_=true;file_=nullptr;
    return io_error_ ? -EIO : valid ? 0 : 1;
  }
 private:
  const char* Number(bool valid,uint64_t n,int slot) {if(!valid)return "null";std::snprintf(numbers_[slot],32,"%" PRIu64,n);return numbers_[slot];}
  static void Put(unsigned char* b,size_t* p,uint64_t n) {while(n>=128){b[(*p)++]=(n&127)|128;n>>=7;}b[(*p)++]=n;}
  void Emit(uint64_t kind,Address a,Address b,uint64_t n,uint64_t old,uint32_t marker) {
    ++attempts_;
    if(stream_full_||io_error_)return;
    unsigned char row[64];size_t k=0;Put(row,&k,kind);Put(row,&k,a);Put(row,&k,b);Put(row,&k,n);Put(row,&k,old);Put(row,&k,marker);
    if(k>byte_cap_-4112-stream_bytes_){stream_full_=true;Error("stream_byte_cap");return;}
    if(std::fwrite(row,1,k,file_)!=k){io_error_=true;Error("stream_io_error");return;}
    stream_bytes_+=k;++events_;
  }
  Heap* heap_;FILE* file_;uint32_t cap_;uint64_t byte_cap_;
  RDXExtents extents_,sources_,destinations_,moved_;
  uint64_t gross_=0,current_=0,peak_=0,trimmed_=0,collected_=0,errors_=0;
  uint64_t attempts_=0,events_=0,stream_bytes_=0,gcs_=0,moves_=0,census_objects_=0,unmonitored_=0;
  size_t max_nodes_=0;int gc_start_=0;bool in_gc_=false,stream_full_=false,io_error_=false;
  const char* first_error_="none";char numbers_[5][32];char file_buffer_[65536];
};
base::LazyMutex raveldex_trace_registry_mutex=LAZY_MUTEX_INITIALIZER;
using RaveldexTraceRegistry=std::unordered_map<Isolate*,std::unique_ptr<RaveldexManagedAllocationTrace>>;
RaveldexTraceRegistry& GetRaveldexTraceRegistry(){static base::LeakyObject<RaveldexTraceRegistry> r;return *r.get();}
void RaveldexManagedGCBegin(Heap* heap,GarbageCollector collector){
  base::MutexGuard lock(raveldex_trace_registry_mutex.Pointer());auto i=GetRaveldexTraceRegistry().find(heap->isolate());if(i!=GetRaveldexTraceRegistry().end())i->second->GCBegin(collector);
}
void RaveldexManagedGCEnd(Heap* heap,GarbageCollector collector){
  base::MutexGuard lock(raveldex_trace_registry_mutex.Pointer());auto i=GetRaveldexTraceRegistry().find(heap->isolate());if(i!=GetRaveldexTraceRegistry().end())i->second->GCEnd(collector);
}
} // namespace
extern "C" int RaveldexManagedTraceStart(void* public_isolate,const char* path,uint32_t capacity,uint32_t stream_mib){
  auto* isolate=reinterpret_cast<Isolate*>(public_isolate);
  if(!path||path[0]!='/'||!capacity||capacity>1000000||stream_mib<1||stream_mib>16384||v8_flags.inline_new||v8_flags.turbo_allocation_folding||!v8_flags.single_threaded||v8_flags.incremental_marking||v8_flags.concurrent_marking||v8_flags.concurrent_sweeping||v8_flags.parallel_scavenge||v8_flags.parallel_compaction||v8_flags.minor_ms||v8_flags.sticky_mark_bits||isolate->has_shared_space())return -EINVAL;
  base::MutexGuard lock(raveldex_trace_registry_mutex.Pointer());if(GetRaveldexTraceRegistry().count(isolate))return -EBUSY;
  int fd=::open(path,O_WRONLY|O_CREAT|O_EXCL|O_CLOEXEC,0600);if(fd<0)return -errno;
  FILE* f=::fdopen(fd,"wb");if(!f){int e=errno;::close(fd);return -e;}
  uint64_t limit=uint64_t(stream_mib)*1048576;
  auto trace=std::make_unique<RaveldexManagedAllocationTrace>(isolate->heap(),f,capacity,limit);
  if(!trace->PrepareBuffer()){std::fclose(f);return -EIO;}
  int header_bytes=std::fprintf(f,"{\"record\":\"header\",\"schema\":\"raveldex-gc-extents-varint-v1\",\"fields\":[\"kind\",\"address\",\"to\",\"bytes\",\"old_bytes\",\"marker\"],\"active_extent_cap_per_map\":%u,\"map_count_max\":5,\"stream_byte_cap\":%" PRIu64 ",\"stdio_buffer_bytes\":65536,\"single_threaded\":true,\"incremental_marking\":false,\"inline_new\":false,\"turbo_allocation_folding\":false,\"collector_overlap_measured\":false,\"physical_memory_measured\":false,\"includes_preexisting_objects\":false}\n",capacity,limit);
  if(header_bytes<0 || std::fflush(f)){std::fclose(f);return -EIO;}
  trace->NoteHeaderBytes(header_bytes);
  auto* raw=trace.get();GetRaveldexTraceRegistry().emplace(isolate,std::move(trace));raw->Start();return 0;
}
extern "C" int RaveldexManagedTraceMark(void* p,uint32_t marker){auto* i=reinterpret_cast<Isolate*>(p);base::MutexGuard lock(raveldex_trace_registry_mutex.Pointer());auto f=GetRaveldexTraceRegistry().find(i);if(f==GetRaveldexTraceRegistry().end())return -ENOENT;f->second->Mark(marker);return 0;}
extern "C" int RaveldexManagedTraceInspect(void* p,v8::Local<v8::Value> value,uint32_t marker){auto* i=reinterpret_cast<Isolate*>(p);base::MutexGuard lock(raveldex_trace_registry_mutex.Pointer());auto f=GetRaveldexTraceRegistry().find(i);if(f==GetRaveldexTraceRegistry().end())return -ENOENT;f->second->Inspect(value,marker);return 0;}
extern "C" int RaveldexManagedTraceStop(void* p,int aborted){auto* i=reinterpret_cast<Isolate*>(p);std::unique_ptr<RaveldexManagedAllocationTrace> trace;{base::MutexGuard lock(raveldex_trace_registry_mutex.Pointer());auto f=GetRaveldexTraceRegistry().find(i);if(f==GetRaveldexTraceRegistry().end())return -ENOENT;trace=std::move(f->second);GetRaveldexTraceRegistry().erase(f);}return trace->Stop(aborted!=0);}
