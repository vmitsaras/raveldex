from pathlib import Path
import difflib
r=Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime');p=r/'node-v24.21.0/deps/v8/src/heap/raveldex-gc-trace.inc';t=p.read_text()
t=t.replace('      uint64_t coverage=0;\n      Intersections(extents_,a,e,','      if(gc_layout_locked_) {Error("gc_size_change_after_move_or_census");return;}\n      uint64_t coverage=0;\n      Intersections(extents_,a,e,',1)
t=t.replace('        if(gc_layout_locked_) {Error("tracked_gc_size_change_after_move_or_census");return;}\n','')
t=t.replace('        current_-=d;trimmed_+=d;++gc_shrinks_;','        current_-=d;trimmed_+=d;++gc_shrinks_;\n        gc_shrink_pending_=true;gc_shrink_address_=a;gc_shrink_size_=n;')
t=t.replace('  void UpdateObjectSizeEvent(Address a,int n) final {Emit(4,a,0,n,0,0);}', '''  void UpdateObjectSizeEvent(Address a,int n) final {
    bool paired=gc_shrink_pending_ && a==gc_shrink_address_ && n==gc_shrink_size_;
    Emit(4,a,0,n,0,0);if(errors_)return;
    if(in_gc_ && !paired) {
      Address e;if(!End(a,n,&e))return;bool tracked=false;
      Intersections(extents_,a,e,[&](Address,Address){tracked=true;});
      Intersections(moved_,a,e,[&](Address,Address){tracked=true;});
      if(tracked)Error("unpaired_tracked_gc_size_update");
    }
  }''')
t=t.replace('    uint64_t before=current_;','    if(gc_shrink_pending_)Error("dangling_gc_shrink_size_update");\n    uint64_t before=current_;')
t=t.replace('    ++attempts_;','''    if(gc_shrink_pending_) {
      if(kind==4 && a==gc_shrink_address_ && n==uint64_t(gc_shrink_size_)) gc_shrink_pending_=false;
      else Error("gc_shrink_size_update_pair_mismatch");
    }
    ++attempts_;''')
t=t.replace('bool in_gc_=false,gc_layout_locked_=false,stream_full_', 'Address gc_shrink_address_=0;int gc_shrink_size_=0;bool gc_shrink_pending_=false;\n  bool in_gc_=false,gc_layout_locked_=false,stream_full_')
p.write_text(t);(r/'recorder-v4.inc').write_text(t)
b=(r/'recorder-v3.inc').read_text();(r/'shrink-v4.patch').write_text(''.join(difflib.unified_diff(b.splitlines(True),t.splitlines(True),fromfile='a/deps/v8/src/heap/raveldex-gc-trace.inc',tofile='b/deps/v8/src/heap/raveldex-gc-trace.inc')))
old=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc/run-build-attempt3.py').read_text();old=old.replace("Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc')", "Path('/tmp/raveldex-ac03-shrink-20261028.F26U9H/runtime')").replace("phase = 'gc-extension-attempt3'", "phase = 'gc-shrink-v4'")
(r/'run-build.py').write_text(old)
