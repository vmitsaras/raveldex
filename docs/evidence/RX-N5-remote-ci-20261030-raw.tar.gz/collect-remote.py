import hashlib,json,stat,subprocess,sys,zipfile
from pathlib import Path,PurePosixPath
stage=Path(__file__).parent
run=int(sys.argv[1]);prefix=sys.argv[2]
def api(endpoint,destination,binary=False):
 args=['gh','api','repos/vmitsaras/raveldex/'+endpoint]
 if binary: args+=['--allow-escape-sequences']
 with destination.open('wb') as f: subprocess.run(args,stdout=f,check=True)
 return None if binary else json.loads(destination.read_text())
r=api(f'actions/runs/{run}',stage/f'{prefix}-run.json')
assert r['status']=='completed',r['status']
j=api(f'actions/runs/{run}/jobs',stage/f'{prefix}-jobs.json')
a=api(f'actions/runs/{run}/artifacts',stage/f'{prefix}-artifacts.json')
for job in j['jobs']:
 node='22' if job['name'].endswith('22)') else '24'
 assert job['name']==f'Candidate verification (Node {node})'
 api(f'actions/jobs/{job["id"]}/logs',stage/f'{prefix}-node{node}-job.log',True)
for item in a['artifacts']:
 node=item['name'].rsplit('-',1)[-1];assert node in ('22','24')
 archive=stage/f'{prefix}-node{node}.zip'
 if not archive.exists(): api(f'actions/artifacts/{item["id"]}/zip',archive,True)
 assert 'sha256:'+hashlib.sha256(archive.read_bytes()).hexdigest()==item['digest']
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  names=z.namelist();assert len(names)==len(set(names))
  assert sum(x.file_size for x in z.infolist())<64*1024*1024
  for x in z.infolist():
   p=PurePosixPath(x.filename)
   assert not p.is_absolute() and '..' not in p.parts and '\\' not in x.filename
   assert stat.S_IFMT(x.external_attr>>16)!=stat.S_IFLNK
  target=stage/f'{prefix}-node{node}'
  if target.exists():
   assert set(str(x.relative_to(target)) for x in target.rglob('*') if x.is_file())==set(names)
   for x in z.infolist():assert (target/x.filename).read_bytes()==z.read(x.filename)
  else:z.extractall(target)
print(json.dumps({'run':run,'sha':r['head_sha'],'conclusion':r['conclusion'],'artifacts':[{'id':x['id'],'name':x['name'],'digest':x['digest']} for x in a['artifacts']]},indent=2))
