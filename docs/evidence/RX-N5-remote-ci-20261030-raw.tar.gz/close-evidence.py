from pathlib import Path
import datetime,gzip,hashlib,io,json,shutil,tarfile
stage=Path(__file__).parent
repo=Path('/Users/vasilis/Documents/GitHub/raveldex');dest=repo/'docs/evidence'
stem='RX-N5-remote-ci-20261030'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p):return json.loads(p.read_text())
def exclusive(path,data):
 with path.open('xb') as f:f.write(data)
review=js(stage/'artifact-review.json');assert review['status']=='Ready' and review['mandatoryFindings']==[] and review['pending']==[]
for source,target in [('second-node22.zip',stem+'-node22.zip'),('second-node24.zip',stem+'-node24.zip'),('first-node22.zip',stem+'-failed-node22.zip'),('first-node24.zip',stem+'-failed-node24.zip'),('artifact-review.json',stem+'-review.json')]:exclusive(dest/target,(stage/source).read_bytes())
exclusive(repo/'test/reviews/rx-n5-remote-ci.py',(stage/'audit-remote.py').read_bytes())
files=[p for p in stage.iterdir() if p.is_file() and p.suffix in ['.json','.log','.txt','.patch','.py','.zip']]
for sub in ['first-node22','first-node24','second-node22','second-node24']:
 files.extend(p for p in (stage/sub).rglob('*') if p.is_file())
for pattern in ['*.json','*.log','*.tgz']:files.extend((stage/'local-english').glob(pattern))
files=sorted(set(files));rows=[]
for path in files:
 b=path.read_bytes();rows.append({'path':str(path.relative_to(stage)),'bytes':len(b),'sha256':sha(b)})
manifest=json.dumps({'kind':'raveldex-n5-ci-raw-members-v1','members':rows},indent=2).encode()+b'\n'
archive=dest/(stem+'-raw.tar.gz')
with archive.open('xb') as output:
 with gzip.GzipFile(fileobj=output,filename='',mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,b in [('raw-manifest.json',manifest)]+[(row['path'],(stage/row['path']).read_bytes()) for row in rows]:
    info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
nodes=[];metadata=js(stage/'second-artifacts.json')['artifacts']
for item in review['nodes']:
 major=item['nodeMajor'];zipname=f'{stem}-node{major}.zip';provider=next(a for a in metadata if a['name'].endswith(f'node-{major}'))
 nodes.append({'nodeMajor':major,'environment':item['environment'],'job':item['job'],'testCounts':item['testCounts'],'totalTests':item['totalTests'],'artifact':{'path':'docs/evidence/'+zipname,'id':provider['id'],'bytes':(dest/zipname).stat().st_size,'sha256':sha((dest/zipname).read_bytes()),'providerDigest':provider['digest'],'expiresAt':provider['expires_at']},'packages':item['packages'],'astro':item['astro']})
summary={'kind':'raveldex-n5-remote-ci-v1','date':'2026-10-30','status':'Pass','originalCompletedN5Source':review['baseImplementation'],'testedSource':review['testedSource'],'run':review['run'],'nodes':nodes,'scope':{'completedN5Tasks':[f'RX-A{i:03}' for i in range(10,101,10)],'productionSourceChanged':False,'packageMetadataChanged':False,'lockfileChanged':False,'rootProductionMembersUnchanged':280,'separateAstroMembersUnchanged':15,'separateEnglishMembersUnchanged':5,'all31TasksRemainDone':True},'fixes':[{'class':'CI harness','description':'Astro honors validated RAVELDEX_CANDIDATE_BROWSER with Chrome local default; report records actual channel.'},{'class':'Workflow configuration','description':'runner.temp moved from invalid job env to verification-step env; original HTTP422 and zero-job push validation are retained.'},{'class':'Test fixture startup allowance','description':'Watchdog test permits2000ms startup and asserts ready plus SIGKILL/killAttempted with5000ms outer observation bound; actual benchmark watchdog and engine bounds unchanged.'},{'class':'Measurement comparison','description':'Hash-bound accepted RX-A090 tar installed offline; historical raw bundle identity retained and gzip compared on same runtime; historical measurements unchanged.'}],'firstAttempt':review['retainedFirstAttempt'],'initialWorkflowValidation':{'runId':41005925739,'source':'441e0aef3abf93fc57c4578e4c66e5cb91b3ba86','status':'Fail','jobs':0,'dispatch':'HTTP422 refused invalid runner context; not a test run'},'focusedVerification':{'watchdog':{'pass':7,'log':'watchdog-fixed.log'},'astroChromium':{'pass':3,'log':'local-astro-fixed.log'},'startupCalibration':'watchdog-startup-probe.json'},'independentReview':{'status':'Ready','mandatoryFindings':[],'path':'docs/evidence/'+stem+'-review.json','sha256':sha((dest/(stem+'-review.json')).read_bytes()),'reproducer':'test/reviews/rx-n5-remote-ci.py','reproducerSha256':sha((repo/'test/reviews/rx-n5-remote-ci.py').read_bytes())},'rawArchive':{'path':'docs/evidence/'+archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'dataMembers':len(rows),'manifestMember':'raw-manifest.json'},'testedSourceBindings':js(stage/'final-tested-source-bindings.json'),'remoteBoundary':review['recordedRemoteBoundary'],'limitations':['Exact Node22.23.4/24.22.1 Ubuntu26.04 x64 and Playwright Chromium149.0.7827.55 automation; no fresh Safari/Firefox or physical AT/input qualification.','Source default and exact-current-Node native qualification remain distinct; no browser/cross-host native portability claim.','Named core gzip20351B on both Linux runtimes equals reconstructed baseline but exceeds unchanged15360B target; historical Darwin20304B retained.','Existing relevance/resource/AT limitations remain; no allocation/heap/transport-copy/paint/latency claim added.','Sparse checkout still excludes only unchanged archival RX-4002 raw GC streams; those measurements were not replayed.','Remote CI tests the exact source revision, separate from later evidence/documentation/auditor-only commit.','No merge/main update, tracking sync, publication, tag, release, visibility or paid-service change.']}
exclusive(dest/(stem+'.json'),json.dumps(summary,indent=2).encode()+b'\n')
print(json.dumps({'summary':stem+'.json','archiveBytes':archive.stat().st_size,'rawMembers':len(rows),'review':'Ready','nodes':[(x['nodeMajor'],x['totalTests']) for x in nodes]}))
