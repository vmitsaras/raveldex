import assert from 'node:assert/strict';
import { readFile, writeFile, access, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import { join } from 'node:path';

const repo='/Users/vasilis/Documents/GitHub/raveldex';
const producer='/tmp/raveldex-remote-ci-20261028-ohw0g124';
const owned='/tmp/raveldex-rx4003-remote-review-20261028';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const json=async path=>JSON.parse(await readFile(path,'utf8'));
const bind=async path=>{const bytes=await readFile(path);return {path,bytes:bytes.length,sha256:sha(bytes)};};
const git=args=>execFileSync('git',['--no-optional-locks',...args],{cwd:repo,encoding:'utf8'}).trim();
const state=await json(join(producer,'transfer-state.json'));
const desired='9f22e37bacab96bd0c1b9b260b6639b3e16292ba';
const original='81c7528678a031dd097d43bce6021025e14ed49e';
assert.equal(state.status,'Pass');assert.equal(state.desired,desired);
assert.equal(state.actualRef,'refs/heads/codex/rx-4002-qualification');
assert.equal(state.batches.length,8);assert.equal(state.completedBatches.length,8);
assert.equal(state.receipts.length,11);
const reachable=new Set(git(['rev-list','--objects',desired]).split('\n').map(line=>line.split(' ')[0]));
const staged=state.batches.flat();assert.equal(new Set(staged.map(item=>item.oid)).size,staged.length);
const metadata=git(['cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)']);
// Query only object headers/sizes, never replay compressed raw archive payloads.
const queried=execFileSync('git',['cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],{cwd:repo,input:staged.map(item=>item.oid).join('\n')+'\n',encoding:'utf8'}).trim().split('\n');
for(const [i,line]of queried.entries()){const[oid,type,bytes]=line.split(' ');assert.equal(type,'blob');assert.equal(oid,staged[i].oid);assert.equal(Number(bytes),staged[i].bytes);assert.ok(reachable.has(oid));}
let parent=state.base;const batchSummary=[];
for(const [index,batch]of state.batches.entries()) {
  const completed=state.completedBatches[index],bytes=batch.reduce((sum,item)=>sum+item.bytes,0);
  assert.equal(completed.number,index+1);assert.equal(completed.bytes,bytes);assert.equal(completed.blobs,batch.length);
  assert.ok(bytes<=state.batchLimitBytes);assert.equal(completed.parent,parent);
  assert.equal(git(['show','-s','--format=%P',completed.commit]),parent);
  assert.equal(git(['rev-parse',completed.commit+'^{tree}']),completed.tree);
  assert.ok(!reachable.has(completed.commit),'artificial stage not part of actual original history');
  parent=completed.commit;batchSummary.push({number:index+1,blobBytes:bytes,blobs:batch.length,commit:completed.commit});
}
assert.equal(parent,state.lastStageTip);
assert.equal(git(['show','-s','--format=%P',state.advance]),state.lastStageTip);
assert.equal(git(['rev-parse',state.advance+'^{tree}']),git(['rev-parse',state.lastStageTip+'^{tree}']));
assert.ok(!reachable.has(state.advance));
const total=staged.reduce((sum,item)=>sum+item.bytes,0);assert.equal(total,6755298304);
const receipts=[];
for(const receipt of state.receipts){assert.equal(receipt.exitCode,0);const bytes=await readFile(receipt.log);assert.equal(sha(bytes),receipt.logSha256);receipts.push({...receipt,bytes:bytes.length});}
const expected=await readFile(join(producer,'final-expected.pack'));
assert.equal(expected.length,state.expectedFinalPack.bytes);assert.equal(sha(expected),state.expectedFinalPack.sha256);assert.equal(expected.subarray(0,4).toString(),'PACK');
assert.equal(expected.readUInt32BE(8),108);
assert.equal(git(['show','-s','--format=%P',desired]),original);
assert.equal(git(['rev-list',original+'..'+desired]),desired);
const changed=git(['diff','--name-only',original,desired]).split('\n');
assert.deepEqual(changed.sort(),['.github/workflows/candidate.yml','.github/workflows/ci.yml','.github/workflows/sync-roadmap.yml','test/ui/announcements-browser.test.mjs','test/ui/focus-browser.test.mjs','test/ui/input-browser.test.mjs'].sort());
const uiAfter=await json(join(owned,'ui-harness-after.json'));
for(const item of uiAfter.files){const bytes=await readFile(join(repo,item.path));assert.equal(sha(bytes),item.sha256);}
const focused=await readFile(join(producer,'chromium-focused.log'),'utf8');
for(const [label,count]of [['tests',15],['pass',15],['fail',0],['cancelled',0],['skipped',0]])assert.match(focused,new RegExp('^ℹ '+label+' '+count+'$','m'));
assert.match(focused,/149\.0\.7827\.55/);assert.match(focused,/c6720f44c5158dff8d4f9d0530f91f6d94942a1c2c3ea9cb3ed49f6b9d7e0d73/);
const sparse=await json(join(producer,'sparse-control.json'));
assert.equal(sparse.sourceCommit,desired);assert.equal(sparse.status,'Pass');
const sparseRoot=join(producer,'sparse-checkout-control');
assert.equal(git(['-C',sparseRoot,'rev-parse','HEAD']),desired);
const paths=git(['ls-tree','-r','--name-only',desired]).split('\n'),omitted=[];
for(const path of paths){let exists=true;try{await access(join(sparseRoot,path));}catch{exists=false;}if(!exists)omitted.push(path);}
assert.equal(omitted.length,127);assert.deepEqual(omitted.sort(),[...sparse.omittedArchiveFiles].sort());
assert.ok(omitted.every(path=>/^docs\/evidence\/RX-4002-gc-shrink-raw-\d+-20261028\.tar\.xz$/.test(path)));
const manifest=await json(join(repo,'docs/planning/roadmap.json'));
assert.equal(manifest.tasks.flatMap(task=>task.evidence??[]).filter(path=>omitted.includes(path)).length,0);
const sparseLog=await json(join(producer,'sparse-control-log.json'));assert.ok(sparseLog.every(item=>item.code===0));
const live=await json(join(owned,'live-provenance-snapshot.json'));
assert.equal(live.run.headSha,desired);assert.equal(live.run.event,'workflow_dispatch');
assert.equal(live.remoteRefs.find(item=>item.ref===state.actualRef).oid,desired);
assert.equal(live.remoteRefs.filter(item=>item.ref===state.temporaryRef).length,0);
assert.ok(live.run.jobs.every(job=>['Candidate verification (Node 22)','Candidate verification (Node 24)'].includes(job.name)));
const sources=[];for(const path of changed)sources.push(await bind(join(repo,path)));
const report={schema:'raveldex-remote-transfer-provenance-independent-review-v1',reviewer:'/root/rx4003_review',reviewedUtc:new Date().toISOString(),status:'Pass for actual transfer, provenance and permission scope; remote candidate verification still in progress at this snapshot',mandatoryFindings:[],
  actualTransfer:{state:await bind(join(producer,'transfer-state.json')),desired,originalCandidateCommit:original,actualRef:state.actualRef,initialRemoteHead:state.initialRemoteHead,intermediateOriginalBase:state.base,originalHistoryPreserved:true,artificialStageCommitsAbsentFromActualHistory:true,stagedBlobBytes:total,stagedBlobs:staged.length,batchLimitBytes:state.batchLimitBytes,batches:batchSummary,closedPushReceipts:receipts,finalExpectedPack:{...state.expectedFinalPack,objects:108},atomicOriginalAndBoundaryPush:'Pass; actual closed log writes 108 objects / rounded 2.62 MiB and updates only original feature branch and owned staging ref',cleanup:'Pass; exact-advance lease on the one created temporary ref, independently absent from live ls-remote',limits:'Staged blob byte sum, expected pack bytes, rounded progress and network timing are distinct quantities. Base-prefix transfer and final metadata transfer are separate from the eight staged batches.'},
  algorithmControls:{producerControl:await bind(join(producer,'transfer-control.json')),producerUnsupportedExplicitRefspec:await bind(join(producer,'transfer-control-explicit-refspec.json')),producerUnsupportedRepoint:await bind(join(producer,'transfer-control-leased-repoint.json')),independentTinyControl:await bind(join(owned,'local-staging-proof.json')),disposition:'Closed bounded local controls show why raw OID or up-to-date-ref transfer fails and why advancing the staging boundary in an atomic multi-ref update reuses objects. Actual GitHub success is separately observed in closed transfer receipts.'},
  sparseCheckout:{receipt:await bind(join(producer,'sparse-control.json')),log:await bind(join(producer,'sparse-control-log.json')),exactCommit:desired,omittedArchiveFiles:127,allOtherTrackedFilesPresent:true,canonicalEvidencePathsOmitted:0,planRenderAndLocalMarkdownChecks:'Pass in closed control log',scope:'Shared local object store control; CI job separately confirms its actual checkout step. Historical raw archives remain in original repository/history and are not numerically replayed by ordinary CI.'},
  sourceAndWorkflowScope:{changedFiles:sources,runtimePublicDocsNpmMetadataCompilerAndRequirementsChanged:false,uiPatch:'Three existing harnesses now honor selected Chromium; source assertions and observation payloads are unchanged. Parent independently reviewed this agent-authored patch.',focusedActualEvidence:{log:await bind(join(producer,'chromium-focused.log')),tests:15,pass:15,fail:0,cancelled:0,skipped:0,browser:'149.0.7827.55 headless Chromium',candidateSha256:'c6720f44c5158dff8d4f9d0530f91f6d94942a1c2c3ea9cb3ed49f6b9d7e0d73'},permissions:'CI and candidate workflows retain contents:read, pinned actions, persist-credentials:false, Node22/24 and explicit Chromium. Existing main-only issue sync remains separate. No npm publish, GitHub release/tag, visibility, paid-service or default-main mutation.'},
  liveCIProvenance:{snapshot:await bind(join(owned,'live-provenance-snapshot.json')),runId:40771652630,url:live.run.url,headSha:live.run.headSha,event:live.run.event,status:live.run.status,conclusion:live.run.conclusion,jobs:live.run.jobs.map(job=>({id:job.databaseId,name:job.name,status:job.status,currentStep:job.steps.find(step=>step.status==='in_progress')?.name})),claim:'Checkout, storage report, Node setup, npm install and Chromium install have succeeded in both jobs. Candidate preparation is still running; no final CI Pass, test count or artifact result is inferred.'},
  exclusions:'Reviewer ran only read-only Git/header/tree/receipt checks, one live gh run view and git ls-remote. No network writes, build, suite, browser run or raw archive replay. Writes confined to owned /tmp review directory in this turn.'};
await writeFile(join(owned,'actual-transfer-review.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:'Pass',output:join(owned,'actual-transfer-review.json'),stagedBlobBytes:total,batches:batchSummary.length,omittedArchiveFiles:omitted.length,liveCIStatus:live.run.status}));
