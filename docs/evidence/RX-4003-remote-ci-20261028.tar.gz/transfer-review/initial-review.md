# Private candidate remote CI: initial independent review

Reviewer: `/root/rx4003_review`. Date: 2026-10-28. Candidate baseline: `81c7528678a031dd097d43bce6021025e14ed49e`. Scope: remote CI preparation and transfer algorithm, with the three explicitly assigned UI test-harness edits. No product build, suite, browser or resource workload is run by this agent.

## Material findings and disposition

1. **Confirmed test portability defect, fixed.** `test/ui/announcements-browser.test.mjs`, `input-browser.test.mjs` and `focus-browser.test.mjs` hard-coded system Chrome despite CI installing and selecting Playwright Chromium. Each now follows the neighboring `RAVELDEX_UI_BROWSER ?? 'chrome'` policy, rejects unknown choices and supplies the Chrome channel only when requested. Launch timeout, assertions and observation payloads are unchanged. All three module syntax checks and focused whitespace review pass. Before/after hashes are in `ui-harness-before.json` and `ui-harness-after.json`. Actual Chromium behavior is parent-owned evidence, pending independent inspection of its closed log.

2. **Confirmed delivery algorithm hazard, bounded control available.** Simply uploading blob objects through temporary commits, retaining local refs, selecting `push.negotiate=true`, using an up-to-date staging refspec, or disabling sparse packing did not by itself prevent the final original commit push from retransmitting blob payloads in the tiny local fixture. The advertised staging ref alone is not sufficient. The closed successful control uses a cumulative staging tree and local staging ref, then creates one empty child of that staging tip and advances that ref in the same multi-ref push as the unchanged original branch commit, with per-command `pack.useSparse=false`. This works with differently named stage paths: the final transfer contains three objects (the original final commit/tree and empty staging child), reuses three 128 KiB blobs, preserves the original desired commit/tree exactly, and passes receiver connectivity checks after deleting the created temporary ref. `local-staging-proof.mjs`, `local-staging-proof.json` and its final packet trace preserve the final control. This is a tiny local file-protocol observation, not an executed GitHub 2 GiB-limit pass.

3. **Runner disk and duration are environment risks.** Missing Git-object metadata records 413 blobs totaling 7,120,078,684 uncompressed bytes; the largest is 77,138,888 bytes and none exceeds 100 MiB. Those are object metadata, not actual push-pack bytes. A full materialized archive checkout plus Git storage can stress the standard runner disk; actual free space and checkout duration need remote observation. Current CI's 20-minute timeout and explicit storage reporting are reasonable preparation. Do not relabel disk, checkout or browser installation failures as product defects.

4. **Potential fixture startup race to classify if observed.** `bench/memory/restore-common.test.mjs:42–44` assumes a spawned Node process installs its SIGTERM handler before a 100 ms watchdog, then expects SIGKILL. Under a loaded two-core runner the child may receive SIGTERM before installing that handler. This is an evidenced test assumption, not a demonstrated failure in this turn and not grounds for a speculative engine/deadline change.

## Current CI plan

Using the already registered `ci.yml` with a feature-branch ref avoids editing the default branch merely to register the new candidate workflow. Its current Node 22/24 matrix, explicit Chromium selectors, private candidate preparation, report/tarball upload, read-only contents permission and disabled checkout credential persistence are coherent. No publication, tag, release, visibility or paid-service action is introduced.

The sparse checkout exclusion targets only `docs/evidence/RX-4002-gc-shrink-raw-*-20261028.tar.xz`. It matches no canonical task evidence path, and source searches find no direct use of those archive names/index in the scripts, tests or memory-method test modules executed by `npm run check`. It preserves runtime/test/public-package sources and the original commit. Record that raw archive omission explicitly; a CI pass does not replay those archived qualification measurements. It is distinct from deleting committed evidence/history or projecting different product source.

Ordinary snapshot tests derive declarations from the actual runtime rather than a fixed macOS qualification. `sw_vers` calls in ordinary browser tests are guarded by the Darwin platform check. The inspected analyzer fixtures use established Unicode characters. No further concrete Linux/Node 22 product failure is established by source review.

Compare each actual job head SHA and all 228 unpacked package members against the original candidate inventory, including the 208 identical compiled files. Preserve each remote tarball's own digest: npm/tar/zlib envelope differences can produce a different tarball hash without different package member bytes. Remote job success does not broaden AT, physical, all-Unicode, memory or browser support.

## Transfer guardrails

- Keep new transfer packs comfortably below 2 GiB and measure actual bounded control behavior; raw object-size sums alone do not prove a push pack bound.
- Use only original objects reachable from the intended original candidate history; preserve that history unchanged.
- Maintain explicit before/after OIDs for every created staging ref and keep the staging population reachable until the actual feature branch is verified at the expected commit.
- The final actual branch update remains an ordinary fast-forward. Prefer atomic final multi-ref update when supported, so a branch rejection does not advance only the staging tip.
- Delete only refs created for this task, with their recorded current tip identities, after verifying actual branch reachability. No mirror push, main-branch mutation or force update of the real branch.

## Primary documentation checked

- [GitHub's 2 GiB push limit](https://docs.github.com/en/get-started/using-git/troubleshooting-the-2-gb-push-limit): confirms the transfer ceiling; its ordinary large-commit guidance does not document this staging workaround.
- [Manual workflow execution](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow): confirms default-branch registration and ref selection.
- [Standard GitHub-hosted runner specifications](https://docs.github.com/en/actions/reference/runners/github-hosted-runners): current private Ubuntu specification is 2 CPUs, 8 GB RAM and 14 GB SSD. This is not a measured free-space result for the future job.
- [Git configuration](https://git-scm.com/docs/git-config): documents negotiation and sparse packing tradeoffs. The local controls, rather than these descriptions alone, establish the tested multi-ref behavior.

Remote upload, workflow execution, failure repair and final remote evidence remain parent-owned and unverified here. This reviewer remains available for their actual closed results.
