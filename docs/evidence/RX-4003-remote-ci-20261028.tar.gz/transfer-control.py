from pathlib import Path
import subprocess,os,json,hashlib
R=Path('/tmp/raveldex-remote-ci-20261028-ohw0g124');local=R/'control-local';remote=R/'control-remote.git';local.mkdir()
log=[]
def run(args,cwd=local,check=True,input=None,env=None):
 p=subprocess.run(args,cwd=cwd,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
 log.append({'args':args,'code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')})
 if check:assert p.returncode==0,log[-1]
 return p
G=['git','-c','user.name=Raveldex transfer control','-c','user.email=control@example.invalid']
run(G+['init','-b','main']);run(['git','init','--bare',str(remote)],cwd=R);run(['git','config','receive.maxInputSize','1572864'],cwd=remote)
(local/'README').write_text('Synthetic bounded transfer control; no product payload.\n');run(G+['add','README']);run(G+['commit','-m','control base']);base=run(G+['rev-parse','HEAD']).stdout.decode().strip();run(G+['push',str(remote),base+':refs/heads/main'])
for n in range(3):(local/('fixture'+str(n))).write_bytes(os.urandom(1048576))
run(G+['add','.']);run(G+['commit','-m','control original unchanged commit']);original=run(G+['rev-parse','HEAD']).stdout.decode().strip()
failed=run(G+['-c','pack.window=0','-c','pack.compression=0','push',str(remote),original+':refs/heads/main'],check=False);assert failed.returncode!=0 and b'maximum allowed size' in failed.stderr
assert run(G+['--git-dir='+str(remote),'rev-parse','main']).stdout.decode().strip()==base
index=R/'control-staging.index';env=dict(os.environ,GIT_INDEX_FILE=str(index));run(G+['read-tree',base],env=env);parent=base;stages=[]
for n in range(3):
 oid=run(G+['rev-parse',original+':fixture'+str(n)]).stdout.decode().strip();run(G+['update-index','--add','--cacheinfo','100644,'+oid+',fixture'+str(n)],env=env)
 tree=run(G+['write-tree'],env=env).stdout.decode().strip();commit=run(G+['commit-tree',tree,'-p',parent],input=('Synthetic staging '+str(n)+'\n').encode()).stdout.decode().strip()
 run(G+['-c','pack.window=0','-c','pack.compression=0','push',str(remote),commit+':refs/heads/temporary-object-stage']);stages.append(commit);parent=commit
run(G+['-c','pack.window=0','-c','pack.compression=0','push',str(remote),original+':refs/heads/main']);actual=run(G+['--git-dir='+str(remote),'rev-parse','main']).stdout.decode().strip();assert actual==original
assert run(G+['--git-dir='+str(remote),'rev-parse','temporary-object-stage']).stdout.decode().strip()==parent
run(G+['push',str(remote),'--force-with-lease=refs/heads/temporary-object-stage:'+parent,':refs/heads/temporary-object-stage'])
for n in range(3):assert hashlib.sha256(run(G+['--git-dir='+str(remote),'show',actual+':fixture'+str(n)]).stdout).digest()==hashlib.sha256((local/('fixture'+str(n))).read_bytes()).digest()
# Large binary stdout is deliberately removed from the textual receipt.
for row in log:
 if len(row['stdout'])>4096:row['stdout']='[binary fixture bytes checked by SHA-256; omitted from text log]'
(R/'transfer-control-log.json').write_text(json.dumps(log,indent=2)+'\n')
report={'kind':'raveldex-synthetic-git-object-staging-control-v1','status':'Pass','receiverInputBound':1572864,'sourcePayloadBytes':3*1048576,'directPushRefused':True,'stagingCommits':stages,'originalCommitUnchanged':original,'receiverActualCommit':actual,'allPayloadHashesAgree':True,'temporaryRefDeletedWithExactLease':True,'scope':'Synthetic local protocol control only; real GitHub success must be observed separately. Real source/branch history not touched.'};(R/'transfer-control.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
