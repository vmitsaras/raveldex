#!/usr/bin/env python3
"""Read-only replay of closed CI artifact bindings; no test/build/pack execution."""
import base64, datetime, fnmatch, gzip, hashlib, io, json, pathlib, re, stat, subprocess, tarfile, zipfile

ROOT=pathlib.Path('/tmp/raveldex-remote-ci-20261028-ohw0g124')
REPO=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex')
OUT=ROOT/'artifact-review'
HEAD='9f22e37bacab96bd0c1b9b260b6639b3e16292ba'
RUN=40771652630
sha=lambda data:hashlib.sha256(data).hexdigest()
readjson=lambda path:json.loads(path.read_bytes())
run=lambda *args:subprocess.check_output(args,cwd=REPO)
inputs=[]
def bound(path):
 data=path.read_bytes(); item={'path':str(path),'bytes':len(data),'sha256':sha(data)};inputs.append(item);return data

def checked_path(name,prefix=''):
 assert '\\' not in name and not name.startswith('/') and not re.match(r'^[A-Za-z]:',name),name
 parts=pathlib.PurePosixPath(name).parts
 assert parts and all(p not in ('..','') for p in parts),name
 assert prefix=='' or name.startswith(prefix),name
 return name

def tar_catalog(data):
 raw=gzip.decompress(data)
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
  members=archive.getmembers(); names=[m.name for m in members]
  assert len(names)==len(set(names))==228
  rows=[];payload={}
  for member in members:
   checked_path(member.name,'package/');assert member.isreg() and not member.issym() and not member.islnk(),member.name
   assert member.size<=2*1024*1024
   body=archive.extractfile(member).read();assert len(body)==member.size
   path=member.name.removeprefix('package/');payload[path]=body
   rows.append({'path':path,'bytes':len(body),'sha256':sha(body),'mode':member.mode})
 return raw,sorted(rows,key=lambda r:r['path']),payload

workflow=run('git','show',HEAD+':.github/workflows/ci.yml').decode()
changed=run('git','diff-tree','--no-commit-id','--name-only','-r',HEAD).decode().splitlines()
expected_changed=['.github/workflows/candidate.yml','.github/workflows/ci.yml','.github/workflows/sync-roadmap.yml','test/ui/announcements-browser.test.mjs','test/ui/focus-browser.test.mjs','test/ui/input-browser.test.mjs']
assert changed==expected_changed
assert 'node: [22, 24]' in workflow and 'fail-fast: false' in workflow
assert 'contents: read' in workflow and 'persist-credentials: false' in workflow
assert not any(word in workflow for word in ['contents: write','packages: write','id-token: write','secrets.','npm publish','gh release','git tag'])
assert 'npm run candidate:prepare' in workflow and 'npm run tracking:preview' in workflow
assert 'retention-days: 7' in workflow and 'if: always()' in workflow
assert 'sparse-checkout-cone-mode: false' in workflow
pattern='docs/evidence/RX-4002-gc-shrink-raw-*-20261028.tar.xz'
assert '!/'+pattern in workflow
source_bindings=[]
for path in changed:
 data=run('git','show',HEAD+':'+path)
 source_bindings.append({'path':path,'bytes':len(data),'sha256':sha(data),'gitBlob':run('git','rev-parse',HEAD+':'+path).decode().strip()})
 if path.startswith('test/'):
  diff=run('git','diff',HEAD+'^',HEAD,'--',path).decode()
  removals=[line for line in diff.splitlines() if line.startswith('-') and not line.startswith('---')]
  assert len(removals)==1 and "browser = await chromium.launch({ channel: 'chrome'" in removals[0]
  assert "['chrome', 'chromium']" in diff and "process.env.RAVELDEX_UI_BROWSER ?? 'chrome'" in diff

binding=readjson(ROOT/'remote-run-binding.json');bound(ROOT/'remote-run-binding.json')
runmeta=readjson(ROOT/'run-40771652630-final.json');bound(ROOT/'run-40771652630-final.json')
artifacts=readjson(ROOT/'run-40771652630-artifacts.json');bound(ROOT/'run-40771652630-artifacts.json')
log=bound(ROOT/'run-40771652630.log').decode()
assert binding['id']==RUN and binding['path']=='.github/workflows/ci.yml' and binding['run_attempt']==1 and binding['head_sha']==HEAD
assert runmeta['databaseId']==RUN and runmeta['headSha']==HEAD and runmeta['status']=='completed' and runmeta['conclusion']=='success' and runmeta['event']=='workflow_dispatch'
assert artifacts['total_count']==len(artifacts['artifacts'])==2
assert len(runmeta['jobs'])==2

original_report=readjson(REPO/'docs/evidence/RX-4003-package.json');bound(REPO/'docs/evidence/RX-4003-package.json')
original_tar_path=pathlib.Path(original_report['package']['tarball'])
original_tar=bound(original_tar_path)
assert sha(original_tar)==original_report['package']['sha256']=='c6720f44c5158dff8d4f9d0530f91f6d94942a1c2c3ea9cb3ed49f6b9d7e0d73'
original_raw,original_members,original_payload=tar_catalog(original_tar)
original_catalog={row['path']:row for row in original_members}
assert len([p for p in original_catalog if p.startswith('dist/')])==208
assert sorted(original_catalog)==sorted(f['path'] for f in original_report['package']['files'])
for f in original_report['package']['files']:
 assert original_catalog[f['path']]['sha256']==f['sha256'] and original_catalog[f['path']]['bytes']==f['bytes']

tracked=run('git','ls-tree','-r','--name-only',HEAD).decode().splitlines()
omitted=[path for path in tracked if fnmatch.fnmatchcase(path,pattern)]
assert len(omitted)==127
sparse=ROOT/'sparse-checkout-control'
assert run('git','-C',str(sparse),'rev-parse','HEAD').decode().strip()==HEAD
missing=[path for path in tracked if not (sparse/path).exists()]
assert missing==omitted
assert not any(p.startswith(('test/','src/','scripts/','bench/')) for p in missing)
sparse_test_paths=[path for path in tracked if path.startswith('test/')]
assert all((sparse/path).is_file() for path in sparse_test_paths)
# The actual full command comes from package.json at the tested commit.
package_at_head=json.loads(run('git','show',HEAD+':package.json'))
assert package_at_head['scripts']['check']=='npm run handoff:check && npm run docs:check && npm run typecheck && npm test'
assert package_at_head['scripts']['test']==json.loads(run('git','show',HEAD+'^:package.json'))['scripts']['test']
assert package_at_head['scripts']['candidate:prepare']=='node scripts/prepare-candidate.mjs'
assert package_at_head['private'] is True and package_at_head['version']=='0.1.0-rc.0'

rows=[]
expected_members={'candidate-report.json','preparation.json','verification.log','vmitsaras-raveldex-0.1.0-rc.0.tgz'}
for major,nodeversion,npmversion,jobid in [(22,'v22.23.4','10.9.9',123110134376),(24,'v24.22.1','11.19.1',123110134029)]:
 name=f'raveldex-ci-candidate-node-{major}'
 artifact=next(a for a in artifacts['artifacts'] if a['name']==name)
 assert artifact['workflow_run']['id']==RUN and artifact['workflow_run']['head_sha']==HEAD and not artifact['expired']
 job=next(j for j in runmeta['jobs'] if j['databaseId']==jobid)
 assert job['name']==f'Candidate verification (Node {major})' and job['status']=='completed' and job['conclusion']=='success'
 assert all(s['status']=='completed' and s['conclusion']=='success' for s in job['steps'])
 joblines=[line for line in log.splitlines() if line.startswith(job['name']+'\t')]
 joblog='\n'.join(joblines)
 assert all(text in joblog for text in [HEAD,'Contents: read','Metadata: read','Ubuntu','26.04.1','Image: ubuntu-26.04','Version: 20261025.179.1',f'node: {nodeversion}',f'npm: {npmversion}'])
 assert 'npm run candidate:prepare -- --output' in joblog
 for namevar in ['RAVELDEX_UI_BROWSER','RAVELDEX_WORKER_BROWSER','RAVELDEX_INDEXEDDB_BROWSER','RAVELDEX_CANDIDATE_BROWSER']:
  assert f'{namevar}: chromium' in joblog
 zpath=ROOT/f'artifact-node-{major}.zip';zipbytes=bound(zpath)
 assert len(zipbytes)==artifact['size_in_bytes'] and 'sha256:'+sha(zipbytes)==artifact['digest']
 assert sha(zipbytes) in joblog and str(artifact['id']) in joblog
 zrows=[];payloads={}
 with zipfile.ZipFile(io.BytesIO(zipbytes)) as archive:
  assert archive.testzip() is None
  members=archive.infolist();assert len(members)==4 and {m.filename for m in members}==expected_members
  for member in members:
   checked_path(member.filename)
   mode=member.external_attr>>16
   assert stat.S_IFMT(mode) in (0,stat.S_IFREG) and not member.is_dir() and not member.flag_bits&1
   assert member.file_size<2*1024*1024 and member.compress_size>0
   data=archive.read(member);assert len(data)==member.file_size
   assert data==(ROOT/'remote-artifacts'/name/member.filename).read_bytes()
   payloads[member.filename]=data
   zrows.append({'path':member.filename,'bytes':len(data),'sha256':sha(data),'mode':mode,'crc32':f'{member.CRC:08x}'})
 prep=json.loads(payloads['preparation.json']);report=json.loads(payloads['candidate-report.json']);verification=payloads['verification.log'].decode()
 assert prep['kind']=='raveldex-candidate-preparation-v1' and prep['status']=='Pass' and prep['private'] is True and prep['packageVersion']=='0.1.0-rc.0'
 assert prep['projectCheck']['exitCode']==0 and prep['projectCheck']['command']=='npm run check' and prep['projectCheck']['log']=='verification.log' and prep['projectCheck']['sha256']==sha(payloads['verification.log'])
 assert prep['candidateReport']['path']=='candidate-report.json' and prep['candidateReport']['sha256']==sha(payloads['candidate-report.json'])
 assert report['status']=='Pass' and report['kind']=='raveldex-native-candidate-v1'
 assert prep['startedAt']<report['startedAt']<report['completedAt']<=prep['completedAt']
 assert job['startedAt']<prep['startedAt']<prep['completedAt']<=job['completedAt']
 assert report['environment']=={'node':nodeversion,'platform':'linux','arch':'x64','release':'7.0.0-1017-azure','npm':npmversion}
 browser=report['documentation']['browser']
 assert browser['status']=='Pass' and browser['environment']=={'channel':'chromium','version':'149.0.7827.55','headless':True,'playwright':'1.61.1'}
 assert report['documentation']['status']==report['documentation']['node']['status']=='Pass'
 assert browser['pageErrors']==[] and browser['foreignRequests']==[] and len(report['documentation']['sources'])==7
 assert report['startup']['reads']==[] and len(report['startup']['outputs'])==19
 assert report['types']['status']=='Pass' and len(report['types']['surface'])==19
 assert sum(len(entry['exports']) for entry in report['types']['surface'])==156
 assert report['graphs']['status']=='Pass' and len(report['graphs']['entries'])==19 and report['graphs']['css']['status']=='Pass'
 assert len(report['package']['exports'])==20 and report['package']['private'] is True and report['package']['runtimeDependencies']==[]
 expected_batches=[544,30,24,26,1]
 counts={k:list(map(int,re.findall(r'^(?:#|ℹ) '+k+r' (\d+)\s*$',verification,re.M))) for k in ['tests','pass','fail','cancelled','skipped','todo']}
 assert counts['tests']==counts['pass']==expected_batches
 assert all(counts[k]==[0]*5 for k in ['fail','cancelled','skipped','todo'])
 success_re=r'^\s*ok \d+ - ' if major==22 else r'^\s*✔ '
 assert len(re.findall(success_re,verification,re.M))==625
 assert not re.search(r'^\s*(?:not ok |✖ )',verification,re.M)
 batches=[];start=0
 for index,summary in enumerate(re.finditer(r'^(?:#|ℹ) tests (\d+)\s*$',verification,re.M)):
  segment=verification[start:summary.start()]
  successes=len(re.findall(success_re,segment,re.M));assert successes==expected_batches[index]
  batches.append({'tests':successes,'summaryTests':int(summary.group(1)),'summaryFormat':'TAP #' if major==22 else 'spec ℹ'})
  start=summary.end()
 assert '> tsc -p tsconfig.json' in verification and '> node scripts/plan.mjs check' in verification and 'Generated roadmap and task documents match' in verification
 assert package_at_head['scripts']['test'] in verification
 tarname=next(n for n in expected_members if n.endswith('.tgz'));tarbytes=payloads[tarname]
 assert sha(tarbytes)==report['package']['sha256']=='413a3ec7475972f9fa78d30cde2f1a61c92304a637e90704bb332fd307465d33'
 assert len(tarbytes)==report['package']['tarballBytes']==166847
 assert 'sha512-'+base64.b64encode(hashlib.sha512(tarbytes).digest()).decode()==report['package']['integrity']
 raw,catalog,body=tar_catalog(tarbytes)
 assert raw==original_raw
 assert catalog==original_members
 assert sum(r['bytes'] for r in catalog)==report['package']['unpackedBytes']==690038
 reported={r['path']:r for r in report['package']['files']};assert set(reported)==set(original_catalog)
 for member in catalog:
  r=reported[member['path']];assert r['bytes']==member['bytes'] and r['sha256']==member['sha256']
 metadata=json.loads(body['package.json']);assert metadata==package_at_head and metadata['private'] is True
 for key in ['dependencies','optionalDependencies','peerDependencies']:assert metadata.get(key,{})=={}
 # Verify non-production packaged source files against the exact tested commit.
 source_members=[]
 for path,data in body.items():
  if path.startswith('dist/'):continue
  assert data==run('git','show',HEAD+':'+path),path
  source_members.append(path)
 rows.append({'status':'Pass','nodeMajor':major,'job':job,'environment':report['environment'],'runner':{'os':'Ubuntu 26.04.1','image':'ubuntu-26.04','imageVersion':'20261025.179.1'},'browser':browser['environment'],
  'artifact':{'id':artifact['id'],'name':name,'zipPath':str(zpath),'zipBytes':len(zipbytes),'zipSha256':sha(zipbytes),'githubDigest':artifact['digest'],'digestMatchesDownloadedAndUploadLog':True,'members':zrows,'safeRegularUnencryptedMembersAndCRCVerified':True,'extractedFileBytesMatchZip':True,'expiresAt':artifact['expires_at']},
  'closedBindings':{'preparationReportAndLogHashesPass':True,'boundedJobAndReportTimesPass':True,'npmIntegrityPass':True,'readOnlyWorkflowPass':True},
  'verification':{'actualSuccessMarkers':625,'summary':counts,'batches':batches,'zeroFailureCancelledSkippedTodo':True,'fullUnchangedTestCommandInLog':True,'typecheckDocsPlannerCommandsPresent':True},
  'candidate':{'version':metadata['version'],'private':True,'runtimeDependencies':[],'reportSha256':sha(payloads['candidate-report.json']),'preparationSha256':sha(payloads['preparation.json']),'verificationLogSha256':sha(payloads['verification.log']),'tarballSha256':sha(tarbytes),'tarballBytes':len(tarbytes),'decompressedTarBytes':len(raw),'decompressedTarSha256':sha(raw),'decompressedTarByteIdenticalToOriginal':True,'all228MemberSizesAndHashesMatchOriginalAndRemoteReport':True,'all208ProductionMembersMatch':True,'all20NonProductionMembersMatchTestedCommit':True,'exports':20,'javascriptEntries':19,'publicDeclarationNames':156,'examples':7,'documentedExamplesNodeAndBrowserPass':True}})

result={'kind':'raveldex-independent-remote-ci-artifact-review-v1','status':'Pass','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewMethod':'Independent raw ZIP/tar/gzip/log/JSON replay. No project checks, builds, package generation, browser runs, publication, remote mutations, heavy archive reading or memory/AT repeats.',
 'run':{'id':RUN,'url':runmeta['url'],'path':binding['path'],'attempt':binding['run_attempt'],'event':runmeta['event'],'headSha':HEAD,'headBranch':runmeta['headBranch'],'status':runmeta['status'],'conclusion':runmeta['conclusion']},
 'sourceReview':{'changedPaths':changed,'bindings':source_bindings,'sixCIAndHarnessFilesOnly':True,'runtimePackageDocsAndTestSelectionUnchanged':True,'harnessBehavior':'Three prior fixed Chrome launches honor the existing explicit chrome/chromium environment selection, reject unsupported selections, and retain all assertions.','workflowPermissions':'CI/manual candidate contents:read, credentials not persisted, SHA-pinned actions, no publication/tag/npm credentials; existing main-only roadmap workflow issues:write is unchanged and was not this run.','sparseCheckout':{'pattern':pattern,'omittedArchiveMembers':len(omitted),'omittedPaths':omitted,'allOtherTrackedFilesPresentInIndependentCatalogCheck':True,'trackedTestFilesRetained':len(sparse_test_paths),'noSourceScriptsTestsOrBenchFilesOmitted':True,'scope':'File-name/stat catalog only; raw stream contents were not read or replayed.'}},
 'original':{'reportPath':str(REPO/'docs/evidence/RX-4003-package.json'),'tarballPath':str(original_tar_path),'tarballSha256':sha(original_tar),'tarballBytes':len(original_tar),'decompressedTarSha256':sha(original_raw),'decompressedTarBytes':len(original_raw),'members':228,'productionMembers':208},
 'jobs':rows,'memberCatalog':original_members,'rawBindings':inputs,'findings':[],
 'supportLimits':['Finite recorded Ubuntu26.04.1 x64 runner / kernel7.0.0-1017-azure / Node22.23.4 and24.22.1 / headless Chromium149.0.7827.55 evidence only; no universal Linux, browser or Node-major support promise.','These artifacts record actual successful remote CI jobs; preparatory harness/browser-matrix/sparse fixes are included in the tested commit. No prior remote job failure is evidenced or asserted by this review.','Remote/local gzip envelope hashes differ. Their completely decompressed tar bytes and all228 package members, including208 production files, are identical.','No new physical, assistive-technology, performance, allocator or power-loss durability qualification was performed. Historical exact-context observations remain separate.','GitHub final metadata, run-path binding, upload logs, downloaded ZIPs and local frozen source were reviewed; no independent live API requery or public release was performed.','The separately completed large transfer-protocol audit is outside this artifact review. Publication remains a separate owner action.']}
(OUT/'independent-artifact-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'output':str(OUT/'independent-artifact-review.json'),'jobs':len(rows),'testsPerJob':625,'zipDigests':[r['artifact']['zipSha256'] for r in rows],'members':228,'decompressedTarSha256':sha(original_raw),'findings':result['findings']}))
