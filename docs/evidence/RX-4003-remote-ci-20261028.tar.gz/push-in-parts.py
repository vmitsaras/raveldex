from pathlib import Path
import subprocess,json,os,uuid,time,hashlib
R=Path('/tmp/raveldex-remote-ci-20261028-ohw0g124');REPO=Path('/Users/vasilis/Documents/GitHub/raveldex');statepath=R/'transfer-state.json'
G=['git','-c','pack.useSparse=false','-c','pack.window=0','-c','pack.compression=0','-c','pack.threads=2'];dest='refs/heads/codex/rx-4002-qualification'
def git(args,input=None,env=None):
 p=subprocess.run(G+args,cwd=REPO,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
 if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
 return p.stdout.decode().strip()
def save(s):statepath.write_text(json.dumps(s,indent=2)+'\n')
def head(ref):
 v=git(['ls-remote','--heads','origin',ref]);return v.split()[0]if v else None
def push(args,name):
 path=R/(name+'.log');start=time.time();print(json.dumps({'phase':'push-start','name':name,'time':start}),flush=True)
 with path.open('wb')as log:p=subprocess.run(G+['push','--progress']+args,cwd=REPO,stdout=log,stderr=subprocess.STDOUT)
 result={'name':name,'exitCode':p.returncode,'elapsedSeconds':time.time()-start,'log':str(path),'logSha256':hashlib.sha256(path.read_bytes()).hexdigest()};print(json.dumps({'phase':'push-finished',**result}),flush=True)
 if p.returncode:raise RuntimeError('Push failed; preserved '+str(path))
 return result
assert git(['remote','get-url','origin'])=='https://github.com/vmitsaras/raveldex.git'
if statepath.exists():s=json.loads(statepath.read_text())
else:
 desired=git(['rev-parse','HEAD']);assert desired.startswith('9f22e37');base=git(['rev-parse','9df98f6']);git(['merge-base','--is-ancestor',base,desired]);initial=head(dest);assert initial=='b8a29b88e2ffae19adba612c16ac1dddfcc963d3'
 raw=git(['rev-list','--objects',desired,'^'+base]);oids=[x.split()[0]for x in raw.splitlines()];meta=git(['cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],input=('\n'.join(oids)+'\n').encode());large=[];other=0
 for line in meta.splitlines():
  oid,kind,n=line.split();n=int(n)
  if kind=='blob'and n>8*1024**2:large.append({'oid':oid,'bytes':n})
  else:other+=n
 assert other<256*1024**2 and large and all(x['bytes']<100*1024**2 for x in large)
 batches=[];batch=[];size=0
 for x in large:
  if size+x['bytes']>900*1024**2:batches.append(batch);batch=[];size=0
  batch.append(x);size+=x['bytes']
 if batch:batches.append(batch)
 temp='refs/heads/codex/ci-object-transfer-'+uuid.uuid4().hex[:12];assert head(temp)is None
 s={'schema':'raveldex-bounded-existing-object-transfer-v1','desired':desired,'base':base,'actualRef':dest,'initialRemoteHead':initial,'temporaryRef':temp,'batchLimitBytes':900*1024**2,'batches':batches,'otherNewObjectBytes':other,'completedBatches':[],'receipts':[],'basePushed':False,'status':'In progress'};save(s)
if not s['basePushed']:
 assert head(dest)==s['initialRemoteHead'];s['receipts'].append(push(['--atomic','origin',s['base']+':'+dest],'push-base'));assert head(dest)==s['base'];s['basePushed']=True;save(s)
index=R/'transfer.index';env=dict(os.environ,GIT_INDEX_FILE=str(index));parent=s['completedBatches'][-1]['commit']if s['completedBatches']else s['base'];git(['read-tree',parent],env=env)
for number,batch in enumerate(s['batches']):
 if number<len(s['completedBatches']):continue
 expected=parent if s['completedBatches']else None;assert head(s['temporaryRef'])==expected
 for x in batch:git(['update-index','--add','--cacheinfo','100644,'+x['oid']+',.ci-transfer-blobs/'+x['oid']],env=env)
 tree=git(['write-tree'],env=env);commit=git(['commit-tree',tree,'-p',parent],input=('Temporary delivery of existing qualification objects, batch '+str(number+1)+'\n').encode())
 git(['update-ref',s['temporaryRef'],commit,parent if s['completedBatches']else'0'*40]);receipt=push(['--atomic','origin',s['temporaryRef']+':'+s['temporaryRef']],'push-objects-'+str(number+1));assert head(s['temporaryRef'])==commit
 s['receipts'].append(receipt);s['completedBatches'].append({'number':number+1,'bytes':sum(x['bytes']for x in batch),'blobs':len(batch),'parent':parent,'tree':tree,'commit':commit});parent=commit;save(s)
assert head(dest)==s['base']and head(s['temporaryRef'])==parent
if 'advance'not in s:
 tree=git(['rev-parse',parent+'^{tree}']);advance=git(['commit-tree',tree,'-p',parent],input=b'Temporary final transfer boundary advance\n');s['advance']=advance;s['lastStageTip']=parent;save(s)
 git(['update-ref',s['temporaryRef'],advance,parent])
# Confirm the explicit negative-object walk is bounded before network finalization.
pack=R/'final-expected.pack'
if not pack.exists():
 with pack.open('wb')as f:
  p=subprocess.run(G+['pack-objects','--revs','--stdout'],cwd=REPO,input=(s['desired']+'\n'+s['advance']+'\n^'+s['lastStageTip']+'\n').encode(),stdout=f,stderr=subprocess.PIPE)
 assert p.returncode==0 and pack.stat().st_size<512*1024**2
 s['expectedFinalPack']={'bytes':pack.stat().st_size,'sha256':hashlib.sha256(pack.read_bytes()).hexdigest()};save(s)
assert git(['rev-parse',s['temporaryRef']])==s['advance']
s['receipts'].append(push(['--atomic','origin',s['desired']+':'+dest,s['temporaryRef']+':'+s['temporaryRef']],'push-original-and-boundary'));assert head(dest)==s['desired']and head(s['temporaryRef'])==s['advance'];s['originalBranchVerified']=True;save(s)
s['receipts'].append(push(['--force-with-lease='+s['temporaryRef']+':'+s['advance'],'origin',':'+s['temporaryRef']],'delete-owned-temporary-ref'));assert head(s['temporaryRef'])is None;git(['update-ref','-d',s['temporaryRef'],s['advance']]);s['temporaryRefDeleted']=True;s['status']='Pass';save(s);print(json.dumps({'phase':'complete','desired':s['desired'],'batches':len(s['batches']),'bytes':sum(x['bytes']for b in s['batches']for x in b),'status':'Pass'}),flush=True)
