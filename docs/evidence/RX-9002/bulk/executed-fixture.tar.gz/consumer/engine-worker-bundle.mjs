// node_modules/@vmitsaras/raveldex/dist/core/errors/error.js
var ERROR_CODES = Object.freeze([
  "INVALID_SCHEMA",
  "INVALID_RECORD",
  "INVALID_QUERY",
  "INVALID_OPTIONS",
  "ID_EXISTS",
  "ID_NOT_FOUND",
  "LIMIT_EXCEEDED",
  "QUEUE_FULL",
  "WORK_LIMIT_EXCEEDED",
  "DEADLINE_EXCEEDED",
  "CANCELLED",
  "DISPOSED",
  "MISSING_CAPABILITY",
  "INCOMPATIBLE_CAPABILITY",
  "REVISION_MISMATCH",
  "REVISION_EXHAUSTED",
  "RESOURCE_EXHAUSTED",
  "UNSUPPORTED_ENVIRONMENT",
  "INTERNAL_ERROR"
]);
var RaveldexError = class extends Error {
  code;
  details;
  constructor(code, details = {}) {
    super(`Raveldex: ${code}`);
    this.name = "RaveldexError";
    this.code = code;
    this.details = Object.freeze({
      ...details.path === void 0 ? {} : { path: details.path.slice(0, 256) },
      ...details.limit === void 0 ? {} : { limit: details.limit },
      ...details.actual === void 0 ? {} : { actual: details.actual }
    });
  }
};
function invalid(code, path) {
  throw new RaveldexError(code, { path });
}
function bound(actual, limit, path) {
  if (!Number.isSafeInteger(actual) || actual > limit) {
    throw new RaveldexError("LIMIT_EXCEEDED", { path, limit, actual });
  }
}

// node_modules/@vmitsaras/raveldex/dist/core/contracts/data.js
var Admission = class {
  maximum;
  entries = 0;
  constructor(maximum) {
    this.maximum = maximum;
  }
  get count() {
    return this.entries;
  }
  charge(count5, path) {
    this.entries += count5;
    bound(this.entries, this.maximum, path);
  }
};
function ownObject(input, code, path, admission) {
  if (typeof input !== "object" || input === null)
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Object.prototype)
    invalid(code, path);
  const keys = Reflect.ownKeys(input);
  admission.charge(keys.length, path);
  const copy = /* @__PURE__ */ Object.create(null);
  for (const key of keys) {
    if (typeof key !== "string")
      invalid(code, path);
    const descriptor = Object.getOwnPropertyDescriptor(input, key);
    if (!descriptor || !("value" in descriptor))
      invalid(code, path);
    copy[key] = descriptor.value;
  }
  return copy;
}
function ownArray(input, maximum, code, path, admission) {
  if (!Array.isArray(input))
    invalid(code, path);
  const proto = Object.getPrototypeOf(input);
  if (proto !== null && proto !== Array.prototype)
    invalid(code, path);
  bound(input.length, maximum, path);
  const keys = Reflect.ownKeys(input);
  admission.charge(keys.length, path);
  if (keys.length !== input.length + 1)
    invalid(code, path);
  for (const key of keys) {
    if (key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= input.length)) {
      invalid(code, path);
    }
  }
  const copy = [];
  for (let i = 0; i < input.length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(input, String(i));
    if (!descriptor || !("value" in descriptor))
      invalid(code, `${path}[${i}]`);
    copy.push(descriptor.value);
  }
  return copy;
}
function keysOnly(data2, allowed, code, path) {
  for (const key of Object.keys(data2))
    if (!allowed.includes(key))
      invalid(code, path);
}
function has(data2, key) {
  return Object.prototype.hasOwnProperty.call(data2, key);
}
function stringValue(input, maximum, code, path) {
  if (typeof input !== "string")
    invalid(code, path);
  bound(input.length, maximum, path);
  return input;
}
function* scanUnicode(value, code, path) {
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, path);
    i += width;
    yield { workUnits: 1 };
  }
}
function codePointWidth(value, index, code, path) {
  const first = value.charCodeAt(index);
  if (first >= 55296 && first <= 56319) {
    const second = value.charCodeAt(index + 1);
    if (!(second >= 56320 && second <= 57343))
      invalid(code, path);
    return 2;
  }
  if (first >= 56320 && first <= 57343)
    invalid(code, path);
  return 1;
}

// node_modules/@vmitsaras/raveldex/dist/core/limits/limits.js
var DEFAULT_LIMITS = Object.freeze({
  maxDocuments: 1e4,
  maxTextFields: 32,
  maxMetadataFields: 32,
  maxFieldNameCodeUnits: 64,
  maxIdCodeUnits: 256,
  maxTextValuesPerField: 64,
  maxMetadataValuesPerField: 128,
  maxMetadataStringCodeUnits: 1024,
  maxMetadataCodeUnitsPerRecord: 32768,
  maxTextCodeUnitsPerValue: 65536,
  maxTextCodeUnitsPerRecord: 262144,
  maxCorpusTextCodeUnits: 67108864,
  maxRawTokenCodeUnits: 256,
  maxTermCodeUnits: 256,
  maxTokensPerRecord: 32768,
  maxCorpusTokens: 4e6,
  maxDictionaryEntries: 25e4,
  maxPostingEntries: 2e6,
  maxMutationBatch: 256,
  maxAdmissionEntries: 16384,
  maxQueryNodes: 128,
  maxQueryDepth: 16,
  maxQueryLexicalCodeUnits: 2048,
  maxQueryCodeUnits: 16384,
  maxQueryTokens: 64,
  maxQueryGroups: 64,
  maxVariantsPerGroup: 16,
  maxExpansionsPerGroup: 256,
  maxQueryExpansions: 1024,
  minPrefixCodePoints: 2,
  maxHits: 100,
  maxQueuedOperations: 32,
  maxSearchWorkUnits: 1e7,
  maxMutationWorkUnits: 5e7,
  checkpointWorkUnits: 2048,
  maxDeadlineMs: 6e4
});
function resolveLimits(input = {}, admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries)) {
  const data2 = ownObject(input, "INVALID_OPTIONS", "limits", admission);
  const result = { ...DEFAULT_LIMITS };
  for (const key of Object.keys(data2)) {
    if (!has(DEFAULT_LIMITS, key))
      invalid("INVALID_OPTIONS", "limits");
    const name2 = key;
    const value = data2[key];
    const minimum = name2 === "maxMetadataFields" || name2 === "maxQueuedOperations" ? 0 : name2 === "minPrefixCodePoints" ? 2 : 1;
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid("INVALID_OPTIONS", `limits.${name2}`);
    if (name2 !== "minPrefixCodePoints")
      bound(value, DEFAULT_LIMITS[name2], `limits.${name2}`);
    result[name2] = value;
  }
  if (result.checkpointWorkUnits > Math.min(result.maxSearchWorkUnits, result.maxMutationWorkUnits)) {
    invalid("INVALID_OPTIONS", "limits.checkpointWorkUnits");
  }
  return Object.freeze(result);
}
function validateStateCounts(counts, limits) {
  const pairs = [
    ["documents", "maxDocuments"],
    ["textCodeUnits", "maxCorpusTextCodeUnits"],
    ["tokens", "maxCorpusTokens"],
    ["dictionaryEntries", "maxDictionaryEntries"],
    ["postingEntries", "maxPostingEntries"]
  ];
  for (const [count5, limit] of pairs) {
    if (!Number.isSafeInteger(counts[count5]) || counts[count5] < 0)
      invalid("INTERNAL_ERROR", `state.${count5}`);
    bound(counts[count5], limits[limit], `state.${count5}`);
  }
}

// node_modules/@vmitsaras/raveldex/dist/core/analyzer/basic.js
var BASIC_ANALYZER = Object.freeze({ id: "basic-v1", environmentProfile: "unqualified" });
var START = /[\p{L}\p{N}]/u;
var CONTINUE = /[\p{L}\p{N}\p{M}]/u;
function* analyzeValue(value, valueIndex = 0, limits = DEFAULT_LIMITS, code = "INVALID_RECORD") {
  bound(value.length, limits.maxTextCodeUnitsPerValue, "analysis.value");
  let start = -1;
  let position = 0;
  function emit(end) {
    const raw = value.slice(start, end);
    const term = raw.normalize("NFKC").toLowerCase();
    bound(term.length, limits.maxTermCodeUnits, "analysis.term");
    const token = Object.freeze({ term, valueIndex, position: position++, start, end });
    start = -1;
    return { workUnits: raw.length + term.length, token };
  }
  for (let i = 0; i < value.length; ) {
    const width = codePointWidth(value, i, code, "analysis.value");
    const point = value.slice(i, i + width);
    if (start >= 0 && !CONTINUE.test(point))
      yield emit(i);
    if (start < 0 && START.test(point))
      start = i;
    i += width;
    if (start >= 0)
      bound(i - start, limits.maxRawTokenCodeUnits, "analysis.rawToken");
    yield { workUnits: 1 };
  }
  if (start >= 0)
    yield emit(value.length);
}

// node_modules/@vmitsaras/raveldex/dist/core/capabilities/bulk-participant.js
var factories = /* @__PURE__ */ new WeakMap();
function registerBulkParticipant(registration, factory) {
  factories.set(registration, factory);
  return registration;
}
function captureBulkParticipant(original, captured) {
  const factory = factories.get(original);
  if (factory)
    factories.set(captured, factory);
}
function bulkParticipant(registration, initial) {
  return factories.get(registration)?.(initial);
}

// node_modules/@vmitsaras/raveldex/dist/core/capabilities/registration.js
function captureRegistrations(input, context) {
  const { schema: schema2, limits, admission } = context, code = "INCOMPATIBLE_CAPABILITY";
  const entries = ownArray(input, 32, code, "addons", admission);
  const registrations = /* @__PURE__ */ new Map();
  const providers = /* @__PURE__ */ Object.create(null);
  const object4 = (value, path, keys) => {
    const data2 = ownObject(value, code, path, admission);
    keysOnly(data2, keys, code, path);
    return data2;
  };
  const string = (value, path, maximum = 128) => {
    const result = stringValue(value, maximum, code, path);
    if (!result.length)
      invalid(code, path);
    for (const step of scanUnicode(result, code, path)) {
      void step;
    }
    return result;
  };
  const id = (value, path) => {
    const result = string(value, path);
    if (!/^[A-Za-z][A-Za-z0-9:._-]*$/.test(result))
      invalid(code, path);
    return result;
  };
  const integer5 = (value, path, minimum = 0) => {
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid(code, path);
    return value;
  };
  const flag = (value, path) => {
    if (typeof value !== "boolean")
      invalid(code, path);
    return value;
  };
  const references = (value, path) => {
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(ownArray(value, 64, code, path, admission).map((value2) => {
      const ref = object4(value2, path, ["id", "contractVersion"]), name2 = id(ref.id, path);
      if (ref.contractVersion !== 1 || seen.has(name2))
        invalid(code, path);
      seen.add(name2);
      return Object.freeze({ id: name2, contractVersion: 1 });
    }));
  };
  for (const entry of entries) {
    const data2 = object4(entry, "addons.registration", ["manifest", "participant", "refinement", "predicate", "sourcePredicate", "aggregation", "evidence", "expansion", "dictionary", "analyzer"]);
    const raw = object4(data2.manifest, "addons.manifest", ["id", "version", "contractVersion", "roles", "provides", "requires", "dataRequirements", "indexEffect", "rebuildPolicy", "execution", "limits", "costs", "codec"]);
    const name2 = id(raw.id, "addons.id"), version = string(raw.version, "addons.version");
    const semanticVersion = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/;
    if (!semanticVersion.test(version) || raw.contractVersion !== 1 || registrations.has(name2))
      invalid(code, "addons.identity");
    const roles = ownArray(raw.roles, 7, code, "addons.roles", admission);
    if (!roles.length || new Set(roles).size !== roles.length || roles.some((role) => role !== "leaf-refinement" && role !== "transaction-participant" && role !== "aggregation" && role !== "evidence" && role !== "term-expansion" && role !== "dictionary-output" && role !== "analyzer"))
      invalid(code, "addons.roles");
    const requirements = object4(raw.dataRequirements, "addons.dataRequirements", ["fields", "source", "positions", "offsets", "metadata"]);
    const metadata2 = flag(requirements.metadata, "addons.metadata");
    const fields2 = ownArray(requirements.fields, metadata2 ? limits.maxMetadataFields : limits.maxTextFields, code, "addons.fields", admission).map((field) => {
      const name3 = id(field, "addons.fields");
      if (!has(metadata2 ? schema2.metadata : schema2.text, name3))
        invalid(code, "addons.fields");
      return name3;
    });
    if (new Set(fields2).size !== fields2.length)
      invalid(code, "addons.fields");
    const execution = object4(raw.execution, "addons.execution", ["direct", "worker", "workerRegistration"]);
    if (execution.direct !== true || typeof execution.worker !== "boolean" || execution.worker !== has(execution, "workerRegistration"))
      invalid(code, "addons.execution");
    const workerRegistration = execution.worker ? string(execution.workerRegistration, "addons.workerRegistration", 8192) : void 0;
    const caps = object4(raw.limits, "addons.limits", ["maxPayloadCodeUnits", "maxWorkUnits", "maxRetainedEntries", "maxOutputEntries"]);
    const ownedLimits = Object.freeze({ maxPayloadCodeUnits: integer5(caps.maxPayloadCodeUnits, "addons.limits", 1), maxWorkUnits: integer5(caps.maxWorkUnits, "addons.limits", 1), maxRetainedEntries: integer5(caps.maxRetainedEntries, "addons.limits"), maxOutputEntries: integer5(caps.maxOutputEntries, "addons.limits") });
    if (ownedLimits.maxPayloadCodeUnits > DEFAULT_LIMITS.maxQueryCodeUnits || ownedLimits.maxWorkUnits > Math.max(DEFAULT_LIMITS.maxSearchWorkUnits, DEFAULT_LIMITS.maxMutationWorkUnits))
      invalid(code, "addons.limits");
    const costs = object4(raw.costs, "addons.costs", ["importedCode", "retainedRepresentation", "transientWork", "externalResources"]);
    if (costs.externalResources !== "none" || raw.rebuildPolicy !== "new-index")
      invalid(code, "addons.costs");
    const participantRole = roles.includes("transaction-participant"), refinementRole = roles.includes("leaf-refinement"), aggregationRole = roles.includes("aggregation"), evidenceRole = roles.includes("evidence");
    const expansionRole = roles.includes("term-expansion");
    const dictionaryRole = roles.includes("dictionary-output");
    const analyzerRole = roles.includes("analyzer");
    if (analyzerRole !== has(data2, "analyzer") || analyzerRole && (roles.length !== 1 || fields2.length !== 0 || metadata2 || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false || has(raw, "codec")))
      invalid(code, "addons.analyzer");
    if (dictionaryRole !== has(data2, "dictionary") || dictionaryRole && (roles.length !== 1 || metadata2 || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.dictionary");
    if (expansionRole !== has(data2, "expansion") || expansionRole && (roles.length !== 1 || metadata2 || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.expansion");
    const leafHandles = ["refinement", "predicate", "sourcePredicate"].filter((key) => has(data2, key)).length;
    if (participantRole !== has(data2, "participant") || refinementRole !== (leafHandles === 1) || leafHandles > 1 || aggregationRole !== has(data2, "aggregation") || evidenceRole !== has(data2, "evidence") || raw.indexEffect !== (participantRole ? "transactional" : analyzerRole ? "analysis" : "none"))
      invalid(code, "addons.roles");
    if ((has(data2, "predicate") || aggregationRole) && (!metadata2 || participantRole || requirements.source !== false || requirements.positions !== false || requirements.offsets !== false))
      invalid(code, "addons.dataRequirements");
    if (has(data2, "sourcePredicate") && (metadata2 || participantRole || requirements.source !== true || requirements.positions !== false || requirements.offsets !== false || !fields2.length || has(raw, "codec")))
      invalid(code, "addons.dataRequirements");
    if (evidenceRole && (participantRole || metadata2 || requirements.offsets === true && requirements.positions !== true))
      invalid(code, "addons.dataRequirements");
    const implementations = {};
    for (const key of ["participant", "refinement", "predicate", "sourcePredicate", "aggregation", "evidence", "expansion", "dictionary", "analyzer"]) {
      if (!has(data2, key))
        continue;
      let methods = key === "participant" ? ["initialize", "prepare"] : key === "refinement" ? ["prepare"] : key === "evidence" ? ["capture", "select", "prepare"] : key === "expansion" ? ["expand"] : key === "analyzer" ? ["transform", "analyze"] : ["capture", "prepare"];
      const attributes = key === "refinement" ? ["kind", "maxTokens"] : key === "sourcePredicate" ? ["kind"] : key === "aggregation" ? ["fieldType"] : key === "expansion" ? ["kind", "maxTokens", "policy"] : key === "analyzer" ? ["kind", "id"] : [];
      const handles = object4(data2[key], `addons.${key}`, [...methods, ...attributes]);
      if (key === "analyzer") {
        methods = handles.kind === "single-token-transform" ? ["transform"] : handles.kind === "identifier-tokenizer" ? ["analyze"] : [];
        if (!methods.length)
          invalid(code, "addons.analyzer");
        keysOnly(handles, [...methods, ...attributes], code, "addons.analyzer");
      }
      for (const method of methods) {
        const callback = handles[method];
        if (typeof callback !== "function")
          invalid(code, `addons.${key}`);
        handles[method] = callback.bind(data2[key]);
      }
      if (key === "refinement" && (handles.kind !== "exact-token-sequence" && handles.kind !== "ordered-token-groups" || integer5(handles.maxTokens, "addons.maxTokens", 1) > DEFAULT_LIMITS.maxQueryTokens))
        invalid(code, "addons.refinement");
      if (key === "sourcePredicate" && handles.kind !== "source-substring")
        invalid(code, "addons.sourcePredicate");
      if (key === "expansion") {
        if (handles.kind !== "weighted-token-alternatives" || integer5(handles.maxTokens, "addons.maxTokens", 1) > DEFAULT_LIMITS.maxQueryTokens)
          invalid(code, "addons.expansion");
        handles.policy = id(handles.policy, "addons.expansion.policy");
      }
      if (key === "analyzer") {
        handles.id = id(handles.id, "addons.analyzer.id");
        if (handles.id === "basic-v1")
          invalid(code, "addons.analyzer.id");
        if (handles.kind === "identifier-tokenizer" !== (handles.id === "code-identifiers-v1"))
          invalid(code, "addons.analyzer.id");
      }
      if (key === "aggregation" && (handles.fieldType !== "string" || fields2.some((field) => schema2.metadata[field]?.type !== handles.fieldType)))
        invalid(code, "addons.aggregation");
      implementations[key] = Object.freeze(handles);
    }
    let codec;
    if (has(raw, "codec")) {
      const value = object4(raw.codec, "addons.codec", ["id", "version"]);
      codec = Object.freeze({ id: id(value.id, "addons.codec"), version: integer5(value.version, "addons.codec", 1) });
    }
    const manifest = Object.freeze({
      id: name2,
      version,
      contractVersion: 1,
      roles: Object.freeze(roles),
      provides: references(raw.provides, "addons.provides"),
      requires: references(raw.requires, "addons.requires"),
      dataRequirements: Object.freeze({ fields: Object.freeze(fields2.sort()), source: flag(requirements.source, "addons.source"), positions: flag(requirements.positions, "addons.positions"), offsets: flag(requirements.offsets, "addons.offsets"), metadata: metadata2 }),
      indexEffect: participantRole ? "transactional" : analyzerRole ? "analysis" : "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: execution.worker, ...workerRegistration ? { workerRegistration } : {} }),
      limits: ownedLimits,
      costs: Object.freeze({ importedCode: string(costs.importedCode, "addons.costs", 1024), retainedRepresentation: string(costs.retainedRepresentation, "addons.costs", 1024), transientWork: string(costs.transientWork, "addons.costs", 1024), externalResources: "none" }),
      ...codec ? { codec } : {}
    });
    const captured = Object.freeze({ manifest, ...implementations });
    if (captured.analyzer && (manifest.provides.length !== 1 || manifest.provides[0].id !== `analyzer:${captured.analyzer.id}` || manifest.requires.length !== 0))
      invalid(code, "addons.analyzer");
    captureBulkParticipant(entry, captured);
    registrations.set(name2, captured);
    if (!manifest.provides.length)
      invalid(code, "addons.provides");
    for (const provided of manifest.provides) {
      if (has(providers, provided.id))
        invalid(code, "addons.providers");
      providers[provided.id] = captured;
    }
  }
  const ordered = [], visited = /* @__PURE__ */ new Set(), active = /* @__PURE__ */ new Set();
  function visit(registration) {
    const { manifest } = registration;
    if (visited.has(manifest.id))
      return;
    if (active.has(manifest.id))
      invalid(code, "addons.cycle");
    active.add(manifest.id);
    for (const requirement of [...manifest.requires].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0)) {
      const provider = providers[requirement.id];
      if (!provider)
        invalid("MISSING_CAPABILITY", "addons.requires");
      visit(provider);
    }
    const data2 = manifest.dataRequirements;
    if (registration.refinement?.kind === "ordered-token-groups") {
      if (!data2.positions || data2.source || data2.offsets || data2.metadata || !data2.fields.length || registration.participant || manifest.codec || manifest.requires.some((ref) => !data2.fields.some((field) => ref.id === `positions:${field}`)))
        invalid(code, "addons.ordered.data");
      for (const field of data2.fields)
        if (!manifest.requires.some((ref) => ref.id === `positions:${field}`) || !providers[`positions:${field}`]?.participant)
          invalid("MISSING_CAPABILITY", "addons.ordered.positions");
    }
    if ((data2.source || data2.positions) && registration.refinement)
      for (const field of data2.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field}`) && !!providers[`${kind}:${field}`]?.participant;
        if (!(data2.source && present("source") || data2.positions && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    if (registration.sourcePredicate) {
      if (manifest.requires.some((ref) => !data2.fields.some((field) => ref.id === `source:${field}`)))
        invalid("INCOMPATIBLE_CAPABILITY", "addons.sourcePredicate.requires");
      for (const field of data2.fields) {
        if (!manifest.requires.some((ref) => ref.id === `source:${field}`) || !providers[`source:${field}`]?.participant)
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    }
    if (registration.evidence && (data2.source || data2.positions || data2.offsets))
      for (const field of data2.fields) {
        const present = (kind) => manifest.requires.some((ref) => ref.id === `${kind}:${field}`) && !!providers[`${kind}:${field}`]?.participant;
        if (!(data2.source && present("source") || data2.offsets && present("offsets") || data2.positions && !data2.offsets && present("positions")))
          invalid("MISSING_CAPABILITY", "addons.data");
      }
    active.delete(manifest.id);
    visited.add(manifest.id);
    ordered.push(registration);
  }
  for (const name2 of [...registrations.keys()].sort())
    visit(registrations.get(name2));
  return Object.freeze({ ordered: Object.freeze(ordered), providers: Object.freeze(providers) });
}

// node_modules/@vmitsaras/raveldex/dist/core/contracts/schema.js
function captureSchema(input, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const schema2 = ownObject(input, "INVALID_SCHEMA", "schema", admission);
  keysOnly(schema2, ["text", "metadata"], "INVALID_SCHEMA", "schema");
  const text2 = ownObject(schema2.text, "INVALID_SCHEMA", "schema.text", admission);
  const metadata2 = has(schema2, "metadata") ? ownObject(schema2.metadata, "INVALID_SCHEMA", "schema.metadata", admission) : /* @__PURE__ */ Object.create(null);
  const textNames = Object.keys(text2);
  const metadataNames = Object.keys(metadata2);
  if (textNames.length === 0)
    invalid("INVALID_SCHEMA", "schema.text");
  bound(textNames.length, limits.maxTextFields, "schema.text");
  bound(metadataNames.length, limits.maxMetadataFields, "schema.metadata");
  const ownedText = /* @__PURE__ */ Object.create(null);
  const ownedMetadata = /* @__PURE__ */ Object.create(null);
  for (const [group, names] of [[text2, textNames], [metadata2, metadataNames]]) {
    for (const name2 of names) {
      if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(name2) || name2 === "constructor" || name2 === "prototype")
        invalid("INVALID_SCHEMA", "schema.fields");
      bound(name2.length, limits.maxFieldNameCodeUnits, "schema.fields");
      if (has(text2, name2) && has(metadata2, name2))
        invalid("INVALID_SCHEMA", "schema.fields");
      const path = `schema.${group === text2 ? "text" : "metadata"}.${name2}`;
      const field = ownObject(group[name2], "INVALID_SCHEMA", path, admission);
      if (group === text2) {
        keysOnly(field, ["boost"], "INVALID_SCHEMA", path);
        const boost = has(field, "boost") ? field.boost : 1;
        if (typeof boost !== "number" || !Number.isFinite(boost) || boost <= 0 || boost > 16)
          invalid("INVALID_SCHEMA", `${path}.boost`);
        ownedText[name2] = Object.freeze({ boost });
      } else {
        keysOnly(field, ["type", "multi", "nullable"], "INVALID_SCHEMA", path);
        if (field.type !== "string" && field.type !== "number" && field.type !== "boolean")
          invalid("INVALID_SCHEMA", `${path}.type`);
        const multi = has(field, "multi") ? field.multi : false;
        const nullable = has(field, "nullable") ? field.nullable : false;
        if (typeof multi !== "boolean" || typeof nullable !== "boolean")
          invalid("INVALID_SCHEMA", path);
        ownedMetadata[name2] = Object.freeze({ type: field.type, multi, nullable });
      }
    }
  }
  return Object.freeze({ text: Object.freeze(ownedText), metadata: Object.freeze(ownedMetadata) });
}
function captureConfiguration(input) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const config = ownObject(input, "INVALID_OPTIONS", "config", admission);
  keysOnly(config, ["schema", "limits", "analyzer", "addons"], "INVALID_OPTIONS", "config");
  if (has(config, "limits") && config.limits === void 0)
    invalid("INVALID_OPTIONS", "config.limits");
  const limits = has(config, "limits") ? resolveLimits(config.limits, admission) : DEFAULT_LIMITS;
  const schema2 = captureSchema(config.schema, limits, admission);
  let selected = BASIC_ANALYZER.id;
  if (has(config, "analyzer")) {
    const analyzer = ownObject(config.analyzer, "INVALID_OPTIONS", "config.analyzer", admission);
    keysOnly(analyzer, ["id", "environmentProfile"], "INVALID_OPTIONS", "config.analyzer");
    if (typeof analyzer.id !== "string" || typeof analyzer.environmentProfile !== "string")
      invalid("INVALID_OPTIONS", "config.analyzer");
    if (!/^[A-Za-z][A-Za-z0-9:._-]{0,127}$/.test(analyzer.id))
      invalid("INVALID_OPTIONS", "config.analyzer");
    selected = analyzer.id;
    if (analyzer.environmentProfile !== BASIC_ANALYZER.environmentProfile)
      invalid("INCOMPATIBLE_CAPABILITY", "config.analyzer");
  }
  const capabilities = has(config, "addons") ? captureRegistrations(config.addons, { schema: schema2, limits, admission }) : void 0;
  const provider = capabilities?.providers[`analyzer:${selected}`];
  if (selected !== BASIC_ANALYZER.id && (!provider?.analyzer || provider.analyzer.id !== selected))
    invalid("MISSING_CAPABILITY", "config.analyzer");
  bound(admission.count, limits.maxAdmissionEntries, "config");
  return Object.freeze({ schema: schema2, limits, analyzer: selected === BASIC_ANALYZER.id ? BASIC_ANALYZER : Object.freeze({ id: selected, environmentProfile: "unqualified" }), ...capabilities?.ordered.length ? { capabilities } : {} });
}

// node_modules/@vmitsaras/raveldex/dist/core/capabilities/participants.js
function initializeParticipants(configuration) {
  const states = /* @__PURE__ */ Object.create(null);
  const participants = [];
  for (const registration of configuration.capabilities?.ordered ?? []) {
    const handle = registration.participant;
    if (!handle)
      continue;
    const id = registration.manifest.id;
    states[id] = handle.initialize(configuration);
    participants.push(Object.freeze({ id, maxWorkUnits: Math.min(registration.manifest.limits.maxWorkUnits, configuration.limits.maxMutationWorkUnits), *prepare(previous, context) {
      const removedIds = [];
      for (const change of context.changes)
        if (change.previous && !change.next) {
          yield { workUnits: change.previous.id.length + 1 };
          removedIds.push(change.previous.id);
        }
      const request = Object.freeze({ ...context.analyze ? { analyze: context.analyze } : {}, kind: context.kind, previousRevision: context.previous.revision, revision: context.core.revision, analyzer: configuration.analyzer, records: context.records, removedIds: Object.freeze(removedIds) });
      const cursor = handle.prepare(previous, request);
      try {
        for (; ; ) {
          const step = cursor.next();
          if (step.done)
            return step.value;
          yield step.value;
        }
      } finally {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    } }));
  }
  return Object.freeze({ states: Object.freeze(states), participants: Object.freeze(participants) });
}

// node_modules/@vmitsaras/raveldex/dist/core/index/directory.js
var DIRECTORY_SLOTS = 256;
function bucketOf(key) {
  let hash = 2166136261;
  for (let i = 0; i < key.length; i++)
    hash = Math.imul(hash ^ key.charCodeAt(i), 16777619);
  return String((hash >>> 0) % DIRECTORY_SLOTS);
}
function directoryGet(directory2, key) {
  return directory2.buckets[bucketOf(key)]?.[key];
}
function* directoryEntries(directory2) {
  for (const bucket of Object.values(directory2.buckets)) {
    for (const key of Object.keys(bucket))
      yield [key, bucket[key]];
  }
}

// node_modules/@vmitsaras/raveldex/dist/core/index/staging.js
function emptyDirectory() {
  return Object.freeze({ size: 0, buckets: Object.freeze(/* @__PURE__ */ Object.create(null)) });
}
var DirectoryStage = class {
  original;
  charge;
  counts;
  pointers;
  touched = /* @__PURE__ */ new Map();
  count;
  sealed = false;
  constructor(original, charge9, counts) {
    this.original = original;
    this.charge = charge9;
    this.counts = counts;
    this.count = original.size;
  }
  get size() {
    return this.count;
  }
  get(key) {
    return (this.pointers ?? this.original.buckets)[bucketOf(key)]?.[key];
  }
  *bucket(slot) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    if (!this.pointers) {
      const pointers = /* @__PURE__ */ Object.create(null);
      if (this.counts)
        this.counts.directories++;
      for (const slot2 of Object.keys(this.original.buckets)) {
        yield this.charge(1);
        pointers[slot2] = this.original.buckets[slot2];
        if (this.counts)
          this.counts.directoryPointers++;
      }
      this.pointers = pointers;
    }
    const cached = this.touched.get(slot);
    if (cached)
      return cached;
    const bucket = /* @__PURE__ */ Object.create(null);
    if (this.counts)
      this.counts.buckets++;
    const previous = this.original.buckets[slot];
    for (const entry of Object.keys(previous ?? {})) {
      yield this.charge(entry.length + 1);
      bucket[entry] = previous[entry];
      if (this.counts)
        this.counts.bucketEntries++;
    }
    this.touched.set(slot, bucket);
    this.pointers[slot] = bucket;
    return bucket;
  }
  *set(key, value) {
    yield this.charge(key.length + 1);
    const bucket = yield* this.bucket(bucketOf(key));
    if (!Object.hasOwn(bucket, key)) {
      this.count++;
      if (this.counts)
        this.counts.insertions++;
    }
    bucket[key] = value;
    if (this.counts)
      this.counts.writes++;
  }
  *delete(key) {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    yield this.charge(key.length + 1);
    const slot = bucketOf(key);
    if ((this.pointers ?? this.original.buckets)[slot]?.[key] === void 0)
      return;
    const bucket = yield* this.bucket(slot);
    delete bucket[key];
    this.count--;
    if (this.counts)
      this.counts.deletes++;
  }
  *finish() {
    if (this.sealed)
      invalid("INTERNAL_ERROR", "staging.sealed");
    this.sealed = true;
    if (!this.pointers)
      return this.original;
    for (const [slot, bucket] of this.touched) {
      const keys = Object.keys(bucket);
      for (const key of keys)
        yield this.charge(key.length + 1);
      if (keys.length)
        Object.freeze(bucket);
      else
        delete this.pointers[slot];
    }
    for (const slot of Object.keys(this.pointers)) {
      void slot;
      yield this.charge(1);
    }
    return Object.freeze({ size: this.count, buckets: Object.freeze(this.pointers) });
  }
};

// node_modules/@vmitsaras/raveldex/dist/core/limits/work.js
var WorkBudget = class {
  maximum;
  policy = "work-v1";
  used = 0;
  constructor(maximum) {
    this.maximum = maximum;
  }
  get consumed() {
    return this.used;
  }
  charge(units) {
    if (!Number.isSafeInteger(units) || units < 0)
      invalid("INTERNAL_ERROR", "work.units");
    this.used += units;
    if (!Number.isSafeInteger(this.used) || this.used > this.maximum)
      invalid("WORK_LIMIT_EXCEEDED", "work");
  }
};
function validateExpansionCounts(perGroup, wholeQuery, limits) {
  for (const count5 of [perGroup, wholeQuery])
    if (!Number.isSafeInteger(count5) || count5 < 0)
      invalid("INTERNAL_ERROR", "expansions");
  bound(perGroup, limits.maxExpansionsPerGroup, "expansions.group");
  bound(wholeQuery, limits.maxQueryExpansions, "expansions.query");
}

// node_modules/@vmitsaras/raveldex/dist/core/analyzer/identifier.js
function* runIdentifierAnalysis(handle, budget, value, valueIndex, limits, code, mode, check2) {
  bound(value.length, limits.maxTextCodeUnitsPerValue, "analysis.value");
  const charge9 = (workUnits) => {
    check2?.();
    budget.charge(workUnits);
    return { workUnits };
  };
  for (const step of scanUnicode(value, code, "analysis.value"))
    yield charge9(step.workUnits);
  const cursor = handle.analyze(value, valueIndex, limits, code, mode);
  let original, position = 0, previousEnd = 0, componentEnd = 0, occurrences = 0;
  const terms = /* @__PURE__ */ new Set();
  const data2 = (input, keys) => {
    if (typeof input !== "object" || input === null || Array.isArray(input) || ![Object.prototype, null].includes(Object.getPrototypeOf(input)))
      invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
    const names = Reflect.ownKeys(input);
    if (names.length > keys.length)
      invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
    const result = /* @__PURE__ */ Object.create(null);
    for (const key of names) {
      if (typeof key !== "string" || !keys.includes(key))
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
      const property = Object.getOwnPropertyDescriptor(input, key);
      if (!property || !("value" in property))
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
      result[key] = property.value;
    }
    return result;
  };
  const boundary = (offset) => Number.isSafeInteger(offset) && offset >= 0 && offset <= value.length && !(offset > 0 && offset < value.length && value.charCodeAt(offset) >= 56320 && value.charCodeAt(offset) <= 57343);
  try {
    for (; ; ) {
      const next = cursor.next();
      check2?.();
      if (next.done)
        break;
      const step = data2(next.value, ["workUnits", "token"]);
      if (!Number.isSafeInteger(step.workUnits) || step.workUnits < 1)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.work");
      yield charge9(step.workUnits);
      if (!Object.hasOwn(step, "token"))
        continue;
      const owned = data2(step.token, ["term", "valueIndex", "position", "start", "end", "kind", "original"]);
      if (Object.hasOwn(owned, "original"))
        owned.original = Object.freeze(data2(owned.original, ["term", "start", "end"]));
      const token = Object.freeze(owned);
      if (token.valueIndex !== valueIndex || !boundary(token.start) || !boundary(token.end) || token.end <= token.start || token.kind !== "original" && token.kind !== "component" || typeof token.term !== "string" || !token.term.length)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.token");
      bound(token.end - token.start, limits.maxRawTokenCodeUnits, "analysis.rawToken");
      bound(token.term.length, limits.maxTermCodeUnits, "analysis.term");
      bound(++occurrences, limits.maxTokensPerRecord, "analysis.tokens");
      for (const scan of scanUnicode(token.term, "INCOMPATIBLE_CAPABILITY", "analysis.term"))
        yield charge9(scan.workUnits);
      yield charge9(token.end - token.start + token.term.length + 1);
      if (value.slice(token.start, token.end).normalize("NFKC").toLowerCase() !== token.term)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.term");
      if (token.kind === "original") {
        if (token.original !== void 0 || token.position !== position++ || token.start < previousEnd)
          invalid("INCOMPATIBLE_CAPABILITY", "analysis.original");
        previousEnd = token.end;
        componentEnd = token.start;
        original = token;
        terms.clear();
        terms.add(token.term);
      } else {
        const origin = token.original;
        if (mode !== "index" || !original || !origin || !Object.isFrozen(origin) || Object.keys(origin).length !== 3 || !Object.keys(origin).every((key) => ["term", "start", "end"].includes(key)) || origin.term !== original.term || origin.start !== original.start || origin.end !== original.end || token.position !== original.position || token.start < componentEnd || token.end > original.end || terms.has(token.term))
          invalid("INCOMPATIBLE_CAPABILITY", "analysis.component");
        componentEnd = token.end;
        terms.add(token.term);
      }
      yield charge9(1);
      yield { workUnits: 1, token };
    }
  } finally {
    try {
      cursor.return(void 0);
    } catch {
    }
  }
}

// node_modules/@vmitsaras/raveldex/dist/core/analyzer/selected.js
function createAnalysis(configuration, check2) {
  if (configuration.analyzer.id === BASIC_ANALYZER.id)
    return analyzeValue;
  const registration = configuration.capabilities?.providers[`analyzer:${configuration.analyzer.id}`];
  if (!registration?.analyzer || registration.analyzer.id !== configuration.analyzer.id)
    invalid("MISSING_CAPABILITY", "analysis.analyzer");
  const handle = registration.analyzer, budget = new WorkBudget(registration.manifest.limits.maxWorkUnits);
  if (handle.kind === "identifier-tokenizer")
    return (value, valueIndex, limits, code = "INVALID_RECORD", mode = "index") => runIdentifierAnalysis(handle, budget, value, valueIndex, limits, code, mode, check2);
  return function* (value, valueIndex, limits, code = "INVALID_RECORD") {
    for (const step of analyzeValue(value, valueIndex, limits, code)) {
      if (!step.token) {
        yield step;
        continue;
      }
      yield { workUnits: step.workUnits };
      const cursor = handle.transform(step.token.term);
      let term;
      try {
        for (; ; ) {
          const transformed = cursor.next();
          check2?.();
          if (transformed.done) {
            term = transformed.value;
            break;
          }
          budget.charge(transformed.value.workUnits);
          yield transformed.value;
        }
      } finally {
        try {
          cursor.return("");
        } catch {
        }
      }
      if (typeof term !== "string" || !term.length)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.term");
      bound(term.length, limits.maxTermCodeUnits, "analysis.term");
      for (const scan of scanUnicode(term, "INCOMPATIBLE_CAPABILITY", "analysis.term")) {
        budget.charge(scan.workUnits);
        yield scan;
      }
      const units = term.length * 2 + 1;
      budget.charge(units);
      yield { workUnits: units };
      if (term.normalize("NFKC").toLowerCase() !== term)
        invalid("INCOMPATIBLE_CAPABILITY", "analysis.term");
      yield { workUnits: 1, token: Object.freeze({ ...step.token, term }) };
    }
  };
}
function requireAnalysis(context) {
  if (context.analyze)
    return context.analyze;
  if (context.analyzer.id === BASIC_ANALYZER.id)
    return analyzeValue;
  return invalid("INCOMPATIBLE_CAPABILITY", "analysis.context");
}

// node_modules/@vmitsaras/raveldex/dist/core/contracts/record.js
function captureId(input, limits, code, path) {
  const id = stringValue(input, limits.maxIdCodeUnits, code, path);
  if (!id.length)
    invalid(code, path);
  return id;
}
function captureScalar(input, field, limits, code, path) {
  if (input === null && field.nullable)
    return null;
  if (typeof input !== field.type)
    invalid(code, path);
  if (typeof input === "number") {
    if (!Number.isFinite(input))
      invalid(code, path);
    return input === 0 ? 0 : input;
  }
  if (typeof input === "string")
    return stringValue(input, limits.maxMetadataStringCodeUnits, code, path);
  if (typeof input === "boolean")
    return input;
  return invalid(code, path);
}
function captureRecord(input, schema2, limits, admission = new Admission(limits.maxAdmissionEntries), path = "record") {
  const record = ownObject(input, "INVALID_RECORD", path, admission);
  keysOnly(record, ["id", "text", "metadata"], "INVALID_RECORD", path);
  const id = captureId(record.id, limits, "INVALID_RECORD", `${path}.id`);
  const textInput = ownObject(record.text, "INVALID_RECORD", `${path}.text`, admission);
  const metadataInput = has(record, "metadata") ? ownObject(record.metadata, "INVALID_RECORD", `${path}.metadata`, admission) : /* @__PURE__ */ Object.create(null);
  const text2 = /* @__PURE__ */ Object.create(null);
  const metadata2 = /* @__PURE__ */ Object.create(null);
  let textCodeUnits = 0;
  let metadataCodeUnits = 0;
  for (const name2 of Object.keys(textInput)) {
    if (!has(schema2.text, name2))
      invalid("INVALID_RECORD", `${path}.text`);
    const fieldPath = `${path}.text.${name2}`;
    const raw = textInput[name2];
    const values = typeof raw === "string" ? [raw] : ownArray(raw, limits.maxTextValuesPerField, "INVALID_RECORD", fieldPath, admission);
    text2[name2] = Object.freeze(values.map((value, i) => {
      const string = stringValue(value, limits.maxTextCodeUnitsPerValue, "INVALID_RECORD", `${fieldPath}[${i}]`);
      textCodeUnits += string.length;
      bound(textCodeUnits, limits.maxTextCodeUnitsPerRecord, `${path}.text`);
      return string;
    }));
  }
  for (const name2 of Object.keys(metadataInput)) {
    const field = schema2.metadata[name2];
    if (!field)
      invalid("INVALID_RECORD", `${path}.metadata`);
    const fieldPath = `${path}.metadata.${name2}`;
    const value = metadataInput[name2];
    const values = field.multi ? ownArray(value, limits.maxMetadataValuesPerField, "INVALID_RECORD", fieldPath, admission) : [value];
    const owned = values.map((item, i) => {
      const scalar = captureScalar(item, field, limits, "INVALID_RECORD", `${fieldPath}[${i}]`);
      if (typeof scalar === "string")
        metadataCodeUnits += scalar.length;
      bound(metadataCodeUnits, limits.maxMetadataCodeUnitsPerRecord, `${path}.metadata`);
      return scalar;
    });
    metadata2[name2] = field.multi ? Object.freeze(owned) : owned[0];
  }
  return Object.freeze({ id, text: Object.freeze(text2), metadata: Object.freeze(metadata2), textCodeUnits });
}
function captureBatch(input, schema2, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const values = ownArray(input, limits.maxMutationBatch, "INVALID_RECORD", "records", admission);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const record = captureRecord(value, schema2, limits, admission, `records[${i}]`);
    if (ids.has(record.id))
      invalid("INVALID_RECORD", `records[${i}].id`);
    ids.add(record.id);
    return record;
  }));
}
function captureRemoveIds(input, limits, admission = new Admission(limits.maxAdmissionEntries)) {
  const values = typeof input === "string" ? [input] : ownArray(input, limits.maxMutationBatch, "INVALID_OPTIONS", "ids", admission);
  const ids = /* @__PURE__ */ new Set();
  return Object.freeze(values.map((value, i) => {
    const id = captureId(value, limits, "INVALID_OPTIONS", `ids[${i}]`);
    if (ids.has(id))
      invalid("INVALID_OPTIONS", `ids[${i}]`);
    ids.add(id);
    return id;
  }));
}
function* analyzeRecord(record, limits, counts, analyze = analyzeValue) {
  if (counts)
    counts.records++;
  yield* scanUnicode(record.id, "INVALID_RECORD", "record.id");
  for (const [field, value] of Object.entries(record.metadata)) {
    for (const item of Array.isArray(value) ? value : [value]) {
      if (typeof item === "string")
        yield* scanUnicode(item, "INVALID_RECORD", `record.metadata.${field}`);
    }
  }
  let tokens = 0;
  for (const [field, values] of Object.entries(record.text)) {
    for (let i = 0; i < values.length; i++) {
      if (counts) {
        counts.values++;
        counts.textCodeUnits += values[i].length;
      }
      for (const step of analyze(values[i], i, limits)) {
        if (step.token) {
          bound(++tokens, limits.maxTokensPerRecord, "record.tokens");
          yield { ...step, field };
        } else
          yield step;
      }
    }
  }
}
function canonicalMetadata(record) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const [name2, value] of Object.entries(record.metadata)) {
    result[name2] = Array.isArray(value) ? Object.freeze([...new Set(value)]) : value;
  }
  return Object.freeze(result);
}

// node_modules/@vmitsaras/raveldex/dist/core/capabilities/capture.js
function captureExtension(capture, input, admission, limits, maximum) {
  const maxCodeUnits = Math.min(maximum, limits.maxQueryCodeUnits);
  const captured = capture(input, Object.freeze({ admission, limits, maxCodeUnits }));
  if (!captured || !Number.isSafeInteger(captured.codeUnits) || captured.codeUnits < 0 || captured.value !== null && typeof captured.value === "object" && !Object.isFrozen(captured.value))
    invalid("INCOMPATIBLE_CAPABILITY", "extensions.capture");
  bound(captured.codeUnits, maxCodeUnits, "extensions.payload");
  return captured;
}

// node_modules/@vmitsaras/raveldex/dist/core/contracts/options.js
function integer(value, minimum, maximum, path) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
    invalid("INVALID_OPTIONS", path);
  bound(value, maximum, path);
  return value;
}
function captureOptions(input = {}, limits, search, admission = new Admission(limits.maxAdmissionEntries), capabilities) {
  const data2 = ownObject(input, "INVALID_OPTIONS", "options", admission);
  keysOnly(data2, search ? ["signal", "deadlineMs", "limit", "offset", "extensions"] : ["signal", "deadlineMs"], "INVALID_OPTIONS", "options");
  const deadlineMs = has(data2, "deadlineMs") ? integer(data2.deadlineMs, 1, limits.maxDeadlineMs, "options.deadlineMs") : Math.min(3e4, limits.maxDeadlineMs);
  let signal;
  if (has(data2, "signal")) {
    const candidate = data2.signal;
    if (typeof candidate !== "object" || candidate === null || typeof candidate.aborted !== "boolean" || typeof candidate.addEventListener !== "function" || typeof candidate.removeEventListener !== "function")
      invalid("INVALID_OPTIONS", "options.signal");
    signal = candidate;
  }
  const base = { deadlineMs, ...signal ? { signal } : {} };
  if (!search)
    return Object.freeze(base);
  const offset = has(data2, "offset") ? integer(data2.offset, 0, limits.maxDocuments, "options.offset") : 0;
  const limit = has(data2, "limit") ? integer(data2.limit, 0, limits.maxHits, "options.limit") : Math.min(20, limits.maxHits, limits.maxDocuments - offset);
  bound(offset + limit, limits.maxDocuments, "options.page");
  let extensions;
  if (has(data2, "extensions")) {
    const captured = ownObject(data2.extensions, "INVALID_OPTIONS", "options.extensions", admission);
    let units = 0;
    for (const capability of Object.keys(captured)) {
      const registration = capabilities?.providers[capability];
      const handler = registration?.evidence ?? registration?.aggregation ?? registration?.dictionary;
      if (!registration || !handler)
        invalid("MISSING_CAPABILITY", "options.extensions");
      const payload = captureExtension(handler.capture, captured[capability], admission, limits, registration.manifest.limits.maxPayloadCodeUnits);
      units += capability.length + payload.codeUnits;
      bound(units, limits.maxQueryCodeUnits, "options.extensions");
      captured[capability] = payload.value;
    }
    if (Object.keys(captured).length)
      extensions = Object.freeze(captured);
  }
  return Object.freeze({ ...base, offset, limit, ...extensions ? { extensions } : {} });
}

// node_modules/@vmitsaras/raveldex/dist/core/mutations/capture.js
function captureMutation(configuration, kind, input, options) {
  const { schema: schema2, limits } = configuration, admission = new Admission(limits.maxAdmissionEntries);
  const capturedOptions = captureOptions(options, limits, false, admission);
  if (capturedOptions.signal?.aborted)
    invalid("CANCELLED", "options.signal");
  let records = [], ids = [];
  switch (kind) {
    case "add":
    case "replace":
      records = Object.freeze([captureRecord(input, schema2, limits, admission)]);
      break;
    case "addMany":
      records = captureBatch(input, schema2, limits, admission);
      break;
    case "remove":
      ids = captureRemoveIds(input, limits, admission);
      break;
    case "clear":
      if (input !== void 0)
        invalid("INVALID_OPTIONS", "clear");
      break;
    default:
      invalid("INVALID_OPTIONS", "mutation.kind");
  }
  return Object.freeze({ kind, records: Object.freeze(records), ids: Object.freeze(ids), options: capturedOptions });
}

// node_modules/@vmitsaras/raveldex/dist/core/query/work.js
function* compareStrings(a, b, charge9) {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    yield charge9(1);
    const difference = a.charCodeAt(i) - b.charCodeAt(i);
    if (difference)
      return difference;
  }
  yield charge9(1);
  return a.length - b.length;
}
function* sortedStrings(input, charge9) {
  const output = [];
  for (const value of input) {
    yield charge9(value.length + 1);
    let i = output.length;
    while (i > 0 && (yield* compareStrings(value, output[i - 1], charge9)) < 0) {
      yield charge9(1);
      output[i] = output[i - 1];
      i--;
    }
    output[i] = value;
  }
  return output;
}

// node_modules/@vmitsaras/raveldex/dist/core/index/term-order.js
var height = (node2) => node2?.height ?? 0;
function* node(key, left, right, charge9) {
  yield charge9(1);
  return Object.freeze({ key, height: 1 + Math.max(height(left), height(right)), left, right });
}
function* balanced(key, left, right, charge9) {
  if (height(left) - height(right) > 1) {
    const l = left;
    if (height(l.left) >= height(l.right))
      return yield* node(l.key, l.left, yield* node(key, l.right, right, charge9), charge9);
    const middle = l.right;
    return yield* node(middle.key, yield* node(l.key, l.left, middle.left, charge9), yield* node(key, middle.right, right, charge9), charge9);
  }
  if (height(right) - height(left) > 1) {
    const r = right;
    if (height(r.right) >= height(r.left))
      return yield* node(r.key, yield* node(key, left, r.left, charge9), r.right, charge9);
    const middle = r.left;
    return yield* node(middle.key, yield* node(key, left, middle.left, charge9), yield* node(r.key, middle.right, r.right, charge9), charge9);
  }
  return yield* node(key, left, right, charge9);
}
function* updateTermOrder(root, key, present, charge9) {
  if (!root)
    return present ? yield* node(key, null, null, charge9) : null;
  const comparison = yield* compareStrings(key, root.key, charge9);
  if (!comparison) {
    if (present)
      return root;
    if (!root.left)
      return root.right;
    if (!root.right)
      return root.left;
    let next = root.right;
    while (next.left) {
      yield charge9(1);
      next = next.left;
    }
    return yield* balanced(next.key, root.left, yield* updateTermOrder(root.right, next.key, false, charge9), charge9);
  }
  if (comparison < 0) {
    const left = yield* updateTermOrder(root.left, key, present, charge9);
    return left === root.left ? root : yield* balanced(root.key, left, root.right, charge9);
  }
  const right = yield* updateTermOrder(root.right, key, present, charge9);
  return right === root.right ? root : yield* balanced(root.key, root.left, right, charge9);
}
function* prefixTerms(root, prefix2, headroom, charge9, checkpoint) {
  const stack = [], keys = [];
  let current = root;
  while (current) {
    checkpoint?.();
    yield charge9(1);
    if ((yield* compareStrings(current.key, prefix2, charge9)) >= 0) {
      stack.push(current);
      current = current.left;
    } else
      current = current.right;
  }
  while (stack.length) {
    const next = stack.pop();
    checkpoint?.();
    yield charge9(1);
    let matches = next.key.length >= prefix2.length;
    for (let i = 0; matches && i < prefix2.length; i++) {
      yield charge9(1);
      matches = next.key.charCodeAt(i) === prefix2.charCodeAt(i);
    }
    if (!matches)
      break;
    keys.push(next.key);
    if (keys.length > headroom)
      return { keys, overflow: true };
    current = next.right;
    while (current) {
      checkpoint?.();
      yield charge9(1);
      stack.push(current);
      current = current.left;
    }
  }
  return { keys, overflow: false };
}

// node_modules/@vmitsaras/raveldex/dist/core/mutations/delta.js
function nonnegative(value, path) {
  if (!Number.isSafeInteger(value) || value < 0)
    invalid("INTERNAL_ERROR", path);
}
var CoreDelta = class {
  old;
  charge;
  diagnostics;
  documents;
  fields = /* @__PURE__ */ new Map();
  counts;
  liveDictionaryEntries;
  constructor(old, charge9, diagnostics) {
    this.old = old;
    this.charge = charge9;
    this.diagnostics = diagnostics;
    validateStateCounts(old.counts, old.configuration.limits);
    if (old.documents.size !== old.counts.documents)
      invalid("INTERNAL_ERROR", "state.documents");
    this.counts = { ...old.counts };
    this.liveDictionaryEntries = old.counts.dictionaryEntries;
    this.documents = new DirectoryStage(old.documents, charge9, diagnostics?.documents);
  }
  field(name2) {
    let field = this.fields.get(name2);
    if (!field) {
      const original = this.old.fields[name2];
      if (!original)
        invalid("INTERNAL_ERROR", "reverse.field");
      nonnegative(original.documents, "field.documents");
      nonnegative(original.length, "field.length");
      if (original.documents > this.old.documents.size || original.length < original.documents)
        invalid("INTERNAL_ERROR", "field.statistics");
      field = { documents: original.documents, length: original.length, order: original.order, terms: new DirectoryStage(original.terms, this.charge, this.diagnostics?.dictionary), cache: /* @__PURE__ */ new Map() };
      this.fields.set(name2, field);
    }
    return field;
  }
  term(field, term) {
    let staged = field.cache.get(term);
    if (!staged) {
      const original = field.terms.get(term);
      if (original) {
        nonnegative(original.df, "term.df");
        nonnegative(original.frequency, "term.frequency");
        if (!original.df || original.df !== original.postings.size || original.frequency < original.df)
          invalid("INTERNAL_ERROR", "term.statistics");
      }
      staged = { ...original ? { original } : {}, df: original?.df ?? 0, frequency: original?.frequency ?? 0, postings: new DirectoryStage(original?.postings ?? emptyDirectory(), this.charge, this.diagnostics?.postings) };
      field.cache.set(term, staged);
    }
    return staged;
  }
  *contribute(document, sign) {
    nonnegative(document.textCodeUnits, "reverse.textCodeUnits");
    this.counts.textCodeUnits += sign * document.textCodeUnits;
    for (const [name2, reverse] of Object.entries(document.fields)) {
      yield this.charge(name2.length + 2);
      const field = this.field(name2);
      nonnegative(reverse.length, "reverse.length");
      if (!reverse.length)
        invalid("INTERNAL_ERROR", "reverse.length");
      field.documents += sign;
      field.length += sign * reverse.length;
      this.counts.tokens += sign * reverse.length;
      if (this.diagnostics)
        this.diagnostics.fieldUpdates++;
      let length = 0;
      for (const [key, tf] of Object.entries(reverse.terms)) {
        yield this.charge(key.length + document.id.length + 4);
        nonnegative(tf, "reverse.tf");
        if (!tf)
          invalid("INTERNAL_ERROR", "reverse.tf");
        length += tf;
        const term = this.term(field, key), current = term.postings.get(document.id);
        if (sign < 0) {
          if (current !== tf)
            invalid("INTERNAL_ERROR", "reverse.posting");
          yield* term.postings.delete(document.id);
        } else {
          if (current !== void 0)
            invalid("INTERNAL_ERROR", "posting.duplicate");
          yield* term.postings.set(document.id, tf);
        }
        if (term.df === 0 && sign > 0)
          this.liveDictionaryEntries++;
        term.df += sign;
        term.frequency += sign * tf;
        if (term.df === 0 && sign < 0)
          this.liveDictionaryEntries--;
        this.counts.postingEntries += sign;
        if (this.diagnostics)
          this.diagnostics.termUpdates++;
      }
      if (length !== reverse.length)
        invalid("INTERNAL_ERROR", "reverse.length");
    }
  }
  *apply(delta) {
    if (delta.previous) {
      yield* this.contribute(delta.previous, -1);
      yield* this.documents.delete(delta.previous.id);
      this.counts.documents--;
    }
    if (delta.next) {
      yield* this.contribute(delta.next, 1);
      yield* this.documents.set(delta.next.id, delta.next);
      this.counts.documents++;
    }
  }
  /** Unsealed add-only construction still enforces every live retention cap. */
  hasDocument(id) {
    return this.documents.get(id) !== void 0;
  }
  checkCounts() {
    validateStateCounts({ ...this.counts, dictionaryEntries: this.liveDictionaryEntries }, this.old.configuration.limits);
    if (this.documents.size !== this.counts.documents)
      invalid("INTERNAL_ERROR", "state.documents");
  }
  *finish() {
    const fields2 = /* @__PURE__ */ Object.create(null);
    for (const name2 of Object.keys(this.old.fields)) {
      yield this.charge(1);
      const field = this.fields.get(name2);
      if (!field) {
        fields2[name2] = this.old.fields[name2];
        continue;
      }
      for (const [key, term] of field.cache) {
        yield this.charge(key.length + 3);
        nonnegative(term.df, "term.df");
        nonnegative(term.frequency, "term.frequency");
        if (term.df !== term.postings.size || term.df > field.documents || term.frequency < term.df || term.frequency > field.length || !term.df && term.frequency !== 0)
          invalid("INTERNAL_ERROR", "term.statistics");
        if (!term.df) {
          if (term.original) {
            yield* field.terms.delete(key);
            field.order = yield* updateTermOrder(field.order, key, false, this.charge);
            this.counts.dictionaryEntries--;
          }
        } else {
          const postings = yield* term.postings.finish();
          yield* field.terms.set(key, Object.freeze({ df: term.df, frequency: term.frequency, postings }));
          if (!term.original) {
            field.order = yield* updateTermOrder(field.order, key, true, this.charge);
            this.counts.dictionaryEntries++;
          }
        }
      }
      nonnegative(field.documents, "field.documents");
      nonnegative(field.length, "field.length");
      if (field.documents > this.counts.documents || field.length < field.documents || !field.documents && field.length !== 0)
        invalid("INTERNAL_ERROR", "field.statistics");
      const terms = yield* field.terms.finish();
      if (field.documents === 0 !== (terms.size === 0))
        invalid("INTERNAL_ERROR", "field.terms");
      fields2[name2] = Object.freeze({ documents: field.documents, length: field.length, terms, order: field.order });
    }
    const documents = yield* this.documents.finish();
    yield this.charge(5);
    validateStateCounts(this.counts, this.old.configuration.limits);
    if (this.counts.dictionaryEntries !== this.liveDictionaryEntries)
      invalid("INTERNAL_ERROR", "state.dictionary");
    if (documents.size !== this.counts.documents)
      invalid("INTERNAL_ERROR", "state.documents");
    return { documents, fields: Object.freeze(fields2), counts: Object.freeze(this.counts) };
  }
};
function* clearedCore(old, charge9) {
  const fields2 = /* @__PURE__ */ Object.create(null);
  for (const name2 of Object.keys(old.fields)) {
    yield charge9(1);
    fields2[name2] = Object.freeze({ documents: 0, length: 0, terms: emptyDirectory(), order: null });
  }
  yield charge9(5);
  return { documents: emptyDirectory(), fields: Object.freeze(fields2), counts: Object.freeze({ documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 }) };
}

// node_modules/@vmitsaras/raveldex/dist/core/mutations/document.js
function* prepareDocument(record, limits, charge9, counts, analyze = analyzeValue) {
  for (const values of Object.values(record.text)) {
    yield charge9(1);
    for (let i = 0; i < values.length; i++)
      yield charge9(1);
  }
  const fields2 = /* @__PURE__ */ Object.create(null);
  for (const step of analyzeRecord(record, limits, counts, analyze)) {
    yield charge9(step.workUnits);
    if (step.token) {
      yield charge9(step.token.term.length + 2);
      const field = fields2[step.field] ??= { length: 0, terms: /* @__PURE__ */ Object.create(null) };
      field.length++;
      field.terms[step.token.term] = (field.terms[step.token.term] ?? 0) + 1;
    }
  }
  const frozen = /* @__PURE__ */ Object.create(null);
  for (const [name2, field] of Object.entries(fields2)) {
    for (const term of Object.keys(field.terms))
      yield charge9(term.length + 1);
    yield charge9(1);
    frozen[name2] = Object.freeze({ length: field.length, terms: Object.freeze(field.terms) });
  }
  for (const value of Object.values(record.metadata)) {
    yield charge9(1);
    for (const item of Array.isArray(value) ? value : [value])
      yield charge9(typeof item === "string" ? item.length + 1 : 1);
  }
  const metadata2 = canonicalMetadata(record);
  for (const value of Object.values(metadata2))
    yield charge9(Array.isArray(value) ? value.length + 1 : 1);
  return Object.freeze({ id: record.id, textCodeUnits: record.textCodeUnits, metadata: metadata2, fields: Object.freeze(frozen) });
}

// node_modules/@vmitsaras/raveldex/dist/core/mutations/owner.js
var MutationOwner = class {
  #root;
  #active = false;
  participants;
  admitted = /* @__PURE__ */ new WeakSet();
  constructor(root, participants = []) {
    if (!Number.isSafeInteger(root.revision) || root.revision < 0 || !Object.isFrozen(root))
      invalid("INTERNAL_ERROR", "revision.root");
    const ids = /* @__PURE__ */ new Set();
    for (const participant of participants) {
      if (!participant.id || ids.has(participant.id) || typeof participant.prepare !== "function" || !Object.hasOwn(root.participants, participant.id))
        invalid("INCOMPATIBLE_CAPABILITY", "participants");
      ids.add(participant.id);
    }
    if (Object.keys(root.participants).length !== ids.size)
      invalid("INCOMPATIBLE_CAPABILITY", "participants");
    this.#root = root;
    this.participants = Object.freeze(participants.map((p) => {
      if (p.maxWorkUnits !== void 0 && (!Number.isSafeInteger(p.maxWorkUnits) || p.maxWorkUnits < 1))
        invalid("INCOMPATIBLE_CAPABILITY", "participants.limits");
      return Object.freeze({ id: p.id, prepare: p.prepare.bind(p), ...p.maxWorkUnits !== void 0 ? { maxWorkUnits: p.maxWorkUnits } : {} });
    }));
  }
  get root() {
    return this.#root;
  }
  /** Trusted optional adapter publication after complete bounded preparation.
   * It runs in ExecutionOwner's FIFO, with no callbacks at the commit point. */
  publishPrepared(root, previous) {
    if (this.#active || this.#root !== previous || root.configuration !== previous.configuration || !Object.isFrozen(root) || previous.revision === Number.MAX_SAFE_INTEGER || root.revision !== previous.revision + 1 || Object.keys(root.participants).length !== this.participants.length || this.participants.some((participant) => !Object.hasOwn(root.participants, participant.id)))
      invalid("INTERNAL_ERROR", "adapter.publication");
    this.#root = root;
  }
  capture(kind, input, options) {
    const request = captureMutation(this.#root.configuration, kind, input, options);
    this.admitted.add(request);
    return request;
  }
  mutate(kind, input, options) {
    return this.execute(this.capture(kind, input, options));
  }
  execute(request, control = {}) {
    if (!this.admitted.delete(request))
      invalid("INTERNAL_ERROR", "mutation.admission");
    return this.consume(request, control);
  }
  *consume(request, control) {
    if (this.#active)
      invalid("INTERNAL_ERROR", "mutation.active");
    this.#active = true;
    const old = this.#root, budget = new WorkBudget(old.configuration.limits.maxMutationWorkUnits);
    const analyze = control.analyze ?? createAnalysis(old.configuration, () => check2());
    let phase = "start";
    const check2 = () => {
      control.checkpoint?.(phase);
      if (control.checkStop)
        control.checkStop(phase);
      else if (request.options.signal?.aborted)
        invalid("CANCELLED", "options.signal");
    };
    const charge9 = (workUnits) => {
      check2();
      budget.charge(workUnits);
      if (control.diagnostics)
        control.diagnostics.workUnits = budget.consumed;
      return { workUnits };
    };
    const boundary = (next) => {
      phase = next;
      check2();
    };
    try {
      check2();
      const changes = [];
      let added = 0, replaced = 0, removed = 0;
      boundary("validation");
      if (request.kind === "remove") {
        for (const id of request.ids) {
          for (const step of scanUnicode(id, "INVALID_OPTIONS", "ids"))
            yield charge9(step.workUnits);
          yield charge9(id.length + 1);
          const previous = directoryGet(old.documents, id);
          if (previous) {
            changes.push(Object.freeze({ previous }));
            removed++;
          }
        }
      } else if (request.kind === "clear") {
        removed = old.documents.size;
      } else {
        for (const record of request.records) {
          yield charge9(record.id.length + 1);
          const previous = directoryGet(old.documents, record.id);
          if (request.kind === "replace") {
            if (!previous)
              invalid("ID_NOT_FOUND", "record.id");
          } else if (previous)
            invalid("ID_EXISTS", "record.id");
          boundary("analysis");
          const next = yield* prepareDocument(record, old.configuration.limits, charge9, control.diagnostics?.analysis, analyze);
          changes.push(Object.freeze({ ...previous ? { previous } : {}, next }));
          if (previous)
            replaced++;
          else
            added++;
          boundary("validation");
        }
      }
      const changed = added + replaced + removed > 0;
      if (!changed) {
        const result2 = Object.freeze({ revision: old.revision, changed: false, added, replaced, removed });
        boundary("precommit");
        yield charge9(1);
        check2();
        return result2;
      }
      if (old.revision === Number.MAX_SAFE_INTEGER)
        invalid("REVISION_EXHAUSTED", "revision");
      boundary("staging");
      let coreData;
      if (request.kind === "clear")
        coreData = yield* clearedCore(old, charge9);
      else {
        const delta = new CoreDelta(old, charge9, control.diagnostics?.copies);
        for (const change of changes)
          yield* delta.apply(change);
        boundary("core");
        coreData = yield* delta.finish();
      }
      const core = Object.freeze({ ...coreData, revision: old.revision + 1, configuration: old.configuration, participants: old.participants });
      const context = Object.freeze({ analyze, kind: request.kind, previous: old, core, changes: Object.freeze(changes), records: request.records });
      const participants = /* @__PURE__ */ Object.create(null);
      for (const participant of this.participants) {
        boundary("participant");
        yield charge9(participant.id.length + 1);
        const participantBudget = participant.maxWorkUnits === void 0 ? void 0 : new WorkBudget(participant.maxWorkUnits);
        const iterator = participant.prepare(old.participants[participant.id], context);
        let finished = false;
        try {
          for (; ; ) {
            const step = iterator.next();
            if (step.done) {
              participants[participant.id] = step.value;
              finished = true;
              break;
            }
            const charged = charge9(step.value.workUnits);
            participantBudget?.charge(step.value.workUnits);
            yield charged;
          }
        } finally {
          if (!finished) {
            try {
              iterator.return(void 0);
            } catch {
            }
          }
        }
      }
      boundary("prepared");
      const root = Object.freeze({ ...core, participants: Object.freeze(participants) });
      const result = Object.freeze({ revision: root.revision, changed: true, added, replaced, removed });
      boundary("precommit");
      yield charge9(1);
      check2();
      this.#root = root;
      return result;
    } finally {
      this.#active = false;
    }
  }
};

// node_modules/@vmitsaras/raveldex/dist/core/contracts/query.js
function captureQuery(input, schema2, limits, admission = new Admission(limits.maxAdmissionEntries), capabilities) {
  let nodes = 0;
  let lexicalUnits = 0;
  let stringUnits = 0;
  const ancestors = /* @__PURE__ */ new Set();
  function string(value, lexical, path) {
    const text2 = stringValue(value, limits.maxQueryCodeUnits, "INVALID_QUERY", path);
    stringUnits += text2.length;
    bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
    if (lexical) {
      lexicalUnits += text2.length;
      bound(lexicalUnits, limits.maxQueryLexicalCodeUnits, "query.lexical");
    }
    return text2;
  }
  function fields2(value, path) {
    const names = ownArray(value, limits.maxTextFields, "INVALID_QUERY", path, admission);
    if (!names.length)
      invalid("INVALID_QUERY", path);
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(names.map((name2) => {
      const selected = string(name2, false, path);
      if (!has(schema2.text, selected) || seen.has(selected))
        invalid("INVALID_QUERY", path);
      seen.add(selected);
      return selected;
    }));
  }
  function node2(value, depth, path) {
    bound(++nodes, limits.maxQueryNodes, "query.nodes");
    bound(depth, limits.maxQueryDepth, "query.depth");
    const data2 = ownObject(value, "INVALID_QUERY", path, admission);
    if (ancestors.has(value))
      invalid("INVALID_QUERY", path);
    ancestors.add(value);
    const kind = string(data2.kind, false, `${path}.kind`);
    let result;
    switch (kind) {
      case "text": {
        keysOnly(data2, ["kind", "text", "operator", "fields"], "INVALID_QUERY", path);
        const operator = has(data2, "operator") ? string(data2.operator, false, `${path}.operator`) : "and";
        if (operator !== "and" && operator !== "or")
          invalid("INVALID_QUERY", `${path}.operator`);
        result = {
          kind,
          text: string(data2.text, true, `${path}.text`),
          operator,
          ...has(data2, "fields") ? { fields: fields2(data2.fields, `${path}.fields`) } : {}
        };
        break;
      }
      case "group": {
        keysOnly(data2, ["kind", "variants", "fields"], "INVALID_QUERY", path);
        const variants = ownArray(data2.variants, limits.maxVariantsPerGroup, "INVALID_QUERY", `${path}.variants`, admission);
        if (!variants.length)
          invalid("INVALID_QUERY", `${path}.variants`);
        const owned = variants.map((variant, i) => {
          const variantPath = `${path}.variants[${i}]`;
          const item = ownObject(variant, "INVALID_QUERY", variantPath, admission);
          keysOnly(item, ["text", "match", "weight"], "INVALID_QUERY", variantPath);
          const match = string(item.match, false, `${variantPath}.match`);
          if (match !== "exact" && match !== "prefix")
            invalid("INVALID_QUERY", `${variantPath}.match`);
          const weight = has(item, "weight") ? item.weight : 1;
          if (typeof weight !== "number" || !Number.isFinite(weight) || weight <= 0 || weight > 1)
            invalid("INVALID_QUERY", `${variantPath}.weight`);
          return Object.freeze({ text: string(item.text, true, `${variantPath}.text`), match, weight });
        });
        result = { kind, variants: Object.freeze(owned), ...has(data2, "fields") ? { fields: fields2(data2.fields, `${path}.fields`) } : {} };
        break;
      }
      case "and":
      case "or": {
        keysOnly(data2, ["kind", "children"], "INVALID_QUERY", path);
        const children = ownArray(data2.children, limits.maxQueryNodes, "INVALID_QUERY", `${path}.children`, admission);
        if (!children.length)
          invalid("INVALID_QUERY", `${path}.children`);
        result = { kind, children: Object.freeze(children.map((child, i) => node2(child, depth + 1, `${path}.children[${i}]`))) };
        break;
      }
      case "not":
        keysOnly(data2, ["kind", "child"], "INVALID_QUERY", path);
        result = { kind, child: node2(data2.child, depth + 1, `${path}.child`) };
        break;
      case "eq": {
        keysOnly(data2, ["kind", "field", "value"], "INVALID_QUERY", path);
        const name2 = string(data2.field, false, `${path}.field`);
        const field = schema2.metadata[name2];
        if (!field)
          invalid("INVALID_QUERY", `${path}.field`);
        const scalar = captureScalar(data2.value, field, limits, "INVALID_QUERY", `${path}.value`);
        if (typeof scalar === "string")
          string(scalar, false, `${path}.value`);
        result = { kind, field: name2, value: scalar };
        break;
      }
      case "all":
      case "none":
        keysOnly(data2, ["kind"], "INVALID_QUERY", path);
        result = { kind };
        break;
      case "extension": {
        keysOnly(data2, ["kind", "capability", "version", "payload"], "INVALID_QUERY", path);
        if (typeof data2.capability !== "string" || !data2.capability.length || !Number.isSafeInteger(data2.version) || data2.version < 1 || !has(data2, "payload"))
          invalid("INVALID_QUERY", path);
        const capability = string(data2.capability, false, `${path}.capability`);
        const registration = capabilities?.providers[capability];
        if (!registration?.refinement && !registration?.predicate && !registration?.sourcePredicate && !registration?.expansion)
          invalid("MISSING_CAPABILITY", path);
        if (data2.version !== 1)
          invalid("INCOMPATIBLE_CAPABILITY", `${path}.version`);
        if (registration.predicate || registration.sourcePredicate) {
          const captured = captureExtension((registration.predicate ?? registration.sourcePredicate).capture, data2.payload, admission, limits, registration.manifest.limits.maxPayloadCodeUnits);
          if (registration.sourcePredicate) {
            lexicalUnits += captured.codeUnits;
            bound(lexicalUnits, limits.maxQueryLexicalCodeUnits, "query.lexical");
          }
          stringUnits += captured.codeUnits;
          bound(stringUnits, limits.maxQueryCodeUnits, "query.strings");
          result = { kind: "predicate", capability, payload: captured.value };
          break;
        }
        const payload = ownObject(data2.payload, "INVALID_QUERY", `${path}.payload`, admission);
        if (registration.refinement?.kind === "ordered-token-groups") {
          keysOnly(payload, ["groups", "maxGap", "fields"], "INVALID_QUERY", `${path}.payload`);
          const maxGap = payload.maxGap;
          if (typeof maxGap !== "number" || !Number.isSafeInteger(maxGap) || maxGap < 0)
            invalid("INVALID_QUERY", `${path}.payload.maxGap`);
          bound(maxGap, 32, `${path}.payload.maxGap`);
          const rawGroups = ownArray(payload.groups, Math.min(32, registration.refinement.maxTokens), "INVALID_QUERY", `${path}.payload.groups`, admission);
          if (!rawGroups.length)
            invalid("INVALID_QUERY", `${path}.payload.groups`);
          const groups = Object.freeze(rawGroups.map((rawGroup) => {
            const alternatives = ownArray(rawGroup, Math.min(16, limits.maxVariantsPerGroup), "INVALID_QUERY", `${path}.payload.group`, admission);
            if (!alternatives.length)
              invalid("INVALID_QUERY", `${path}.payload.group`);
            return Object.freeze(alternatives.map((value2) => string(value2, true, `${path}.payload.alternative`)));
          }));
          const selected2 = has(payload, "fields") ? fields2(payload.fields, `${path}.payload.fields`) : registration.manifest.dataRequirements.fields;
          bound(groups.reduce((sum, group) => sum + group.reduce((n, text3) => n + text3.length, 0), 0) + selected2.reduce((sum, field) => sum + field.length, 0), registration.manifest.limits.maxPayloadCodeUnits, `${path}.payload`);
          result = { kind: "ordered", capability, fields: selected2, groups, maxGap };
          break;
        }
        keysOnly(payload, ["text", "fields"], "INVALID_QUERY", `${path}.payload`);
        const text2 = string(payload.text, true, `${path}.payload.text`);
        const selected = has(payload, "fields") ? fields2(payload.fields, `${path}.payload.fields`) : void 0;
        bound(text2.length + (selected?.reduce((sum, field) => sum + field.length, 0) ?? 0), registration.manifest.limits.maxPayloadCodeUnits, `${path}.payload`);
        result = { kind, capability, version: 1, payload: Object.freeze({ text: text2, ...selected ? { fields: selected } : {} }) };
        break;
      }
      default:
        return invalid("INVALID_QUERY", path);
    }
    ancestors.delete(value);
    return Object.freeze(result);
  }
  if (typeof input === "string") {
    bound(1, limits.maxQueryNodes, "query.nodes");
    bound(1, limits.maxQueryDepth, "query.depth");
    return Object.freeze({ kind: "text", text: string(input, true, "query"), operator: "and" });
  }
  return node2(input, 1, "query");
}
function* analyzeQuery(query, schema2, limits, capabilities, analyze = analyzeValue) {
  let tokens = 0;
  const groups = /* @__PURE__ */ new Set();
  const queryLimits = { ...limits, maxTextCodeUnitsPerValue: limits.maxQueryLexicalCodeUnits };
  function groupKey(fields2, variants) {
    const names = [...fields2 ?? Object.keys(schema2.text)].sort();
    const alternatives = [...new Set(variants.map((variant) => JSON.stringify(variant)))].sort();
    return JSON.stringify([names, alternatives]);
  }
  function addGroup(key) {
    groups.add(key);
    bound(groups.size, limits.maxQueryGroups, "query.groups");
  }
  function* walk(leaf) {
    switch (leaf.kind) {
      case "ordered": {
        const handler = capabilities?.providers[leaf.capability]?.refinement;
        if (handler?.kind !== "ordered-token-groups")
          invalid("MISSING_CAPABILITY", "query.capability");
        let count5 = 0;
        for (let groupIndex = 0; groupIndex < leaf.groups.length; groupIndex++) {
          const variants = [];
          for (const text2 of leaf.groups[groupIndex]) {
            let emitted = 0;
            for (const step of analyze(text2, 0, queryLimits, "INVALID_QUERY", "phrase")) {
              if (step.token) {
                if (++emitted > 1)
                  invalid("INVALID_QUERY", "query.proximity.alternative");
                bound(++count5, handler.maxTokens, "query.proximity.tokens");
                bound(++tokens, limits.maxQueryTokens, "query.tokens");
                variants.push([step.token.term, "exact", 1]);
              }
              yield { ...step, leaf, groupIndex };
            }
            if (emitted !== 1)
              invalid("INVALID_QUERY", "query.proximity.alternative");
          }
          addGroup(groupKey(leaf.fields, variants));
        }
        break;
      }
      case "text":
        for (const step of analyze(leaf.text, 0, queryLimits, "INVALID_QUERY", "query")) {
          if (step.token) {
            bound(++tokens, limits.maxQueryTokens, "query.tokens");
            addGroup(groupKey(leaf.fields, [[step.token.term, "exact", 1]]));
          }
          yield { ...step, leaf };
        }
        break;
      case "extension": {
        const registration = capabilities?.providers[leaf.capability];
        const handler = registration?.refinement ?? registration?.expansion;
        if (!handler)
          invalid("MISSING_CAPABILITY", "query.capability");
        let count5 = 0;
        for (const step of analyze(leaf.payload.text, 0, queryLimits, "INVALID_QUERY", registration?.refinement ? "phrase" : "query")) {
          if (step.token) {
            bound(++count5, handler.maxTokens, registration?.refinement ? "query.phraseTokens" : "query.expansionTokens");
            bound(++tokens, limits.maxQueryTokens, "query.tokens");
            addGroup(groupKey(leaf.payload.fields, [[step.token.term, "exact", 1]]));
          }
          yield { ...step, leaf };
        }
        break;
      }
      case "group": {
        const variants = [];
        for (let i = 0; i < leaf.variants.length; i++) {
          const variant = leaf.variants[i];
          let count5 = 0;
          for (const step of analyze(variant.text, 0, queryLimits, "INVALID_QUERY", "query")) {
            if (step.token) {
              bound(++tokens, limits.maxQueryTokens, "query.tokens");
              if (++count5 > 1)
                invalid("INVALID_QUERY", "query.variants");
              if (variant.match === "prefix" && [...step.token.term].length < limits.minPrefixCodePoints)
                invalid("INVALID_QUERY", "query.prefix");
              variants.push([step.token.term, variant.match, variant.weight ?? 1]);
            }
            yield { ...step, leaf, variantIndex: i };
          }
          if (count5 !== 1)
            invalid("INVALID_QUERY", "query.variants");
        }
        addGroup(groupKey(leaf.fields, variants));
        break;
      }
      case "and":
      case "or":
        for (const child of leaf.children)
          yield* walk(child);
        break;
      case "not":
        yield* walk(leaf.child);
        break;
      case "eq":
        if (typeof leaf.value === "string")
          yield* scanUnicode(leaf.value, "INVALID_QUERY", "query.value");
        break;
      case "predicate":
      case "all":
      case "none":
        break;
    }
  }
  yield* walk(query);
}

// node_modules/@vmitsaras/raveldex/dist/core/ranking/bm25.js
var positiveInteger = (value) => Number.isSafeInteger(value) && value > 0;
function rankingContext(root) {
  return { root, fields: /* @__PURE__ */ new Map() };
}
function* scoreDocument(root, doc, participating, expansions, charge9, facts, context = rankingContext(root)) {
  if (context.root !== root)
    invalid("INTERNAL_ERROR", "ranking.root");
  let score = 0;
  for (const key of yield* sortedStrings(participating, charge9)) {
    const expanded = expansions.get(key);
    let groupScore = 0;
    for (const field of expanded.group.fields) {
      let best = 0;
      let found = false;
      let selected;
      let prepared = context.fields.get(field);
      for (const alternative of expanded.fields.get(field)) {
        yield charge9(doc.id.length + field.length + alternative.term.length + 3);
        const tf = directoryGet(alternative.entry.postings, doc.id);
        if (tf === void 0)
          continue;
        yield charge9(1);
        if (!prepared) {
          const statistics = root.fields[field];
          const N2 = statistics.documents, totalLength2 = statistics.length;
          const boost2 = root.configuration.schema.text[field].boost;
          if (!positiveInteger(N2) || !positiveInteger(totalLength2) || N2 > root.documents.size || totalLength2 < N2 || !Number.isFinite(boost2) || boost2 <= 0 || boost2 > 16)
            invalid("INTERNAL_ERROR", "ranking.statistics");
          const avgLength2 = totalLength2 / N2;
          prepared = { N: N2, totalLength: totalLength2, boost: boost2, avgLength: avgLength2, terms: /* @__PURE__ */ new Map() };
          context.fields.set(field, prepared);
        }
        const { N, totalLength, boost, avgLength } = prepared;
        const length = doc.fields[field]?.length ?? 0;
        if (!positiveInteger(tf) || !positiveInteger(length) || tf > length || length > totalLength)
          invalid("INTERNAL_ERROR", "ranking.statistics");
        let term = prepared.terms.get(alternative.entry);
        if (!term) {
          const df2 = alternative.entry.df;
          if (!positiveInteger(df2) || df2 > N)
            invalid("INTERNAL_ERROR", "ranking.statistics");
          const idf2 = Math.log(1 + (N - df2 + 0.5) / (df2 + 0.5));
          term = { df: df2, idf: idf2 };
          prepared.terms.set(alternative.entry, term);
        }
        const { df, idf } = term;
        const normalizer = 1.2 * (1 - 0.75 + 0.75 * length / avgLength);
        const tfPart = tf * (1.2 + 1) / (tf + normalizer);
        const base = boost * idf * tfPart;
        const weighted = alternative.weight * base;
        if (!Number.isFinite(weighted) || weighted < 0)
          invalid("INTERNAL_ERROR", "ranking.score");
        if (!found || weighted > best) {
          found = true;
          best = weighted;
          if (facts)
            selected = { kind: "field", id: doc.id, group: key, field, term: alternative.term, variant: alternative.variantKey, weight: alternative.weight, boost, tf, df, N, length, totalLength, avgLength, k1: 1.2, b: 0.75, idf, normalizer, tfPart, base, selected: weighted };
        }
      }
      groupScore += best;
      if (facts && selected) {
        yield charge9(1);
        facts.record(selected);
      }
    }
    score += groupScore;
    if (facts) {
      yield charge9(1);
      facts.record({ kind: "group", id: doc.id, group: key, score: groupScore });
    }
  }
  if (!Number.isFinite(score) || score < 0)
    invalid("INTERNAL_ERROR", "ranking.score");
  return score;
}

// node_modules/@vmitsaras/raveldex/dist/core/ranking/page.js
var PageSelection = class {
  capacity;
  charge;
  heap = [];
  constructor(capacity, charge9) {
    this.capacity = capacity;
    this.charge = charge9;
  }
  *compare(a, b) {
    yield this.charge(1);
    return a.score === b.score ? yield* compareStrings(a.id, b.id, this.charge) : b.score - a.score;
  }
  *add(hit) {
    if (!this.capacity)
      return;
    if (this.heap.length === this.capacity) {
      if ((yield* this.compare(hit, this.heap[0])) >= 0)
        return;
      this.heap[0] = hit;
      yield* this.down();
    } else {
      let i = this.heap.length;
      this.heap.push(hit);
      yield this.charge(1);
      while (i > 0) {
        const parent = Math.floor((i - 1) / 2);
        if ((yield* this.compare(this.heap[i], this.heap[parent])) <= 0)
          break;
        yield this.charge(1);
        [this.heap[parent], this.heap[i]] = [this.heap[i], this.heap[parent]];
        i = parent;
      }
    }
  }
  *down() {
    let i = 0;
    while (i * 2 + 1 < this.heap.length) {
      let child = i * 2 + 1;
      if (child + 1 < this.heap.length && (yield* this.compare(this.heap[child + 1], this.heap[child])) > 0)
        child++;
      if ((yield* this.compare(this.heap[i], this.heap[child])) >= 0)
        break;
      yield this.charge(1);
      [this.heap[i], this.heap[child]] = [this.heap[child], this.heap[i]];
      i = child;
    }
  }
  *finish(offset, limit) {
    const reversed = [];
    while (this.heap.length) {
      const rank = this.heap.length - 1;
      const hit = this.heap[0];
      const last = this.heap.pop();
      yield this.charge(1);
      if (this.heap.length) {
        this.heap[0] = last;
        yield* this.down();
      }
      if (rank >= offset && rank < offset + limit) {
        yield this.charge(1);
        reversed.push(Object.freeze(hit));
      }
    }
    return Object.freeze(reversed.reverse());
  }
};

// node_modules/@vmitsaras/raveldex/dist/core/retrieval/expand.js
function* expandGroups(root, groups, charge9, checkpoint) {
  const queryPairs = /* @__PURE__ */ new Set();
  const result = /* @__PURE__ */ new Map();
  for (const key of yield* sortedStrings(groups.keys(), charge9)) {
    const group = groups.get(key);
    let perGroup = 0;
    const fields2 = /* @__PURE__ */ new Map();
    const ids = /* @__PURE__ */ new Set();
    for (const name2 of group.fields) {
      const field = root.fields[name2];
      if (!field)
        invalid("INTERNAL_ERROR", "index.fields");
      const terms = /* @__PURE__ */ new Map();
      function* add(term, entry, weight, variantKey) {
        yield charge9(term.length + 1);
        const old = terms.get(term);
        if (!old) {
          yield charge9(name2.length + term.length + 1);
          queryPairs.add(JSON.stringify([name2, term]));
          validateExpansionCounts(++perGroup, queryPairs.size, root.configuration.limits);
        }
        if (!old || weight > old.weight || weight === old.weight && (yield* compareStrings(variantKey, old.variantKey, charge9)) < 0) {
          terms.set(term, Object.freeze({ term, entry, weight, variantKey }));
        }
      }
      for (const variant of group.variants) {
        if (variant.match === "exact") {
          checkpoint?.("dictionary");
          yield charge9(variant.term.length + 1);
          const entry = directoryGet(field.terms, variant.term);
          if (entry)
            yield* add(variant.term, entry, variant.weight, variant.key);
        } else {
          const headroom = Math.min(root.configuration.limits.maxExpansionsPerGroup - perGroup, root.configuration.limits.maxQueryExpansions - queryPairs.size);
          const selected = yield* prefixTerms(field.order, variant.term, headroom, charge9, () => checkpoint?.("dictionary"));
          if (!selected.overflow) {
            for (const term of selected.keys) {
              yield charge9(term.length + 1);
              const entry = directoryGet(field.terms, term);
              if (!entry)
                invalid("INTERNAL_ERROR", "index.order");
              yield* add(term, entry, variant.weight, variant.key);
            }
          } else {
            for (const [term, entry] of directoryEntries(field.terms)) {
              checkpoint?.("dictionary");
              yield charge9(1);
              let matches = term.length >= variant.term.length;
              for (let i = 0; matches && i < variant.term.length; i++) {
                yield charge9(1);
                matches = term.charCodeAt(i) === variant.term.charCodeAt(i);
              }
              if (matches)
                yield* add(term, entry, variant.weight, variant.key);
            }
          }
        }
      }
      const alternatives = [];
      for (const term of yield* sortedStrings(terms.keys(), charge9)) {
        const expansion = terms.get(term);
        const entry = expansion.entry;
        if (!Number.isSafeInteger(entry.df) || entry.df < 1 || entry.df > field.documents || entry.df !== entry.postings.size)
          invalid("INTERNAL_ERROR", "index.df");
        alternatives.push(expansion);
        for (const [id, tf] of directoryEntries(entry.postings)) {
          checkpoint?.("postings");
          yield charge9(id.length + name2.length + term.length + 3);
          const doc = directoryGet(root.documents, id);
          if (!doc || !Number.isSafeInteger(tf) || tf <= 0 || doc.fields[name2]?.terms[term] !== tf)
            invalid("INTERNAL_ERROR", "index.postings");
          yield charge9(id.length + 1);
          ids.add(id);
        }
      }
      fields2.set(name2, Object.freeze(alternatives));
    }
    result.set(key, { group, fields: fields2, ids });
  }
  return result;
}

// node_modules/@vmitsaras/raveldex/dist/core/trace/facts.js
function captureTrace(input, limits, admission) {
  const data2 = ownObject(input, "INVALID_OPTIONS", "trace", admission);
  keysOnly(data2, ["ids", "maxFacts", "expectedRevision"], "INVALID_OPTIONS", "trace");
  const ids = ownArray(data2.ids, limits.maxDocuments, "INVALID_OPTIONS", "trace.ids", admission).map((id) => {
    const value = stringValue(id, limits.maxIdCodeUnits, "INVALID_OPTIONS", "trace.ids");
    if (!value.length)
      invalid("INVALID_OPTIONS", "trace.ids");
    return value;
  });
  if (new Set(ids).size !== ids.length)
    invalid("INVALID_OPTIONS", "trace.ids");
  const maxFacts = has(data2, "maxFacts") ? data2.maxFacts : 4096;
  if (typeof maxFacts !== "number" || !Number.isSafeInteger(maxFacts) || maxFacts < 1)
    invalid("INVALID_OPTIONS", "trace.maxFacts");
  bound(maxFacts, 4096, "trace.maxFacts");
  const revision = data2.expectedRevision;
  if (has(data2, "expectedRevision") && (typeof revision !== "number" || !Number.isSafeInteger(revision) || revision < 0))
    invalid("INVALID_OPTIONS", "trace.expectedRevision");
  return Object.freeze({ ids: Object.freeze(ids), maxFacts, ...typeof revision === "number" ? { expectedRevision: revision } : {} });
}
var FactCollector = class {
  maximum;
  facts = [];
  constructor(maximum) {
    this.maximum = maximum;
    bound(1, maximum, "trace.facts");
  }
  record(fact) {
    bound(this.facts.length + 2, this.maximum, "trace.facts");
    this.facts.push(Object.freeze(fact));
  }
  finish(revision, analyzer, query) {
    return Object.freeze({ revision, model: "raveldex-bm25-v1", analyzer, query, tieBreaker: "utf16-id-ascending", facts: Object.freeze(this.facts) });
  }
};

// node_modules/@vmitsaras/raveldex/dist/core/query/compile.js
function* compileQuery(query, configuration, charge9, expansion, analyze = createAnalysis(configuration)) {
  const tokens = /* @__PURE__ */ new Map();
  const orderedTokens = /* @__PURE__ */ new Map();
  for (const step of analyzeQuery(query, configuration.schema, configuration.limits, configuration.capabilities, analyze)) {
    yield charge9(step.workUnits);
    if (step.token && step.leaf) {
      yield charge9(1);
      if (step.groupIndex !== void 0) {
        let groups2 = orderedTokens.get(step.leaf);
        if (!groups2) {
          groups2 = [];
          orderedTokens.set(step.leaf, groups2);
        }
        const list2 = groups2[step.groupIndex] ?? [];
        list2.push(step.token.term);
        groups2[step.groupIndex] = list2;
        continue;
      }
      let list = tokens.get(step.leaf);
      if (!list) {
        list = [];
        tokens.set(step.leaf, list);
      }
      list.push(step.token.term);
    }
  }
  const groups = /* @__PURE__ */ new Map();
  function* group(fields2, variants) {
    const names = yield* sortedStrings(fields2 ?? Object.keys(configuration.schema.text), charge9);
    const entries = /* @__PURE__ */ new Map();
    for (const variant of variants) {
      yield charge9(variant.term.length + 1);
      const key3 = JSON.stringify([variant.term, variant.match, variant.weight]);
      yield charge9(key3.length + 1);
      entries.set(key3, Object.freeze({ ...variant, key: key3 }));
    }
    const keys = yield* sortedStrings(entries.keys(), charge9);
    yield charge9(names.reduce((n, field) => n + field.length, 1) + keys.reduce((n, key3) => n + key3.length, 1));
    const key2 = JSON.stringify([names, keys]);
    yield charge9(key2.length + 1);
    let canonical2 = groups.get(key2);
    if (!canonical2) {
      canonical2 = Object.freeze({ key: key2, fields: Object.freeze(names), variants: Object.freeze(keys.map((entry) => entries.get(entry))) });
      groups.set(key2, canonical2);
      bound(groups.size, configuration.limits.maxQueryGroups, "query.groups");
    }
    return Object.freeze({ kind: "group", group: canonical2 });
  }
  function* walk(raw) {
    yield charge9(1);
    switch (raw.kind) {
      case "ordered": {
        const lexical = [], termGroups = [];
        for (const terms of orderedTokens.get(raw) ?? []) {
          const node3 = yield* group(raw.fields, terms.map((term) => ({ term, match: "exact", weight: 1 })));
          if (node3.kind !== "group")
            invalid("INTERNAL_ERROR", "query.proximity.group");
          lexical.push(node3.group);
          termGroups.push(Object.freeze(node3.group.variants.map((variant) => variant.term)));
        }
        return Object.freeze({ kind: "extension", capability: raw.capability, fields: Object.freeze(yield* sortedStrings(raw.fields, charge9)), terms: Object.freeze(termGroups.flat()), groups: Object.freeze(lexical), termGroups: Object.freeze(termGroups), maxGap: raw.maxGap });
      }
      case "text": {
        const children = [];
        for (const term of tokens.get(raw) ?? [])
          children.push(yield* group(raw.fields, [{ term, match: "exact", weight: 1 }]));
        return children.length ? Object.freeze({ kind: raw.operator ?? "and", children: Object.freeze(children) }) : Object.freeze({ kind: "none" });
      }
      case "group":
        return yield* group(raw.fields, raw.variants.map((variant, i) => ({ term: tokens.get(raw)[i], match: variant.match, weight: variant.weight ?? 1 })));
      case "extension": {
        if (configuration.capabilities?.providers[raw.capability]?.expansion) {
          if (!expansion)
            invalid("MISSING_CAPABILITY", "query.expansion");
          const selected = Object.freeze(yield* sortedStrings(raw.payload.fields ?? Object.keys(configuration.schema.text), charge9));
          const terms2 = tokens.get(raw) ?? [];
          const alternatives = yield* expansion.resolve(raw.capability, selected, terms2);
          const children = [];
          for (let i = 0; i < alternatives.length; i++) {
            const term = terms2[i];
            const variants = [{ term, match: "exact", weight: 1 }, ...alternatives[i].filter((variant) => variant.term !== term)];
            bound(variants.length, configuration.limits.maxVariantsPerGroup, "query.expansion.variants");
            children.push(yield* group(selected, variants));
          }
          return children.length ? Object.freeze({ kind: "and", children: Object.freeze(children) }) : Object.freeze({ kind: "none" });
        }
        const lexical = [], terms = Object.freeze(tokens.get(raw) ?? []);
        for (const term of terms) {
          const node3 = yield* group(raw.payload.fields, [{ term, match: "exact", weight: 1 }]);
          if (node3.kind === "group")
            lexical.push(node3.group);
        }
        return Object.freeze({
          kind: "extension",
          capability: raw.capability,
          fields: Object.freeze(yield* sortedStrings(raw.payload.fields ?? Object.keys(configuration.schema.text), charge9)),
          terms,
          groups: Object.freeze(lexical)
        });
      }
      case "and":
      case "or": {
        const children = [];
        for (const child of raw.children)
          children.push(yield* walk(child));
        return Object.freeze({ kind: raw.kind, children: Object.freeze(children) });
      }
      case "not":
        return Object.freeze({ kind: "not", child: yield* walk(raw.child) });
      case "predicate":
        return Object.freeze({ kind: "predicate", capability: raw.capability, payload: raw.payload });
      case "eq":
        return Object.freeze({ kind: "eq", field: raw.field, value: raw.value });
      case "all":
      case "none":
        return Object.freeze({ kind: raw.kind });
    }
  }
  const node2 = yield* walk(query);
  const key = JSON.stringify(node2);
  yield charge9(key.length + 1);
  return { node: node2, groups, key };
}

// node_modules/@vmitsaras/raveldex/dist/core/query/evaluate.js
function* evaluate(node2, doc, expansions, charge9, facts, path = "query", refinements) {
  yield charge9(1);
  let matched = false;
  let groups = /* @__PURE__ */ new Set();
  switch (node2.kind) {
    case "group":
      yield charge9(doc.id.length + node2.group.key.length + 1);
      matched = expansions.get(node2.group.key).ids.has(doc.id);
      if (matched) {
        yield charge9(node2.group.key.length + 1);
        groups.add(node2.group.key);
      }
      break;
    case "extension": {
      matched = node2.terms.length > 0;
      for (const group of node2.groups) {
        yield charge9(doc.id.length + group.key.length + 1);
        if (!expansions.get(group.key).ids.has(doc.id))
          matched = false;
      }
      if (matched) {
        const verifier = refinements?.get(node2);
        if (!verifier)
          invalid("MISSING_CAPABILITY", "query.refinement");
        const cursor = verifier.test(doc.id, doc.metadata);
        try {
          for (; ; ) {
            const step = cursor.next();
            if (step.done) {
              matched = step.value;
              break;
            }
            yield step.value;
          }
        } finally {
          try {
            cursor.return(false);
          } catch {
          }
        }
      }
      if (matched)
        for (const group of node2.groups) {
          yield charge9(group.key.length + 1);
          groups.add(group.key);
        }
      break;
    }
    case "predicate": {
      const predicate = refinements?.get(node2);
      if (!predicate)
        invalid("MISSING_CAPABILITY", "query.predicate");
      matched = yield* predicate.test(doc.id, doc.metadata);
      break;
    }
    case "all":
      matched = true;
      break;
    case "none":
      break;
    case "eq": {
      yield charge9(node2.field.length + 1);
      if (Object.hasOwn(doc.metadata, node2.field)) {
        const value = doc.metadata[node2.field];
        const values = Array.isArray(value) ? value : [value];
        for (const scalar of values) {
          yield charge9(typeof scalar === "string" && typeof node2.value === "string" ? Math.max(scalar.length, node2.value.length) + 1 : 1);
          if (scalar === node2.value) {
            matched = true;
            break;
          }
        }
      }
      break;
    }
    case "not":
      matched = !(yield* evaluate(node2.child, doc, expansions, charge9, facts, facts ? `${path}.child` : "", refinements)).matched;
      break;
    case "and":
    case "or": {
      matched = node2.kind === "and";
      for (let i = 0; i < node2.children.length; i++) {
        const child = yield* evaluate(node2.children[i], doc, expansions, charge9, facts, facts ? `${path}.children[${i}]` : "", refinements);
        matched = node2.kind === "and" ? matched && child.matched : matched || child.matched;
        if (child.matched)
          for (const key of child.groups) {
            yield charge9(key.length + 1);
            groups.add(key);
          }
      }
      if (!matched)
        groups = /* @__PURE__ */ new Set();
      break;
    }
  }
  if (facts) {
    const keys = Object.freeze(yield* sortedStrings(groups, charge9));
    yield charge9(1);
    facts.record({
      kind: "node",
      id: doc.id,
      path,
      node: node2.kind,
      matched,
      groups: keys,
      ...node2.kind === "predicate" || node2.kind === "extension" ? { capability: node2.capability } : {},
      ...node2.kind === "eq" ? { field: node2.field } : {}
    });
  }
  return { matched, groups };
}

// node_modules/@vmitsaras/raveldex/dist/core/capabilities/refinement.js
function* prepareRefinements(node2, root, charge9, options, analyze = createAnalysis(root.configuration)) {
  const leaves = /* @__PURE__ */ new Map();
  const aggregations = [], budgets = /* @__PURE__ */ new Map();
  const outputs = [];
  let evidence;
  function setup(capability) {
    const set = root.configuration.capabilities, registration = set?.providers[capability];
    if (!registration)
      invalid("MISSING_CAPABILITY", "query.capability");
    let budget = budgets.get(registration.manifest.id);
    if (!budget) {
      budget = new WorkBudget(Math.min(registration.manifest.limits.maxWorkUnits, root.configuration.limits.maxSearchWorkUnits));
      budgets.set(registration.manifest.id, budget);
    }
    const shared = budget;
    return { registration, *run(cursor) {
      try {
        for (; ; ) {
          const step = cursor.next();
          charge9(0);
          if (step.done)
            return step.value;
          const charged = charge9(step.value.workUnits);
          shared.charge(step.value.workUnits);
          yield charged;
        }
      } finally {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    } };
  }
  const metadataContext = (capability, payload) => Object.freeze({ revision: root.revision, schema: root.configuration.schema, limits: root.configuration.limits, capability, payload });
  function state(capability, consumer) {
    const registration = root.configuration.capabilities.providers[consumer];
    if (!registration.manifest.requires.some((ref) => ref.id === capability))
      invalid("MISSING_CAPABILITY", "query.provider");
    const provider = root.configuration.capabilities.providers[capability];
    if (!provider?.participant || !Object.hasOwn(root.participants, provider.manifest.id))
      invalid("MISSING_CAPABILITY", "query.provider");
    return root.participants[provider.manifest.id];
  }
  function output(capability, result) {
    if (!result || !Number.isSafeInteger(result.entries) || result.entries < 0 || result.value !== null && typeof result.value === "object" && !Object.isFrozen(result.value))
      invalid("INCOMPATIBLE_CAPABILITY", "extensions.output");
    bound(result.entries, Math.min(root.configuration.capabilities.providers[capability].manifest.limits.maxOutputEntries, root.configuration.limits.maxAdmissionEntries), "extensions.output");
    return result.value;
  }
  function* walk(node3) {
    if (node3.kind === "extension" || node3.kind === "predicate") {
      const { registration, run } = setup(node3.capability);
      let test;
      if (node3.kind === "extension") {
        if (!registration.refinement)
          invalid("MISSING_CAPABILITY", "query.refinement");
        if (registration.refinement.kind === "ordered-token-groups" !== (node3.termGroups !== void 0))
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement.kind");
        const context = Object.freeze({
          analyze,
          revision: root.revision,
          analyzer: root.configuration.analyzer,
          limits: root.configuration.limits,
          fields: node3.fields,
          terms: node3.terms,
          ...node3.termGroups ? { groups: node3.termGroups, maxGap: node3.maxGap } : {},
          state(capability) {
            return state(capability, node3.capability);
          }
        });
        const prepared = yield* run(registration.refinement.prepare(context));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement");
        test = prepared.test.bind(prepared);
      } else if (registration.sourcePredicate) {
        const prepared = yield* run(registration.sourcePredicate.prepare(Object.freeze({
          ...metadataContext(node3.capability, node3.payload),
          analyzer: root.configuration.analyzer,
          state: (requested) => state(requested, node3.capability)
        })));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.sourcePredicate");
        const predicate = prepared.test.bind(prepared);
        test = (id) => predicate(id);
      } else {
        if (!registration.predicate)
          invalid("MISSING_CAPABILITY", "query.predicate");
        const prepared = yield* run(registration.predicate.prepare(metadataContext(node3.capability, node3.payload)));
        if (!prepared || typeof prepared.test !== "function")
          invalid("INCOMPATIBLE_CAPABILITY", "query.predicate");
        const predicate = prepared.test.bind(prepared);
        test = (_id, metadata2) => predicate(metadata2);
      }
      leaves.set(node3, Object.freeze({ *test(id, metadata2) {
        const matched = yield* run(test(id, metadata2));
        if (typeof matched !== "boolean")
          invalid("INCOMPATIBLE_CAPABILITY", "query.refinement");
        return matched;
      } }));
    } else if (node3.kind === "and" || node3.kind === "or")
      for (const child of node3.children)
        yield* walk(child);
    else if (node3.kind === "not")
      yield* walk(node3.child);
  }
  yield* walk(node2);
  for (const capability of Object.keys(options.extensions ?? {}).sort()) {
    yield charge9(capability.length + 1);
    const { registration, run } = setup(capability);
    if (registration.dictionary) {
      const prepared2 = yield* run(registration.dictionary.prepare(Object.freeze({
        ...metadataContext(capability, options.extensions[capability]),
        analyzer: root.configuration.analyzer,
        *dictionary(fields2) {
          if (!Array.isArray(fields2) || !fields2.length)
            invalid("INCOMPATIBLE_CAPABILITY", "extensions.dictionary.fields");
          bound(fields2.length, root.configuration.limits.maxTextFields, "extensions.dictionary.fields");
          const selected = /* @__PURE__ */ new Set();
          for (const field of fields2) {
            if (typeof field !== "string" || !registration.manifest.dataRequirements.fields.includes(field) || selected.has(field))
              invalid("MISSING_CAPABILITY", "extensions.dictionary.fields");
            selected.add(field);
          }
          for (const field of selected)
            for (const [term, entry] of directoryEntries(root.fields[field].terms)) {
              yield Object.freeze({ workUnits: field.length + term.length + 1, field, term, documentFrequency: entry.df });
            }
        }
      })));
      if (!prepared2 || typeof prepared2.finish !== "function")
        invalid("INCOMPATIBLE_CAPABILITY", "extensions.dictionary");
      const finish2 = prepared2.finish.bind(prepared2);
      outputs.push(Object.freeze({ capability, *finish() {
        return output(capability, yield* run(finish2()));
      } }));
      continue;
    }
    if (registration.evidence) {
      if (evidence)
        invalid("INVALID_OPTIONS", "options.extensions.evidence");
      const prepared2 = yield* run(registration.evidence.prepare(Object.freeze({
        ...metadataContext(capability, options.extensions[capability]),
        analyzer: root.configuration.analyzer,
        analyze,
        state: (requested) => state(requested, capability)
      })));
      if (!prepared2 || typeof prepared2.finish !== "function")
        invalid("INCOMPATIBLE_CAPABILITY", "extensions.evidence");
      const finish2 = prepared2.finish.bind(prepared2);
      evidence = Object.freeze({ capability, *finish(context) {
        return output(capability, yield* run(finish2(context)));
      } });
      continue;
    }
    if (!registration.aggregation)
      invalid("MISSING_CAPABILITY", "options.extensions");
    const prepared = yield* run(registration.aggregation.prepare(metadataContext(capability, options.extensions[capability])));
    if (!prepared || typeof prepared.add !== "function" || typeof prepared.finish !== "function")
      invalid("INCOMPATIBLE_CAPABILITY", "extensions.aggregation");
    const add = prepared.add.bind(prepared), finish = prepared.finish.bind(prepared);
    aggregations.push(Object.freeze({
      capability,
      *add(metadata2) {
        if ((yield* run(add(metadata2))) !== void 0)
          invalid("INCOMPATIBLE_CAPABILITY", "extensions.aggregation");
      },
      *finish() {
        return output(capability, yield* run(finish()));
      }
    }));
  }
  return { leaves, aggregations, outputs, ...evidence ? { evidence } : {} };
}

// node_modules/@vmitsaras/raveldex/dist/core/capabilities/expansion.js
function createExpansionResolver(root, charge9) {
  const budgets = /* @__PURE__ */ new Map(), outputs = /* @__PURE__ */ new Map();
  const observations = /* @__PURE__ */ new Map(), cache = /* @__PURE__ */ new Map();
  let outputEntries = 0;
  return {
    *resolve(capability, fields2, terms) {
      if (root.configuration.analyzer.id !== "basic-v1")
        invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.analyzer");
      const registration = root.configuration.capabilities?.providers[capability];
      if (!registration?.expansion)
        invalid("MISSING_CAPABILITY", "query.expansion");
      for (const field of fields2) {
        yield charge9(field.length + 1);
        if (!registration.manifest.dataRequirements.fields.includes(field))
          invalid("MISSING_CAPABILITY", "query.expansion.fields");
      }
      const output = (count5) => {
        const entries = (outputs.get(registration.manifest.id) ?? 0) + count5;
        bound(entries, registration.manifest.limits.maxOutputEntries, "query.expansion.output");
        bound(outputEntries + count5, root.configuration.limits.maxAdmissionEntries, "query.expansion.output");
        outputs.set(registration.manifest.id, entries);
        outputEntries += count5;
      };
      if (!observations.has(capability)) {
        output(3);
        yield charge9(3);
        observations.set(capability, []);
      }
      let budget = budgets.get(registration.manifest.id);
      if (!budget) {
        budget = new WorkBudget(Math.min(registration.manifest.limits.maxWorkUnits, root.configuration.limits.maxSearchWorkUnits));
        budgets.set(registration.manifest.id, budget);
      }
      const result = [];
      for (const term of terms) {
        const key = JSON.stringify([capability, fields2, term]);
        yield charge9(key.length + 1);
        const reused = cache.get(key);
        if (reused) {
          result.push(reused);
          continue;
        }
        const before = budget.consumed;
        let exact = false, visited = 0;
        for (const field of fields2) {
          yield charge9(field.length + term.length + 1);
          if (directoryGet(root.fields[field].terms, term))
            exact = true;
        }
        const context = Object.freeze({
          revision: root.revision,
          analyzer: root.configuration.analyzer,
          limits: root.configuration.limits,
          fields: fields2,
          term,
          exact,
          *dictionary() {
            for (const field of fields2)
              for (const [candidate] of directoryEntries(root.fields[field].terms)) {
                visited++;
                yield { workUnits: field.length + candidate.length + 1, term: candidate };
              }
          }
        });
        const cursor = registration.expansion.expand(context);
        let alternatives;
        try {
          for (; ; ) {
            const step = cursor.next();
            if (step.done) {
              alternatives = step.value;
              break;
            }
            const charged = charge9(step.value.workUnits);
            budget.charge(step.value.workUnits);
            yield charged;
          }
        } finally {
          try {
            cursor.return([]);
          } catch {
          }
        }
        if (!Array.isArray(alternatives) || !Object.isFrozen(alternatives))
          invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.output");
        bound(alternatives.length, root.configuration.limits.maxVariantsPerGroup, "query.expansion.alternatives");
        const byTerm = /* @__PURE__ */ new Map();
        for (const alternative of alternatives) {
          if (!alternative || typeof alternative.term !== "string" || !alternative.term.length || alternative.term.length > root.configuration.limits.maxTermCodeUnits || !Number.isFinite(alternative.weight) || alternative.weight <= 0 || alternative.weight > 1 || byTerm.has(alternative.term))
            invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.output");
          yield charge9(alternative.term.length + 1);
          let live = false;
          for (const field of fields2) {
            yield charge9(field.length + alternative.term.length + 1);
            if (directoryGet(root.fields[field].terms, alternative.term))
              live = true;
          }
          if (!live)
            invalid("INCOMPATIBLE_CAPABILITY", "query.expansion.dictionary");
          byTerm.set(alternative.term, Object.freeze({ term: alternative.term, match: "exact", weight: alternative.weight }));
        }
        const variants = [];
        for (const name2 of yield* sortedStrings(byTerm.keys(), charge9))
          variants.push(byTerm.get(name2));
        const owned = Object.freeze(variants);
        const entries = 8 + fields2.length + 4 * variants.length;
        output(entries);
        yield charge9(entries);
        const list = observations.get(capability) ?? [];
        list.push(Object.freeze({ term, fields: fields2, alternatives: owned, dictionaryEntriesVisited: visited, workUnits: budget.consumed - before }));
        observations.set(capability, list);
        cache.set(key, owned);
        result.push(owned);
      }
      return result;
    },
    finish() {
      if (!observations.size)
        return void 0;
      const result = /* @__PURE__ */ Object.create(null);
      for (const [capability, groups] of observations)
        result[capability] = Object.freeze({
          policy: root.configuration.capabilities.providers[capability].expansion.policy,
          groups: Object.freeze(groups)
        });
      return Object.freeze(result);
    }
  };
}

// node_modules/@vmitsaras/raveldex/dist/core/query/candidates.js
function* hasRecordChecks(node2, charge9) {
  yield charge9(1);
  if (node2.kind === "predicate" || node2.kind === "extension")
    return true;
  if (node2.kind === "not")
    return yield* hasRecordChecks(node2.child, charge9);
  if (node2.kind === "and" || node2.kind === "or") {
    for (const child of node2.children)
      if (yield* hasRecordChecks(child, charge9))
        return true;
  }
  return false;
}
function* intersect(bounds, charge9) {
  let smallest;
  for (const bound2 of bounds) {
    yield charge9(1);
    if (bound2 && (!smallest || bound2.size < smallest.size))
      smallest = bound2;
  }
  if (!smallest || bounds.every((bound2) => !bound2 || bound2 === smallest))
    return smallest;
  const result = /* @__PURE__ */ new Set();
  for (const id of smallest) {
    yield charge9(id.length + 1);
    let included = true;
    for (const bound2 of bounds) {
      yield charge9(1);
      if (bound2 && !bound2.has(id)) {
        included = false;
        break;
      }
    }
    if (included)
      result.add(id);
  }
  return result;
}
function* candidateBound(node2, expansions, charge9) {
  if (node2.kind !== "extension" && (yield* hasRecordChecks(node2, charge9)))
    return void 0;
  function* visit(node3) {
    yield charge9(1);
    switch (node3.kind) {
      case "group":
        return expansions.get(node3.group.key).ids;
      case "extension":
        return node3.terms.length ? yield* intersect(node3.groups.map((group) => expansions.get(group.key).ids), charge9) : /* @__PURE__ */ new Set();
      case "none":
        return /* @__PURE__ */ new Set();
      case "all":
      case "eq":
      case "predicate":
      case "not":
        return void 0;
      case "and":
      case "or": {
        const bounds = [];
        for (const child of node3.children)
          bounds.push(yield* visit(child));
        if (node3.kind === "and")
          return yield* intersect(bounds, charge9);
        if (bounds.some((bound2) => !bound2))
          return void 0;
        if (bounds.every((bound2) => bound2 === bounds[0]))
          return bounds[0];
        const result = /* @__PURE__ */ new Set();
        for (const bound2 of bounds)
          for (const id of bound2) {
            yield charge9(id.length + 1);
            result.add(id);
          }
        return result;
      }
    }
  }
  return yield* visit(node2);
}
function* candidateDocuments(root, bound2, selected, charge9) {
  if (!bound2 || bound2.size === root.documents.size)
    return directoryEntries(root.documents);
  const buckets = /* @__PURE__ */ new Set();
  for (const ids of [bound2, selected])
    for (const id of ids) {
      yield charge9(id.length + 1);
      buckets.add(bucketOf(id));
    }
  const ordered = [];
  if (buckets.size)
    for (const slot of Object.keys(root.documents.buckets)) {
      yield charge9(1);
      if (!buckets.has(slot))
        continue;
      const bucket = root.documents.buckets[slot];
      for (const id of Object.keys(bucket)) {
        yield charge9(id.length + 1);
        if (bound2.has(id) || selected.has(id))
          ordered.push(id);
      }
    }
  function* entries() {
    for (const id of ordered)
      yield [id, directoryGet(root.documents, id)];
  }
  return entries();
}

// node_modules/@vmitsaras/raveldex/dist/core/query/search.js
function captureSearch(configuration, input, options, trace) {
  const { schema: schema2, limits } = configuration;
  const admission = new Admission(limits.maxAdmissionEntries);
  const page = captureOptions(options, limits, true, admission, configuration.capabilities);
  if (page.signal?.aborted)
    invalid("CANCELLED", "options.signal");
  const query = captureQuery(input, schema2, limits, admission, configuration.capabilities);
  let request = trace === void 0 ? void 0 : captureTrace(trace, limits, admission);
  let evidence;
  for (const capability of Object.keys(page.extensions ?? {})) {
    const handler = configuration.capabilities?.providers[capability]?.evidence;
    if (!handler)
      continue;
    if (request || evidence)
      invalid("INVALID_OPTIONS", "options.extensions.evidence");
    request = captureTrace(handler.select(page.extensions[capability]), limits, admission);
    evidence = capability;
  }
  return Object.freeze({ query, options: page, ...request ? { trace: request } : {}, ...evidence ? { evidence } : {} });
}
function* executeOwnedSearch(root, request, control = {}) {
  const { query, options, trace } = request;
  const budget = new WorkBudget(root.configuration.limits.maxSearchWorkUnits);
  let phase = "start";
  const check2 = () => {
    control.checkpoint?.(phase);
    if (control.checkStop)
      control.checkStop(phase);
    else if (options.signal?.aborted)
      invalid("CANCELLED", "options.signal");
  };
  const boundary = (next) => {
    phase = next;
    check2();
  };
  const charge9 = (workUnits) => {
    check2();
    budget.charge(workUnits);
    return { workUnits };
  };
  check2();
  if (trace?.expectedRevision !== void 0 && trace.expectedRevision !== root.revision)
    invalid("REVISION_MISMATCH", "trace.expectedRevision");
  const selected = /* @__PURE__ */ new Set();
  if (trace)
    for (const id of trace.ids) {
      for (const step of scanUnicode(id, "INVALID_OPTIONS", "trace.ids"))
        yield charge9(step.workUnits);
      yield charge9(id.length + 1);
      selected.add(id);
    }
  const collector = trace ? new FactCollector(trace.maxFacts) : void 0;
  boundary("analysis");
  const expansion = root.configuration.capabilities?.ordered.some((registration) => registration.expansion) ? createExpansionResolver(root, charge9) : void 0;
  const analyze = createAnalysis(root.configuration, check2);
  const compiled = yield* compileQuery(query, root.configuration, charge9, expansion, analyze);
  boundary("expansion");
  const expansions = yield* expandGroups(root, compiled.groups, charge9, boundary);
  const extensions = root.configuration.capabilities ? yield* prepareRefinements(compiled.node, root, charge9, options, analyze) : void 0;
  boundary("candidates");
  const bound2 = yield* candidateBound(compiled.node, expansions, charge9);
  const documents = yield* candidateDocuments(root, bound2, selected, charge9);
  const page = new PageSelection(options.limit ? options.offset + options.limit : 0, charge9);
  const ranking = rankingContext(root);
  let total = 0;
  for (const [id, doc] of documents) {
    const candidate = !bound2 || bound2.has(id);
    boundary("evaluation");
    yield charge9(id.length + 1);
    if (doc.id !== id)
      invalid("INTERNAL_ERROR", "index.documents");
    const facts = selected.has(id) ? collector : void 0;
    const qualified = yield* evaluate(compiled.node, doc, expansions, charge9, facts, "query", extensions?.leaves);
    boundary("scoring");
    const score = qualified.matched ? yield* scoreDocument(root, doc, qualified.groups, expansions, charge9, facts, ranking) : 0;
    if (candidate && qualified.matched) {
      total++;
      if (extensions?.aggregations.length) {
        boundary("aggregation");
        for (const aggregation of extensions.aggregations)
          yield* aggregation.add(doc.metadata);
      }
      boundary("selection");
      yield* page.add({ id, score });
    }
    if (facts) {
      const groups = Object.freeze(yield* sortedStrings(qualified.groups, charge9));
      yield charge9(1);
      facts.record({ kind: "document", id, exists: true, matched: qualified.matched, groups, score });
    }
  }
  if (collector)
    for (const id of selected) {
      yield charge9(id.length + 1);
      if (!directoryGet(root.documents, id))
        collector.record({ kind: "document", id, exists: false, matched: false, groups: Object.freeze([]), score: 0 });
    }
  boundary("selection");
  const hits = yield* page.finish(options.offset, options.limit);
  let additional = expansion?.finish();
  if (extensions?.aggregations.length) {
    boundary("aggregation");
    const result2 = /* @__PURE__ */ Object.create(null);
    for (const aggregation of extensions.aggregations)
      result2[aggregation.capability] = yield* aggregation.finish();
    additional = Object.freeze({ ...additional, ...result2 });
  }
  const scoreTrace = collector?.finish(root.revision, root.configuration.analyzer, compiled.key);
  if (extensions?.outputs.length) {
    boundary("aggregation");
    const result2 = /* @__PURE__ */ Object.create(null);
    for (const output of extensions.outputs)
      result2[output.capability] = yield* output.finish();
    additional = Object.freeze({ ...additional, ...result2 });
  }
  if (extensions?.evidence) {
    boundary("aggregation");
    if (!scoreTrace)
      invalid("INTERNAL_ERROR", "extensions.evidence");
    const publicResult = Object.freeze({ revision: root.revision, model: "raveldex-bm25-v1", completeness: "complete", total, hits, ...additional ? { extensions: additional } : {} });
    const value = yield* extensions.evidence.finish(Object.freeze({
      query: compiled.node,
      trace: scoreTrace,
      result: publicResult,
      counts: root.counts,
      searchWorkUnits: budget.consumed,
      maxSearchWorkUnits: root.configuration.limits.maxSearchWorkUnits,
      capabilities: Object.freeze(root.configuration.capabilities.ordered.map((registration) => registration.manifest))
    }));
    additional = Object.freeze({ ...additional, [extensions.evidence.capability]: value });
  }
  boundary("result");
  yield charge9(1);
  const result = Object.freeze({
    revision: root.revision,
    model: "raveldex-bm25-v1",
    completeness: "complete",
    total,
    hits,
    ...scoreTrace && !request.evidence ? { trace: scoreTrace } : {},
    ...additional ? { extensions: additional } : {}
  });
  check2();
  return result;
}

// node_modules/@vmitsaras/raveldex/dist/core/execution/host.js
function directHost() {
  const host = globalThis;
  if (typeof host.performance?.now !== "function" || typeof host.setTimeout !== "function" || typeof host.clearTimeout !== "function")
    invalid("INTERNAL_ERROR", "execution.host");
  const now = host.performance.now.bind(host.performance);
  const schedule = host.setTimeout.bind(host), cancel = host.clearTimeout.bind(host);
  let immediate, clearImmediate, Channel;
  try {
    const make = host.setImmediate, clear = host.clearImmediate;
    if (typeof make === "function" && typeof clear === "function") {
      immediate = make.bind(host);
      clearImmediate = clear.bind(host);
    }
  } catch {
  }
  if (!immediate)
    try {
      const Constructor = host.MessageChannel;
      if (typeof Constructor === "function")
        Channel = Constructor;
    } catch {
    }
  const pending = /* @__PURE__ */ new Set();
  let disposed = false, fastCount = 0;
  let channel;
  function closeChannel(current) {
    if (channel !== current)
      return;
    channel = void 0;
    current.callbacks.clear();
    try {
      current.ports.port1.onmessage = null;
    } catch {
    }
    current.close();
  }
  function message(callback) {
    if (!channel) {
      let ports;
      try {
        ports = new Channel();
        const first = ports.port1, second = ports.port2;
        const closeFirst = first.close.bind(first), closeSecond = second.close.bind(second);
        const current2 = { ports, post: second.postMessage.bind(second), close() {
          for (const close of [closeFirst, closeSecond])
            try {
              close();
            } catch {
            }
        }, callbacks: /* @__PURE__ */ new Map(), sequence: 0 };
        first.onmessage = (event) => {
          if (disposed || channel !== current2)
            return;
          const id2 = event.data;
          if (typeof id2 !== "number")
            return;
          const run = current2.callbacks.get(id2);
          current2.callbacks.delete(id2);
          try {
            run?.();
          } finally {
            if (!current2.callbacks.size)
              closeChannel(current2);
          }
        };
        channel = current2;
      } catch {
        Channel = void 0;
        for (const port of [ports?.port1, ports?.port2])
          if (port) {
            try {
              port.onmessage = null;
            } catch {
            }
            try {
              port.close();
            } catch {
            }
          }
        return void 0;
      }
    }
    const current = channel, id = ++current.sequence;
    current.callbacks.set(id, callback);
    try {
      current.post(id);
    } catch (error) {
      current.callbacks.delete(id);
      if (!current.callbacks.size)
        closeChannel(current);
      throw error;
    }
    return () => {
      current.callbacks.delete(id);
      if (!current.callbacks.size)
        closeChannel(current);
    };
  }
  return Object.freeze({ now, schedule(callback, delayMs) {
    const handle = schedule(callback, delayMs);
    return () => cancel(handle);
  }, continuation(input) {
    if (disposed)
      invalid("INTERNAL_ERROR", "execution.host");
    let callback = input, handle;
    const remove = () => {
      pending.delete(stop);
    };
    const run = () => {
      const invoke = callback;
      callback = void 0;
      handle = void 0;
      remove();
      if (!disposed)
        invoke?.();
    };
    const stop = () => {
      callback = void 0;
      const cancelHandle = handle;
      handle = void 0;
      remove();
      cancelHandle?.();
    };
    pending.add(stop);
    try {
      const timerTurn = ++fastCount === 8;
      if (timerTurn)
        fastCount = 0;
      if (!timerTurn && immediate) {
        const id = immediate(run);
        handle = () => clearImmediate(id);
      } else if (!timerTurn && Channel)
        handle = message(run);
      if (!handle) {
        const id = schedule(run, 0);
        handle = () => cancel(id);
      }
    } catch (error) {
      stop();
      throw error;
    }
    return stop;
  }, dispose() {
    if (disposed)
      return;
    disposed = true;
    for (const stop of [...pending])
      try {
        stop();
      } catch {
      }
    if (channel)
      closeChannel(channel);
  } });
}

// node_modules/@vmitsaras/raveldex/dist/core/execution/engine.js
function emptyRoot(configuration, states = Object.freeze(/* @__PURE__ */ Object.create(null))) {
  const fields2 = /* @__PURE__ */ Object.create(null);
  for (const name2 of Object.keys(configuration.schema.text))
    fields2[name2] = Object.freeze({ documents: 0, length: 0, terms: emptyDirectory(), order: null });
  return Object.freeze({
    configuration,
    revision: 0,
    documents: emptyDirectory(),
    fields: Object.freeze(fields2),
    counts: Object.freeze({ documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 }),
    participants: states
  });
}
var ExecutionOwner = class {
  #owner;
  #configuration;
  #host;
  #metrics;
  #queue = [];
  #active;
  #closing = false;
  #pumping = false;
  #disposal;
  #disposed;
  #hostReleased = false;
  constructor(root, host, participants = [], metrics) {
    this.#owner = new MutationOwner(root, participants);
    this.#configuration = root.configuration;
    this.#metrics = metrics;
    const schedule = host.schedule.bind(host), continuation = host.continuation, dispose = host.dispose;
    this.#host = Object.freeze({
      now: host.now.bind(host),
      schedule,
      continuation: continuation ? continuation.bind(host) : (callback) => schedule(callback, 0),
      ...dispose ? { dispose: dispose.bind(host) } : {}
    });
  }
  get root() {
    return this.#owner?.root;
  }
  adapterOperation(capture, control) {
    return this.admit(() => {
      const request = capture(this.#configuration);
      return { options: request.options, start: (check2) => {
        const owner = this.#owner, previous = owner.root;
        return request.start(previous, check2, (root) => owner.publishPrepared(root, previous));
      } };
    }, control);
  }
  adapterReplace(capture) {
    return this.admit(() => {
      const request = capture(this.#configuration);
      return { options: request.options, start: (check2) => {
        const owner = this.#owner, maximum = this.#configuration.limits.maxMutationWorkUnits;
        return (function* () {
          const budget = new WorkBudget(maximum);
          function* metered2(cursor) {
            let finished = false;
            try {
              for (; ; ) {
                check2("patch");
                const step = cursor.next();
                if (step.done) {
                  finished = true;
                  return step.value;
                }
                check2("patch");
                budget.charge(step.value.workUnits);
                yield step.value;
              }
            } finally {
              if (!finished) {
                try {
                  cursor.return(void 0);
                } catch {
                }
              }
            }
          }
          const record = yield* metered2(request.start(owner.root, check2));
          check2("patch.replace");
          const replacement = owner.capture("replace", record, request.options);
          check2("patch.replace");
          return yield* metered2(owner.execute(replacement, { checkStop: check2 }));
        })();
      } };
    });
  }
  search(query, options) {
    return this.searchControlled(query, options);
  }
  searchControlled(query, options, control) {
    return this.admit(() => {
      const request = captureSearch(this.#configuration, query, options);
      return { options: request.options, start: (check2) => executeOwnedSearch(this.#owner.root, request, { checkStop: check2 }) };
    }, control);
  }
  add(record, options) {
    return this.mutate("add", record, options);
  }
  addMany(records, options) {
    return this.mutate("addMany", records, options);
  }
  replace(record, options) {
    return this.mutate("replace", record, options);
  }
  remove(ids, options) {
    return this.mutate("remove", ids, options);
  }
  clear(options) {
    return this.mutate("clear", void 0, options);
  }
  mutate(kind, input, options) {
    return this.mutateControlled(kind, input, options);
  }
  mutateControlled(kind, input, options, control) {
    return this.admit(() => {
      const request = this.#owner.capture(kind, input, options);
      return { options: request.options, start: (check2) => this.#owner.execute(request, { checkStop: check2 }) };
    }, control);
  }
  check(op, phase) {
    if (this.#metrics) {
      this.#metrics.checks++;
      if (phase)
        this.#metrics.phaseChecks[phase] = (this.#metrics.phaseChecks[phase] ?? 0) + 1;
    }
    if (this.#closing)
      invalid("DISPOSED", "execution");
    const aborted = op.options?.signal?.aborted;
    const expired = this.#host.now() >= op.deadline;
    if (this.#closing)
      invalid("DISPOSED", "execution");
    if (aborted || op.cancelled)
      invalid("CANCELLED", "options.signal");
    if (expired)
      invalid("DEADLINE_EXCEEDED", "options.deadlineMs");
  }
  admit(capture, control) {
    try {
      if (this.#closing)
        invalid("DISPOSED", "execution");
      const admittedAt = this.#host.now();
      const request = capture();
      if (control) {
        if (!Number.isFinite(control.elapsedMs) || control.elapsedMs < 0)
          invalid("INTERNAL_ERROR", "execution.control");
        request.options = Object.freeze({ ...request.options, signal: control.signal });
      }
      if (this.#closing)
        invalid("DISPOSED", "execution");
      if (request.options.signal?.aborted)
        invalid("CANCELLED", "options.signal");
      if (control && control.elapsedMs >= request.options.deadlineMs)
        invalid("DEADLINE_EXCEEDED", "options.deadlineMs");
      if (this.#active && this.#queue.length >= this.#configuration.limits.maxQueuedOperations)
        invalid("QUEUE_FULL", "execution.queue");
      let resolve, reject;
      const promise = new Promise((yes, no) => {
        resolve = yes;
        reject = no;
      });
      const op = {
        options: request.options,
        start: void 0,
        cursor: void 0,
        resolve,
        reject,
        deadline: admittedAt + request.options.deadlineMs - (control?.elapsedMs ?? 0),
        detach: void 0,
        timer: void 0,
        resume: void 0,
        settled: false,
        executing: false,
        cancelled: false
      };
      op.start = () => request.start((phase) => this.check(op, phase));
      if (this.#active)
        this.#queue.push(op);
      else
        this.#active = op;
      try {
        const signal = op.options.signal;
        if (signal) {
          const stop = () => {
            op.cancelled = true;
            this.stop(op);
          };
          op.detach = () => signal.removeEventListener("abort", stop);
          signal.addEventListener("abort", stop, { once: true });
          if (op.settled) {
            try {
              signal.removeEventListener("abort", stop);
            } catch {
            }
          }
        }
        if (!op.settled) {
          this.check(op);
          op.timer = this.#host.schedule(() => {
            op.timer = void 0;
            this.stop(op);
          }, Math.max(0, op.deadline - this.#host.now()));
        }
      } catch (error) {
        this.finish(op, void 0, this.error(error));
      }
      this.pump();
      return promise;
    } catch (error) {
      return Promise.reject(this.error(error));
    }
  }
  /** Event/timer stop while suspended closes staging immediately; running code checks cooperatively. */
  stop(op) {
    if (op.settled || op.executing)
      return;
    try {
      this.check(op);
      op.timer?.();
      op.timer = this.#host.schedule(() => {
        op.timer = void 0;
        this.stop(op);
      }, Math.max(0, op.deadline - this.#host.now()));
    } catch (error) {
      this.finish(op, void 0, this.error(error));
      this.pump();
    }
  }
  pump() {
    if (this.#pumping)
      return;
    this.#pumping = true;
    let consumed = 0;
    try {
      for (; ; ) {
        if (!this.#active)
          this.#active = this.#queue.shift();
        const op = this.#active;
        if (!op || op.resume)
          break;
        op.executing = true;
        try {
          this.check(op);
          op.cursor ??= op.start();
          op.start = void 0;
          for (; ; ) {
            this.check(op);
            const step = op.cursor.next();
            if (step.done) {
              this.finish(op, step.value);
              break;
            }
            consumed += step.value.workUnits;
            if (this.#metrics) {
              this.#metrics.workUnits += step.value.workUnits;
              this.#metrics.steps++;
              this.#metrics.maxStepWorkUnits = Math.max(this.#metrics.maxStepWorkUnits, step.value.workUnits);
              this.#metrics.maxTaskWorkUnits = Math.max(this.#metrics.maxTaskWorkUnits, consumed);
            }
            if (consumed >= this.#configuration.limits.checkpointWorkUnits) {
              this.check(op);
              op.resume = this.#host.continuation(() => {
                op.resume = void 0;
                this.pump();
              });
              if (this.#metrics)
                this.#metrics.hostYields++;
              break;
            }
          }
        } catch (error) {
          this.finish(op, void 0, this.error(error));
        } finally {
          op.executing = false;
        }
        if (this.#active === op)
          break;
      }
    } finally {
      this.#pumping = false;
      this.release();
    }
  }
  error(error) {
    return error instanceof RaveldexError ? error : new RaveldexError("INTERNAL_ERROR");
  }
  finish(op, result, failure) {
    if (op.settled)
      return;
    op.settled = true;
    const resolve = op.resolve, reject = op.reject;
    const cursor = op.cursor;
    op.options = void 0;
    op.start = void 0;
    op.cursor = void 0;
    op.resolve = void 0;
    op.reject = void 0;
    if (failure !== void 0) {
      try {
        cursor?.return(void 0);
      } catch {
      }
    }
    for (const cleanup of [op.resume, op.timer, op.detach]) {
      try {
        cleanup?.();
      } catch {
      }
    }
    op.resume = void 0;
    op.timer = void 0;
    op.detach = void 0;
    if (this.#active === op)
      this.#active = void 0;
    else
      this.#queue = this.#queue.filter((item) => item !== op);
    if (failure !== void 0)
      reject(this.error(failure));
    else
      resolve(result);
    this.release();
  }
  dispose() {
    if (this.#disposal)
      return this.#disposal;
    this.#closing = true;
    this.#disposal = new Promise((resolve) => {
      this.#disposed = resolve;
    });
    for (const op of [...this.#queue])
      this.finish(op, void 0, new RaveldexError("DISPOSED"));
    if (this.#active && !this.#active.executing)
      this.finish(this.#active, void 0, new RaveldexError("DISPOSED"));
    this.release();
    return this.#disposal;
  }
  release() {
    if (this.#closing && !this.#active && this.#queue.length === 0) {
      this.#owner = void 0;
      if (!this.#hostReleased) {
        this.#hostReleased = true;
        try {
          this.#host.dispose?.();
        } catch {
        }
      }
      const resolve = this.#disposed;
      this.#disposed = void 0;
      resolve?.();
    }
  }
};
var executionOwners = /* @__PURE__ */ new WeakMap();
function getExecutionOwner(engine) {
  return executionOwners.get(engine);
}
function facadeFromExecutionOwner(owner) {
  const facade = Object.freeze({
    search: owner.search.bind(owner),
    add: owner.add.bind(owner),
    addMany: owner.addMany.bind(owner),
    replace: owner.replace.bind(owner),
    remove: owner.remove.bind(owner),
    clear: owner.clear.bind(owner),
    dispose: owner.dispose.bind(owner)
  });
  executionOwners.set(facade, owner);
  return facade;
}

// node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/bulk.js
function* reconstructSource(records, configuration, check2) {
  const states = /* @__PURE__ */ Object.create(null);
  const participants = (configuration.capabilities?.ordered ?? []).flatMap((registration) => {
    if (!registration.participant)
      return [];
    const id = registration.manifest.id, handle = registration.participant;
    states[id] = handle.initialize(configuration);
    const maximum = Math.min(registration.manifest.limits.maxWorkUnits, configuration.limits.maxMutationWorkUnits);
    return [{ id, handle, maximum, budget: new WorkBudget(maximum), bulk: bulkParticipant(registration, states[id]) }];
  });
  globalThis.__rx9002BulkTrace?.({ event: "participants", records: records.length, participants: participants.map((p) => ({ id: p.id, bulk: !!p.bulk })) });
  const old = emptyRoot(configuration, Object.freeze(states));
  const analyze = createAnalysis(configuration, check2);
  let phase = "snapshot.source.admission";
  const boundary = (next) => {
    phase = next;
    check2(phase);
  };
  let budget = new WorkBudget(configuration.limits.maxMutationWorkUnits);
  const charge9 = (workUnits) => {
    check2(phase);
    budget.charge(workUnits);
    return { workUnits };
  };
  const delta = new CoreDelta(old, charge9);
  let revision = 0, currentStates = old.participants;
  for (const record of records) {
    yield { workUnits: 1 };
    boundary("snapshot.source.admission");
    const request = captureMutation(configuration, "add", record);
    budget = new WorkBudget(configuration.limits.maxMutationWorkUnits);
    const owned = request.records[0];
    yield charge9(owned.id.length + 1);
    if (delta.hasDocument(owned.id))
      invalid("ID_EXISTS", "record.id");
    boundary("snapshot.source.analysis");
    const document = yield* prepareDocument(owned, configuration.limits, charge9, void 0, analyze);
    boundary("snapshot.source.core");
    yield* delta.apply({ next: document });
    yield charge9(5);
    delta.checkCounts();
    const nextStates = /* @__PURE__ */ Object.create(null);
    for (const participant of participants) {
      boundary("snapshot.source.participant");
      yield charge9(participant.id.length + 1);
      const invocation = new WorkBudget(participant.maximum);
      const context = Object.freeze({ analyze, kind: "add", previousRevision: revision, revision: revision + 1, analyzer: configuration.analyzer, records: request.records, removedIds: Object.freeze([]) });
      globalThis.__rx9002BulkTrace?.({ event: "add", id: participant.id, bulk: !!participant.bulk });
      const cursor = participant.bulk ? participant.bulk.add(context) : participant.handle.prepare(currentStates[participant.id], context);
      try {
        for (; ; ) {
          const step = cursor.next();
          if (step.done) {
            nextStates[participant.id] = participant.bulk ? currentStates[participant.id] : step.value;
            break;
          }
          participant.budget.charge(step.value.workUnits);
          const charged = charge9(step.value.workUnits);
          invocation.charge(step.value.workUnits);
          yield charged;
        }
      } finally {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    }
    currentStates = Object.freeze(nextStates);
    revision++;
    yield charge9(1);
    check2();
  }
  budget = new WorkBudget(configuration.limits.maxMutationWorkUnits);
  boundary("snapshot.source.finalization");
  const core = yield* delta.finish();
  const finalStates = { ...currentStates };
  for (const participant of participants) {
    if (!participant.bulk)
      continue;
    boundary("snapshot.source.participant-finalization");
    yield charge9(participant.id.length + 1);
    const invocation = new WorkBudget(participant.maximum);
    globalThis.__rx9002BulkTrace?.({ event: "finish", id: participant.id });
    const cursor = participant.bulk.finish(revision);
    try {
      for (; ; ) {
        const step = cursor.next();
        if (step.done) {
          finalStates[participant.id] = step.value;
          break;
        }
        participant.budget.charge(step.value.workUnits);
        const charged = charge9(step.value.workUnits);
        invocation.charge(step.value.workUnits);
        yield charged;
      }
    } finally {
      try {
        cursor.return(void 0);
      } catch {
      }
    }
  }
  return Object.freeze({ ...core, configuration, revision, participants: Object.freeze(finalStates) });
}

// node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/error.js
var SNAPSHOT_REASONS = Object.freeze([
  "MALFORMED_SNAPSHOT",
  "ENCODED_LIMIT_EXCEEDED",
  "INTEGRITY_MISMATCH",
  "UNSUPPORTED_FORMAT",
  "UNSUPPORTED_CODEC",
  "SCHEMA_MISMATCH",
  "ANALYZER_MISMATCH",
  "RANKING_MISMATCH",
  "CAPABILITY_MISMATCH",
  "INDEX_DETAIL_MISMATCH",
  "LIMITS_MISMATCH",
  "SOURCE_UNAVAILABLE",
  "UNQUALIFIED_PROFILE",
  "PROFILE_MISMATCH",
  "INVALID_NATIVE_STATE",
  "UNSUPPORTED_ENGINE"
]);
var SnapshotAdapterError = class extends RaveldexError {
  reason;
  constructor(reason, path = "snapshot") {
    super(reason === "ENCODED_LIMIT_EXCEEDED" ? "LIMIT_EXCEEDED" : reason === "SOURCE_UNAVAILABLE" || reason === "UNSUPPORTED_ENGINE" ? "MISSING_CAPABILITY" : "INCOMPATIBLE_CAPABILITY", { path });
    this.name = "SnapshotAdapterError";
    this.reason = reason;
  }
};
function fail(reason, path) {
  throw new SnapshotAdapterError(reason, path);
}

// node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/qualification.js
function currentNodeSnapshotEnvironment() {
  const process = globalThis.process;
  const versions = process?.versions;
  if (!versions || ["node", "v8", "icu", "unicode"].some((key) => typeof versions[key] !== "string") || typeof process?.platform !== "string" || typeof process?.arch !== "string")
    fail("UNQUALIFIED_PROFILE", "snapshot.environment");
  return Object.freeze({
    runtime: "node",
    version: versions.node,
    v8: versions.v8,
    icu: versions.icu,
    unicode: versions.unicode,
    platform: process.platform,
    arch: process.arch
  });
}
function captureQualification(input, matchCurrent = true) {
  const admission = new Admission(256), code = "INVALID_OPTIONS";
  const data2 = ownObject(input, code, "snapshot.qualification", admission);
  keysOnly(data2, ["profileId", "scope", "environment", "evidence"], code, "snapshot.qualification");
  if (typeof data2.profileId !== "string" || !/^[A-Za-z][A-Za-z0-9:._-]{0,127}$/.test(data2.profileId) || data2.profileId === "unqualified" || data2.scope !== "exact-node-runtime")
    invalid(code, "snapshot.qualification");
  const environment = ownObject(data2.environment, code, "snapshot.environment", admission);
  const keys = ["runtime", "version", "v8", "icu", "unicode", "platform", "arch"];
  keysOnly(environment, keys, code, "snapshot.environment");
  for (const key of keys) {
    if (!has(environment, key) || typeof environment[key] !== "string" || !environment[key].length || environment[key].length > 128)
      invalid(code, "snapshot.environment");
    for (const step of scanUnicode(environment[key], code, "snapshot.environment")) {
      void step;
    }
  }
  if (environment.runtime !== "node")
    invalid(code, "snapshot.environment");
  const ownedEnvironment = Object.freeze(environment);
  if (matchCurrent) {
    const current = currentNodeSnapshotEnvironment();
    for (const key of keys)
      if (ownedEnvironment[key] !== current[key])
        fail("PROFILE_MISMATCH", "snapshot.environment");
  }
  const evidence = ownArray(data2.evidence, 32, code, "snapshot.evidence", admission).map((value) => {
    if (typeof value !== "string" || !value.trim().length || value.length > 256)
      invalid(code, "snapshot.evidence");
    for (const step of scanUnicode(value, code, "snapshot.evidence")) {
      void step;
    }
    return value;
  });
  if (!evidence.length || new Set(evidence).size !== evidence.length)
    invalid(code, "snapshot.evidence");
  return Object.freeze({ profileId: data2.profileId, scope: "exact-node-runtime", environment: ownedEnvironment, evidence: Object.freeze(evidence) });
}

// node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/json.js
var MAX_ENCODED_BYTES = 64 * 1024 * 1024;
var MAX_DEPTH = 64;
var MAX_NODES = 8e6;
var MAX_STRING = 262144;
var HEX = /^[0-9a-f]{8}$/;
function* utf8Bytes(text2, maximum) {
  let bytes = 0, units = 0;
  for (let i = 0; i < text2.length; i++) {
    const point = text2.charCodeAt(i);
    if (point < 128)
      bytes++;
    else if (point < 2048)
      bytes += 2;
    else if (point >= 55296 && point <= 56319) {
      const next = text2.charCodeAt(++i);
      if (!(next >= 56320 && next <= 57343))
        fail("MALFORMED_SNAPSHOT");
      bytes += 4;
    } else {
      if (point >= 56320 && point <= 57343)
        fail("MALFORMED_SNAPSHOT");
      bytes += 3;
    }
    if (bytes > maximum)
      fail("ENCODED_LIMIT_EXCEEDED");
    if (++units === 256) {
      yield { workUnits: units };
      units = 0;
    }
  }
  if (units)
    yield { workUnits: units };
  return bytes;
}
function* checksum(text2) {
  let hash = 2166136261, units = 0;
  for (let i = 0; i < text2.length; i++) {
    hash = Math.imul(hash ^ text2.charCodeAt(i), 16777619);
    if (++units === 256) {
      yield { workUnits: units };
      units = 0;
    }
  }
  if (units)
    yield { workUnits: units };
  return (hash >>> 0).toString(16).padStart(8, "0");
}
function* encodeJson(value, maximum) {
  const chunks = [], active = /* @__PURE__ */ new Set();
  let bytes = 0, nodes = 0;
  function* append(text2) {
    bytes += yield* utf8Bytes(text2, maximum - bytes);
    chunks.push(text2);
  }
  function* visit(value2, depth) {
    yield { workUnits: 1 };
    if (++nodes > MAX_NODES || depth > MAX_DEPTH)
      fail("ENCODED_LIMIT_EXCEEDED");
    if (value2 === null || typeof value2 === "boolean") {
      yield* append(String(value2));
      return;
    }
    if (typeof value2 === "number") {
      if (!Number.isFinite(value2))
        fail("INVALID_NATIVE_STATE");
      yield* append(JSON.stringify(value2));
      return;
    }
    if (typeof value2 === "string") {
      if (value2.length > MAX_STRING)
        fail("ENCODED_LIMIT_EXCEEDED");
      for (const step of scanUnicode(value2, "INCOMPATIBLE_CAPABILITY", "snapshot.string"))
        yield step;
      yield* append(JSON.stringify(value2));
      return;
    }
    if (typeof value2 !== "object" || active.has(value2))
      fail("INVALID_NATIVE_STATE");
    active.add(value2);
    try {
      if (Array.isArray(value2)) {
        if (value2.length > MAX_NODES)
          fail("ENCODED_LIMIT_EXCEEDED");
        if (!Object.isFrozen(value2) || Reflect.ownKeys(value2).length !== value2.length + 1)
          fail("INVALID_NATIVE_STATE");
        yield* append("[");
        for (let i = 0; i < value2.length; i++) {
          const descriptor = Object.getOwnPropertyDescriptor(value2, String(i));
          if (!descriptor || !("value" in descriptor))
            fail("INVALID_NATIVE_STATE");
          if (i)
            yield* append(",");
          yield* visit(descriptor.value, depth + 1);
        }
        yield* append("]");
      } else {
        const prototype = Object.getPrototypeOf(value2);
        if (prototype !== null && prototype !== Object.prototype || !Object.isFrozen(value2))
          fail("INVALID_NATIVE_STATE");
        const keys = Object.keys(value2);
        if (Reflect.ownKeys(value2).length !== keys.length)
          fail("INVALID_NATIVE_STATE");
        for (const key of keys)
          yield { workUnits: key.length + Math.ceil(Math.log2(keys.length + 1)) + 1 };
        keys.sort();
        yield* append("{");
        for (let i = 0; i < keys.length; i++) {
          const key = keys[i], descriptor = Object.getOwnPropertyDescriptor(value2, key);
          if (!descriptor || !("value" in descriptor))
            fail("INVALID_NATIVE_STATE");
          if (i)
            yield* append(",");
          yield* visit(key, depth + 1);
          yield* append(":");
          yield* visit(descriptor.value, depth + 1);
        }
        yield* append("}");
      }
    } finally {
      active.delete(value2);
    }
  }
  yield* visit(value, 0);
  yield { workUnits: 1 };
  return chunks.join("");
}
function* decodeJson(text2, maximum) {
  yield* utf8Bytes(text2, maximum);
  let position = 0, nodes = 0, bodyStart = -1, bodyEnd = -1, uncharged = 0;
  function* step() {
    if (++uncharged >= 128) {
      yield { workUnits: uncharged };
      uncharged = 0;
    }
  }
  function* whitespace() {
    while (position < text2.length && /[\x20\t\r\n]/.test(text2[position])) {
      position++;
      yield* step();
    }
  }
  function* string() {
    if (text2[position++] !== '"')
      fail("MALFORMED_SNAPSHOT");
    let value2 = "", pieces = [];
    for (; ; ) {
      if (position >= text2.length)
        fail("MALFORMED_SNAPSHOT");
      const character = text2[position++];
      yield* step();
      if (character === '"')
        break;
      if (character.charCodeAt(0) < 32)
        fail("MALFORMED_SNAPSHOT");
      if (character === "\\") {
        const escaped = text2[position++];
        yield* step();
        const simple = { '"': '"', "\\": "\\", "/": "/", b: "\b", f: "\f", n: "\n", r: "\r", t: "	" };
        if (Object.hasOwn(simple, escaped))
          value2 += simple[escaped];
        else if (escaped === "u") {
          const digits = text2.slice(position, position + 4);
          if (!/^[0-9a-fA-F]{4}$/.test(digits))
            fail("MALFORMED_SNAPSHOT");
          value2 += String.fromCharCode(parseInt(digits, 16));
          position += 4;
          uncharged += 4;
        } else
          fail("MALFORMED_SNAPSHOT");
      } else
        value2 += character;
      if (value2.length >= 1024) {
        pieces.push(value2);
        value2 = "";
      }
      if (pieces.length * 1024 + value2.length > MAX_STRING)
        fail("ENCODED_LIMIT_EXCEEDED");
    }
    pieces.push(value2);
    value2 = pieces.join("");
    pieces = [];
    if (value2.length > MAX_STRING)
      fail("ENCODED_LIMIT_EXCEEDED");
    for (const item of scanUnicode(value2, "INCOMPATIBLE_CAPABILITY", "snapshot.string"))
      yield item;
    return value2;
  }
  function* visit(depth) {
    yield { workUnits: 1 };
    if (++nodes > MAX_NODES || depth > MAX_DEPTH)
      fail("ENCODED_LIMIT_EXCEEDED");
    yield* whitespace();
    const next = text2[position];
    if (next === '"')
      return yield* string();
    if (next === "{") {
      position++;
      yield* step();
      const result = /* @__PURE__ */ Object.create(null);
      yield* whitespace();
      if (text2[position] === "}") {
        position++;
        return Object.freeze(result);
      }
      for (; ; ) {
        yield* whitespace();
        const key = yield* string();
        if (Object.hasOwn(result, key))
          fail("MALFORMED_SNAPSHOT");
        yield* whitespace();
        if (text2[position++] !== ":")
          fail("MALFORMED_SNAPSHOT");
        yield* whitespace();
        const start2 = position;
        result[key] = yield* visit(depth + 1);
        if (depth === 0 && key === "body") {
          bodyStart = start2;
          bodyEnd = position;
        }
        yield* whitespace();
        const delimiter = text2[position++];
        if (delimiter === "}")
          break;
        if (delimiter !== ",")
          fail("MALFORMED_SNAPSHOT");
      }
      return Object.freeze(result);
    }
    if (next === "[") {
      position++;
      yield* step();
      const result = [];
      yield* whitespace();
      if (text2[position] === "]") {
        position++;
        return Object.freeze(result);
      }
      for (; ; ) {
        result.push(yield* visit(depth + 1));
        yield* whitespace();
        const delimiter = text2[position++];
        if (delimiter === "]")
          break;
        if (delimiter !== ",")
          fail("MALFORMED_SNAPSHOT");
      }
      return Object.freeze(result);
    }
    for (const [literal, value2] of [["true", true], ["false", false], ["null", null]]) {
      if (text2.slice(position, position + literal.length) === literal) {
        position += literal.length;
        uncharged += literal.length;
        return value2;
      }
    }
    const start = position;
    while (position < text2.length && /[0-9eE+.\-]/.test(text2[position])) {
      position++;
      if (position - start > 128)
        fail("MALFORMED_SNAPSHOT");
      yield* step();
    }
    const token = text2.slice(start, position);
    if (!/^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?$/.test(token))
      fail("MALFORMED_SNAPSHOT");
    const number = Number(token);
    if (!Number.isFinite(number))
      fail("MALFORMED_SNAPSHOT");
    return number;
  }
  const value = yield* visit(0);
  yield* whitespace();
  if (position !== text2.length || bodyStart < 0)
    fail("MALFORMED_SNAPSHOT");
  if (uncharged)
    yield { workUnits: uncharged };
  return Object.freeze({ value, bodyText: text2.slice(bodyStart, bodyEnd) });
}
function object(value, keys, reason = "MALFORMED_SNAPSHOT") {
  if (typeof value !== "object" || value === null || Array.isArray(value))
    fail(reason);
  const result = value;
  const prototype = Object.getPrototypeOf(result);
  if (prototype !== null && prototype !== Object.prototype || !Object.isFrozen(result) || Reflect.ownKeys(result).length !== keys.length || keys.some((key) => {
    const descriptor = Object.getOwnPropertyDescriptor(result, key);
    return !descriptor || !("value" in descriptor) || !descriptor.enumerable;
  }))
    fail(reason);
  return result;
}
function count(value, maximum, minimum = 0) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum)
    fail("INVALID_NATIVE_STATE");
  return value;
}
function isChecksum(value) {
  return typeof value === "string" && HEX.test(value);
}
function equalData(left, right) {
  if (left === right)
    return true;
  if (typeof left !== "object" || left === null || typeof right !== "object" || right === null)
    return false;
  if (Array.isArray(left) || Array.isArray(right))
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((value, index) => equalData(value, right[index]));
  const a = left, b = right, keys = Object.keys(a);
  return keys.length === Object.keys(b).length && keys.every((key) => Object.hasOwn(b, key) && equalData(a[key], b[key]));
}

// node_modules/@vmitsaras/raveldex/dist/core/index/invariants.js
function check(value, path) {
  if (!value)
    invalid("INTERNAL_ERROR", `index.${path}`);
}
function count2(value, path, positive = false) {
  check(Number.isSafeInteger(value) && value >= (positive ? 1 : 0), path);
}
function* inspectIndex(root) {
  const budget = new WorkBudget(root.configuration.limits.maxMutationWorkUnits);
  const charge9 = (workUnits) => {
    budget.charge(workUnits);
    return { workUnits };
  };
  function* directory2(data2) {
    count2(data2.size, "directory.size");
    check(Object.getPrototypeOf(data2.buckets) === null, "directory.prototype");
    let entries = 0;
    for (const [slot, bucket] of Object.entries(data2.buckets)) {
      yield charge9(1);
      check(Number.isInteger(Number(slot)) && Number(slot) >= 0 && Number(slot) < DIRECTORY_SLOTS && String(Number(slot)) === slot, "directory.slot");
      check(Object.getPrototypeOf(bucket) === null && Object.keys(bucket).length > 0, "directory.bucket");
      for (const key of Object.keys(bucket)) {
        yield charge9(key.length + 1);
        check(bucketOf(key) === slot, "directory.hash");
        entries++;
      }
    }
    check(entries === data2.size, "directory.size");
  }
  count2(root.revision, "revision");
  yield* directory2(root.documents);
  const counts = { documents: 0, textCodeUnits: 0, tokens: 0, dictionaryEntries: 0, postingEntries: 0 };
  const statistics = /* @__PURE__ */ Object.create(null);
  for (const field of Object.keys(root.configuration.schema.text))
    statistics[field] = { documents: 0, length: 0 };
  for (const [id, record] of directoryEntries(root.documents)) {
    yield charge9(id.length + 1);
    check(record.id === id, "documents.id");
    count2(record.textCodeUnits, "documents.textCodeUnits");
    counts.documents++;
    counts.textCodeUnits += record.textCodeUnits;
    for (const [name2, field] of Object.entries(record.fields)) {
      yield charge9(1);
      check(Object.hasOwn(statistics, name2), "reverse.field");
      count2(field.length, "reverse.length", true);
      let length = 0;
      for (const [term, tf] of Object.entries(field.terms)) {
        yield charge9(term.length + id.length + 2);
        count2(tf, "reverse.frequency", true);
        length += tf;
        const entry = root.fields[name2] && directoryGet(root.fields[name2].terms, term);
        check(entry !== void 0 && directoryGet(entry.postings, id) === tf, "reverse.posting");
      }
      check(length === field.length, "reverse.length");
      statistics[name2].documents++;
      statistics[name2].length += length;
      counts.tokens += length;
    }
  }
  check(Object.keys(root.fields).length === Object.keys(statistics).length, "fields.count");
  for (const [name2, field] of Object.entries(root.fields)) {
    yield charge9(1);
    const expected = statistics[name2];
    check(expected !== void 0, "fields.name");
    check(field.documents === expected.documents && field.length === expected.length, "fields.statistics");
    yield* directory2(field.terms);
    const seen = /* @__PURE__ */ new Set();
    function* order(node2, lower2, upper) {
      yield charge9(1);
      if (node2 === null)
        return 0;
      check(typeof node2 === "object" && node2 !== null && Object.isFrozen(node2) && !seen.has(node2), "order.node");
      seen.add(node2);
      check(typeof node2.key === "string", "order.key");
      yield charge9(node2.key.length + 1);
      check(directoryGet(field.terms, node2.key) !== void 0, "order.term");
      if (lower2 !== void 0)
        check((yield* compareStrings(lower2, node2.key, charge9)) < 0, "order.lower");
      if (upper !== void 0)
        check((yield* compareStrings(node2.key, upper, charge9)) < 0, "order.upper");
      const left = yield* order(node2.left, lower2, node2.key), right = yield* order(node2.right, node2.key, upper);
      check(node2.height === 1 + Math.max(left, right) && Math.abs(left - right) <= 1, "order.height");
      return node2.height;
    }
    yield* order(field.order);
    check(seen.size === field.terms.size, "order.size");
    for (const [term, entry] of directoryEntries(field.terms)) {
      yield charge9(term.length + 1);
      count2(entry.df, "terms.df", true);
      count2(entry.frequency, "terms.frequency", true);
      check(entry.df <= field.documents, "terms.df");
      yield* directory2(entry.postings);
      let df = 0, frequency = 0;
      for (const [id, tf] of directoryEntries(entry.postings)) {
        yield charge9(id.length + term.length + 2);
        count2(tf, "postings.frequency", true);
        const record = directoryGet(root.documents, id);
        check(record !== void 0 && record.fields[name2]?.terms[term] === tf, "postings.reverse");
        df++;
        frequency += tf;
      }
      check(entry.df === df && entry.frequency === frequency, "terms.statistics");
      counts.dictionaryEntries++;
      counts.postingEntries += df;
    }
  }
  for (const name2 of Object.keys(counts)) {
    yield charge9(1);
    check(root.counts[name2] === counts[name2], "corpus.statistics");
  }
  validateStateCounts(counts, root.configuration.limits);
}

// node_modules/@vmitsaras/raveldex/dist/addons/positions/tagged.js
var charge = (workUnits = 1) => ({ workUnits });
var count3 = (value, maximum) => Number.isSafeInteger(value) && value >= 0 && value <= maximum;
function data(input, keys, nullPrototype = false) {
  if (typeof input !== "object" || input === null || !Object.isFrozen(input) || Array.isArray(input) || nullPrototype && Object.getPrototypeOf(input) !== null)
    invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers");
  const result = input;
  if (Reflect.ownKeys(result).length > keys.length)
    invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers");
  for (const key of Reflect.ownKeys(result))
    if (typeof key !== "string" || !keys.includes(key) || !Object.hasOwn(Object.getOwnPropertyDescriptor(result, key), "value"))
      invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers");
  keysOnly(result, keys, "INCOMPATIBLE_CAPABILITY", "positions.identifiers");
  return result;
}
function* taggedPositionTokens(input, offsets, limits) {
  const value = data(input, ["tokenCount", "originalCount", "terms"]);
  if (!count3(value.tokenCount, limits.maxTokensPerRecord) || !count3(value.originalCount, value.tokenCount) || !has(value, "terms"))
    invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.counts");
  const tokenCount = value.tokenCount, originalCount = value.originalCount;
  if (typeof value.terms !== "object" || value.terms === null || !Object.isFrozen(value.terms) || Object.getPrototypeOf(value.terms) !== null)
    invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.terms");
  const terms = value.terms;
  const keys = Reflect.ownKeys(terms);
  yield charge(keys.length + 1);
  if (keys.length > tokenCount)
    invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.terms");
  const originals = /* @__PURE__ */ new Map(), byPosition = /* @__PURE__ */ new Map();
  let seen = 0;
  for (const term of keys) {
    if (typeof term !== "string" || !term.length || term.length > limits.maxTermCodeUnits)
      invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.term");
    yield* scanUnicode(term, "INCOMPATIBLE_CAPABILITY", "positions.identifiers.term");
    yield charge(term.length * 2 + 1);
    if (term.normalize("NFKC").toLowerCase() !== term)
      invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.term");
    const descriptor = Object.getOwnPropertyDescriptor(terms, term);
    if (!descriptor || !("value" in descriptor))
      invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.terms");
    const list = descriptor.value;
    if (!Array.isArray(list) || !Object.isFrozen(list) || !list.length || list.length > originalCount || Reflect.ownKeys(list).length !== list.length + 1)
      invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.occurrences");
    let last = -1;
    for (let index = 0; index < list.length; index++) {
      yield charge(7);
      const descriptor2 = Object.getOwnPropertyDescriptor(list, String(index));
      if (!descriptor2 || !("value" in descriptor2))
        invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.occurrences");
      const entry = data(descriptor2.value, offsets ? ["position", "positionLength", "kind", "start", "end"] : ["position", "positionLength", "kind"]);
      const { position, kind, start, end } = entry;
      if (!count3(position, originalCount - 1) || position <= last || entry.positionLength !== 1 || kind !== "original" && kind !== "component")
        invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.occurrence");
      if (offsets && (!count3(start, limits.maxTextCodeUnitsPerValue) || !count3(end, limits.maxTextCodeUnitsPerValue) || end <= start || end - start > limits.maxRawTokenCodeUnits))
        invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.offsets");
      const token = Object.freeze({ term, position, positionLength: 1, kind, ...offsets ? { start, end } : {} });
      if (kind === "original") {
        if (originals.has(position))
          invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.original");
        originals.set(position, token);
      }
      const siblings = byPosition.get(position) ?? [];
      siblings.push(token);
      byPosition.set(position, siblings);
      last = position;
      if (++seen > tokenCount)
        invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.counts");
    }
  }
  if (seen !== tokenCount || originals.size !== originalCount)
    invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.counts");
  const output = [];
  let previousEnd = 0;
  for (let position = 0; position < originalCount; position++) {
    yield charge();
    const original = originals.get(position);
    if (!original || offsets && original.start < previousEnd)
      invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.order");
    if (offsets)
      previousEnd = original.end;
    output.push(original);
    const sorted = [];
    for (const token of byPosition.get(position)) {
      yield charge();
      if (token.kind === "original")
        continue;
      if (token.term === original.term || offsets && (token.start < original.start || token.end > original.end))
        invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.component");
      let index = sorted.length;
      while (index > 0) {
        yield charge(token.term.length + sorted[index - 1].term.length + 1);
        const prior = sorted[index - 1];
        if (offsets ? prior.start < token.start || prior.start === token.start && prior.end <= token.end : prior.term <= token.term)
          break;
        index--;
      }
      sorted.splice(index, 0, token);
    }
    let componentEnd = original.start ?? 0;
    for (const token of sorted) {
      yield charge();
      if (offsets && (token.start < componentEnd || token.start === original.start && token.end === original.end))
        invalid("INCOMPATIBLE_CAPABILITY", "positions.identifiers.component");
      if (offsets)
        componentEnd = token.end;
      output.push(token);
    }
  }
  return Object.freeze(output);
}

// node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/native.js
function map(input) {
  if (typeof input !== "object" || input === null || Array.isArray(input) || Object.getPrototypeOf(input) !== null || !Object.isFrozen(input))
    fail("INVALID_NATIVE_STATE");
  const result = input;
  for (const key of Reflect.ownKeys(result)) {
    const descriptor = Object.getOwnPropertyDescriptor(result, key);
    if (typeof key !== "string" || !descriptor || !("value" in descriptor) || !descriptor.enumerable)
      fail("INVALID_NATIVE_STATE");
  }
  return result;
}
function fieldsEqual(input, expected) {
  return Array.isArray(input) && input.length === expected.length && input.every((value, index) => value === expected[index]);
}
function* unicode(value, maximum, nonempty = false) {
  if (typeof value !== "string" || value.length > maximum || nonempty && !value.length)
    fail("INVALID_NATIVE_STATE");
  yield* scanUnicode(value, "INCOMPATIBLE_CAPABILITY", "snapshot.native.string");
  return value;
}
function* canonicalTerm(value, maximum) {
  const term = yield* unicode(value, maximum, true);
  yield { workUnits: term.length + 1 };
  if (term.toLowerCase() !== term)
    fail("INVALID_NATIVE_STATE");
  return term;
}
function* directory(input, maximum, keyMaximum) {
  const data2 = object(input, ["size", "buckets"], "INVALID_NATIVE_STATE"), expectedSize = count(data2.size, maximum), buckets = map(data2.buckets);
  let size = 0;
  for (const [slot, raw] of Object.entries(buckets)) {
    yield { workUnits: 1 };
    if (!/^(0|[1-9][0-9]*)$/.test(slot) || Number(slot) > 255)
      fail("INVALID_NATIVE_STATE");
    const bucket = map(raw);
    if (!Object.keys(bucket).length)
      fail("INVALID_NATIVE_STATE");
    for (const key of Object.keys(bucket)) {
      yield* unicode(key, keyMaximum, true);
      yield { workUnits: key.length + 1 };
      if (bucketOf(key) !== slot || ++size > maximum)
        fail("INVALID_NATIVE_STATE");
    }
  }
  if (size !== expectedSize)
    fail("INVALID_NATIVE_STATE");
  return input;
}
function requireCodecs(configuration) {
  for (const registration of configuration.capabilities?.ordered ?? [])
    if (registration.participant) {
      const codec = registration.manifest.codec;
      if (!codec || codec.version !== 1 || !["raveldex-source-v1", "raveldex-positions-v1"].includes(codec.id))
        fail("UNSUPPORTED_CODEC", "snapshot.participants");
      const identity = registration.manifest.execution.workerRegistration;
      const family = codec.id === "raveldex-source-v1" ? "source" : "positions";
      if (!identity?.startsWith(`raveldex:${family}:1:`))
        fail("UNSUPPORTED_CODEC", "snapshot.participants");
    }
}
function* metadata(entry, configuration) {
  const owned = captureRecord({ id: entry.id, text: {}, metadata: entry.metadata }, configuration.schema, configuration.limits);
  for (const [field, raw] of Object.entries(owned.metadata)) {
    yield { workUnits: field.length + 1 };
    if (Array.isArray(raw) && new Set(raw).size !== raw.length)
      fail("INVALID_NATIVE_STATE");
    const original = entry.metadata[field];
    if (Array.isArray(raw) ? !Array.isArray(original) || raw.some((item, index) => !Object.is(item, original[index])) : !Object.is(raw, original))
      fail("INVALID_NATIVE_STATE");
    for (const item of Array.isArray(raw) ? raw : [raw])
      if (typeof item === "string")
        yield* unicode(item, configuration.limits.maxMetadataStringCodeUnits);
  }
}
function* validateNative(payload, configuration, revision, check2, liveFields) {
  requireCodecs(configuration);
  const analyze = createAnalysis(configuration, check2);
  const data2 = object(payload, ["documents", "fields", "counts", "participants"], "INVALID_NATIVE_STATE"), limits = configuration.limits;
  const documents = yield* directory(data2.documents, limits.maxDocuments, limits.maxIdCodeUnits);
  const fieldData = map(data2.fields), fieldNames2 = Object.keys(configuration.schema.text);
  if (Object.keys(fieldData).length !== fieldNames2.length || fieldNames2.some((name2) => !Object.hasOwn(fieldData, name2)))
    fail("INVALID_NATIVE_STATE");
  const counts = object(data2.counts, ["documents", "textCodeUnits", "tokens", "dictionaryEntries", "postingEntries"], "INVALID_NATIVE_STATE");
  for (const [name2, maximum] of [["documents", limits.maxDocuments], ["textCodeUnits", limits.maxCorpusTextCodeUnits], ["tokens", limits.maxCorpusTokens], ["dictionaryEntries", limits.maxDictionaryEntries], ["postingEntries", limits.maxPostingEntries]])
    count(counts[name2], maximum);
  for (const [id, entry] of directoryEntries(documents)) {
    object(entry, ["id", "textCodeUnits", "metadata", "fields"], "INVALID_NATIVE_STATE");
    yield* unicode(entry.id, limits.maxIdCodeUnits, true);
    if (entry.id !== id)
      fail("INVALID_NATIVE_STATE");
    count(entry.textCodeUnits, limits.maxTextCodeUnitsPerRecord);
    yield* metadata(entry, configuration);
    const fields2 = map(entry.fields);
    let tokens = 0;
    for (const [name2, raw] of Object.entries(fields2)) {
      if (!Object.hasOwn(configuration.schema.text, name2))
        fail("INVALID_NATIVE_STATE");
      const reverse = object(raw, ["length", "terms"], "INVALID_NATIVE_STATE"), terms = map(reverse.terms);
      tokens += count(reverse.length, limits.maxTokensPerRecord, 1);
      if (!Object.keys(terms).length || tokens > limits.maxTokensPerRecord)
        fail("INVALID_NATIVE_STATE");
      for (const [term, frequency] of Object.entries(terms)) {
        yield* canonicalTerm(term, limits.maxTermCodeUnits);
        count(frequency, limits.maxTokensPerRecord, 1);
      }
    }
    if (tokens > entry.textCodeUnits * (configuration.analyzer.id === "code-identifiers-v1" ? 2 : 1))
      fail("INVALID_NATIVE_STATE");
  }
  const restoredFields = /* @__PURE__ */ Object.create(null);
  for (const name2 of fieldNames2) {
    const field = object(fieldData[name2], ["documents", "length", "terms"], "INVALID_NATIVE_STATE");
    count(field.documents, limits.maxDocuments);
    count(field.length, limits.maxCorpusTokens);
    const terms = yield* directory(field.terms, limits.maxDictionaryEntries, limits.maxTermCodeUnits);
    if (liveFields && liveFields[name2]?.terms !== terms)
      fail("INVALID_NATIVE_STATE");
    let order = liveFields ? liveFields[name2].order : null;
    for (const [key, entry] of directoryEntries(terms)) {
      if (!liveFields)
        order = yield* updateTermOrder(order, key, true, (workUnits) => ({ workUnits }));
      object(entry, ["df", "frequency", "postings"], "INVALID_NATIVE_STATE");
      count(entry.df, limits.maxDocuments, 1);
      count(entry.frequency, limits.maxCorpusTokens, 1);
      const postings = yield* directory(entry.postings, limits.maxDocuments, limits.maxIdCodeUnits);
      for (const [, frequency] of directoryEntries(postings)) {
        yield { workUnits: 1 };
        count(frequency, limits.maxTokensPerRecord, 1);
      }
    }
    restoredFields[name2] = Object.freeze({ documents: field.documents, length: field.length, terms, order });
  }
  const participants = map(data2.participants);
  const expected = initializeParticipants(configuration).states;
  if (Object.keys(participants).length !== Object.keys(expected).length || Object.keys(expected).some((id) => !Object.hasOwn(participants, id)))
    fail("INVALID_NATIVE_STATE");
  const root = Object.freeze({ revision, configuration, documents, fields: Object.freeze(restoredFields), counts, participants });
  yield* inspectIndex(root);
  for (const registration of configuration.capabilities?.ordered ?? []) {
    if (!registration.participant)
      continue;
    const id = registration.manifest.id;
    const budget = new WorkBudget(Math.min(registration.manifest.limits.maxWorkUnits, limits.maxMutationWorkUnits));
    const cursor = registration.manifest.codec.id === "raveldex-source-v1" ? source(participants[id], expected[id], root, analyze) : positions(participants[id], expected[id], root, analyze);
    let finished = false;
    try {
      for (; ; ) {
        const step = cursor.next();
        if (step.done) {
          finished = true;
          break;
        }
        budget.charge(step.value.workUnits);
        yield step.value;
      }
    } finally {
      if (!finished) {
        try {
          cursor.return(void 0);
        } catch {
        }
      }
    }
  }
  const completeSource = fieldNames2.every((field) => !!configuration.capabilities?.providers[`source:${field}`]?.participant);
  if (completeSource)
    for (const [id, document] of directoryEntries(root.documents)) {
      let units = 0;
      for (const field of fieldNames2) {
        const provider = configuration.capabilities.providers[`source:${field}`], values = directoryGet(root.participants[provider.manifest.id].records, id).text[field];
        for (const value of values ?? []) {
          yield { workUnits: value.length + 1 };
          units += value.length;
        }
      }
      if (units !== document.textCodeUnits)
        fail("INVALID_NATIVE_STATE");
    }
  return root;
}
function* source(input, expected, core, analyze) {
  const data2 = object(input, ["kind", "revision", "analyzer", "fields", "records", "retainedEntries", "textCodeUnits", "maxRetainedEntries", "maxTextCodeUnits"], "INVALID_NATIVE_STATE");
  if (data2.kind !== expected.kind || data2.revision !== core.revision || !equalData(data2.analyzer, core.configuration.analyzer) || !fieldsEqual(data2.fields, expected.fields) || data2.maxRetainedEntries !== expected.maxRetainedEntries || data2.maxTextCodeUnits !== expected.maxTextCodeUnits)
    fail("INVALID_NATIVE_STATE");
  const records = yield* directory(data2.records, core.documents.size, core.configuration.limits.maxIdCodeUnits);
  if (records.size !== core.documents.size)
    fail("INVALID_NATIVE_STATE");
  let retainedEntries = 0, textCodeUnits = 0;
  for (const [id, entry] of directoryEntries(records)) {
    object(entry, ["text", "retainedEntries", "textCodeUnits"], "INVALID_NATIVE_STATE");
    const document = directoryGet(core.documents, id);
    if (!document)
      fail("INVALID_NATIVE_STATE");
    const text2 = map(entry.text);
    let entries = 1, units = 0;
    for (const field of Object.keys(text2)) {
      if (!expected.fields.includes(field))
        fail("INVALID_NATIVE_STATE");
      const values = text2[field];
      if (!Array.isArray(values) || values.length > core.configuration.limits.maxTextValuesPerField)
        fail("INVALID_NATIVE_STATE");
      entries += 1 + values.length;
      const terms = /* @__PURE__ */ Object.create(null);
      for (const value of values) {
        yield* unicode(value, core.configuration.limits.maxTextCodeUnitsPerValue);
        units += value.length;
        for (const step of analyze(value, 0, core.configuration.limits)) {
          yield { workUnits: step.workUnits };
          if (step.token)
            terms[step.token.term] = (terms[step.token.term] ?? 0) + 1;
        }
      }
      const reverse = document.fields[field];
      if (Object.keys(terms).length !== Object.keys(reverse?.terms ?? {}).length)
        fail("INVALID_NATIVE_STATE");
      for (const term of Object.keys(terms)) {
        yield { workUnits: term.length + 1 };
        if (terms[term] !== reverse?.terms[term])
          fail("INVALID_NATIVE_STATE");
      }
    }
    for (const field of expected.fields)
      if (!Object.hasOwn(text2, field) && document.fields[field])
        fail("INVALID_NATIVE_STATE");
    if (entries !== entry.retainedEntries || units !== entry.textCodeUnits || units > document.textCodeUnits)
      fail("INVALID_NATIVE_STATE");
    retainedEntries += entries;
    textCodeUnits += units;
  }
  if (data2.retainedEntries !== retainedEntries || data2.textCodeUnits !== textCodeUnits || retainedEntries > expected.maxRetainedEntries || textCodeUnits > expected.maxTextCodeUnits)
    fail("INVALID_NATIVE_STATE");
}
function* positions(input, expected, core, analyze) {
  const keys = ["kind", "revision", "analyzer", "fields", "offsetFields", "records", "limits", "maxRetainedEntries", "maxOccurrences", "maxTermCodeUnits", "retainedEntries", "occurrenceCount", "offsetCount", "termEntries", "termCodeUnits"];
  const data2 = object(input, keys, "INVALID_NATIVE_STATE");
  if (data2.kind !== expected.kind || data2.revision !== core.revision || !equalData(data2.analyzer, core.configuration.analyzer) || !equalData(data2.limits, expected.limits) || !fieldsEqual(data2.fields, expected.fields) || !fieldsEqual(data2.offsetFields, expected.offsetFields) || data2.maxRetainedEntries !== expected.maxRetainedEntries || data2.maxOccurrences !== expected.maxOccurrences || data2.maxTermCodeUnits !== expected.maxTermCodeUnits)
    fail("INVALID_NATIVE_STATE");
  const records = yield* directory(data2.records, core.documents.size, core.configuration.limits.maxIdCodeUnits);
  if (records.size !== core.documents.size)
    fail("INVALID_NATIVE_STATE");
  const totals = { retainedEntries: 0, occurrenceCount: 0, offsetCount: 0, termEntries: 0, termCodeUnits: 0 };
  for (const [id, entry] of directoryEntries(records)) {
    object(entry, ["positions", ...Object.keys(totals)], "INVALID_NATIVE_STATE");
    const document = directoryGet(core.documents, id);
    if (!document)
      fail("INVALID_NATIVE_STATE");
    const fields2 = map(entry.positions), counts = { retainedEntries: 1, occurrenceCount: 0, offsetCount: 0, termEntries: 0, termCodeUnits: 0 };
    let minimumCodeUnits = 0;
    for (const [field, rawValues] of Object.entries(fields2)) {
      if (!expected.fields.includes(field) || !Array.isArray(rawValues) || rawValues.length > expected.limits.maxTextValuesPerField)
        fail("INVALID_NATIVE_STATE");
      counts.retainedEntries += 1 + rawValues.length;
      const withOffsets = expected.offsetFields.includes(field), frequencies = /* @__PURE__ */ Object.create(null);
      const sourceProvider = core.configuration.capabilities?.providers[`source:${field}`];
      const sourceRoot = sourceProvider ? core.participants[sourceProvider.manifest.id] : void 0;
      const sourceValues = sourceRoot ? directoryGet(sourceRoot.records, id)?.text[field] : void 0;
      if (sourceRoot && (!sourceValues || sourceValues.length !== rawValues.length))
        fail("INVALID_NATIVE_STATE");
      for (let valueIndex = 0; valueIndex < rawValues.length; valueIndex++) {
        if (expected.kind === "raveldex-positions-v2") {
          const value2 = object(rawValues[valueIndex], ["tokenCount", "originalCount", "terms"], "INVALID_NATIVE_STATE");
          let tokens;
          try {
            tokens = yield* taggedPositionTokens(value2, withOffsets, expected.limits);
          } catch {
            fail("INVALID_NATIVE_STATE");
          }
          const terms2 = map(value2.terms), tokenCount2 = count(value2.tokenCount, expected.limits.maxTokensPerRecord);
          for (const [term, occurrences] of Object.entries(terms2)) {
            yield { workUnits: term.length + 1 };
            counts.termEntries++;
            counts.termCodeUnits += term.length;
            counts.retainedEntries++;
            frequencies[term] = (frequencies[term] ?? 0) + occurrences.length;
          }
          let lastOriginalEnd = 0;
          for (const token of tokens) {
            yield { workUnits: token.term.length + 1 };
            counts.occurrenceCount++;
            counts.retainedEntries++;
            if (withOffsets) {
              counts.offsetCount++;
              counts.retainedEntries += 2;
              if (token.kind === "original")
                lastOriginalEnd = token.end;
            }
          }
          minimumCodeUnits += lastOriginalEnd;
          if (counts.occurrenceCount > expected.limits.maxTokensPerRecord)
            fail("INVALID_NATIVE_STATE");
          if (sourceValues) {
            const seen = /* @__PURE__ */ Object.create(null);
            let analyzed = 0;
            for (const step of analyze(sourceValues[valueIndex], valueIndex, expected.limits)) {
              yield { workUnits: step.workUnits };
              if (!step.token)
                continue;
              const token = step.token, occurrence = value2.terms[token.term]?.[seen[token.term] ?? 0];
              if (!occurrence || occurrence.position !== token.position || occurrence.kind !== token.kind || withOffsets && (occurrence.start !== token.start || occurrence.end !== token.end))
                fail("INVALID_NATIVE_STATE");
              seen[token.term] = (seen[token.term] ?? 0) + 1;
              analyzed++;
            }
            if (analyzed !== tokenCount2)
              fail("INVALID_NATIVE_STATE");
          }
          continue;
        }
        const value = object(rawValues[valueIndex], ["tokenCount", "terms"], "INVALID_NATIVE_STATE"), tokenCount = count(value.tokenCount, expected.limits.maxTokensPerRecord), terms = map(value.terms);
        const ordinals = /* @__PURE__ */ new Map();
        for (const [term, rawOccurrences] of Object.entries(terms)) {
          yield* canonicalTerm(term, expected.limits.maxTermCodeUnits);
          if (!Array.isArray(rawOccurrences) || !rawOccurrences.length || rawOccurrences.length > tokenCount)
            fail("INVALID_NATIVE_STATE");
          counts.termEntries++;
          counts.termCodeUnits += term.length;
          counts.retainedEntries++;
          let last = -1;
          for (const rawOccurrence of rawOccurrences) {
            yield { workUnits: term.length + 1 };
            const occurrence = object(rawOccurrence, withOffsets ? ["position", "positionLength", "start", "end"] : ["position", "positionLength"], "INVALID_NATIVE_STATE");
            const position = count(occurrence.position, tokenCount - 1);
            if (position <= last || occurrence.positionLength !== 1 || ordinals.has(position))
              fail("INVALID_NATIVE_STATE");
            last = position;
            let span = {};
            if (withOffsets) {
              const start = count(occurrence.start, expected.limits.maxTextCodeUnitsPerValue), end = count(occurrence.end, expected.limits.maxTextCodeUnitsPerValue, 1);
              if (end <= start || end - start > expected.limits.maxRawTokenCodeUnits)
                fail("INVALID_NATIVE_STATE");
              span = { start, end };
              counts.offsetCount++;
              counts.retainedEntries += 2;
            }
            ordinals.set(position, span);
            counts.occurrenceCount++;
            counts.retainedEntries++;
          }
          frequencies[term] = (frequencies[term] ?? 0) + rawOccurrences.length;
        }
        if (ordinals.size !== tokenCount || counts.occurrenceCount > expected.limits.maxTokensPerRecord)
          fail("INVALID_NATIVE_STATE");
        let previousEnd = 0;
        for (let position = 0; position < tokenCount; position++) {
          yield { workUnits: 1 };
          const span = ordinals.get(position);
          if (!span)
            fail("INVALID_NATIVE_STATE");
          if (withOffsets) {
            if (span.start < previousEnd)
              fail("INVALID_NATIVE_STATE");
            previousEnd = span.end;
          }
        }
        minimumCodeUnits += previousEnd;
        if (sourceValues) {
          const seen = /* @__PURE__ */ Object.create(null);
          let analyzed = 0;
          for (const step of analyze(sourceValues[valueIndex], valueIndex, expected.limits)) {
            yield { workUnits: step.workUnits };
            if (!step.token)
              continue;
            const token = step.token, occurrence = value.terms[token.term]?.[seen[token.term] ?? 0];
            if (!occurrence || occurrence.position !== token.position || withOffsets && (occurrence.start !== token.start || occurrence.end !== token.end))
              fail("INVALID_NATIVE_STATE");
            seen[token.term] = (seen[token.term] ?? 0) + 1;
            analyzed++;
          }
          if (analyzed !== tokenCount)
            fail("INVALID_NATIVE_STATE");
        }
      }
      const reverse = document.fields[field]?.terms ?? {};
      if (Object.keys(frequencies).length !== Object.keys(reverse).length || Object.keys(frequencies).some((term) => frequencies[term] !== reverse[term]))
        fail("INVALID_NATIVE_STATE");
    }
    for (const field of expected.fields) {
      if (!Object.hasOwn(fields2, field) && document.fields[field])
        fail("INVALID_NATIVE_STATE");
      const provider = core.configuration.capabilities?.providers[`source:${field}`], retained = provider ? directoryGet(core.participants[provider.manifest.id].records, id)?.text : void 0;
      if (retained && Object.hasOwn(retained, field) !== Object.hasOwn(fields2, field))
        fail("INVALID_NATIVE_STATE");
    }
    if (minimumCodeUnits > document.textCodeUnits)
      fail("INVALID_NATIVE_STATE");
    for (const key of Object.keys(totals)) {
      if (entry[key] !== counts[key])
        fail("INVALID_NATIVE_STATE");
      totals[key] += counts[key];
    }
  }
  for (const key of Object.keys(totals))
    if (data2[key] !== totals[key])
      fail("INVALID_NATIVE_STATE");
  if (totals.retainedEntries > expected.maxRetainedEntries || totals.occurrenceCount > expected.maxOccurrences || totals.termCodeUnits > expected.maxTermCodeUnits)
    fail("INVALID_NATIVE_STATE");
}
function rebaseNative(root, revision) {
  const participants = /* @__PURE__ */ Object.create(null);
  for (const [id, state] of Object.entries(root.participants))
    participants[id] = Object.freeze({ ...state, revision });
  return Object.freeze({ ...root, revision, participants: Object.freeze(participants) });
}

// node_modules/@vmitsaras/raveldex/dist/core/capabilities/worker-identity.js
function workerIdentity(family, options) {
  function canonical2(value) {
    if (value === null || typeof value !== "object")
      return JSON.stringify(value);
    if (Array.isArray(value))
      return `[${value.map(canonical2).join(",")}]`;
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical2(value[key])}`).join(",")}}`;
  }
  return `raveldex:${family}:1:${canonical2(options)}`;
}

// node_modules/@vmitsaras/raveldex/dist/addons/phrases/options.js
function sourceEntryCeiling(documents, fields2, values) {
  return documents * (1 + fields2 * (1 + values));
}
function capturePhraseOptions(input, source2) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const options = ownObject(input, "INVALID_OPTIONS", "addons.options", admission);
  keysOnly(options, source2 ? ["fields", "id", "maxRetainedEntries", "maxWorkUnits"] : ["fields", "id", "maxWorkUnits"], "INVALID_OPTIONS", "addons.options");
  const fieldsInput = ownArray(options.fields, DEFAULT_LIMITS.maxTextFields, "INVALID_OPTIONS", "addons.fields", admission);
  if (fieldsInput.length === 0)
    invalid("INVALID_OPTIONS", "addons.fields");
  const seen = /* @__PURE__ */ new Set();
  const fields2 = Object.freeze(fieldsInput.map((value) => {
    const field = stringValue(value, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", "addons.fields");
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) || field === "constructor" || field === "prototype" || seen.has(field))
      invalid("INVALID_OPTIONS", "addons.fields");
    seen.add(field);
    return field;
  }));
  const id = has(options, "id") ? stringValue(options.id, 64, "INVALID_OPTIONS", "addons.id") : source2 ? "source" : "source-phrases";
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "addons.id");
  const workCeiling = source2 ? DEFAULT_LIMITS.maxMutationWorkUnits : DEFAULT_LIMITS.maxSearchWorkUnits;
  const maxWorkUnits = has(options, "maxWorkUnits") ? options.maxWorkUnits : workCeiling;
  if (typeof maxWorkUnits !== "number" || !Number.isSafeInteger(maxWorkUnits) || maxWorkUnits < 1)
    invalid("INVALID_OPTIONS", "addons.maxWorkUnits");
  bound(maxWorkUnits, workCeiling, "addons.maxWorkUnits");
  const entryCeiling = sourceEntryCeiling(DEFAULT_LIMITS.maxDocuments, fields2.length, DEFAULT_LIMITS.maxTextValuesPerField);
  const maxRetainedEntries = source2 && has(options, "maxRetainedEntries") ? options.maxRetainedEntries : source2 ? entryCeiling : 0;
  if (typeof maxRetainedEntries !== "number" || !Number.isSafeInteger(maxRetainedEntries) || maxRetainedEntries < 0)
    invalid("INVALID_OPTIONS", "addons.maxRetainedEntries");
  bound(maxRetainedEntries, entryCeiling, "addons.maxRetainedEntries");
  return Object.freeze({ fields: fields2, id, maxWorkUnits, maxRetainedEntries });
}

// node_modules/@vmitsaras/raveldex/dist/addons/phrases/store.js
var rawCharge = (workUnits) => ({ workUnits });
function requireSourceRoot(input, field, revision, analyzer) {
  if (input === void 0 || input === null)
    invalid("MISSING_CAPABILITY", "phrases.source");
  if (typeof input !== "object" || !Object.isFrozen(input))
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.source");
  const root = input;
  if (root.kind !== "raveldex-source-v1" || !Array.isArray(root.fields) || !Object.isFrozen(root.fields) || root.fields.length === 0 || root.fields.length > DEFAULT_LIMITS.maxTextFields || typeof root.analyzer !== "object" || root.analyzer === null || !Object.isFrozen(root.analyzer) || typeof root.records !== "object" || root.records === null || !Object.isFrozen(root.records) || !Number.isSafeInteger(root.records.size) || root.records.size < 0 || root.records.size > DEFAULT_LIMITS.maxDocuments || typeof root.records.buckets !== "object" || root.records.buckets === null || !Object.isFrozen(root.records.buckets) || !Number.isSafeInteger(root.revision) || root.revision < 0 || !Number.isSafeInteger(root.retainedEntries) || root.retainedEntries < 0 || !Number.isSafeInteger(root.textCodeUnits) || root.textCodeUnits < 0 || !Number.isSafeInteger(root.maxRetainedEntries) || root.maxRetainedEntries < root.retainedEntries || !Number.isSafeInteger(root.maxTextCodeUnits) || root.maxTextCodeUnits < root.textCodeUnits)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.source");
  if (!root.fields.includes(field))
    invalid("MISSING_CAPABILITY", "phrases.source.field");
  if (root.revision !== revision)
    invalid("REVISION_MISMATCH", "phrases.source.revision");
  if (root.analyzer.id !== analyzer.id || root.analyzer.environmentProfile !== analyzer.environmentProfile)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.analyzer");
  return root;
}
function* retainRecord(record, fields2) {
  const text2 = /* @__PURE__ */ Object.create(null);
  let retainedEntries = 1, textCodeUnits = 0;
  for (const field of fields2) {
    yield rawCharge(field.length + 1);
    if (!has(record.text, field))
      continue;
    const values = record.text[field];
    if (!Object.isFrozen(values))
      invalid("INTERNAL_ERROR", "source.record.values");
    retainedEntries += 1 + values.length;
    for (const value of values) {
      yield rawCharge(1);
      textCodeUnits += value.length;
    }
    text2[field] = values;
  }
  return Object.freeze({ text: Object.freeze(text2), retainedEntries, textCodeUnits });
}
function initialRoot(configuration, fields2, requestedEntries) {
  for (const field of fields2)
    if (!has(configuration.schema.text, field))
      invalid("MISSING_CAPABILITY", "source.fields");
  const maxRetainedEntries = Math.min(requestedEntries, sourceEntryCeiling(configuration.limits.maxDocuments, fields2.length, configuration.limits.maxTextValuesPerField));
  return Object.freeze({
    kind: "raveldex-source-v1",
    revision: 0,
    analyzer: Object.freeze({ id: configuration.analyzer.id, environmentProfile: configuration.analyzer.environmentProfile }),
    fields: fields2,
    records: emptyDirectory(),
    retainedEntries: 0,
    textCodeUnits: 0,
    maxRetainedEntries,
    maxTextCodeUnits: configuration.limits.maxCorpusTextCodeUnits
  });
}
function* prepareSource(previous, context, fields2) {
  const old = requireSourceRoot(previous, fields2[0], context.previousRevision, context.analyzer);
  if (context.revision !== context.previousRevision + 1 || !Number.isSafeInteger(context.revision))
    invalid("REVISION_MISMATCH", "source.revision");
  if (context.kind === "clear") {
    yield rawCharge(1);
    return Object.freeze({ ...old, revision: context.revision, records: emptyDirectory(), retainedEntries: 0, textCodeUnits: 0 });
  }
  const stage = new DirectoryStage(old.records, rawCharge);
  let retainedEntries = old.retainedEntries, textCodeUnits = old.textCodeUnits;
  for (const id of context.removedIds) {
    yield rawCharge(id.length + 1);
    const retained = stage.get(id);
    if (!retained)
      invalid("MISSING_CAPABILITY", "source.record");
    retainedEntries -= retained.retainedEntries;
    textCodeUnits -= retained.textCodeUnits;
    yield* stage.delete(id);
  }
  for (const record of context.records) {
    yield rawCharge(record.id.length + 1);
    const retained = stage.get(record.id);
    if (context.kind === "replace" && !retained)
      invalid("MISSING_CAPABILITY", "source.record");
    if (context.kind !== "replace" && retained)
      invalid("INCOMPATIBLE_CAPABILITY", "source.record");
    if (retained) {
      retainedEntries -= retained.retainedEntries;
      textCodeUnits -= retained.textCodeUnits;
    }
    const next = yield* retainRecord(record, fields2);
    retainedEntries += next.retainedEntries;
    textCodeUnits += next.textCodeUnits;
    bound(retainedEntries, old.maxRetainedEntries, "source.retainedEntries");
    bound(textCodeUnits, old.maxTextCodeUnits, "source.textCodeUnits");
    yield* stage.set(record.id, next);
  }
  if (retainedEntries < 0 || textCodeUnits < 0)
    invalid("INCOMPATIBLE_CAPABILITY", "source.counts");
  const records = yield* stage.finish();
  return Object.freeze({ ...old, revision: context.revision, records, retainedEntries, textCodeUnits });
}
function bulkSource(initial, fields2) {
  const old = requireSourceRoot(initial, fields2[0], 0, initial?.analyzer);
  if (old.records.size !== 0 || old.retainedEntries !== 0 || old.textCodeUnits !== 0)
    invalid("INCOMPATIBLE_CAPABILITY", "source.bulk.initial");
  const stage = new DirectoryStage(old.records, rawCharge);
  let revision = 0, retainedEntries = 0, textCodeUnits = 0, sealed = false;
  return Object.freeze({
    *add(context) {
      if (sealed)
        invalid("INTERNAL_ERROR", "source.bulk.sealed");
      if (context.kind !== "add" || context.records.length !== 1 || context.removedIds.length !== 0)
        invalid("INCOMPATIBLE_CAPABILITY", "source.bulk.add");
      if (context.previousRevision !== revision || context.revision !== revision + 1 || !Number.isSafeInteger(context.revision))
        invalid("REVISION_MISMATCH", "source.revision");
      if (context.analyzer.id !== old.analyzer.id || context.analyzer.environmentProfile !== old.analyzer.environmentProfile)
        invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.analyzer");
      const record = context.records[0];
      yield rawCharge(record.id.length + 1);
      if (stage.get(record.id))
        invalid("INCOMPATIBLE_CAPABILITY", "source.record");
      const next = yield* retainRecord(record, fields2);
      retainedEntries += next.retainedEntries;
      textCodeUnits += next.textCodeUnits;
      bound(retainedEntries, old.maxRetainedEntries, "source.retainedEntries");
      bound(textCodeUnits, old.maxTextCodeUnits, "source.textCodeUnits");
      yield* stage.set(record.id, next);
      revision = context.revision;
    },
    *finish(finalRevision) {
      if (sealed)
        invalid("INTERNAL_ERROR", "source.bulk.sealed");
      if (finalRevision !== revision || !Number.isSafeInteger(finalRevision))
        invalid("REVISION_MISMATCH", "source.revision");
      sealed = true;
      const records = yield* stage.finish();
      return Object.freeze({ ...old, revision, records, retainedEntries, textCodeUnits });
    }
  });
}
function createSourceProvider(options) {
  const captured = capturePhraseOptions(options, true);
  const registration = Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["transaction-participant"]),
      provides: Object.freeze(captured.fields.map((field) => Object.freeze({ id: `source:${field}`, contractVersion: 1 }))),
      requires: Object.freeze([]),
      dataRequirements: Object.freeze({ fields: captured.fields, source: true, positions: false, offsets: false, metadata: false }),
      indexEffect: "transactional",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("source", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: captured.maxRetainedEntries, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Selected-source capture and copy-on-write directory staging; no phrase verifier.", retainedRepresentation: "One entry per record, present selected field and original value; selected original UTF-16 strings only.", transientWork: "Changed selected-field values and touched source-directory buckets; shared mutation budget.", externalResources: "none" }),
      codec: Object.freeze({ id: "raveldex-source-v1", version: 1 })
    }),
    participant: Object.freeze({
      initialize: (configuration) => initialRoot(configuration, captured.fields, captured.maxRetainedEntries),
      prepare: (previous, context) => prepareSource(previous, context, captured.fields)
    })
  });
  return registerBulkParticipant(registration, (initial) => bulkSource(initial, captured.fields));
}

// node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/source.js
function* sourceRecords(root) {
  const fields2 = Object.keys(root.configuration.schema.text);
  const providers = requireCompleteSource(root);
  const records = [];
  for (const [id, entry] of directoryEntries(root.documents)) {
    yield { workUnits: id.length + 1 };
    const text2 = /* @__PURE__ */ Object.create(null);
    let textCodeUnits = 0;
    for (let index = 0; index < fields2.length; index++) {
      const field = fields2[index], retained = directoryGet(providers[index].records, id);
      yield { workUnits: id.length + field.length + 1 };
      if (!retained)
        fail("INVALID_NATIVE_STATE");
      if (Object.hasOwn(retained.text, field)) {
        text2[field] = retained.text[field];
        for (const value of text2[field]) {
          yield { workUnits: value.length + 1 };
          textCodeUnits += value.length;
        }
      }
    }
    if (textCodeUnits !== entry.textCodeUnits)
      fail("INVALID_NATIVE_STATE");
    records.push(Object.freeze({ id, text: Object.freeze(text2), metadata: entry.metadata }));
  }
  for (const record of records)
    yield { workUnits: record.id.length + Math.ceil(Math.log2(records.length + 1)) + 1 };
  records.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  return Object.freeze(records);
}
function requireCompleteSource(root) {
  return Object.keys(root.configuration.schema.text).map((field) => {
    const registration = root.configuration.capabilities?.providers[`source:${field}`];
    if (!registration?.participant || registration.manifest.codec?.id !== "raveldex-source-v1" || registration.manifest.codec.version !== 1)
      fail("SOURCE_UNAVAILABLE");
    return requireSourceRoot(root.participants[registration.manifest.id], field, root.revision, root.configuration.analyzer);
  });
}

// node_modules/@vmitsaras/raveldex/dist/adapters/snapshots/snapshots.js
var CODEC = Object.freeze({ id: "raveldex-json-v1", version: 1 });
var INDEX_DETAIL = Object.freeze({ id: "frequency-directory-256-v1", version: 1 });
var RANKING = Object.freeze({ model: "raveldex-bm25-v1", implementationVersion: 1 });
var bindings = /* @__PURE__ */ new WeakMap();
function* metered(cursor, maximum, check2) {
  const budget = new WorkBudget(maximum);
  let finished = false;
  try {
    for (; ; ) {
      check2("snapshot");
      const step = cursor.next();
      if (step.done) {
        finished = true;
        return step.value;
      }
      check2("snapshot");
      budget.charge(step.value.workUnits);
      yield step.value;
    }
  } finally {
    if (!finished) {
      try {
        cursor.return(void 0);
      } catch {
      }
    }
  }
}
function header(root, qualification) {
  return Object.freeze({
    schemaVersion: 1,
    schema: root.configuration.schema,
    analyzer: root.configuration.analyzer,
    ranking: RANKING,
    capabilities: Object.freeze((root.configuration.capabilities?.ordered ?? []).map((entry) => entry.manifest)),
    indexDetail: INDEX_DETAIL,
    limits: root.configuration.limits,
    originRevision: root.revision,
    nativeQualification: qualification ?? null
  });
}
function nativeQualification(engine, root) {
  const qualification = bindings.get(engine);
  if (!qualification || root.configuration.analyzer.environmentProfile === "unqualified")
    fail("UNQUALIFIED_PROFILE");
  const current = captureQualification(qualification);
  if (current.profileId !== root.configuration.analyzer.environmentProfile)
    fail("PROFILE_MISMATCH");
  return current;
}
function* encoded(root, format, qualification, maximum, check2) {
  requireCodecs(root.configuration);
  if (format === "raveldex-source")
    requireCompleteSource(root);
  const fields2 = /* @__PURE__ */ Object.create(null);
  for (const [name2, field] of Object.entries(root.fields)) {
    yield { workUnits: name2.length + 1 };
    fields2[name2] = Object.freeze({ documents: field.documents, length: field.length, terms: field.terms });
  }
  const native = Object.freeze({ documents: root.documents, fields: Object.freeze(fields2), counts: root.counts, participants: root.participants });
  try {
    yield* validateNative(native, root.configuration, root.revision, check2, root.fields);
  } catch (error) {
    if (error instanceof SnapshotAdapterError || error instanceof RaveldexError && ["CANCELLED", "DISPOSED", "DEADLINE_EXCEEDED", "WORK_LIMIT_EXCEEDED", "RESOURCE_EXHAUSTED"].includes(error.code))
      throw error;
    fail("INVALID_NATIVE_STATE");
  }
  const payload = format === "raveldex-source" ? Object.freeze({ records: yield* sourceRecords(root) }) : native;
  const body = yield* encodeJson(Object.freeze({ header: header(root, qualification), payload }), maximum);
  const integrity = yield* checksum(body);
  const result = `{"format":${JSON.stringify(format)},"formatVersion":1,"codec":{"id":"${CODEC.id}","version":1},"body":${body},"integrity":{"algorithm":"fnv1a32-utf16","value":"${integrity}"}}`;
  yield* utf8Bytes(result, maximum);
  return result;
}
function checkedHeader(raw, root, format, qualification) {
  const value = object(raw, ["schemaVersion", "schema", "analyzer", "ranking", "capabilities", "indexDetail", "limits", "originRevision", "nativeQualification"]);
  if (value.schemaVersion !== 1 || !equalData(value.schema, root.configuration.schema))
    fail("SCHEMA_MISMATCH");
  if (!equalData(value.ranking, RANKING))
    fail("RANKING_MISMATCH");
  if (!equalData(value.indexDetail, INDEX_DETAIL))
    fail("INDEX_DETAIL_MISMATCH");
  if (!equalData(value.limits, root.configuration.limits))
    fail("LIMITS_MISMATCH");
  if (!equalData(value.capabilities, (root.configuration.capabilities?.ordered ?? []).map((entry) => entry.manifest)))
    fail("CAPABILITY_MISMATCH");
  const analyzer = object(value.analyzer, ["id", "environmentProfile"]);
  if (analyzer.id !== root.configuration.analyzer.id || typeof analyzer.environmentProfile !== "string" || !analyzer.environmentProfile.length || analyzer.environmentProfile.length > 128)
    fail("ANALYZER_MISMATCH");
  if (format === "raveldex-native") {
    if (analyzer.environmentProfile === "unqualified" || value.nativeQualification === null)
      fail("UNQUALIFIED_PROFILE");
    if (!equalData(value.analyzer, root.configuration.analyzer) || !equalData(value.nativeQualification, qualification))
      fail("PROFILE_MISMATCH");
  } else {
    if (value.nativeQualification !== null) {
      let declared;
      try {
        declared = captureQualification(value.nativeQualification, false);
      } catch {
        fail("PROFILE_MISMATCH");
      }
      if (declared.profileId !== analyzer.environmentProfile)
        fail("PROFILE_MISMATCH");
    } else if (analyzer.environmentProfile !== "unqualified")
      fail("PROFILE_MISMATCH");
  }
  count(value.originRevision, Number.MAX_SAFE_INTEGER);
  return value;
}
function* preparedSource(payload, configuration, check2) {
  const data2 = object(payload, ["records"]);
  if (!Array.isArray(data2.records) || data2.records.length > configuration.limits.maxDocuments)
    fail("MALFORMED_SNAPSHOT");
  return yield* reconstructSource(data2.records, configuration, check2);
}
function* restoreCursor(engine, root, encoded2, maximum, publish, check2) {
  check2("snapshot.decode");
  let decoded;
  try {
    decoded = yield* decodeJson(encoded2, maximum);
  } catch (error) {
    if (error instanceof SnapshotAdapterError || error instanceof RaveldexError && ["CANCELLED", "DISPOSED", "DEADLINE_EXCEEDED", "WORK_LIMIT_EXCEEDED", "RESOURCE_EXHAUSTED"].includes(error.code))
      throw error;
    fail("MALFORMED_SNAPSHOT");
  }
  const envelope = object(decoded.value, ["format", "formatVersion", "codec", "body", "integrity"]);
  if (envelope.format !== "raveldex-source" && envelope.format !== "raveldex-native" || envelope.formatVersion !== 1)
    fail("UNSUPPORTED_FORMAT");
  if (!equalData(envelope.codec, CODEC))
    fail("UNSUPPORTED_CODEC");
  const integrity = object(envelope.integrity, ["algorithm", "value"]);
  if (integrity.algorithm !== "fnv1a32-utf16" || !isChecksum(integrity.value))
    fail("UNSUPPORTED_CODEC");
  check2("snapshot.integrity");
  if ((yield* checksum(decoded.bodyText)) !== integrity.value)
    fail("INTEGRITY_MISMATCH");
  const format = envelope.format, body = object(envelope.body, ["header", "payload"]);
  const qualification = format === "raveldex-native" ? nativeQualification(engine, root) : void 0;
  check2("snapshot.compatibility");
  const origin = checkedHeader(body.header, root, format, qualification);
  requireCodecs(root.configuration);
  if (root.revision === Number.MAX_SAFE_INTEGER)
    invalid("REVISION_EXHAUSTED", "revision");
  let prepared;
  check2(format === "raveldex-native" ? "snapshot.validation" : "snapshot.staging");
  try {
    prepared = format === "raveldex-native" ? yield* validateNative(body.payload, root.configuration, origin.originRevision, check2) : yield* preparedSource(body.payload, root.configuration, check2);
  } catch (error) {
    if (error instanceof SnapshotAdapterError || error instanceof RaveldexError && ["CANCELLED", "DISPOSED", "DEADLINE_EXCEEDED", "WORK_LIMIT_EXCEEDED", "REVISION_EXHAUSTED", "RESOURCE_EXHAUSTED"].includes(error.code))
      throw error;
    fail("INVALID_NATIVE_STATE");
  }
  const next = rebaseNative(prepared, root.revision + 1);
  const result = Object.freeze({
    format,
    originRevision: origin.originRevision,
    revision: next.revision,
    reindexed: format === "raveldex-source",
    receivingAnalyzer: root.configuration.analyzer
  });
  yield { workUnits: 1 };
  check2("snapshot.precommit");
  publish(next);
  return result;
}
function controlledSnapshots(engine, options = {}, control) {
  const owner = getExecutionOwner(engine);
  if (!owner)
    fail("UNSUPPORTED_ENGINE");
  const data2 = ownObject(options, "INVALID_OPTIONS", "snapshot.options", new Admission(32));
  keysOnly(data2, ["maxEncodedBytes"], "INVALID_OPTIONS", "snapshot.options");
  const maximum = has(data2, "maxEncodedBytes") ? data2.maxEncodedBytes : MAX_ENCODED_BYTES;
  if (typeof maximum !== "number" || !Number.isSafeInteger(maximum) || maximum < 1024 || maximum > MAX_ENCODED_BYTES)
    invalid("INVALID_OPTIONS", "snapshot.maxEncodedBytes");
  function exportFormat(format, options2) {
    return owner.adapterOperation((configuration) => ({ options: captureOptions(options2, configuration.limits, false), *start(root, check2) {
      const qualification = format === "raveldex-native" ? nativeQualification(engine, root) : bindings.get(engine);
      return yield* metered(encoded(root, format, qualification, maximum, check2), configuration.limits.maxMutationWorkUnits, check2);
    } }), control);
  }
  return Object.freeze({
    exportSource: (options2) => exportFormat("raveldex-source", options2),
    exportNative: (options2) => exportFormat("raveldex-native", options2),
    restore(encoded2, options2) {
      return owner.adapterOperation((configuration) => {
        const capturedOptions = captureOptions(options2, configuration.limits, false);
        if (capturedOptions.signal?.aborted)
          invalid("CANCELLED", "options.signal");
        if (typeof encoded2 !== "string")
          fail("MALFORMED_SNAPSHOT");
        if (encoded2.length > maximum)
          fail("ENCODED_LIMIT_EXCEEDED");
        return { options: capturedOptions, *start(root, check2, publish) {
          return yield* metered(restoreCursor(engine, root, encoded2, maximum, publish, check2), configuration.limits.maxMutationWorkUnits, check2);
        } };
      }, control);
    }
  });
}

// node_modules/@vmitsaras/raveldex/dist/adapters/worker/error.js
var WORKER_ERROR_CODES = Object.freeze([
  "INVALID_TRANSPORT",
  "TRANSPORT_LIMIT",
  "INCOMPATIBLE_WORKER",
  "TIMEOUT",
  "TERMINATED",
  "STARTUP_FAILED",
  "OUTCOME_UNKNOWN",
  "DISPOSED"
]);
var WorkerAdapterError = class extends Error {
  code;
  details;
  operationId;
  constructor(code, details = {}) {
    super(`Raveldex worker: ${code}`);
    this.name = "WorkerAdapterError";
    this.code = code;
    this.operationId = details.operationId;
    this.details = Object.freeze({ ...details });
  }
};

// node_modules/@vmitsaras/raveldex/dist/adapters/worker/protocol.js
var PROTOCOL = 1;
var IMPLEMENTATION = "raveldex-native-v1";
var MAX_MESSAGE_BYTES = 8 * 1024 * 1024;
var MAX_PENDING = 64;
var RECEIPT_WINDOW = 256;
var MAX_NODES2 = 131072;
var MAX_DEPTH2 = 64;
var MAX_ARRAY = 65536;
var OPERATIONS = Object.freeze(["init", "search", "add", "addMany", "replace", "remove", "clear", "reconcile", "dispose", "snapshotExportSource", "snapshotRestore", "snapshotReconcile"]);
var mutation = (operation) => ["add", "addMany", "replace", "remove", "clear", "snapshotRestore"].includes(operation);
function monotonicEpoch() {
  const origin = performance.timeOrigin, now = performance.now();
  if (!Number.isFinite(origin) || !Number.isFinite(now))
    throw new WorkerAdapterError("STARTUP_FAILED", { path: "worker.clock" });
  return origin + now;
}
function fail2(path = "transport") {
  throw new WorkerAdapterError("INVALID_TRANSPORT", { path });
}
function object2(value, allowed) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    fail2();
  const data2 = value;
  if (allowed && Object.keys(data2).some((key) => !allowed.includes(key)))
    fail2();
  return data2;
}
function integer2(value, maximum = Number.MAX_SAFE_INTEGER, minimum = 0) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum)
    fail2();
  return value;
}
function cap(value = MAX_MESSAGE_BYTES) {
  return integer2(value, MAX_MESSAGE_BYTES, 1024);
}
function sessionValue(value) {
  if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value))
    fail2("transport.session");
  return value;
}
function captureMessage(input, maximum) {
  let bytes = 0, nodes = 0;
  const active = /* @__PURE__ */ new Set();
  const charge9 = (amount) => {
    bytes += amount;
    if (bytes > maximum)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.bytes", limit: maximum, actual: bytes });
  };
  function string(value) {
    charge9(2);
    for (let i = 0; i < value.length; i++) {
      const point = value.charCodeAt(i);
      if (point === 34 || point === 92 || point === 8 || point === 9 || point === 10 || point === 12 || point === 13)
        charge9(2);
      else if (point < 32)
        charge9(6);
      else if (point < 128)
        charge9(1);
      else if (point < 2048)
        charge9(2);
      else if (point >= 55296 && point <= 56319 && value.charCodeAt(i + 1) >= 56320 && value.charCodeAt(i + 1) <= 57343) {
        charge9(4);
        i++;
      } else
        charge9(point >= 55296 && point <= 57343 ? 6 : 3);
    }
  }
  function visit(value, depth) {
    if (++nodes > MAX_NODES2 || depth > MAX_DEPTH2)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.structure", limit: depth > MAX_DEPTH2 ? MAX_DEPTH2 : MAX_NODES2, actual: depth > MAX_DEPTH2 ? depth : nodes });
    if (value === null) {
      charge9(4);
      return null;
    }
    if (typeof value === "boolean") {
      charge9(value ? 4 : 5);
      return value;
    }
    if (typeof value === "string") {
      string(value);
      return value;
    }
    if (typeof value === "number" && Number.isFinite(value)) {
      charge9(String(value).length);
      return value;
    }
    if (!value || typeof value !== "object" || active.has(value))
      fail2("transport.data");
    const array2 = Array.isArray(value), prototype = Object.getPrototypeOf(value);
    if (prototype !== null && prototype !== (array2 ? Array.prototype : Object.prototype))
      fail2("transport.prototype");
    const keys = Reflect.ownKeys(value);
    if (keys.length > MAX_NODES2 - nodes)
      throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.structure", limit: MAX_NODES2, actual: keys.length + nodes });
    active.add(value);
    charge9(2);
    if (array2) {
      if (value.length > MAX_ARRAY)
        throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.array", limit: MAX_ARRAY, actual: value.length });
      if (keys.length !== value.length + 1 || keys.some((key) => key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length)))
        fail2("transport.array");
      const result2 = [];
      for (let i = 0; i < value.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
        if (!descriptor || !("value" in descriptor))
          fail2("transport.accessor");
        if (i)
          charge9(1);
        result2.push(visit(descriptor.value, depth + 1));
      }
      active.delete(value);
      return Object.freeze(result2);
    }
    const result = /* @__PURE__ */ Object.create(null);
    let index = 0;
    for (const key of keys) {
      if (typeof key !== "string" || key.length > 256)
        fail2("transport.key");
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !("value" in descriptor))
        fail2("transport.accessor");
      if (index++)
        charge9(1);
      string(key);
      charge9(1);
      result[key] = visit(descriptor.value, depth + 1);
    }
    active.delete(value);
    return Object.freeze(result);
  }
  return visit(input, 0);
}
function canonical(value) {
  if (value === null || typeof value !== "object")
    return JSON.stringify(value);
  if (Array.isArray(value))
    return `[${value.map(canonical).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
}
function wireError(error) {
  if (error instanceof RaveldexError && error.name === "SnapshotAdapterError" && "reason" in error && typeof error.reason === "string" && error.reason.length <= 64)
    return Object.freeze({ name: "SnapshotAdapterError", code: error.code, reason: error.reason, details: error.details });
  if (error instanceof RaveldexError)
    return Object.freeze({ name: "RaveldexError", code: error.code, details: error.details });
  if (error instanceof WorkerAdapterError)
    return Object.freeze({ name: "WorkerAdapterError", code: error.code, details: error.details });
  return Object.freeze({ name: "RaveldexError", code: "INTERNAL_ERROR", details: Object.freeze({}) });
}

// node_modules/@vmitsaras/raveldex/dist/adapters/worker/host.js
var liveScopes = /* @__PURE__ */ new WeakSet();
function serveWorkerWithSnapshots(scope, options = {}, snapshotFactory) {
  if (liveScopes.has(scope))
    throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.owner" });
  liveScopes.add(scope);
  try {
    return installWorkerHost(scope, options, snapshotFactory);
  } catch (error) {
    liveScopes.delete(scope);
    throw error;
  }
}
function installWorkerHost(scope, options, snapshotFactory) {
  const data2 = ownObject(options, "INVALID_OPTIONS", "worker.host", new Admission(64));
  keysOnly(data2, ["addons", "maxMessageBytes"], "INVALID_OPTIONS", "worker.host");
  const addons = Object.hasOwn(data2, "addons") ? ownArray(data2.addons, 32, "INVALID_OPTIONS", "worker.host.addons", new Admission(64)) : [];
  const hostMaximum = cap(data2.maxMessageBytes);
  const post = scope.postMessage.bind(scope), addListener = scope.addEventListener.bind(scope), removeListener = scope.removeEventListener.bind(scope);
  let maximum = hostMaximum, session, lastId = 0;
  let owner, configuration;
  let initialized = false, closing = false, cleaned = false, disposal;
  const active = /* @__PURE__ */ new Map();
  const receipts = /* @__PURE__ */ new Map();
  const receiptDomains = /* @__PURE__ */ new Map();
  let snapshots;
  const inflight = /* @__PURE__ */ new Map();
  function record(value) {
    receipts.set(value.operationId, value);
    while (receipts.size > RECEIPT_WINDOW) {
      const victim = [...receipts].find(([, receipt]) => receipt.status !== "pending");
      if (!victim)
        break;
      receipts.delete(victim[0]);
      receiptDomains.delete(victim[0]);
    }
  }
  function send(request, kind, value) {
    const envelope = { protocol: PROTOCOL, session: request.session, id: request.id, operation: request.operation, kind, value };
    try {
      post(captureMessage(envelope, maximum));
    } catch (error) {
      const failure2 = mutation(request.operation) ? new WorkerAdapterError("OUTCOME_UNKNOWN", { operationId: `${request.session}:${request.id}` }) : error instanceof WorkerAdapterError ? error : new WorkerAdapterError("TERMINATED");
      try {
        post(captureMessage({ ...envelope, kind: "error", value: wireError(failure2) }, maximum));
      } catch {
      }
    }
  }
  function identity(value) {
    return { schema: value.schema, limits: value.limits, analyzer: value.analyzer };
  }
  async function execute(request) {
    const id = request.id, operation = request.operation;
    const operationId = `${request.session}:${id}`;
    let trackedMutation = false;
    try {
      const payload = object2(request.payload);
      if (operation === "init") {
        if (initialized || closing)
          throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.initialized" });
        initialized = true;
        object2(payload, ["implementation", "model", "configuration", "identity", "hasAddons", "manifests", "sameHost", "maxMessageBytes"]);
        if (payload.implementation !== IMPLEMENTATION || payload.model !== "raveldex-bm25-v1" || payload.sameHost !== true || typeof payload.hasAddons !== "boolean")
          throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.sameHost" });
        const incomingConfiguration = object2(payload.configuration, ["schema", "limits", "analyzer"]);
        maximum = Math.min(hostMaximum, cap(payload.maxMessageBytes));
        const captured = captureConfiguration({ ...incomingConfiguration, ...payload.hasAddons || addons.length ? { addons } : {} });
        const manifests = (captured.capabilities?.ordered ?? []).map((registration) => registration.manifest);
        if (manifests.some((manifest) => !manifest.execution.worker || !manifest.execution.workerRegistration) || canonical(identity(captured)) !== canonical(payload.identity) || canonical(manifests) !== canonical(payload.manifests))
          throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "worker.configuration" });
        const installed = initializeParticipants(captured);
        configuration = captured;
        owner = new ExecutionOwner(emptyRoot(captured, installed.states), directHost(), installed.participants);
        snapshots = snapshotFactory?.(owner);
        send(request, "result", { implementation: IMPLEMENTATION, model: "raveldex-bm25-v1", analyzer: captured.analyzer, identity: identity(captured), manifests, maxMessageBytes: maximum, receipts: RECEIPT_WINDOW });
        return;
      }
      if (!owner || !configuration)
        throw new WorkerAdapterError("STARTUP_FAILED");
      if (closing)
        throw new WorkerAdapterError("DISPOSED");
      if (operation === "reconcile" || operation === "snapshotReconcile") {
        object2(payload, ["operationId"]);
        if (typeof payload.operationId !== "string" || !payload.operationId.startsWith(`${session}:`) || !/^[1-9][0-9]*$/.test(payload.operationId.slice(session.length + 1)))
          fail2("transport.operationId");
        integer2(Number(payload.operationId.slice(session.length + 1)), lastId, 1);
        const domain = receiptDomains.get(payload.operationId);
        if (domain !== void 0 && domain !== (operation === "snapshotReconcile"))
          throw new WorkerAdapterError("INVALID_TRANSPORT", { path: "transport.receiptDomain" });
        send(request, "result", receipts.get(payload.operationId) ?? { operationId: payload.operationId, status: "expired" });
        return;
      }
      if (operation === "dispose") {
        object2(payload, []);
        closing = true;
        await owner.dispose();
        await Promise.all([...inflight].filter(([requestId]) => requestId !== id).map(([, promise]) => promise));
        send(request, "result", null);
        cleanup();
        return;
      }
      if ((operation === "snapshotExportSource" || operation === "snapshotRestore") && !snapshots)
        throw new WorkerAdapterError("INCOMPATIBLE_WORKER", { path: "snapshot.host" });
      if (active.size >= MAX_PENDING)
        throw new WorkerAdapterError("TRANSPORT_LIMIT", { path: "transport.pending", limit: MAX_PENDING, actual: active.size + 1 });
      object2(payload, operation === "search" ? ["query", "options", "admittedAt"] : ["input", "options", "admittedAt"]);
      const requestOptions = object2(payload.options, operation === "search" ? ["deadlineMs", "limit", "offset", "extensions"] : ["deadlineMs"]);
      if (typeof payload.admittedAt !== "number" || !Number.isFinite(payload.admittedAt) || payload.admittedAt < 0)
        fail2("transport.admission");
      const controller = new AbortController();
      active.set(id, controller);
      const control = { signal: controller.signal, elapsedMs: Math.max(0, monotonicEpoch() - payload.admittedAt) };
      if (mutation(operation)) {
        trackedMutation = true;
        receiptDomains.set(operationId, operation === "snapshotRestore");
        record(Object.freeze({ operationId, status: "pending" }));
      }
      const result = operation === "snapshotExportSource" ? await snapshots.exportSource(requestOptions, control) : operation === "snapshotRestore" ? await snapshots.restore(payload.input, requestOptions, control) : operation === "search" ? await owner.searchControlled(payload.query, requestOptions, control) : await owner.mutateControlled(operation, payload.input, requestOptions, control);
      if (trackedMutation)
        record(Object.freeze({ operationId, status: "committed", result }));
      send(request, "result", result);
    } catch (error) {
      const failure2 = wireError(error);
      if (trackedMutation)
        record(Object.freeze({ operationId, status: "rejected", error: failure2 }));
      send(request, "error", failure2);
    } finally {
      active.delete(id);
    }
  }
  function receive(raw) {
    if (closing)
      return;
    let request;
    try {
      request = object2(captureMessage(raw, maximum), ["protocol", "session", "id", "operation", "payload"]);
      if (request.protocol !== PROTOCOL)
        fail2("transport.protocol");
      const incomingSession = sessionValue(request.session), id = integer2(request.id, Number.MAX_SAFE_INTEGER, 1);
      if (session !== void 0 && incomingSession !== session || id <= lastId)
        fail2("transport.identity");
      if (request.operation !== "cancel" && !OPERATIONS.includes(request.operation))
        fail2("transport.operation");
      if (session === void 0) {
        if (request.operation !== "init")
          throw new WorkerAdapterError("STARTUP_FAILED");
        session = incomingSession;
      }
      lastId = id;
      if (request.operation === "cancel") {
        const payload = object2(request.payload, ["targetId"]);
        active.get(integer2(payload.targetId, id - 1, 1))?.abort();
        return;
      }
      const running = execute(request);
      inflight.set(id, running);
      void running.finally(() => inflight.delete(id));
    } catch (error) {
      if (request && request.protocol === PROTOCOL && request.session === session && typeof request.id === "number" && Number.isSafeInteger(request.id) && request.id > lastId && OPERATIONS.includes(request.operation))
        send(request, "error", wireError(error));
    }
  }
  const message = (event) => receive(event.data);
  const failure = () => {
    void dispose();
  };
  function cleanup() {
    if (cleaned)
      return;
    cleaned = true;
    closing = true;
    for (const [type, listener] of [["message", message], ["messageerror", failure]]) {
      try {
        removeListener(type, listener);
      } catch {
      }
    }
    active.clear();
    receipts.clear();
    receiptDomains.clear();
    snapshots = void 0;
    owner = void 0;
    configuration = void 0;
    liveScopes.delete(scope);
  }
  function dispose() {
    if (disposal)
      return disposal;
    if (cleaned)
      return Promise.resolve();
    closing = true;
    disposal = (async () => {
      try {
        await owner?.dispose();
        await Promise.all([...inflight.values()]);
      } finally {
        cleanup();
      }
    })();
    return disposal;
  }
  try {
    addListener("message", message);
    addListener("messageerror", failure);
  } catch (error) {
    cleanup();
    throw error;
  }
  return Object.freeze({ dispose });
}

// node_modules/@vmitsaras/raveldex/dist/adapters/worker/snapshots-host.js
function serveSnapshotRaveldexWorker(scope, options = {}) {
  return serveWorkerWithSnapshots(scope, options, (owner) => {
    const engine = facadeFromExecutionOwner(owner);
    return Object.freeze({
      exportSource: (options2, control) => controlledSnapshots(engine, {}, control).exportSource(options2),
      restore: (encoded2, options2, control) => controlledSnapshots(engine, {}, control).restore(encoded2, options2)
    });
  });
}

// node_modules/@vmitsaras/raveldex/dist/addons/phrases/verifier.js
var rawCharge2 = (workUnits) => ({ workUnits });
function* phraseFailureTable(terms) {
  const failure = [];
  if (terms.length) {
    yield rawCharge2(1);
    failure.push(0);
  }
  for (let i = 1; i < terms.length; i++) {
    let matched = failure[i - 1];
    for (; ; ) {
      if ((yield* compareStrings(terms[i], terms[matched], rawCharge2)) === 0) {
        matched++;
        break;
      }
      if (matched === 0)
        break;
      yield rawCharge2(1);
      matched = failure[matched - 1];
    }
    yield rawCharge2(1);
    failure.push(matched);
  }
  return Object.freeze(failure);
}
function* sourceValueMatches(value, valueIndex, terms, failure, limits, analyze = analyzeValue) {
  if (terms.length === 0)
    return false;
  let matched = 0;
  for (const step of analyze(value, valueIndex, limits, "INVALID_RECORD", "phrase")) {
    yield rawCharge2(step.workUnits);
    if (!step.token)
      continue;
    for (; ; ) {
      if ((yield* compareStrings(step.token.term, terms[matched], rawCharge2)) === 0) {
        matched++;
        if (matched === terms.length)
          return true;
        break;
      }
      if (matched === 0)
        break;
      yield rawCharge2(1);
      matched = failure[matched - 1];
    }
  }
  return false;
}

// node_modules/@vmitsaras/raveldex/dist/addons/phrases/index.js
var MAX_PHRASE_TOKENS = 32;
var rawCharge3 = (workUnits) => ({ workUnits });
function* preparePhrase(context, enabledFields) {
  const analyze = requireAnalysis(context);
  bound(context.terms.length, Math.min(MAX_PHRASE_TOKENS, context.limits.maxQueryTokens), "phrases.tokens");
  const fields2 = [];
  for (const field of context.fields) {
    yield rawCharge3(field.length + enabledFields.length + 1);
    if (!enabledFields.includes(field))
      invalid("MISSING_CAPABILITY", "phrases.field");
    const root = requireSourceRoot(context.state(`source:${field}`), field, context.revision, context.analyzer);
    yield rawCharge3(root.fields.length + 1);
    fields2.push(Object.freeze({ name: field, root }));
  }
  const failure = yield* phraseFailureTable(context.terms);
  const sources = Object.freeze(fields2);
  const terms = context.terms, limits = context.limits;
  return Object.freeze({
    *test(id) {
      const records = [];
      for (const field of sources) {
        yield rawCharge3(id.length + 1);
        const record = directoryGet(field.root.records, id);
        if (!record)
          invalid("MISSING_CAPABILITY", "phrases.source.record");
        if (!Object.isFrozen(record) || typeof record.text !== "object" || record.text === null || !Object.isFrozen(record.text))
          invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.record");
        records.push({ field: field.name, record });
      }
      for (const { field, record } of records) {
        const values = record.text[field];
        if (!values)
          continue;
        if (!Array.isArray(values) || !Object.isFrozen(values) || values.length > limits.maxTextValuesPerField)
          invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.values");
        for (let i = 0; i < values.length; i++) {
          yield rawCharge3(1);
          if (typeof values[i] !== "string")
            invalid("INCOMPATIBLE_CAPABILITY", "phrases.source.values");
          if (yield* sourceValueMatches(values[i], i, terms, failure, limits, analyze))
            return true;
        }
      }
      return false;
    }
  });
}
function createSourcePhrases(options) {
  const captured = capturePhraseOptions(options, false);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["leaf-refinement"]),
      provides: Object.freeze([Object.freeze({ id: "phrases", contractVersion: 1 })]),
      requires: Object.freeze(captured.fields.map((field) => Object.freeze({ id: `source:${field}`, contractVersion: 1 }))),
      dataRequirements: Object.freeze({ fields: captured.fields, source: true, positions: false, offsets: false, metadata: false }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("source-phrases", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Native analyzer, resumable source phrase verifier and selected-source protocol.", retainedRepresentation: "No additional index state; source providers retain declared originals.", transientWork: "At most 32 phrase-prefix entries plus one current token; complete lexical candidates are scanned under the shared search budget.", externalResources: "none" })
    }),
    refinement: Object.freeze({
      kind: "exact-token-sequence",
      maxTokens: MAX_PHRASE_TOKENS,
      prepare: (context) => preparePhrase(context, captured.fields)
    })
  });
}

// node_modules/@vmitsaras/raveldex/dist/addons/positions/options.js
function positionEntryCeiling(documents, fields2, values, tokens, offsets) {
  return documents * (1 + fields2 * (1 + values)) + tokens * (offsets ? 4 : 2);
}
function capturePositionOptions(input, participant) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const options = ownObject(input, "INVALID_OPTIONS", "positions.options", admission);
  keysOnly(options, participant ? ["fields", "offsets", "id", "maxRetainedEntries", "maxWorkUnits"] : ["fields", "id", "maxWorkUnits"], "INVALID_OPTIONS", "positions.options");
  const captureFields = (input2, path) => {
    const seen = /* @__PURE__ */ new Set();
    return Object.freeze(ownArray(input2, DEFAULT_LIMITS.maxTextFields, "INVALID_OPTIONS", path, admission).map((value) => {
      const field = stringValue(value, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", path);
      if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) || field === "constructor" || field === "prototype" || seen.has(field))
        invalid("INVALID_OPTIONS", path);
      seen.add(field);
      return field;
    }));
  };
  const fields2 = captureFields(options.fields, "positions.fields");
  if (!fields2.length)
    invalid("INVALID_OPTIONS", "positions.fields");
  const offsetFields = participant && has(options, "offsets") ? captureFields(options.offsets, "positions.offsets") : Object.freeze([]);
  if (offsetFields.some((field) => !fields2.includes(field)))
    invalid("INVALID_OPTIONS", "positions.offsets");
  const id = has(options, "id") ? stringValue(options.id, 64, "INVALID_OPTIONS", "positions.id") : participant ? "positions" : "position-phrases";
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "positions.id");
  const workCeiling = participant ? DEFAULT_LIMITS.maxMutationWorkUnits : DEFAULT_LIMITS.maxSearchWorkUnits;
  const maxWorkUnits = has(options, "maxWorkUnits") ? options.maxWorkUnits : workCeiling;
  if (typeof maxWorkUnits !== "number" || !Number.isSafeInteger(maxWorkUnits) || maxWorkUnits < 1)
    invalid("INVALID_OPTIONS", "positions.maxWorkUnits");
  bound(maxWorkUnits, workCeiling, "positions.maxWorkUnits");
  const ceiling = positionEntryCeiling(DEFAULT_LIMITS.maxDocuments, fields2.length, DEFAULT_LIMITS.maxTextValuesPerField, DEFAULT_LIMITS.maxCorpusTokens, offsetFields.length > 0);
  const maxRetainedEntries = participant && has(options, "maxRetainedEntries") ? options.maxRetainedEntries : participant ? ceiling : 0;
  if (typeof maxRetainedEntries !== "number" || !Number.isSafeInteger(maxRetainedEntries) || maxRetainedEntries < 0)
    invalid("INVALID_OPTIONS", "positions.maxRetainedEntries");
  bound(maxRetainedEntries, ceiling, "positions.maxRetainedEntries");
  return Object.freeze({ fields: fields2, offsetFields, id, maxWorkUnits, maxRetainedEntries });
}

// node_modules/@vmitsaras/raveldex/dist/addons/positions/store.js
var rawCharge4 = (workUnits) => ({ workUnits });
var finiteCount = (value) => Number.isSafeInteger(value) && value >= 0;
var fieldNames = (fields2) => fields2.every((field) => typeof field === "string" && /^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) && field !== "constructor" && field !== "prototype") && new Set(fields2).size === fields2.length;
function requirePositionRoot(input, field, revision, analyzer) {
  if (input === void 0 || input === null)
    invalid("MISSING_CAPABILITY", "phrases.positions");
  if (typeof input !== "object" || !Object.isFrozen(input))
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions");
  const root = input;
  if (root.kind !== (analyzer.id === "code-identifiers-v1" ? "raveldex-positions-v2" : "raveldex-positions-v1") || !Array.isArray(root.fields) || !Object.isFrozen(root.fields) || !root.fields.length || root.fields.length > DEFAULT_LIMITS.maxTextFields || !fieldNames(root.fields) || !Array.isArray(root.offsetFields) || !Object.isFrozen(root.offsetFields) || root.offsetFields.length > root.fields.length || !fieldNames(root.offsetFields) || root.offsetFields.some((name2) => !root.fields.includes(name2)) || typeof root.analyzer !== "object" || root.analyzer === null || !Object.isFrozen(root.analyzer) || typeof root.limits !== "object" || root.limits === null || !Object.isFrozen(root.limits) || typeof root.records !== "object" || root.records === null || !Object.isFrozen(root.records) || !finiteCount(root.records.size) || root.records.size > DEFAULT_LIMITS.maxDocuments || typeof root.records.buckets !== "object" || root.records.buckets === null || !Object.isFrozen(root.records.buckets) || !finiteCount(root.revision) || !finiteCount(root.retainedEntries) || !finiteCount(root.occurrenceCount) || !finiteCount(root.offsetCount) || root.offsetCount > root.occurrenceCount || !finiteCount(root.termEntries) || root.termEntries > root.occurrenceCount || !finiteCount(root.termCodeUnits) || !finiteCount(root.maxRetainedEntries) || root.maxRetainedEntries < root.retainedEntries || !finiteCount(root.maxOccurrences) || root.maxOccurrences < root.occurrenceCount || !finiteCount(root.maxTermCodeUnits) || root.maxTermCodeUnits < root.termCodeUnits)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions");
  for (const key of ["maxDocuments", "maxTextValuesPerField", "maxTextCodeUnitsPerValue", "maxTokensPerRecord", "maxCorpusTokens", "maxTermCodeUnits"]) {
    const value = root.limits[key];
    if (!Number.isSafeInteger(value) || value < 1 || value > DEFAULT_LIMITS[key])
      invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.limits");
  }
  if (root.records.size > root.limits.maxDocuments || root.maxOccurrences > root.limits.maxCorpusTokens || root.maxTermCodeUnits > root.limits.maxCorpusTokens * root.limits.maxTermCodeUnits || root.maxRetainedEntries > positionEntryCeiling(root.limits.maxDocuments, root.fields.length, root.limits.maxTextValuesPerField, root.limits.maxCorpusTokens, root.offsetFields.length > 0))
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.limits");
  if (!root.fields.includes(field))
    invalid("MISSING_CAPABILITY", "phrases.positions.field");
  if (root.revision !== revision)
    invalid("REVISION_MISMATCH", "phrases.positions.revision");
  if (root.analyzer.id !== analyzer.id || root.analyzer.environmentProfile !== analyzer.environmentProfile)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.analyzer");
  return root;
}
function initialRoot2(configuration, fields2, offsetFields, requestedEntries) {
  createAnalysis(configuration);
  for (const field of fields2)
    if (!has(configuration.schema.text, field))
      invalid("MISSING_CAPABILITY", "positions.fields");
  const limits = configuration.limits;
  return Object.freeze({
    kind: configuration.analyzer.id === "code-identifiers-v1" ? "raveldex-positions-v2" : "raveldex-positions-v1",
    revision: 0,
    analyzer: Object.freeze({ id: configuration.analyzer.id, environmentProfile: configuration.analyzer.environmentProfile }),
    fields: fields2,
    offsetFields,
    limits,
    records: emptyDirectory(),
    retainedEntries: 0,
    occurrenceCount: 0,
    offsetCount: 0,
    termEntries: 0,
    termCodeUnits: 0,
    maxRetainedEntries: Math.min(requestedEntries, positionEntryCeiling(limits.maxDocuments, fields2.length, limits.maxTextValuesPerField, limits.maxCorpusTokens, offsetFields.length > 0)),
    maxOccurrences: limits.maxCorpusTokens,
    maxTermCodeUnits: limits.maxCorpusTokens * limits.maxTermCodeUnits
  });
}
function* retainRecord2(record, root, analyze) {
  const positions2 = /* @__PURE__ */ Object.create(null);
  let retainedEntries = 1, occurrenceCount = 0, offsetCount = 0, termEntries = 0, termCodeUnits = 0;
  for (const field of root.fields) {
    yield rawCharge4(field.length + root.offsetFields.length + 1);
    if (!has(record.text, field))
      continue;
    const withOffsets = root.offsetFields.includes(field), values = [];
    retainedEntries += 1;
    for (let valueIndex = 0; valueIndex < record.text[field].length; valueIndex++) {
      yield rawCharge4(1);
      retainedEntries++;
      const terms = /* @__PURE__ */ Object.create(null);
      let tokenCount = 0, originalCount = 0;
      for (const step of analyze(record.text[field][valueIndex], valueIndex, root.limits)) {
        yield rawCharge4(step.workUnits);
        if (!step.token)
          continue;
        const token = step.token;
        yield rawCharge4(token.term.length + (withOffsets ? 4 : 2));
        if (root.kind === "raveldex-positions-v1") {
          if (token.kind !== void 0 || token.original !== void 0 || token.position !== tokenCount)
            invalid("INTERNAL_ERROR", "positions.order");
        } else {
          if (token.kind === "original") {
            if (token.position !== originalCount++)
              invalid("INTERNAL_ERROR", "positions.order");
          } else if (token.kind !== "component" || token.position !== originalCount - 1 || !token.original)
            invalid("INTERNAL_ERROR", "positions.order");
        }
        tokenCount++;
        const occurrence = Object.freeze({
          position: token.position,
          positionLength: 1,
          ...root.kind === "raveldex-positions-v2" ? { kind: token.kind } : {},
          ...withOffsets ? { start: token.start, end: token.end } : {}
        });
        if (!has(terms, token.term)) {
          terms[token.term] = [];
          termEntries++;
          termCodeUnits += token.term.length;
          retainedEntries++;
        }
        terms[token.term].push(occurrence);
        occurrenceCount++;
        retainedEntries++;
        if (withOffsets) {
          offsetCount++;
          retainedEntries += 2;
        }
        bound(occurrenceCount, root.limits.maxTokensPerRecord, "positions.record.tokens");
        bound(retainedEntries, root.maxRetainedEntries, "positions.retainedEntries");
      }
      for (const term of Object.keys(terms)) {
        yield rawCharge4(term.length + terms[term].length + 1);
        Object.freeze(terms[term]);
      }
      values.push(Object.freeze({ tokenCount, ...root.kind === "raveldex-positions-v2" ? { originalCount } : {}, terms: Object.freeze(terms) }));
    }
    positions2[field] = Object.freeze(values);
  }
  return Object.freeze({ positions: Object.freeze(positions2), retainedEntries, occurrenceCount, offsetCount, termEntries, termCodeUnits });
}
function* preparePositions(previous, context, fields2) {
  const analyze = requireAnalysis(context);
  const old = requirePositionRoot(previous, fields2[0], context.previousRevision, context.analyzer);
  if (context.revision !== context.previousRevision + 1 || !Number.isSafeInteger(context.revision))
    invalid("REVISION_MISMATCH", "positions.revision");
  if (context.kind === "clear") {
    yield rawCharge4(1);
    return Object.freeze({ ...old, revision: context.revision, records: emptyDirectory(), retainedEntries: 0, occurrenceCount: 0, offsetCount: 0, termEntries: 0, termCodeUnits: 0 });
  }
  const stage = new DirectoryStage(old.records, rawCharge4);
  let retainedEntries = old.retainedEntries, occurrenceCount = old.occurrenceCount, offsetCount = old.offsetCount, termEntries = old.termEntries, termCodeUnits = old.termCodeUnits;
  const adjust = (record, sign) => {
    retainedEntries += sign * record.retainedEntries;
    occurrenceCount += sign * record.occurrenceCount;
    offsetCount += sign * record.offsetCount;
    termEntries += sign * record.termEntries;
    termCodeUnits += sign * record.termCodeUnits;
  };
  for (const id of context.removedIds) {
    yield rawCharge4(id.length + 1);
    const retained = stage.get(id);
    if (!retained)
      invalid("MISSING_CAPABILITY", "positions.record");
    adjust(retained, -1);
    yield* stage.delete(id);
  }
  for (const record of context.records) {
    yield rawCharge4(record.id.length + 1);
    const retained = stage.get(record.id);
    if (context.kind === "replace" && !retained)
      invalid("MISSING_CAPABILITY", "positions.record");
    if (context.kind !== "replace" && retained)
      invalid("INCOMPATIBLE_CAPABILITY", "positions.record");
    if (retained)
      adjust(retained, -1);
    const next = yield* retainRecord2(record, old, analyze);
    adjust(next, 1);
    bound(retainedEntries, old.maxRetainedEntries, "positions.retainedEntries");
    bound(occurrenceCount, old.maxOccurrences, "positions.occurrences");
    bound(termCodeUnits, old.maxTermCodeUnits, "positions.termCodeUnits");
    yield* stage.set(record.id, next);
  }
  if ([retainedEntries, occurrenceCount, offsetCount, termEntries, termCodeUnits].some((count5) => !finiteCount(count5)))
    invalid("INCOMPATIBLE_CAPABILITY", "positions.counts");
  const records = yield* stage.finish();
  return Object.freeze({ ...old, revision: context.revision, records, retainedEntries, occurrenceCount, offsetCount, termEntries, termCodeUnits });
}
function bulkPositions(initial, fields2) {
  const old = requirePositionRoot(initial, fields2[0], 0, initial?.analyzer);
  if (old.records.size !== 0 || [old.retainedEntries, old.occurrenceCount, old.offsetCount, old.termEntries, old.termCodeUnits].some((count5) => count5 !== 0))
    invalid("INCOMPATIBLE_CAPABILITY", "positions.bulk.initial");
  const stage = new DirectoryStage(old.records, rawCharge4);
  let revision = 0, retainedEntries = 0, occurrenceCount = 0, offsetCount = 0, termEntries = 0, termCodeUnits = 0, sealed = false;
  return Object.freeze({
    *add(context) {
      if (sealed)
        invalid("INTERNAL_ERROR", "positions.bulk.sealed");
      const analyze = requireAnalysis(context);
      if (context.kind !== "add" || context.records.length !== 1 || context.removedIds.length !== 0)
        invalid("INCOMPATIBLE_CAPABILITY", "positions.bulk.add");
      if (context.previousRevision !== revision || context.revision !== revision + 1 || !Number.isSafeInteger(context.revision))
        invalid("REVISION_MISMATCH", "positions.revision");
      if (context.analyzer.id !== old.analyzer.id || context.analyzer.environmentProfile !== old.analyzer.environmentProfile)
        invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.analyzer");
      const record = context.records[0];
      yield rawCharge4(record.id.length + 1);
      if (stage.get(record.id))
        invalid("INCOMPATIBLE_CAPABILITY", "positions.record");
      const next = yield* retainRecord2(record, old, analyze);
      retainedEntries += next.retainedEntries;
      occurrenceCount += next.occurrenceCount;
      offsetCount += next.offsetCount;
      termEntries += next.termEntries;
      termCodeUnits += next.termCodeUnits;
      bound(retainedEntries, old.maxRetainedEntries, "positions.retainedEntries");
      bound(occurrenceCount, old.maxOccurrences, "positions.occurrences");
      bound(termCodeUnits, old.maxTermCodeUnits, "positions.termCodeUnits");
      if ([retainedEntries, occurrenceCount, offsetCount, termEntries, termCodeUnits].some((count5) => !finiteCount(count5)))
        invalid("INCOMPATIBLE_CAPABILITY", "positions.counts");
      yield* stage.set(record.id, next);
      revision = context.revision;
    },
    *finish(finalRevision) {
      if (sealed)
        invalid("INTERNAL_ERROR", "positions.bulk.sealed");
      if (finalRevision !== revision || !Number.isSafeInteger(finalRevision))
        invalid("REVISION_MISMATCH", "positions.revision");
      sealed = true;
      const records = yield* stage.finish();
      return Object.freeze({ ...old, revision, records, retainedEntries, occurrenceCount, offsetCount, termEntries, termCodeUnits });
    }
  });
}
function createPositionProvider(options) {
  const captured = capturePositionOptions(options, true);
  const registration = Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["transaction-participant"]),
      provides: Object.freeze([...captured.fields.map((field) => Object.freeze({ id: `positions:${field}`, contractVersion: 1 })), ...captured.offsetFields.map((field) => Object.freeze({ id: `offsets:${field}`, contractVersion: 1 }))]),
      requires: Object.freeze([]),
      dataRequirements: Object.freeze({ fields: captured.fields, source: false, positions: true, offsets: captured.offsetFields.length > 0, metadata: false }),
      indexEffect: "transactional",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("positions", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: captured.maxRetainedEntries, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Native analyzer and selected-position copy-on-write staging; no phrase verifier.", retainedRepresentation: "Record, selected-field/value and term containers, ordered occurrences with positionLength 1, and two original span coordinates only for selected offset fields; no display source or metadata.", transientWork: "One native analysis per changed selected value, occurrence construction and touched directory buckets; shared mutation budget.", externalResources: "none" }),
      codec: Object.freeze({ id: "raveldex-positions-v1", version: 1 })
    }),
    participant: Object.freeze({
      initialize: (configuration) => initialRoot2(configuration, captured.fields, captured.offsetFields, captured.maxRetainedEntries),
      prepare: (previous, context) => preparePositions(previous, context, captured.fields)
    })
  });
  return registerBulkParticipant(registration, (initial) => bulkPositions(initial, captured.fields));
}

// node_modules/@vmitsaras/raveldex/dist/addons/positions/verifier.js
var rawCharge5 = (workUnits) => ({ workUnits });
var finiteCount2 = (value) => Number.isSafeInteger(value) && value >= 0;
function* requireOccurrences(value, term, offsets, maximumSpan) {
  yield rawCharge5(term.length + 1);
  if (!has(value.terms, term))
    return Object.freeze([]);
  const occurrences = value.terms[term];
  if (!Array.isArray(occurrences) || !Object.isFrozen(occurrences) || !occurrences.length || occurrences.length > value.tokenCount)
    invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.occurrences");
  let last = -1;
  for (const occurrence of occurrences) {
    yield rawCharge5(offsets ? 5 : 3);
    if (typeof occurrence !== "object" || occurrence === null || !Object.isFrozen(occurrence) || !finiteCount2(occurrence.position) || occurrence.position >= value.tokenCount || occurrence.position <= last || occurrence.positionLength !== 1 || Object.keys(occurrence).some((key) => key !== "position" && key !== "positionLength" && key !== "start" && key !== "end"))
      invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.occurrence");
    if (offsets) {
      if (!has(occurrence, "start") || !has(occurrence, "end") || !finiteCount2(occurrence.start) || !finiteCount2(occurrence.end) || occurrence.end <= occurrence.start || occurrence.end > maximumSpan)
        invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.offsets");
    } else if (has(occurrence, "start") || has(occurrence, "end"))
      invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.offsets");
    last = occurrence.position;
  }
  return occurrences;
}
function* intersectOffsets(lists) {
  if (!lists.length || lists.some((list) => !list.length))
    return false;
  const cursors = lists.map(() => 0);
  for (const start of lists[0]) {
    yield rawCharge5(1);
    let matched = true;
    for (let offset = 1; offset < lists.length; offset++) {
      const list = lists[offset], target = start.position + offset;
      let cursor = cursors[offset];
      while (cursor < list.length) {
        yield rawCharge5(1);
        if (list[cursor].position >= target)
          break;
        cursor++;
      }
      cursors[offset] = cursor;
      yield rawCharge5(1);
      if (cursor === list.length || list[cursor].position !== target)
        matched = false;
    }
    if (matched)
      return true;
  }
  return false;
}
function* preparePositionField(context, field) {
  return yield* preparePositionFieldWith(context, field, context.terms, intersectOffsets);
}
function* preparePositionFieldWith(context, field, terms, matches) {
  requireAnalysis(context);
  yield rawCharge5(field.length + 1);
  const root = requirePositionRoot(context.state(`positions:${field}`), field, context.revision, context.analyzer);
  yield rawCharge5(root.fields.length + root.offsetFields.length + 1);
  const offsets = root.offsetFields.includes(field);
  return Object.freeze({
    *test(id) {
      yield rawCharge5(id.length + 1);
      const record = directoryGet(root.records, id);
      if (!record)
        invalid("MISSING_CAPABILITY", "phrases.positions.record");
      if (!Object.isFrozen(record) || typeof record.positions !== "object" || record.positions === null || !Object.isFrozen(record.positions) || Object.getPrototypeOf(record.positions) !== null || !finiteCount2(record.retainedEntries) || !finiteCount2(record.occurrenceCount) || record.occurrenceCount > root.limits.maxTokensPerRecord || !finiteCount2(record.offsetCount) || record.offsetCount > record.occurrenceCount || !finiteCount2(record.termEntries) || record.termEntries > record.occurrenceCount || !finiteCount2(record.termCodeUnits))
        invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.record");
      if (!has(record.positions, field))
        return false;
      const values = record.positions[field];
      if (!Array.isArray(values) || !Object.isFrozen(values) || values.length > root.limits.maxTextValuesPerField)
        invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.values");
      let matched = false;
      for (const value of values) {
        yield rawCharge5(1);
        if (typeof value !== "object" || value === null || !Object.isFrozen(value) || !finiteCount2(value.tokenCount) || value.tokenCount > root.limits.maxTokensPerRecord || typeof value.terms !== "object" || value.terms === null || !Object.isFrozen(value.terms) || Object.getPrototypeOf(value.terms) !== null)
          invalid("INCOMPATIBLE_CAPABILITY", "phrases.positions.value");
        const byTerm = /* @__PURE__ */ new Map(), lists = [];
        if (root.kind === "raveldex-positions-v2") {
          const tokens = yield* taggedPositionTokens(value, offsets, root.limits);
          const originals = /* @__PURE__ */ new Map();
          for (const token of tokens) {
            yield rawCharge5(token.term.length + 1);
            if (token.kind !== "original")
              continue;
            const list = originals.get(token.term) ?? [];
            list.push(token);
            originals.set(token.term, list);
          }
          for (const term of terms) {
            yield rawCharge5(term.length + 1);
            lists.push(originals.get(term) ?? []);
          }
          if (yield* matches(lists))
            matched = true;
          continue;
        }
        for (const term of terms) {
          yield rawCharge5(term.length + 1);
          let list = byTerm.get(term);
          if (!list) {
            list = yield* requireOccurrences(value, term, offsets, root.limits.maxTextCodeUnitsPerValue);
            byTerm.set(term, list);
          }
          lists.push(list);
        }
        if (yield* matches(lists))
          matched = true;
      }
      return matched;
    }
  });
}

// node_modules/@vmitsaras/raveldex/dist/addons/phrases/mixed.js
function createPhrases(options) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const raw = ownObject(options, "INVALID_OPTIONS", "phrases.options", admission);
  keysOnly(raw, ["fields", "id", "maxWorkUnits"], "INVALID_OPTIONS", "phrases.options");
  const data2 = ownObject(raw.fields, "INVALID_OPTIONS", "phrases.fields", admission);
  const fields2 = Object.keys(data2);
  const captured = capturePhraseOptions({ fields: fields2, ...has(raw, "id") ? { id: raw.id } : { id: "mixed-phrases" }, ...has(raw, "maxWorkUnits") ? { maxWorkUnits: raw.maxWorkUnits } : {} }, false);
  const strategies = /* @__PURE__ */ Object.create(null);
  for (const field of captured.fields) {
    const strategy = stringValue(data2[field], 16, "INVALID_OPTIONS", "phrases.strategy");
    if (strategy !== "source" && strategy !== "positions")
      invalid("INVALID_OPTIONS", "phrases.strategy");
    strategies[field] = strategy;
  }
  Object.freeze(strategies);
  const source2 = captured.fields.filter((field) => strategies[field] === "source");
  const sourceHandler = source2.length ? createSourcePhrases({ fields: source2 }).refinement : void 0;
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["leaf-refinement"]),
      provides: Object.freeze([Object.freeze({ id: "phrases", contractVersion: 1 })]),
      requires: Object.freeze(captured.fields.map((field) => Object.freeze({ id: `${strategies[field]}:${field}`, contractVersion: 1 }))),
      dataRequirements: Object.freeze({ fields: captured.fields, source: source2.length > 0, positions: source2.length < captured.fields.length, offsets: false, metadata: false }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("mixed-phrases", { captured, strategies }) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Explicit source and position strict phrase verifiers.", retainedRepresentation: "No extra state; declared providers own each selected representation.", transientWork: "Complete lexical candidates; per-field source scans or ordered occurrence intersections under one shared search budget.", externalResources: "none" })
    }),
    refinement: Object.freeze({
      kind: "exact-token-sequence",
      maxTokens: 32,
      *prepare(context) {
        const verifiers = [];
        for (const field of context.fields) {
          yield { workUnits: field.length + 1 };
          if (!has(strategies, field))
            invalid("MISSING_CAPABILITY", "phrases.field");
          if (strategies[field] === "positions")
            verifiers.push(yield* preparePositionField(context, field));
          else
            verifiers.push(yield* sourceHandler.prepare(Object.freeze({ ...context, fields: Object.freeze([field]) })));
        }
        return Object.freeze({ *test(id) {
          let matched = false;
          for (const verifier of verifiers)
            if (yield* verifier.test(id))
              matched = true;
          return matched;
        } });
      }
    })
  });
}

// node_modules/@vmitsaras/raveldex/dist/addons/metadata/payload.js
function copyPayload(input, admission, code, maximum) {
  let codeUnits = 0;
  const path = "extensions.payload", ancestors = /* @__PURE__ */ new Set();
  const text2 = (value) => {
    codeUnits += value.length;
    bound(codeUnits, maximum, path);
    return value;
  };
  function copy(value, depth) {
    bound(depth, 16, path);
    if (typeof value === "string")
      return text2(value);
    if (value === null || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value))
      return value;
    if (typeof value !== "object" || value === null || ancestors.has(value))
      invalid(code, path);
    ancestors.add(value);
    let owned;
    if (Array.isArray(value))
      owned = Object.freeze(ownArray(value, admission.maximum, code, path, admission).map((item) => copy(item, depth + 1)));
    else {
      const data2 = ownObject(value, code, path, admission);
      for (const key of Object.keys(data2)) {
        text2(key);
        data2[key] = copy(data2[key], depth + 1);
      }
      owned = Object.freeze(data2);
    }
    ancestors.delete(value);
    return owned;
  }
  return Object.freeze({ value: copy(input, 1), codeUnits });
}
function captureMetadataPayload(input, context, code) {
  return copyPayload(input, context.admission, code, context.maxCodeUnits);
}
function* validatePayload(value, code) {
  yield { workUnits: 1 };
  if (typeof value === "string")
    yield* scanUnicode(value, code, "extensions.payload");
  else if (Array.isArray(value))
    for (const item of value)
      yield* validatePayload(item, code);
  else if (value !== null && typeof value === "object")
    for (const [key, item] of Object.entries(value)) {
      yield* scanUnicode(key, code, "extensions.payload");
      yield* validatePayload(item, code);
    }
}
function* captureMetadataOutput(input, limits) {
  const admission = new Admission(limits.maxAdmissionEntries);
  const captured = copyPayload(input, admission, "INCOMPATIBLE_CAPABILITY", limits.maxAdmissionEntries * limits.maxMetadataStringCodeUnits);
  yield { workUnits: admission.count + captured.codeUnits };
  yield* validatePayload(captured.value, "INCOMPATIBLE_CAPABILITY");
  return Object.freeze({ value: captured.value, entries: admission.count });
}

// node_modules/@vmitsaras/raveldex/dist/addons/filters/options.js
function captureFilterOptions(input) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const options = ownObject(input, "INVALID_OPTIONS", "filters.options", admission);
  keysOnly(options, ["fields", "id", "maxWorkUnits"], "INVALID_OPTIONS", "filters.options");
  const inputs = ownArray(options.fields, DEFAULT_LIMITS.maxMetadataFields, "INVALID_OPTIONS", "filters.fields", admission);
  if (inputs.length === 0)
    invalid("INVALID_OPTIONS", "filters.fields");
  const seen = /* @__PURE__ */ new Set();
  const fields2 = Object.freeze(inputs.map((inputField) => {
    const field = stringValue(inputField, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", "filters.fields");
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) || field === "constructor" || field === "prototype" || seen.has(field))
      invalid("INVALID_OPTIONS", "filters.fields");
    seen.add(field);
    return field;
  }));
  const id = has(options, "id") ? stringValue(options.id, 64, "INVALID_OPTIONS", "filters.id") : "filters";
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "filters.id");
  const maxWorkUnits = has(options, "maxWorkUnits") ? options.maxWorkUnits : DEFAULT_LIMITS.maxSearchWorkUnits;
  if (typeof maxWorkUnits !== "number" || !Number.isSafeInteger(maxWorkUnits) || maxWorkUnits < 1)
    invalid("INVALID_OPTIONS", "filters.maxWorkUnits");
  bound(maxWorkUnits, DEFAULT_LIMITS.maxSearchWorkUnits, "filters.maxWorkUnits");
  return Object.freeze({ fields: fields2, id, maxWorkUnits });
}

// node_modules/@vmitsaras/raveldex/dist/addons/filters/index.js
var charge2 = (workUnits) => ({ workUnits });
function* prepareFilter(context, enabled) {
  yield* validatePayload(context.payload, "INVALID_QUERY");
  const admission = new Admission(context.limits.maxAdmissionEntries);
  const payload = ownObject(context.payload, "INVALID_QUERY", "filters.payload", admission);
  yield charge2(admission.count + 1);
  const range = context.capability === "numeric-range";
  if (!range && context.capability !== "set-membership")
    invalid("INCOMPATIBLE_CAPABILITY", "filters.capability");
  keysOnly(payload, range ? ["field", "gt", "gte", "lt", "lte"] : ["field", "values"], "INVALID_QUERY", "filters.payload");
  yield charge2(Object.keys(payload).length + 1);
  const field = stringValue(payload.field, context.limits.maxFieldNameCodeUnits, "INVALID_QUERY", "filters.field");
  yield charge2(field.length + 1);
  const descriptor = context.schema.metadata[field];
  if (!descriptor)
    invalid("INVALID_QUERY", "filters.field");
  let selected = false;
  for (const allowed of enabled) {
    yield charge2(allowed.length + field.length + 1);
    if (allowed === field) {
      selected = true;
      break;
    }
  }
  if (!selected)
    invalid("MISSING_CAPABILITY", "filters.field");
  if (range) {
    if (descriptor.type !== "number")
      invalid("INVALID_QUERY", "filters.field.type");
    const lowerName = has(payload, "gt") ? "gt" : has(payload, "gte") ? "gte" : void 0;
    const upperName = has(payload, "lt") ? "lt" : has(payload, "lte") ? "lte" : void 0;
    yield charge2(6);
    if (has(payload, "gt") && has(payload, "gte") || has(payload, "lt") && has(payload, "lte") || !lowerName && !upperName)
      invalid("INVALID_QUERY", "filters.bounds");
    const lower2 = lowerName ? payload[lowerName] : void 0;
    const upper = upperName ? payload[upperName] : void 0;
    for (const endpoint of [lower2, upper]) {
      yield charge2(1);
      if (endpoint !== void 0 && (typeof endpoint !== "number" || !Number.isFinite(endpoint)))
        invalid("INVALID_QUERY", "filters.bounds");
    }
    if (lowerName && lower2 === void 0 || upperName && upper === void 0)
      invalid("INVALID_QUERY", "filters.bounds");
    yield charge2(1);
    if (typeof lower2 === "number" && typeof upper === "number" && lower2 > upper)
      invalid("INVALID_QUERY", "filters.bounds");
    const lowerBound = lower2, upperBound = upper;
    return Object.freeze({
      *test(metadata2) {
        yield charge2(field.length + 1);
        if (!has(metadata2, field))
          return false;
        const value = metadata2[field];
        const values2 = Array.isArray(value) ? value : [value];
        for (const item of values2) {
          yield charge2(1);
          if (typeof item !== "number")
            continue;
          let matches = true;
          if (lowerBound !== void 0) {
            yield charge2(1);
            matches = lowerName === "gt" ? item > lowerBound : item >= lowerBound;
          }
          if (upperBound !== void 0) {
            yield charge2(1);
            matches = matches && (upperName === "lt" ? item < upperBound : item <= upperBound);
          }
          if (matches)
            return true;
        }
        return false;
      }
    });
  }
  const values = ownArray(payload.values, Math.min(128, context.limits.maxMetadataValuesPerField), "INVALID_QUERY", "filters.values", admission);
  yield charge2(values.length + 1);
  if (values.length === 0)
    invalid("INVALID_QUERY", "filters.values");
  for (const value of values) {
    yield charge2(typeof value === "string" ? value.length + 1 : 1);
    if (value === null) {
      if (!descriptor.nullable)
        invalid("INVALID_QUERY", "filters.values");
    } else if (typeof value !== descriptor.type)
      invalid("INVALID_QUERY", "filters.values");
    else if (typeof value === "number" && !Number.isFinite(value))
      invalid("INVALID_QUERY", "filters.values");
    else if (typeof value === "string")
      bound(value.length, context.limits.maxMetadataStringCodeUnits, "filters.values");
  }
  const requested = Object.freeze(values);
  return Object.freeze({
    *test(metadata2) {
      yield charge2(field.length + 1);
      if (!has(metadata2, field))
        return false;
      const value = metadata2[field];
      const actual = Array.isArray(value) ? value : [value];
      for (const item of actual) {
        yield charge2(1);
        for (const candidate of requested) {
          yield charge2(typeof item === "string" && typeof candidate === "string" ? item.length + candidate.length + 1 : 1);
          if (item === candidate)
            return true;
        }
      }
      return false;
    }
  });
}
function createFilters(options) {
  const captured = captureFilterOptions(options);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["leaf-refinement"]),
      provides: Object.freeze(["numeric-range", "set-membership"].map((id) => Object.freeze({ id, contractVersion: 1 }))),
      requires: Object.freeze([]),
      dataRequirements: Object.freeze({ fields: captured.fields, source: false, positions: false, offsets: false, metadata: true }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("filters", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: 0 }),
      costs: Object.freeze({ importedCode: "Typed numeric-range and set-membership metadata predicates.", retainedRepresentation: "No side index or copied metadata; reads the immutable core revision.", transientWork: "Bounded owned payload and complete candidate evaluation under the shared search budget.", externalResources: "none" })
    }),
    predicate: Object.freeze({
      capture: (input, context) => captureMetadataPayload(input, context, "INVALID_QUERY"),
      prepare: (context) => prepareFilter(context, captured.fields)
    })
  });
}

// node_modules/@vmitsaras/raveldex/dist/addons/facets/options.js
function captureFacetOptions(input) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const options = ownObject(input, "INVALID_OPTIONS", "facets.options", admission);
  keysOnly(options, ["fields", "id", "maxWorkUnits", "maxDistinctValuesPerField", "maxBucketsPerField"], "INVALID_OPTIONS", "facets.options");
  const seen = /* @__PURE__ */ new Set();
  const fields2 = Object.freeze(ownArray(options.fields, DEFAULT_LIMITS.maxMetadataFields, "INVALID_OPTIONS", "facets.fields", admission).map((value) => {
    const field = stringValue(value, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", "facets.fields");
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field) || field === "constructor" || field === "prototype" || seen.has(field))
      invalid("INVALID_OPTIONS", "facets.fields");
    seen.add(field);
    return field;
  }));
  if (!fields2.length)
    invalid("INVALID_OPTIONS", "facets.fields");
  const id = has(options, "id") ? stringValue(options.id, 64, "INVALID_OPTIONS", "facets.id") : "facets";
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "facets.id");
  const integer5 = (key, fallback, maximum, minimum) => {
    const value = has(options, key) ? options[key] : fallback;
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum)
      invalid("INVALID_OPTIONS", `facets.${key}`);
    bound(value, maximum, `facets.${key}`);
    return value;
  };
  return Object.freeze({
    fields: fields2,
    id,
    maxWorkUnits: integer5("maxWorkUnits", DEFAULT_LIMITS.maxSearchWorkUnits, DEFAULT_LIMITS.maxSearchWorkUnits, 1),
    maxDistinctValuesPerField: integer5("maxDistinctValuesPerField", 1e4, 1e4, 1),
    maxBucketsPerField: integer5("maxBucketsPerField", 100, 100, 0)
  });
}

// node_modules/@vmitsaras/raveldex/dist/addons/facets/facets.js
var charge3 = (workUnits = 1) => ({ workUnits });
function* compare(a, b) {
  yield charge3();
  if (a.count !== b.count)
    return b.count - a.count;
  if (a.missing !== b.missing)
    return a.missing ? 1 : -1;
  if (a.missing)
    return 0;
  if (a.value === null || b.value === null)
    return a.value === b.value ? 0 : a.value === null ? -1 : 1;
  const left = a.value, right = b.value;
  for (let index = 0; index < Math.min(left.length, right.length); index++) {
    yield charge3();
    const delta = left.charCodeAt(index) - right.charCodeAt(index);
    if (delta)
      return delta;
  }
  yield charge3();
  return left.length - right.length;
}
function* select(heap, bucket, maximum) {
  yield charge3();
  if (!maximum)
    return;
  if (heap.length < maximum) {
    let index = heap.length;
    heap.push(bucket);
    while (index) {
      const parent = Math.floor((index - 1) / 2);
      if ((yield* compare(heap[index], heap[parent])) <= 0)
        break;
      yield charge3();
      [heap[index], heap[parent]] = [heap[parent], heap[index]];
      index = parent;
    }
    return;
  }
  if ((yield* compare(bucket, heap[0])) >= 0)
    return;
  heap[0] = bucket;
  yield charge3();
  for (let index = 0; ; ) {
    const left = index * 2 + 1;
    if (left >= heap.length)
      break;
    const right = left + 1;
    const worst = right < heap.length && (yield* compare(heap[right], heap[left])) > 0 ? right : left;
    if ((yield* compare(heap[index], heap[worst])) >= 0)
      break;
    yield charge3();
    [heap[index], heap[worst]] = [heap[worst], heap[index]];
    index = worst;
  }
}
function* prepare(context, options) {
  yield* validatePayload(context.payload, "INVALID_OPTIONS");
  const admission = new Admission(context.limits.maxAdmissionEntries);
  const payload = ownObject(context.payload, "INVALID_OPTIONS", "facets.payload", admission);
  keysOnly(payload, ["fields"], "INVALID_OPTIONS", "facets.payload");
  const requests = ownArray(payload.fields, 8, "INVALID_OPTIONS", "facets.fields", admission);
  if (!requests.length)
    invalid("INVALID_OPTIONS", "facets.fields");
  const selected = /* @__PURE__ */ new Set(), counters = [];
  for (const raw of requests) {
    const request = ownObject(raw, "INVALID_OPTIONS", "facets.field", admission);
    keysOnly(request, ["field", "limit", "missing"], "INVALID_OPTIONS", "facets.field");
    const field = stringValue(request.field, context.limits.maxFieldNameCodeUnits, "INVALID_OPTIONS", "facets.field");
    yield charge3((field.length + 1) * (options.fields.length + 1));
    const declared = context.schema.metadata[field];
    if (!declared || declared.type !== "string")
      invalid("INVALID_OPTIONS", "facets.field");
    if (!options.fields.includes(field))
      invalid("MISSING_CAPABILITY", "facets.field");
    if (selected.has(field))
      invalid("INVALID_OPTIONS", "facets.fields");
    selected.add(field);
    const limit = has(request, "limit") ? request.limit : Math.min(20, options.maxBucketsPerField);
    if (typeof limit !== "number" || !Number.isSafeInteger(limit) || limit < 0)
      invalid("INVALID_OPTIONS", "facets.limit");
    bound(limit, options.maxBucketsPerField, "facets.limit");
    const missing = has(request, "missing") ? request.missing : false;
    if (typeof missing !== "boolean")
      invalid("INVALID_OPTIONS", "facets.missing");
    counters.push({
      field,
      limit,
      missing,
      cap: Math.min(options.maxDistinctValuesPerField, context.limits.maxDocuments * (declared.multi ? context.limits.maxMetadataValuesPerField : 1)),
      values: /* @__PURE__ */ new Map()
    });
  }
  return Object.freeze({
    *add(metadata2) {
      for (const counter of counters) {
        yield charge3(counter.field.length + 1);
        if (!has(metadata2, counter.field)) {
          if (counter.missing) {
            if (!counter.missingBucket) {
              bound(counter.values.size + 1, counter.cap, "facets.distinctValues");
              counter.missingBucket = { missing: true, count: 0 };
            }
            counter.missingBucket.count++;
            yield charge3();
          }
          continue;
        }
        const input = metadata2[counter.field], values = Array.isArray(input) ? input : [input];
        const seen = /* @__PURE__ */ new Set();
        for (const raw of values) {
          if (raw !== null && typeof raw !== "string")
            invalid("INCOMPATIBLE_CAPABILITY", "facets.metadata");
          if (raw === null && !context.schema.metadata[counter.field].nullable)
            invalid("INCOMPATIBLE_CAPABILITY", "facets.metadata");
          const value = raw;
          yield charge3((value?.length ?? 0) + 1);
          if (seen.has(value))
            continue;
          seen.add(value);
          yield charge3((value?.length ?? 0) + 1);
          let bucket = counter.values.get(value);
          if (!bucket) {
            bound(counter.values.size + (counter.missingBucket ? 1 : 0) + 1, counter.cap, "facets.distinctValues");
            bucket = { missing: false, value, count: 0 };
            counter.values.set(value, bucket);
          }
          bucket.count++;
          yield charge3();
        }
      }
    },
    *finish() {
      const fields2 = [];
      for (const counter of counters) {
        const heap = [];
        for (const bucket of counter.values.values())
          yield* select(heap, bucket, counter.limit);
        if (counter.missingBucket)
          yield* select(heap, counter.missingBucket, counter.limit);
        for (let index = 1; index < heap.length; index++) {
          const value = heap[index];
          let target = index;
          while (target && (yield* compare(value, heap[target - 1])) < 0) {
            heap[target] = heap[target - 1];
            target--;
            yield charge3();
          }
          heap[target] = value;
          yield charge3();
        }
        const buckets = [];
        for (const bucket of heap) {
          yield charge3((bucket.value?.length ?? 0) + 4);
          buckets.push(Object.freeze(bucket.missing ? { kind: "missing", count: bucket.count } : { kind: "value", value: bucket.value, count: bucket.count }));
        }
        const total = counter.values.size + (counter.missingBucket ? 1 : 0);
        fields2.push(Object.freeze({ field: counter.field, buckets: Object.freeze(buckets), distinctValueTotal: total, omittedBucketCount: total - buckets.length }));
        yield charge3(4);
      }
      return yield* captureMetadataOutput(Object.freeze({ fields: Object.freeze(fields2) }), context.limits);
    }
  });
}
function createFacets(options) {
  const captured = captureFacetOptions(options);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["aggregation"]),
      provides: Object.freeze([Object.freeze({ id: "facets", contractVersion: 1 })]),
      requires: Object.freeze([]),
      dataRequirements: Object.freeze({ fields: captured.fields, source: false, positions: false, offsets: false, metadata: true }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("facets", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: 8192 }),
      costs: Object.freeze({
        importedCode: "Typed metadata aggregation, per-document distinct counting and bounded output heap.",
        retainedRepresentation: "No side index or corpus metadata copy; counters exist only during requested aggregation.",
        transientWork: "Complete qualifying documents counted under distinct/work ceilings; at most eight fields and 100 returned buckets per field; comparisons and output projection are resumable.",
        externalResources: "none"
      })
    }),
    aggregation: Object.freeze({
      fieldType: "string",
      capture: (input, context) => captureMetadataPayload(input, context, "INVALID_OPTIONS"),
      prepare: (context) => prepare(context, captured)
    })
  });
}

// node_modules/@vmitsaras/raveldex/dist/addons/inspector/options.js
function fields(input, admission, maximum, path) {
  const seen = /* @__PURE__ */ new Set();
  return Object.freeze(ownArray(input, maximum, "INVALID_OPTIONS", path, admission).map((value) => {
    const name2 = stringValue(value, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", path);
    if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(name2) || name2 === "constructor" || name2 === "prototype" || seen.has(name2))
      invalid("INVALID_OPTIONS", path);
    seen.add(name2);
    return name2;
  }));
}
function integer3(input, maximum, path) {
  if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 1)
    invalid("INVALID_OPTIONS", path);
  bound(input, maximum, path);
  return input;
}
function captureInspectorOptions(input) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const options = ownObject(input, "INVALID_OPTIONS", "inspector.options", admission);
  keysOnly(options, ["id", "sourceFields", "maxFacts", "maxWorkUnits", "maxOutputEntries"], "INVALID_OPTIONS", "inspector.options");
  const id = has(options, "id") ? stringValue(options.id, 64, "INVALID_OPTIONS", "inspector.id") : "inspector";
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "inspector.id");
  return Object.freeze({
    id,
    sourceFields: has(options, "sourceFields") ? fields(options.sourceFields, admission, DEFAULT_LIMITS.maxTextFields, "inspector.sourceFields") : Object.freeze([]),
    maxFacts: integer3(has(options, "maxFacts") ? options.maxFacts : 4096, 4096, "inspector.maxFacts"),
    maxWorkUnits: integer3(has(options, "maxWorkUnits") ? options.maxWorkUnits : DEFAULT_LIMITS.maxSearchWorkUnits, DEFAULT_LIMITS.maxSearchWorkUnits, "inspector.maxWorkUnits"),
    maxOutputEntries: integer3(has(options, "maxOutputEntries") ? options.maxOutputEntries : DEFAULT_LIMITS.maxAdmissionEntries, DEFAULT_LIMITS.maxAdmissionEntries, "inspector.maxOutputEntries")
  });
}
function parseInspectorRequest(input, limits, options) {
  const admission = new Admission(limits.maxAdmissionEntries);
  const data2 = ownObject(input, "INVALID_OPTIONS", "inspector.request", admission);
  keysOnly(data2, ["ids", "maxFacts", "expectedRevision", "sourceFields"], "INVALID_OPTIONS", "inspector.request");
  const seen = /* @__PURE__ */ new Set();
  const ids = Object.freeze(ownArray(data2.ids, Math.min(128, limits.maxDocuments), "INVALID_OPTIONS", "inspector.ids", admission).map((value) => {
    const id = stringValue(value, limits.maxIdCodeUnits, "INVALID_OPTIONS", "inspector.ids");
    if (!id.length || seen.has(id))
      invalid("INVALID_OPTIONS", "inspector.ids");
    seen.add(id);
    return id;
  }));
  const maxFacts = integer3(has(data2, "maxFacts") ? data2.maxFacts : options.maxFacts, options.maxFacts, "inspector.maxFacts");
  const revision = data2.expectedRevision;
  if (has(data2, "expectedRevision") && (typeof revision !== "number" || !Number.isSafeInteger(revision) || revision < 0))
    invalid("INVALID_OPTIONS", "inspector.expectedRevision");
  const sourceFields = has(data2, "sourceFields") ? fields(data2.sourceFields, admission, limits.maxTextFields, "inspector.sourceFields") : Object.freeze([]);
  for (const field of sourceFields)
    if (!options.sourceFields.includes(field))
      invalid("MISSING_CAPABILITY", "inspector.sourceFields");
  return Object.freeze({ ids, maxFacts, ...typeof revision === "number" ? { expectedRevision: revision } : {}, sourceFields });
}
function captureInspectorRequest(input, context, options) {
  const captured = captureMetadataPayload(input, context, "INVALID_OPTIONS");
  return Object.freeze({ value: parseInspectorRequest(captured.value, context.limits, options), codeUnits: captured.codeUnits });
}

// node_modules/@vmitsaras/raveldex/dist/addons/inspector/output.js
var MAX_INSPECTOR_TEXT_CODE_UNITS = 262144;
function* ownInspectorOutput(input, maximumEntries, code = "INCOMPATIBLE_CAPABILITY") {
  const admission = new Admission(maximumEntries), ancestors = /* @__PURE__ */ new Set();
  let codeUnits = 0;
  function* text2(value2) {
    codeUnits += value2.length;
    bound(codeUnits, MAX_INSPECTOR_TEXT_CODE_UNITS, "inspector.output.text");
    yield* scanUnicode(value2, code, "inspector.output.text");
    return value2;
  }
  function* copy(value2, depth) {
    bound(depth, 16, "inspector.output.depth");
    yield { workUnits: 1 };
    if (typeof value2 === "string")
      return yield* text2(value2);
    if (value2 === null || typeof value2 === "boolean" || typeof value2 === "number" && Number.isFinite(value2))
      return value2;
    if (typeof value2 !== "object" || value2 === null || ancestors.has(value2))
      invalid(code, "inspector.output");
    ancestors.add(value2);
    let owned;
    if (Array.isArray(value2)) {
      const data2 = ownArray(value2, maximumEntries, code, "inspector.output", admission), result = [];
      yield { workUnits: data2.length + 1 };
      for (const item of data2)
        result.push(yield* copy(item, depth + 1));
      owned = Object.freeze(result);
    } else {
      const data2 = ownObject(value2, code, "inspector.output", admission);
      yield { workUnits: Object.keys(data2).length };
      for (const key of Object.keys(data2)) {
        yield* text2(key);
        data2[key] = yield* copy(data2[key], depth + 1);
      }
      owned = Object.freeze(data2);
    }
    ancestors.delete(value2);
    return owned;
  }
  const value = yield* copy(input, 1);
  return Object.freeze({ value, entries: admission.count });
}

// node_modules/@vmitsaras/raveldex/dist/addons/inspector/inspector.js
var charge4 = (workUnits = 1) => ({ workUnits });
function* sourceFor(id, exists, request, roots, limits) {
  if (!request.sourceFields.length)
    return { status: "not-requested" };
  if (!exists)
    return { status: "unavailable", reason: "record-absent" };
  const fields2 = /* @__PURE__ */ Object.create(null);
  for (const field of request.sourceFields) {
    yield charge4(id.length + field.length + 1);
    const record = directoryGet(roots.get(field).records, id);
    if (!record)
      invalid("MISSING_CAPABILITY", "inspector.source.record");
    if (!Object.isFrozen(record) || !record.text || !Object.isFrozen(record.text))
      invalid("INCOMPATIBLE_CAPABILITY", "inspector.source.record");
    if (!has(record.text, field))
      fields2[field] = { status: "absent" };
    else {
      const values = record.text[field];
      if (!Array.isArray(values) || !Object.isFrozen(values) || values.length > limits.maxTextValuesPerField)
        invalid("INCOMPATIBLE_CAPABILITY", "inspector.source.values");
      for (const value of values) {
        yield charge4();
        if (typeof value !== "string" || value.length > limits.maxTextCodeUnitsPerValue)
          invalid("INCOMPATIBLE_CAPABILITY", "inspector.source.values");
      }
      fields2[field] = { status: "available", values };
    }
  }
  return { status: "available", fields: fields2 };
}
function* project(context, finished, request, roots, options) {
  const { trace, result } = finished;
  if (trace.revision !== context.revision || result.revision !== context.revision || trace.model !== result.model)
    invalid("REVISION_MISMATCH", "inspector.revision");
  const facts = /* @__PURE__ */ new Map(), page = /* @__PURE__ */ new Map();
  for (const fact of trace.facts) {
    yield charge4(1);
    if (fact.kind === "document") {
      if (facts.has(fact.id))
        invalid("INCOMPATIBLE_CAPABILITY", "inspector.trace");
      facts.set(fact.id, fact);
    }
  }
  for (let index = 0; index < result.hits.length; index++) {
    const hit = result.hits[index];
    yield charge4(hit.id.length + 1);
    page.set(hit.id, index);
  }
  const documents = [];
  for (const id of request.ids) {
    yield charge4(id.length + 1);
    const fact = facts.get(id);
    if (!fact)
      invalid("INCOMPATIBLE_CAPABILITY", "inspector.trace");
    const index = page.get(id), eligibility = !fact.exists ? "absent" : fact.matched ? "matched" : "excluded";
    documents.push({
      id,
      exists: fact.exists,
      eligibility,
      score: fact.exists ? fact.score : null,
      groups: fact.groups,
      page: { placement: !fact.exists ? "absent" : !fact.matched ? "excluded" : index === void 0 ? "outside-page" : "returned", index: index ?? null },
      absoluteRank: { status: "unavailable", reason: "not-collected" },
      source: yield* sourceFor(id, fact.exists, request, roots, context.limits)
    });
  }
  const data2 = {
    kind: "raveldex-inspector-v1",
    revision: context.revision,
    model: "raveldex-bm25-v1",
    configuration: {
      schema: context.schema,
      limits: context.limits,
      analyzer: context.analyzer,
      capabilities: finished.capabilities.map((manifest) => ({
        id: manifest.id,
        version: manifest.version,
        contractVersion: manifest.contractVersion,
        roles: manifest.roles,
        provides: manifest.provides,
        requires: manifest.requires
      }))
    },
    query: { traceScope: "selected-documents", alternativeScope: "selected-best-per-group-and-field", fullAlternatives: { status: "unavailable", reason: "not-collected" } },
    trace,
    documents,
    result: { total: result.total, returned: result.hits.length },
    resources: {
      outcome: "complete",
      unit: "work-v1",
      searchWorkUnits: finished.searchWorkUnits,
      maxSearchWorkUnits: finished.maxSearchWorkUnits,
      scope: "before-evidence-projection",
      counts: finished.counts,
      heapBytes: { status: "unavailable", reason: "not-measured" }
    },
    numericalTolerance: { absolute: 1e-12, relative: 1e-12 }
  };
  return yield* ownInspectorOutput(data2, Math.min(options.maxOutputEntries, context.limits.maxAdmissionEntries));
}
function* prepare2(context, options) {
  yield* validatePayload(context.payload, "INVALID_OPTIONS");
  const request = parseInspectorRequest(context.payload, context.limits, options), roots = /* @__PURE__ */ new Map();
  for (const field of request.sourceFields) {
    yield charge4(field.length + 1);
    if (!has(context.schema.text, field))
      invalid("INVALID_OPTIONS", "inspector.sourceFields");
    roots.set(field, requireSourceRoot(context.state(`source:${field}`), field, context.revision, context.analyzer));
  }
  return Object.freeze({ finish: (finished) => project(context, finished, request, roots, options) });
}
function createInspector(options = {}) {
  const captured = captureInspectorOptions(options);
  return Object.freeze({
    manifest: Object.freeze({
      id: captured.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["evidence"]),
      provides: Object.freeze([Object.freeze({ id: "inspector", contractVersion: 1 })]),
      requires: Object.freeze(captured.sourceFields.map((field) => Object.freeze({ id: `source:${field}`, contractVersion: 1 }))),
      dataRequirements: Object.freeze({ fields: captured.sourceFields, source: captured.sourceFields.length > 0, positions: false, offsets: false, metadata: false }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity("inspector", captured) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: captured.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: captured.maxOutputEntries }),
      costs: Object.freeze({
        importedCode: "Factual native Inspector projection, explicit source lookup and bounded JSON diagnostics; no DOM or phrase verifier.",
        retainedRepresentation: "No side root, record metadata copy, full corpus trace or original source retention.",
        transientWork: "Only explicitly selected IDs, at most 4096 header-inclusive facts, bounded output entries and 262144 aggregate original UTF-16 key/string units.",
        externalResources: "none"
      })
    }),
    evidence: Object.freeze({
      capture: (input, context) => captureInspectorRequest(input, context, captured),
      select: (payload) => {
        const request = payload;
        return Object.freeze({ ids: request.ids, maxFacts: request.maxFacts, ...request.expectedRevision === void 0 ? {} : { expectedRevision: request.expectedRevision } });
      },
      prepare: (context) => prepare2(context, captured)
    })
  });
}

// node_modules/@vmitsaras/raveldex/dist/addons/evidence/occurrences.js
var charge5 = (workUnits = 1) => ({ workUnits });
function* equal(a, b) {
  for (let index = 0; index < Math.min(a.length, b.length); index++) {
    yield charge5();
    if (a.charCodeAt(index) !== b.charCodeAt(index))
      return false;
  }
  yield charge5();
  return a.length === b.length;
}
function* contributingLeaves(node2, facts, path = "query") {
  const output = [];
  function* walk(node3, path2) {
    yield charge5(path2.length + 1);
    const fact = facts.get(path2);
    if (!fact || fact.node !== node3.kind)
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.trace.node");
    if (!fact.matched || node3.kind === "not")
      return;
    if (node3.kind === "group")
      output.push({ kind: "group", group: node3.group });
    else if (node3.kind === "extension") {
      if (fact.capability !== node3.capability)
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.trace.node");
      output.push({ kind: "phrase", fields: node3.fields, terms: node3.terms });
    } else if (node3.kind === "and" || node3.kind === "or")
      for (let index = 0; index < node3.children.length; index++)
        yield* walk(node3.children[index], `${path2}.children[${index}]`);
  }
  yield* walk(node2, path);
  return output;
}
function* prefix(term, query) {
  yield charge5();
  if (term.length < query.length)
    return false;
  for (let index = 0; index < query.length; index++) {
    yield charge5();
    if (term.charCodeAt(index) !== query.charCodeAt(index))
      return false;
  }
  return true;
}
function* matchingGroup(tokens, group, mark) {
  for (const token of tokens) {
    yield charge5();
    for (const variant of group.variants) {
      yield charge5();
      const matches = variant.match === "prefix" ? yield* prefix(token.term, variant.term) : yield* equal(token.term, variant.term);
      if (matches) {
        mark(token);
        break;
      }
    }
  }
}
function* phraseTable(terms) {
  const failure = [];
  if (terms.length) {
    yield charge5();
    failure.push(0);
  }
  for (let index = 1; index < terms.length; index++) {
    let matched = failure[index - 1];
    for (; ; ) {
      if (yield* equal(terms[index], terms[matched])) {
        matched++;
        break;
      }
      if (!matched)
        break;
      yield charge5();
      matched = failure[matched - 1];
    }
    yield charge5();
    failure.push(matched);
  }
  return Object.freeze(failure);
}
function* matchingPhrase(tokens, terms, failure, mark) {
  if (!terms.length)
    return;
  let matched = 0;
  let originals = tokens;
  if (tokens[0]?.kind === "original") {
    const selected = [];
    for (const token of tokens) {
      yield charge5();
      if (token.kind === "original")
        selected.push(token);
    }
    originals = selected;
  }
  for (const token of originals) {
    yield charge5();
    for (; ; ) {
      if (yield* equal(token.term, terms[matched])) {
        matched++;
        break;
      }
      if (!matched)
        break;
      yield charge5();
      matched = failure[matched - 1];
    }
    if (matched === terms.length) {
      for (let offset = terms.length - 1; offset >= 0; offset--) {
        yield charge5();
        mark(originals[token.position - offset]);
      }
      matched = failure[matched - 1];
    }
  }
}

// node_modules/@vmitsaras/raveldex/dist/addons/evidence/options.js
function name(input, path) {
  const value = stringValue(input, DEFAULT_LIMITS.maxFieldNameCodeUnits, "INVALID_OPTIONS", path);
  if (!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(value) || value === "constructor" || value === "prototype")
    invalid("INVALID_OPTIONS", path);
  return value;
}
function integer4(input, maximum, path) {
  if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 1)
    invalid("INVALID_OPTIONS", path);
  bound(input, maximum, path);
  return input;
}
function captureMatchOptions(input, defaultId) {
  const admission = new Admission(DEFAULT_LIMITS.maxAdmissionEntries);
  const raw = ownObject(input, "INVALID_OPTIONS", "evidence.options", admission);
  keysOnly(raw, ["fields", "id", "maxFacts", "maxRanges", "maxWorkUnits", "maxOutputEntries"], "INVALID_OPTIONS", "evidence.options");
  const id = has(raw, "id") ? stringValue(raw.id, 64, "INVALID_OPTIONS", "evidence.id") : defaultId;
  if (!/^[A-Za-z][A-Za-z0-9_.:-]*$/.test(id))
    invalid("INVALID_OPTIONS", "evidence.id");
  const fields2 = ownObject(raw.fields, "INVALID_OPTIONS", "evidence.fields", admission), names = Object.keys(fields2);
  if (!names.length)
    invalid("INVALID_OPTIONS", "evidence.fields");
  bound(names.length, DEFAULT_LIMITS.maxTextFields, "evidence.fields");
  const strategies = /* @__PURE__ */ Object.create(null);
  for (const field of names) {
    name(field, "evidence.fields");
    const strategy = fields2[field];
    if (strategy !== "source" && strategy !== "offsets")
      invalid("INVALID_OPTIONS", "evidence.strategy");
    strategies[field] = strategy;
  }
  return Object.freeze({
    id,
    fields: Object.freeze(names.sort()),
    strategies: Object.freeze(strategies),
    maxFacts: integer4(has(raw, "maxFacts") ? raw.maxFacts : 4096, 4096, "evidence.maxFacts"),
    maxRanges: integer4(has(raw, "maxRanges") ? raw.maxRanges : 4096, 4096, "evidence.maxRanges"),
    maxWorkUnits: integer4(has(raw, "maxWorkUnits") ? raw.maxWorkUnits : DEFAULT_LIMITS.maxSearchWorkUnits, DEFAULT_LIMITS.maxSearchWorkUnits, "evidence.maxWorkUnits"),
    maxOutputEntries: integer4(has(raw, "maxOutputEntries") ? raw.maxOutputEntries : DEFAULT_LIMITS.maxAdmissionEntries, DEFAULT_LIMITS.maxAdmissionEntries, "evidence.maxOutputEntries")
  });
}
function parseMatchRequest(input, limits, options) {
  const admission = new Admission(limits.maxAdmissionEntries);
  const raw = ownObject(input, "INVALID_OPTIONS", "evidence.request", admission);
  keysOnly(raw, ["ids", "fields", "expectedRevision", "maxFacts", "maxRanges"], "INVALID_OPTIONS", "evidence.request");
  const idsSeen = /* @__PURE__ */ new Set();
  const ids = Object.freeze(ownArray(raw.ids, Math.min(128, limits.maxDocuments), "INVALID_OPTIONS", "evidence.ids", admission).map((input2) => {
    const value = stringValue(input2, limits.maxIdCodeUnits, "INVALID_OPTIONS", "evidence.ids");
    if (!value.length || idsSeen.has(value))
      invalid("INVALID_OPTIONS", "evidence.ids");
    idsSeen.add(value);
    return value;
  }));
  const seen = /* @__PURE__ */ new Set();
  const fields2 = has(raw, "fields") ? Object.freeze(ownArray(raw.fields, limits.maxTextFields, "INVALID_OPTIONS", "evidence.fields", admission).map((input2) => {
    const field = name(input2, "evidence.fields");
    if (seen.has(field))
      invalid("INVALID_OPTIONS", "evidence.fields");
    if (!has(options.strategies, field))
      invalid("MISSING_CAPABILITY", "evidence.fields");
    seen.add(field);
    return field;
  }).sort()) : options.fields;
  const revision = raw.expectedRevision;
  if (has(raw, "expectedRevision") && (typeof revision !== "number" || !Number.isSafeInteger(revision) || revision < 0))
    invalid("INVALID_OPTIONS", "evidence.expectedRevision");
  return Object.freeze({
    ids,
    fields: fields2,
    ...typeof revision === "number" ? { expectedRevision: revision } : {},
    maxFacts: integer4(has(raw, "maxFacts") ? raw.maxFacts : options.maxFacts, options.maxFacts, "evidence.maxFacts"),
    maxRanges: integer4(has(raw, "maxRanges") ? raw.maxRanges : options.maxRanges, options.maxRanges, "evidence.maxRanges")
  });
}
function captureMatchRequest(input, context, options) {
  const captured = captureMetadataPayload(input, context, "INVALID_OPTIONS");
  return Object.freeze({ value: parseMatchRequest(captured.value, context.limits, options), codeUnits: captured.codeUnits });
}

// node_modules/@vmitsaras/raveldex/dist/addons/evidence/providers.js
var charge6 = (workUnits = 1) => ({ workUnits });
var count4 = (value, maximum) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && value <= maximum;
function object3(input, maximum, path, nullPrototype = false) {
  if (typeof input !== "object" || input === null || !Object.isFrozen(input) || nullPrototype && Object.getPrototypeOf(input) !== null)
    invalid("INCOMPATIBLE_CAPABILITY", path);
  if (Reflect.ownKeys(input).length > maximum)
    invalid("INCOMPATIBLE_CAPABILITY", path);
  return ownObject(input, "INCOMPATIBLE_CAPABILITY", path, new Admission(maximum));
}
function* array(input, maximum, path) {
  if (!Array.isArray(input) || !Object.isFrozen(input) || !count4(input.length, maximum))
    invalid("INCOMPATIBLE_CAPABILITY", path);
  const prototype = Object.getPrototypeOf(input);
  if (prototype !== Array.prototype && prototype !== null)
    invalid("INCOMPATIBLE_CAPABILITY", path);
  const keys = Reflect.ownKeys(input);
  yield charge6(keys.length + 1);
  if (keys.length !== input.length + 1)
    invalid("INCOMPATIBLE_CAPABILITY", path);
  for (const key of keys) {
    yield charge6();
    if (key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= input.length))
      invalid("INCOMPATIBLE_CAPABILITY", path);
  }
  const values = [];
  for (let index = 0; index < input.length; index++) {
    yield charge6();
    const descriptor = Object.getOwnPropertyDescriptor(input, String(index));
    if (!descriptor || !("value" in descriptor))
      invalid("INCOMPATIBLE_CAPABILITY", path);
    values.push(descriptor.value);
  }
  return values;
}
function* sourceTokens(root, id, field, limits, analyze = analyzeValue) {
  yield charge6(id.length + field.length + 1);
  const record = directoryGet(root.records, id);
  if (!record)
    invalid("MISSING_CAPABILITY", "evidence.source.record");
  const data2 = object3(record, 3, "evidence.source.record");
  keysOnly(data2, ["text", "retainedEntries", "textCodeUnits"], "INCOMPATIBLE_CAPABILITY", "evidence.source.record");
  if (!count4(data2.retainedEntries, root.maxRetainedEntries) || !count4(data2.textCodeUnits, limits.maxTextCodeUnitsPerRecord))
    invalid("INCOMPATIBLE_CAPABILITY", "evidence.source.record");
  const text2 = object3(data2.text, limits.maxTextFields, "evidence.source.text");
  for (const name2 of Object.keys(text2)) {
    yield charge6(name2.length + 1);
    if (!root.fields.includes(name2))
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.source.fields");
  }
  if (!has(text2, field))
    return Object.freeze([]);
  const values = yield* array(text2[field], limits.maxTextValuesPerField, "evidence.source.values");
  const output = [];
  let tokenCount = 0;
  for (let valueIndex = 0; valueIndex < values.length; valueIndex++) {
    const value = values[valueIndex];
    yield charge6();
    if (typeof value !== "string" || value.length > limits.maxTextCodeUnitsPerValue)
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.source.value");
    const tokens = [];
    for (const step of analyze(value, valueIndex, limits, "INCOMPATIBLE_CAPABILITY")) {
      yield charge6(step.workUnits);
      if (step.token) {
        if (++tokenCount > limits.maxTokensPerRecord)
          invalid("INCOMPATIBLE_CAPABILITY", "evidence.source.tokens");
        tokens.push(step.token);
      }
    }
    yield charge6(tokens.length + 1);
    output.push(Object.freeze(tokens));
  }
  return Object.freeze(output);
}
function* offsetTokens(root, id, field, limits) {
  yield charge6(id.length + field.length + 1);
  const record = directoryGet(root.records, id);
  if (!record)
    invalid("MISSING_CAPABILITY", "evidence.offsets.record");
  const data2 = object3(record, 6, "evidence.offsets.record");
  keysOnly(data2, ["positions", "retainedEntries", "occurrenceCount", "offsetCount", "termEntries", "termCodeUnits"], "INCOMPATIBLE_CAPABILITY", "evidence.offsets.record");
  if (!count4(data2.retainedEntries, root.maxRetainedEntries) || !count4(data2.occurrenceCount, limits.maxTokensPerRecord) || !count4(data2.offsetCount, data2.occurrenceCount) || !count4(data2.termEntries, data2.occurrenceCount) || !count4(data2.termCodeUnits, limits.maxTokensPerRecord * limits.maxTermCodeUnits))
    invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.record");
  const fields2 = object3(data2.positions, limits.maxTextFields, "evidence.offsets.fields", true);
  for (const name2 of Object.keys(fields2)) {
    yield charge6(name2.length + 1);
    if (!root.fields.includes(name2))
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.fields");
  }
  if (!has(fields2, field))
    return Object.freeze([]);
  const values = yield* array(fields2[field], limits.maxTextValuesPerField, "evidence.offsets.values");
  const output = [];
  let fieldCount = 0;
  if (root.kind === "raveldex-positions-v2") {
    for (let valueIndex = 0; valueIndex < values.length; valueIndex++) {
      const tokens = yield* taggedPositionTokens(values[valueIndex], true, limits);
      fieldCount += tokens.length;
      if (fieldCount > data2.occurrenceCount || fieldCount > data2.offsetCount)
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.counts");
      const originals = /* @__PURE__ */ new Map(), result = [];
      for (const token of tokens) {
        yield charge6(token.term.length + 1);
        const original = originals.get(token.position);
        if (token.kind === "component" && !original)
          invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.original");
        const value = Object.freeze({
          term: token.term,
          valueIndex,
          position: token.position,
          start: token.start,
          end: token.end,
          kind: token.kind,
          ...token.kind === "component" ? { original: Object.freeze({ term: original.term, start: original.start, end: original.end }) } : {}
        });
        if (token.kind === "original")
          originals.set(token.position, value);
        result.push(value);
      }
      output.push(Object.freeze(result));
    }
    return Object.freeze(output);
  }
  for (let valueIndex = 0; valueIndex < values.length; valueIndex++) {
    yield charge6();
    const value = object3(values[valueIndex], 2, "evidence.offsets.value");
    keysOnly(value, ["tokenCount", "terms"], "INCOMPATIBLE_CAPABILITY", "evidence.offsets.value");
    if (!count4(value.tokenCount, limits.maxTokensPerRecord))
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.tokens");
    const tokenCount = value.tokenCount;
    fieldCount += tokenCount;
    if (fieldCount > data2.occurrenceCount || fieldCount > data2.offsetCount)
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.counts");
    if (typeof value.terms !== "object" || value.terms === null || !Object.isFrozen(value.terms) || Object.getPrototypeOf(value.terms) !== null)
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.terms");
    const keys = Reflect.ownKeys(value.terms);
    yield charge6(keys.length + 1);
    if (keys.length > tokenCount)
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.terms");
    const tokens = [];
    let occurrenceCount = 0;
    for (const term of keys) {
      yield charge6();
      if (typeof term !== "string" || !term.length || term.length > limits.maxTermCodeUnits)
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.term");
      yield* scanUnicode(term, "INCOMPATIBLE_CAPABILITY", "evidence.offsets.term");
      const descriptor = Object.getOwnPropertyDescriptor(value.terms, term);
      if (!descriptor || !("value" in descriptor))
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.terms");
      const occurrences = yield* array(descriptor.value, tokenCount, "evidence.offsets.occurrences");
      if (!occurrences.length)
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.occurrences");
      let last = -1;
      for (const input of occurrences) {
        yield charge6(5);
        const occurrence = object3(input, 4, "evidence.offsets.occurrence");
        keysOnly(occurrence, ["position", "positionLength", "start", "end"], "INCOMPATIBLE_CAPABILITY", "evidence.offsets.occurrence");
        const { position, start, end } = occurrence;
        if (!count4(position, tokenCount - 1) || position <= last || occurrence.positionLength !== 1 || !count4(start, limits.maxTextCodeUnitsPerValue) || !count4(end, limits.maxTextCodeUnitsPerValue) || end <= start || end - start > limits.maxRawTokenCodeUnits || has(tokens, position))
          invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.occurrence");
        tokens[position] = Object.freeze({ term, valueIndex, position, start, end });
        last = position;
        occurrenceCount++;
        if (occurrenceCount > tokenCount)
          invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.counts");
      }
    }
    if (occurrenceCount !== tokenCount)
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.counts");
    let previousEnd = 0;
    for (let position = 0; position < tokenCount; position++) {
      yield charge6();
      const token = tokens[position];
      if (!token || token.start < previousEnd)
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.offsets.order");
      previousEnd = token.end;
    }
    yield charge6(tokens.length + 1);
    output.push(Object.freeze(tokens));
  }
  return Object.freeze(output);
}

// node_modules/@vmitsaras/raveldex/dist/addons/evidence/builder.js
var charge7 = (workUnits = 1) => ({ workUnits });
function* rangesFor(id, leaves, fields2, providers, context, maximum, counter) {
  const ranges = [];
  const tables = /* @__PURE__ */ new Map();
  let tokenCount = 0;
  for (const field of fields2) {
    yield charge7(field.length + 1);
    const active = [];
    for (const leaf of leaves) {
      const names = leaf.kind === "group" ? leaf.group.fields : leaf.fields;
      yield charge7(names.length + 1);
      if (names.includes(field))
        active.push(leaf);
    }
    if (!active.length)
      continue;
    const provider = providers.get(field);
    const values = provider.kind === "source" ? yield* sourceTokens(provider.root, id, field, context.limits, requireAnalysis(context)) : yield* offsetTokens(provider.root, id, field, context.limits);
    for (let valueIndex = 0; valueIndex < values.length; valueIndex++) {
      const tokens = values[valueIndex];
      yield charge7();
      tokenCount += tokens.length;
      if (tokenCount > context.limits.maxTokensPerRecord)
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.record.tokens");
      const selected = /* @__PURE__ */ new Set();
      const mark = (token) => {
        if (selected.has(token))
          return;
        selected.add(token);
        bound(++counter.value, maximum, "evidence.ranges");
      };
      for (const leaf of active) {
        yield charge7();
        if (leaf.kind === "group")
          yield* matchingGroup(tokens, leaf.group, mark);
        else {
          let table = tables.get(leaf);
          if (!table) {
            table = yield* phraseTable(leaf.terms);
            tables.set(leaf, table);
          }
          yield* matchingPhrase(tokens, leaf.terms, table, mark);
        }
      }
      for (const token of tokens) {
        yield charge7();
        if (selected.has(token))
          ranges.push(Object.freeze({
            field,
            valueIndex,
            position: token.position,
            start: token.start,
            end: token.end,
            term: token.term,
            ...token.kind ? { kind: token.kind } : {},
            ...token.original ? { original: token.original } : {}
          }));
      }
    }
  }
  if (context.analyzer.id === "code-identifiers-v1") {
    const sorted = [];
    for (const range of ranges) {
      let index = sorted.length;
      while (index > 0) {
        yield charge7(fields2.length * 2 + 1);
        const prior = sorted[index - 1];
        const order = fields2.indexOf(prior.field) - fields2.indexOf(range.field) || prior.valueIndex - range.valueIndex || prior.start - range.start || prior.end - range.end || prior.position - range.position;
        if (order <= 0)
          break;
        index--;
      }
      sorted.splice(index, 0, range);
    }
    return Object.freeze(sorted);
  }
  return Object.freeze(ranges);
}
function* project2(context, finished, request, options, providers, presentation2, maxSerializedBytes) {
  if (finished.trace.revision !== context.revision || finished.result.revision !== context.revision || finished.trace.model !== finished.result.model || finished.trace.analyzer.id !== context.analyzer.id || finished.trace.analyzer.environmentProfile !== context.analyzer.environmentProfile)
    invalid("REVISION_MISMATCH", "evidence.revision");
  function* supported(node2) {
    yield charge7();
    if (node2.kind === "extension" && node2.termGroups)
      invalid("MISSING_CAPABILITY", "evidence.proximity");
    if (node2.kind === "and" || node2.kind === "or")
      for (const child of node2.children)
        yield* supported(child);
    else if (node2.kind === "not")
      yield* supported(node2.child);
  }
  yield* supported(finished.query);
  const documents = /* @__PURE__ */ new Map(), nodes = /* @__PURE__ */ new Map();
  for (const fact of finished.trace.facts) {
    yield charge7(fact.id.length + 1);
    if (fact.kind === "document") {
      if (documents.has(fact.id))
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.trace");
      documents.set(fact.id, fact);
    } else if (fact.kind === "node") {
      let paths = nodes.get(fact.id);
      if (!paths) {
        paths = /* @__PURE__ */ new Map();
        nodes.set(fact.id, paths);
      }
      yield charge7(fact.path.length + 1);
      if (paths.has(fact.path))
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.trace");
      paths.set(fact.path, fact);
    }
  }
  const output = [], counter = { value: 0 };
  for (const id of request.ids) {
    yield charge7(id.length + 1);
    const fact = documents.get(id);
    if (!fact)
      invalid("INCOMPATIBLE_CAPABILITY", "evidence.trace");
    const eligibility = !fact.exists ? "absent" : fact.matched ? "matched" : "excluded";
    const leaves = eligibility === "matched" ? yield* contributingLeaves(finished.query, nodes.get(id) ?? /* @__PURE__ */ new Map()) : [];
    const ranges = leaves.length ? yield* rangesFor(id, leaves, request.fields, providers, context, request.maxRanges, counter) : Object.freeze([]);
    let extra = /* @__PURE__ */ Object.create(null);
    if (presentation2) {
      const value = yield* presentation2.project(id, ranges, eligibility);
      extra = ownObject(value, "INCOMPATIBLE_CAPABILITY", "evidence.presentation", new Admission(options.maxOutputEntries));
      yield charge7(Object.keys(extra).length + 1);
      if (has(extra, "id") || has(extra, "eligibility") || has(extra, "ranges"))
        invalid("INCOMPATIBLE_CAPABILITY", "evidence.presentation");
    }
    output.push({ id, eligibility, ranges, ...extra });
  }
  const data2 = {
    kind: "raveldex-match-evidence-v1",
    revision: context.revision,
    fields: request.fields,
    scope: "successful-positive-token-occurrences",
    complete: true,
    documents: output
  };
  const owned = yield* ownInspectorOutput(data2, Math.min(options.maxOutputEntries, context.limits.maxAdmissionEntries));
  if (maxSerializedBytes !== void 0) {
    const serialized = JSON.stringify(owned.value);
    yield charge7(serialized.length + 1);
    let bytes = 0;
    for (const char of serialized) {
      yield charge7();
      const point = char.codePointAt(0);
      bytes += point <= 127 ? 1 : point <= 2047 ? 2 : point <= 65535 ? 3 : 4;
      bound(bytes, maxSerializedBytes, "evidence.output.bytes");
    }
  }
  return owned;
}
function* prepare3(context, options, presentation2) {
  yield* validatePayload(context.payload, "INVALID_OPTIONS");
  requireAnalysis(context);
  const request = presentation2?.parse ? presentation2.parse(context.payload, context.limits, options) : parseMatchRequest(context.payload, context.limits, options), providers = /* @__PURE__ */ new Map();
  for (const field of request.fields) {
    yield charge7(field.length + 1);
    if (!has(context.schema.text, field))
      invalid("INVALID_OPTIONS", "evidence.fields");
    if (options.strategies[field] === "source")
      providers.set(field, { kind: "source", root: requireSourceRoot(context.state(`source:${field}`), field, context.revision, context.analyzer) });
    else {
      const root = requirePositionRoot(context.state(`offsets:${field}`), field, context.revision, context.analyzer);
      yield charge7(root.offsetFields.length + 1);
      if (!root.offsetFields.includes(field))
        invalid("MISSING_CAPABILITY", "evidence.offsets.field");
      providers.set(field, { kind: "offsets", root });
    }
  }
  const prepared = presentation2 ? yield* presentation2.prepare(context, request.fields) : void 0;
  if (prepared && typeof prepared.project !== "function")
    invalid("INCOMPATIBLE_CAPABILITY", "evidence.presentation");
  return Object.freeze({ finish: (finished) => project2(context, finished, request, options, providers, prepared, presentation2?.maxSerializedBytes) });
}
function buildMatchEvidence(input, presentation2) {
  const capability = presentation2?.capability ?? "match-evidence", options = captureMatchOptions(input, capability);
  const sourceFields = options.fields.filter((field) => options.strategies[field] === "source" || presentation2 !== void 0);
  const offsetFields = options.fields.filter((field) => options.strategies[field] === "offsets");
  const requires = [...sourceFields.map((field) => `source:${field}`), ...offsetFields.map((field) => `offsets:${field}`)];
  return Object.freeze({
    manifest: Object.freeze({
      id: options.id,
      version: "0.0.0",
      contractVersion: 1,
      roles: Object.freeze(["evidence"]),
      provides: Object.freeze([Object.freeze({ id: capability, contractVersion: 1 })]),
      requires: Object.freeze(requires.map((id) => Object.freeze({ id, contractVersion: 1 }))),
      dataRequirements: Object.freeze({ fields: options.fields, source: sourceFields.length > 0, positions: offsetFields.length > 0, offsets: offsetFields.length > 0, metadata: false }),
      indexEffect: "none",
      rebuildPolicy: "new-index",
      execution: Object.freeze({ direct: true, worker: true, workerRegistration: workerIdentity(capability, { options, ...presentation2 ? { presentation: presentation2.workerOptions } : {} }) }),
      limits: Object.freeze({ maxPayloadCodeUnits: DEFAULT_LIMITS.maxQueryCodeUnits, maxWorkUnits: options.maxWorkUnits, maxRetainedEntries: 0, maxOutputEntries: options.maxOutputEntries }),
      costs: Object.freeze({
        importedCode: "Actual positive-path original-token evidence and optional explicit presentation; no scorer, diagnostics, DOM or network.",
        retainedRepresentation: "No additional root or source retention; per-field source or original-offset providers are explicit.",
        transientWork: "Selected source analysis or validated stored occurrences, complete bounded range union, actual native facts and owned output; shared operation budget.",
        externalResources: "none"
      })
    }),
    evidence: Object.freeze({
      capture: (value, context) => presentation2?.capture ? presentation2.capture(value, context, options) : captureMatchRequest(value, context, options),
      select: (value) => {
        const request = value;
        return Object.freeze({ ids: request.ids, maxFacts: request.maxFacts, ...request.expectedRevision === void 0 ? {} : { expectedRevision: request.expectedRevision } });
      },
      prepare: (context) => prepare3(context, options, presentation2)
    })
  });
}

// node_modules/@vmitsaras/raveldex/dist/addons/evidence/index.js
function createMatchEvidence(options) {
  return buildMatchEvidence(options);
}

// node_modules/@vmitsaras/raveldex/dist/addons/snippets/snippets.js
var charge8 = (workUnits = 1) => ({ workUnits });
function cap2(input, maximum, path) {
  if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 1)
    invalid("INVALID_OPTIONS", path);
  bound(input, maximum, path);
  return input;
}
function segmenter() {
  try {
    if (typeof Intl !== "object" || Intl === null || typeof Intl.Segmenter !== "function")
      invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
    const result = new Intl.Segmenter(void 0, { granularity: "grapheme" });
    if (typeof result.segment !== "function" || result.resolvedOptions().granularity !== "grapheme")
      invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
    return result;
  } catch {
    invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
  }
}
function* boundaries(source2, host) {
  yield* scanUnicode(source2, "INCOMPATIBLE_CAPABILITY", "snippets.source.text");
  yield charge8(source2.length + 1);
  let iterator, next, close;
  try {
    iterator = host.segment(source2)[Symbol.iterator]();
    next = iterator.next;
    close = iterator.return;
  } catch {
    invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
  }
  if (!iterator || typeof next !== "function" || close !== void 0 && typeof close !== "function")
    invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
  const result = [0];
  let previous = 0;
  try {
    while (true) {
      let done, index, segment;
      try {
        const step = next.call(iterator);
        if (!step || typeof step !== "object")
          invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
        done = step.done;
        if (done !== void 0 && typeof done !== "boolean")
          invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
        if (done)
          break;
        const part = step.value;
        if (!part || typeof part !== "object")
          invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
        index = part.index;
        segment = part.segment;
      } catch {
        invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
      }
      if (!Number.isSafeInteger(index) || index !== previous || typeof segment !== "string" || segment.length === 0 || previous + segment.length > source2.length) {
        invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
      }
      yield charge8(segment.length + 1);
      if (source2.slice(previous, previous + segment.length) !== segment)
        invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
      previous += segment.length;
      result.push(previous);
    }
  } finally {
    try {
      close?.call(iterator);
    } catch {
    }
  }
  if (previous !== source2.length)
    invalid("UNSUPPORTED_ENVIRONMENT", "snippets.segmenter");
  return result;
}
function* lower(points, coordinate) {
  let low = 0, high = points.length;
  while (low < high) {
    yield charge8();
    const middle = low + Math.floor((high - low) / 2);
    if (points[middle] < coordinate)
      low = middle + 1;
    else
      high = middle;
  }
  return low;
}
function* floor(points, coordinate) {
  const index = yield* lower(points, coordinate);
  return points[index] === coordinate ? index : index - 1;
}
function* sourceValue(context, root, id, field, valueIndex, missingCode = "INCOMPATIBLE_CAPABILITY") {
  yield charge8(id.length + field.length + 1);
  const record = directoryGet(root.records, id);
  if (!record)
    invalid("MISSING_CAPABILITY", "snippets.source.record");
  if (!Object.isFrozen(record))
    invalid("INCOMPATIBLE_CAPABILITY", "snippets.source.record");
  const data2 = ownObject(record, "INCOMPATIBLE_CAPABILITY", "snippets.source.record", new Admission(3));
  yield charge8(Object.keys(data2).length + 1);
  keysOnly(data2, ["text", "retainedEntries", "textCodeUnits"], "INCOMPATIBLE_CAPABILITY", "snippets.source.record");
  if (typeof data2.text !== "object" || data2.text === null || !Object.isFrozen(data2.text))
    invalid("INCOMPATIBLE_CAPABILITY", "snippets.source.record");
  const text2 = ownObject(data2.text, "INCOMPATIBLE_CAPABILITY", "snippets.source.text", new Admission(context.limits.maxTextFields));
  yield charge8(Object.keys(text2).length + 1);
  if (!has(text2, field))
    invalid(missingCode === "INVALID_OPTIONS" ? missingCode : "MISSING_CAPABILITY", "snippets.source.field");
  const values = text2[field];
  if (!Array.isArray(values) || !Object.isFrozen(values) || values.length > context.limits.maxTextValuesPerField)
    invalid("INCOMPATIBLE_CAPABILITY", "snippets.source.values");
  for (let index = 0; index < values.length; index++) {
    yield charge8();
    const descriptor = Object.getOwnPropertyDescriptor(values, String(index));
    if (!descriptor || !("value" in descriptor))
      invalid("INCOMPATIBLE_CAPABILITY", "snippets.source.values");
    const value = descriptor.value;
    if (typeof value !== "string" || value.length > context.limits.maxTextCodeUnitsPerValue)
      invalid("INCOMPATIBLE_CAPABILITY", "snippets.source.values");
  }
  if (!Number.isSafeInteger(valueIndex) || valueIndex < 0 || valueIndex >= values.length)
    invalid(missingCode, "snippets.source.valueIndex");
  return Object.getOwnPropertyDescriptor(values, String(valueIndex)).value;
}
function* valuesFor(context, roots, fields2, id, ranges, host, caps, references = []) {
  const groups = /* @__PURE__ */ new Map();
  for (const range of ranges) {
    yield charge8(range.field.length + 1);
    if (!roots.has(range.field) || !Number.isSafeInteger(range.valueIndex) || range.valueIndex < 0 || range.valueIndex >= context.limits.maxTextValuesPerField || !Number.isSafeInteger(range.start) || !Number.isSafeInteger(range.end) || range.start < 0 || range.end <= range.start || !Number.isSafeInteger(range.position) || range.position < 0)
      invalid("INCOMPATIBLE_CAPABILITY", "snippets.range");
    let values = groups.get(range.field);
    if (!values) {
      values = /* @__PURE__ */ new Map();
      groups.set(range.field, values);
    }
    let value = values.get(range.valueIndex);
    if (!value) {
      value = [];
      values.set(range.valueIndex, value);
    }
    value.push(range);
  }
  const referenced = /* @__PURE__ */ new Set();
  for (const ref of references) {
    yield charge8(ref.field.length + 1);
    if (!roots.has(ref.field))
      invalid("INVALID_OPTIONS", "sections.field");
    let values = groups.get(ref.field);
    if (!values) {
      values = /* @__PURE__ */ new Map();
      groups.set(ref.field, values);
    }
    if (!values.has(ref.valueIndex))
      values.set(ref.valueIndex, []);
    referenced.add(ref.field + ":" + ref.valueIndex);
  }
  const result = [];
  for (const field of fields2) {
    yield charge8(field.length + 1);
    const values = groups.get(field);
    if (!values)
      continue;
    yield charge8(values.size + 1);
    const indexes = [...values.keys()].sort((a, b) => a - b);
    for (const valueIndex of indexes) {
      const original = yield* sourceValue(context, roots.get(field), id, field, valueIndex, referenced.has(field + ":" + valueIndex) ? "INVALID_OPTIONS" : "INCOMPATIBLE_CAPABILITY");
      const points = yield* boundaries(original, host);
      const expanded = [];
      let priorStart = -1, priorEnd = -1;
      for (const range of values.get(valueIndex)) {
        yield charge8();
        if (range.end > original.length || range.start < priorStart || range.start === priorStart && range.end < priorEnd)
          invalid("INCOMPATIBLE_CAPABILITY", "snippets.range");
        const raw = original.slice(range.start, range.end);
        yield* scanUnicode(raw, "INCOMPATIBLE_CAPABILITY", "snippets.range.source");
        yield charge8(raw.length + range.term.length + 1);
        if (context.analyzer.id === "basic-v1") {
          if (raw.normalize("NFKC").toLowerCase() !== range.term)
            invalid("INCOMPATIBLE_CAPABILITY", "snippets.range.source");
        } else if (context.analyzer.id === "code-identifiers-v1" && range.kind === "component") {
          const origin = range.original;
          if (!origin || !Number.isSafeInteger(origin.start) || !Number.isSafeInteger(origin.end) || origin.start < 0 || origin.end > original.length || origin.start > range.start || origin.end < range.end)
            invalid("INCOMPATIBLE_CAPABILITY", "snippets.range.original");
          const identifier = original.slice(origin.start, origin.end);
          yield charge8(identifier.length + origin.term.length + 1);
          let originals = 0, matched = false;
          for (const step of requireAnalysis(context)(identifier, 0, context.limits, "INCOMPATIBLE_CAPABILITY", "index")) {
            yield charge8(step.workUnits);
            if (!step.token)
              continue;
            const token = step.token;
            if (token.kind === "original") {
              originals++;
              if (token.term !== origin.term || token.start !== 0 || token.end !== identifier.length)
                invalid("INCOMPATIBLE_CAPABILITY", "snippets.range.original");
            } else if (token.kind === "component" && token.term === range.term && token.start + origin.start === range.start && token.end + origin.start === range.end)
              matched = true;
          }
          if (originals !== 1 || !matched)
            invalid("INCOMPATIBLE_CAPABILITY", "snippets.range.source");
        } else {
          if (context.analyzer.id === "code-identifiers-v1" && (range.kind !== "original" || range.original !== void 0))
            invalid("INCOMPATIBLE_CAPABILITY", "snippets.range.original");
          let tokens = 0;
          for (const step of requireAnalysis(context)(raw, 0, context.limits, "INCOMPATIBLE_CAPABILITY", "query")) {
            yield charge8(step.workUnits);
            if (!step.token)
              continue;
            if (++tokens !== 1 || step.token.start !== 0 || step.token.end !== raw.length || step.token.term !== range.term)
              invalid("INCOMPATIBLE_CAPABILITY", "snippets.range.source");
          }
          if (tokens !== 1)
            invalid("INCOMPATIBLE_CAPABILITY", "snippets.range.source");
        }
        priorStart = range.start;
        priorEnd = range.end;
        const start = points[yield* floor(points, range.start)];
        const end = points[yield* lower(points, range.end)];
        const unavailable = range.end - range.start > caps.codeUnits ? "match-too-long" : end - start > caps.codeUnits ? "grapheme-too-long" : null;
        expanded.push({ range, start, end, unavailable, shown: false });
      }
      result.push({ field, valueIndex, source: original, boundaries: points, ranges: expanded });
    }
  }
  return result;
}
function* windowFor(value, anchor, caps) {
  const width = anchor.end - anchor.start;
  const preferredStart = Math.max(0, anchor.start - Math.floor((caps.codeUnits - width) / 2));
  let start = value.boundaries[yield* lower(value.boundaries, preferredStart)];
  const end = value.boundaries[yield* floor(value.boundaries, Math.min(value.source.length, start + caps.codeUnits))];
  start = value.boundaries[yield* lower(value.boundaries, Math.max(0, end - caps.codeUnits))];
  if (start > anchor.start || end < anchor.end || end - start > caps.codeUnits)
    invalid("INTERNAL_ERROR", "snippets.window");
  const unions = [];
  for (const candidate of value.ranges) {
    yield charge8();
    if (candidate.unavailable || candidate.start < start || candidate.end > end)
      continue;
    const previous = unions[unions.length - 1];
    if (previous && candidate.start <= previous.end)
      previous.end = Math.max(previous.end, candidate.end);
    else
      unions.push({ start: candidate.start, end: candidate.end });
  }
  let anchorIndex = -1;
  for (let index = 0; index < unions.length; index++) {
    yield charge8();
    const union = unions[index];
    if (union.start <= anchor.start && union.end >= anchor.end) {
      anchorIndex = index;
      break;
    }
  }
  if (anchorIndex < 0)
    invalid("INTERNAL_ERROR", "snippets.anchor");
  const highlights = [];
  const first = Math.max(0, anchorIndex - caps.highlights + 1);
  for (let index = first; index < Math.min(unions.length, first + caps.highlights); index++) {
    yield charge8();
    highlights.push(unions[index]);
  }
  for (const candidate of value.ranges) {
    yield charge8();
    if (candidate.unavailable)
      continue;
    for (const highlight of highlights) {
      yield charge8();
      if (highlight.start <= candidate.start && highlight.end >= candidate.end) {
        candidate.shown = true;
        break;
      }
    }
  }
  return { value, start, end, highlights };
}
function* project3(context, roots, fields2, id, ranges, eligibility, host, caps) {
  const empty = { unshownMatches: 0, windowLimit: false, highlightLimit: false, matchTooLong: 0, graphemeTooLong: 0 };
  if (eligibility !== "matched" || ranges.length === 0) {
    yield charge8();
    if (ranges.length)
      invalid("INCOMPATIBLE_CAPABILITY", "snippets.eligibility");
    return { snippets: [], snippetOmissions: empty };
  }
  const values = yield* valuesFor(context, roots, fields2, id, ranges, host, caps), windows = [];
  for (const value of values) {
    for (const range of value.ranges) {
      yield charge8();
      if (!range.shown && !range.unavailable && windows.length < caps.windows)
        windows.push(yield* windowFor(value, range, caps));
    }
  }
  let unshownMatches = 0, unavailable = 0, matchTooLong = 0, graphemeTooLong = 0, highlightLimit = false;
  for (const value of values) {
    for (const range of value.ranges) {
      yield charge8();
      if (range.shown)
        continue;
      unshownMatches++;
      if (range.unavailable) {
        unavailable++;
        if (range.unavailable === "match-too-long")
          matchTooLong++;
        else
          graphemeTooLong++;
      } else {
        for (const window of windows) {
          yield charge8();
          if (window.value === value && range.start >= window.start && range.end <= window.end) {
            highlightLimit = true;
            break;
          }
        }
      }
    }
  }
  const snippets = [];
  for (const window of windows) {
    yield charge8(window.end - window.start + 1);
    const highlights = [];
    for (const mark of window.highlights) {
      yield charge8();
      highlights.push({ start: mark.start - window.start, end: mark.end - window.start });
    }
    snippets.push({
      field: window.value.field,
      valueIndex: window.value.valueIndex,
      start: window.start,
      end: window.end,
      text: window.value.source.slice(window.start, window.end),
      highlights,
      omittedBefore: window.start > 0,
      omittedAfter: window.end < window.value.source.length
    });
  }
  return { snippets, snippetOmissions: {
    unshownMatches,
    windowLimit: windows.length === caps.windows && unshownMatches > unavailable,
    highlightLimit,
    matchTooLong,
    graphemeTooLong
  } };
}
function presentation(caps) {
  return Object.freeze({
    capability: "snippets",
    workerOptions: Object.freeze({ ...caps }),
    prepare: function* (context, fields2) {
      const roots = /* @__PURE__ */ new Map();
      for (const field of fields2) {
        yield charge8(field.length + 1);
        roots.set(field, requireSourceRoot(context.state(`source:${field}`), field, context.revision, context.analyzer));
      }
      const host = segmenter();
      yield charge8();
      return Object.freeze({ project: (id, ranges, eligibility) => project3(context, roots, fields2, id, ranges, eligibility, host, caps) });
    }
  });
}
function createSnippetEvidence(options) {
  const data2 = ownObject(options, "INVALID_OPTIONS", "snippets.options", new Admission(DEFAULT_LIMITS.maxAdmissionEntries));
  keysOnly(data2, ["fields", "id", "maxFacts", "maxRanges", "maxWorkUnits", "maxOutputEntries", "maxSnippets", "maxCodeUnits", "maxHighlights"], "INVALID_OPTIONS", "snippets.options");
  const caps = Object.freeze({
    windows: cap2(has(data2, "maxSnippets") ? data2.maxSnippets : 3, 3, "snippets.maxSnippets"),
    codeUnits: cap2(has(data2, "maxCodeUnits") ? data2.maxCodeUnits : 240, 240, "snippets.maxCodeUnits"),
    highlights: cap2(has(data2, "maxHighlights") ? data2.maxHighlights : 32, 32, "snippets.maxHighlights")
  });
  const base = /* @__PURE__ */ Object.create(null);
  for (const key of ["fields", "id", "maxFacts", "maxRanges", "maxWorkUnits", "maxOutputEntries"])
    if (has(data2, key))
      base[key] = data2[key];
  if (!has(base, "id"))
    base.id = "snippets";
  return buildMatchEvidence(base, presentation(caps));
}

// records.mjs
var text = (value) => ({ kind: "text", text: value });
var phrase = (value, fields2 = ["title", "body"]) => ({ kind: "extension", capability: "phrases", version: 1, payload: { text: value, fields: fields2 } });
var queries = [
  ["file caf\xE9", ["a"]],
  [{ kind: "text", text: "\uFF23\uFF21\uFF32", fields: ["title"] }, ["a", "b", "d"]],
  ["red", ["a", "d", "b"]],
  [phrase("red car", ["title"]), ["a", "b"]],
  [phrase("red car"), ["a", "b", "d"]],
  [phrase("car red"), []],
  [{ kind: "extension", capability: "numeric-range", version: 1, payload: { field: "price", lt: 10 } }, ["a"]],
  [{ kind: "extension", capability: "set-membership", version: 1, payload: { field: "category", values: ["Guide"] } }, ["a", "d"]],
  [{ kind: "not", child: text("red") }, ["c", "empty"]],
  [{ kind: "or", children: [{ kind: "and", children: [text("red"), text("missing")] }, text("blue")] }, ["a", "c"]],
  [{ kind: "all" }, ["a", "b", "c", "d", "empty"]],
  [{ kind: "none" }, []]
];

// configuration.mjs
function addonsFor() {
  const strategies = { title: "source", body: "offsets" };
  return [
    createSourceProvider({ fields: ["title", "body"] }),
    createPositionProvider({ fields: ["body"], offsets: ["body"] }),
    createPhrases({ fields: { title: "source", body: "positions" } }),
    createFilters({ fields: ["price", "category"] }),
    createFacets({ fields: ["category"] }),
    createInspector({ sourceFields: ["title", "body"] }),
    createMatchEvidence({ fields: strategies }),
    createSnippetEvidence({ fields: strategies, maxCodeUnits: 80 })
  ];
}

// engine-worker.mjs
serveSnapshotRaveldexWorker(self, { addons: addonsFor() });
globalThis.__rx9002BulkTrace = (event) => self.postMessage({ __rx9002Bulk: event });
