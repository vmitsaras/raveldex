import { serveSnapshotRaveldexWorker } from '@vmitsaras/raveldex/adapters/worker/snapshots/host';
import { addonsFor } from './configuration.mjs';
serveSnapshotRaveldexWorker(self, { addons: addonsFor() });

globalThis.__rx9002BulkTrace = event => self.postMessage({__rx9002Bulk:event});
