import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { pathToFileURL } from 'node:url';
import { createServer } from 'node:http';
const [repo, stage] = process.argv.slice(2), exec = promisify(execFile);
const report = { status: 'Fail', observations: [], errors: [] };
let server, browser;
try {
  const follow = JSON.parse(await fs.readFile(path.join(stage, 'follow.json')));
  const example = /EXAMPLE_RESULT=(.+)/.exec(follow.commands.find(row => row.stdout?.includes('EXAMPLE_RESULT=')).stdout)[1];
  const project = path.join(example, 'copied-guide'); await fs.mkdir(path.join(project, 'src/pages/guide/updates'), { recursive: true });
  const source = await fs.readFile(path.join(repo, 'docs/api/STATIC_ASTRO.md'), 'utf8');
  const code = [...source.matchAll(/```js\n([\s\S]*?)\n```/g)].map(item => item[1]); assert.equal(code.length, 4);
  await fs.writeFile(path.join(project, 'search-content.mjs'), code[0]);
  await fs.writeFile(path.join(project, 'build.mjs'), code[1] + '\nexport { artifacts };');
  const { artifacts } = await import(pathToFileURL(path.join(project, 'build.mjs')));
  assert.equal(artifacts.manifest.recordCount, 1); assert.equal(artifacts.manifest.base, '/docs/');
  await fs.writeFile(path.join(project, 'astro.config.mjs'), code[2]);
  await fs.writeFile(path.join(project, 'client.mjs'), code[3] + '\nwindow.copiedGuide = { loaded, ui };');
  await fs.writeFile(path.join(project, 'src/pages/index.astro'), '<!doctype html><html lang="en"><head><title>Copied Astro guide</title></head><body><section id="search" aria-label="Documentation search"></section><script>import "../../client.mjs";</script></body></html>');
  await fs.writeFile(path.join(project, 'src/pages/guide/updates/index.astro'), '<!doctype html><html lang="en"><head><title>Atomic updates</title></head><body><h1>Atomic updates</h1></body></html>');
  const build = await exec(process.execPath, [path.join(example, 'node_modules/astro/bin/astro.mjs'), 'build', '--root', project], {
    cwd: project, env: { ...process.env, ASTRO_TELEMETRY_DISABLED: '1' }, timeout: 120_000, maxBuffer: 4 * 1024 * 1024 });
  report.build = build;
  const files = new Map();
  async function visit(dir, prefix = '') {
    for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
      const key = prefix + entry.name;
      if (entry.isDirectory()) await visit(path.join(dir, entry.name), key + '/');
      else files.set(key, await fs.readFile(path.join(dir, entry.name)));
    }
  }
  await visit(path.join(project, 'dist'));
  server = createServer((request, response) => {
    const url = new URL(request.url, 'http://localhost');
    let key = url.pathname.startsWith('/docs/') ? url.pathname.slice(6) : '';
    if (!key || key.endsWith('/')) key += 'index.html';
    const data = files.get(key), ext = key.split('.').at(-1);
    response.writeHead(data ? 200 : 404, { 'content-type': { html: 'text/html', css: 'text/css', js: 'text/javascript', json: 'application/json' }[ext] ?? 'application/octet-stream' });
    response.end(data);
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const { chromium } = await import(pathToFileURL(path.join(repo, 'node_modules/playwright-core/index.mjs')));
  browser = await chromium.launch({ channel: 'chrome', headless: true });
  const page = await browser.newPage(), errors = [];
  page.on('pageerror', error => errors.push(String(error)));
  await page.goto(`http://127.0.0.1:${server.address().port}/docs/`);
  await page.waitForFunction(() => Boolean(window.copiedGuide));
  await page.getByRole('searchbox').fill('atomic'); await page.getByRole('button', { name: 'Search', exact: true }).click();
  await page.waitForFunction(() => document.querySelector('[data-raveldex-status]')?.textContent === '1 results. Showing 1–1.');
  assert.equal(await page.getByRole('link', { name: 'Atomic updates', exact: true }).count(), 1);
  const destination = await page.getByRole('link', { name: 'Atomic updates', exact: true }).getAttribute('href');
  assert.equal(new URL(destination).pathname, '/docs/guide/updates/');
  assert.equal((await fetch(destination)).status, 200);
  await page.evaluate(async () => { window.copiedGuide.ui.destroy(); await window.copiedGuide.loaded.dispose(); });
  assert.equal(await page.locator('#search').innerHTML(), ''); assert.deepEqual(errors, []);
  report.observations.push({ name: 'Four exact Astro guide code blocks: shared content, Node builder, real Astro hook and browser loader', base: '/docs/', total: 1, displayUrl: '/docs/guide/updates/', cleanup: true, pageErrors: errors });
  report.status = 'Pass';
} catch (error) { report.errors.push({ message: error.message, stack: error.stack }); throw error; }
finally {
  await browser?.close(); if (server) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
  await fs.writeFile(path.join(stage, 'astro-snippets.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ status: report.status, observations: report.observations.length, errors: report.errors }));
}
