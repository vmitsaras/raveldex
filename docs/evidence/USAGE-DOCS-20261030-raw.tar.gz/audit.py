from pathlib import Path
import json, hashlib, tarfile, subprocess, re
repo=Path('/Users/vasilis/Documents/GitHub/raveldex');stage=Path('/tmp/raveldex-usage-docs-20261030')
preserved=json.loads((stage/'preserved.json').read_text())
for name,meta in preserved.items():
    p=repo/name
    assert p.is_file() and p.stat().st_size==meta['bytes'] and p.stat().st_mtime_ns==meta['mtime'],name
    if 'sha256' in meta:assert hashlib.sha256(p.read_bytes()).hexdigest()==meta['sha256'],name
manifest=json.loads((repo/'docs/_pages-manifest.json').read_text())
expected={x['path']:x for x in manifest['files'] if x['path']!='_config.yml'}
actual={p.relative_to(stage/'jekyll-output').as_posix():p for p in (stage/'jekyll-output').rglob('*') if p.is_file()}
assert set(actual)==set(expected)
for name,p in actual.items():assert hashlib.sha256(p.read_bytes()).hexdigest()==expected[name]['sha256'],name
assert (repo/'docs/_pages-manifest.json').read_bytes()==(stage/'final-manifest-first.json').read_bytes()
for name in ['src','package-lock.json','docs/planning/roadmap.json','docs/specs','docs/architecture','test/fixtures','examples/core-docs/corpus.mjs','integrations/astro/src','integrations/languages/english/src','examples/astro/content.json','examples/astro/content-provenance.json','examples/astro/qualification.mjs']:
    assert not subprocess.check_output(['git','diff','87fb5c3','--',name],cwd=repo).strip(),name
before=(stage/'before.patch').read_text(); after=subprocess.check_output(['git','diff','87fb5c3','--','package.json'],cwd=repo,text=True)
section=next(part for part in before.split('diff --git ')[1:] if part.startswith('a/package.json b/package.json'))
assert after=='diff --git '+section
comparisons=[]
for label,new,old in [
 ('core',stage/'closed-core/vmitsaras-raveldex-0.1.0-rc.0.tgz',stage/'baseline/core.tgz'),
 ('english',stage/'source-artifacts/english/vmitsaras-raveldex-english-0.1.0-rc.0.tgz',stage/'baseline/english.tgz'),
 ('astro',stage/'source-artifacts/astro/vmitsaras-raveldex-astro-0.1.0-rc.0.tgz',stage/'baseline/astro.tgz')]:
    with tarfile.open(new) as a,tarfile.open(old) as b:
        aa={x.name:a.extractfile(x).read() for x in a if x.isfile()};bb={x.name:b.extractfile(x).read() for x in b if x.isfile()}
        runtime={k:v for k,v in aa.items() if k.startswith('package/dist/')}
        assert runtime=={k:v for k,v in bb.items() if k.startswith('package/dist/')},label
        metadata=json.loads(aa['package/package.json']);assert metadata['private'] and metadata['version']=='0.1.0-rc.0'
        assert all(not k.startswith(('package/docs/guide/','package/docs/demo/','package/site/')) for k in aa)
        for name,content in aa.items():
            if name.endswith('.md'):
                source=repo/name.removeprefix('package/') if label=='core' else repo/('integrations/astro/README.md' if label=='astro' else 'integrations/languages/english/README.md')
                assert source.read_bytes()==content,(label,name)
        comparisons.append({'name':label,'productionMembersUnchanged':len(runtime),'members':len(aa),'bytes':new.stat().st_size,'sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'private':True,'version':'0.1.0-rc.0'})
editorial=[]
for name,p in actual.items():
    text=p.read_text()
    if name.endswith('.html'):
        prose=re.sub(r'<pre[\s\S]*?</pre>|<code[\s\S]*?</code>','',text);prose=re.sub(r'<[^>]+>',' ',prose)
        if re.search(r'RX-\d{4}|owner.reported|user confirmed|Medium verbosity|VoiceOver Utility|15 KiB|3407c2a',prose,re.I):editorial.append(name)
assert not editorial
for route in ['contracts/core-contract/index.html','guide/preparation/index.html','guide/publication-status/index.html','guide/release-notes/index.html','guide/release-scope/index.html']:
    assert not (repo/'docs'/route).exists(),route
report={'status':'Pass','protectedRecordsUnchanged':len(preserved),'metadataUnchangedSinceTaskStart':True,'packageComparisons':comparisons,'publicFiles':len(actual),'publicBytes':sum(p.stat().st_size for p in actual.values()),'htmlPages':sum(p.endswith('.html') for p in actual),'jekyllByteIdentity':True,'deterministicOutput':True,'manifestSha256':hashlib.sha256((repo/'docs/_pages-manifest.json').read_bytes()).hexdigest(),'editorialFindings':editorial,'qualificationCorpusSha256':'267ec0eeb44c09bb3e24cf8a8e71cd90a73441d16f406a891c73f8f8603fdded','usageCorpus':json.loads((repo/'docs/demo/corpus.json').read_text())['hash']}
(stage/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
