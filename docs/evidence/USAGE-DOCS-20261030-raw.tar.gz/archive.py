from pathlib import Path
import json, tarfile, gzip, io, hashlib
repo=Path('/Users/vasilis/Documents/GitHub/raveldex');stage=Path('/tmp/raveldex-usage-docs-20261030')
target=repo/'docs/evidence/USAGE-DOCS-20261030-raw.tar.gz';assert not target.exists()
files={}
def add(root,name,output=None):
    p=root/name;assert p.is_file() and not p.is_symlink(),p
    files[output or name]=p.read_bytes()
for name in ['before.patch','before-docs.tar.gz','preserved.json','npm-ci.log','check.log','build-1.log','build-2.log','final-build-1.log','final-build-2.log','final-manifest-first.json','pages-check.log','candidate.log','candidate-final.log','closed-core.log','ui-example.log','browser.log','browser.json','browser-final.log','browser-final.json','browser-closed.log','browser-closed.json','verified-browser.log','verified-browser.json','follow.mjs','follow.json','follow.log','astro-snippets.mjs','astro-snippets.json','astro-snippets.log','local-demo.log','jekyll.log','preservation-jekyll.json','audit.py','audit.json','audit.log','home.png','home-narrow.png','demo.png','archive.py']:
    add(stage,name)
for folder,names in {
    'closed-core':['candidate-report.json','vmitsaras-raveldex-0.1.0-rc.0.tgz'],
    'source-artifacts/core':['vmitsaras-raveldex-0.1.0-rc.0.tgz'],
    'source-artifacts/english':['english-package.json','verification.log','vmitsaras-raveldex-english-0.1.0-rc.0.tgz'],
    'source-artifacts/astro':['astro-package.json','verification.log','vmitsaras-raveldex-astro-0.1.0-rc.0.tgz'],
    'baseline':['core.tgz','english.tgz','astro.tgz']}.items():
    for name in names:add(stage,folder+'/'+name)
for p in (stage/'jekyll-output').rglob('*'):
    if p.is_file():add(stage,p.relative_to(stage).as_posix())
manifest=json.loads((repo/'docs/_pages-manifest.json').read_text())
sources=set(x['path'] for x in manifest['inputs'] if not x['path'].startswith('dist/'))
sources.update(['site/README.md','test/pages/browser.test.mjs','test/pages/ui-example.test.mjs','test/tooling/usage-corpus.test.mjs','test/consumer/ui-pilot.test.mjs','test/ui/packed-browser.test.mjs','scripts/ui-pilot.mjs','examples/docs-search/pilot.css','docs/evidence/USAGE-DOCS-20261030.md','docs/_config.yml','docs/_pages-manifest.json','PROJECT_CONTEXT.md','CODEX_HANDOFF.md'])
for name in sources:add(repo,name,'source/'+name)
inventory={'kind':'raveldex-usage-docs-raw-v1','files':[{'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in sorted(files.items())]}
files['manifest.json']=(json.dumps(inventory,indent=2)+'\n').encode()
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as t:
    for name,data in sorted(files.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
        t.addfile(member,io.BytesIO(data))
raw=gzip.compress(stream.getvalue(),compresslevel=9,mtime=0);target.write_bytes(raw)
report=json.loads((stage/'audit.json').read_text())
report.update({'date':'2026-10-30','implementation':'complete','verification':'Pass','fullCheck':{'tests':868,'fail':0,'skip':0,'batches':[784,30,24,26,1,3]},'focusedBrowser':{'tests':2,'fail':0,'report':'verified-browser.json','sequential':True},'widths':[320,390,768,1024,1280],'localLinksAndFragments':427,'nativeSafariZoom':{'browser':'Safari 27.0.1 (22625.1.29.11.28)','zoomObserved':'200 %','method':'Computer Use native page menu and AX/screenshot observation','query':'module worker','total':1,'inspectorInitialFocus':'Close Inspector','escapeFocus':'Inspect results','normalZoomRestored':True,'scope':'Finite native-app automation before final Astro code-example completion; no human speech/physical input claim.'},'astroCodeBlocks':'Pass: four exact blocks together','documentedCommands':'Pass: five observations','publication':'Not performed','failedAttempt':'An overlapped browser run exceeded 120 seconds; its shared log is unsuitable for acceptance. Subsequent sequential verified-browser run passed 2/2. Cause unconfirmed.','rawArchive':{'path':'docs/evidence/USAGE-DOCS-20261030-raw.tar.gz','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'members':len(files)}})
(repo/'docs/evidence/USAGE-DOCS-20261030.json').write_text(json.dumps(report,indent=2)+'\n')
with tarfile.open(target) as t:
    for item in inventory['files']:
        data=t.extractfile(item['path']).read();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
print(json.dumps(report['rawArchive']))
print('All archive member identities verified')
