# Runtime and integration requirements

## Modules and runtimes

Raveldex provides ESM imports and TypeScript declarations. Use the declared package exports; implementation paths under `dist/` and `src/` are not supported imports. There is no CommonJS entry.

| Package or feature | Requirement |
| --- | --- |
| Core and English analyzer | Node `>=22` for Node applications. Core has no DOM dependency. |
| Astro integration | Node `>=22.12.0`, exact core peer `0.1.0-rc.0`; the build hook requires Astro `7.3.2`. |
| Native DOM UI | A browser DOM and a bundler or static build that resolves the public ESM imports. Import UI CSS separately. |
| Snippets | Usable `Intl.Segmenter` for grapheme-safe display boundaries. |
| Worker adapter | Module workers and matching client/host configuration and add-ons. |
| IndexedDB adapter | An available IndexedDB factory and an application-selected database/namespace. |

Importing core does not initialize a UI, worker, database or network request. Create those integrations explicitly.

## Analyzer compatibility

The default analyzer normalizes NFKC and lowercases tokens. Accents remain significant: `cafe` and `café` can produce different matches. Choose [English morphology](ENGLISH.md) or [identifier analysis](IDENTIFIERS.md) when those rules suit your corpus. Changing analyzer requires rebuilding the index.

Workers must use the same analyzer, schema, limits and selected capabilities as the main-thread configuration. Functions and live add-on handles must be installed locally in each host rather than sent as cloneable configuration.

## Snapshot compatibility

Use source snapshots for browser/worker rebuilding. Retain original text for every field you need to export. Source restore uses the receiving analyzer and runtime, so cross-runtime tokenization and scores can differ.

Native snapshots require an application-supplied `NativeSnapshotQualification` at engine creation and the exact declared Node/V8/ICU/Unicode/platform/architecture environment. Version detection alone does not establish that qualification. Browser and worker native loading is unavailable. See [snapshot setup and methods](HOSTS.md#source-and-native-snapshots).

## UI integration

The UI uses native form, select, link and dialog behavior. It keeps search focus during result updates and returns Inspector focus to its opener on close. Status announcements depend on the browser and screen reader, and typing feedback can interrupt them; test the combination used by your application. Do not require users to change screen-reader settings.

See [keyboard, focus and status](HOSTS.md#keyboard-focus-and-status) and [practical limits](LIMITATIONS.md).
