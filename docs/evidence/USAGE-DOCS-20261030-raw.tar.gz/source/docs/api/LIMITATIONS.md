# Practical limits and recovery

## Matching text

Default string queries are lexical AND searches over complete normalized terms. They do not infer meaning, strip accents, correct typos or automatically treat the last word as a prefix. Use explicit [prefix queries](CORE.md#query-shapes), [typo tolerance](TYPO.md), [synonyms](SYNONYMS.md) or [query syntax](QUERY_SYNTAX.md) when your interface needs those behaviors.

[English stemming](ENGLISH.md) can join differently spelled words, but can also join words you intended to keep separate. Review results against your own vocabulary. Literal/infix and ordered-proximity matching are separate optional operations; they are not enabled by ordinary strings.

## Retain the data you need

Core retains indexed statistics, not original text, positions or offsets. Select providers before creating the engine when your application needs phrases, source export, highlights or snippets. Provider/analyzer changes require a new engine and rebuild.

Snippets are bounded excerpts and can omit matches or context. Use the result URL or your full document view to show the complete source. Render supplied snippet text as text and explicit highlight ranges, never as trusted HTML.

## Handle operation limits

Record, dictionary, posting, queue, work, output and deadline bounds apply independently. A collection admitted in several batches can still exceed the budget of a single source restore. `WORK_LIMIT_EXCEEDED` or `DEADLINE_EXCEEDED` rejects the operation; do not display an incomplete total as a successful search.

Pass an `AbortSignal` when work becomes obsolete, handle the typed error, and keep authoritative application data for recovery. See [execution, errors and bounds](CORE.md#execution-errors-and-bounds).

## Recover worker and storage operations

A missing worker reply does not prove that a mutation failed. Use its operation ID to reconcile while the session survives. If the owner is lost or its receipt has expired, rebuild explicitly from authoritative source instead of blindly retrying the write.

IndexedDB save/load/erase use explicit generation tokens. Handle conflicts by loading the current generation and deciding what to save. Storage quota or availability failures do not make a save successful. The DOM UI presents worker failures as a generic search error; use the adapter's typed error for application diagnostics.

## Choose snapshot format deliberately

Source snapshots rebuild under the receiver and may exceed its operation budget. Native snapshots require the exact application-qualified Node runtime; they are not portable browser caches. See [snapshot requirements](COMPATIBILITY.md#snapshot-compatibility).

## Test your interface

The native UI supplies labeled controls, status messages and a modal Inspector. Keep visible focus and readable contrast when styling it. Status speech can be interrupted by typing feedback; confirm the important flows in your application's target browser and assistive technology. See [UI integration](HOSTS.md#native-dom-ui-and-css).
