# Static search and Astro

Use `@vmitsaras/raveldex-astro` to build a search index from selected content and load it on demand. Core stays framework independent; the integration supplies a static builder, an Astro hook and a browser loader.

## Install matching packages

Install the local core and integration artifacts together. The integration requires core `0.1.0-rc.0`, Node `>=22.12.0`, and Astro `7.3.2` when using the build hook:

```sh
npm install --ignore-scripts --no-audit --no-fund /absolute/artifacts/core/vmitsaras-raveldex-0.1.0-rc.0.tgz /absolute/artifacts/astro/vmitsaras-raveldex-astro-0.1.0-rc.0.tgz astro@7.3.2
```

See [building tarballs](GETTING_STARTED.md#build-tarballs-from-a-source-checkout). Static builder/client applications that do not use the Astro hook can omit the optional Astro peer.

## Build static search

Supply every record, title and directory-style route explicitly. The builder does not crawl pages or parse Markdown/HTML. Keep drafts and private content out of this allowlist. Every indexed text field needs a source provider. Put the shared content in `search-content.mjs`:

```js
import { createSourceProvider } from '@vmitsaras/raveldex/addons/phrases/source';

export const configuration = {
  schema: { text: { title: {}, body: {} } },
  addons: [createSourceProvider({ fields: ['title', 'body'] })],
};
export const entries = [{
    record: { id: 'updates', text: { title: 'Atomic updates', body: 'Replace a complete record.' } },
    title: 'Atomic updates',
    path: '/guide/updates/',
  }];
```

Use it from a Node build module:

```js
import { buildStaticSearch } from '@vmitsaras/raveldex-astro/build';
import { configuration, entries } from './search-content.mjs';

const artifacts = await buildStaticSearch({
  configuration,
  buildId: 'docs-v1',
  base: '/docs/',
  entries,
});
console.log(artifacts.manifest.recordCount); // 1
```

The returned `{ manifest, files }` contains JSON files with content-addressed names. Write all content files into your owned `raveldex/` directory before writing `manifest.json`. Use a new build ID and complete generation when content changes. Safe directory-style ASCII base paths end in `/`; IDs stay independent of the deployment base.

## Use the Astro hook

Import the default `raveldexAstro` factory from `@vmitsaras/raveldex-astro` in `astro.config.mjs`. Pass `configuration`, `buildId` and `getEntries`. Use static output and directory-style routes. The hook creates search assets after the static build and uses Astro's configured base.

Create `astro.config.mjs` using the shared content above:

```js
import { defineConfig } from 'astro/config';
import raveldexAstro from '@vmitsaras/raveldex-astro';
import { configuration, entries } from './search-content.mjs';

export default defineConfig({
  output: 'static',
  base: '/docs/',
  trailingSlash: 'always',
  integrations: [raveldexAstro({ configuration, buildId: 'docs-v1', getEntries: () => entries })],
});
```

Follow [the runnable Astro example](https://github.com/vmitsaras/raveldex/blob/main/examples/astro/README.md) to copy, install, build and preview at both `/` and `/docs/`.

## Load search on demand

Import `loadStaticSearch` from `@vmitsaras/raveldex-astro/client`. Provide the manifest URL, expected build ID and the same configuration. Use its engine for queries; request display documents only when opening the interface:

```js
import { loadStaticSearch } from '@vmitsaras/raveldex-astro/client';
import { mountRaveldexUI } from '@vmitsaras/raveldex/addons/ui';
import '@vmitsaras/raveldex/addons/ui/styles.css';
import { configuration } from './search-content.mjs';

const loaded = await loadStaticSearch({
  manifestUrl: new URL('/docs/raveldex/manifest.json', location.origin).href,
  expectedBuildId: 'docs-v1',
  configuration,
});
const ui = mountRaveldexUI({
  root: document.querySelector('#search'),
  engine: loaded.engine,
  documents: await loaded.loadDocuments(),
});
// When removing the search component:
// ui.destroy();
// await loaded.dispose();
```

Resolve the manifest relative to the site's deployment base, not an arbitrary nested route. Keep authored documentation links available while loading. Handle loader errors and offer an explicit retry; do not replace a working engine until its replacement has loaded successfully. The loader validates build/configuration identity, file sizes and digests. SHA-256 checks detect corruption or mixed generations, not an untrusted sender.

## Release resources and choose formats

Destroy a mounted UI first, then call `loaded.dispose()` to abort pending display requests and dispose the owned engine. Use source snapshots in browsers. Native loading requires an exact application-qualified Node runtime and matching declaration; browser native loading refuses rather than silently rebuilding.

The hook supports static builds, not `astro dev`, SSR, route crawling or watchers. Whole-source rebuilds and output sizes remain bounded. See [snapshot requirements](COMPATIBILITY.md#snapshot-compatibility), [operation limits](LIMITATIONS.md#handle-operation-limits) and the [full builder/loader API](https://github.com/vmitsaras/raveldex/blob/main/integrations/astro/README.md).
