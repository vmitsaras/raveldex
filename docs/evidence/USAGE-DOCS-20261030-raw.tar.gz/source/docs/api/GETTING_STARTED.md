# Getting started

Raveldex searches records you provide. Define searchable fields, add records, then use the returned IDs to look up your application's titles, URLs or other display data.

## Install the package

The packages are currently unpublished and supplied as local tarballs. Use an ESM application and install the file you have received or built:

```sh
npm init -y
npm pkg set type=module
npm install --offline --ignore-scripts --no-audit --no-fund /absolute/artifacts/core/vmitsaras-raveldex-0.1.0-rc.0.tgz
```

Replace the absolute path with your core tarball. Core and the English analyzer require Node 22 or later; the Astro integration requires Node 22.12 or later. Browser applications bundle the ESM imports with their existing tooling. See [compatibility](COMPATIBILITY.md).

## Smallest core example

```js
import { createRaveldex } from '@vmitsaras/raveldex';

const engine = createRaveldex({
  schema: { text: { title: { boost: 2 }, body: {} } },
});
try {
  await engine.add({
    id: 'guide:updates',
    text: { title: 'Atomic updates', body: 'Replace one complete record.' },
  });
  const result = await engine.search('atomic');
  console.log(result.total); // 1
  console.log(result.hits[0].id); // guide:updates
} finally {
  await engine.dispose();
}
```

The field boost gives title matches more weight. `total` is the complete matching count; `hits` is the requested page of IDs and scores. Keep display documents in your application and join them by ID. Default string searches require all complete analyzed terms: `atomic updates` matches the title above, while `atom` does not. Use an explicit prefix query when you need prefix matching.

## Update your collection

Use `addMany` to add a batch, `replace` to replace a complete record, `remove` to delete IDs and `clear` to empty the collection. Await writes before searching when the result must include them. Successful writes publish one consistent revision; results identify the revision they searched. See [records, mutations and query shapes](CORE.md).

## Add a search interface

Use [the native DOM UI](HOSTS.md#native-dom-ui-and-css) to mount a labeled search form, results and pagination into your own element. Import its CSS separately. The UI borrows your engine: destroy the interface before disposing that engine.

Core does not retain original text. Select a source or position provider when you need [phrases, snippets or highlights](ADDONS.md). For static Astro pages, follow [the Astro guide](STATIC_ASTRO.md).

## Build tarballs from a source checkout

If you have repository access, use Node 24 and npm. From the repository root, compile once and pack the three matching artifacts:

```sh
export RAVELDEX_REPOSITORY="$(pwd -P)"
export RAVELDEX_ARTIFACTS="$(mktemp -d "${TMPDIR:-/tmp}/raveldex-artifacts.XXXXXX")"
npm ci
npm run build
mkdir "$RAVELDEX_ARTIFACTS/core"
npm pack --ignore-scripts --pack-destination "$RAVELDEX_ARTIFACTS/core"
node scripts/pack-english.mjs --output "$RAVELDEX_ARTIFACTS/english"
node scripts/pack-astro.mjs --output "$RAVELDEX_ARTIFACTS/astro"
```

Each separate pack output directory must be new. Keep these variables in the shell when following the [Astro example](https://github.com/vmitsaras/raveldex/blob/main/examples/astro/README.md). The commands compile and pack local artifacts. Install the matching local core alongside either optional package; the Astro build hook also uses `astro@7.3.2`.

## Next steps

- [Choose optional capabilities](ADDONS.md): phrases, facets, typo tolerance, suggestions and more.
- [Use the public API](README.md): options, defaults, methods and result types.
- [Run the example modules](examples/README.md) in your own installed application.
- [Handle practical limits](LIMITATIONS.md): analysis, operation bounds and recovery.
