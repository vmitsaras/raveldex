# Build and preview the documentation site

The intended publishing source is **GitHub Pages → Deploy from a branch → main → /docs**. The generated site uses `/raveldex/`; there is no custom domain or Pages deployment workflow. Building or previewing does not publish anything.

## Local workflow

Use Node 24 and npm in a source checkout. The pinned Astro toolchain renders the explicit public source list in [pages.mjs](pages.mjs). The browser demo is bundled from a real locally packed/installed core package. No registry release is needed.

```sh
npm ci
npm run pages:build
npm run pages:check
npm run pages:preview
```

Open `http://127.0.0.1:4174/raveldex/`. Use `npm run pages:preview -- --port 4175` if the default port is occupied. Ctrl+C stops only that preview. Read a guide, open the browser demo, search `module worker`, follow the result to its usage guide, expand Advanced demo settings and compare direct/worker execution.

`pages:build` compiles package output, then generates the site. `pages:generate` reuses existing compiler output; run it only after a successful package build. `pages:check` verifies generated/source identities, local links/fragments and the publishable inventory. Source changes require regeneration. Package `build` and `prepack` remain separate from site generation.

For Astro integration onboarding, follow [the existing fixture walkthrough](../examples/astro/README.md). It includes paired local packages, isolated installation, root and `/docs/` builds/previews and cleanup. The documentation site does not turn that qualification fixture into a production starter.

## Preserve repository-only records

Existing `docs/` source, evidence, history and planning paths remain intact. Only files in `docs/_pages-manifest.json` are owned by the generator. It refuses unexpected files, symlinks and edited generated output; inspect a refusal rather than deleting the existing tree or overwriting human edits. Scratch builds live under ignored `.tmp/pages/`.

The preview serves only the verified public inventory. Do not substitute a server that exposes the whole `docs/` directory: it also contains repository-only records.

`docs/_config.yml` is required to exclude every original source/maintainer directory when GitHub publishes from the branch. **Never add `.nojekyll`** or an overriding Jekyll `include`: that would bypass this boundary. The local inventory check is deliberately strict, but is not itself a Jekyll build. Before activation, verify an actual Pages-compatible Jekyll build in isolated tooling and inspect its final output. Record unavailable tooling as Blocked.

The generated HTML has no front matter; GitHub's Jekyll stage passes it through as static files. Its only required transformation is excluding non-public records. No theme, custom plugins, Ruby application or server runtime is shipped. See [GitHub's Jekyll configuration](https://docs.github.com/en/pages/setting-up-a-github-pages-site-with-jekyll/about-github-pages-and-jekyll).

For the site's browser regression check, use the same installed Chrome or configured Chromium prerequisite as the package checks, then run `node --test test/pages/browser.test.mjs`. The check starts and stops its own preview, exercises direct/worker search and local links, and records finite DOM behavior rather than human screen-reader or physical-input qualification.

## One-time repository settings and later activation

After local review, a maintainer with an eligible GitHub plan selects **Settings → Pages → Build and deployment → Deploy from a branch → main → /docs**, then saves. The expected project address is `https://vmitsaras.github.io/raveldex/`; it is a target address, not a claim that the site is live. Publishing from a private personal repository requires a plan supporting private-repository Pages. Do not change repository visibility to work around missing eligibility.

Commit the generated files with the site sources when explicitly authorized; changing the branch publishing folder requires regenerating first. Do not push or enable Pages merely to run local verification. No packages, tags or releases are created by this workflow.

The source repository is already larger than GitHub's recommended 1 GB repository size. The public file inventory excludes roughly 6.7 GB of raw evidence; nevertheless, GitHub build/checkout duration must be observed during eventual activation. Published output must remain below 1 GB and deployments below ten minutes. See [Pages limits](https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits).
