# Add local search to your application

Raveldex indexes the records you provide and returns ranked IDs, scores and exact result counts. Use core alone, or add a browser interface, filters, snippets, workers and static-site integration.

[Try the live demo](../examples/docs-search/index.html) · [Get started](../docs/api/GETTING_STARTED.md)

## A small working example

<!-- usage-core-example -->

Define searchable fields, add a record, and search. Keep the display data in your own application; results identify it by ID.

## What would you like to build?

- [Add records, search and update a collection](../docs/api/CORE.md).
- [Mount a browser search form and style it](../docs/api/HOSTS.md#native-dom-ui-and-css).
- [Add phrases, filters, facets and snippets](../docs/api/ADDONS.md).
- [Run a module worker](../docs/api/HOSTS.md#one-owner-module-worker) or [save source snapshots](../docs/api/HOSTS.md#source-and-native-snapshots).
- [Add search to Astro pages](../docs/api/STATIC_ASTRO.md) with the [setup/build/preview example](../examples/astro/README.md).

Browse the [guides](guides.md), [API reference](../docs/api/README.md) or [runnable examples](../examples/README.md). Check [runtime requirements](../docs/api/COMPATIBILITY.md) and [practical limits](../docs/api/LIMITATIONS.md) when choosing optional features.
