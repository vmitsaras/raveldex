# Raveldex

Add local search to your application's records. Raveldex is a framework-independent TypeScript library with ESM imports, native BM25 ranking, exact result counts and atomic updates. Core has no runtime dependencies and needs no DOM, worker or database.

[Get started](docs/api/GETTING_STARTED.md) · [API reference](docs/api/README.md) · [Runnable examples](https://github.com/vmitsaras/raveldex/blob/main/examples/README.md)

## Install

The packages are currently unpublished. Install a supplied or locally built tarball into an ESM application:

```sh
npm init -y
npm pkg set type=module
npm install --offline --ignore-scripts /absolute/artifacts/core/vmitsaras-raveldex-0.1.0-rc.0.tgz
```

Replace the path with your core artifact. To create the tarballs from a source checkout, follow [build from source](docs/api/GETTING_STARTED.md#build-tarballs-from-a-source-checkout). Core and English use Node 22 or later; the Astro integration uses Node 22.12 or later. Browser applications use the same ESM imports through their existing bundler.

## Smallest core example

<!-- candidate-example: quick-start -->
```js
import { createRaveldex } from '@vmitsaras/raveldex';

const engine = createRaveldex({
  schema: { text: { title: { boost: 2 }, body: {} } },
});
try {
  await engine.add({
    id: 'guide:updates',
    text: { title: 'Atomic updates', body: 'Replace one complete record.' },
  });
  const page = await engine.search('atomic');
  console.log(page.revision, page.total, page.hits);
} finally {
  await engine.dispose();
}
```

`total` counts every match; `hits` contains the current page of IDs and scores. Keep display records in your application and join them by ID. Plain string queries require all complete analyzed terms. Use explicit prefix or optional query operations for other matching behavior.

## Build the search you need

| Task | Guide |
| --- | --- |
| Define fields, index documents and update records | [Core usage](docs/api/CORE.md) |
| Add phrases, filters, facets, snippets or highlights | [Search add-ons](docs/api/ADDONS.md) |
| Mount search controls and customize their CSS | [Native DOM UI](docs/api/HOSTS.md#native-dom-ui-and-css) |
| Run search in a worker or save source snapshots | [Host integrations](docs/api/HOSTS.md) |
| Add search to static Astro pages | [Astro](docs/api/STATIC_ASTRO.md) |
| Choose English morphology or identifier components | [English](docs/api/ENGLISH.md) · [Identifiers](docs/api/IDENTIFIERS.md) |
| Offer explicit spelling and query tools | [Typos](docs/api/TYPO.md) · [Suggestions](docs/api/SUGGESTIONS.md) · [Synonyms](docs/api/SYNONYMS.md) · [Query syntax](docs/api/QUERY_SYNTAX.md) |
| Match raw text, ordered terms or apply record patches | [Literal/infix](docs/api/LITERAL.md) · [Proximity](docs/api/PROXIMITY.md) · [Patches](docs/api/RECORD_PATCH.md) |

Select optional providers when creating the engine. Core alone retains no original text, positions or offsets. Import UI CSS separately, and destroy a borrowed UI before disposing its engine.

## Examples

Use `npm run pilot:ui` from a source checkout for the interactive usage-guide search demo. Try `source provider`, choose a category, open a guide, or inspect why a result matched. Advanced settings compare exact terms with phrases, direct execution with a worker, and source reanalysis with stored offsets.

The [example index](https://github.com/vmitsaras/raveldex/blob/main/examples/README.md) also links the core terminal example, [complete Astro setup/build/preview walkthrough](https://github.com/vmitsaras/raveldex/blob/main/examples/astro/README.md), migration example and small installed API recipes. Source checkout links require repository access.

## Requirements and limits

Default matching is lexical and accent-sensitive; it does not infer meaning or correct spelling automatically. Handle work/deadline errors, and reconcile uncertain transport writes before retrying. Use source snapshots for browser/worker rebuilding; native snapshots require an exact application-qualified Node environment. Read [compatibility](docs/api/COMPATIBILITY.md) and [practical limits](docs/api/LIMITATIONS.md).

MIT licensed. [Source and issues](https://github.com/vmitsaras/raveldex) require repository access.
