# Examples

Choose an example based on where you want search to run.

| Example | Run it | What to try |
| --- | --- | --- |
| [Browser search](docs-search/README.md) | `npm run pilot:ui` | Search usage guides, filter results, inspect scores and compare direct/worker execution. |
| [Core terminal search](core-docs/README.md) | `npm run pilot:core -- 'atomic mutation'` | Index source records and read IDs, scores and exact totals. |
| [Astro static site](astro/README.md) | Follow the copy/install/build/preview steps | Load search on demand, follow a result and rebuild with a subdirectory base. |
| [Migration](migration/README.md) | Follow the converter example | Convert a companion source export and rebuild a native collection. |
| [API recipes](../docs/api/examples/README.md) | Copy a module into your installed ESM application | Core, a minimal browser UI, add-ons, snapshots, workers or storage. |

For repository commands, first run `npm ci` with Node 24 from a source checkout. Stop local preview servers with Ctrl+C, or use the root-scoped Astro stop command documented in that example. Source checkouts require repository access. Start with [installation](../docs/api/GETTING_STARTED.md) if you only have package tarballs.
