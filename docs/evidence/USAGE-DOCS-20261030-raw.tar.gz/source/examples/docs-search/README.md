# Search the usage guides

Find instructions for adding search to an application. The example searches selected sections from five practical guides: getting started, core usage, search add-ons, host integration and Astro.

## Run locally

From a source checkout, use Node 24 and npm:

```sh
npm ci
npm run pilot:ui
```

Open the printed HTTP URL. The command builds and installs a local package, bundles the browser/worker entries and serves only its demo assets. Stop the server with Ctrl+C. Use `--port 4175` when the default port is occupied.

## Try a search

1. Search `source provider` to find the guide to retaining original text.
2. Search `typed filters` to find metadata filtering and facets.
3. Search `module worker` to find worker setup.
4. Enter `unmatchedword` for an empty result, then edit the query to recover.
5. Choose a Category to narrow results; select All to clear it. Pagination keeps the complete total.
6. Open a result to read its guide. Open Inspector to see matching terms and scoring facts; Escape or Close returns to the results.

Tab moves through native controls and links. Return in the search field submits. Search/filter/page updates retain focus on the control used. The Inspector uses a native modal dialog.

## Advanced demo settings

Expand the settings to switch between exact terms and strict phrases, original-source reanalysis and stored offsets, or direct execution and one module worker. Changing these settings rebuilds the engine and preserves query text; filters and page reset. Destroy interface and Reinitialize search demonstrate cleanup and remounting.

The demo enables phrases, facets, snippets and Inspector explicitly. It keeps data in memory and opens no database. A worker failure does not retry mutations automatically; Reinitialize search creates a fresh engine from the guide collection.

## Add the interface to your own application

Copy [the minimal UI recipe](../../docs/api/examples/ui.mjs), provide a mounting element and import `@vmitsaras/raveldex/addons/ui/styles.css`. It indexes a record, maps its ID to a title/URL and returns a `dispose()` method. See [complete markup and initialization](../../docs/api/HOSTS.md#mount-a-minimal-search-form).

For snippets/highlights, select original-text or offset providers and the snippet add-on before creating the engine. For filters, select the filter/facet add-ons and declare your metadata fields. Keep display text as text; snippets are bounded excerpts, and result links open the full guide.
