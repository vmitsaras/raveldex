# Add search to Astro pages

Build and preview a static Astro site with on-demand search. The example has three indexed documentation pages and a draft excluded from search. You supply the records, titles and routes explicitly.

## Prepare artifacts

Use Node 24 and npm. Follow [build tarballs from a source checkout](../../docs/api/GETTING_STARTED.md#build-tarballs-from-a-source-checkout) first. This sets `RAVELDEX_REPOSITORY` and `RAVELDEX_ARTIFACTS` in the current shell and creates matching core/integration tarballs. In another terminal, set those variables to the actual absolute paths before continuing.

## Copy and install the fixture

Create an isolated directory so package installation and build outputs cannot modify the repository example. Resolve its physical path so the build and preview use the same root, including macOS temporary-directory aliases:

```sh
export RAVELDEX_EXAMPLE="$(mktemp -d "${TMPDIR:-/tmp}/raveldex-astro-example.XXXXXX")"
export RAVELDEX_EXAMPLE="$(cd "$RAVELDEX_EXAMPLE" && pwd -P)"
cp -R "$RAVELDEX_REPOSITORY/examples/astro/." "$RAVELDEX_EXAMPLE/"
printf '%s\n' '{"name":"raveldex-astro-example","private":true,"type":"module"}' > "$RAVELDEX_EXAMPLE/package.json"
npm --prefix "$RAVELDEX_EXAMPLE" install --ignore-scripts --no-audit --no-fund "$RAVELDEX_ARTIFACTS/core/vmitsaras-raveldex-0.1.0-rc.0.tgz" "$RAVELDEX_ARTIFACTS/astro/vmitsaras-raveldex-astro-0.1.0-rc.0.tgz" astro@7.3.2
```

Resolving Astro and its transitive dependencies needs registry access or an adequate npm cache. The paired core/integration are actual local tarballs, not source imports or workspace aliases. The optional framework peer is pinned here because the fixture uses the real build hook.

## Build and preview at the root

```sh
ASTRO_TELEMETRY_DISABLED=1 node "$RAVELDEX_EXAMPLE/node_modules/astro/bin/astro.mjs" build --root "$RAVELDEX_EXAMPLE"
ASTRO_TELEMETRY_DISABLED=1 node "$RAVELDEX_EXAMPLE/node_modules/astro/bin/astro.mjs" preview --background --root "$RAVELDEX_EXAMPLE" --host 127.0.0.1 --port 4321
```

Open the local URL printed by Astro, normally `http://127.0.0.1:4321/`. The explicit background flag keeps the server available after the command returns, including in agent environments. Keep it running during the check. Do not open `dist/index.html` with `file://`; search loads same-origin HTTP assets. `dist/raveldex/manifest.json` and its content-addressed source/display files should exist after a successful build.

After either preview session, stop only this fixture's registered server before rebuilding or finishing:

```sh
ASTRO_TELEMETRY_DISABLED=1 node "$RAVELDEX_EXAMPLE/node_modules/astro/bin/astro.mjs" preview stop --root "$RAVELDEX_EXAMPLE"
```

Do not use --force to replace an unrelated server. If the requested port is busy, use the actual URL reported by Astro.

## Rebuild for a subdirectory

Use the same base in both build and preview, otherwise preview's configured routes may disagree with generated asset URLs:

```sh
RAVELDEX_ASTRO_BASE=/docs/ ASTRO_TELEMETRY_DISABLED=1 node "$RAVELDEX_EXAMPLE/node_modules/astro/bin/astro.mjs" build --root "$RAVELDEX_EXAMPLE"
RAVELDEX_ASTRO_BASE=/docs/ ASTRO_TELEMETRY_DISABLED=1 node "$RAVELDEX_EXAMPLE/node_modules/astro/bin/astro.mjs" preview --background --root "$RAVELDEX_EXAMPLE" --host 127.0.0.1 --port 4321
```

Open `http://127.0.0.1:4321/docs/` (or the port Astro actually reports). No deployment is performed. The hook expects a static directory build and refuses collisions in its reserved artifact namespace; do not manually copy an old `raveldex/` namespace into the fresh build.

## What to try

1. Read the authored documentation links before opening search.
2. Activate **Load search data**: manifest/source load, while display data and UI stay deferred.
3. Activate **Open search**, search `atomic`, and follow **Atomic publication** to the real page. Search `marzipanprivate` to confirm the rendered draft is excluded.
4. Use the labeled search controls, pagination and Inspector. The UI uses native dialog/keyboard behavior, separate CSS and application-owned display records.
5. Inject the next search error, submit, then retry. **Close search** restores authored content; **Unload search data** disposes the owned runtime. Unload during a pending open must not revive a stale UI.
6. Repeat at `/docs/`; navigation, source/display requests and result URLs should retain that deployment base.

## Use the pattern in your application

Define the records you want indexed, configure the Astro hook and load the source manifest from your client module. Keep draft/private content out of the index allowlist. See [the Astro integration guide](../../docs/api/STATIC_ASTRO.md) for the public imports, configuration and loader lifecycle.

The example includes a `qualification.mjs` declaration for its native-snapshot test path. Leave native qualification out of ordinary source-based application setup; it is not a declaration you can reuse for a different application. The browser loads source snapshots and rebuilds them with its receiving analyzer.
