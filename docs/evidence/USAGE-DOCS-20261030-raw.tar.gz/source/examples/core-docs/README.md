# Search documentation from the terminal

Use the framework-independent core to index document sections and print ranked results. This example searches selected implementation-contract sections and returns the matching IDs, scores and total.

## Run

From a source checkout, use Node 24 and npm:

```sh
npm ci
npm run pilot:core -- 'atomic mutation'
```

The command compiles and installs a local core tarball into a temporary consumer. It prints that directory and the query results. The engine is disposed when the command finishes. It creates no browser UI or database.

## Search another term

Inside the printed consumer directory:

```sh
node run.mjs corpus.json judgments.json 'original source'
```

Queries use exact analyzed terms by default. Use the typed query shapes in [core usage](../../docs/api/CORE.md#query-shapes) for prefixes, fields, Boolean groups and metadata equality.

## Use your own records

Start from [the core recipe](../../docs/api/examples/core.mjs): define the schema, add your records and call `search`. Keep titles/URLs in your application and join them to returned IDs. Use `replace`, `remove` or `clear` to update the collection, then dispose the engine when finished.

For an interactive search example, use [the usage-guide browser demo](../docs-search/README.md).
