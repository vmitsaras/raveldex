from pathlib import Path
import json,hashlib,os
p=Path('/private/tmp/raveldex-rx7001-d5l7vtnp');root=Path('/Users/vasilis/Documents/GitHub/raveldex')
b=json.loads((p/'before-hashes.json').read_text());plan=json.loads((root/'docs/planning/roadmap.json').read_text());old=json.loads((p/'roadmap-before.json').read_text())
assert plan['milestones']==old['milestones']
assert [t for t in plan['tasks'] if t['id']!='RX-7001']==[t for t in old['tasks'] if t['id']!='RX-7001']
a=next(t for t in plan['tasks'] if t['id']=='RX-7001');c=next(t for t in old['tasks'] if t['id']=='RX-7001')
for k in ['dependsOn','acceptanceCriteria','verification','objective','affectedPaths']:assert a[k]==c[k],k
pages={f['path'] for f in json.loads((p/'pages-before.json').read_text())['files']}|{f['path'] for f in json.loads((root/'docs/_pages-manifest.json').read_text())['files']}
changed=[];unchanged=[]
for f,h in b.items():
 assert (root/f).is_file(),f
 (unchanged if hashlib.sha256((root/f).read_bytes()).hexdigest()==h else changed).append(f)
allowed={'CHANGELOG.md','README.md','IMPLEMENTATION_TASKS.md','ROADMAP.md','package.json','test/consumer/candidate.test.mjs','docs/_pages-manifest.json','docs/planning/roadmap.json','docs/api/README.md','docs/api/HOSTS.md','scripts/candidate-check.mjs','scripts/copy-ui-css.mjs','src/addons/ui/mounts.ts','PROJECT_CONTEXT.md','CODEX_HANDOFF.md','docs/specs/SEARCH_SOLUTIONS.md','docs/planning/SEARCH_SOLUTIONS_IMPLEMENTATION_PLAN.md'}|{'docs/'+f for f in pages}
assert not(set(changed)-allowed),set(changed)-allowed
current=set()
for directory,dirs,files in os.walk(root):
 dirs[:]=[d for d in dirs if d not in {'.git','node_modules','dist','.astro','.tmp','.candidate'}]
 for file in files:current.add(str((Path(directory)/file).relative_to(root)))
added=sorted(current-set(b));allowedNew={'src/addons/ui/dropdown.ts','src/addons/ui/dropdown.css','test/ui/dropdown-browser.test.mjs','test/ui/dropdown-fixture.mjs','test/ui/dropdown-worker.mjs','test/consumer/dropdown-types.ts','docs/specs/DROPDOWN.md'}
assert not [f for f in added if f not in allowedNew and not f.startswith('docs/evidence/RX-7001')],added
x={'kind':'raveldex-rx7001-source-audit-v1','status':'Pass','baselineFiles':len(b),'existingFilesUnchanged':len(unchanged),'changedExisting':changed,'added':added,'missingExisting':[],'other49TaskObjectsUnchanged':True,'all9MilestoneObjectsUnchanged':True,'selectedDependenciesAcceptanceVerificationPreserved':True,'lockfileUnchanged':'package-lock.json' in unchanged,'preserved':'Core/adapters/Astro/provider/native protocol sources, all earlier UI runtime except type-only mount-kind union, four installed starter source trees, frozen qualification fixtures and all earlier evidence have identical task-start hashes.','scope':'Task-start dirty-worktree hash baseline; does not attribute earlier uncommitted work to RX-7001.'}
(p/'scope-audit.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({k:v for k,v in x.items() if k not in ['added']},indent=2));print('new files',len(added))
