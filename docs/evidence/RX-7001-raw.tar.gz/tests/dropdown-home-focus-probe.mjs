import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
const directory = JSON.parse(await readFile('/private/tmp/raveldex-rx7001-d5l7vtnp/tests/initial-consumer-paths.json'))[0];
const server = createServer(async (request, response) => {
  const file = { '/': 'index.html', '/fixture.mjs': 'fixture.mjs', '/dropdown.css': 'dropdown.css' }[request.url];
  if (!file) { response.writeHead(404).end(); return; }
  response.setHeader('content-type', file.endsWith('.mjs') ? 'text/javascript' : file.endsWith('.css') ? 'text/css' : 'text/html');
  response.end(await readFile(join(directory, file)));
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
let browser;
try {
  browser = await chromium.launch({ channel: 'chrome', headless: true }); const page = await browser.newPage({ viewport: { width: 1100, height: 850 } });
  await page.goto('http://127.0.0.1:' + server.address().port); await page.waitForFunction(() => window.createDropdownFixture); await page.evaluate(() => window.createDropdownFixture());
  await page.evaluate(() => {
    window.keys = [];
    for (const type of ['keydown', 'keyup', 'focusin', 'focusout']) document.addEventListener(type, event => {
      window.keys.push({ type, key: event.key, prevented: event.defaultPrevented, documentFocused: document.hasFocus(), target: event.target.id,
        active: document.activeElement.id, selection: [event.target.selectionStart, event.target.selectionEnd],
        virtual: event.target.getAttribute?.('aria-activedescendant') });
    });
  });
  await page.bringToFront();
  const ordinary = page.locator('#outside-input'), field = page.locator('.raveldex-dropdown__input'), results = [];
  const snap = async name => results.push({ name, ...await field.evaluate(n => ({ field: { value: n.value, documentFocused: document.hasFocus(), selection: [n.selectionStart, n.selectionEnd], focused: n === document.activeElement, virtual: n.getAttribute('aria-activedescendant') }, ordinary: [document.getElementById('outside-input').selectionStart, document.getElementById('outside-input').selectionEnd] })) });
  await ordinary.fill('shared'); await ordinary.press('Home'); await ordinary.press('End');
  await page.evaluate(() => window.dropdownHarness.handle.search('shared')); await snap('searched without focus');
  await field.press('ArrowDown'); await snap('arrowDown'); await field.evaluate(n => n.setSelectionRange(n.value.length, n.value.length));
  await field.press('Shift+ArrowLeft'); await snap('shiftLeft'); await page.bringToFront(); await field.press('Home'); await snap('Home'); await field.press('End'); await snap('End');
  await field.evaluate(n => n.setSelectionRange(5, 6)); await page.keyboard.press('Home'); await snap('keyboardHome');
  const report = { browser: browser.version(), directory, results, events: await page.evaluate(() => window.keys), scope: 'Initial exact installed fixture bundle; native editing diagnosis only, not final regression evidence.' };
  await writeFile('/private/tmp/raveldex-rx7001-d5l7vtnp/tests/dropdown-home-focus-probe.json', JSON.stringify(report, null, 2) + '\n'); console.log(JSON.stringify(report, null, 2));
  await page.evaluate(() => window.cleanupDropdownFixtures());
} finally { await browser?.close(); await new Promise(resolve => server.close(resolve)); }
