import { webkit } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { writeFile } from 'node:fs/promises';
const server = createServer((request, response) => {
  response.setHeader('content-type', 'text/html; charset=utf-8');
  response.end(request.url === '/target/' ? '<!doctype html><html lang="en"><title>Native target</title><h1>Native target</h1></html>'
    : '<!doctype html><html lang="en"><title>Native controls</title><main><h1>Native controls</h1><label>First<input id="first"></label><button id="button">Action</button><a id="full" href="/target/">Full route</a><label>Last<input id="last"></label><div popover="manual" id="popup" role="grid"><div role="row"><div role="gridcell"><a id="link" tabindex="-1" href="/target/">Native result</a></div></div></div></main></html>');
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
let browser;
try {
  browser = await webkit.launch({ headless: true }); const context = await browser.newContext(); context.setDefaultTimeout(5000);
  const page = await context.newPage(), origin = 'http://127.0.0.1:' + server.address().port; await page.goto(origin); await page.bringToFront();
  const tabs = [];
  for (const chord of ['Tab', 'Alt+Tab']) {
    await page.locator('#first').focus(); const sequence = [];
    for (let i=0;i<5;i++) { await page.keyboard.press(chord); sequence.push(await page.evaluate(()=>({tag:document.activeElement.tagName,id:document.activeElement.id,hasFocus:document.hasFocus()}))); }
    tabs.push({chord,sequence});
  }
  const activation = [];
  for (const kind of ['middle','meta']) {
    await page.goto(origin); await page.bringToFront();
    await page.evaluate(()=>{ window.events=[]; for(const type of ['pointerdown','click','auxclick','contextmenu'])document.addEventListener(type,e=>{if(e.target.id==='link')window.events.push({type,button:e.button,meta:e.metaKey,ctrl:e.ctrlKey,trusted:e.isTrusted,prevented:e.defaultPrevented});});document.getElementById('popup').showPopover(); });
    const opened = page.waitForEvent('popup',{timeout:2000}).then(p=>p).catch(()=>null);
    await page.locator('#link').click(kind==='middle'?{button:'middle'}:{modifiers:['Meta']});
    const target = await opened; let targetURL;
    if(target){await target.waitForLoadState();targetURL=target.url();await target.close();}
    activation.push({kind,popup:!!target,targetURL,mainURL:page.url(),events:await page.evaluate(()=>window.events)});
  }
  const report={browser:browser.version(),tabs,activation,scope:'Plain native text fields/button/anchor and manual-popover grid; no Raveldex code, no OS/browser setting changes. Scripted input only.'};
  await writeFile('/private/tmp/raveldex-rx7001-d5l7vtnp/tests/webkit-native-baseline.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));await context.close();
}finally{await browser?.close();await new Promise(resolve=>server.close(resolve));}
