import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { writeFile } from 'node:fs/promises';
const browser = await chromium.launch({ channel: 'chrome', headless: true });
try {
  const page = await browser.newPage();
  await page.setContent('<!doctype html><html lang="en"><title>Native input keys</title><input id="ordinary"><input id="combo" role="combobox" aria-autocomplete="list" aria-haspopup="grid" aria-expanded="false">');
  const result = [];
  for (const selector of ['#ordinary', '#combo']) for (const selection of [[6, 6], [5, 6]]) {
    const field = page.locator(selector); await field.fill('shared');
    await field.evaluate((n, range) => n.setSelectionRange(...range), selection);
    const before = await field.evaluate(n => ({ value: n.value, selection: [n.selectionStart, n.selectionEnd] }));
    await field.press('Home'); const home = await field.evaluate(n => [n.selectionStart, n.selectionEnd]);
    await field.press('End'); const end = await field.evaluate(n => [n.selectionStart, n.selectionEnd]);
    result.push({ selector, before, home, end });
  }
  const report = { browser: browser.version(), result, scope: 'Plain native input behavior, no Raveldex script; matching selection preconditions test-harness diagnosis.' };
  await writeFile('/private/tmp/raveldex-rx7001-d5l7vtnp/tests/native-home-probe.json', JSON.stringify(report, null, 2) + '\n'); console.log(JSON.stringify(report, null, 2));
} finally { await browser.close(); }
