import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { writeFile } from 'node:fs/promises';
const browser = await chromium.launch({ channel: 'chrome', headless: true });
try {
  const result = [];
  for (const scrollable of [false, true]) for (const open of [false, true]) for (const activeHistory of [false, true]) {
    const page = await browser.newPage({ viewport: { width: 1100, height: 850 } });
    await page.setContent(`<!doctype html><html lang="en"><meta charset="utf-8"><title>Native popup keys</title><style>main{min-height:${scrollable ? 1500 : 0}px}[popover]{max-height:100px;overflow:auto}</style><body><main><form role="search"><label for="combo">Search<input type="text" id="combo" role="combobox" aria-autocomplete="list" aria-haspopup="grid" aria-expanded="${open}" aria-controls="grid"></label></form><label>Ordinary<input id="ordinary" type="text"></label><div id="grid" role="grid" popover="manual"><div role="row"><div role="gridcell" id="cell"><a href="#end" tabindex="-1">Alpha guide</a></div></div></div><p id="end">End</p></main></body></html>`);
    await page.bringToFront();
    if (open) await page.evaluate(() => document.getElementById('grid').showPopover());
    for (const selector of ['#ordinary', '#combo']) {
      const field = page.locator(selector); await field.fill('shared');
      if (selector === '#combo' && activeHistory) await field.evaluate(n => { n.setAttribute('aria-activedescendant', 'cell'); document.getElementById('cell').setAttribute('aria-selected', 'true'); n.removeAttribute('aria-activedescendant'); document.getElementById('cell').setAttribute('aria-selected', 'false'); });
      await field.evaluate(n => n.setSelectionRange(5, 6));
      await field.press('Home'); const home = await field.evaluate(n => ({ selection: [n.selectionStart, n.selectionEnd], focused: document.hasFocus(), scrollY }));
      await field.press('End'); const end = await field.evaluate(n => ({ selection: [n.selectionStart, n.selectionEnd], focused: document.hasFocus(), scrollY }));
      result.push({ scrollable, open, activeHistory, selector, home, end });
    }
    await page.close();
  }
  const report = { browser: browser.version(), result, scope: 'Plain native controls/manual popover; no Raveldex script or listener. Matches selection5..6 and records scroll/document focus.' };
  await writeFile('/private/tmp/raveldex-rx7001-d5l7vtnp/tests/native-popover-keys-probe.json', JSON.stringify(report, null, 2) + '\n'); console.log(JSON.stringify(report, null, 2));
} finally { await browser.close(); }
