RX-7001 installed dropdown browser handoff

Final identical frozen source/harness: 24/24 Pass in Chrome 156.0.8078.74, WebKit 26.5 and CI-selected Chromium 149.0.7827.55. Zero failures, skips or cancellations.

Source SHA-256:
- test/ui/dropdown-browser.test.mjs: b76779c02504277c5922d535e9f52877f2f2cf68c2e96595063e076044252905
- test/ui/dropdown-fixture.mjs: 8a1ff152604daae8f8c616a24ce136c391d2d8e9d578936bb1e59ac2f7245ca1
- test/ui/dropdown-worker.mjs: 423e0ce7cf3b03f9fa926bb7e9f581efb3ac6b40b000e252c6e09808254e0400
- src/addons/ui/dropdown.ts: 6518154660f1937749fc8ddc3b9a4da6e22a391947af373413e70b6dde380940
- src/addons/ui/dropdown.css: acef9af7c581dbaaf74eb365450d1540978321e3f1d0dee42fce41c31b1072be

Installed dropdown.js: 07965b187a0aeac5de26cc462cb329ff9a56253824fcb079352874819911ce1e

All real consumer copies match recorded fixture/source identities. Graph 19,719 minified / 7,468 gzip bytes; CSS 4,549 bytes. Byte quantities are not memory or latency measurements.

Evidence boundaries:
- Human AT/speech: Not run. Chrome/Chromium CDP native AX and page DOM/ARIA snapshots are separate supporting evidence.
- WebKit is Playwright WebKit 26.5, not native Safari. Plain Tab dismissal is tested; native Option/Alt+Tab is used for ordinary button/link traversal after a no-Raveldex baseline proved the recorded preference.
- Modified new-tab proof in recorded WebKit: Blocked, equally for native baseline and component. Middle click follows the native baseline same-page destination; no synthetic navigation or settings change.
- Physical IME/touch/mobile keyboard/actual browser zoom: Not run. Synthetic composition and 200% root-font text scaling are labeled.
- Memory/physical paint/latency: Not measured. Graph byte, serialized byte and DOM quantities only.

Case identities:
01. core-only idle mount and bounded native results expose a computed combobox/grid/link hierarchy (test/ui/dropdown-browser.test.mjs:155)
02. prefix/text modes and Unicode keep literal native membership and exact handoff query meaning (test/ui/dropdown-browser.test.mjs:196)
03. virtual arrows clamp, preserve raw input/focus and use stable current cell IDs without automatic selection (test/ui/dropdown-browser.test.mjs:218)
04. native editing and modifier combinations clear virtual selection without replacing text or activating links (test/ui/dropdown-browser.test.mjs:234)
05. Enter without a virtual selection searches; Enter on the current result follows its actual anchor (test/ui/dropdown-browser.test.mjs:263)
06. result anchors retain actual modified/new-tab and context-menu behavior (test/ui/dropdown-browser.test.mjs:272)
07. Escape preserves the field; Tab leaves normally and the separate full-results link remains reachable (test/ui/dropdown-browser.test.mjs:319)
08. composition suppresses interim submit/navigation and performs one committed native search (test/ui/dropdown-browser.test.mjs:340)
09. early arrows share pending work and retain only explicit first/last navigation intent (test/ui/dropdown-browser.test.mjs:372)
10. input edits, revision replacements and late ignored-abort replies cannot retain or revive stale active IDs (test/ui/dropdown-browser.test.mjs:385)
11. outside pointer and focus changes cancel pending programmatic presentation even when focus was already outside (test/ui/dropdown-browser.test.mjs:400)
12. native failures, malformed results, no-results and Clear retain deliberate recoverable feedback (test/ui/dropdown-browser.test.mjs:414)
13. public single-line refusal leaves earlier input intact; malformed/oversized values stay visible with no handoff (test/ui/dropdown-browser.test.mjs:457)
14. options are captured before DOM mutation and root ownership stays exclusive across UI presets (test/ui/dropdown-browser.test.mjs:476)
15. pending destruction restores exact authored Nodes and never disposes or revives its borrowed owner (test/ui/dropdown-browser.test.mjs:517)
16. authored fallback callbacks and abort-triggered replacements cannot erase newer mounts (test/ui/dropdown-browser.test.mjs:548)
17. native popover cancellation/closure and queued old toggles keep expansion and active references truthful (test/ui/dropdown-browser.test.mjs:574)
18. one popup per document uses independent state and a shared borrowed engine without disposing it (test/ui/dropdown-browser.test.mjs:584)
19. optional shortcut coordinates with modal, ignores native editing contexts and removes its owned listener (test/ui/dropdown-browser.test.mjs:597)
20. owned open/closed shadow focus stays inside; ancestor native dialog Escape dismisses only the dropdown first (test/ui/dropdown-browser.test.mjs:636)
21. real module-worker hits remain native and actual worker loss is visible without fallback (test/ui/dropdown-browser.test.mjs:682)
22. top-layer placement survives clipping/transform, viewport edges and active-cell scrolling with finite rendered growth (test/ui/dropdown-browser.test.mjs:692)
23. long RTL/dark/text-scaled and forced-color layouts retain controls, active indication and selected axe rules (test/ui/dropdown-browser.test.mjs:735)
24. a short viewport with no usable row retains truthful totals and an accessible full-results recovery without auto-reopening (test/ui/dropdown-browser.test.mjs:766)

Raw final reports:
- /private/tmp/raveldex-rx7001-d5l7vtnp/tests/final-chrome.json and /private/tmp/raveldex-rx7001-d5l7vtnp/tests/final-chrome.log (6858.269958 ms)
- /private/tmp/raveldex-rx7001-d5l7vtnp/tests/final-webkit.json and /private/tmp/raveldex-rx7001-d5l7vtnp/tests/final-webkit.log (18558.387375 ms)
- /private/tmp/raveldex-rx7001-d5l7vtnp/tests/final-chromium-ci.json and /private/tmp/raveldex-rx7001-d5l7vtnp/tests/final-chromium-ci.log (4659.382084 ms)

Earlier runs and focused native diagnostics remain in this directory. The JSON handoff contains exact commands, source/copy identities, platform baselines, defect classifications and limitations. No root build/clean, dependency/browser download, remote action or commit was performed by this subagent. All own browser/server test processes finished.
