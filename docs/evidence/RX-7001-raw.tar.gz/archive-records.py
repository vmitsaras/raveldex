from pathlib import Path
import json,gzip,tarfile,shutil,hashlib
p=Path('/private/tmp/raveldex-rx7001-d5l7vtnp');e=Path('/Users/vasilis/Documents/GitHub/raveldex/docs/evidence')
summary=json.loads((p/'tests/handoff-summary.json').read_text())
final=Path(summary['runs'][0]['consumer']['directory'])/'vmitsaras-raveldex-0.1.0-rc.0.tgz'
assert hashlib.sha256(final.read_bytes()).hexdigest()==summary['runs'][0]['package']['sha256']
(p/'final-packages').mkdir(exist_ok=True);shutil.copyfile(final,p/'final-packages/final-browser-package.tgz')
shutil.copyfile(p/'candidate-final/vmitsaras-raveldex-0.1.0-rc.0.tgz',p/'final-packages/candidate-prose-metadata-snapshot.tgz')
logs={'integration-check.log':'integration-check.log.gz','site/run.log':'site.log.gz','pages-final.log':'pages.log.gz','jekyll.log':'jekyll.log.gz','isolated-timeout-rerun-approved.log':'isolated-regressions.log.gz','synchronized-check.log':'synchronized-check.log.gz','pages-build.log':'pages-build.log.gz'}
for a,b in logs.items():
 if (p/a).is_file():(e/f'RX-7001-{b}').write_bytes(gzip.compress((p/a).read_bytes(),mtime=0))
selected=[]
for d in ['tests','review','platform','site','baseline','final-source','final-packages']:
 selected.extend(f for f in (p/d).rglob('*') if f.is_file())
selected.extend(f for f in p.glob('*') if f.is_file() and f.suffix in {'.json','.log','.py','.mjs'})
selected.append(p/'candidate-final/candidate-report.json')
with tarfile.open(e/'RX-7001-raw.tar.gz','w:gz') as tar:
 for f in sorted(set(selected)):tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
print('Archived',len(set(selected)),'raw artifacts including exact final sources and both identified private packages.')
