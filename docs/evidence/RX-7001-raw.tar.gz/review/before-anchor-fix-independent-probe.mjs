import { build } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/esbuild/lib/main.js';
import { chromium, webkit } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { release, arch } from 'node:os';

const root = '/Users/vasilis/Documents/GitHub/raveldex';
const directory = '/private/tmp/raveldex-rx7001-d5l7vtnp/review';
const phase = process.argv[2] ?? 'initial';
await build({ stdin: { contents: `export {mountRaveldexDropdown} from '${root}/src/addons/ui/dropdown.ts'; export {createRaveldex} from '${root}/dist/index.js';`, resolveDir: root },
  bundle: true, platform: 'browser', format: 'esm', outfile: directory + '/probe.js', logLevel: 'silent' });
const css = await readFile(root + '/src/addons/ui/dropdown.css', 'utf8');
const server = createServer(async (request, response) => {
  if (request.url === '/probe.js') { response.setHeader('content-type', 'text/javascript'); response.end(await readFile(directory + '/probe.js')); return; }
  response.setHeader('content-type', 'text/html'); response.end(`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Independent dropdown review</title><style>${css}</style><body><main><h1>Review</h1><button id="outside">Outside</button></main></body></html>`);
});
await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
const report = { kind: 'raveldex-rx7001-independent-probe-v1', phase, environment: { node: process.version, os: release(), arch: arch() },
  scope: 'Source-bundled optional UI with existing compiled genuine core; separate from installed-consumer, human AT, physical-input or real-zoom proof.', engines: [] };
try {
  for (const [name, type] of [['chrome', chromium], ['webkit', webkit]]) {
    let browser, page;
    const entry = { name, observations: [] }; report.engines.push(entry);
    try {
      browser = await type.launch({ ...(name === 'chrome' ? { channel: 'chrome' } : {}), headless: true, timeout: 20000 }); entry.version = browser.version();
      page = await browser.newPage({ viewport: { width: 640, height: 480 } }); page.setDefaultTimeout(10000);
      await page.goto(`http://127.0.0.1:${server.address().port}/`);
      entry.observations = await page.evaluate(async () => {
        const { mountRaveldexDropdown, createRaveldex } = await import('/probe.js');
        const output = [], check = (value, message) => { if (!value) throw Error(message); };
        window.reviewOutput = output;
        const make = async (extra = {}) => {
          const engine = createRaveldex({ schema: { text: { body: {} } } });
          await engine.addMany(['a','b','c'].map(id => ({ id, text: { body: 'alpha' } })));
          const host = document.createElement('section'), root = document.createElement('div'), original = document.createTextNode('Authored browse'); root.append(original); host.append(root); document.querySelector('main').append(host);
          let calls = 0;
          const state = { onAbort: null, hold: false, releases: [], entered: null };
          const borrowed = { ...engine, async search(query, options) {
            calls++; options.signal?.addEventListener('abort', () => state.onAbort?.(), { once: true });
            const held = state.hold; state.hold = false;
            const { signal, ...withoutSignal } = options; void signal;
            const result = await engine.search(query, withoutSignal);
            if (held) await new Promise(resolve => { state.releases.push(resolve); state.entered?.(); });
            return result;
          } };
          const handle = mountRaveldexDropdown({ root, engine: borrowed, documents: ['a','b','c'].map(id => ({ id, title: 'Alpha ' + id, url: '/guide/' + id + '/' })),
            fullResults: { url: '/search/?keep=1#results' }, maxResults: 2, debounceMs: 0, ...extra });
          const input = root.querySelector('[role=combobox]'), popup = root.querySelector('[role=grid]');
          return { root, host, original, engine, handle, input, popup, state, calls: () => calls, async cleanup() { state.onAbort = null; handle.destroy(); for (const release of state.releases.splice(0)) release(); check(root.firstChild === original, 'original node identity'); await engine.dispose(); host.remove(); } };
        };
        const state = f => ({ expanded: f.input.getAttribute('aria-expanded'), active: f.input.getAttribute('aria-activedescendant'), visible: f.popup.matches(':popover-open'), rows: f.popup.querySelectorAll('[role=row]').length });
        {
          const f = await make(); f.popup.addEventListener('beforetoggle', event => { if (event.newState === 'open') event.preventDefault(); }, { once: true });
          await f.handle.search('alpha'); const observed = state(f);
          check(!observed.visible && observed.expanded === 'false' && !observed.active, 'canceled popover show leaves coherent collapsed state');
          output.push({ name: 'canceled native opening', status: 'Pass', observed }); await f.cleanup();
        }
        {
          const f = await make(); f.popup.addEventListener('beforetoggle', event => { if (event.newState === 'open') f.handle.destroy(); }, { once: true });
          await f.handle.search('alpha'); const observed = { restored: f.root.firstChild === f.original, visible: f.popup.matches(':popover-open'), connected: f.popup.isConnected };
          check(observed.restored && !observed.visible && !observed.connected, 'opening callback destroy leaves no orphan');
          check((await f.engine.search('alpha')).total === 3, 'UI did not dispose borrowed owner');
          output.push({ name: 'native opening callback destroy', status: 'Pass', observed }); await f.cleanup();
        }
        {
          const f = await make(); await f.handle.search('alpha'); f.input.focus();
          f.input.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true, cancelable: true }));
          check(Boolean(f.input.getAttribute('aria-activedescendant')), 'initial virtual active cell exists');
          f.popup.hidePopover();
          const immediately = state(f);
          f.handle.open(); await Promise.resolve(); await Promise.resolve(); await new Promise(resolve => setTimeout(resolve, 60));
          const observed = state(f); check(observed.visible && observed.expanded === 'true' && !observed.active, 'queued old native close preserves fresh reopen');
          output.push({ name: 'raw native hide then same-task reopen', status: 'Pass', immediately, observed }); await f.cleanup();
        }
        {
          const f = await make(); await f.handle.search('alpha'); f.input.focus();
          f.input.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true, cancelable: true }));
          const before = f.input.getAttribute('aria-activedescendant');
          const event = new KeyboardEvent('keydown', { key: 'Home', bubbles: true, cancelable: true }); f.input.dispatchEvent(event);
          const observed = { before, after: f.input.getAttribute('aria-activedescendant'), defaultPrevented: event.defaultPrevented, focus: document.activeElement === f.input };
          check(observed.before && !observed.after && !observed.defaultPrevented && observed.focus, 'native editing removes virtual selection without prevention');
          output.push({ name: 'editing clears active cell before input event', status: 'Pass', observed }); await f.cleanup();
        }
        {
          const f = await make(); let reached, replacement;
          const entered = new Promise(resolve => { reached = resolve; }); f.state.entered = reached; f.state.hold = true;
          const old = f.handle.search('alpha'); await entered;
          f.state.onAbort = () => { f.state.onAbort = null; replacement = f.handle.search('alpha'); };
          f.handle.clear(); await replacement;
          const observed = { ...state(f), value: f.input.value, state: f.root.querySelector('.raveldex-dropdown').dataset.state, calls: f.calls() };
          for (const release of f.state.releases.splice(0)) release(); await old;
          check(observed.visible && observed.expanded === 'true' && observed.rows === 2 && observed.state === 'results', 'clear abort callback retains replacement search');
          output.push({ name: 'clear abort callback replacement search', status: 'Pass', observed }); await f.cleanup();
        }
        for (const action of ['close', 'Tab', 'clear']) {
          const f = await make(); f.input.focus(); f.input.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
          f.input.value = 'alp'; f.input.dispatchEvent(new InputEvent('input', { bubbles: true, isComposing: true, inputType: 'insertCompositionText' }));
          const before = f.calls();
          if (action === 'Tab') f.input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true }));
          else f.handle[action]();
          f.input.value = 'alpha'; f.input.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: 'alpha' }));
          f.input.dispatchEvent(new InputEvent('input', { bubbles: true, isComposing: false, inputType: 'insertText' }));
          await new Promise(resolve => setTimeout(resolve, 30));
          const afterSuppressedCommit = f.calls();
          f.handle.open(); await f.handle.search(); const afterOpen = { ...state(f), calls: f.calls(), state: f.root.querySelector('.raveldex-dropdown').dataset.state };
          f.input.value = 'alpha '; f.input.dispatchEvent(new InputEvent('input', { bubbles: true, isComposing: false, inputType: 'insertText' }));
          await f.handle.search(); const afterEdit = { ...state(f), calls: f.calls(), state: f.root.querySelector('.raveldex-dropdown').dataset.state };
          const observation = { name: 'suppressed composition resumes after ' + action, status: 'Observed', before, afterSuppressedCommit, afterOpen, afterEdit }; output.push(observation);
          try { check(before === 0 && afterSuppressedCommit === 0 && afterOpen.calls === 1 && afterOpen.visible && afterEdit.calls === 2 && afterEdit.visible && afterEdit.state === 'results', 'suppressed composition permits explicit reopen and ordinary edit'); observation.status = 'Pass'; }
          finally { await f.cleanup(); }
        }
        {
          const f = await make(); await f.handle.search('alpha'); f.input.focus();
          const dialog = document.createElement('dialog'), button = document.createElement('button'); button.textContent = 'Close foreign'; dialog.append(button); document.body.append(dialog);
          const status = () => f.root.querySelector('[role=status]').textContent;
          const before = status(); dialog.showModal(); button.focus();
          const during = { ...state(f), status: status(), busy: f.root.querySelector('.raveldex-dropdown').getAttribute('aria-busy') };
          dialog.close(); await new Promise(resolve => setTimeout(resolve, 20));
          const after = { ...state(f), status: status(), focus: document.activeElement === f.input, state: f.root.querySelector('.raveldex-dropdown').dataset.state };
          const observation = { name: 'actual foreign native dialog dismisses obsolete feedback', status: 'Observed', before, during, after }; output.push(observation);
          try { check(!after.visible && !after.active && after.rows === 0 && !after.status.includes('Showing'), 'foreign native dialog closure must not retain obsolete result counts'); observation.status = 'Pass'; }
          finally { await f.cleanup(); dialog.remove(); }
        }
        return output;
      });
      entry.status = 'Pass'; await page.close();
    } catch (error) { entry.status = 'Fail'; entry.failure = { message: error.message, stack: error.stack }; if (page) entry.observations = await page.evaluate(() => window.reviewOutput ?? []).catch(() => []); process.exitCode = 1; }
    finally { await browser?.close(); }
  }
  report.status = report.engines.every(entry => entry.status === 'Pass') ? 'Pass' : 'Fail';
} finally { await new Promise(resolve => server.close(resolve)); }
report.sourceHashes = {};
for (const path of ['src/addons/ui/dropdown.ts', 'src/addons/ui/dropdown.css', 'src/addons/ui/mounts.ts', 'docs/specs/DROPDOWN.md']) report.sourceHashes[path] = createHash('sha256').update(await readFile(root + '/' + path)).digest('hex');
await writeFile(directory + '/' + phase + '-independent.json', JSON.stringify(report, null, 2) + '\n'); console.log(JSON.stringify(report, null, 2));
