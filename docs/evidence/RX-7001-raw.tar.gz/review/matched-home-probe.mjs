import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
const folder = '/private/tmp/raveldex-rx7001-d5l7vtnp';
const directory = JSON.parse(await readFile(folder + '/tests/initial-consumer-paths.json'))[0];
const server = createServer(async (request, response) => {
  const file = { '/':'index.html', '/fixture.mjs':'fixture.mjs', '/dropdown.css':'dropdown.css' }[request.url];
  if (!file) { response.writeHead(404).end(); return; }
  response.setHeader('content-type', file.endsWith('.mjs') ? 'text/javascript' : file.endsWith('.css') ? 'text/css' : 'text/html'); response.end(await readFile(join(directory,file)));
});
await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
let browser;
const report = { kind:'raveldex-rx7001-matched-native-editing-diagnostic-v1', directory, observations:[], scope:'Exact initial installed fixture diagnosis; source is historical first dropdown bundle, not final implementation qualification. Scripted actual Chrome keys, visibility/layout/document focus recorded. No custom caret behavior is introduced.' };
try {
  browser=await chromium.launch({channel:'chrome',headless:true,timeout:20000}); report.browser=browser.version();
  const page=await browser.newPage({viewport:{width:1100,height:850}});page.setDefaultTimeout(10000);
  await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>window.createDropdownFixture);await page.evaluate(()=>window.createDropdownFixture());
  await page.evaluate(()=>{
    document.getElementById('clip-host').style.cssText='position:fixed;top:100px;left:10px;width:400px';
    document.getElementById('outside-input').style.cssText='position:fixed;top:150px;left:700px;width:180px';window.scrollTo(0,0);
    window.homeTrace=[];for(const type of ['keydown','keyup'])document.addEventListener(type,event=>window.homeTrace.push({type,key:event.key,defaultPrevented:event.defaultPrevented,target:event.target.id,documentFocus:document.hasFocus(),selection:[event.target.selectionStart,event.target.selectionEnd],scroll:[scrollX,scrollY]}));
  });
  const field=page.locator('.raveldex-dropdown__input'),ordinary=page.locator('#outside-input');
  const snapshot=async locator=>locator.evaluate(n=>{const r=n.getBoundingClientRect(),s=getComputedStyle(n);return{value:n.value,selection:[n.selectionStart,n.selectionEnd,n.selectionDirection],documentFocus:document.hasFocus(),active:n===document.activeElement,rect:{x:r.x,y:r.y,width:r.width,height:r.height},viewport:[innerWidth,innerHeight],visible:r.top>=0&&r.bottom<=innerHeight&&r.left>=0&&r.right<=innerWidth,scroll:[scrollX,scrollY],role:n.getAttribute('role'),activeDescendant:n.getAttribute('aria-activedescendant'),style:{font:s.font,direction:s.direction,display:s.display,visibility:s.visibility},disabled:n.disabled,readOnly:n.readOnly};});
  const run=async(name,locator,selection,key)=>{
    await locator.fill('shared');await locator.focus();await locator.evaluate((n,range)=>n.setSelectionRange(...range),selection);await page.bringToFront();
    const before=await snapshot(locator);await locator.press(key);const after=await snapshot(locator);report.observations.push({name,key,before,after});
  };
  for(const selection of [[6,6],[5,6]])for(const key of ['Home','End'])await run('ordinary in live fixture',ordinary,selection,key);
  await page.evaluate(()=>window.dropdownHarness.handle.search('shared'));await field.press('ArrowDown');await field.press('ArrowRight');
  for(const selection of [[6,6],[5,6]])for(const key of ['Home','End'])await run('live dropdown after virtual navigation',field,selection,key);
  await page.evaluate(()=>{const h=window.dropdownHarness,markup=h.root.innerHTML;h.handle.destroy();h.root.innerHTML=markup;});
  const clone=page.locator('.raveldex-dropdown__input');
  await page.evaluate(()=>{const input=document.querySelector('.raveldex-dropdown__input');input.removeAttribute('aria-activedescendant');const popup=document.querySelector('[popover]');if(popup)popup.showPopover();});
  for(const selection of [[6,6],[5,6]])for(const key of ['Home','End'])await run('static cloned native combobox with retired UI listeners',clone,selection,key);
  for(const selection of [[6,6],[5,6]])for(const key of ['Home','End'])await run('ordinary after UI listener retirement',ordinary,selection,key);
  await page.evaluate(()=>{const grid=document.querySelector('[popover]');if(grid?.matches(':popover-open'))grid.hidePopover();});
  for(const selection of [[6,6],[5,6]])for(const key of ['Home','End'])await run('static cloned combo with native popover closed',clone,selection,key);
  report.events=await page.evaluate(()=>window.homeTrace);await page.evaluate(()=>window.cleanupDropdownFixtures()); report.status='Observed';
}catch(error){report.status='Fail';report.failure={message:error.message,stack:error.stack};process.exitCode=1;}
finally{await browser?.close();await new Promise(resolve=>server.close(resolve));}
report.bundleSHA256=createHash('sha256').update(await readFile(join(directory,'fixture.mjs'))).digest('hex');
await writeFile(folder+'/review/matched-home-probe.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
