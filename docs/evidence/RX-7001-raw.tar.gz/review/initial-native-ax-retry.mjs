import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
const directory = '/private/tmp/raveldex-rx7001-d5l7vtnp/review', root = '/Users/vasilis/Documents/GitHub/raveldex';
const phase = process.argv[2] ?? 'initial';
const css = await readFile(root + '/src/addons/ui/dropdown.css', 'utf8');
const server = createServer(async (request, response) => {
  if (request.url === '/probe.js') { response.setHeader('content-type', 'text/javascript'); response.end(await readFile(directory + '/probe.js')); return; }
  response.setHeader('content-type', 'text/html'); response.end(`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Native AX dropdown review</title><style>${css}</style><body><main><h1>Native AX review</h1><button id="before">Before</button><div id="root">Authored fallback</div><button id="after">After</button></main><script type="module">import * as reviewModule from '/probe.js';window.reviewModule=reviewModule;</script></body></html>`);
});
await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
let browser;
const report = { kind: 'raveldex-rx7001-native-chrome-AX-v1', phase, scope: 'Actual Chrome CDP Accessibility tree and scripted native Tab/Arrow/Escape. Source-bundled UI with genuine compiled native engine, not fresh installed consumer or human speech.', observations: [] };
try {
  browser = await chromium.launch({ channel: 'chrome', headless: true, timeout: 20000 }); report.browser = browser.version();
  const page = await browser.newPage({ viewport: { width: 960, height: 720 } }); page.setDefaultTimeout(12000);
  await page.goto(`http://127.0.0.1:${server.address().port}/`); await page.waitForFunction(() => !!window.reviewModule);
  await page.evaluate(async () => {
    const { createRaveldex, mountRaveldexDropdown } = window.reviewModule;
    const engine = createRaveldex({ schema: { text: { body: {} } } }); await engine.addMany(['a','b','c'].map(id => ({ id, text: { body: 'alpha' } })));
    const root = document.getElementById('root'), original = [...root.childNodes];
    const handle = mountRaveldexDropdown({ root, engine, documents: ['a','b','c'].map(id => ({ id, title: 'Alpha ' + id, url: '/guide/' + id + '/' })),
      maxResults: 2, debounceMs: 0, fullResults: { url: '/search/?keep=1#results' } });
    window.reviewCase = { root, engine, handle, original };
  });
  const cdp = await page.context().newCDPSession(page); await cdp.send('Accessibility.enable');
  const capture = async name => {
    const native = await cdp.send('Accessibility.getFullAXTree');
    const selected = native.nodes.filter(node => !node.ignored && ['combobox','grid','row','gridcell','link','status','search','button'].includes(node.role?.value));
    const observation = { name, nativeNodes: selected, DOM: await page.evaluate(() => {
      const root = window.reviewCase.root, input = root.querySelector('[role=combobox]'), grid = root.querySelector('[role=grid]');
      return { expanded: input.getAttribute('aria-expanded'), controls: input.getAttribute('aria-controls'), active: input.getAttribute('aria-activedescendant'), inputDOMFocus: document.activeElement === input,
        popup: grid.matches(':popover-open'), cellIDs: [...grid.querySelectorAll('[role=gridcell]')].map(n => n.id), selectedIDs: [...grid.querySelectorAll('[aria-selected=true]')].map(n => n.id), status: root.querySelector('[role=status]').textContent };
    }) };
    report.observations.push(observation); return observation;
  };
  const idle = await capture('idle');
  assert.equal(idle.DOM.expanded, 'false'); assert.equal(idle.nativeNodes.filter(n => n.role.value === 'combobox').length, 1);
  assert.equal(idle.nativeNodes.some(n => n.role.value === 'grid'), false);
  const input = page.getByRole('combobox'); await input.fill('alpha'); await input.press('Enter');
  await page.waitForFunction(() => window.reviewCase.root.querySelector('[role=grid]').matches(':popover-open'));
  await input.press('ArrowDown'); const active = await capture('active result');
  assert.equal(active.DOM.inputDOMFocus, true); assert.equal(active.DOM.expanded, 'true'); assert.ok(active.DOM.active);
  assert.deepEqual(active.DOM.selectedIDs, [active.DOM.active]);
  const combo = active.nativeNodes.find(n => n.role.value === 'combobox');
  assert.equal(combo.properties.find(p => p.name === 'expanded').value.value, true);
  const related = combo.properties.find(p => p.name === 'activedescendant'); assert.ok(related?.value.relatedNodes?.length);
  assert.equal(related.value.relatedNodes[0].idref, active.DOM.active);
  assert.equal(active.nativeNodes.filter(n => n.role.value === 'grid').length, 1);
  assert.equal(active.nativeNodes.filter(n => n.role.value === 'row').length, 2);
  assert.equal(active.nativeNodes.filter(n => n.role.value === 'gridcell').length, 2);
  assert.ok(active.nativeNodes.some(n => n.role.value === 'link' && n.name.value === 'Alpha a'));
  await input.press('Escape'); const collapsed = await capture('native Escape collapsed');
  assert.equal(collapsed.DOM.expanded, 'false'); assert.equal(collapsed.DOM.active, null); assert.equal(collapsed.DOM.inputDOMFocus, true);
  assert.equal(collapsed.nativeNodes.some(n => n.role.value === 'grid'), false);
  await page.evaluate(async () => { await window.reviewCase.engine.dispose(); await window.reviewCase.handle.search('alpha'); });
  const retry = page.getByRole('button', { name: 'Retry search', exact: true }); await retry.waitFor(); await input.focus();
  const traversal = [];
  for (let i = 0; i < 3; i++) {
    await page.keyboard.press('Tab'); traversal.push(await page.evaluate(() => ({ tag: document.activeElement.tagName, text: document.activeElement.textContent, retryVisible: !document.querySelector('.raveldex-dropdown__retry').hidden })));
  }
  assert.equal(traversal.at(-1).text, 'Retry search'); assert.ok(traversal.every(x => x.retryVisible));
  await page.keyboard.press('Enter'); await retry.waitFor();
  const recovery = await page.evaluate(() => ({ inputDOMFocus: document.activeElement === document.querySelector('[role=combobox]'), state: document.querySelector('.raveldex-dropdown').dataset.state }));
  assert.deepEqual(recovery, { inputDOMFocus: true, state: 'error' });
  report.observations.push({ name: 'native keyboard Retry traversal and activation', traversal, recovery, note: 'Real disposed-engine error remains explicit after retry; no fabricated success.' });
  for (let i = 0; i < 3; i++) await page.keyboard.press('Tab');
  const clearBefore = await page.evaluate(() => ({ tag: document.activeElement.tagName, text: document.activeElement.textContent }));
  await page.evaluate(() => window.reviewCase.handle.clear());
  const clearAfter = await page.evaluate(() => ({ tag: document.activeElement.tagName, text: document.activeElement.textContent, inputFocused: document.activeElement === document.querySelector('[role=combobox]'), state: document.querySelector('.raveldex-dropdown').dataset.state }));
  report.observations.push({ name: 'programmatic clear while Retry owns focus', before: clearBefore, after: clearAfter, status: 'Observed only; evaluate against focus contract' });
  await page.evaluate(() => { window.reviewCase.handle.destroy(); });
  const destroyed = await capture('destroy restored authored DOM'); assert.equal(destroyed.nativeNodes.some(n => ['combobox','grid','gridcell'].includes(n.role.value)), false);
  report.status = 'Pass';
} catch (error) { report.status = 'Fail'; report.failure = { message: error.message, stack: error.stack }; process.exitCode = 1; }
finally { await browser?.close(); await new Promise(resolve => server.close(resolve)); }
report.bundleSHA256 = createHash('sha256').update(await readFile(directory + '/probe.js')).digest('hex');
report.sourceHashes = JSON.parse(await readFile(directory + '/initial-independent.json', 'utf8')).sourceHashes;
await writeFile(directory + '/' + phase + '-native-AX.json', JSON.stringify(report, null, 2) + '\n'); console.log(JSON.stringify(report, null, 2));
