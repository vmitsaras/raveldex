import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { release, arch } from 'node:os';
import { chromium, webkit } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
const directory = new URL('./', import.meta.url);
const report = { environment: { node: process.version, os: release(), arch: arch() }, engines: [],
  method: 'Exact installed browser previews from approved generated Pages inventory. Element counts, serialized UTF-8 outerHTML and network request counts are observed work/output, never retained/peak memory, latency or physical paint. WebKit is Playwright WebKit, not Safari.',
  limitations: ['Finite seven/six-page data only; no universal capacity or performance promise.', 'Scripted keyboard, not human or physical input.'] };
const origin = 'http://127.0.0.1:4188/raveldex/examples/';
const root = '/Users/vasilis/Documents/GitHub/raveldex/';
const snapshot = async page => page.locator('.raveldex-inline').evaluate(node => ({
  elements: node.querySelectorAll('*').length, outerHTMLBytes: new TextEncoder().encode(node.outerHTML).length,
  textUTF16: node.textContent.length, results: node.querySelectorAll('[data-raveldex-inline-result]').length,
  IDs: [...node.querySelectorAll('[data-raveldex-inline-result]')].map(n => n.dataset.raveldexInlineResult),
  marks: node.querySelectorAll('mark').length, sections: node.querySelectorAll('.raveldex-inline__section').length,
  status: node.querySelector('.raveldex-inline__status').textContent,
}));
try {
for (const [name, engine] of [['chrome', chromium], ['webkit', webkit]]) {
  const browser = await engine.launch({ ...(name === 'chrome' ? { channel: 'chrome' } : {}), headless: true, timeout: 20000 });
  const entry = { name, version: browser.version(), surfaces: [] }; report.engines.push(entry);
  try {
  for (const family of ['inline', 'modal']) {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 }, reducedMotion: 'reduce' }); page.setDefaultTimeout(12000);
    const errors = [], contentRequests = []; page.on('pageerror', error => errors.push(String(error)));
    page.on('request', req => { if(req.url().endsWith('/content.json')) contentRequests.push(req.url()); });
    await page.goto(origin + family + '-preview/');
    const sample = { family, stages: [] }; entry.surfaces.push(sample);
    if (family === 'modal') { assert.equal(contentRequests.length, 0); sample.beforeActivationDataRequests=0; await page.getByRole('button',{name:'Search documentation',exact:true}).click(); }
    const input = page.getByRole('searchbox', { name: family === 'inline' ? 'Search walking guides' : 'Search the workshop guide', exact: true }); await input.waitFor();
    sample.stages.push({ name:'idle', ...await snapshot(page) });
    const total = family === 'inline' ? 7 : 6;
    await input.fill(family === 'inline' ? 'walking guide' : 'workshop'); await input.press('Enter');
    await page.locator('.raveldex-inline__status').filter({hasText:`${total} results. Showing 3.`}).waitFor();
    sample.stages.push({ name:'first batch', ...await snapshot(page) });
    await page.getByRole('button',{name:'Load more',exact:true}).click();
    await page.locator('.raveldex-inline__status').filter({hasText:`${total} results. Showing 6.`}).waitFor();
    sample.stages.push({ name:'render cap', ...await snapshot(page) });
    const IDs = [...sample.stages.at(-1).IDs];
    if(family === 'inline') {
      await page.getByRole('button',{name:'Next results',exact:true}).click();
      await page.locator('.raveldex-inline__page-summary').filter({hasText:'7–7 of 7'}).waitFor();
      sample.stages.push({ name:'bounded next page', ...await snapshot(page) }); IDs.push(...sample.stages.at(-1).IDs);
    }
    assert.deepEqual([...new Set(IDs)].sort(), (family==='inline'?['getting-started','packing','weather','access','maps','symbols','care']:['first-visit','booking','sewing','woodworking','access','directions']).sort());
    sample.completeIDs=IDs;
    await input.fill(family==='inline'?'weather':'bobbin'); await input.press('Enter');
    await page.locator('.raveldex-inline__status').filter({hasText:'1 result. Showing 1.'}).waitFor();
    sample.stages.push({ name:'one matching page', ...await snapshot(page) });
    assert.deepEqual(sample.stages.at(-1).IDs,[family==='inline'?'weather':'sewing']); assert.ok(sample.stages.at(-1).marks>0);
    if(family==='modal') {
      const anchor=page.getByRole('link',{name:'Thread the machine',exact:true}); await anchor.waitFor();
      sample.sectionURL=await anchor.getAttribute('href'); assert.ok(sample.sectionURL.endsWith('#threading-100%25'));
    }
    await input.fill('zzzzmissing'); await input.press('Enter'); await page.locator('.raveldex-inline__status').filter({hasText:'No results.'}).waitFor();
    sample.stages.push({ name:'no results', ...await snapshot(page) }); assert.equal(sample.stages.at(-1).results,0);
    await page.getByRole('button',{name:'Clear',exact:true}).click(); await page.locator('.raveldex-inline__status').filter({hasText:/Enter a/}).waitFor();
    sample.stages.push({ name:'cleared', ...await snapshot(page) });
    if(family==='modal') { await input.fill('bobbin'); await input.press('Enter'); await page.getByRole('link',{name:'Thread the machine',exact:true}).waitFor(); }
    else { await input.fill('weather'); await input.press('Enter'); await page.locator('.raveldex-inline__status').filter({hasText:'1 result. Showing 1.'}).waitFor(); }
    await page.screenshot({path:new URL(`${name}-${family}-desktop.png`,directory).pathname});
    await page.setViewportSize({width:320,height:568});
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
    await page.screenshot({path:new URL(`${name}-${family}-320.png`,directory).pathname});
    sample.contentRequests=contentRequests.length; assert.equal(contentRequests.length,1); assert.deepEqual(errors,[]); sample.pageErrors=errors;
    sample.reducedMotion=await page.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches); assert.equal(sample.reducedMotion,true);
    if(family==='modal') {
      await page.getByRole('button',{name:'Close search',exact:true}).click();
      assert.equal(await page.getByRole('button',{name:'Search documentation',exact:true}).evaluate(n=>n===n.ownerDocument.activeElement),true);
      await page.getByRole('button',{name:'Search documentation',exact:true}).click();
      assert.equal(await input.inputValue(),'bobbin'); await page.getByRole('link',{name:'Thread the machine',exact:true}).waitFor();
      sample.reopenPreservesQuery=true; assert.equal(contentRequests.length,1);
    }
    await page.close(); sample.status='Pass';
  }
  } finally { await browser.close(); }
  entry.status='Pass';
}
report.sourceHashes={};
for(const f of ['docs/_pages-manifest.json','examples/inline-browser/controller.mjs','examples/modal-browser/controller.mjs']) report.sourceHashes[f]=createHash('sha256').update(await readFile(root+f)).digest('hex');
report.status='Pass';
} catch(error) { report.status='Fail'; report.failure={message:error.message,stack:error.stack}; process.exitCode=1; }
await writeFile(new URL('report.json',directory),JSON.stringify(report,null,2)+'\n'); console.log(JSON.stringify({status:report.status,engines:report.engines.map(e=>({name:e.name,status:e.status,version:e.version})),failure:report.failure},null,2));
