import assert from 'node:assert/strict';
import { build } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/esbuild/lib/main.js';
import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const root='/Users/vasilis/Documents/GitHub/raveldex';
const dir='/var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-rx6008-5jv56vnt/review';
await build({stdin:{contents:`export { createInlineSearch as browserInline } from '${root}/examples/inline-browser/controller.mjs'; export { createInlineSearch as astroInline } from '${root}/examples/inline-astro/src/search.mjs'; export { createRaveldex } from '${root}/dist/index.js';`,resolveDir:root},bundle:true,format:'esm',platform:'browser',outfile:dir+'/final-probe.js',alias:{'@vmitsaras/raveldex':root+'/dist','@vmitsaras/raveldex-astro':root+'/integrations/astro/dist'}});
const server=createServer(async(req,res)=>{if(req.url==='/probe.js'){res.setHeader('content-type','text/javascript');res.end(await readFile(dir+'/final-probe.js'));}else{res.setHeader('content-type','text/html');res.end('<!doctype html><title>Read-only final review probe</title><body></body>');}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
let browser;
try{browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage();await page.goto('http://127.0.0.1:'+server.address().port);
const observations=await page.evaluate(async()=>{
 const {browserInline,astroInline,createRaveldex}=await import('/probe.js');let sequence=0;const output=[];
 const nodes=()=>{const root=document.createElement('div'),status=document.createElement('p'),retry=document.createElement('button'),button=document.createElement('button');document.body.append(root,status,retry,button);return{root,status,retry,button};};
 const destroyNodes=n=>{for(const v of Object.values(n))v.remove();};
 const insertCallback=(status,fn)=>{const tag='final-disconnect-'+(++sequence);customElements.define(tag,class extends HTMLElement{disconnectedCallback(){fn();}});status.append(document.createElement(tag));};
 for(const [family,create] of [['browser',browserInline],['astro',astroInline]]){
  {
   const n=nodes();let controller,disposal,loads=0;
   controller=create({...n,manifestUrl:location.origin+'/manifest.json',buildId:'review',load:async()=>{loads++;throw Error('should not load');}});
   insertCallback(n.status,()=>{disposal=controller.destroy();});const work=controller.start();await work;await disposal;
   output.push({family,phase:'initial-status-destroy',loads,mounted:n.root.querySelectorAll('.raveldex-inline').length,hidden:family==='browser'?n.retry.hidden:n.button.hidden,closed:/closed/.test(n.status.textContent),stableDestroy:disposal===controller.destroy()});destroyNodes(n);
  }
  {
   const n=nodes();let controller,nested,loads=0;
   const engine=createRaveldex({schema:{text:{body:{}}}});let disposals=0;const owner={engine,documents:[],loadDocuments:async()=>[],dispose:async()=>{disposals++;await engine.dispose();}};
   controller=create({...n,manifestUrl:location.origin+'/manifest.json',buildId:'review',load:async()=>{loads++;return owner;}});
   insertCallback(n.status,()=>{nested=controller.start();});const work=controller.start();await work;await controller.destroy();
   output.push({family,phase:'initial-status-reenter-start',deduplicated:nested===work,loads,disposals,mounted:n.root.querySelectorAll('.raveldex-inline').length});destroyNodes(n);
  }
  {
   const n=nodes();let release,reached,loads=0,disposals=0;const gate=new Promise(r=>release=r),waiting=new Promise(r=>reached=r);const engine=createRaveldex({schema:{text:{body:{}}}});
   const owner={engine,documents:[],loadDocuments:async()=>[],dispose:async()=>{disposals++;await engine.dispose();}};
   const controller=create({...n,manifestUrl:location.origin+'/manifest.json',buildId:'review',load:async()=>{loads++;reached();await gate;return owner;}});const work=controller.start();await waiting;const disposal=controller.destroy();let settled=false;disposal.then(()=>settled=true);for(let i=0;i<8;i++)await Promise.resolve();const waited=!settled;release();await Promise.all([work,disposal]);
   output.push({family,phase:'late-owned-engine',loads,disposals,waited,disposed:await engine.search('x').then(()=>false,e=>e.code==='DISPOSED'),mounted:n.root.querySelectorAll('.raveldex-inline').length});destroyNodes(n);
  }
  {
   const n=nodes();let controller,release,reached,disposal;const gate=new Promise((_,r)=>release=r),waiting=new Promise(r=>reached=r);
   controller=create({...n,manifestUrl:location.origin+'/manifest.json',buildId:'review',load:async()=>{reached();return gate;}});const work=controller.start();await waiting;insertCallback(n.status,()=>{disposal=controller.destroy();});release(Error('expected failure'));await work;await disposal;
   output.push({family,phase:'failure-status-destroy',mounted:n.root.querySelectorAll('.raveldex-inline').length,hidden:family==='browser'?n.retry.hidden:n.button.hidden,closed:/closed/.test(n.status.textContent),stableDestroy:disposal===controller.destroy()});destroyNodes(n);
  }
 }
 return output;
});
for(const o of observations){assert.equal(o.mounted,0);if(o.phase==='initial-status-destroy'){assert.equal(o.loads,0);assert.equal(o.hidden,true);assert.equal(o.closed,true);assert.equal(o.stableDestroy,true);}if(o.phase==='initial-status-reenter-start'){assert.equal(o.deduplicated,true);assert.equal(o.loads,1);assert.equal(o.disposals,1);}if(o.phase==='late-owned-engine'){assert.equal(o.loads,1);assert.equal(o.disposals,1);assert.equal(o.waited,true);assert.equal(o.disposed,true);}if(o.phase==='failure-status-destroy'){assert.equal(o.hidden,true);assert.equal(o.closed,true);assert.equal(o.stableDestroy,true);}}
const sourceHashes={};for(const f of ['examples/inline-browser/controller.mjs','examples/inline-astro/src/search.mjs'])sourceHashes[f]=createHash('sha256').update(await readFile(root+'/'+f)).digest('hex');const report={status:'Pass',assertedGroups:observations.length,browser:browser.version(),node:process.version,sourceHashes,observations,scope:'Read-only bundled application source probes using existing compiled Raveldex, not freshly installed package evidence.'};await writeFile(dir+'/final-inline-probe.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}finally{await browser?.close();await new Promise(r=>server.close(r));}
