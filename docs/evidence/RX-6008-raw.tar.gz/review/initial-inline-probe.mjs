import { build } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/esbuild/lib/main.js';
import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const root='/Users/vasilis/Documents/GitHub/raveldex';
const dir='/var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-rx6008-5jv56vnt/review';
await build({stdin:{contents:`export { createInlineSearch as browserInline } from '${root}/examples/inline-browser/controller.mjs'; export { createInlineSearch as astroInline } from '${root}/examples/inline-astro/src/search.mjs'; export { createRaveldex } from '${root}/dist/index.js';`,resolveDir:root},bundle:true,format:'esm',platform:'browser',outfile:dir+'/probe.js',alias:{'@vmitsaras/raveldex':root+'/dist','@vmitsaras/raveldex-astro':root+'/integrations/astro/dist'}});
const server=createServer(async(req,res)=>{if(req.url==='/probe.js'){res.setHeader('content-type','text/javascript');res.end(await readFile(dir+'/probe.js'));}else{res.setHeader('content-type','text/html');res.end('<!doctype html><title>Read-only review probe</title><body></body>');}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
let browser;
try{browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage();await page.goto('http://127.0.0.1:'+server.address().port);
const observations=await page.evaluate(async()=>{
 const {browserInline,astroInline,createRaveldex}=await import('/probe.js');let sequence=0;const output=[];
 for(const [family,create] of [['browser',browserInline],['astro',astroInline]]){
  const root=document.createElement('div'),status=document.createElement('p'),retry=document.createElement('button'),button=document.createElement('button');document.body.append(root,status,retry,button);
  let controller,disposal,loads=0,disposals=0,release;const gate=new Promise(r=>release=r);const engine=createRaveldex({schema:{text:{body:{}}}});
  const owner={engine,documents:[],loadDocuments:async()=>[],dispose:async()=>{disposals++;await engine.dispose();}};
  controller=create({root,status,retry,button,manifestUrl:location.origin+'/manifest.json',buildId:'review',load:async()=>{loads++;await gate;return owner;}});
  const tag='review-disconnect-'+(++sequence);customElements.define(tag,class extends HTMLElement{disconnectedCallback(){disposal=controller.destroy();}});status.append(document.createElement(tag));
  const work=controller.start();let disposalSettled=false;disposal.then(()=>{disposalSettled=true;});for(let i=0;i<8;i++)await Promise.resolve();
  const before={loads,disposals,disposalSettled,status:status.textContent,retryHidden:retry.hidden,buttonHidden:button.hidden};release();await Promise.all([work,disposal]);output.push({family,phase:'initial-status-destroy',before,after:{loads,disposals,mounted:root.querySelectorAll('.raveldex-inline').length}});root.remove();status.remove();retry.remove();button.remove();
 }
 {
  const root=document.createElement('div'),status=document.createElement('p'),retry=document.createElement('button');document.body.append(root,status,retry);let controller,release,reached;
  const gate=new Promise((_,reject)=>release=reject),waiting=new Promise(r=>reached=r);controller=browserInline({root,status,retry,load:async()=>{reached();return gate;}});const work=controller.start();await waiting;let disposal;const tag='review-disconnect-'+(++sequence);customElements.define(tag,class extends HTMLElement{disconnectedCallback(){disposal=controller.destroy();}});status.append(document.createElement(tag));release(new Error('expected failure'));await work;await disposal;output.push({family:'browser',phase:'failure-status-destroy',retryHidden:retry.hidden,status:status.textContent,mounted:root.querySelectorAll('.raveldex-inline').length});
 }
 return output;
});const sourceHashes={};for(const f of ['examples/inline-browser/controller.mjs','examples/inline-astro/src/search.mjs'])sourceHashes[f]=createHash('sha256').update(await readFile(root+'/'+f)).digest('hex');const report={browser:browser.version(),node:process.version,sourceHashes,observations,scope:'Read-only bundled application source probes using existing compiled Raveldex, not freshly installed package evidence.'};await writeFile(dir+'/initial-inline-probe.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}finally{await browser?.close();await new Promise(r=>server.close(r));}
