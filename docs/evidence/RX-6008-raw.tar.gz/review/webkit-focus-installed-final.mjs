import assert from 'node:assert/strict';
import { webkit } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { writeFile, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const dir='/var/folders/m4/7qvldjl917j4nwbkw7bxmn_m0000gn/T/raveldex-rx6008-5jv56vnt/review';
const url='http://127.0.0.1:4188/raveldex/examples/modal-preview/';const browser=await webkit.launch({headless:true,timeout:20000});const observations=[];
const state=async page=>page.evaluate(()=>{const n=document.activeElement;return{tag:n?.tagName,text:n?.textContent?.slice(0,100),hiddenAncestor:n?.closest('[hidden],dialog:not([open])')?.outerHTML.slice(0,120),trigger:n?.matches('[data-search-trigger]'),insideLoading:Boolean(n?.closest('[data-search-loading]')),insideReady:Boolean(n?.closest('.raveldex-modal')),openDialogs:[...document.querySelectorAll('dialog[open]')].map(n=>n.getAttribute('class')||n.getAttribute('data-search-loading')||'loading')};});
try{
for(const activation of ['pointer','keyboard']){
 const page=await browser.newPage();await page.goto(url);await page.evaluate(()=>{window.reviewFocus=[];for(const type of ['focusin','focusout','close'])document.addEventListener(type,e=>{const n=e.target;window.reviewFocus.push({type,tag:n?.tagName,text:n?.textContent?.slice(0,65),hidden:Boolean(n?.closest?.('[hidden],dialog:not([open])'))});},true);});
 const trigger=page.getByRole('button',{name:'Search documentation',exact:true});const stages=[{name:'before activation',...await state(page)}];
 if(activation==='pointer')await trigger.click();else{await trigger.focus();await trigger.press('Enter');}
 const input=page.getByRole('searchbox',{name:'Search the workshop guide',exact:true});await input.waitFor();stages.push({name:'first ready',...await state(page)});
 await page.getByRole('button',{name:'Close search',exact:true}).click();stages.push({name:'first ready pointer close',...await state(page)});
 await trigger.click();await input.waitFor();stages.push({name:'second ready pointer open',...await state(page)});await page.getByRole('button',{name:'Close search',exact:true}).click();stages.push({name:'second ready pointer close',...await state(page)});
 observations.push({activation,stages,focusEvents:await page.evaluate(()=>window.reviewFocus)});await page.close();
}
const sourceHashes={};for(const f of ['examples/modal-browser/controller.mjs','examples/modal-astro/src/search.mjs','src/addons/ui/modal.ts'])sourceHashes[f]=createHash('sha256').update(await readFile('/Users/vasilis/Documents/GitHub/raveldex/'+f)).digest('hex');const report={browser:'Playwright WebKit '+browser.version(),node:process.version,url,sourceHashes,observations,scope:'Actual currently installed generated browser starter preview. Scripted native pointer and keyboard interactions, not Safari/human AT.'};await writeFile(dir+'/webkit-focus-installed-final.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));assert.equal(observations[0].stages[2].trigger,true,'first pointer-open restores logical trigger');assert.equal(observations[0].stages[4].trigger,true,'subsequent direct trigger listener restores');assert.equal(observations[1].stages[2].trigger,true,'keyboard activation begins from focused trigger');
}finally{await browser.close();}
