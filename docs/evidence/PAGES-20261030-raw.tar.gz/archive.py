from pathlib import Path
import json, tarfile, gzip, io, hashlib
repo=Path('/Users/vasilis/Documents/GitHub/raveldex');stage=Path('/tmp/raveldex-pages-20261030')
destination=repo/'docs/evidence/PAGES-20261030-raw.tar.gz'
assert not destination.exists()
files={}
def add(root,source,name=None):
    p=root/source
    assert p.is_file() and not p.is_symlink(),p
    files[name or source]=p.read_bytes()
for name in ['npm-ci.log','full-check.log','tooling-final.log','browser-closed.log','browser-closed.json','site-final-1.log','site-final-2.log','site-final-first.json','site-final-check.log','candidate-final.log','jekyll-build-final.log','jekyll-comparison-final.json','gems.txt','jekyll-install.log','jekyll-install-isolated.log','ffi-install.log','i18n-install.log','public-suffix-install.log','jekyll-install-compatible.log','jekyll-install-final.log','jekyll-install-complete.log','account-eligibility.json','repository-pages.json','environment.json','audit.py','audit.log','final-audit.json','preexisting.patch','follow-instructions.mjs','follow-instructions.log','home.png','home-narrow.png','instructions/follow-instructions.json','archive.py']:
    add(stage,name)
for folder,names in {
    'candidate-final':['candidate-report.json','vmitsaras-raveldex-0.1.0-rc.0.tgz'],
    'english':['english-package.json','verification.log','vmitsaras-raveldex-english-0.1.0-rc.0.tgz'],
    'astro':['astro-package.json','verification.log','vmitsaras-raveldex-astro-0.1.0-rc.0.tgz'],
    'prior-artifacts':['core.tgz','english.tgz','astro.tgz']}.items():
    for name in names:add(stage,folder+'/'+name)
for p in sorted((stage/'jekyll-output').rglob('*')):
    if p.is_file():add(stage,p.relative_to(stage).as_posix())
for name in ['docs/_pages-manifest.json','docs/_config.yml','site/pages.mjs','site/index.md','site/404.md','site/Layout.astro','site/styles.css','site/README.md','scripts/build-pages.mjs','scripts/check-pages.mjs','scripts/preview-pages.mjs','scripts/lib/pages.mjs','test/tooling/pages.test.mjs','test/pages/browser.test.mjs','docs/evidence/PAGES-20261030.md','PROJECT_CONTEXT.md','CODEX_HANDOFF.md']:
    add(repo,name,'source/'+name)
m=json.loads((repo/'docs/_pages-manifest.json').read_text())
for item in m['inputs']:
    if not item['path'].startswith('dist/'): add(repo,item['path'],'source/'+item['path'])
manifest={'kind':'raveldex-pages-preparation-raw-v1','members':[{'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in sorted(files.items())]}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as archive:
    for name,data in sorted(files.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
        archive.addfile(member,io.BytesIO(data))
raw=gzip.compress(stream.getvalue(),compresslevel=9,mtime=0);destination.write_bytes(raw)
audit=json.loads((stage/'final-audit.json').read_text())
audit.update({'date':'2026-10-30','implementation':'complete','localVerification':'Pass','publication':'Not performed','fullCheck':{'tests':866,'failed':0,'skipped':0,'batches':[782,30,24,26,1,3]},'finalBrowser':json.loads((stage/'browser-closed.json').read_text()),'installedInstructions':{'status':'Pass','observations':4,'bases':['/','/docs/']},'jekyll':json.loads((stage/'jekyll-comparison-final.json').read_text()),'deterministicFinalBuilds':True,'htmlPages':37,'htmlLinksAndFragments':563,'blocked':['Private-repository Pages eligibility: account plan field not exposed'],'notRun':['Hosted Pages deployment and duration','Remote CI for these uncommitted changes','New human AT/physical-input/real-zoom/memory qualification'],'rawArchive':{'path':'docs/evidence/PAGES-20261030-raw.tar.gz','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'members':len(files)}})
(repo/'docs/evidence/PAGES-20261030.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(audit['rawArchive']))
with tarfile.open(destination) as archive:
    for row in manifest['members']:
        data=archive.extractfile(row['path']).read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print('All archived member hashes verified')
