# Project context

Snapshot: 2026-10-30. Repository: `vmitsaras/raveldex`.

## Current state

All **21 release-track and ten selected N5 tasks are done** in the [canonical roadmap](docs/planning/roadmap.json). No implementation task remains. Core, English and Astro packages remain private `0.1.0-rc.0`; no package, tag, release or public site has been published by this documentation work.

The owner-authorized merge fast-forwarded main to `3407c2a801a27bfd32569619854ff3be510e6116`. [Main CI 41008634728](https://github.com/vmitsaras/raveldex/actions/runs/41008634728) passed 860 tests on each of Node 22.23.4 and 24.22.1 / Ubuntu 26.04 x64, including private candidate and separate English/Astro artifacts. [Tracking 41008634712](https://github.com/vmitsaras/raveldex/actions/runs/41008634712) also passed. Those exact-source results do not qualify later documentation bytes or a public release.

The documentation consolidation keeps one Unreleased draft and archives chronology. The subsequent owner request prepares a minimal content-first docs/demo site for main-branch `/docs` publishing, using Jekyll exclusions to preserve repository-only evidence paths. [Site instructions](site/README.md) own build/preview and the publication boundary; activation and remote writes remain separate. [Publication status](docs/release/PUBLICATION_STATUS.md) owns remaining package-release decisions. The [documentation review](docs/planning/DOCUMENTATION_REVIEW.md) records the earlier consolidation separately from later site verification.

[Site verification](docs/evidence/PAGES-20261030.md) records 37 HTML pages, actual local Jekyll exclusions, packed-demo browser checks and fresh root/subdirectory Astro walkthroughs. Pages remains disabled; account-plan eligibility was not exposed by the read-only credential. Local preparation is not hosted deployment or package publication.

## Architecture and ownership

- Native TypeScript, pure ESM, framework-agnostic core with no runtime dependencies or foreign engine below it.
- Core owns indexing, retrieval, native BM25, exact totals, deterministic order, atomic incremental writes, FIFO execution, finite limits and cooperative cancellation.
- Core alone retains no original text, positions, offsets, DOM, worker or database state. Optional registrations/providers are explicit at owner creation.
- Source, phrases, positions/offsets, filters/facets, Inspector, evidence/snippets and UI/CSS stay optional. The UI borrows the application engine and display records; destroy UI before disposing its owner.
- Workers own one complete engine. Transport loss can leave outcomes unknown; receipts/reconciliation and authoritative source recovery remain explicit.
- Source snapshots rebuild under the receiver. Native snapshots require exact application-qualified Node environments; browser/worker native portability is unavailable.
- English is also packaged independently. The separate Astro adapter builds explicit static allowlists and loads artifacts on demand; it adds no framework dependency to core.

The [API index](docs/api/README.md), [compatibility policy](docs/release/COMPATIBILITY.md), specifications and current source define exact public behavior. The [support record](docs/support/RX-4003.md) separates runtime tests, automated browser checks, human AT/physical input and calibrated memory observations.

## Limits and continuation

The 15 KiB core planning-target miss, lexical relevance gaps, English overstemming, finite rebuild/deadline refusals, generic UI transport-error presentation and bounded VoiceOver announcement findings remain disclosed. Admission ceilings are not universal completion, latency, memory or portability guarantees.

Follow AGENTS.md and inspect actual source before changing behavior. Preserve completed tasks, existing evidence, public-contract boundaries and private guards. Publication, version changes, registry access/dist-tag, visibility and deployment remain owner decisions; release-verification tooling is separate from this documentation slice.

## Maintainer history

The [candidate history archive](docs/history/CANDIDATE_HISTORY.md) preserves pre-consolidation narratives and their original Git/blob identities. Detailed commands, failures and accepted artifacts remain in their original evidence files. Historical states and authorizations do not supersede the current owner request.
