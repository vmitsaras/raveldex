# Raveldex documentation

Raveldex is a native TypeScript local search library. Start with the framework-independent core, then select the optional analysis, search and host capabilities your application needs.

The implementation is complete; the packages remain **private and unpublished**. These guides describe local-tarball evaluation, not a registry release.

## Start here

1. [Prepare and install local packages](../docs/release/PREPARATION.md), then run the [smallest core example](../README.md#smallest-core-example). You need repository access for the source checkout.
2. Read the [API reference](../docs/api/README.md) and choose optional capabilities explicitly.
3. [Try the browser demo](../examples/docs-search/index.html) without installation on the generated site. It searches 34 selected contract sections; it is not a search over every page on this site.
4. Follow the [Astro setup, build and preview walkthrough](../examples/astro/README.md) for the existing static fixture. It includes isolated installation, root and subdirectory builds, expected interactions and server cleanup.

## Runnable examples

| Example | Where it runs | What to expect |
| --- | --- | --- |
| [Core documentation search](../examples/core-docs/README.md) | Terminal | Real-document search through the installed core. |
| [Browser demo](../examples/docs-search/index.html) and [instructions](../examples/docs-search/README.md) | Browser | Exact terms/phrases, facets, snippets, Inspector, direct or worker execution. |
| [Astro fixture](../examples/astro/README.md) | Local static build and HTTP preview | Three selected source paragraphs, deferred search loading and real result navigation. |
| [Migration](../examples/migration/README.md) | Terminal | Explicit source conversion followed by native rebuilding. |
| [API recipes](../docs/api/examples/README.md) | Installed ESM application | Small core, optional module, browser and worker consumers. |

The browser demo enables a selected set of capabilities. It does not silently enable every optional feature or persist your query. Terminal and Astro instructions require a source checkout and the documented tooling.

## Understand the boundaries

Read [compatibility](../docs/release/COMPATIBILITY.md), [support and limitations](../docs/support/RX-4003.md) and [Unreleased notes](../CHANGELOG.md). The Astro fixture's native declaration is test evidence, not reusable production qualification. Browser automation and bounded human observations remain separately scoped.
