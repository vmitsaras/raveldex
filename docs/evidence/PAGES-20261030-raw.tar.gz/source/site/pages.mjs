// Explicit public content. Everything else under docs/ remains repository-only.
export const BASE = '/raveldex/';
export const EXCLUDED = ['accessibility', 'api', 'architecture', 'decisions', 'evaluation',
  'evidence', 'history', 'migration', 'planning', 'release', 'research', 'specs', 'support'];
export const PAGES = [
  ['site/index.md', '', 'Raveldex documentation'],
  ['site/404.md', '404', 'Page not found'],
  ['README.md', 'guide/overview', 'Getting started'],
  ['docs/release/PREPARATION.md', 'guide/preparation', 'Prepare and install'],
  ['docs/release/COMPATIBILITY.md', 'guide/compatibility', 'Compatibility'],
  ['docs/release/CANDIDATE.md', 'guide/release-scope', 'Implementation scope'],
  ['docs/release/PUBLICATION_STATUS.md', 'guide/publication-status', 'Publication status'],
  ['docs/support/RX-4003.md', 'guide/limitations', 'Support and limitations'],
  ['CHANGELOG.md', 'guide/release-notes', 'Unreleased notes'],
  ['examples/README.md', 'examples', 'Runnable examples'],
  ['examples/astro/README.md', 'examples/astro', 'Astro setup, build and preview'],
  ['examples/core-docs/README.md', 'examples/core', 'Core terminal example'],
  ['examples/docs-search/README.md', 'examples/browser', 'Browser demo instructions'],
  ['examples/migration/README.md', 'examples/migration', 'Migration terminal example'],
  ['docs/api/examples/README.md', 'examples/api', 'Installed API recipes'],
  ['integrations/astro/README.md', 'reference/astro-package', 'Astro package'],
  ['integrations/languages/english/README.md', 'reference/english-package', 'English package'],
  ...['README', 'CORE', 'ADDONS', 'HOSTS', 'TYPO', 'SUGGESTIONS', 'SYNONYMS', 'ENGLISH',
    'IDENTIFIERS', 'LITERAL', 'PROXIMITY', 'QUERY_SYNTAX', 'RECORD_PATCH', 'STATIC_ASTRO']
    .map(name => [`docs/api/${name}.md`, name === 'README' ? 'reference' : `reference/${name.toLowerCase().replaceAll('_', '-')}`, name === 'README' ? 'API reference' : name.replaceAll('_', ' ')]),
  ...['CORE_CONTRACT', 'RANKING', 'MUTATIONS_AND_EXECUTION'].map(name =>
    [`docs/specs/${name}.md`, `contracts/${name.toLowerCase().replaceAll('_', '-')}`, name.replaceAll('_', ' ')]),
  ...['NATIVE_ARCHITECTURE', 'ADDONS_AND_ADAPTERS'].map(name =>
    [`docs/architecture/${name}.md`, `contracts/${name.toLowerCase().replaceAll('_', '-')}`, name.replaceAll('_', ' ')]),
];
export const RECIPES = ['core', 'addons', 'snapshots', 'browser', 'worker', 'worker-host', 'migration'];
export const href = route => BASE + (route ? route === '404' ? '404.html' : `${route}/` : '');
export const JEKYLL = `# Required: Jekyll excludes repository-only records before branch publication.\n# Do not add .nojekyll. Do not add includes that override these exclusions.\nurl: https://vmitsaras.github.io\nbaseurl: /raveldex\ntheme: null\nplugins: []\nexclude:\n${EXCLUDED.map(name => `  - ${name}\n`).join('')}`;
