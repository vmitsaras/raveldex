# Codex handoff

## Current boundary

All 31 tasks are complete: 21 release tasks and ten selected optional features. Native TypeScript and the existing optional-module architecture are adopted. Do not reset tasks or invent another implementation task.

Core, English and Astro remain private `0.1.0-rc.0`. Documentation uses one **Unreleased** draft and a repository-only history archive. The subsequent owner request prepares a minimal docs/demo site for main-branch `/docs` publication; follow [site build/preview instructions](site/README.md), preserve Jekyll exclusions and never delete the existing docs tree. Activation, remote writes, package publication, tags, releases and visibility changes remain excluded.

Read [AGENTS.md](AGENTS.md), [current context](PROJECT_CONTEXT.md), [publication status](docs/release/PUBLICATION_STATUS.md) and the [documentation review](docs/planning/DOCUMENTATION_REVIEW.md) before continuing. For behavior changes, inspect the relevant task/specification, source and tests.

## Verification workflow

```sh
npm ci
npm run check
npm run handoff:status
npm run handoff:next
```

The planner reports the active release backlog complete. The canonical manifest owns task state; readable plans are generated. Existing main CI tested exact source `3407c2a` with 860 tests on each Node 22/24 job. Later documentation/artifact changes need their own recorded verification; historical CI never qualifies changed bytes automatically.

For a new private candidate verification, use a fresh output directory:

```sh
npm run candidate:prepare -- --output /tmp/raveldex-candidate-review
```

Preparation retains private metadata and does not publish. Separate English/Astro pack scripts must consume the same stable compiler output when artifact identity is being reviewed. Release metadata requires a separately implemented verification path; do not weaken candidate guards to make a public release pass.

## Preserve boundaries

- No foreign engine beneath core, hidden optional retention or import-time host initialization.
- Preserve exact totals/revisions/scores, original UTF-16 coordinates, explicit capabilities/errors and resource limits.
- Keep source recovery and exact-Node native qualification distinct; unknown transport/storage outcomes do not authorize blind retries.
- Preserve failed/refused observations and scoped AT/memory findings. Do not turn automated checks into speech, physical-input, physical-copy or all-platform claims.
- `tracking:preview` is local. `tracking:sync` is an explicit remote write requiring an authorized token/environment.

Report what changed, actual verification, limitations and next eligible work. Local completion does not imply remote CI or publication. The [maintainer history](docs/history/CANDIDATE_HISTORY.md) preserves earlier candidate narratives without competing with current guidance.

The [Pages preparation record](docs/evidence/PAGES-20261030.md) owns local site results and the remaining eligibility/hosted-build checks. `npm run pages:preview` serves only the approved public inventory; do not serve the full evidence-bearing docs tree or add `.nojekyll`.
