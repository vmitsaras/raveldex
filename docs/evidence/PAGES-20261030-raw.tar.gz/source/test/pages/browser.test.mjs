import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { readFile, writeFile } from 'node:fs/promises';
import { chromium } from 'playwright-core';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

test('branch Pages projection and real packed demo work at /raveldex/', { timeout: 120_000 }, async () => {
  const root = fileURLToPath(new URL('../../', import.meta.url));
  const server = spawn(process.execPath, ['scripts/preview-pages.mjs', '--port', '0'], { cwd: root, stdio: ['ignore', 'pipe', 'pipe'] });
  const exited = once(server, 'exit');
  let log = '', browser;
  const observations = [], failures = [];
  server.stdout.on('data', bytes => { log += bytes; });
  server.stderr.on('data', bytes => { log += bytes; });
  try {
    const deadline = Date.now() + 20_000;
    while (!/Open http:\/\/127\.0\.0\.1:\d+\/raveldex\//.test(log)) {
      assert.equal(server.exitCode, null, log);
      assert.ok(Date.now() < deadline, `preview startup timeout: ${log}`);
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    const url = /Open (http:\/\/127\.0\.0\.1:\d+\/raveldex\/)/.exec(log)[1];
    const channel = process.env.RAVELDEX_CANDIDATE_BROWSER === 'chromium' ? undefined : 'chrome';
    browser = await chromium.launch({ channel, headless: true });
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    const pageErrors = [], badRequests = [], network = [];
    page.on('pageerror', error => pageErrors.push(String(error)));
    page.on('request', request => network.push(request.url()));
    page.on('response', response => { if (response.status() >= 400) badRequests.push({ url: response.url(), status: response.status() }); });
    await page.goto(url);
    await page.keyboard.press('Tab');
    assert.equal(await page.locator('.skip').evaluate(node => node === document.activeElement), true);
    await page.keyboard.press('Enter');
    assert.equal(await page.locator('main').evaluate(node => node === document.activeElement), true);
    await page.getByRole('link', { name: 'Astro setup, build and preview walkthrough', exact: true }).click();
    assert.equal(new URL(page.url()).pathname, '/raveldex/examples/astro/');
    assert.match(await page.locator('main').innerText(), /preview stop --root/);
    await page.reload();
    assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Packed Astro static documentation consumer');
    const recipe = await fetch(new URL('example-files/core.mjs', url));
    assert.equal(recipe.status, 200);
    assert.equal(await recipe.text(), await readFile(join(root, 'docs/api/examples/core.mjs'), 'utf8'));
    for (const path of ['evidence/PUBLIC-DOCS-20261030-raw.tar.gz', 'history/CANDIDATE_HISTORY.md', 'planning/roadmap.json', '_pages-manifest.json', '_config.yml', 'missing-page/']) {
      const result = await fetch(new URL(path, url));
      assert.equal(result.status, 404, path);
      assert.match(await result.text(), /Page not found/);
    }
    observations.push({ name: 'onboarding, deep-link refresh, exact recipe and private-path refusal', status: 'Pass' });
    await page.goto(new URL('demo/', url).href);
    const ready = async () => {
      await page.waitForFunction(() => document.querySelector('[data-pilot-search]')?.dataset.pilotState === 'ready');
      await page.waitForFunction(() => document.querySelector('[data-raveldex-ui]')?.getAttribute('aria-busy') === 'false');
    };
    const search = async text => {
      await page.locator('[data-raveldex-input]').fill(text);
      await page.locator('[data-raveldex-submit]').click();
      await ready();
    };
    const collect = () => page.locator('[data-raveldex-result]').evaluateAll(nodes => nodes.map(node => ({
      id: node.dataset.raveldexResult, score: node.querySelector('[data-raveldex-score]').textContent,
      text: [...node.querySelectorAll('[data-raveldex-snippet]')].map(item => item.textContent),
    })));
    await ready();
    assert.match(await page.locator('[data-pilot-identity]').innerText(), /34 complete documentation sections from 5 allowlisted files/);
    await search('term contribution');
    assert.ok(await page.locator('[data-raveldex-result]').count() > 0);
    const link = page.locator('[data-raveldex-result-title]').first();
    const destination = await link.getAttribute('href');
    assert.ok(new URL(destination, url).pathname.startsWith('/raveldex/contracts/'));
    assert.equal(new URL(destination, url).origin, new URL(url).origin);
    await link.click();
    assert.equal(new URL(page.url()).origin, new URL(url).origin);
    const anchor = decodeURIComponent(new URL(page.url()).hash.slice(1));
    assert.equal(await page.locator(`[id="${anchor}"]`).count(), 1);
    await page.goBack();
    await ready();
    await search('source');
    assert.equal(await page.locator('[data-raveldex-next]').getAttribute('aria-disabled'), 'false');
    const firstPage = await collect();
    await page.locator('[data-raveldex-next]').click(); await ready();
    assert.notDeepEqual(await collect(), firstPage);
    const facet = page.locator('[data-raveldex-facet]');
    assert.ok(await facet.locator('option').count() > 1);
    await facet.selectOption({ index: 1 }); await ready();
    await facet.selectOption({ index: 0 }); await ready();
    await search('term contribution');
    await page.locator('[data-pilot-mode]').selectOption('phrase'); await ready();
    const direct = await collect(); assert.ok(direct.length > 0);
    await page.locator('[data-pilot-representation]').selectOption('offsets'); await ready();
    assert.deepEqual(await collect(), direct);
    await page.locator('[data-pilot-execution]').selectOption('worker'); await ready();
    assert.deepEqual(await collect(), direct);
    assert.ok(network.some(item => new URL(item).pathname.endsWith('/demo/engine-worker.mjs')));
    const inspect = page.locator('[data-raveldex-inspect]');
    await inspect.click();
    await page.waitForFunction(() => document.querySelector('[data-raveldex-inspector-data]')?.textContent.includes('raveldex-bm25-v1'));
    assert.equal(await page.locator('[data-raveldex-inspector-close]').evaluate(node => node === document.activeElement), true);
    await page.keyboard.press('Escape');
    assert.equal(await inspect.evaluate(node => node === document.activeElement), true);
    await page.locator('[data-pilot-destroy]').click();
    assert.equal(await page.locator('[data-raveldex-ui]').count(), 0);
    await page.locator('[data-pilot-initialize]').click(); await ready();
    assert.equal(await page.locator('[data-raveldex-input]').inputValue(), 'term contribution');
    await search('unmatchedword');
    assert.equal(await page.locator('[data-raveldex-status]').innerText(), 'No results.');
    await search('term contribution');
    observations.push({ name: 'real packed demo navigation, pagination, facets, phrase/offset/worker parity, Inspector, empty recovery, teardown', status: 'Pass', direct });
    for (const width of [320, 1280]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto(new URL('guide/preparation/', url).href);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true, `guide reflow at ${width}`);
      await page.goto(new URL('demo/', url).href); await ready();
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true, `demo reflow at ${width}`);
    }
    observations.push({ name: '320px and 1280px reflow (320px approximates 400% layout width only)', status: 'Pass' });
    assert.deepEqual(pageErrors, []);
    assert.deepEqual(badRequests, []);
    assert.ok(network.every(item => new URL(item).origin === new URL(url).origin));
    console.log(JSON.stringify({ browser: browser.version(), observations, pageErrors, badRequests }));
  } catch (error) { failures.push({ message: error.message, stack: error.stack }); throw error; }
  finally {
    const version = browser?.version();
    await browser?.close();
    if (server.exitCode === null && server.signalCode === null) server.kill('SIGTERM');
    await exited;
    await writeFile(process.env.RAVELDEX_PAGES_REPORT ?? join(tmpdir(), 'raveldex-pages-browser.json'), JSON.stringify({
      status: failures.length ? 'Fail' : 'Pass', browser: version, node: process.version, observations, failures,
      scope: 'One automated Chrome/Chromium session; no human AT, physical input, real zoom, heap/copy peaks or live deployment qualification.',
    }, null, 2) + '\n');
  }
});
