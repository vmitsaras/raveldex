import assert from 'node:assert/strict';
import { mkdir, rm, copyFile, readFile, writeFile, realpath } from 'node:fs/promises';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { build as bundle } from 'esbuild';
import { BASE, PAGES, RECIPES, JEKYLL, href } from '../site/pages.mjs';
import { prepareUIPilot } from './lib/ui-consumer.mjs';
import { command } from './lib/packed-consumer.mjs';
import { publishGenerated, rewriteMarkdown, auditLinks, sha256 } from './lib/pages.mjs';

const root = await realpath(fileURLToPath(new URL('../', import.meta.url)));
const work = join(root, '.tmp/pages');
const source = join(work, 'source');
const output = join(work, 'output');
await rm(work, { recursive: true, force: true }); // Only this script's scratch tree.
await mkdir(join(source, 'src/pages'), { recursive: true });
await copyFile(join(root, 'site/Layout.astro'), join(source, 'src/Layout.astro'));
await writeFile(join(source, 'package.json'), '{"private":true,"type":"module"}\n');
await writeFile(join(source, 'astro.config.mjs'), `import { defineConfig } from 'astro/config';
export default defineConfig({ output: 'static', site: 'https://vmitsaras.github.io', base: ${JSON.stringify(BASE)},
  trailingSlash: 'always', outDir: ${JSON.stringify(output)}, build: { format: 'directory', assets: 'site-assets' },
  markdown: { syntaxHighlight: false }, devToolbar: { enabled: false } });\n`);
const routes = new Map(PAGES.map(([path, route]) => [path, href(route)]));
const recipes = new Map(RECIPES.map(name => [`docs/api/examples/${name}.mjs`, `${BASE}example-files/${name}.mjs`]));
assert.equal(routes.size, PAGES.length, 'unique source allowlist');
assert.equal(new Set(routes.values()).size, PAGES.length, 'unique public routes');
routes.set('examples/docs-search/index.html', BASE + 'demo/');
for (const [path, route, title] of PAGES) {
  const destination = join(source, 'src/pages', route ? route + '.md' : 'index.md');
  await mkdir(dirname(destination), { recursive: true });
  const layout = relative(dirname(destination), join(source, 'src/Layout.astro')).replaceAll('\\', '/');
  const markdown = rewriteMarkdown(await readFile(join(root, path), 'utf8'), path, routes, recipes);
  await writeFile(destination, `---\nlayout: ${JSON.stringify(layout.startsWith('.') ? layout : './' + layout)}\ntitle: ${JSON.stringify(title)}\n---\n${markdown}`);
}
const built = await command(process.execPath, [join(root, 'node_modules/astro/bin/astro.mjs'), 'build', '--root', source]);
process.stdout.write(built.stdout);
process.stderr.write(built.stderr);
await mkdir(join(output, 'site-assets'), { recursive: true });
await copyFile(join(root, 'site/styles.css'), join(output, 'site-assets/styles.css'));
await copyFile(join(root, 'LICENSE'), join(output, 'site-assets/LICENSE.txt'));
await mkdir(join(output, 'example-files'), { recursive: true });
for (const name of RECIPES) await copyFile(join(root, `docs/api/examples/${name}.mjs`), join(output, `example-files/${name}.mjs`));

// Reuse the real installed-package pilot. Change display navigation only, after
// its corpus validation; the frozen records, source bytes and hashes stay exact.
const pilot = await prepareUIPilot();
const entryPath = join(pilot.directory, 'pilot-entry.mjs');
const entry = await readFile(entryPath, 'utf8');
const original = 'url: section.sourceUrl';
assert.equal(entry.split(original).length, 2, 'exact deployment adapter seam');
const destinations = Object.fromEntries(pilot.corpus.sources.map(item => {
  assert.ok(routes.has(item.path));
  return [item.path, routes.get(item.path)];
}));
await writeFile(entryPath, entry.replace(original, `url: ${JSON.stringify(destinations)}[section.sourcePath] + '#' + section.anchor`));
await bundle({ absWorkingDir: pilot.directory, entryPoints: ['pilot-entry.mjs'], outfile: 'main.mjs',
  bundle: true, platform: 'browser', format: 'esm', target: 'es2022', minify: true,
  treeShaking: true, legalComments: 'none', charset: 'ascii', sourcemap: false });
await mkdir(join(output, 'demo'), { recursive: true });
for (const name of ['main.mjs', 'engine-worker.mjs', 'ui.css', 'pilot.css', 'corpus.json']) {
  await copyFile(join(pilot.directory, name), join(output, 'demo', name));
}
let demo = await readFile(join(pilot.directory, 'index.html'), 'utf8');
demo = demo.replace('<body class="docs-pilot">', `<body class="docs-pilot">\n    <a href="#main">Skip to content</a>\n    <nav aria-label="Documentation"><a href="${BASE}">Documentation home</a> · <a href="${BASE}examples/browser/">Demo instructions</a> · <a href="${BASE}reference/">API</a></nav>`)
  .replace('<main class="docs-pilot__main">', '<main id="main" class="docs-pilot__main" tabindex="-1">')
  .replace('read its GitHub source', 'read its contract on this site')
  .replace('href="https://github.com/vmitsaras/raveldex/tree/main/docs/specs"', `href="${BASE}contracts/core-contract/"`)
  .replace('Raveldex repository</a>', `Raveldex repository (repository access)</a> · <a href="${BASE}site-assets/LICENSE.txt">MIT license</a>`);
await writeFile(join(output, 'demo/index.html'), demo);
// Plain demo styling; package UI styles are copied unchanged and remain separate.
await writeFile(join(output, 'demo/pilot.css'), `${await readFile(join(root, 'site/styles.css'), 'utf8')}\n.docs-pilot__controls { display:flex; flex-wrap:wrap; gap:1rem; align-items:end; }\n.docs-pilot__control { display:grid; gap:.25rem; }\n.docs-pilot__controls :is(button,select) { min-height:2.75rem; padding:.4rem; }\n.docs-pilot__status { min-height:1.6em; }\n`);
assert.equal(sha256(await readFile(join(output, 'demo/corpus.json'))), sha256(await readFile(join(pilot.directory, 'corpus.json'))));
await writeFile(join(output, '_config.yml'), JEKYLL);
// Validate before touching branch-published files.
const { walk } = await import('./lib/pages.mjs');
const staged = { files: (await walk(output)).map(path => ({ path })) };
const links = await auditLinks(output, staged);
const inputPaths = new Set([...PAGES.map(x => x[0]), ...RECIPES.map(name => `docs/api/examples/${name}.mjs`),
  'site/Layout.astro', 'site/styles.css', 'site/pages.mjs', 'scripts/build-pages.mjs', 'scripts/lib/pages.mjs',
  'scripts/lib/ui-consumer.mjs', 'scripts/lib/packed-consumer.mjs', 'examples/core-docs/corpus.mjs',
  'test/fixtures/docs/judgments.mjs', 'package.json', 'package-lock.json', 'LICENSE',
  ...['index.html', 'main.mjs', 'engine-worker.mjs', 'configuration.mjs'].map(name => `examples/docs-search/${name}`),
  ...pilot.package.files.filter(file => file.path.startsWith('dist/')).map(file => file.path)]);
const inputs = await Promise.all([...inputPaths].sort().map(async path => ({ path, sha256: sha256(await readFile(join(root, path))) })));
const manifest = await publishGenerated(join(root, 'docs'), output, inputs);
console.log(JSON.stringify({ status: 'Pass', ...links, files: manifest.files.length,
  bytes: manifest.files.reduce((sum, file) => sum + file.bytes, 0),
  corpusSha256: pilot.corpus.hash, packageSha256: pilot.package.sha256, packagePrivate: pilot.report.package.private }));
