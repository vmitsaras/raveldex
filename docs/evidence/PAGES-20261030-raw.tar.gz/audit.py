from pathlib import Path
import json, hashlib, tarfile, subprocess, re, sys
repo=Path(sys.argv[1]).resolve(); stage=Path(sys.argv[2]).resolve()
m=json.loads((repo/'docs/_pages-manifest.json').read_text()); pub=stage/'jekyll-output'
expected={x['path']:x for x in m['files'] if x['path']!='_config.yml'}
actual={p.relative_to(pub).as_posix():p for p in pub.rglob('*') if p.is_file()}
assert set(actual)==set(expected),(set(actual)-set(expected),set(expected)-set(actual))
for name,p in actual.items(): assert hashlib.sha256(p.read_bytes()).hexdigest()==expected[name]['sha256'],name
(stage/'jekyll-comparison-final.json').write_text(json.dumps({'status':'Pass','files':len(actual),'bytes':sum(p.stat().st_size for p in actual.values()),'allFilesByteIdentical':True,'jekyll':'3.10.0','ruby':'2.6.10','safe':True,'scope':'Local Jekyll core, same documented Pages Jekyll version; not the full hosted github-pages runtime/plugins.'},indent=2)+'\n')
old=json.loads(subprocess.check_output(['git','show','87fb5c3:package.json'],cwd=repo)); new=json.loads((repo/'package.json').read_text())
extra={k:v for k,v in new['scripts'].items() if k not in old['scripts']}
assert set(extra)=={'pages:build','pages:generate','pages:check','pages:preview'}
new['scripts']={k:v for k,v in new['scripts'].items() if k not in extra}; assert old==new
protected=['src','integrations/astro/src','integrations/languages/english/src','package-lock.json','docs/planning/roadmap.json','docs/specs','docs/architecture','test/fixtures','examples/astro/content.json','examples/astro/content-provenance.json','examples/astro/qualification.mjs','examples/docs-search']
for path in protected: assert not subprocess.check_output(['git','diff','87fb5c3','--',path],cwd=repo).strip(),path
before=(stage/'preexisting.patch').read_text(); after=subprocess.check_output(['git','diff','--binary','87fb5c3'],cwd=repo,text=True)
def sections(s): return {b.splitlines()[0]:b for b in s.split('diff --git ')[1:]}
intentional={'README.md','PROJECT_CONTEXT.md','CODEX_HANDOFF.md','docs/release/PUBLICATION_STATUS.md','examples/README.md'}
for key,value in sections(before).items():
    path=key.split(' b/')[1]
    if path not in intentional: assert sections(after).get(key)==value,path
prior=repo/'docs/evidence/PUBLIC-DOCS-20261030-raw.tar.gz'
assert hashlib.sha256(prior.read_bytes()).hexdigest()=='e356e1b63cd77cb48c436bc8885893d823ec0341cba7758bc493c87c1872b77f'
comparisons=[]
for label,a,b in [
 ('core',stage/'candidate-final/vmitsaras-raveldex-0.1.0-rc.0.tgz',stage/'prior-artifacts/core.tgz'),
 ('english',stage/'english/vmitsaras-raveldex-english-0.1.0-rc.0.tgz',stage/'prior-artifacts/english.tgz'),
 ('astro',stage/'astro/vmitsaras-raveldex-astro-0.1.0-rc.0.tgz',stage/'prior-artifacts/astro.tgz')]:
    with tarfile.open(a) as ta,tarfile.open(b) as tb:
        aa={x.name:ta.extractfile(x).read() for x in ta if x.isfile()}; bb={x.name:tb.extractfile(x).read() for x in tb if x.isfile()}
        runtime={k:v for k,v in aa.items() if k.startswith('package/dist/')}
        assert runtime=={k:v for k,v in bb.items() if k.startswith('package/dist/')},label
        assert all(not k.startswith(('package/docs/guide/','package/docs/demo/','package/docs/reference/','package/site/')) for k in aa)
        metadata=json.loads(aa['package/package.json']); assert metadata['private'] and metadata['version']=='0.1.0-rc.0'
        for name,content in aa.items():
            if name.endswith('.md'):
                original = repo/name.removeprefix('package/') if label=='core' else repo/('integrations/astro/README.md' if label=='astro' else 'integrations/languages/english/README.md')
                assert original.read_bytes()==content,(label,name)
        comparisons.append({'name':label,'productionFilesUnchanged':len(runtime),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size,'members':len(aa),'private':True,'version':metadata['version']})
patterns=[r'AKIA[0-9A-Z]{16}',r'gh[pousr]_[A-Za-z0-9]{25,}',r'github_pat_[A-Za-z0-9_]{30,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
findings=[]
for name,p in actual.items():
    for pattern in patterns:
        if re.search(pattern,p.read_text()): findings.append({'file':name,'pattern':pattern})
assert not findings
report={'status':'Pass','generatedManifestSha256':hashlib.sha256((repo/'docs/_pages-manifest.json').read_bytes()).hexdigest(),'publicFiles':len(actual),'publicBytes':sum(p.stat().st_size for p in actual.values()),'inputFiles':len(m['inputs']),'unchangedProtectedPaths':protected,'unrelatedPriorDiffPreserved':True,'priorClosedEvidenceUnchanged':True,'packageComparisons':comparisons,'heuristicPublicSecretScan':{'files':len(actual),'findings':findings,'scope':'Finite token/private-key patterns in allowlisted text output, not whole-history certification.'}}
(stage/'final-audit.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report))
