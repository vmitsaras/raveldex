from pathlib import Path
import json,hashlib,os
r=Path('/Users/vasilis/Documents/GitHub/raveldex');p=Path('/private/tmp/raveldex-rx7002-hec89x70')
b=json.loads((p/'before-hashes.json').read_text());a=json.loads((r/'docs/planning/roadmap.json').read_text());old=json.loads((p/'roadmap-before.json').read_text())
assert a['milestones']==old['milestones']
assert [t for t in a['tasks'] if t['id']!='RX-7002']==[t for t in old['tasks'] if t['id']!='RX-7002']
cur=next(t for t in a['tasks'] if t['id']=='RX-7002');prev=next(t for t in old['tasks'] if t['id']=='RX-7002')
for k in ['dependsOn','objective','acceptanceCriteria','verification']:assert cur[k]==prev[k],k
assert cur['affectedPaths']==prev['affectedPaths']+['src/addons/ui/dropdown.ts','test/ui/dropdown-browser.test.mjs']
assert cur['specs']==prev['specs']+['docs/specs/DROPDOWN.md']
pages={x['path'] for x in json.loads((p/'pages-before.json').read_text())['files']}|{x['path'] for x in json.loads((r/'docs/_pages-manifest.json').read_text())['files']}
allowed={'CHANGELOG.md','CODEX_HANDOFF.md','IMPLEMENTATION_TASKS.md','PROJECT_CONTEXT.md','README.md','ROADMAP.md','docs/api/HOSTS.md','docs/_pages-manifest.json','docs/planning/roadmap.json','docs/specs/DROPDOWN.md','docs/specs/SEARCH_SOLUTIONS.md','docs/planning/SEARCH_SOLUTIONS_IMPLEMENTATION_PLAN.md','examples/README.md','site/README.md','site/Inline.astro','site/Modal.astro','site/pages.mjs','site/starters.mjs','scripts/build-pages.mjs','scripts/lib/inline-starters.mjs','src/addons/ui/dropdown.ts','test/ui/dropdown-browser.test.mjs'}|{'docs/'+x for x in pages}
changed=[];unchanged=[];missing=[]
for f,h in b.items():
 if not (r/f).is_file():missing.append(f)
 elif hashlib.sha256((r/f).read_bytes()).hexdigest()==h:unchanged.append(f)
 else:changed.append(f)
assert not missing,missing
assert not (set(changed)-allowed),set(changed)-allowed
current=set()
for directory,dirs,files in os.walk(r):
 dirs[:]=[d for d in dirs if d not in {'.git','node_modules','dist','.astro','.tmp','.candidate'}]
 for name in files:current.add(str((Path(directory)/name).relative_to(r)))
added=sorted(current-set(b))
newallowed={'test/consumer/dropdown-browser-starter.test.mjs','test/pages/dropdown-starter.test.mjs','site/Dropdown.astro'}|{'docs/'+x for x in pages}
assert not [x for x in added if x not in newallowed and not x.startswith(('examples/dropdown-browser/','docs/evidence/RX-7002'))],added
assert all(f in unchanged for f in b if f not in {'src/addons/ui/dropdown.ts','test/ui/dropdown-browser.test.mjs'} and f.startswith(('src/','integrations/','test/ui/','examples/inline-browser/','examples/inline-astro/','examples/modal-browser/','examples/modal-astro/','docs/evidence/'))), 'Earlier runtime/starter/evidence bytes changed'
assert 'package.json' in unchanged and 'package-lock.json' in unchanged
out={'kind':'raveldex-rx7002-scope-audit-v1','status':'Pass','baselineFiles':len(b),'existingUnchanged':len(unchanged),'changedExisting':changed,'added':added,'missing':missing,'other49TaskObjectsUnchanged':True,'all9MilestonesUnchanged':True,'selectedAcceptanceDependenciesVerificationPreserved':True,'confirmedBoundedRuntimeRemediation':['src/addons/ui/dropdown.ts','test/ui/dropdown-browser.test.mjs'],'rootPackageAndLockfileUnchanged':True,'preserved':'All core/adapter/provider/integration source, UI outside the bounded dropdown blur repair, old UI tests outside its focused pointer regression, four prior installed starter trees and every earlier evidence file match task-start hashes.','scope':'Task-start dirty-worktree baseline, no attribution of prior changes.'}
(p/'scope-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='added'},indent=2));print('new task-owned files',len(added))
