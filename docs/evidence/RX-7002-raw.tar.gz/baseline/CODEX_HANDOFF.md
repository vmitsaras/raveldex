# Codex handoff

## Current boundary

The original 36 tasks, RX-6001–RX-6008 and [RX-7001](docs/evidence/RX-7001.md) are done: 45 complete and five planned out of 50. The new optional compact dropdown follows [DROPDOWN.md](docs/specs/DROPDOWN.md): borrowed engine, bounded real hits/exact totals, editable combobox with one-column native-popover grid, real links, explicit raw-query full-results URL, no-space recovery and opt-in shared shortcuts. Existing compiled core/legacy/inline/modal graphs, all four installed starter sources and earlier evidence are unchanged. RX-6008 retains its original inline/modal gallery and wrapper qualification scope.

The next recommended task is [RX-7002](IMPLEMENTATION_TASKS.md#rx-7002), complete installed dropdown header/full-results starters and gallery. [RX-7003](IMPLEMENTATION_TASKS.md#rx-7003), native directory state/URL integration, is independently ready. Read the concrete dropdown contract before adding its starter; the current API guide is a wiring fragment and requires the application to supply a matching real destination. Do not repeat N7 or RX-7001, add an engine, or change native page semantics. The current owner request covers RX-7001; later tasks need their own continuation.

RX-7001 final fresh-installed suites pass 24 grouped cases each in Chrome 156, cached Chromium 149 and Playwright WebKit 26.5, with exact installed-source identities. Independent review verifies lifecycle/edge repairs and actual Chrome CDP AX relationships. Required broad-check results, initial teardown timeouts and isolated reruns are separately recorded in its evidence. WebKit is not Safari: native Option+Tab traversal is labeled, and modified new-tab proof remains Blocked. Human AT/speech, physical IME/touch/on-screen keyboard and actual browser zoom are Not run; Firefox startup is Blocked. Dropdown graph is 19,719 minified / 7,467 gzip bytes; graph bytes are not memory/latency. Local safe Jekyll output exactly matches the 117-file public inventory. No remote CI, publication or broad accessibility claim follows.

RX-6008 passed 1,001 repository tests (846 main, 101 UI, 24 worker, 26 IndexedDB, one migration browser, three installed Astro), 11 site cases and 12 additional installed modal cases in Playwright WebKit 26.5, all with zero failures/skips/cancellations. Its 94 focused Chrome cases overlap the repository suite. Fresh root/help builds, exact archives, actual heading targets, published CSS, native counts/pages and new per-surface composition/no-results/Clear cases pass. Independent review reproduced/fixed inline status teardown and WebKit closed-loading-shell focus; final genuine-owner probes and installed regressions pass. Local Jekyll exactly matches 117 files; optional graphs are byte-identical to RX-6006. WebKit is not Safari. Human AT, physical input, actual 200%/400% zoom, broader devices/platforms and calibrated memory/latency remain Not run or Blocked; Firefox startup is blocked. No release or broad accessibility claim follows.

RX-6006's final synchronized check passed 985 repository tests (830 main, 101 UI, 24 worker, 26 IndexedDB, one migration browser, three installed Astro), including 26 new installed modal cases and the escaped-code link-audit regression. Native focus/Tab/Escape, deliberate pointer dismissal, query/filter preservation/reset, closed search, main/context cancellation, actual links, stale maps, worker loss, same-task native-close Promise gaps, shadow boundaries, multi-instance scroll/shortcut ownership and reentrant restoration execute. Independent review findings were fixed and reprobed. Long text retains full native accessible names with zero selected axe violations in three dark RTL/forced-colors emulated sizes. Native Tab can enter browser chrome without focusing authored background controls. Unknown opaque focused shadow-capable page regions are conservatively refused; unknown body-attached/inactive closed trees are not a global discovery promise.

The HTML documentation example exposed a tooling bug: escaped href/id text was audited as real tags. The corrected actual-opening-tag audit passes seven focused cases while still refusing genuine base/fragment errors. Nine final site browser cases and actual local Jekyll's complete 80-file byte comparison passed. Required post-roadmap `npm run check` records the extra tooling test in its own evidence. Human AT, physical input/mobile keyboard, actual zoom, other engines/devices, calibrated memory/latency, fresh remote CI and deployment remain unverified.

Core, English and Astro remain private `0.1.0-rc.0`. Documentation uses one **Unreleased** draft and a repository-only history archive. The subsequent owner request prepares a minimal docs/demo site for main-branch `/docs` publication; follow [site build/preview instructions](site/README.md), preserve Jekyll exclusions and never delete the existing docs tree. Activation, remote writes, package publication, tags, releases and visibility changes remain excluded.

Read [AGENTS.md](AGENTS.md), [current context](PROJECT_CONTEXT.md), [publication status](docs/release/PUBLICATION_STATUS.md) and the [documentation review](docs/planning/DOCUMENTATION_REVIEW.md) before continuing. For behavior changes, inspect the relevant task/specification, source and tests.

## Verification workflow

```sh
npm ci
npm run check
npm run handoff:status
npm run handoff:next
```

The planner recommends RX-7002 and also lists independently ready RX-7003. RX-6001–RX-6008 and RX-7001 have their own scoped acceptance evidence; the five remaining N8 tasks stay planned with empty evidence until their own implementation/verification occurs. The canonical manifest owns task state; readable plans are generated. Existing main CI tested exact source `3407c2a` with 860 tests on each Node 22/24 job. Later documentation/artifact changes need their own recorded verification; historical CI never qualifies changed bytes automatically.

For a new private candidate verification, use a fresh output directory:

```sh
npm run candidate:prepare -- --output /tmp/raveldex-candidate-review
```

Preparation retains private metadata and does not publish. Separate English/Astro pack scripts must consume the same stable compiler output when artifact identity is being reviewed. Release metadata requires a separately implemented verification path; do not weaken candidate guards to make a public release pass.

## Preserve boundaries

- No foreign engine beneath core, hidden optional retention or import-time host initialization.
- Preserve exact totals/revisions/scores, original UTF-16 coordinates, explicit capabilities/errors and resource limits.
- Keep source recovery and exact-Node native qualification distinct; unknown transport/storage outcomes do not authorize blind retries.
- Preserve failed/refused observations and scoped AT/memory findings. Do not turn automated checks into speech, physical-input, physical-copy or all-platform claims.
- `tracking:preview` is local. `tracking:sync` is an explicit remote write requiring an authorized token/environment.

Report what changed, actual verification, limitations and next eligible work. Local completion does not imply remote CI or publication. The [maintainer history](docs/history/CANDIDATE_HISTORY.md) preserves earlier candidate narratives without competing with current guidance.

The [Pages preparation record](docs/evidence/PAGES-20261030.md) owns local site results and the remaining eligibility/hosted-build checks. `npm run pages:preview` serves only the approved public inventory; do not serve the full evidence-bearing docs tree or add `.nojekyll`.

The latest [usage documentation record](docs/evidence/USAGE-DOCS-20261030.md) supersedes the earlier site's content structure. Keep public guidance about using Raveldex; retain dated confirmations/CI/qualification narratives in maintainer records. Ordinary browser/Pages demos use `prepareUsageDemo` and five usage guides. Preserve `prepareUIPilot`, the original corpus/judgments and independent qualification expectations when changing demo copy.

The [plain-language documentation record](docs/evidence/NATURAL-DOCS-20261030.md) follows that rewrite. It records fresh verification of the more natural prose and example explanations, with code blocks, heading links, styling and runtime behavior preserved. Keep setup and expected outcomes next to examples; do not turn partial configuration/query fragments into claims of standalone execution.

The subsequent owner-selected Search Workbench design is implemented through the shared site shell, Home/Demo Astro pages and SearchWorkbench component. Home uses the real packed demo bundle with one hit and one configured short snippet, preserving exact totals and omission notices. Home and the ordinary demo default to final-word prefix search through optional UI `mode: 'prefix'`; earlier words are exact, two normalized code points enable completion and shorter endings remain exact. Advanced settings retain exact-word and strict-phrase modes. Integrations omitting the UI mode and the frozen qualification pilot retain exact-word defaults. The final prefix matrix checks direct/worker execution with source/offset snippets; allow 180 seconds for both site browser suites. Follow [site/README.md](site/README.md), the [design contract](docs/specs/SITE_WORKBENCH.md) and N6 evidence. Run both `test/pages/browser.test.mjs` and `test/pages/workbench.test.mjs` after generated-site changes. No deployment, remote tracking write or release was part of this implementation.
