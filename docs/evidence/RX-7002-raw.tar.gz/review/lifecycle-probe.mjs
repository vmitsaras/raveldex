import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {build} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/esbuild/lib/main.js';
import {chromium,webkit} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
const root='/Users/vasilis/Documents/GitHub/raveldex', out='/private/tmp/raveldex-rx7002-hec89x70/review';
const sourcePaths=['examples/dropdown-browser/controller.mjs','examples/dropdown-browser/configuration.mjs','examples/dropdown-browser/content.mjs','examples/dropdown-browser/theme.css'];
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const hashes=Object.fromEntries(await Promise.all(sourcePaths.map(async p=>[p,hash(await readFile(root+'/'+p))])));
const entry=`export {createHeaderSearch} from ${JSON.stringify(root+'/examples/dropdown-browser/controller.mjs')};export {createRaveldex} from ${JSON.stringify(root+'/dist/index.js')};export {readInitialQuery} from ${JSON.stringify(root+'/examples/dropdown-browser/configuration.mjs')};`;
const result=await build({stdin:{contents:entry,resolveDir:root,sourcefile:'independent-entry.mjs'},outfile:out+'/probe.js',bundle:true,format:'esm',platform:'browser',target:'es2022',metafile:true,logLevel:'silent',plugins:[{name:'compiled-native-alias',setup(b){b.onResolve({filter:/^@vmitsaras\/raveldex(?:\/.*)?$/},args=>({path:args.path==='@vmitsaras/raveldex'?root+'/dist/index.js':root+'/dist/'+args.path.slice('@vmitsaras/raveldex/'.length)+'.js'}));}}]});
await writeFile(out+'/probe-meta.json',JSON.stringify(result.metafile,null,2));
const css=(await Promise.all(['dist/addons/ui/dropdown.css','dist/addons/ui/inline.css','dist/addons/ui/modal.css','examples/dropdown-browser/theme.css'].map(p=>readFile(root+'/'+p,'utf8')))).join('\n');
await writeFile(out+'/probe.css',css);
const html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/probe.css"></head><body><main><div id="root"><span id="original">Original header</span></div><p id="status"></p><button id="retry" hidden>Retry</button><button id="trigger" hidden>Open expanded search</button><div id="modal"></div><div id="full"></div><button id="outside">Outside</button></main><script type="module">window.demo=await import("/probe.js");window.makeOwner=async()=>{const engine=window.demo.createRaveldex({schema:{text:{title:{boost:2},body:{}}}});await engine.addMany([{id:"alpha",text:{title:"Alpha guide",body:"shared alpha guide"}},{id:"beta",text:{title:"Beta guide",body:"shared beta guide"}},{id:"other",text:{title:"Other guide",body:"shared guide"}}]);let count=0;return {engine,documents:[{id:"alpha",title:"Alpha guide",url:"/guide/alpha/"},{id:"beta",title:"Beta guide",url:"/guide/beta/"},{id:"other",title:"Other guide",url:"/guide/other/"}],dispose(){count++;return engine.dispose();},count:()=>count};};window.ready=true;</script></body></html>';
const server=createServer(async(req,res)=>{try{if(req.url==='/probe.js'){res.setHeader('content-type','text/javascript');res.end(await readFile(out+'/probe.js'));}else if(req.url==='/probe.css'){res.setHeader('content-type','text/css');res.end(css);}else{res.setHeader('content-type','text/html');res.end(html);}}catch(e){res.writeHead(500).end(String(e));}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url='http://127.0.0.1:'+server.address().port;
const reports=[];
try{
 for(const [name,type,options] of [['chrome',chromium,{channel:'chrome'}],['webkit',webkit,{}]]){
  let browser;try{
   browser=await type.launch({headless:true,...options});const observations=[];const errors=[];
   async function fresh(){const page=await browser.newPage({viewport:{width:1100,height:900}});page.setDefaultTimeout(5000);page.on('pageerror',e=>errors.push(String(e)));await page.goto(url);await page.waitForFunction(()=>window.ready);return page;}
   for(const action of ['loading-status-destroy','late-owner-destroy','header-disconnection','modal-disconnection','trigger-focus-destroy','failure-disposal-wait']){
    const page=await fresh();const data=await page.evaluate(async action=>{
     const root=document.querySelector('#root'),status=document.querySelector('#status'),retry=document.querySelector('#retry'),trigger=document.querySelector('#trigger'),modalRoot=document.querySelector('#modal');
     const nativeText=Object.getOwnPropertyDescriptor(Node.prototype,'textContent');
     const owner=await makeOwner();let c,loads=0,disposal,release,entered,work;
     const gate=new Promise(r=>{release=r;});
     const enteredPromise=new Promise(r=>{entered=r;});
     const options={root,status,retry,fullResultsURL:location.origin+'/search/?from=header#results',modalRoot,modalTrigger:trigger,modalHandoff:true};
     const original=root.firstChild;
     if(action==='loading-status-destroy'){
      Object.defineProperty(status,'textContent',{configurable:true,get(){return nativeText.get.call(this);},set(value){nativeText.set.call(this,value);if(value.startsWith('Loading search')){const nested=c.start();window.nestedSame=nested===work;disposal=c.destroy();}}});
      c=demo.createHeaderSearch({...options,load:async()=>{loads++;return owner;}});work=c.start();await work;await disposal;
      const answer={action,loads,nestedSame:window.nestedSame,rootRestored:root.firstChild===original,uiCount:root.querySelectorAll('.raveldex-dropdown').length};await owner.dispose();return answer;
     }
     if(action==='late-owner-destroy'){
      c=demo.createHeaderSearch({...options,load:async()=>{loads++;entered();await gate;return owner;}});work=c.start();await enteredPromise;disposal=c.destroy();const stable=disposal===c.destroy();release();await Promise.all([work,disposal]);return {action,loads,stable,disposals:owner.count(),rootRestored:root.firstChild===original,uiCount:root.querySelectorAll('.raveldex-dropdown').length};
     }
     if(action==='header-disconnection'||action==='modal-disconnection'){
      const host=action==='header-disconnection'?root:modalRoot;customElements.define('review-disconnect',class extends HTMLElement{disconnectedCallback(){disposal=c.destroy();}});const authored=document.createElement('review-disconnect');authored.textContent='Authored';host.replaceChildren(authored);
      c=demo.createHeaderSearch({...options,load:async()=>{loads++;return owner;}});work=c.start();await work;if(action==='modal-disconnection')await c.openModal();await disposal;
      return {action,loads,disposals:owner.count(),authoredNodeRestored:host.firstChild===authored,uiCount:document.querySelectorAll('.raveldex-dropdown,.raveldex-modal').length};
     }
     if(action==='trigger-focus-destroy'){
      c=demo.createHeaderSearch({...options,load:async()=>{loads++;return owner;}});await c.start();root.querySelector('input').value='alpha';root.querySelector('input').focus();trigger.addEventListener('focus',()=>{disposal=c.destroy();},{once:true});await c.openModal();await disposal;return {action,loads,disposals:owner.count(),rootRestored:root.firstChild===original,uiCount:document.querySelectorAll('.raveldex-dropdown,.raveldex-modal').length};
     }
     if(action==='failure-disposal-wait'){
      let disposeEntered;const cleanupEntered=new Promise(r=>{disposeEntered=r;});const nativeDispose=owner.dispose;owner.dispose=async()=>{await nativeDispose();disposeEntered();await gate;};
      Object.defineProperty(status,'textContent',{configurable:true,get(){return nativeText.get.call(this);},set(value){nativeText.set.call(this,value);if(value==='Search is ready.')throw new Error('Authored ready-status refusal');}});
      c=demo.createHeaderSearch({...options,load:async()=>{loads++;return owner;}});work=c.start();await cleanupEntered;let settled=false;disposal=c.destroy();void disposal.then(()=>{settled=true;});await new Promise(r=>setTimeout(r,0));const settledBeforeRelease=settled;const stable=disposal===c.destroy();release();await Promise.all([work,disposal]);return {action,loads,disposals:owner.count(),stable,settledBeforeRelease,settledAfterRelease:settled,rootRestored:root.firstChild===original};
     }
    },action);
    if(action==='loading-status-destroy'){assert.equal(data.loads,0);assert.equal(data.nestedSame,true);assert.equal(data.rootRestored,true);assert.equal(data.uiCount,0);}
    else{assert.equal(data.disposals,1);if('uiCount' in data)assert.equal(data.uiCount,0);if('rootRestored' in data)assert.equal(data.rootRestored,true);if('authoredNodeRestored' in data)assert.equal(data.authoredNodeRestored,true);if('stable' in data)assert.equal(data.stable,true);if('settledBeforeRelease' in data){assert.equal(data.settledBeforeRelease,false);assert.equal(data.settledAfterRelease,true);}}
    observations.push(data);await page.close();
   }
   reports.push({engine:name,browser:browser.version(),observations,pageErrors:errors});
  }finally{await browser?.close();}
 }
}finally{await new Promise(r=>server.close(r));}
const finalHashes=Object.fromEntries(await Promise.all(sourcePaths.map(async p=>[p,hash(await readFile(root+'/'+p))])));
const report={kind:'raveldex-rx7002-independent-reentry-probe-v1',sourceSHA256:hashes,sourceUnchanged:JSON.stringify(hashes)===JSON.stringify(finalHashes),compiledCoreSHA256:hash(await readFile(root+'/dist/index.js')),scope:'Source-bundled application wrapper plus actual compiled native core/UI. Tool-driven focus/click events, no human AT or physical input. Not a fresh installed consumer.',reports};
await writeFile(out+'/independent-lifecycle.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
