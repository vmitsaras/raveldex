import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {build} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/esbuild/lib/main.js';
import {chromium,webkit} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
const root='/Users/vasilis/Documents/GitHub/raveldex', out='/private/tmp/raveldex-rx7002-hec89x70/review';
const sourcePaths=['examples/dropdown-browser/controller.mjs','examples/dropdown-browser/configuration.mjs','examples/dropdown-browser/content.mjs','examples/dropdown-browser/theme.css','src/addons/ui/dropdown.ts','dist/addons/ui/dropdown.js','dist/addons/ui/inline.js','dist/addons/ui/modal.js'];
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const hashes=Object.fromEntries(await Promise.all(sourcePaths.map(async p=>[p,hash(await readFile(root+'/'+p))])));
const entry=`export {mountRaveldexDropdown} from ${JSON.stringify(root+'/dist/addons/ui/dropdown.js')};export {createHeaderSearch} from ${JSON.stringify(root+'/examples/dropdown-browser/controller.mjs')};export {createRaveldex} from ${JSON.stringify(root+'/dist/index.js')};export {readInitialQuery} from ${JSON.stringify(root+'/examples/dropdown-browser/configuration.mjs')};`;
const result=await build({stdin:{contents:entry,resolveDir:root,sourcefile:'independent-entry.mjs'},outfile:out+'/probe.js',bundle:true,format:'esm',platform:'browser',target:'es2022',metafile:true,logLevel:'silent',plugins:[{name:'compiled-native-alias',setup(b){b.onResolve({filter:/^@vmitsaras\/raveldex(?:\/.*)?$/},args=>({path:args.path==='@vmitsaras/raveldex'?root+'/dist/index.js':root+'/dist/'+args.path.slice('@vmitsaras/raveldex/'.length)+'.js'}));}}]});
await writeFile(out+'/probe-meta.json',JSON.stringify(result.metafile,null,2));
const css=(await Promise.all(['dist/addons/ui/dropdown.css','dist/addons/ui/inline.css','dist/addons/ui/modal.css','examples/dropdown-browser/theme.css'].map(p=>readFile(root+'/'+p,'utf8')))).join('\n');
await writeFile(out+'/probe.css',css);
const html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/probe.css"></head><body><main><div id="root"><span id="original">Original header</span></div><p id="status"></p><button id="retry" hidden>Retry</button><button id="trigger" hidden>Open expanded search</button><div id="modal"></div><div id="full"></div><button id="outside">Outside</button></main><script type="module">window.demo=await import("/probe.js");window.makeOwner=async()=>{const engine=window.demo.createRaveldex({schema:{text:{title:{boost:2},body:{}}}});await engine.addMany([{id:"alpha",text:{title:"Alpha guide",body:"shared alpha guide"}},{id:"beta",text:{title:"Beta guide",body:"shared beta guide"}},{id:"other",text:{title:"Other guide",body:"shared guide"}}]);let count=0;return {engine,documents:[{id:"alpha",title:"Alpha guide",url:"/guide/alpha/"},{id:"beta",title:"Beta guide",url:"/guide/beta/"},{id:"other",title:"Other guide",url:"/guide/other/"}],dispose(){count++;return engine.dispose();},count:()=>count};};window.ready=true;</script></body></html>';
const server=createServer(async(req,res)=>{try{if(req.url==='/probe.js'){res.setHeader('content-type','text/javascript');res.end(await readFile(out+'/probe.js'));}else if(req.url==='/probe.css'){res.setHeader('content-type','text/css');res.end(css);}else{res.setHeader('content-type','text/html');res.end(html);}}catch(e){res.writeHead(500).end(String(e));}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url='http://127.0.0.1:'+server.address().port;
const reports=[];
try{
 for(const [name,type,options] of [['chrome',chromium,{channel:'chrome'}],['webkit',webkit,{}]]){
  let browser;try{
   browser=await type.launch({headless:true,...options});const observations=[];const errors=[];
   async function fresh(){const page=await browser.newPage({viewport:{width:1100,height:900}});page.setDefaultTimeout(5000);page.on('pageerror',e=>errors.push(String(e)));await page.goto(url);await page.waitForFunction(()=>window.ready);return page;}
   for(const action of ['standalone','wrapper-after-retry']){
    const page=await fresh(),trace=[];page.on('console',msg=>{if(msg.text().startsWith('REVIEWTRACE '))trace.push(JSON.parse(msg.text().slice(12)));});
    const setup=await page.evaluate(async action=>{
     const owner=await makeOwner(),root=document.querySelector('#root');root.style.width='404px';owner.documents[0].title='Plan an alpha walking trip — a detailed guide to a long and welcoming route';let loads=0;
     if(action==='standalone'){window.view=demo.mountRaveldexDropdown({root,engine:owner.engine,documents:owner.documents,fullResults:{url:location.origin+'/search/'},maxResults:3});}
     else{window.controller=demo.createHeaderSearch({root,status:document.querySelector('#status'),retry:document.querySelector('#retry'),load:async()=>{if(++loads===1)throw new Error('Controlled first load failure');return owner;},fullResultsURL:location.origin+'/search/'});await controller.start();}
     window.reviewOwner=owner;
     for(const type of ['pointerdown','mousedown','pointerup','mouseup','blur','focusin','focusout','click','beforetoggle'])document.addEventListener(type,e=>console.log('REVIEWTRACE '+JSON.stringify({type,target:e.target.tagName,classes:e.target.className,trusted:e.isTrusted,related:e.relatedTarget?.className,active:document.activeElement?.className,popup:!!document.querySelector(':popover-open'),state:e.newState})),true);
     return {action,loads};
    },action);
    if(action==='wrapper-after-retry'){await page.locator('#retry').click();await page.getByText('Search is ready.',{exact:true}).waitFor();}
    const input=page.locator('#root input');await input.fill('alpha');await input.press('Enter');const link=page.locator('[data-raveldex-dropdown-result] a').first();await link.waitFor();const href=await link.getAttribute('href');const before=await link.evaluate(n=>({href:n.href,rect:n.getBoundingClientRect().toJSON(),documentHasFocus:document.hasFocus(),active:document.activeElement?.className,hit:document.elementFromPoint(n.getBoundingClientRect().left+n.getBoundingClientRect().width/2,n.getBoundingClientRect().top+n.getBoundingClientRect().height/2)?.className}));
    await link.click();await page.waitForURL(href,{timeout:5000});assert.equal(page.url(),url+'/guide/alpha/');assert.ok(trace.some(e=>e.type==='click'&&e.target==='A'&&e.trusted));observations.push({...setup,before,actualURL:page.url(),trustedTrace:trace});await page.close();
   }
   assert.deepEqual(errors,[]);reports.push({engine:name,browser:browser.version(),observations,pageErrors:errors});
  }finally{await browser?.close();}
 }
}finally{await new Promise(r=>server.close(r));}
const graphHashes=Object.fromEntries(await Promise.all(Object.keys(result.metafile.inputs).filter(p=>p!=='independent-entry.mjs'&&p!=='<stdin>').map(async p=>[p,hash(await readFile(p.startsWith('/')?p:root+'/'+p))])));
const finalHashes=Object.fromEntries(await Promise.all(sourcePaths.map(async p=>[p,hash(await readFile(root+'/'+p))])));
const report={kind:'raveldex-rx7002-independent-reentry-probe-v1',sourceSHA256:hashes,sourceUnchanged:JSON.stringify(hashes)===JSON.stringify(finalHashes),compiledCoreSHA256:hash(await readFile(root+'/dist/index.js')),graphInputSHA256:graphHashes,scope:'Source-bundled application wrapper plus actual compiled native core/UI. Tool-driven focus/click events, no human AT or physical input. Not a fresh installed consumer.',reports};
await writeFile(out+'/final-native-links.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
