import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {build} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/esbuild/lib/main.js';
import {chromium,webkit} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
const root='/Users/vasilis/Documents/GitHub/raveldex', out='/private/tmp/raveldex-rx7002-hec89x70/review';
const sourcePaths=['examples/dropdown-browser/controller.mjs','examples/dropdown-browser/configuration.mjs','examples/dropdown-browser/content.mjs','examples/dropdown-browser/theme.css'];
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const hashes=Object.fromEntries(await Promise.all(sourcePaths.map(async p=>[p,hash(await readFile(root+'/'+p))])));
const entry=`export {createHeaderSearch} from ${JSON.stringify(root+'/examples/dropdown-browser/controller.mjs')};export {createRaveldex} from ${JSON.stringify(root+'/dist/index.js')};export {readInitialQuery} from ${JSON.stringify(root+'/examples/dropdown-browser/configuration.mjs')};`;
const result=await build({stdin:{contents:entry,resolveDir:root,sourcefile:'independent-entry.mjs'},outfile:out+'/probe.js',bundle:true,format:'esm',platform:'browser',target:'es2022',metafile:true,logLevel:'silent',plugins:[{name:'compiled-native-alias',setup(b){b.onResolve({filter:/^@vmitsaras\/raveldex(?:\/.*)?$/},args=>({path:args.path==='@vmitsaras/raveldex'?root+'/dist/index.js':root+'/dist/'+args.path.slice('@vmitsaras/raveldex/'.length)+'.js'}));}}]});
await writeFile(out+'/probe-meta.json',JSON.stringify(result.metafile,null,2));
const css=(await Promise.all(['dist/addons/ui/dropdown.css','dist/addons/ui/inline.css','dist/addons/ui/modal.css','examples/dropdown-browser/theme.css'].map(p=>readFile(root+'/'+p,'utf8')))).join('\n');
await writeFile(out+'/probe.css',css);
const html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/probe.css"></head><body><main><div id="root"><span id="original">Original header</span></div><p id="status"></p><button id="retry" hidden>Retry</button><button id="trigger" hidden>Open expanded search</button><div id="modal"></div><div id="full"></div><button id="outside">Outside</button></main><script type="module">window.demo=await import("/probe.js");window.makeOwner=async()=>{const engine=window.demo.createRaveldex({schema:{text:{title:{boost:2},body:{}}}});await engine.addMany([{id:"alpha",text:{title:"Alpha guide",body:"shared alpha guide"}},{id:"beta",text:{title:"Beta guide",body:"shared beta guide"}},{id:"other",text:{title:"Other guide",body:"shared guide"}}]);let count=0;return {engine,documents:[{id:"alpha",title:"Alpha guide",url:"/guide/alpha/"},{id:"beta",title:"Beta guide",url:"/guide/beta/"},{id:"other",title:"Other guide",url:"/guide/other/"}],dispose(){count++;return engine.dispose();},count:()=>count};};window.ready=true;</script></body></html>';
const server=createServer(async(req,res)=>{try{if(req.url==='/probe.js'){res.setHeader('content-type','text/javascript');res.end(await readFile(out+'/probe.js'));}else if(req.url==='/probe.css'){res.setHeader('content-type','text/css');res.end(css);}else{res.setHeader('content-type','text/html');res.end(html);}}catch(e){res.writeHead(500).end(String(e));}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url='http://127.0.0.1:'+server.address().port;
const reports=[];
try{
 for(const [name,type,options] of [['chrome',chromium,{channel:'chrome'}],['webkit',webkit,{}]]){
  let browser;try{
   browser=await type.launch({headless:true,...options});const observations=[];const errors=[];
   async function fresh(){const page=await browser.newPage({viewport:{width:1100,height:900}});page.setDefaultTimeout(5000);page.on('pageerror',e=>errors.push(String(e)));await page.goto(url);await page.waitForFunction(()=>window.ready);return page;}
   for(const action of ['nested-open','nested-open-close','nested-refused']){
    const page=await fresh();const data=await page.evaluate(async action=>{
     const owner=await makeOwner(), root=document.querySelector('#root'), trigger=document.querySelector('#trigger');
     const c=demo.createHeaderSearch({root,status:document.querySelector('#status'),retry:document.querySelector('#retry'),load:async()=>owner,fullResultsURL:location.origin+'/search/?from=header#results',modalRoot:document.querySelector('#modal'),modalTrigger:trigger,modalHandoff:true});
     await c.start();const field=root.querySelector('input');field.value='alpha';field.focus();let inner;
     trigger.addEventListener('focus',()=>{field.value=action==='nested-refused'?'x'.repeat(2049):'beta';inner=c.openModal();if(action==='nested-open-close')document.querySelector('.raveldex-modal__close').click();},{once:true});
     const outer=c.openModal();await Promise.all([outer,inner]);await new Promise(r=>setTimeout(r,40));
     const state={action,header:field.value.length>100?'oversize:'+field.value.length:field.value,open:!!document.querySelector('dialog[open]'),modalQuery:document.querySelector('.raveldex-modal input')?.value,ids:[...document.querySelectorAll('.raveldex-modal [data-raveldex-inline-result]')].map(x=>x.dataset.raveldexInlineResult),feedback:document.querySelector('#status').textContent,active:document.activeElement?.outerHTML.slice(0,180)};
     await c.destroy();state.disposals=owner.count();return state;
    },action);observations.push(data);await page.close();
   }
   reports.push({engine:name,browser:browser.version(),observations,pageErrors:errors});
  }finally{await browser?.close();}
 }
}finally{await new Promise(r=>server.close(r));}
const finalHashes=Object.fromEntries(await Promise.all(sourcePaths.map(async p=>[p,hash(await readFile(root+'/'+p))])));
const report={kind:'raveldex-rx7002-independent-reentry-probe-v1',sourceSHA256:hashes,sourceUnchanged:JSON.stringify(hashes)===JSON.stringify(finalHashes),compiledCoreSHA256:hash(await readFile(root+'/dist/index.js')),scope:'Source-bundled application wrapper plus actual compiled native core/UI. Tool-driven focus/click events, no human AT or physical input. Not a fresh installed consumer.',reports};
await writeFile(out+'/independent-reentry.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
