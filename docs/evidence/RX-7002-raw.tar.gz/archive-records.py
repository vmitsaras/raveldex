from pathlib import Path
import json,gzip,shutil,tarfile,hashlib
r=Path('/Users/vasilis/Documents/GitHub/raveldex');p=Path('/private/tmp/raveldex-rx7002-hec89x70');e=r/'docs/evidence'
if (p/'tests/handoff-summary.json').is_file():
 f=e/'RX-7002-browser-summary.json';s=json.loads(f.read_text());s['testAgentHandoff']=json.loads((p/'tests/handoff-summary.json').read_text());f.write_text(json.dumps(s,indent=2)+'\n');(p/'browser-summary.json').write_text(json.dumps(s,indent=2)+'\n')
v=json.loads((e/'RX-7002-verification.json').read_text())
for name,h in v['sourceSHA256'].items():
 assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h,name
 t=p/'final-source'/name;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,t)
for name in ['PROJECT_CONTEXT.md','CODEX_HANDOFF.md','docs/specs/DROPDOWN.md','docs/specs/SEARCH_SOLUTIONS.md','docs/planning/SEARCH_SOLUTIONS_IMPLEMENTATION_PLAN.md','docs/planning/roadmap.json','ROADMAP.md','IMPLEMENTATION_TASKS.md','site/Inline.astro','site/Modal.astro','site/README.md','examples/README.md']:
 t=p/'final-source'/name;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,t)
report=json.loads((p/'tests/final-chrome.json').read_text());package=Path(report['consumer']['directory'])/report['consumer']['packedFilename'];assert hashlib.sha256(package.read_bytes()).hexdigest()==report['package']['sha256']
(p/'final-packages').mkdir(exist_ok=True);shutil.copyfile(package,p/'final-packages/final-browser-package.tgz')
for a,b in {'site/run.log':'site.log.gz','pages.log':'pages.log.gz','jekyll.log':'jekyll.log.gz','tests/runtime-before.log':'runtime-before.log.gz','synchronized-check.log':'synchronized-check.log.gz','pages-build.log':'pages-build.log.gz'}.items():
 if (p/a).is_file():(e/('RX-7002-'+b)).write_bytes(gzip.compress((p/a).read_bytes(),mtime=0))
selected=[]
for directory in ['tests','review','starter','baseline','site','final-source','final-packages']:
 selected.extend(f for f in (p/directory).rglob('*') if f.is_file())
selected.extend(f for f in p.iterdir() if f.is_file() and f.suffix in {'.json','.log','.mjs','.py'})
with tarfile.open(e/'RX-7002-raw.tar.gz','w:gz') as tar:
 for f in sorted(set(selected)):tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
print('Archived',len(set(selected)),'raw artifacts and exact source/private package identities; installed dependency trees excluded.')
