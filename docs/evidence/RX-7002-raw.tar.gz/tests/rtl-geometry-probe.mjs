import {chromium} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import {readFile,writeFile} from 'node:fs/promises';import{spawn}from'node:child_process';import{once}from'node:events';import{createServer}from'node:net';
const dir=JSON.parse(await readFile('/private/tmp/raveldex-rx7002-hec89x70/tests/final-chrome.json','utf8')).observations[0].evidence.directory;
const reserve=createServer();reserve.listen(0,'127.0.0.1');await once(reserve,'listening');const port=reserve.address().port,c=once(reserve,'close');reserve.close();await c;
const server=spawn(process.execPath,['preview.mjs','--port',String(port)],{cwd:dir,env:{...process.env,RAVELDEX_DROPDOWN_BASE:'/'},stdio:['ignore','pipe','pipe']});const exited=once(server,'exit');let log='';server.stdout.on('data',x=>log+=x);while(!log.includes('Open http:'))await new Promise(r=>setTimeout(r,20));
const browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage({viewport:{width:320,height:568},colorScheme:'dark',reducedMotion:'reduce'});page.setDefaultTimeout(5000);
try{
 await page.goto(`http://127.0.0.1:${port}/search/?q=walking%20gui#results`);await page.locator('[data-raveldex-inline-result]').nth(2).waitFor();await page.evaluate(()=>document.documentElement.dir='rtl');
 const data=await page.evaluate(()=>({scrollX,scrollY,innerWidth,docWidth:document.documentElement.scrollWidth,controls:[...document.querySelectorAll('.raveldex-dropdown__input,.raveldex-inline__input,.raveldex-inline__navigation button')].map(n=>({cls:n.className,rect:n.getBoundingClientRect().toJSON(),display:getComputedStyle(n).display,visibility:getComputedStyle(n).visibility,hidden:n.hidden,disabled:n.disabled}))}));
 await page.evaluate(()=>scrollTo(0,0));await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await page.screenshot({path:'/private/tmp/raveldex-rx7002-hec89x70/tests/rtl-from-top.png',fullPage:true});
 await page.getByRole('button',{name:'Load more',exact:true}).click();await page.locator('[data-raveldex-inline-result]').nth(5).waitFor();data.nativeLoadMoreCount=await page.locator('[data-raveldex-inline-result]').count();
 await writeFile('/private/tmp/raveldex-rx7002-hec89x70/tests/rtl-geometry-probe.json',JSON.stringify(data,null,2)+'\n');console.log(JSON.stringify(data,null,2));
}finally{await browser.close();server.kill('SIGTERM');await exited;}
