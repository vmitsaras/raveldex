import {chromium} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import {readFile,writeFile} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {createServer} from 'node:net';
const dir=JSON.parse(await readFile('/private/tmp/raveldex-rx7002-hec89x70/tests/chrome-reviewed.json','utf8')).observations[0].evidence.directory;
const res=createServer();res.listen(0,'127.0.0.1');await once(res,'listening');const port=res.address().port;const closed=once(res,'close');res.close();await closed;
const server=spawn(process.execPath,['preview.mjs','--port',String(port)],{cwd:dir,env:{...process.env,RAVELDEX_DROPDOWN_BASE:'/'},stdio:['ignore','pipe','pipe']}); const exited=once(server,'exit');let stdout='';server.stdout.on('data',x=>stdout+=x);server.stderr.on('data',x=>stdout+=x);
while(!stdout.includes('Open http:')){if(server.exitCode!==null)throw Error(stdout);await new Promise(r=>setTimeout(r,20));}
const browser=await chromium.launch({channel:'chrome',headless:true}); const out=[];
try{
 for(const failure of [false,true]){
  const page=await browser.newPage();page.setDefaultTimeout(5000);const network=[];page.on('request',r=>network.push(r.url()));
  if(failure)await page.route('**/content.json',r=>r.fulfill({status:503,body:'unavailable'}));
  await page.goto(`http://127.0.0.1:${port}/`);
  if(failure){await page.locator('[data-search-retry]').waitFor();await page.unroute('**/content.json');await page.locator('[data-search-retry]').click();}
  await page.getByText('Search is ready.',{exact:true}).waitFor();const input=page.locator('[data-raveldex-dropdown-input]');await input.fill('riverside');await input.press('Enter');const link=page.locator('[data-raveldex-dropdown-result] a');await link.waitFor();
  await page.evaluate(()=>{window.events=[];const input=document.querySelector('[data-raveldex-dropdown-input]');
   for(const type of ['pointerdown','mousedown','pointerup','mouseup','click','focusin','focusout','blur','beforetoggle','toggle','scroll'])document.addEventListener(type,e=>{window.events.push({type,target:e.target.tagName,cls:e.target.className,active:document.activeElement?.className,defaultPrevented:e.defaultPrevented,trusted:e.isTrusted,state:e.newState,x:e.clientX,y:e.clientY,scrollY,popup:!!document.querySelector(':popover-open')});},true);
   window.addEventListener('blur',()=>window.events.push({type:'window-blur'}));
  });
  const before=await link.evaluate(n=>{const rect=n.getBoundingClientRect(),hit=document.elementFromPoint(rect.left+rect.width/2,rect.top+rect.height/2);return{href:n.href,rect:rect.toJSON(),popup:document.querySelector(':popover-open')?.getBoundingClientRect().toJSON(),hit:{tag:hit?.tagName,cls:hit?.className,text:hit?.textContent?.slice(0,80)},active:document.activeElement?.className,hasFocus:document.hasFocus(),scrollY};});
  await link.click();await page.waitForTimeout(100); const after={url:page.url(),events:await page.evaluate(()=>window.events),state:await page.locator('.raveldex-dropdown').getAttribute('data-state')};
  out.push({failure,before,after,network});await page.close();
 }
}finally{await browser.close();server.kill('SIGTERM');await exited;}
await writeFile('/private/tmp/raveldex-rx7002-hec89x70/tests/pointer-probe.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
