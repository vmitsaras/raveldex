import {chromium,webkit} from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import {readFile,writeFile} from'node:fs/promises';import{spawn}from'node:child_process';import{once}from'node:events';import{createServer}from'node:net';import assert from'node:assert/strict';
const root='/private/tmp/raveldex-rx7002-hec89x70/tests';const source=JSON.parse(await readFile(root+'/final-chrome.json','utf8'));const dir=source.observations[0].evidence.directory;const expected=source.observations.find(x=>x.name==='native full route /').evidence.expectedIDs;
const reservation=createServer();reservation.listen(0,'127.0.0.1');await once(reservation,'listening');const port=reservation.address().port,closed=once(reservation,'close');reservation.close();await closed;
const child=spawn(process.execPath,['preview.mjs','--port',String(port)],{cwd:dir,env:{...process.env,RAVELDEX_DROPDOWN_BASE:'/'},stdio:['ignore','pipe','pipe']});const exited=once(child,'exit');let log='';child.stdout.on('data',x=>log+=x);const deadline=Date.now()+10000;while(!log.includes('Open http:')){assert.equal(child.exitCode,null,log);assert.ok(Date.now()<deadline,log);await new Promise(r=>setTimeout(r,20));}
const observations=[];
try{
 for(const engine of ['chrome','chromium','webkit']){
  const browser=engine==='webkit'?await webkit.launch({headless:true}):await chromium.launch({...(engine==='chrome'?{channel:'chrome'}:{}),headless:true});
  try{
   for(const forcedColors of ['none','active']){
    const context=await browser.newContext({viewport:{width:320,height:568},colorScheme:'dark',forcedColors,reducedMotion:'reduce'});const page=await context.newPage();page.setDefaultTimeout(5000);
    await page.goto(`http://127.0.0.1:${port}/search/?q=walking%20gui#results`);await page.locator('[data-raveldex-inline-result]').nth(2).waitFor();await page.evaluate(()=>{document.documentElement.dir='rtl';scrollTo(0,0);});await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
    const geometry=await page.evaluate(()=>({direction:getComputedStyle(document.documentElement).direction,scrollX,scrollY,viewportWidth:innerWidth,documentWidth:document.documentElement.scrollWidth,dark:matchMedia('(prefers-color-scheme: dark)').matches,forced:matchMedia('(forced-colors: active)').matches,controls:[...document.querySelectorAll('.raveldex-dropdown__input,.raveldex-inline__input,.raveldex-inline__navigation button')].map(node=>({cls:node.className,left:node.getBoundingClientRect().left,right:node.getBoundingClientRect().right,height:node.getBoundingClientRect().height,display:getComputedStyle(node).display,visibility:getComputedStyle(node).visibility}))}));
    assert.equal(geometry.direction,'rtl');assert.equal(geometry.scrollX,0);assert.equal(geometry.scrollY,0);assert.equal(geometry.documentWidth,320);assert.equal(geometry.dark,true);assert.equal(geometry.forced,forcedColors==='active');for(const node of geometry.controls){assert.ok(node.left>=0&&node.right<=320&&node.height>=44);assert.equal(node.visibility,'visible');}
    const screenshot=`clean-${engine}-320-rtl-${forcedColors}.png`;await page.screenshot({path:root+'/'+screenshot,fullPage:true});
    await page.getByRole('button',{name:'Load more',exact:true}).click();await page.locator('[data-raveldex-inline-result]').nth(5).waitFor();const IDs=await page.locator('[data-raveldex-inline-result]').evaluateAll(nodes=>nodes.map(node=>node.dataset.raveldexInlineResult));assert.deepEqual(IDs,expected.slice(0,6));
    observations.push({engine,version:browser.version(),forcedColors,geometry,screenshot,nativeLoadMoreIDs:IDs});await context.close();
   }
  }finally{await browser.close();}
 }
}finally{child.kill('SIGTERM');await exited;}
const report={kind:'raveldex-dropdown-clean-visual-probe-v1',status:'Pass',sourceInstalledConsumer:dir,packageSHA256:source.package.sha256,sourceSHA256:source.sourceSHA256,method:'Same final installed browser build; actual RTL320x568 dark/forced-colors contexts. Scroll top and wait two animation frames before full-page capture to avoid prior offscreen-compositor artifacts. Frame waits are capture setup, not physical-paint timing.',observations,limits:'Supporting automated rendered/geometry/native-click evidence, not human AT/physical input/actual browser zoom or physical paint measurement.'};await writeFile(root+'/clean-visual-probe.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
