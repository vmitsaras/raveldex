import type { LoadedStaticSearch, StaticLoadOptions } from './types.js';
export { StaticSearchError, STATIC_SEARCH_ERROR_CODES } from './error.js';
export type { StaticSearchErrorCode } from './error.js';
export type { LoadedStaticSearch, LoadDocumentsOptions, StaticLoadOptions, StaticManifest, StaticAsset, StaticDocument } from './types.js';
/** An explicit load creates a private candidate. Only a complete compatible
 * restore is returned to the application; existing application owners are untouched. */
export declare function loadStaticSearch(input: StaticLoadOptions): Promise<LoadedStaticSearch>;
