export const STATIC_SEARCH_ERROR_CODES = Object.freeze([
    'INVALID_INPUT', 'INVALID_ARTIFACT', 'STALE_BUILD', 'INCOMPATIBLE_ARTIFACT',
    'MISSING_ARTIFACT', 'INTEGRITY_MISMATCH', 'ASSET_LIMIT', 'FETCH_FAILED',
    'CANCELLED', 'DISPOSED',
]);
export class StaticSearchError extends Error {
    code;
    constructor(code) {
        super(`Raveldex static search: ${code}`);
        this.name = 'StaticSearchError';
        this.code = code;
    }
}
export function fail(code) { throw new StaticSearchError(code); }
