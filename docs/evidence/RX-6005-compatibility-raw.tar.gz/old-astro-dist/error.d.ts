export declare const STATIC_SEARCH_ERROR_CODES: readonly ["INVALID_INPUT", "INVALID_ARTIFACT", "STALE_BUILD", "INCOMPATIBLE_ARTIFACT", "MISSING_ARTIFACT", "INTEGRITY_MISMATCH", "ASSET_LIMIT", "FETCH_FAILED", "CANCELLED", "DISPOSED"];
export type StaticSearchErrorCode = typeof STATIC_SEARCH_ERROR_CODES[number];
export declare class StaticSearchError extends Error {
    readonly code: StaticSearchErrorCode;
    constructor(code: StaticSearchErrorCode);
}
export declare function fail(code: StaticSearchErrorCode): never;
