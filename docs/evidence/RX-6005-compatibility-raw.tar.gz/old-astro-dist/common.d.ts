import type { StaticSearchErrorCode } from './error.js';
import type { StaticAsset, StaticManifest } from './types.js';
export declare const MANIFEST_LIMIT: number;
export declare const DOCUMENTS_LIMIT: number;
export declare const SNAPSHOT_LIMIT: number;
export declare const ENTRY_LIMIT = 10000;
export declare const HASH: RegExp;
export type Data = Record<string, unknown>;
export declare function object(input: unknown, allowed?: readonly string[], code?: StaticSearchErrorCode): Data;
export interface OwnershipBudget {
    count: number;
    maximum: number;
    functions?: boolean;
}
/** Bounded plain-data ownership; configuration functions remain trusted handles,
 * bound to their original object before a later native capture can rebind them. */
export declare function cloneOwned(input: unknown, budget?: OwnershipBudget, depth?: number, owner?: object): unknown;
export declare function string(input: unknown, maximum: number, code?: StaticSearchErrorCode): string;
export declare function buildId(input: unknown, code?: StaticSearchErrorCode): string;
export declare function safePath(input: unknown, code?: StaticSearchErrorCode): string;
export declare function sourceUrl(base: string, path: string): string;
export declare function bytes(text: string, maximum: number): Uint8Array<ArrayBuffer>;
export declare function digest(data: Uint8Array<ArrayBuffer>): Promise<string>;
export declare function hashText(text: string, maximum: number): Promise<string>;
export declare function parse(text: string): unknown;
/** Public snapshot headers supply normalized actual configuration; no private
 * engine import or caller-supplied identity substitutes for this fingerprint. */
export declare function configurationIdentity(source: string): Promise<string>;
export declare function batchSize(source: string): number;
export declare function idIdentity(ids: readonly string[]): Promise<string>;
export declare function asset(prefix: 'source' | 'native' | 'documents', text: string): Promise<StaticAsset>;
export declare function captureManifest(raw: unknown): StaticManifest;
