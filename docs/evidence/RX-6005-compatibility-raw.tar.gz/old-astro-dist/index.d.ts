import type { AstroIntegration } from 'astro';
import type { Configuration } from '@vmitsaras/raveldex';
import type { NativeSnapshotQualification } from '@vmitsaras/raveldex/adapters/snapshots';
import type { StaticEntry } from './types.js';
export interface RaveldexAstroOptions {
    readonly configuration: Configuration;
    readonly getEntries: () => readonly StaticEntry[] | Promise<readonly StaticEntry[]>;
    readonly buildId: string;
    readonly nativeQualification?: NativeSnapshotQualification;
}
/** Static build integration only. Content discovery and client activation stay explicit. */
export default function raveldexAstro(input: RaveldexAstroOptions): AstroIntegration;
