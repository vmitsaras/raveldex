import type { StaticArtifacts, StaticBuildOptions } from './types.js';
export { StaticSearchError, STATIC_SEARCH_ERROR_CODES } from './error.js';
export type { StaticSearchErrorCode } from './error.js';
export type { StaticArtifacts, StaticAsset, StaticBuildOptions, StaticEntry, StaticManifest, StaticDocument } from './types.js';
/** Explicit complete reconstruction from an owned allowlist; no framework,
 * parser, filesystem, fetch or worker access occurs in this entry. */
export declare function buildStaticSearch(input: StaticBuildOptions): Promise<StaticArtifacts>;
