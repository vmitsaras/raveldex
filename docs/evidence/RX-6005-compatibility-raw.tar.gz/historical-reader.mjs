import assert from 'node:assert/strict';
import { cp,writeFile,readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { prepareConsumer,command } from '/Users/vasilis/Documents/GitHub/raveldex/scripts/lib/packed-consumer.mjs';
import { packAstro } from '/Users/vasilis/Documents/GitHub/raveldex/scripts/pack-astro.mjs';
const consumer=await prepareConsumer([],[]);
const pack=await packAstro({output:join(consumer.directory,'astro-pack')});
await command('npm',['install',pack.tarball,'--offline','--ignore-scripts','--omit=dev','--no-audit','--no-fund','--package-lock=false','--cache',join(consumer.directory,'.npm-cache')],consumer.directory);
await cp('/private/tmp/raveldex-rx6005-q58tlsbn/old-astro-dist',join(consumer.directory,'old-dist'),{recursive:true});
await writeFile(join(consumer.directory,'probe.mjs'),`
import assert from 'node:assert/strict';
import {buildStaticSearch as oldBuild} from './old-dist/build.js';
import {loadStaticSearch as oldLoad} from './old-dist/client.js';
import {buildStaticSearch} from '@vmitsaras/raveldex-astro/build';
import {loadStaticSearch} from '@vmitsaras/raveldex-astro/client';
import {createSourceProvider} from '@vmitsaras/raveldex/addons/phrases/source';
const configuration={schema:{text:{body:{}}},addons:[createSourceProvider({fields:['body']})]};
const base={configuration,entries:[{record:{id:'a',text:{body:'alpha beta'}},title:'A',path:'/a/'}],buildId:'historical-v1',base:'/help/'};
const old=await oldBuild(base),fresh=await buildStaticSearch({...base,pageSections:[{pageId:'a',sections:[{anchor:'part',heading:'Part',headingLevel:2,field:'body',valueIndex:0,start:0,end:10}]}]});
for(const[file,wire]of Object.entries(old.files))assert.equal(fresh.files[file],wire);
await assert.rejects(oldBuild({...base,pageSections:[]}),{code:'INVALID_INPUT'});
const requests=[];
const network=artifacts=>async input=>{const url=String(input);requests.push(url);const file=url.slice(url.lastIndexOf('/')+1),wire=artifacts.files[file];const response=new Response(wire??'',{status:wire===undefined?404:200});Object.defineProperty(response,'url',{value:url});return response};
const options={configuration,manifestUrl:'https://docs.example/help/raveldex/manifest.json',expectedBuildId:'historical-v1'};
const legacy=await oldLoad({...options,fetch:network(fresh)});
try{assert.equal('loadSections'in legacy,false);assert.equal((await legacy.engine.search('alpha')).total,1);assert.equal((await legacy.loadDocuments())[0].url,'/help/a/');assert.equal(requests.length,3);assert.ok(requests.every(x=>!x.includes('sections-')));}finally{await legacy.dispose()}
requests.length=0;
const newer=await loadStaticSearch({...options,fetch:network(old)});
try{assert.equal((await newer.engine.search('alpha')).total,1);assert.equal(requests.length,2);await assert.rejects(newer.loadSections(),{code:'MISSING_ARTIFACT'});assert.equal((await newer.engine.search('alpha')).total,1);}finally{await newer.dispose()}
console.log(JSON.stringify({status:'Pass',oldProducerNewReader:true,newProducerOldReader:true,exactOldBytes:Object.keys(old.files),oldOptionRejected:true,oldReaderNoCompanionIO:true,newMissingCompanionTyped:true,ordinaryOwnersUsable:true}));
`);
const result=await command(process.execPath,['probe.mjs'],consumer.directory);
const report={...JSON.parse(result.stdout),consumer:consumer.directory,core:consumer.package,astro:pack.report.package,oldReaderFiles:await Promise.all(['client','build','common','error'].map(async n=>({path:n+'.js',bytes:(await readFile(join(consumer.directory,'old-dist',n+'.js'))).length})))};
await writeFile('/private/tmp/raveldex-rx6005-q58tlsbn/historical-reader.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,consumer:report.consumer,oldProducerNewReader:true,newProducerOldReader:true}));
