import assert from 'node:assert/strict';
import { build } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/esbuild/lib/main.js';
import { chromium } from '/Users/vasilis/Documents/GitHub/raveldex/node_modules/playwright-core/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const repo='/Users/vasilis/Documents/GitHub/raveldex';
const work='/private/tmp/raveldex-rx6007-bh1oh6ge';
const entries=[repo+'/examples/modal-browser/controller.mjs',repo+'/examples/modal-astro/src/search.mjs'];
const hashes=Object.fromEntries(await Promise.all(entries.map(async p=>[p,createHash('sha256').update(await readFile(p)).digest('hex')])));
const metadata=JSON.parse(await readFile(repo+'/package.json','utf8'));
const result=await build({plugins:[{name:'review-self-package',setup(b){b.onResolve({filter:/^@vmitsaras\/raveldex(?:\/|$)/},args=>{const key=args.path==='@vmitsaras/raveldex'?'.':'.'+args.path.slice('@vmitsaras/raveldex'.length);return {path:repo+'/'+metadata.exports[key].import.slice(2)};});}}],stdin:{contents:`export {createDocumentationSearch as browser} from ${JSON.stringify(entries[0])};export {createDocumentationSearch as astro} from ${JSON.stringify(entries[1])};export {createRaveldex} from '@vmitsaras/raveldex';`,resolveDir:repo},bundle:true,platform:'browser',format:'esm',target:'es2022',write:false,alias:{'@vmitsaras/raveldex-astro/client':repo+'/integrations/astro/dist/client.js'}});
const js=result.outputFiles[0].text;
const server=createServer((req,res)=>{if(req.url==='/probe.js'){res.setHeader('content-type','text/javascript');res.end(js);}else{res.setHeader('content-type','text/html');res.end('<!doctype html><html lang="en"><title>Review probe</title><body></body></html>');}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
let browser;
try{
 browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage();await page.goto(`http://127.0.0.1:${server.address().port}/`);
 const observations=await page.evaluate(async()=>{
  const {browser:browserFactory,astro:astroFactory,createRaveldex}=await import('/probe.js');
  const out=[];
  function nodes(kind){const section=document.createElement('section');section.innerHTML='<button type="button" data-trigger>Open</button><div data-root><p>Original</p></div><dialog><h2>Loading</h2><p role="status"></p><button data-search-cancel data-loading-close>Close</button><button data-retry hidden>Retry</button></dialog>';document.body.append(section);return{root:section.querySelector('[data-root]'),trigger:section.querySelector('[data-trigger]'),loadingDialog:section.querySelector('dialog'),status:section.querySelector('p[role]'),retry:section.querySelector('[data-retry]'),section};}
  for(const [kind,factory] of [['browser',browserFactory],['astro',astroFactory]]){
   const n=nodes(kind);let calls=0,controller;const gates=[];const owners=[];let reentered;
   const load=async options=>{const signal=kind==='browser'?options:options.signal;const index=calls++;let release;const gate=new Promise(r=>{release=r});gates.push(release);if(index===0)signal.addEventListener('abort',()=>{reentered=controller.open()},{once:true});await gate;const engine=createRaveldex({schema:{text:{body:{}}}});let count=0;const owner={engine,documents:[],dispose:async()=>{count++;await engine.dispose()},loadDocuments:async()=>[],loadSections:async()=>undefined,count:()=>count};owners.push(owner);return owner;};
   controller=factory({...n,load,manifestUrl:location.origin+'/manifest.json',buildId:'review'});n.trigger.focus();const first=controller.open();await Promise.resolve();await Promise.resolve();
   // Raw native close removes modality before its queued event; reconcile may abort A and reenter B.
   n.loadingDialog.close();const reopened=controller.open();await Promise.resolve();await Promise.resolve();
   out.push({kind,case:'raw close abort reentry',calls,loadingOpen:n.loadingDialog.open,newPromise:reopened!==first,reentered:!!reentered,returnedCurrent:reopened===reentered});
   const ended=controller.destroy();for(const release of gates)release();await ended;await first;await reopened;out.push({kind,case:'cleanup',disposals:owners.map(o=>o.count())});n.section.remove();
  }
  for(const [kind,factory] of [['browser',browserFactory],['astro',astroFactory]]){
   const n=nodes(kind),engine=createRaveldex({schema:{text:{body:{}}}});let disposed=0;const docs=[{id:'',title:'Invalid record',url:'javascript:alert(1)'}];const candidate={engine,documents:docs,loadDocuments:async()=>docs,loadSections:async()=>undefined,dispose:async()=>{disposed++;await engine.dispose()}};
   let called=0;const before={modals:document.querySelectorAll('dialog:modal').length,dialogs:[...document.querySelectorAll('dialog')].map(x=>({open:x.open,connected:x.isConnected}))};const controller=factory({...n,load:async()=>{called++;return candidate},manifestUrl:location.origin+'/manifest.json',buildId:'review'});n.trigger.focus();await controller.open();out.push({kind,case:'mount failure',before,called,loadingOpen:n.loadingDialog.open,retryVisible:!n.retry.hidden,status:n.status.textContent,disposed});await controller.destroy();n.section.remove();
  }
  for(const [kind,factory] of [['browser',browserFactory],['astro',astroFactory]]){
   const n=nodes(kind);let controller,destroyed,calls=0;
   customElements.define('review-status-'+kind,class extends HTMLElement{disconnectedCallback(){if(controller)destroyed=controller.destroy()}});
   n.status.append(document.createElement('review-status-'+kind));
   controller=factory({...n,load:async()=>{calls++;throw Error('No loading should occur')},manifestUrl:location.origin+'/manifest.json',buildId:'review'});
   await controller.open();await destroyed;
   out.push({kind,case:'destroy during authored status disconnection',calls,loadingOpen:n.loadingDialog.open});
   n.loadingDialog.close();n.section.remove();
  }
  return out;
 });
 for(const item of observations){
  if(item.case==='raw close abort reentry'){assert.equal(item.calls,2);assert.equal(item.loadingOpen,true);assert.equal(item.newPromise,true);assert.equal(item.reentered,true);assert.equal(item.returnedCurrent,true);}
  if(item.case==='cleanup')assert.deepEqual(item.disposals,[1,1]);
  if(item.case==='mount failure'){assert.equal(item.called,1);assert.equal(item.loadingOpen,true);assert.equal(item.retryVisible,true);assert.equal(item.disposed,1);}
  if(item.case==='destroy during authored status disconnection'){assert.equal(item.calls,0);assert.equal(item.loadingOpen,false);}
 }
 const report={kind:'RX6007-independent-review-probe',scope:'Actual Chrome wrapper lifecycle probes bundled from current application source and existing compiled Raveldex; not fresh installed consumer proof.',browser:browser.version(),hashes,observations};await writeFile(work+'/review-probe-final.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
}finally{await browser?.close();await new Promise(resolve=>server.close(resolve));}
