import pathlib,hashlib,json,tarfile,io,importlib.util,sys
R=pathlib.Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn');D=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex/docs/evidence');repo=D.parents[1]
spec=importlib.util.spec_from_file_location('verify',repo/'bench/memory/runtime-archive.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
class Slice:
 def __init__(self,path,offset,n):self.f=path.open('rb');self.f.seek(offset);self.n=n
 def read(self,n):
  b=self.f.read(min(n,self.n));self.n-=len(b);return b
 def close(self):self.f.close()
def package(name,items):
 manifest=json.dumps({'schema':'raveldex-ac03-workload-archive-v1','members':[{k:x[k] for k in ['name','bytes','sha256']} for x in items]},indent=2).encode()
 target=D/name;assert not target.exists()
 with tarfile.open(target,'w:xz',preset=6) as tar:
  meta=tarfile.TarInfo('MANIFEST.json');meta.size=len(manifest);tar.addfile(meta,io.BytesIO(manifest))
  for row in items:
   info=tarfile.TarInfo(row['name']);info.size=row['bytes'];info.mode=0o600
   f=Slice(row['path'],row.get('offset',0),row['bytes'])
   try:tar.addfile(info,f)
   finally:f.close()
 assert target.stat().st_size<100*1024**2
 receipt=v.verify(target);record=dict(path=str(target.relative_to(repo)),bytes=target.stat().st_size,sha256=sha(target),verification=receipt)
 print(json.dumps(record),flush=True);return record
streams=[];parts=[]
for p in sorted(R.glob('codecs/*/*/*.rdxgc')):
 size=p.stat().st_size;offset=0;row=dict(name=str(p.relative_to(R)),bytes=size,sha256=sha(p),parts=[])
 with p.open('rb') as f:
  while offset<size:
   n=min(128*1024**2,size-offset);h=hashlib.sha256();remaining=n
   while remaining:
    b=f.read(min(1048576,remaining));assert b;h.update(b);remaining-=len(b)
   part=dict(name='raw/'+str(p.relative_to(R))+'.part-'+str(len(row['parts'])).zfill(3),bytes=n,sha256=h.hexdigest(),offset=offset,path=p)
   parts.append(part);row['parts'].append(part);offset+=n
 streams.append(row)
groups=[];current=[];n=0
for part in parts:
 if n+part['bytes']>768*1024**2:groups.append(current);current=[];n=0
 current.append(part);n+=part['bytes']
if current:groups.append(current)
records=[]
for i,group in enumerate(groups,1):
 name=f'RX-4002-codecs-copy-raw-{i:02}-20261028.tar.xz'
 for part in group:part['archive']=name
 records.append(package(name,group))
index={'schema':'raveldex-raw-parts-v1','scope':'Byte-exact contiguous raw parts; no event dropping, delta conversion or prefix qualification','archives':records,'streams':[{**{k:row[k] for k in ['name','bytes','sha256']},'parts':[{k:p[k] for k in ['name','bytes','sha256','offset','archive']} for p in row['parts']]} for row in streams]}
(R/'raw-index.json').write_text(json.dumps(index,indent=2)+'\n')
items=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.is_symlink() or any(x in ('pycache','__pycache__') for x in p.relative_to(R).parts):continue
 if p.suffix=='.pyc' or str(p.relative_to(R)) in ['packaging.log','packaging-index.json']:continue
 if p.suffix=='.rdxgc' and p.is_relative_to(R/'codecs'):continue
 if p.name in ['xcrun_db']:continue
 with p.open('rb') as f:magic=f.read(4)
 if magic in (bytes.fromhex('cffaedfe'),bytes.fromhex('feedfacf')):continue
 items.append(dict(name=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p),path=p))
records.append(package('RX-4002-codecs-copy-20261028.tar.xz',items))
(R/'packaging-index.json').write_text(json.dumps({'archives':records,'rawBytes':sum(x['bytes'] for x in streams),'rawStreams':len(streams),'rawParts':len(parts),'totalCompressedBytes':sum(x['bytes'] for x in records)},indent=2)+'\n')
