import hashlib,json,pathlib
base=pathlib.Path(__file__).parent
raw=json.loads((base/'raw-sequence.json').read_text());hist=json.loads((base/'address-history.json').read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
source=pathlib.Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/gc')
paths=[pathlib.Path(raw['input']),source/'recorder-v3.inc',source/'node-gc-v3',source/'node-v24.21.0/deps/v8/src/heap/heap.cc',source/'node-v24.21.0/deps/v8/src/common/globals.h']
identity={str(p):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in paths}
(base/'identities.json').write_text(json.dumps(identity,indent=2)+'\n')
report='''# RX-4002 bounded read-only GC-layout diagnosis — 2026-10-28

This diagnosis inspects the already-recorded source/native 10,000-record receiver stream. No runtime/build/debugger/network execution or source mutation occurred. Diagnostic outputs are confined to this directory. It is a structural and address-local scan, not a replacement for independent extent-map replay. The parent owns public-operation checks and full replay separately.

## Concrete failure

The stream is 824,918,661 bytes with 68,429,628 stored/attempted events, zero drops, 168 paired GC begin/end records, and exactly two kind-3 records inside GC. Footer: `valid:false`, `errors:1`, `first_error:"tracked_size_change_during_gc_unsupported"`, `aborted:false`. All five managed metrics are **null**. No prefix or recovered metric is accepted.

The first in-GC shrink is the failing event. The recorder emits kind 3 before checking `errors_`; its only in-GC tracked-shrink failure checks frozen `extents_` and `moved_`. There is no earlier in-GC shrink, no earlier error (footer error count one), and `preexisting_or_unmonitored_changes:0`. The immediately preceding begin clears `moved_`, and no move has occurred in this cycle. Therefore the failing intersection is with the frozen pre-GC monitored map. The exact full coverage belongs to independent full replay; the address-local witnesses below support an entire 376-byte monitored birth retained at that same address.

| Sequence (1-based) | Byte offset (0-based) | Kind | Address / result |
|---:|---:|---:|---|
| 607 | 7,768 | 1 birth | 13,602,529,692,640, size 376 |
| 50,425,302 | 609,077,581 | 10 census | same address, size 376, GC #107 |
| 50,777,150 | 613,357,406 | 8 GC begin | GC #108, marker 1 = MARK_COMPACTOR, reported before 29,219,576 |
| 50,777,151 | 613,357,415 | 3 shrink | address 13,602,529,692,640, old 376 → new 264 |
| 50,777,152 | 613,357,429 | 4 size update | same address, new 264 |
| 50,777,153 | 613,357,442 | 3 shrink | address 13,602,529,695,216, old 968 → new 760 |
| 50,777,154 | 613,357,456 | 4 size update | same second address, new 760 |
| 50,777,155 | 613,357,469 | 2 move | first raw move in GC #108 |
| 50,777,832 | 613,369,862 | 9 GC end | after 677 raw moves, zero census rows |

The first old extent is `[13602529692640,13602529693016)` (`[0xc5f15f34be0,0xc5f15f34d58)`). Its new extent ends at 13,602,529,692,904 (`0xc5f15f34ce8`), a 112-byte tail removal. Exactly 107 earlier census rows record the original 376 bytes at that address, one per GC #1–107. No raw move source/destination intersects its old extent before the failing shrink.

The second address was a 968-byte birth at sequence 730, offset 9,264, and has the same 107 earlier exact-size census witnesses. Its old extent is `[13602529695216,13602529696184)` and its new end is 13,602,529,695,976, a 208-byte tail removal. This second event is emitted after invalidation and the recorder returns before classifying it. It must not be called a second independently detected error.

The first error suppresses GC reconciliation and census in `GCEnd`; subsequent allocation/move/shrink emissions continue, but their managed accounting does not. The unchanged 29,219,576 value in the failing GC end and later markers is stale diagnostic state, not an accepted occupied-memory result. Footer `gc_moves` counts accepted pre-error processing, whereas the structural scan counts all 421,294 raw move rows; that difference is expected after invalidation.

## Nearby and later layout sequencing

Both in-GC shrinks occur immediately after GC #108 begins and before any move or census. GC #108 has 677 raw moves and no census. This establishes a concrete shrink-before-move ordering; it does not calibrate a hypothetical shrink after movement.

Later raw GC #110 move destinations reuse removed tails:

- First target: sequences 51,327,116–51,327,119, offsets 619,962,151 / 619,962,169 / 619,962,187 / 619,962,205, contain four 24-byte destinations starting at 13,602,529,692,904 / 928 / 952 / 976. The first destination equals the new end of the first shrunk object. Together they occupy 96 bytes of its former 112-byte tail.
- Second target: sequence 51,327,037, offset 619,960,714, moves 160 bytes to 13,602,529,695,976, exactly its new end. Sequence 51,327,038 moves 160 bytes to 13,602,529,696,136; the latter crosses beyond the old 968-byte extent.

These are post-invalidation raw sequencing witnesses only. They show why calibration must account for released tails and later destination reuse; they do not restore missing census/reconciliation or qualify a numeric result.

## Source-supported caller facts and limits

The byte-hashed source in `identities.json` contains exactly two calls to the custom `SizeChangeEvent` hook: `heap.cc:3547` (large-object `RightTrimArray`) and `heap.cc:4154` (`NotifyObjectSizeChange`, which aligns sizes and creates the filler before reporting). `RightTrimArray` invokes the small-object notification at `heap.cc:3516`, stores the new capacity at line 3541, and emits `UpdateObjectSizeEvent` at line 3555. Repository-wide source search finds that as the sole invocation of the size-update hook (other hits are declarations/overrides). The matching immediate kind-3/kind-4 pairs are therefore strong source-supported evidence of the RightTrimArray notification sequence.

The raw stream has no object type, template instantiation, stack or callsite ID. **Do not identify either target as WeakArrayList, TransitionArray, JSArray elements, or another concrete object from its size.** MARK_COMPACTOR source has multiple array trimming routes; the existing recorder comment mentioning preexisting WeakArrayList does not identify this newly monitored object. No native caller trace was collected here.

The source guard at `recorder-v3.inc:71–83` intentionally rejects monitored/partly monitored GC shrink. `GCBegin` lines 98–104 freeze the old tag map and clear move staging; `GCEnd` lines 105–130 performs move and full-census reconciliation only if there are no errors. `globals.h:1571` binds collector marker 1 to MARK_COMPACTOR. Exact source/runtime/stream identities are recorded separately.

## Narrow next calibration requirement

No safe generalization to all GC size changes follows from this stream. Keep this window invalid with all derived metrics null. A future, separately versioned task-owned recorder extension needs a controlled observed monitored in-place array right trim during MARK_COMPACTOR **before movement**, with original-size ownership, exact kept prefix/removed tail, later moves into that tail, and a successful completed-GC non-filler census independently reconciled. Capture caller/type identity explicitly if the extension is limited to a particular source route; current sizes alone cannot select one.

If future support claims more than this exact ordering, it must separately calibrate moved-object shrink and source/destination overlaps, including partly monitored extents and address reuse; reject uncalibrated cases. Independent literal replay cases should exercise shrink-before-move plus tail reuse and negative unsupported/loss/abort controls. A fresh full product window is required after a successful calibration. This diagnosis neither implements such support nor recommends relaxing the present guard, changing production limits, or salvaging metrics from this failed run.

## Reproduction and scope

`scan-gc-layout.py INPUT raw-sequence.json` checks contiguous six-varint framing from the header, terminal length/EOF, stored event count, all GC size-change contexts and kind counts. `scan-address-history.py INPUT` scans the same framing for exact-address birth/shrink/update/census records and raw move extents intersecting the two old extents. Both use bounded selected output and no extent ledger; elapsed times were 35.35 s and 28.31 s. They do not independently validate every stream semantic or claim object identity from addresses. `raw-sequence.json` and `address-history.json` preserve exact rows. `write-report.py` binds input/source hashes and writes this report. No project files or prior instrumentation files were changed.
'''
(base/'REPORT.md').write_text(report)
print(json.dumps(dict(report=str(base/'REPORT.md'),identities=str(base/'identities.json'),rawSha256=identity[raw['input']]['sha256'])))
