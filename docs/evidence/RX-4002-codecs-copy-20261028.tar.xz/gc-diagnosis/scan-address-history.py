"""Address-local sequential evidence, not an identity or extent-map replay."""
import collections, importlib.util,json,mmap,pathlib,sys,time
base=pathlib.Path(__file__).parent
# Keep these literal framing/decoder helpers independent of any ledger replay.
import re
var=rb'[\x80-\xff]*[\x00-\x7f]'; pattern=re.compile(rb'([\x01-\x0a])((?:'+var+rb'){5})')
def enc(n):
 b=[]
 while n>=128:b.append((n&127)|128);n>>=7
 b.append(n);return bytes(b)
def decode(b):
 out=[];n=s=0
 for x in b:
  n|=(x&127)<<s
  if x<128:out.append(n);n=s=0
  else:s+=7
 return out
p=pathlib.Path(sys.argv[1]); report=json.loads((base/'raw-sequence.json').read_text()); targets={r['event']['values'][1]:r['event']['values'][4] for r in report['gcSizeChanges']}; prefixes=tuple(enc(a) for a in targets)
started=time.monotonic(); found=[]; gc=seq=0; inside=False
with p.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
 pos=data.find(b'\n')+1
 for m in pattern.finditer(data,pos):
  if m.start()!=pos:break
  pos=m.end();seq+=1;k=m.group(1)[0]
  if k==8:gc+=1;inside=True
  if k==9:inside=False
  record=None
  if k in (1,3,4,10) and m.group(2).startswith(prefixes):record=decode(m.group())
  elif k==2:
   r=decode(m.group());_,a,to,n,old,mark=r
   overlaps=[]
   for target,length in targets.items():
    if a<target+length and target<a+n:overlaps.append(dict(target=target,role='source'))
    if to<target+length and target<to+n:overlaps.append(dict(target=target,role='destination'))
   if overlaps:record=r
  if record:
   found.append(dict(seq=seq,offset=m.start(),gcCycle=gc,inGc=inside,values=record))
   assert len(found)<=8192,'History output bound'
 assert data[pos]==0
out=base/'address-history.json';out.write_text(json.dumps(dict(input=str(p),targets=targets,events=seq,rows=found,elapsedSeconds=time.monotonic()-started,scope='Only exact address rows and move extents intersecting those addresses. Address reuse is possible; this is not monitored identity reconstruction.'),indent=2)+'\n')
print(json.dumps(dict(output=str(out),rows=len(found),elapsedSeconds=time.monotonic()-started)))
