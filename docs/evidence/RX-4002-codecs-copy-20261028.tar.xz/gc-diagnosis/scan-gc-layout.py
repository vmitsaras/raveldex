"""Bounded sequential raw diagnosis; no extent-map replay or runtime execution.
Each six-varint frame is matched from its exact preceding end. Only selected
GC shrink rows and their immediate surroundings are decoded; bounded context.
"""
import collections, hashlib, json, mmap, pathlib, re, sys, time
path = pathlib.Path(sys.argv[1]); out = pathlib.Path(sys.argv[2]); started=time.monotonic()
var = rb'[\x80-\xff]*[\x00-\x7f]'
pattern=re.compile(rb'([\x01-\x0a])((?:'+var+rb'){5})')
def decode(blob):
    result=[]; n=shift=0
    for b in blob:
        n|=(b&127)<<shift
        if b<128: result.append(n); n=shift=0
        else: shift+=7
    assert not shift
    return result
def row(seq, start, blob):
    vals=decode(blob)
    assert len(vals)==6
    return dict(seq=seq, offset=start, values=vals)
with path.open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
    headerend=data.find(b'\n')+1; header=json.loads(data[:headerend]); pos=headerend
    seq=cycles=moves=census=0; gc=None; ring=collections.deque(maxlen=8); targets=[]; pending=[]
    kinds=collections.Counter()
    for m in pattern.finditer(data,headerend):
        if m.start()!=pos: break
        pos=m.end(); seq+=1; kind=m.group(1)[0]; kinds[kind]+=1
        if pending:
            r=row(seq,m.start(),m.group())
            for t in pending:t['after'].append(r)
            pending=[t for t in pending if len(t['after'])<8]
        if kind==8:
            cycles+=1; gc=dict(cycle=cycles, begin=row(seq,m.start(),m.group()), moves=0, census=0)
        elif kind==2 and gc: gc['moves']+=1
        elif kind==10 and gc: gc['census']+=1
        elif kind==3 and gc:
            assert len(targets)<4096, 'GC shrink diagnosis bound'
            t=dict(event=row(seq,m.start(),m.group()),gc=dict(gc),before=[row(*r) for r in ring],after=[])
            targets.append(t); pending.append(t)
        elif kind==9:
            if gc:
                for t in targets:
                    if t['gc']['cycle']==cycles:t['gcEnd']=row(seq,m.start(),m.group());t['finalGcMoveCount']=gc['moves'];t['finalGcCensusCount']=gc['census']
            gc=None
        ring.append((seq,m.start(),m.group()))
    assert data[pos]==0, (pos,data[pos])
    end=pos+1
    while data[end]>=128:end+=1
    length=decode(data[pos+1:end+1])[0]; end+=1
    summary=json.loads(data[end:end+length]);assert end+length==len(data)
    assert summary['events']==seq
    result=dict(input=str(path),bytes=len(data),header=header,events=seq,kindCounts=dict(kinds),gcSizeChanges=targets,summary=summary,elapsedSeconds=time.monotonic()-started,scope='Sequential structural diagnosis only. No managed metrics reconstructed and no object type inferred.')
    out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(output=str(out),events=seq,gcSizeChanges=len(targets),elapsedSeconds=time.monotonic()-started)))
