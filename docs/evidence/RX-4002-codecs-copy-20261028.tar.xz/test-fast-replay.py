import importlib.util,pathlib,tempfile,unittest,json,sys
repo=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex');root=pathlib.Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
fast=load('fast',repo/'bench/memory/gc-runtime-fast-audit.py');tests=load('tests',repo/'bench/memory/gc-runtime-audit.test.py');records=[]
def both(self,raw):
 with tempfile.TemporaryDirectory(dir=root) as directory:
  p=pathlib.Path(directory)/'literal.rdxgc';p.write_bytes(raw)
  try:reference=tests.m.audit(p)
  except ValueError:
   with self.assertRaises(ValueError):fast.audit(p,root/'gc-runtime-replay')
   records.append({'bytes':len(raw),'bothReject':True});raise
  actual=fast.audit(p,root/'gc-runtime-replay')
  for key in ['bytes','sha256','events','valid','independentReplay','summary','maxStreamMiB']:
   self.assertEqual(actual[key],reference[key],key)
  if reference['valid']:self.assertEqual(actual['marks'],{str(k):v for k,v in reference['marks'].items()})
  else:self.assertEqual(actual['prefixFailure']['sequence'],reference['prefixFailure']['sequence'])
  records.append({'bytes':len(raw),'bothAgree':True,'valid':reference['valid']});return reference
tests.Replay.run_bytes=both
suite=unittest.defaultTestLoader.loadTestsFromTestCase(tests.Replay);result=unittest.TextTestRunner().run(suite)
(root/'fast-literal-equivalence.json').write_text(json.dumps({'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'cases':records},indent=2)+'\n')
sys.exit(not result.wasSuccessful())
