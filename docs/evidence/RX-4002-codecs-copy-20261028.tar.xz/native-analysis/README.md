# Independent saved native evidence review

**Pass for the recorded four-record sender string-copy/lifetime slice. In-place remains Refused/unverified.** No runtime launch, attach, target call or frozen candidate modification was performed by this review. All writes are in this directory.

`roundtrip-review.json` independently reconstructs all 1,438 rows and 336 native frame pairs from renderer 35416. It verifies 38 allocation births, 22 growth frees, 16 protocol-bound final frees, zero remaining/pending/drop/invalid state, and exact old/new requested-extent pair accounting. The unchanged installed 208 production files are independently rehashed; production/harness identities match the prior recorded run and the installed tarball stays `6ff6e901…9c437`.

The 222 selected one-byte string-copy calls total **9,974 bytes**. Exactly one 3,993-byte direct copy belongs to export response chain 4 / protocol ID 4; exactly one belongs to restore request chain 11 / protocol ID 8. These match the controller's 3,993-code-unit source string and actual sender directions. Native payload values were not read; this is length/route/protocol correlation, not independent byte-for-byte snapshot identity. Remaining selected copies are metadata/result string fields.

The 22 separate growth copies total **2,448 bytes**. Maximum selected old/new requested pair is **5,328 bytes**. This is pair-local coexistence; no all-buffer/global/physical peak or complete transport-copy total is claimed. All final deletion witnesses follow the explicit forced-GC drain. No two-byte route or product in-place resize appears in this cohort.

`review.json` covers the earlier empty cohort and refused control: idle has no native traffic; 162 empty-cohort rows contain 37 native pairs, 25 selected string copies / 227 bytes, 144 growth-copy bytes and two bound final frees. The 164-row cumulative in-place checkpoint adds only window markers. `receipt-refusal-review.json` confirms the separate preflight receipt-writing defect using mocks, with no target call.

`NEXT-LLDB-CALIBRATION.md` records current installed LLDB command documentation and the minimum future execution-control capability proof. It explicitly leaves the exact callback-suppression cause unknown and proposes no blind cleanup or skipped-breakpoint workaround. Preserve/archive current sources before any follow-up fix.

Reproduce offline with PYTHONPYCACHEPREFIX pointing inside this directory:

```sh
python3 /tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/native-analysis/review.py
python3 /tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/native-analysis/review_roundtrip.py
python3 /tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/native-analysis/reproduce_receipt_refusal.py
```

`artifact-index.json` binds final review artifacts and reviewed raw dependencies. `final-receipt.json` is the bounded disposition. Receiver copies, actual in-place calibration and the 1,000/10,000 product message matrix remain separate work.
