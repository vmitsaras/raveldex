"""Independent per-frame, lifetime and selected-string review of saved product run."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys
R=Path(__file__).resolve().parent;N=R.parent/'native';run=N/'native-run-2';p=run/'tap-1-source-roundtrip.json'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
x=json.loads(p.read_text());install=json.loads((run/'lldb-install.json').read_text());c=json.loads((N/'controller-run-3/report.json').read_text())
assert x['pid']==install['pid']==c['rendererPid']==35416 and x['invalid']==[] and x['dropped']==0 and x['remaining']=={} and x['pending']=={}
assert h(N/'hook-manifest.json')==install['manifestSha256'];assert h(N/'lldb_native_tap.py')==x['observerSha256']
base=install['base'];stacks={};returns={};live={};births={};payload_pending={};copy_pending={};string_rows=[];growth=[];frees=[];counts=Counter();native_pairs=0
for i,row in enumerate(x['rows'],1):
 assert row['seq']==i and row['pid']==x['pid'];kind=row['kind'];tid=row['tid'];f=row['nativeFrame'];counts[kind]+=1
 if tid:assert f['pc']==base+f['moduleOffset']
 if kind=='payload-copy-enter':
  assert tid not in payload_pending;data=live[row['ptr']]
  assert row['site']==0x17009b8==f['moduleOffset'];assert row['allocation']==data['allocation'];assert row['chain']==data['chain'];assert row['ptr']<=row['dest']<row['dest']+row['length']<=row['ptr']+data['cap'];payload_pending[tid]=row
 elif kind=='copy-enter':
  old=live[row['src']];assert old['cap']==row['oldCap'];assert row['length']<=min(row['oldCap'],row['newCap']);assert f['moduleOffset']==0x17a173c;copy_pending[tid]=row;growth.append(row)
 elif kind=='native-call-begin':
  ctx=row['call'];stack=stacks.setdefault(tid,[]);assert ctx['parentCallId']==(stack[-1]['callId'] if stack else None)
  assert ctx['entryPC']==f['pc'] and ctx['sp']==f['sp'] and ctx['lr']==f['lr']
  if ctx['kind']=='payload-copy':
   entry=payload_pending.pop(tid);assert all(ctx[k]==entry[k] for k in ['ptr','allocation','chain','src','dest','length','site']);assert ctx['returnPC']==ctx['entryPC']+4
  if ctx['kind']=='copy':
   entry=copy_pending.pop(tid);assert all(ctx[k]==entry[k] for k in ['src','dest','length','chain']);assert ctx['returnPC']==base+0x17a1740
  stack.append(ctx)
 elif kind=='native-call-return':
  ctx=stacks[tid].pop();assert ctx['callId']==row['callId'];assert ctx['sp']==f['sp']==row['matchedSP'];assert ctx['returnPC']==f['pc']==row['matchedReturnPC']==f['lr'];assert ctx['lr']==row['matchedLR'];assert ctx['entryPC']==row['matchedEntryPC'];returns[tid]=ctx;native_pairs+=1
 elif kind=='buffer-live':
  assert row['ptr'] not in live and row['allocation'] not in births
  live[row['ptr']]=dict(cap=row['cap'],allocation=row['allocation'],chain=row['chain']);births[row['allocation']]=dict(ptr=row['ptr'],cap=row['cap'],chain=row['chain'],bornSeq=i)
 elif kind=='buffer-confirmed':assert all(live[row['ptr']][k]==row[k] for k in ['cap','allocation','chain'])
 elif kind=='buffer-resize':raise AssertionError('No in-place resize expected/claimed in this product cohort')
 elif kind in ('internal-free-return','final-free-return','root-free-return'):
  ctx=returns.pop(tid);assert kind==ctx['kind']+'-return';assert all(ctx[k]==row[k] for k in ['ptr','cap','chain','allocation']);data=live.pop(row['ptr']);assert all(data[k]==row[k] for k in ['cap','chain','allocation']);births[row['allocation']]['freedSeq']=i;births[row['allocation']]['freeKind']=kind;frees.append(row)
 elif kind in ('payload-copy-return','copy-return','realloc-return','buffer-alloc-return','destructor-return'):
  ctx=returns.pop(tid)
  if kind=='payload-copy-return':
   assert ctx['kind']=='payload-copy';assert all(ctx[k]==row[k] for k in ['ptr','allocation','chain','src','dest','length','site']);assert row['returned']==row['dest'];assert live[row['ptr']]['allocation']==row['allocation'];string_rows.append(row)
  elif kind=='copy-return':assert ctx['kind']=='copy' and all(ctx[k]==row[k] for k in ['src','dest','length','chain']) and row['returned']==row['dest']
assert not live and not any(stacks.values()) and not returns and not payload_pending and not copy_pending
assert len(births)==38 and len(frees)==38 and all(b.get('freedSeq',0)>b['bornSeq'] for b in births.values())
commands=[r for r in c['commands'] if r['command']['cmd']=='case'];assert all('error' not in r for r in commands)
bycase={r['command']['kind']:r['result'] for r in commands};assert bycase['empty']['revision']==1 and not bycase['empty']['changed'];assert bycase['export']['codeUnits']==3993;assert bycase['prior']['revision']==3 and bycase['prior']['total']==1;assert bycase['restore']['revision']==4 and bycase['restore']['originRevision']==1;assert bycase['search']['revision']==4 and bycase['search']['total']==4;assert sorted(h['id'] for h in bycase['search']['hits'])==['item:00000','item:00001','item:00002','item:00003'];assert bycase['dispose']=={'disposed':True}
large=[r for r in string_rows if r['length']==3993];assert len(large)==2 and {r['chain'] for r in large}=={4,11}
assert x['bindings']['4']['id']==4 and x['bindings']['4']['operation']=='snapshotExportSource' and x['bindings']['4']['direction']=='worker-to-main'
assert x['bindings']['11']['id']==8 and x['bindings']['11']['operation']=='snapshotRestore' and x['bindings']['11']['direction']=='main-to-worker'
sys.path.insert(0,str(N));from audit_tap import audit
replay=audit(p,N/'controller-run-3/report.json',run/'lldb-install.json');assert len(replay['observedBoundFinalFrees'])==16
bychain=[]
for chain in range(1,17):
 md=x['bindings'][str(chain)];ss=[r for r in string_rows if r['chain']==chain];gg=[r for r in growth if r['chain']==chain];bb=[dict(allocation=a,**b) for a,b in births.items() if b['chain']==chain]
 assert ss and bb and len([b for b in bb if b['freeKind']=='final-free-return'])==1
 bychain.append(dict(chain=chain,id=md['id'],operation=md['operation'],direction=md['direction'],kind=md['kind'],wireBytes=md['wireBytes'],stringCopyCalls=len(ss),stringCopyBytes=sum(r['length'] for r in ss),snapshot3993ByteCopies=sum(r['length']==3993 for r in ss),growthCopyCalls=len(gg),growthCopyBytes=sum(r['length'] for r in gg),largestGrowthPairRequestedExtent=max([r['oldCap']+r['newCap'] for r in gg],default=0),births=bb))
log=(run/'lldb-observer.log').read_text();host=json.loads((run/'lldb-observer-host.json').read_text());assert 'RX_NATIVE_HOOKS_REMOVED' in log and 'Process 35416 detached' in log and host['exitCode']==0 and host['timedOut'] is False
assert c['preservation']=='Pass' and c['ownedBrowserClosed'] is True and c['commandFailures']==0
old=json.loads(Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/controller-run-1/report.json').read_text())
assert c['productionFiles']==old['productionFiles'] and len(c['productionFiles'])==208
installed=Path(c['consumer'])/'node_modules/@vmitsaras/raveldex'
for entry in c['productionFiles']:assert h(installed/entry['path'])==entry['sha256']
old_sources={entry['source']:entry['sha256'] for entry in old['sources']}
for entry in c['sources']:
 assert entry['sha256']==old_sources[entry['source']]
 if 'target' in entry:assert h(Path(entry['target']))==entry['sha256']
assert c['tarballSha256']==old['tarballSha256']=='6ff6e90128f60af39bb8f47800c61ed83d85d4ded7a8e3c96d2bd34467f9c437'
out=dict(schema='raveldex-native-roundtrip-independent-review-v1',outcome='Pass for recorded four-record sender string copies and buffer lifetimes',pid=x['pid'],binarySha256=install['binarySha256'],observerSha256=x['observerSha256'],rows=len(x['rows']),nativeFramePairs=native_pairs,selectedOneByteStringCalls=len(string_rows),selectedOneByteStringBytes=sum(r['length'] for r in string_rows),selectedGrowthCopies=len(growth),selectedGrowthCopyBytes=sum(r['length'] for r in growth),largestGrowthPairRequestedExtent=max(r['oldCap']+r['newCap'] for r in growth),births=len(births),internalGrowthFrees=sum(r['kind']=='internal-free-return' for r in frees),boundFinalFrees=16,remaining=0,protocolChains=bychain,literalControllerChecks='Pass',independentlyRehashedInstalledFiles=208,unchangedProductionAndHarnessComparedWithPriorRun=True,installedProductionPreservation=c['preservation'],controllerClosure=c['ownedBrowserClosed'],debuggerCleanup='Hooks removed, detached, host exit0 without timeout',limitations=['Direct sender string-content copies only; no complete payload/transport-copy total','Snapshot export response chain4 and restore request chain11 each contain one observed 3993-byte sender copy matching controller codeUnits; native values were not read and whole payload equality is not independently established here','All string-copy sites here are one-byte; two-byte execution remains unverified','Final frees follow explicitly forced main/worker/main GC, not natural automatic timing','Largest old/new requested pair is pair-local coexistence, not global high-water/usable allocation/physical memory','No product in-place resize occurred; prior explicit in-place control remains refused','Four-record cohort does not replace 1000/10000 product message matrix'],files={str(q):h(q) for q in [p,run/'lldb-install.json',run/'lldb-observer.log',run/'lldb-observer-host.json',N/'controller-run-3/report.json',N/'controller-run-3/pid-proof-trace.json',N/'lldb_native_tap.py',N/'audit_tap.py',N/'hook-manifest.json']})
(R/'roundtrip-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['protocolChains','files']},indent=2))
