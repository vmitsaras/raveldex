"""Pure mocks reproduce existing-receipt refusal only. No real LLDB/target import."""
from pathlib import Path
import hashlib,importlib.util,json,sys,types
R=Path(__file__).resolve().parent;N=R.parent/'native';out=R/'receipt-preflight';out.mkdir(exist_ok=True)
sentinel=out/'inplace-calibration.json'
if not sentinel.exists():sentinel.write_text('{"historicalReceipt":"preserve exactly"}\n')
before=hashlib.sha256(sentinel.read_bytes()).hexdigest()
sys.modules['lldb']=types.SimpleNamespace(eStateStopped=1)
sys.path.insert(0,str(N))
spec=importlib.util.spec_from_file_location('calibrate_frozen',N/'calibrate_inplace.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
called=[]
class Thread:
 def GetThreadID(self):return 99
 def GetFrameAtIndex(self,index):called.append('GetFrameAtIndex');raise AssertionError('native-expression stage reached')
process=types.SimpleNamespace(GetProcessID=lambda:77,GetState=lambda:1,GetSelectedThread=lambda:Thread())
m.rx=types.SimpleNamespace(INSTALLED=True,ACTIVE=True,INVALID=[],DROPPED=0,CALLS={},LIVE={},LABEL='inplace-control',TARGET=types.SimpleNamespace(GetProcess=lambda:process),CONFIG=dict(pid=77,mainTid=99),ROWS=[dict(kind='realloc-enter',root=100)],BASE=0x100000000,TYPE=0x100000000+0x974695b,OUT=out)
messages=[];result=types.SimpleNamespace(SetError=messages.append,PutCString=messages.append)
try:m.run(None,'execute-owned-native-control',result,None)
except FileExistsError as e:failure=dict(type=type(e).__name__,message=str(e))
else:raise AssertionError('Expected frozen receipt-writing defect was not reproduced')
after=hashlib.sha256(sentinel.read_bytes()).hexdigest();assert before==after and called==[] and messages==[]
record=dict(schema='raveldex-existing-receipt-mock-refusal-v1',outcome='Confirmed instrumentation receipt-writing defect',exception=failure,sentinelUnchanged=True,sentinelSha256=before,nativeExpressionStageReached=False,resultMessageDelivered=False,source=str(N/'calibrate_inplace.py'),sourceSha256=hashlib.sha256((N/'calibrate_inplace.py').read_bytes()).hexdigest(),classification='Local instrumentation error handling; no product call or product failure')
(R/'receipt-refusal-review.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
