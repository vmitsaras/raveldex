"""Independent bounded saved-row review; no live target APIs imported."""
from pathlib import Path
import collections,hashlib,json,sys
R=Path(__file__).resolve().parent;N=R.parent/'native';run=N/'native-run-1'
sys.path.insert(0,str(N))
from audit_tap import audit
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
install=json.loads((run/'lldb-install.json').read_text());controller=json.loads((N/'controller-run-2/report.json').read_text())
base=install['base'];pid=install['pid'];assert pid==33939==controller['rendererPid']
assert install['binarySha256']=='a0bfe7b4da4787b66058477d696cd1d09065d25f06a548947722b9af77ee8282'
assert h(N/'hook-manifest.json')==install['manifestSha256']
accepted=[]
for name in ('tap-1-idle.json','tap-2-empty-and-drain.json','tap-3-inplace-control.json'):
 p=run/name;x=json.loads(p.read_text());assert x['dropped']==0 and not x['invalid'] and not x['remaining'] and not x['pending']
 stacks={};payload={};strings=[];counts=collections.Counter();previous=None
 for i,row in enumerate(x['rows'],1):
  assert row['seq']==i and row['pid']==pid
  k=row['kind'];tid=row['tid'];counts[k]+=1
  if k=='payload-copy-enter':
   assert row['site']==0x17009b8 and row['nativeFrame']['pc']==base+row['site']
   payload[tid]=row
  elif k=='native-call-begin':
   c=row['call'];stack=stacks.setdefault(tid,[]);assert c['parentCallId']==(stack[-1]['callId'] if stack else None)
   assert c['entryPC']==row['nativeFrame']['pc'];assert c['sp']==row['nativeFrame']['sp'];assert c['lr']==row['nativeFrame']['lr']
   if c['kind']=='payload-copy':
    en=payload.pop(tid);assert all(c[z]==en[z] for z in ['ptr','allocation','chain','src','dest','length','site']);assert c['returnPC']==c['entryPC']+4
   stack.append(c)
  elif k=='native-call-return':
   c=stacks[tid].pop();assert c['callId']==row['callId'];assert c['sp']==row['nativeFrame']['sp']==row['matchedSP'];assert c['returnPC']==row['nativeFrame']['pc']==row['matchedReturnPC'];assert c['lr']==row['matchedLR'];previous=(tid,c)
  elif k=='payload-copy-return':
   assert previous[0]==tid;c=previous[1];assert c['kind']=='payload-copy';assert all(c[z]==row[z] for z in ['ptr','allocation','chain','src','dest','length','site']);assert row['returned']==row['dest'];strings.append(row)
 assert not any(stacks.values()) and not payload
 replay=audit(p,N/'controller-run-2/report.json',run/'lldb-install.json')
 accepted.append(dict(path=str(p),sha256=h(p),rows=len(x['rows']),nativePairs=counts['native-call-return'],directStringCalls=len(strings),directStringBytes=sum(r['length'] for r in strings),byChain=[dict(chain=c,calls=sum(r['chain']==c for r in strings),bytes=sum(r['length'] for r in strings if r['chain']==c),metadata=x['bindings'][str(c)]) for c in sorted({r['chain'] for r in strings})],growthCopies=counts['copy-return'],growthCopyBytes=sum(r['length'] for r in x['rows'] if r['kind']=='copy-return'),boundFinalFrees=len(replay['observedBoundFinalFrees']),candidateReplay='Pass',independentFrameReplay='Pass'))
x2=json.loads((run/'tap-2-empty-and-drain.json').read_text());x3=json.loads((run/'tap-3-inplace-control.json').read_text())
assert x3['rows'][:len(x2['rows'])]==x2['rows'];delta=x3['rows'][len(x2['rows']):]
assert [r['kind'] for r in delta]==['window-begin','window-checkpoint']
receipt=json.loads((run/'inplace-calibration.json').read_text());assert receipt['outcome']=='Refused' and receipt['expressionStateUncertain'] is True
assert len(receipt['nativeCalls'])==2 and all(c['offset']=='0x9f734' and c['result']==136 for c in receipt['nativeCalls'])
assert receipt['observerSha256']==h(N/'lldb_native_tap.py')
log=(run/'lldb-observer.log').read_text();assert 'Expression execution hit a breakpoint: breakpoint 5.1.' in log
assert '0x10227c36c' in log and int('10227c36c',16)-base==0x1c36c
assert 'RX_NATIVE_HOOKS_REMOVED' in log and 'Process 33939 detached' in log
host=json.loads((run/'lldb-observer-host.json').read_text());assert host['exitCode']==0 and host['timedOut'] is False
out=dict(schema='raveldex-native-copy-independent-review-v1',outcome='Pass for bounded empty sender-string route; in-place Refused/unverified',pid=pid,binarySha256=install['binarySha256'],observerSha256=h(N/'lldb_native_tap.py'),native=list(accepted),inplace=dict(receiptSha256=h(run/'inplace-calibration.json'),quantized129=136,quantized130=136,allocationEntryBreakpointOffset='0x1c36c',incrementalNativeRows=0,qualifyingAllocation=False,qualifyingReallocation=False,qualifyingFree=False,status='Refused',classification='Debugger-expression/instrumentation behavior; no product failure established'),cleanup=dict(hooksRemovedInLog=True,detachedInLog=True,hostExitCode=0,processAbsence='Parent-reported, not independently checked in this offline review'),limitations=['No direct two-byte execution in these records','Only empty addMany request/result string fields observed; no snapshot payload in these records','No complete copy total or physical high-water claim','In-place receipt is refused even though cumulative raw tap still has zero invalid/drop/live/pending; its new window contains no native witnesses'],files={str(p):h(p) for p in [N/'lldb_native_tap.py',N/'calibrate_inplace.py',N/'audit_tap.py',N/'hook-manifest.json',N/'controller-run-2/report.json',N/'controller-run-2/pid-proof-trace.json',run/'lldb-install.json',run/'lldb-observer.log',run/'lldb-observer-host.json',run/'inplace-calibration.json']})
(R/'review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(rows=[dict(name=Path(r['path']).name,rows=r['rows'],nativePairs=r['nativePairs'],directStringCalls=r['directStringCalls'],directStringBytes=r['directStringBytes'],growthCopyBytes=r['growthCopyBytes'],boundFinalFrees=r['boundFinalFrees']) for r in accepted],inplace=out['inplace']),indent=2))
