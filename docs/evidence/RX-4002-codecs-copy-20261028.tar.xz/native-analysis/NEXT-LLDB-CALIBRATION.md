# Disposition and next bounded LLDB execution calibration

The first in-place control is **Refused**, not a product failure. Both pure quantization expressions returned 136 for requested lengths 129/130. The allocation expression then stopped at the exact observed allocator-entry hook, PC minus current image base = `0x1c36c`. Its body/return, a resulting control pointer, reallocation and final free have no qualifying raw witnesses. The only new tap rows are the in-place window begin/checkpoint. Cumulative zero invalid/drop/pending/live fields therefore say nothing about the interrupted expression's completion. Parent removed hooks, detached and closed the owned process; this review does not resume it or guess cleanup.

Current installed `lldb-2103.0.34.103` / Swift 6.4 no-target help is retained at `lldb-expression-help.log`. It documents that `--ignore-breakpoints false` permits expression interruption at breakpoints, and that a later `continue` can complete an interrupted expression. This directly explains why the error is an execution-control outcome. It does **not** establish why this nested Python `EvaluateExpression` path produced no Python observer entry callback; Python nesting/LLDB thread-plan callback behavior remains an unproven causal detail.

Do not change IgnoreBreakpoints to true: skipping the instrumentation would defeat allocation/free calibration. Do not treat successful quantizer calls as proof that instrumented native calls complete.

After current evidence is archived, the smallest next route is a separate execution-control capability calibration, with the same owned PID/thread/UUID/code guards and a new output directory. Issue native expressions at the top-level LLDB command prompt, outside the Python command invoking `EvaluateExpression`. This is a **proposed route, unexecuted here**, not a confirmed fix. A fresh explicit expression should retain bounded timeout/all-thread refusal and breakpoint observation, for example the command shape:

```text
expression --ignore-breakpoints false --unwind-on-error false --all-threads false --timeout 5000000 --language c++ -- <exact byte-bound native call using freshly observed root/base/type>
```

No stale numerical PID, root, base, type or control pointer is supplied in this plan. Existing source path/function offsets remain the reviewed ones. A parent driver must make the handshake explicit:

1. Start from an idle, drained, armed observer and selected trace-proven main thread. Re-establish equal quantized class in the fresh renderer.
2. Issue one separate control allocation, with a persistent expression result variable. Require the actual allocator entry callback and a pending exact frame before considering any manual continuation. If LLDB stops before callback dispatch and no entry row exists, refuse this route before advancing the allocator body; close the owned renderer. Do not fabricate an entry row or silently skip the breakpoint.
3. If a real matching entry row exists but the expression is interrupted, one bounded top-level continuation may test completion. Require the exact native return, new birth and known persistent result pointer to agree before any reallocation/free call. Do not repeat blind continuations.
4. Only after that capability is proven, perform the separate 129→130 control-pointer reallocation and free with the same frame/result handshake. Require same returned pointer, retained birth ID, actual buffer-resize, no growth-copy/API-only retirement, matching root-free return and zero pending/live state. If it moves, record that real outcome and refuse in-place acceptance.
5. Stop/timeout/unknown expression completion leaves that control refused; parent closes the owned renderer rather than guessing native cleanup. Keep all failures and raw thread/PC/frame state.

A stricter alternative is to first calibrate this handshake with a separately added entry/return hook on the already byte-verified pure quantizer. That can prove expression callback/continuation behavior before a native allocation. It requires a separately versioned observer and focused tests; it is optional, and no such mutation is made here.

The local existing-receipt preflight defect is confirmed by `reproduce_receipt_refusal.py` using mocks only. `path` is assigned before checking existence; the refusal is caught, but the final exclusive-open attempts the same existing path and raises uncaught FileExistsError. The sentinel remains byte-identical and the native-expression stage is never reached. After archiving, a local follow-up should keep the old receipt unchanged and deliver the refusal through the LLDB result without trying to create that existing file (for example, assign the output path only after a successful nonexistence check, with an exclusive-open collision handler). Add that exact refusal regression. It does not invalidate the independent successful product sender-copy run, and no frozen calibrator source is edited by this review.
