"""Independent unchanged ASCII corpus/envelope checker; imports no product code."""
import collections,hashlib,json,pathlib,sys
ROOT=pathlib.Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def unique(pairs):
 d={}
 for k,v in pairs:
  assert k not in d,('duplicate',k)
  d[k]=v
 return d
def flat(d):
 assert set(d)=={'buckets','size'}
 result={}
 for bucket in d['buckets'].values():
  assert not (set(result)&set(bucket)); result.update(bucket)
 assert len(result)==d['size'];return result

def check(path):
 text=path.read_text();d=json.loads(text,object_pairs_hook=unique)
 assert set(d)=={'format','formatVersion','codec','body','integrity'}
 assert d['format'] in ('raveldex-native','raveldex-source') and d['formatVersion']==1 and d['codec']=={'id':'raveldex-json-v1','version':1}
 start=text.index('"body":')+7
 body,end=json.JSONDecoder(object_pairs_hook=unique).raw_decode(text,start)
 assert body==d['body']; h=2166136261
 for b in text[start:end].encode('utf-16le') [::2] if text[start:end].isascii() else ():
  h=((h^b)*16777619)&0xffffffff
 assert text[start:end].isascii(), 'Task envelope intentionally ASCII only'
 assert d['integrity']=={'algorithm':'fnv1a32-utf16','value':f'{h:08x}'}
 host=json.loads((path.parent.parent/'host.json').read_text());n=host['size'];mode=host['mode'];header=body['header'];p=body['payload'];rev=(n+255)//256
 assert header['originRevision']==rev
 assert header['analyzer']=={'id':'basic-v1','environmentProfile':'rx4002-gc-ad443b2a6fc8-ascii-v1'}
 assert header['nativeQualification']['profileId']==header['analyzer']['environmentProfile']
 expected={};postings=collections.defaultdict(dict);total_chars=total_tokens=total_terms=total_retained=termchars=0
 for i in range(n):
  id=f'item:{i:05d}';value=('red blue' if i%3==0 else 'red green blue')+f' echo echo value{i%37}'
  words=value.split(' ');freq=dict(collections.Counter(words));positions=collections.defaultdict(list);cursor=0
  for pos,w in enumerate(words):
   positions[w].append({'position':pos,'positionLength':1,'start':cursor,'end':cursor+len(w)});cursor+=len(w)+1
  expected[id]={'id':id,'value':value,'metadata':{'group':f'group{i%5}'},'freq':freq,'positions':dict(positions),'tokens':len(words)}
  for w,f in freq.items():postings[w][id]=f
  total_chars+=len(value);total_tokens+=len(words);total_terms+=len(freq);total_retained+=3+len(freq)+3*len(words);termchars+=sum(map(len,freq))
 if d['format']=='raveldex-source':
  assert set(p)=={'records'} and p['records']==[{'id':id,'text':{'body':[v['value']]},'metadata':v['metadata']} for id,v in expected.items()]
  return {'path':str(path),'sha256':sha(path),'format':d['format'],'mode':mode,'records':n,'allOriginalValuesAndMetadata':True,'checksum':'Pass'}
 assert set(p)=={'counts','documents','fields','participants'}
 docs=flat(p['documents']);assert set(docs)==set(expected)
 for id,v in expected.items():
  assert docs[id]=={'id':id,'metadata':v['metadata'],'fields':{'body':{'length':v['tokens'],'terms':v['freq']}},'textCodeUnits':len(v['value'])},id
 assert p['counts']=={'dictionaryEntries':len(postings),'documents':n,'postingEntries':total_terms,'textCodeUnits':total_chars,'tokens':total_tokens}
 assert set(p['fields'])=={'body'};field=p['fields']['body'];assert field['documents']==n and field['length']==total_tokens and set(field)=={'documents','length','terms'}
 terms=flat(field['terms']);assert set(terms)==set(postings)
 for word,rows in postings.items():
  entry=terms[word];assert set(entry)=={'df','frequency','postings'} and entry['df']==len(rows) and entry['frequency']==sum(rows.values()) and flat(entry['postings'])==rows,word
 participant='source' if mode=='source-phrase' else 'positions';assert set(p['participants'])=={participant};part=p['participants'][participant]
 assert part['revision']==rev and part['analyzer']==header['analyzer'] and part['fields']==['body'];side=flat(part['records']);assert set(side)==set(expected)
 if participant=='source':
  assert part['kind']=='raveldex-source-v1' and part['retainedEntries']==3*n and part['textCodeUnits']==total_chars
  for id,v in expected.items():assert side[id]=={'retainedEntries':3,'text':{'body':[v['value']]},'textCodeUnits':len(v['value'])},id
 else:
  assert part['kind']=='raveldex-positions-v1' and part['offsetFields']==['body']
  assert part['occurrenceCount']==part['offsetCount']==total_tokens and part['termEntries']==total_terms and part['retainedEntries']==total_retained and part['termCodeUnits']==termchars
  for id,v in expected.items():
   freq=v['freq'];tokens=v['tokens']
   assert side[id]=={'occurrenceCount':tokens,'offsetCount':tokens,'positions':{'body':[{'tokenCount':tokens,'terms':v['positions']}]},'retainedEntries':3+len(freq)+3*tokens,'termCodeUnits':sum(map(len,freq)),'termEntries':len(freq)},id
 return {'path':str(path),'sha256':sha(path),'format':d['format'],'mode':mode,'records':n,'checksum':'Pass','allDocumentIdsMetadataFrequencyVectors':'Pass','allFieldTermsStatsPostings':'Pass','allParticipantRecords':'Pass','sourceOriginalValues':participant=='source','positionOffsetsAndSequence':participant=='positions','tokens':total_tokens,'termEntries':total_terms,'textCodeUnits':total_chars}
if __name__=='__main__':
 paths=[pathlib.Path(p) for p in sys.argv[1:]] if sys.argv[1:] else sorted((ROOT/'codecs').glob('*/producer/encoded.json'))
 results=[check(p) for p in paths]
 output={'schema':'raveldex-independent-literal-codec-audit-v1','scriptSha256':sha(pathlib.Path(__file__)),'status':'Pass','results':results,'scope':'Literal unchanged ASCII corpus, all exported document metadata/frequencies, field term statistics/postings, and selected source or position/offset participant contents. No product tokenizer/scorer/codec imported; no full ranking or map replay performed.'}
 print(json.dumps(output,indent=2))
