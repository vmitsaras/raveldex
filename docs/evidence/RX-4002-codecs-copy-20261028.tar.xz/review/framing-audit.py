"""Lightweight canonical varint framing/marker scan, without extent map replay."""
import collections,hashlib,json,pathlib,re,sys,time
V=rb'(?:[\x00-\x7f]|[\x80-\xff]{1,8}[\x01-\x7f]|[\x80-\xff]{9}\x01)'
ROW=re.compile(rb'([\x01-\x0a])'+V+V+V+V+rb'('+V+rb')')
def value(data):
 n=0
 for shift,b in enumerate(data):n|=(b&127)<<(7*shift)
 return n

def audit(path):
 start=time.time();digest=hashlib.sha256();counts=collections.Counter();marks={};n=offset=0;pending=b'';gc=False;gcs=moves=census=0
 with path.open('rb') as f:
  line=f.readline(4097);assert line.endswith(b'\n') and len(line)<=4096
  header=json.loads(line);digest.update(line);offset=len(line);total=offset
  assert header['schema']=='raveldex-gc-extents-varint-v1' and header['fields']==['kind','address','to','bytes','old_bytes','marker']
  while True:
   block=f.read(1048576)
   if block:digest.update(block);total+=len(block)
   data=pending+block;last=0
   for m in ROW.finditer(data):
    if m.start()!=last:break
    last=m.end();kind=m[1][0];n+=1;counts[kind]+=1
    if kind==5:
     marker=value(m[2]);assert len(marks)<4096 or marker in marks
     row=marks.setdefault(marker,{'count':0,'firstSequence':n,'lastSequence':n});row['count']+=1;row['lastSequence']=n
    elif kind==8:assert not gc;gc=True;gcs+=1
    elif kind==9:assert gc;gc=False
    elif kind==2 and gc:moves+=1
    elif kind==10:assert gc;census+=1
   offset+=last;pending=data[last:]
   if pending.startswith(b'\0'):
    assert len(pending)<8192
    while True:
     block=f.read(8192)
     if not block:break
     digest.update(block);total+=len(block);pending+=block
     assert len(pending)<=8192,'Footer/trailing bound'
    break
   assert len(pending)<=60,('Invalid record or unexpected bytes',offset,len(pending))
   assert block,'Missing footer or truncated record'
  assert pending[0]==0
  fm=re.compile(V).match(pending,1);assert fm is not None
  length=value(fm[0]);assert 0<length<=4096 and len(pending)==fm.end()+length
  summary=json.loads(pending[fm.end():]);assert summary['events']==n and summary['stream_bytes_before_summary']==offset
  assert summary['attempted_events']==n+summary['dropped_events'] and summary['gc_cycles']==gcs and summary['gc_moves']==moves and summary['census_objects']==census
  assert total==path.stat().st_size and total<=header['stream_byte_cap']
  if summary['valid']:assert not gc and summary['errors']==summary['dropped_events']==0 and summary['aborted'] is False
  assert marks.get(100,{}).get('count')==marks.get(101,{}).get('count')==1 and marks[100]['firstSequence']<marks[101]['firstSequence']
 return {'path':str(path),'sha256':digest.hexdigest(),'bytes':total,'events':n,'eventKinds':dict(counts),'marks':marks,'header':header,'summary':summary,'canonicalFraming':'Pass','markerCardinality':'Pass','gcPairingAndCounts':'Pass','extentMetricsIndependentlyReplayed':False,'elapsedSeconds':time.time()-start}
if __name__=='__main__':
 result={'schema':'raveldex-independent-gc-framing-audit-v1','status':'Pass','scope':'Complete canonical varint framing, counts, GC pairing, unique ordered markers, footer and raw SHA only; does not recompute occupied extent metrics.','scriptSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'results':[audit(pathlib.Path(p)) for p in sys.argv[1:]]}
 print(json.dumps(result,indent=2))
