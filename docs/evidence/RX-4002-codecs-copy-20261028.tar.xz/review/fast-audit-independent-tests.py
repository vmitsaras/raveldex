import sys
sys.dont_write_bytecode=True
import hashlib,importlib.util,json,pathlib
ROOT=pathlib.Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/review'); REPO=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex')
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
slow=module('review_slow',REPO/'bench/memory/gc-runtime-audit.py');fast=module('review_fast',REPO/'bench/memory/gc-runtime-fast-audit.py')
HEADER={'schema':'raveldex-gc-extents-varint-v1','fields':['kind','address','to','bytes','old_bytes','marker'],'single_threaded':True,'incremental_marking':False,'inline_new':False,'turbo_allocation_folding':False,'collector_overlap_measured':False,'includes_preexisting_objects':False,'physical_memory_measured':False,'active_extent_cap_per_map':64,'map_count_max':5,'stream_byte_cap':1048576,'stdio_buffer_bytes':65536}
def u(n):
 result=bytearray()
 while n>=128:result.append((n&127)|128);n>>=7
 result.append(n);return bytes(result)
def tape(name,rows,summary):
 raw=json.dumps(HEADER).encode()+b'\n'+b''.join(u(n) for row in rows for n in row)
 footer={'events':len(rows),'attempted_events':len(rows),'dropped_events':0,'stream_bytes_before_summary':len(raw),'valid':True,'errors':0,'aborted':False,**summary}
 b=json.dumps(footer).encode();p=ROOT/(name+'.rdxgc');p.write_bytes(raw+b'\0'+u(len(b))+b);return p
metrics=('gross_birth_bytes','mutator_occupied_high_water_bytes','occupied_at_stop_bytes','trimmed_bytes','gc_removed_bytes')
rows=[(5,0,0,0,0,100),(1,100,0,20,0,0),(2,100,104,16,0,0),(3,104,0,8,16,0),(8,0,0,8,0,0),(2,104,200,8,0,0),(2,300,104,4,0,0),(10,104,0,4,0,0),(10,200,0,8,0,0),(9,0,0,8,8,0),(8,0,0,8,0,1),(9,0,0,0,8,1),(5,0,0,0,20,101)]
summary=dict(zip(metrics,[20,20,0,12,8]),gc_cycles=2,gc_moves=2,census_objects=2,heap_gc_count_start=0,heap_gc_count_stop=2)
results=[];exe=ROOT/'independent-gc-runtime-replay'
def both(name,path,expected=True):
 reports=[]
 for name2,fn in [('slow',lambda:slow.audit(path)),('fast',lambda:fast.audit(path,exe))]:
  try:r=fn();reports.append({'implementation':name2,'accepted':True,'report':r})
  except Exception as e:reports.append({'implementation':name2,'accepted':False,'errorType':type(e).__name__,'error':str(e)})
 assert all(r['accepted']==expected for r in reports),reports
 if expected:
  a,b=(r['report'] for r in reports)
  for key in ['sha256','bytes','events','valid','independentReplay','summary','marks']:assert json.loads(json.dumps(a[key]))==json.loads(json.dumps(b[key])),(name,key)
 results.append({'name':name,'status':'Pass','accepted':expected,'reports':reports})
p=tape('review-trim-shrink-frozen-move-death',rows,summary);both('trim/shrink/frozenMoves/death',p)
both('tamperedValidMetricRejected',tape('review-tampered-metric',rows,{**summary,'mutator_occupied_high_water_bytes':21}),False)
invalid=dict.fromkeys(metrics,None);invalid.update(valid=False,errors=1)
both('invalidMovedTrackedShrinkNullPrefix',tape('review-moved-shrink',[(1,100,0,8,0,0),(8,0,0,8,0,0),(2,100,200,8,0,0),(3,200,0,4,8,0)],invalid))
both('u64ExtentOverflowNullPrefix',tape('review-u64-overflow',[(1,2**64-3,0,4,0,0)],invalid))
p=tape('review-malformed-varint',[],invalid);raw=p.read_bytes();line=raw.index(b'\n')+1;p.write_bytes(raw[:line]+b'\x81'*9+b'\x02'+raw[line:]);both('u64VarintOverflowRejected',p,False)
p=tape('review-truncation',rows,summary);p.write_bytes(p.read_bytes()[:-1]);both('truncationRejected',p,False)
p=tape('review-trailing',rows,summary);p.write_bytes(p.read_bytes()+b'X');both('trailingBytesRejected',p,False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
print(json.dumps({'schema':'raveldex-independent-fast-replay-tests-v1','status':'Pass','tests':len(results),'sourceHashes':{str(p):sha(p) for p in [pathlib.Path(__file__),exe,ROOT/'audited-gc-runtime-replay.cc',REPO/'bench/memory/gc-runtime-fast-audit.py',REPO/'bench/memory/gc-runtime-replay.cc',REPO/'bench/memory/gc-runtime-audit.py']},'results':results},indent=2))
