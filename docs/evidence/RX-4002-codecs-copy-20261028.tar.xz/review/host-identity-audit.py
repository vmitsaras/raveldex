import hashlib,json,pathlib,sys
ROOT=pathlib.Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn');REPO=pathlib.Path('/Users/vasilis/Documents/GitHub/raveldex')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
rows=[]
for path in sorted((ROOT/'codecs').glob('*/host.json')):
 d=json.loads(path.read_text());assert d['schema']=='raveldex-gc-codec-matrix-host-v1';files=d['productionFiles'];assert len(files)==208 and len({r['path'] for r in files})==208
 for s in d['sources']:assert sha(REPO/s['path'])==sha(pathlib.Path(s['target']))==s['sha256']
 expectedflags=['--expose-internals','--expose-gc','--no-inline-new','--no-turbo-allocation-folding','--single-threaded','--no-incremental-marking','--min-semi-space-size=16','--max-semi-space-size=16']
 processrows=[]
 for process in d['processes']:
  if 'exitCode' not in process:continue
  argv=process['argv'];runtime=pathlib.Path(argv[0]);consumer=pathlib.Path(process['cwd']);installed=consumer/'node_modules/@vmitsaras/raveldex'
  assert argv[1:9]==expectedflags
  assert sha(runtime)==d['runtimeSha256']=='ad443b2a6fc8092abeeb3ae8c6405e101cf15fc531f05eb769da4707d5154ae0'
  assert sha(consumer/'vmitsaras-raveldex-0.0.0.tgz')==d['packageSha256']=='6ff6e90128f60af39bb8f47800c61ed83d85d4ded7a8e3c96d2bd34467f9c437'
  for f in files:assert sha(installed/f['path'])==sha(REPO/f['path'])==f['sha256']
  assert argv[10:14]==[d['mode'],str(d['size']),process['role'],d['format']]
  folder=pathlib.Path(argv[14]);child=json.loads((folder/'report.json').read_text());assert child==process['child']
  assert process['exitCode']==0 and child['disposed'] is True and child['deadlineMs']==60000 and child['batchSize']==256 and child['changedFixture'] is False
  assert child['runtime']['argv']==expectedflags and pathlib.Path(child['runtime']['path']).resolve()==runtime.resolve()
  assert all(process[k] is True for k in ('runtimeUnchanged','productionUnchanged','sourcesUnchanged'))
  for artifact in process['artifacts']:
   f=folder/artifact['name'];assert f.stat().st_size==artifact['bytes'] and sha(f)==artifact['sha256']
  processrows.append({'role':process['role'],'pid':child['runtime']['pid'],'publicOutcome':child['operation']['publicOutcome'],'traceStatus':child['traceStatus'],'allArtifactHashes':'Pass','production208CurrentMatches':'Pass','exactArgvAndRuntime':'Pass'})
 assert len({r['pid'] for r in processrows})==len(processrows)
 rows.append({'path':str(path),'sha256':sha(path),'sources':d['sources'],'processes':processrows,'finished':d.get('finished')})
print(json.dumps({'schema':'raveldex-independent-host-identity-audit-v1','status':'Pass','scriptSha256':sha(pathlib.Path(__file__)),'scope':'Actual current208productionfile identities, staged/repositorysource hashes, runtime/package bytes, exact argv, saved child reports and each finalized artifact hash. Host booleans separately attest before/after execution; reviewer did not witness launch in real time.','results':rows},indent=2))
