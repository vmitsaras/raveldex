"""Offline assertions over cumulative native rows. No browser/LLDB imports."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

from wire_metadata import decode


def controller_parity(record,report_path,install_path):
    report=json.loads(Path(report_path).read_text())
    install=json.loads(Path(install_path).read_text());config=install['config']
    assert report['schema']=='raveldex-native-message-control-v1'
    assert report['rendererPid']==record['pid']==config['pid']==install['pid']
    assert report['binarySha256']==install['binarySha256']
    trace_path=Path(report_path).with_name('pid-proof-trace.json')
    trace=trace_path.read_bytes()
    assert hashlib.sha256(trace).hexdigest()==report['pidProof']['sha256']
    marks=report['pidProof']['marks'];label=report['pidProof']['label']
    for realm,config_key in [('main','mainTid'),('worker','workerTid')]:
        mark=[row for row in marks if row['name']==label+':'+realm]
        assert len(mark)==1 and mark[0]['pid']==record['pid'] and mark[0]['tid']==config[config_key]
        assert mark[0] in json.loads(trace)['traceEvents']
    peer=report['workerTarget']['targetInfo']
    assert peer['type']=='worker' and peer['url']==report['workerUrl']
    assert report['isolates']['main']['id']!=report['isolates']['worker']['id']
    latest={}
    snapshots=[report['initialObservation']]+[command['observations'] for command in report['commands'] if 'observations' in command]
    for snapshot in snapshots:
        for realm in ('main','worker'):
            value=snapshot[realm];assert value['dropped']==0 and value['realm']==realm
            rows=value['rows'];old=latest.get(realm,[])
            assert len(rows)>=len(old) and rows[:len(old)]==old
            assert [row['sequence'] for row in rows]==list(range(1,len(rows)+1))
            latest[realm]=rows
    identities={}
    keys=('protocol','session','id','operation','kind')
    for realm,rows in latest.items():
        for row in rows:
            assert row['realm']==realm and row['protocol']==1
            identity=tuple(row[key] for key in keys)
            identities.setdefault(identity,Counter())[(realm,row['direction'],row['edge'])]+=1
    matched=[]
    for chain,metadata in record['bindings'].items():
        assert metadata['peer']==config['peer'] and metadata['processId']==record['pid']
        direction=metadata['direction'];sender='main' if direction=='main-to-worker' else 'worker';receiver='worker' if sender=='main' else 'main'
        assert metadata['senderTid']==config['mainTid' if sender=='main' else 'workerTid']
        identity=tuple(metadata[key] for key in keys)
        expected=Counter({(sender,'send','begin'):1,(sender,'send','end'):1,(receiver,'read','begin'):1,(receiver,'read','end'):1})
        assert identities[identity]==expected
        matched.append(dict(chain=int(chain),protocol=metadata['protocol'],session=metadata['session'],id=metadata['id'],operation=metadata['operation'],kind=metadata['kind'],direction=direction,
                            senderTid=metadata['senderTid'],rendererPid=record['pid'],workerTargetId=peer['targetId'],workerUrl=peer['url'],peerLabel=config['peer'],fourControllerEdges='Pass'))
    return dict(reportSha256=hashlib.sha256(Path(report_path).read_bytes()).hexdigest(),installSha256=hashlib.sha256(Path(install_path).read_bytes()).hexdigest(),
                pidTraceSha256=report['pidProof']['sha256'],matched=matched,actualMessageIdentities=len(identities),boundNativeChains=len(matched),
                coverage='Every bound native chain matches four unchanged actual controller envelope edges; messages outside native scope remain separately unqualified.')


def audit(path,report_path=None,install_path=None):
    record=json.loads(Path(path).read_text())
    assert record['schema']=='raveldex-lldb-buffer-observation-v2'
    assert record['dropped']==0 and record['invalid']==[] and record['pending']=={}
    rows=record['rows'];live={};calls={};births={};bound={};free_calls={};closed=[];api_retirements=[];returned={};next_call=0
    counts=Counter();payload_entries={}
    for expected_seq,row in enumerate(rows,1):
        assert row['seq']==expected_seq and row['pid']==record['pid']
        kind=row['kind'];counts[kind]+=1;tid=row['tid'];frame=row['nativeFrame']
        if tid:
            assert isinstance(frame,dict) and all(isinstance(frame[key],int) and frame[key]>=0 for key in ('pc','sp','lr','fp','moduleOffset'))
        if kind=='native-call-begin':
            ctx=row['call'];stack=calls.setdefault(tid,[])
            if ctx['kind']=='payload-copy':
                enter=payload_entries.pop(tid)
                assert all(ctx[k]==enter[k] for k in ('ptr','allocation','chain','src','dest','length','site'))
                assert frame['moduleOffset']==ctx['site']
                expected_return=ctx['entryPC']+4 if ctx['site']==0x17009b8 else ctx['lr']
                assert ctx['returnPC']==expected_return
            assert ctx['entryPC']==frame['pc'] and ctx['sp']==frame['sp'] and ctx['lr']==frame['lr']
            assert ctx['parentCallId']==(stack[-1]['callId'] if stack else None)
            next_call+=1
            assert ctx['callId']==next_call
            stack.append(ctx)
        elif kind=='native-call-return':
            ctx=calls[tid].pop()
            assert ctx['callId']==row['callId']
            assert ctx['sp']==frame['sp']==row['matchedSP']
            assert ctx['returnPC']==frame['pc']==row['matchedReturnPC']
            assert ctx['lr']==row['matchedLR'] and ctx['entryPC']==row['matchedEntryPC']
            assert frame['lr']==ctx['returnPC']
            assert tid not in returned
            returned[tid]=ctx
            if ctx['kind']=='final-free':
                assert free_calls[ctx['callId']]['rootSeen']
        elif kind=='buffer-live':
            ptr=row['ptr'];allocation=row['allocation']
            assert ptr not in live and allocation not in births and ptr>0 and row['cap']>=0
            assert allocation==len(births)+1
            live[ptr]=dict(allocation=allocation,cap=row['cap'],chain=row['chain'],tid=tid)
            births[allocation]=dict(ptr=ptr,chain=row['chain'],tid=tid)
        elif kind=='buffer-confirmed':
            assert live[row['ptr']]==dict(allocation=row['allocation'],cap=row['cap'],chain=row['chain'],tid=tid)
        elif kind=='buffer-resize':
            assert live[row['ptr']]['allocation']==row['allocation']
            live[row['ptr']]['cap']=row['cap']
        elif kind=='api-only-retirement':
            assert row['ptr'] in live
            api_retirements.append(live.pop(row['ptr']))
        elif kind=='payload-copy-enter':
            assert tid not in payload_entries;payload_entries[tid]=row
            data=live[row['ptr']]
            assert data['allocation']==row['allocation'] and data['chain']==row['chain']
            assert row['ptr']<=row['dest']<row['dest']+row['length']<=row['ptr']+data['cap']
            assert row['src']>0 and row['site'] in (0x17009b8,0x3de04f0)
            assert frame['moduleOffset']==row['site']
            if row['site']==0x3de04f0:assert row['length']%2==0
        elif kind=='payload-copy-return':
            ctx=returned.pop(tid);assert ctx['kind']=='payload-copy'
            assert all(row[k]==ctx[k] for k in ('ptr','allocation','chain','src','dest','length','site'))
            assert row['returned']==row['dest']
            assert live[row['ptr']]['allocation']==row['allocation']
            if row['site']==0x17009b8:assert frame['moduleOffset']==0x17009bc
        elif kind=='copy-enter':
            assert row['src'] in live and row['dest'] not in live and row['src']!=row['dest']
            assert row['oldCap']==live[row['src']]['cap'] and row['length']<=min(row['oldCap'],row['newCap'])
        elif kind=='final-free-enter':
            assert row['ptr'] in live
            destructor=calls[tid][-1]
            assert destructor['kind']=='destructor' and destructor['callId']==row['destructorCallId']
            assert destructor['ptr']==row['ptr'] and destructor['allocation']==row['allocation'] and destructor['owner']==row['owner']
            assert frame['moduleOffset']==0x19ca210
        elif kind=='final-free-root-enter':
            ctx=calls[tid][-1]
            assert ctx['kind']=='final-free' and ctx['callId']==row['callId'] and ctx['ptr']==row['ptr']
            assert frame['moduleOffset']==0x1d6d0
            free_calls[row['callId']]=dict(rootSeen=True)
        elif kind in ('root-free-return','internal-free-return','final-free-return'):
            ctx=returned.pop(tid)
            assert kind==ctx['kind']+'-return'
            assert all(row[key]==ctx[key] for key in ('ptr','cap','chain','allocation'))
            data=live.pop(row['ptr'])
            assert data['allocation']==row['allocation'] and data['cap']==row['cap'] and data['chain']==row['chain']
            closed.append(dict(allocation=data['allocation'],chain=data['chain'],kind=kind,seq=row['seq']))
        elif kind in ('realloc-return','copy-return','buffer-alloc-return','destructor-return'):
            ctx=returned.pop(tid)
            assert {'realloc-return':'realloc','copy-return':'copy','buffer-alloc-return':'alloc','destructor-return':'destructor'}[kind]==ctx['kind']
        elif kind=='message-bound':
            data=live[row['ptr']];metadata=row['metadata'];prefix=bytes.fromhex(metadata['prefixHex'])
            assert data['allocation']==row['allocation'] and data['chain']==row['chain']
            assert len(prefix)==metadata['prefixBytes']<=min(data['cap'],metadata['wireBytes'],256)
            parsed=decode(lambda offset,count:prefix[offset:offset+count],len(prefix))
            assert all(parsed[key]==metadata[key] for key in parsed)
            assert metadata['senderTid']==data['tid'] and metadata['processId']==record['pid']
            if row['chain'] in bound:
                assert all(bound[row['chain']][key]==metadata[key] for key in ('session','id','operation','kind','direction'))
            bound[row['chain']]=metadata
    assert not any(calls.values()) and not returned and not payload_entries
    assert {str(chain):value for chain,value in bound.items()}==record['bindings']
    assert {str(ptr):(data['allocation'],data['cap'],data['chain']) for ptr,data in live.items()}=={
        ptr:(data['allocation'],data['cap'],data['chain']) for ptr,data in record['remaining'].items()}
    qualified=[]
    for freed in closed:
        if freed['kind']=='final-free-return' and freed['chain'] in bound:
            qualified.append(dict(**freed,metadata=bound[freed['chain']]))
    parity=controller_parity(record,report_path,install_path) if report_path else None
    return dict(schema='raveldex-native-buffer-replay-v2',source=str(Path(path).resolve()),sourceSha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),controllerParity=parity,
                selectedStringCopyCalls=counts['payload-copy-return'],selectedStringCopyBytes=sum(r['length'] for r in rows if r['kind']=='payload-copy-return'),
                rows=len(rows),counts=dict(counts),births=len(births),remaining=len(live),boundChains=len(bound),
                observedBoundFinalFrees=qualified,apiOnlyRetirements=api_retirements,
                limits=['No full-payload copy total, global high-water, or physical memory claim.',
                        'Qualification requires external controller metadata/process/thread/peer parity; replay only verifies internal row consistency.',
                        'No free is inferred for remaining buffers; explicit GC controls retain their separate scope.'])


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('path');parser.add_argument('--controller');parser.add_argument('--install');args=parser.parse_args()
    assert bool(args.controller)==bool(args.install)
    print(json.dumps(audit(args.path,args.controller,args.install),indent=2))
