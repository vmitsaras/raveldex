from pathlib import Path
r=Path(__file__).parent;p=r/'lldb_native_tap.py';s=p.read_text()
s=s.replace('# Task-owned LLDB observer: no target calls, payload reads or argument edits.','# Task-owned LLDB observer: no target calls, full payload reads or argument edits.\n# Direct string copies record pointers/counts only; contents are never read.')
s=s.replace("    elif kind=='destructor':\n", "    elif kind=='payload-copy':\n        data=LIVE.get(ctx['ptr'])\n        if not data or data['allocation']!=ctx['allocation']:problem('payload_generation_mismatch')\n        if reg(frame,'x0')!=ctx['dest']:problem('payload_return_not_destination')\n        event('payload-copy-return',tid,**{k:ctx[k] for k in ('ptr','allocation','chain','src','dest','length','site')},returned=reg(frame,'x0'))\n    elif kind=='destructor':\n")
s=s.replace("        if role=='destructor':", """        if role in ('payload-onebyte','payload-twobyte'):
            dest=reg(frame,'x0');src=reg(frame,'x1');length=reg(frame,'x2')
            hits=[(ptr,data) for ptr,data in LIVE.items() if ptr<=dest<ptr+data['cap']]
            if not hits:return False
            if len(hits)!=1:problem('payload_destination_ambiguous');return False
            ptr,data=hits[0]
            if not src or not 0<length<=64*1024*1024 or dest+length>ptr+data['cap']:
                problem('payload_extent_invalid');return False
            if any(c['kind']=='payload-copy' for c in stack):problem('nested_payload_copy');return False
            site=pc-BASE
            fields=dict(ptr=ptr,allocation=data['allocation'],chain=data['chain'],src=src,dest=dest,length=length,site=site)
            event('payload-copy-enter',tid,**fields)
            pending(frame,'payload-copy',fields,BASE+0x17009bc if role=='payload-onebyte' else None)
        elif role=='destructor':""")
s=s.replace("(0x19ca210,'final-free')]:", "(0x19ca210,'final-free'),(0x17009b8,'payload-onebyte'),(0x3de04f0,'payload-twobyte')]:")
s=s.replace("API-reported/requested native buffer extents and selected growth-copy/final-deletion call sites; no OS physical pages, global high-water or full payload-copy coverage.","API-reported/requested serializer buffer extents, selected growth copies, direct one/two-byte string writes and final deletion. No complete transport-copy, all wire-store, deserializer, global native or physical memory claim.")
p.write_text(s)
p=r/'audit_tap.py';s=p.read_text();s=s.replace("        elif kind=='copy-enter':", """        elif kind=='payload-copy-enter':
            data=live[row['ptr']]
            assert data['allocation']==row['allocation'] and data['chain']==row['chain']
            assert row['ptr']<=row['dest']<row['dest']+row['length']<=row['ptr']+data['cap']
            assert row['src']>0 and row['site'] in (0x17009b8,0x3de04f0)
            assert frame['moduleOffset']==row['site']
        elif kind=='payload-copy-return':
            ctx=returned.pop(tid);assert ctx['kind']=='payload-copy'
            assert all(row[k]==ctx[k] for k in ('ptr','allocation','chain','src','dest','length','site'))
            assert row['returned']==row['dest']
            assert live[row['ptr']]['allocation']==row['allocation']
            if row['site']==0x17009b8:assert frame['moduleOffset']==0x17009bc
        elif kind=='copy-enter':""")
# A tail branch keeps the original LR; a BL updates LR to the instruction after BL.
# Existing generic frame equality already checks both exact patterns at return.
s=s.replace("                rows=len(rows),", "                selectedStringCopyCalls=counts['payload-copy-return'],selectedStringCopyBytes=sum(r['length'] for r in rows if r['kind']=='payload-copy-return'),\n                rows=len(rows),")
p.write_text(s)
p=r/'test_observer.py';s=p.read_text().replace("path=root/'native-run-1/tap-5-export-gc-drain.json'", "path=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/native-run-1/tap-5-export-gc-drain.json')");p.write_text(s)
