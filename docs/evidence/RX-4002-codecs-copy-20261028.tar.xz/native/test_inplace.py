import sys,types,unittest
sys.modules['lldb']=types.SimpleNamespace()
import calibrate_inplace as control
from calibrate_inplace import qualify
class Tests(unittest.TestCase):
 def rows(self):return [dict(kind='buffer-live',ptr=1000,cap=129),dict(kind='realloc-return',old=1000,dest=1000,cap=130),dict(kind='buffer-resize',ptr=1000,cap=130,allocation=1),dict(kind='root-free-return',ptr=1000,cap=130,allocation=1)]
 def test_literal_same_pointer_resize(self):self.assertTrue(qualify(self.rows(),1000,129,130)['unchangedPointer'])
 def test_moved_refuses(self):
  r=self.rows();r[1]['dest']=2000
  with self.assertRaises(AssertionError):qualify(r,1000,129,130)
 def test_copy_refuses(self):
  with self.assertRaises(AssertionError):qualify(self.rows()+[dict(kind='copy-enter')],1000,129,130)
 def test_stale_free_refuses(self):
  r=self.rows();r[-1]['allocation']=2
  with self.assertRaises(AssertionError):qualify(r,1000,129,130)
 def test_missing_resize_refuses(self):
  with self.assertRaises(AssertionError):qualify([r for r in self.rows() if r['kind']!='buffer-resize'],1000,129,130)
class Preflight(unittest.TestCase):
 def setUp(self):
  self.old=control.rx;self.errors=[];control.rx=types.SimpleNamespace(INSTALLED=True,ACTIVE=True,INVALID=[],DROPPED=0,CALLS={},LIVE={},LABEL='inplace-control')
  self.result=types.SimpleNamespace(SetError=self.errors.append,PutCString=lambda _:self.fail('unexpected success'))
 def tearDown(self):control.rx=self.old
 def reject(self,argument='execute-owned-native-control'):
  control.run(None,argument,self.result,None);self.assertEqual(len(self.errors),1);self.assertIn('Refused',self.errors[0])
 def test_missing_explicit_argument_refuses(self):self.reject('')
 def test_invalid_observer_refuses(self):control.rx.INVALID=['lost'];self.reject()
 def test_pending_calls_refuse(self):control.rx.CALLS={1:[{}]};self.reject()
 def test_live_product_buffers_refuse(self):control.rx.LIVE={1000:{}};self.reject()
 def test_wrong_window_refuses(self):control.rx.LABEL='product';self.reject()
if __name__=='__main__':unittest.main(verbosity=2)
