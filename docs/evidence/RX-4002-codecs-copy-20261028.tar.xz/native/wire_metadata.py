"""Strict, bounded V8-16 / Blink-21 *prefix* decoder for Raveldex metadata.

The caller supplies exact reads from a known task-owned native allocation.
Never consumes payload/value, recursively decodes data, or searches for strings.
"""
import re
import struct


class PrefixError(ValueError):
    pass


def decode(read, available, maximum=256):
    offset = 0
    raw = bytearray()

    def take(count):
        nonlocal offset
        if count < 0 or offset + count > min(available, maximum):
            raise PrefixError('prefix_bound')
        data = read(offset, count)
        if len(data) != count:
            raise PrefixError('short_read')
        offset += count
        raw.extend(data)
        return data

    def byte():
        return take(1)[0]

    def varint():
        value = 0
        for shift in range(0, 35, 7):
            part = byte()
            value |= (part & 127) << shift
            if not part & 128:
                if value > 0xffffffff:
                    raise PrefixError('varint_overflow')
                return value
        raise PrefixError('varint_overflow')

    def tag():
        value = byte()
        # V8 emits optional zero padding for aligned two-byte strings.
        while value == 0:
            value = byte()
        return value

    def string():
        kind = tag()
        length = varint()
        if kind not in (ord('"'), ord('S'), ord('c')) or length > 96:
            raise PrefixError('unsupported_metadata_string')
        data = take(length)
        try:
            return data.decode({ord('"'): 'latin1', ord('S'): 'utf8', ord('c'): 'utf-16-le'}[kind])
        except UnicodeError as error:
            raise PrefixError('invalid_metadata_string') from error

    def integer():
        kind = tag()
        if kind in (ord('I'), ord('U')):
            number = varint()
            return (number >> 1) ^ -(number & 1) if kind == ord('I') else number
        if kind == ord('N'):
            number = struct.unpack('<d', take(8))[0]
            if number.is_integer() and 0 <= number <= 2**53 - 1:
                return int(number)
        raise PrefixError('unsupported_metadata_integer')

    if byte() != 0xff or varint() != 21 or byte() != 0xfe:
        raise PrefixError('unsupported_blink_header')
    trailer = take(12)
    if byte() != 0xff or varint() != 16 or tag() != ord('o'):
        raise PrefixError('unsupported_v8_header')
    if string() != 'protocol' or integer() != 1:
        raise PrefixError('not_raveldex_protocol')
    if string() != 'session':
        raise PrefixError('unexpected_key_order')
    session = string()
    if not re.fullmatch('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', session):
        raise PrefixError('invalid_session')
    if string() != 'id':
        raise PrefixError('unexpected_key_order')
    identifier = integer()
    if identifier < 1:
        raise PrefixError('invalid_request_id')
    if string() != 'operation':
        raise PrefixError('unexpected_key_order')
    operation = string()
    if operation not in ('init', 'search', 'add', 'addMany', 'replace', 'remove', 'clear', 'reconcile', 'dispose', 'snapshotExportSource', 'snapshotRestore', 'snapshotReconcile', 'cancel'):
        raise PrefixError('unknown_operation')
    next_key = string()
    if next_key == 'payload':
        direction, kind = 'main-to-worker', None
    elif next_key == 'kind':
        kind = string()
        if kind not in ('result', 'error') or string() != 'value':
            raise PrefixError('invalid_response_prefix')
        direction = 'worker-to-main'
    else:
        raise PrefixError('unexpected_key_order')
    return dict(protocol=1, session=session, id=identifier, operation=operation,
                kind=kind, direction=direction, prefixBytes=offset,
                prefixHex=raw.hex(), trailerHeaderHex=trailer.hex())
