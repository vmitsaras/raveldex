
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100e59aa8 <_fontations_ffi$cxxbridge1$199$num_color_stops>:
1016ffb00: 949dc513    	bl	0x103e70f4c <__v8_internal_Print_TransitionTree+0x228564>
1016ffb04: d4200000    	brk	#0
1016ffb08: d4400000    	hlt	#0
1016ffb0c: d4200020    	brk	#0x1
1016ffb10: 97a5ab66    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
1016ffb14: aa0003f6    	mov	x22, x0
1016ffb18: 17fffd62    	b	0x1016ff0a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a55f8>
1016ffb1c: f9011b5b    	str	x27, [x26, #0x230]
1016ffb20: aa1a03e0    	mov	x0, x26
1016ffb24: 97b12ba0    	bl	0x10034a9a4 <_cxxbridge1$slice$new+0x304ec8>
1016ffb28: 17fffde9    	b	0x1016ff2cc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5824>
1016ffb2c: a941a295    	ldp	x21, x8, [x20, #0x18]
1016ffb30: 910006b6    	add	x22, x21, #0x1
1016ffb34: eb0802df    	cmp	x22, x8
1016ffb38: 54003028    	b.hi	0x10170013c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6694>
1016ffb3c: f9000e96    	str	x22, [x20, #0x18]
1016ffb40: f9400a88    	ldr	x8, [x20, #0x10]
1016ffb44: 52800bc9    	mov	w9, #0x5e               ; =94
1016ffb48: 38356909    	strb	w9, [x8, x21]
1016ffb4c: b9400268    	ldr	w8, [x19]
1016ffb50: 51000501    	sub	w1, w8, #0x1
1016ffb54: aa1403e0    	mov	x0, x20
1016ffb58: 97e48a8a    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
1016ffb5c: 3940aa88    	ldrb	w8, [x20, #0x2a]
1016ffb60: 35000068    	cbnz	w8, 0x1016ffb6c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a60c4>
1016ffb64: 52802036    	mov	w22, #0x101             ; =257
1016ffb68: 17fffdd9    	b	0x1016ff2cc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5824>
1016ffb6c: aa1403e0    	mov	x0, x20
1016ffb70: 52803b41    	mov	w1, #0x1da              ; =474
1016ffb74: 949b874f    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
1016ffb78: 1400000a    	b	0x1016ffba0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a60f8>
1016ffb7c: 51049668    	sub	w8, w19, #0x125
1016ffb80: 7100091f    	cmp	w8, #0x2
1016ffb84: 54ffa163    	b.lo	0x1016fefb0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5508>
1016ffb88: 7110427f    	cmp	w19, #0x410
1016ffb8c: 54ffa120    	b.eq	0x1016fefb0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5508>
1016ffb90: aa1403e0    	mov	x0, x20
1016ffb94: 52803b21    	mov	w1, #0x1d9              ; =473
1016ffb98: aa1603e2    	mov	x2, x22
1016ffb9c: 949b82eb    	bl	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
1016ffba0: 52800016    	mov	w22, #0x0               ; =0
1016ffba4: 17fffdca    	b	0x1016ff2cc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5824>
1016ffba8: 9100a3e0    	add	x0, sp, #0x28
1016ffbac: 94189c65    	bl	0x101d26d40 <_crabby_avifPeekCompatibleFileType+0x93034>
1016ffbb0: 34ffa0c0    	cbz	w0, 0x1016fefc8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5520>
1016ffbb4: 17fffffb    	b	0x1016ffba0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a60f8>
1016ffbb8: 91000661    	add	x1, x19, #0x1
1016ffbbc: aa1403e0    	mov	x0, x20
1016ffbc0: 940004cc    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
1016ffbc4: 529fc028    	mov	w8, #0xfe01             ; =65025
1016ffbc8: 6a08001f    	tst	w0, w8
1016ffbcc: 54ffa721    	b.ne	0x1016ff0b0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5608>
1016ffbd0: 17fffd3c    	b	0x1016ff0c0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5618>
1016ffbd4: 91000661    	add	x1, x19, #0x1
1016ffbd8: aa1403e0    	mov	x0, x20
1016ffbdc: 940004c5    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
1016ffbe0: 529fc028    	mov	w8, #0xfe01             ; =65025
1016ffbe4: 6a08001f    	tst	w0, w8
1016ffbe8: 54ffb1e1    	b.ne	0x1016ff224 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a577c>
1016ffbec: 17fffd92    	b	0x1016ff234 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a578c>
1016ffbf0: 7110467f    	cmp	w19, #0x411
1016ffbf4: aa1503fa    	mov	x26, x21
1016ffbf8: aa1703fb    	mov	x27, x23
1016ffbfc: aa1803fc    	mov	x28, x24
1016ffc00: aa0103f6    	mov	x22, x1
1016ffc04: 54001a81    	b.ne	0x1016fff54 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64ac>
1016ffc08: aa1403e0    	mov	x0, x20
1016ffc0c: aa1603e1    	mov	x1, x22
1016ffc10: 949b839c    	bl	0x103de0a80 <__v8_internal_Print_TransitionTree+0x198098>
1016ffc14: 1400009b    	b	0x1016ffe80 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a63d8>
1016ffc18: aa1603e1    	mov	x1, x22
1016ffc1c: aa1c03f8    	mov	x24, x28
1016ffc20: aa1b03f7    	mov	x23, x27
1016ffc24: aa1a03f5    	mov	x21, x26
1016ffc28: 71208e7f    	cmp	w19, #0x823
1016ffc2c: 540003ac    	b.gt	0x1016ffca0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a61f8>
1016ffc30: 71202a7f    	cmp	w19, #0x80a
1016ffc34: 5400010d    	b.le	0x1016ffc54 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a61ac>
1016ffc38: 51202e68    	sub	w8, w19, #0x80b
1016ffc3c: 71000d1f    	cmp	w8, #0x3
1016ffc40: 540006a2    	b.hs	0x1016ffd14 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a626c>
1016ffc44: f9400021    	ldr	x1, [x1]
1016ffc48: aa1403e0    	mov	x0, x20
1016ffc4c: 949b871c    	bl	0x103de18bc <__v8_internal_Print_TransitionTree+0x198ed4>
1016ffc50: 1400003a    	b	0x1016ffd38 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6290>
1016ffc54: 51049668    	sub	w8, w19, #0x125
1016ffc58: 7100091f    	cmp	w8, #0x2
1016ffc5c: 540000c3    	b.lo	0x1016ffc74 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a61cc>
1016ffc60: 7110427f    	cmp	w19, #0x410
1016ffc64: 54fffc61    	b.ne	0x1016ffbf0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6148>
1016ffc68: aa1403e0    	mov	x0, x20
1016ffc6c: 949b82f9    	bl	0x103de0850 <__v8_internal_Print_TransitionTree+0x197e68>
1016ffc70: 14000032    	b	0x1016ffd38 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6290>
1016ffc74: aa0103f6    	mov	x22, x1
1016ffc78: f9400028    	ldr	x8, [x1]
1016ffc7c: f2681d1f    	tst	x8, #0xff000000
1016ffc80: aa1503fa    	mov	x26, x21
1016ffc84: aa1703fb    	mov	x27, x23
1016ffc88: aa1803fc    	mov	x28, x24
1016ffc8c: 540002e0    	b.eq	0x1016ffce8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6240>
1016ffc90: 926eb508    	and	x8, x8, #0xfffffffffffc0000
1016ffc94: b9400108    	ldr	w8, [x8]
1016ffc98: 37000288    	tbnz	w8, #0x0, 0x1016ffce8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6240>
1016ffc9c: 140000ae    	b	0x1016fff54 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64ac>
1016ffca0: 7120f67f    	cmp	w19, #0x83d
1016ffca4: 540002ac    	b.gt	0x1016ffcf8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6250>
1016ffca8: 51209268    	sub	w8, w19, #0x824
1016ffcac: 7100291f    	cmp	w8, #0xa
1016ffcb0: aa1503fa    	mov	x26, x21
1016ffcb4: aa1703fb    	mov	x27, x23
1016ffcb8: aa1803fc    	mov	x28, x24
1016ffcbc: aa0103f6    	mov	x22, x1
1016ffcc0: 54ff99c3    	b.lo	0x1016feff8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5550>
1016ffcc4: 5120ee68    	sub	w8, w19, #0x83b
1016ffcc8: 7100091f    	cmp	w8, #0x2
1016ffccc: 54000323    	b.lo	0x1016ffd30 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6288>
1016ffcd0: 7120f67f    	cmp	w19, #0x83d
1016ffcd4: aa1503fa    	mov	x26, x21
1016ffcd8: aa1703fb    	mov	x27, x23
1016ffcdc: aa1803fc    	mov	x28, x24
1016ffce0: aa0103f6    	mov	x22, x1
1016ffce4: 54001381    	b.ne	0x1016fff54 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64ac>
1016ffce8: aa1403e0    	mov	x0, x20
1016ffcec: aa1603e1    	mov	x1, x22
1016ffcf0: 949b8843    	bl	0x103de1dfc <__v8_internal_Print_TransitionTree+0x199414>
1016ffcf4: 14000063    	b	0x1016ffe80 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a63d8>
1016ffcf8: 7120fa7f    	cmp	w19, #0x83e
1016ffcfc: 540001a0    	b.eq	0x1016ffd30 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6288>
1016ffd00: 7121167f    	cmp	w19, #0x845
1016ffd04: 54000c21    	b.ne	0x1016ffe88 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a63e0>
1016ffd08: aa1403e0    	mov	x0, x20
1016ffd0c: 949b8442    	bl	0x103de0e14 <__v8_internal_Print_TransitionTree+0x19842c>
1016ffd10: 1400000a    	b	0x1016ffd38 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6290>
1016ffd14: 71203a7f    	cmp	w19, #0x80e
1016ffd18: 54001321    	b.ne	0x1016fff7c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64d4>
1016ffd1c: aa1403e0    	mov	x0, x20
1016ffd20: 52803b61    	mov	w1, #0x1db              ; =475
1016ffd24: 949b86e3    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
1016ffd28: 52800016    	mov	w22, #0x0               ; =0
1016ffd2c: 14000020    	b	0x1016ffdac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6304>
1016ffd30: aa1403e0    	mov	x0, x20
1016ffd34: 949b8832    	bl	0x103de1dfc <__v8_internal_Print_TransitionTree+0x199414>
1016ffd38: 12003c16    	and	w22, w0, #0xffff
1016ffd3c: 1400001c    	b	0x1016ffdac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6304>
1016ffd40: aa1603f9    	mov	x25, x22
1016ffd44: aa1c03f8    	mov	x24, x28
1016ffd48: aa1b03f7    	mov	x23, x27
1016ffd4c: aa1a03f5    	mov	x21, x26
1016ffd50: 7121767f    	cmp	w19, #0x85d
1016ffd54: 540001cd    	b.le	0x1016ffd8c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a62e4>
1016ffd58: 71217a7f    	cmp	w19, #0x85e
1016ffd5c: 54000100    	b.eq	0x1016ffd7c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a62d4>
1016ffd60: 7121d27f    	cmp	w19, #0x874
1016ffd64: 540004a1    	b.ne	0x1016ffdf8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6350>
1016ffd68: aa1403e0    	mov	x0, x20
1016ffd6c: aa1903e1    	mov	x1, x25
1016ffd70: 949b88a3    	bl	0x103de1ffc <__v8_internal_Print_TransitionTree+0x199614>
1016ffd74: aa0003f6    	mov	x22, x0
1016ffd78: 1400000d    	b	0x1016ffdac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6304>
1016ffd7c: aa1403e0    	mov	x0, x20
1016ffd80: aa1903e1    	mov	x1, x25
1016ffd84: 949b83e6    	bl	0x103de0d1c <__v8_internal_Print_TransitionTree+0x198334>
1016ffd88: 14000006    	b	0x1016ffda0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a62f8>
1016ffd8c: 7121467f    	cmp	w19, #0x851
1016ffd90: 540001c1    	b.ne	0x1016ffdc8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6320>
1016ffd94: f9400321    	ldr	x1, [x25]
1016ffd98: aa1403e0    	mov	x0, x20
1016ffd9c: 949b8307    	bl	0x103de09b8 <__v8_internal_Print_TransitionTree+0x197fd0>
1016ffda0: 3940aa88    	ldrb	w8, [x20, #0x2a]
1016ffda4: 350000c8    	cbnz	w8, 0x1016ffdbc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6314>
1016ffda8: 52802036    	mov	w22, #0x101             ; =257
1016ffdac: aa1503fa    	mov	x26, x21
1016ffdb0: aa1703fb    	mov	x27, x23
1016ffdb4: aa1803fc    	mov	x28, x24
1016ffdb8: 17fffd3d    	b	0x1016ff2ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5804>
1016ffdbc: aa1403e0    	mov	x0, x20
1016ffdc0: 52803b41    	mov	w1, #0x1da              ; =474
1016ffdc4: 17ffffd8    	b	0x1016ffd24 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a627c>
1016ffdc8: 7121567f    	cmp	w19, #0x855
1016ffdcc: aa1503fa    	mov	x26, x21
1016ffdd0: aa1703fb    	mov	x27, x23
1016ffdd4: aa1803fc    	mov	x28, x24
1016ffdd8: aa1903f6    	mov	x22, x25
1016ffddc: 54000bc1    	b.ne	0x1016fff54 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64ac>
1016ffde0: aa1403e0    	mov	x0, x20
1016ffde4: aa1603e1    	mov	x1, x22
1016ffde8: 946fc11f    	bl	0x1032f0264 <_media$cxxbridge1$199$init_symphonia_decoder+0x6f9814>
1016ffdec: 12003c16    	and	w22, w0, #0xffff
1016ffdf0: 3607a5f6    	tbz	w22, #0x0, 0x1016ff2ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5804>
1016ffdf4: 140000cc    	b	0x101700124 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a667c>
1016ffdf8: 7121d67f    	cmp	w19, #0x875
1016ffdfc: aa1503fa    	mov	x26, x21
1016ffe00: aa1703fb    	mov	x27, x23
1016ffe04: aa1803fc    	mov	x28, x24
1016ffe08: aa1903f6    	mov	x22, x25
1016ffe0c: 54000a41    	b.ne	0x1016fff54 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64ac>
1016ffe10: aa1403e0    	mov	x0, x20
1016ffe14: aa1603e1    	mov	x1, x22
1016ffe18: 949b8843    	bl	0x103de1f24 <__v8_internal_Print_TransitionTree+0x19953c>
1016ffe1c: 14000019    	b	0x1016ffe80 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a63d8>
1016ffe20: d1000529    	sub	x9, x9, #0x1
1016ffe24: aa1703f6    	mov	x22, x23
1016ffe28: 17fffc8b    	b	0x1016ff054 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a55ac>
1016ffe2c: aa1603f7    	mov	x23, x22
1016ffe30: 39400d53    	ldrb	w19, [x10, #0x3]
1016ffe34: 34ffff73    	cbz	w19, 0x1016ffe20 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6378>
1016ffe38: 531e7675    	lsl	w21, w19, #2
1016ffe3c: 39401156    	ldrb	w22, [x10, #0x4]
1016ffe40: 78407140    	ldurh	w0, [x10, #0x7]
1016ffe44: 7110841f    	cmp	w0, #0x421
1016ffe48: 54000060    	b.eq	0x1016ffe54 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a63ac>
1016ffe4c: 97a8d4ed    	bl	0x100135200 <_cxxbridge1$slice$new+0xef724>
1016ffe50: 14000002    	b	0x1016ffe58 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a63b0>
1016ffe54: 52800180    	mov	w0, #0xc                ; =12
1016ffe58: 4b0002a8    	sub	w8, w21, w0
1016ffe5c: 4b1302c9    	sub	w9, w22, w19
1016ffe60: 0b880928    	add	w8, w9, w8, asr #2
1016ffe64: 51000908    	sub	w8, w8, #0x2
1016ffe68: 31000d1f    	cmn	w8, #0x3
1016ffe6c: aa1703f6    	mov	x22, x23
1016ffe70: 54ff8ec2    	b.hs	0x1016ff048 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a55a0>
1016ffe74: aa1403e0    	mov	x0, x20
1016ffe78: aa1603e1    	mov	x1, x22
1016ffe7c: 949b8275    	bl	0x103de0850 <__v8_internal_Print_TransitionTree+0x197e68>
1016ffe80: 12003c16    	and	w22, w0, #0xffff
1016ffe84: 17fffd0a    	b	0x1016ff2ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5804>
1016ffe88: 71211a7f    	cmp	w19, #0x846
1016ffe8c: aa1503fa    	mov	x26, x21
1016ffe90: aa1703fb    	mov	x27, x23
1016ffe94: aa1803fc    	mov	x28, x24
1016ffe98: aa0103f6    	mov	x22, x1
1016ffe9c: 540005c1    	b.ne	0x1016fff54 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64ac>
1016ffea0: aa1403e0    	mov	x0, x20
1016ffea4: aa1603e1    	mov	x1, x22
1016ffea8: 949b8484    	bl	0x103de10b8 <__v8_internal_Print_TransitionTree+0x1986d0>
1016ffeac: 17fffff5    	b	0x1016ffe80 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a63d8>
1016ffeb0: a941a293    	ldp	x19, x8, [x20, #0x18]
1016ffeb4: 91000675    	add	x21, x19, #0x1
1016ffeb8: eb0802bf    	cmp	x21, x8
1016ffebc: 54001c68    	b.hi	0x101700248 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a67a0>
1016ffec0: f9000e95    	str	x21, [x20, #0x18]
1016ffec4: f9400a88    	ldr	x8, [x20, #0x10]
1016ffec8: 52800c29    	mov	w9, #0x61               ; =97
1016ffecc: 38336909    	strb	w9, [x8, x19]
1016ffed0: aa1403e0    	mov	x0, x20
1016ffed4: aa1603e1    	mov	x1, x22
1016ffed8: 97e489aa    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
1016ffedc: f9400280    	ldr	x0, [x20]
1016ffee0: f94013e1    	ldr	x1, [sp, #0x20]
1016ffee4: 52800002    	mov	w2, #0x0                ; =0
1016ffee8: 52800243    	mov	w3, #0x12               ; =18
1016ffeec: 52800024    	mov	w4, #0x1                ; =1
1016ffef0: 52800005    	mov	w5, #0x0                ; =0
1016ffef4: 52800006    	mov	w6, #0x0                ; =0
1016ffef8: 97d40442    	bl	0x100c01000 <_sfv$cxxbridge1$199$decode_item+0x14c73c>
1016ffefc: b40003c0    	cbz	x0, 0x1016fff74 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64cc>
1016fff00: aa0003e2    	mov	x2, x0
1016fff04: aa1403e0    	mov	x0, x20
1016fff08: f94013e1    	ldr	x1, [sp, #0x20]
1016fff0c: 940003a9    	bl	0x101700db0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7308>
1016fff10: 36000320    	tbz	w0, #0x0, 0x1016fff74 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64cc>
1016fff14: d360fc15    	lsr	x21, x0, #32
1016fff18: a941a293    	ldp	x19, x8, [x20, #0x18]
1016fff1c: 91000677    	add	x23, x19, #0x1
1016fff20: eb0802ff    	cmp	x23, x8
1016fff24: 54001ac8    	b.hi	0x10170027c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a67d4>
1016fff28: f9000e97    	str	x23, [x20, #0x18]
1016fff2c: f9400a88    	ldr	x8, [x20, #0x10]
1016fff30: 52800809    	mov	w9, #0x40               ; =64
1016fff34: 38336909    	strb	w9, [x8, x19]
1016fff38: aa1403e0    	mov	x0, x20
1016fff3c: aa1503e1    	mov	x1, x21
1016fff40: 97e48990    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
1016fff44: aa1403e0    	mov	x0, x20
1016fff48: aa1603e1    	mov	x1, x22
1016fff4c: 97e4898d    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
1016fff50: 17fffcd4    	b	0x1016ff2a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a57f8>
1016fff54: aa1403e0    	mov	x0, x20
1016fff58: 52803b21    	mov	w1, #0x1d9              ; =473
1016fff5c: aa1603e2    	mov	x2, x22
1016fff60: 949b81fa    	bl	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
1016fff64: 14000004    	b	0x1016fff74 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64cc>
1016fff68: aa1403e0    	mov	x0, x20
1016fff6c: 52803b41    	mov	w1, #0x1da              ; =474
1016fff70: 949b8650    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
1016fff74: 52800016    	mov	w22, #0x0               ; =0
1016fff78: 17fffccd    	b	0x1016ff2ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5804>
1016fff7c: 71203e7f    	cmp	w19, #0x80f
1016fff80: aa1503fa    	mov	x26, x21
1016fff84: aa1703fb    	mov	x27, x23
1016fff88: aa1803fc    	mov	x28, x24
1016fff8c: aa0103f6    	mov	x22, x1
1016fff90: 54fffe21    	b.ne	0x1016fff54 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a64ac>
1016fff94: aa1403e0    	mov	x0, x20
1016fff98: aa1603e1    	mov	x1, x22
1016fff9c: 949b84df    	bl	0x103de1318 <__v8_internal_Print_TransitionTree+0x198930>
1016fffa0: aa0003f6    	mov	x22, x0
1016fffa4: 17fffcc2    	b	0x1016ff2ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5804>
1016fffa8: b4000638    	cbz	x24, 0x10170006c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a65c4>
1016fffac: f9400a80    	ldr	x0, [x20, #0x10]
1016fffb0: aa1803e1    	mov	x1, x24
1016fffb4: 95d56269    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
1016fffb8: 17fffd56    	b	0x1016ff510 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5a68>
1016fffbc: aa0803e1    	mov	x1, x8
1016fffc0: 97a5aa3a    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
1016fffc4: aa0003e1    	mov	x1, x0
1016fffc8: 17fffde8    	b	0x1016ff768 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5cc0>
1016fffcc: 52800028    	mov	w8, #0x1                ; =1
1016fffd0: 3900aa88    	strb	w8, [x20, #0x2a]
1016fffd4: 17fffd30    	b	0x1016ff494 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a59ec>
1016fffd8: 91000661    	add	x1, x19, #0x1
1016fffdc: aa1403e0    	mov	x0, x20
1016fffe0: 940003c4    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
1016fffe4: 529fc028    	mov	w8, #0xfe01             ; =65025
1016fffe8: 6a08001f    	tst	w0, w8
1016fffec: 54ffaec1    	b.ne	0x1016ff5c4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5b1c>
1016ffff0: 17fffd79    	b	0x1016ff5d4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5b2c>
1016ffff4: 910006a1    	add	x1, x21, #0x1
1016ffff8: aa1403e0    	mov	x0, x20
1016ffffc: 940003bd    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
101700000: 529fc028    	mov	w8, #0xfe01             ; =65025
101700004: 6a08001f    	tst	w0, w8
101700008: 54ffbea1    	b.ne	0x1016ff7dc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5d34>
10170000c: 17fffdf8    	b	0x1016ff7ec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5d44>
101700010: aa0a012a    	orr	x10, x9, x10
101700014: b85ff14b    	ldur	w11, [x10, #-0x1]
101700018: 7114557f    	cmp	w11, #0x515
10170001c: 54000060    	b.eq	0x101700028 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6580>
101700020: 52800016    	mov	w22, #0x0               ; =0
101700024: 17fffd58    	b	0x1016ff584 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5adc>
101700028: fc403140    	ldur	d0, [x10, #0x3]
10170002c: d2e8660a    	mov	x10, #0x4330000000000000 ; =4841369599423283200
101700030: 9e670141    	fmov	d1, x10
101700034: 1e612800    	fadd	d0, d0, d1
101700038: 9e66000a    	fmov	x10, d0
10170003c: 52a8660b    	mov	w11, #0x43300000        ; =1127219200
101700040: eb4a817f    	cmp	x11, x10, lsr #32
101700044: 1a9f0156    	csel	w22, w10, wzr, eq
101700048: 17fffd4f    	b	0x1016ff584 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5adc>
10170004c: b4000178    	cbz	x24, 0x101700078 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a65d0>
101700050: f9400a80    	ldr	x0, [x20, #0x10]
101700054: aa1803e1    	mov	x1, x24
101700058: 95d56240    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
10170005c: 17fffe28    	b	0x1016ff8fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5e54>
101700060: 97a5aa12    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
101700064: aa0003f7    	mov	x23, x0
101700068: 17fffda2    	b	0x1016ff6f0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5c48>
10170006c: d4200000    	brk	#0
101700070: d4400000    	hlt	#0
101700074: d4200020    	brk	#0x1
101700078: d4200000    	brk	#0
10170007c: d4400000    	hlt	#0
101700080: d4200020    	brk	#0x1
101700084: 52800028    	mov	w8, #0x1                ; =1
101700088: 3900aa88    	strb	w8, [x20, #0x2a]
10170008c: 17fffd0b    	b	0x1016ff4b8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5a10>
101700090: d101bba1    	sub	x1, x29, #0x6e
101700094: aa1503e2    	mov	x2, x21
101700098: 95d56044    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
10170009c: 17fffc81    	b	0x1016ff2a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a57f8>
1017000a0: 91000661    	add	x1, x19, #0x1
1017000a4: aa1403e0    	mov	x0, x20
1017000a8: 94000392    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
1017000ac: 529fc028    	mov	w8, #0xfe01             ; =65025
1017000b0: 6a08001f    	tst	w0, w8
1017000b4: 54ff9521    	b.ne	0x1016ff358 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a58b0>
1017000b8: 17fffcac    	b	0x1016ff368 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a58c0>
1017000bc: 910006a1    	add	x1, x21, #0x1
1017000c0: aa1403e0    	mov	x0, x20
1017000c4: 9400038b    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
1017000c8: 529fc028    	mov	w8, #0xfe01             ; =65025
1017000cc: 6a08001f    	tst	w0, w8
1017000d0: 54ff9721    	b.ne	0x1016ff3b4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a590c>
1017000d4: 17fffcbc    	b	0x1016ff3c4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a591c>
1017000d8: d101bba1    	sub	x1, x29, #0x6e
1017000dc: aa1703e2    	mov	x2, x23
1017000e0: 95d56032    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
1017000e4: 17fffd56    	b	0x1016ff63c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5b94>
1017000e8: d101bba1    	sub	x1, x29, #0x6e
1017000ec: aa1503e2    	mov	x2, x21
1017000f0: 95d5602e    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
1017000f4: 17fffdd7    	b	0x1016ff850 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5da8>
1017000f8: 52800028    	mov	w8, #0x1                ; =1
1017000fc: 3900aa88    	strb	w8, [x20, #0x2a]
101700100: 17fffc68    	b	0x1016ff2a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a57f8>
101700104: b4000d16    	cbz	x22, 0x1017002a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a67fc>
101700108: f9400a80    	ldr	x0, [x20, #0x10]
10170010c: aa1603e1    	mov	x1, x22
101700110: 95d56212    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
101700114: f90017f6    	str	x22, [sp, #0x28]
101700118: a9416bfb    	ldp	x27, x26, [sp, #0x10]
10170011c: f94007fc    	ldr	x28, [sp, #0x8]
101700120: 17fffcd5    	b	0x1016ff474 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a59cc>
101700124: aa1403e0    	mov	x0, x20
101700128: aa1903e1    	mov	x1, x25
10170012c: 710402df    	cmp	w22, #0x100
101700130: 54ffd9e2    	b.hs	0x1016ffc6c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a61c4>
101700134: 949b8666    	bl	0x103de1acc <__v8_internal_Print_TransitionTree+0x1990e4>
101700138: 17ffff00    	b	0x1016ffd38 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6290>
10170013c: 910006a1    	add	x1, x21, #0x1
101700140: aa1403e0    	mov	x0, x20
101700144: 9400036b    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
101700148: 529fc028    	mov	w8, #0xfe01             ; =65025
10170014c: 6a08001f    	tst	w0, w8
101700150: 54ffcf61    	b.ne	0x1016ffb3c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6094>
101700154: 17fffe7e    	b	0x1016ffb4c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a60a4>
101700158: 529fc035    	mov	w21, #0xfe01            ; =65025
10170015c: 528005b8    	mov	w24, #0x2d              ; =45
101700160: 52802039    	mov	w25, #0x101             ; =257
101700164: 2a1303f7    	mov	w23, w19
101700168: 2a1603f3    	mov	w19, w22
10170016c: f9400281    	ldr	x1, [x20]
101700170: 9100a3e0    	add	x0, sp, #0x28
101700174: f94013e2    	ldr	x2, [sp, #0x20]
101700178: d2800003    	mov	x3, #0x0                ; =0
10170017c: aa1703e4    	mov	x4, x23
101700180: aa0203e5    	mov	x5, x2
101700184: 52800026    	mov	w6, #0x1                ; =1
101700188: 97a5e02c    	bl	0x100078238 <_cxxbridge1$slice$new+0x3275c>
10170018c: b9402fe8    	ldr	w8, [sp, #0x2c]
101700190: 340001c8    	cbz	w8, 0x1017001c8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6720>
101700194: 9100a3e0    	add	x0, sp, #0x28
101700198: 52800001    	mov	w1, #0x0                ; =0
10170019c: 97a5e0b0    	bl	0x10007845c <_cxxbridge1$slice$new+0x32980>
1017001a0: b4ffc8e0    	cbz	x0, 0x1016ffabc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6014>
1017001a4: aa0003e1    	mov	x1, x0
1017001a8: aa1403e0    	mov	x0, x20
1017001ac: 940000d4    	bl	0x1017004fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a54>
1017001b0: 6a20033f    	bics	wzr, w25, w0
1017001b4: 54ffc841    	b.ne	0x1016ffabc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6014>
1017001b8: 910006f7    	add	x23, x23, #0x1
1017001bc: eb17027f    	cmp	x19, x23
1017001c0: 54fffd61    	b.ne	0x10170016c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a66c4>
1017001c4: 17fffd70    	b	0x1016ff784 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5cdc>
1017001c8: a941a29a    	ldp	x26, x8, [x20, #0x18]
1017001cc: 9100075b    	add	x27, x26, #0x1
1017001d0: eb08037f    	cmp	x27, x8
1017001d4: 54000808    	b.hi	0x1017002d4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a682c>
1017001d8: f9000e9b    	str	x27, [x20, #0x18]
1017001dc: f9400a88    	ldr	x8, [x20, #0x10]
1017001e0: 383a6918    	strb	w24, [x8, x26]
1017001e4: 17fffff5    	b	0x1017001b8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6710>
1017001e8: b4000656    	cbz	x22, 0x1017002b0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6808>
1017001ec: f9400a80    	ldr	x0, [x20, #0x10]
1017001f0: aa1603e1    	mov	x1, x22
1017001f4: 95d561d9    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
1017001f8: f90017f6    	str	x22, [sp, #0x28]
1017001fc: 17fffc92    	b	0x1016ff444 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a599c>
101700200: b40005f8    	cbz	x24, 0x1017002bc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6814>
101700204: f9400a80    	ldr	x0, [x20, #0x10]
101700208: aa1803e1    	mov	x1, x24
10170020c: 95d561d3    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
101700210: f90017f8    	str	x24, [sp, #0x28]
101700214: 17fffdca    	b	0x1016ff93c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5e94>
101700218: 52800028    	mov	w8, #0x1                ; =1
10170021c: 3900aa88    	strb	w8, [x20, #0x2a]
101700220: 17fffd07    	b	0x1016ff63c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5b94>
101700224: b4000537    	cbz	x23, 0x1017002c8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6820>
101700228: f9400a80    	ldr	x0, [x20, #0x10]
10170022c: aa1703e1    	mov	x1, x23
101700230: 95d561ca    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
101700234: f90017f7    	str	x23, [sp, #0x28]
101700238: 17fffdd0    	b	0x1016ff978 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5ed0>
10170023c: 52800028    	mov	w8, #0x1                ; =1
101700240: 3900aa88    	strb	w8, [x20, #0x2a]
101700244: 17fffd83    	b	0x1016ff850 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5da8>
101700248: 91000661    	add	x1, x19, #0x1
10170024c: aa1403e0    	mov	x0, x20
101700250: 94000328    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
101700254: 529fc028    	mov	w8, #0xfe01             ; =65025
101700258: 6a08001f    	tst	w0, w8
10170025c: 54ffe321    	b.ne	0x1016ffec0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6418>
101700260: 17ffff1c    	b	0x1016ffed0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6428>
101700264: b40001b6    	cbz	x22, 0x101700298 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a67f0>
101700268: f9400a80    	ldr	x0, [x20, #0x10]
10170026c: aa1603e1    	mov	x1, x22
101700270: 95d561ba    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
101700274: f90017f6    	str	x22, [sp, #0x28]
101700278: 17fffc7f    	b	0x1016ff474 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a59cc>
10170027c: 91000661    	add	x1, x19, #0x1
101700280: aa1403e0    	mov	x0, x20
101700284: 9400031b    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
101700288: 529fc028    	mov	w8, #0xfe01             ; =65025
10170028c: 6a08001f    	tst	w0, w8
101700290: 54ffe4c1    	b.ne	0x1016fff28 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6480>
101700294: 17ffff29    	b	0x1016fff38 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6490>
101700298: d4200000    	brk	#0
10170029c: d4400000    	hlt	#0
1017002a0: d4200020    	brk	#0x1
1017002a4: d4200000    	brk	#0
1017002a8: d4400000    	hlt	#0
1017002ac: d4200020    	brk	#0x1
1017002b0: d4200000    	brk	#0
1017002b4: d4400000    	hlt	#0
1017002b8: d4200020    	brk	#0x1
1017002bc: d4200000    	brk	#0
1017002c0: d4400000    	hlt	#0
1017002c4: d4200020    	brk	#0x1
1017002c8: d4200000    	brk	#0
1017002cc: d4400000    	hlt	#0
1017002d0: d4200020    	brk	#0x1
1017002d4: 91000741    	add	x1, x26, #0x1
1017002d8: aa1403e0    	mov	x0, x20
1017002dc: 94000305    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
1017002e0: 6a15001f    	tst	w0, w21
1017002e4: 54fff6a0    	b.eq	0x1017001b8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6710>
1017002e8: 17ffffbc    	b	0x1017001d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6730>
1017002ec: 00000000    	udf	#0x0
1017002f0: d10183ff    	sub	sp, sp, #0x60
1017002f4: a90167fa    	stp	x26, x25, [sp, #0x10]
1017002f8: a9025ff8    	stp	x24, x23, [sp, #0x20]
1017002fc: a90357f6    	stp	x22, x21, [sp, #0x30]
101700300: a9044ff4    	stp	x20, x19, [sp, #0x40]
101700304: a9057bfd    	stp	x29, x30, [sp, #0x50]
101700308: 910143fd    	add	x29, sp, #0x50
10170030c: aa0103f5    	mov	x21, x1
101700310: aa0003f3    	mov	x19, x0
101700314: a941a017    	ldp	x23, x8, [x0, #0x18]
101700318: 910006f8    	add	x24, x23, #0x1
10170031c: eb08031f    	cmp	x24, x8
101700320: 54000628    	b.hi	0x1017003e4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a693c>
101700324: f9400a60    	ldr	x0, [x19, #0x10]
101700328: f9000e78    	str	x24, [x19, #0x18]
10170032c: 52800928    	mov	w8, #0x49               ; =73
101700330: 38376808    	strb	w8, [x0, x23]
101700334: d2800014    	mov	x20, #0x0               ; =0
101700338: 121f7aa8    	and	w8, w21, #0xfffffffe
10170033c: 4a957d09    	eor	w9, w8, w21, asr #31
101700340: 91002be8    	add	x8, sp, #0xa
101700344: aa0903ea    	mov	x10, x9
101700348: 32190129    	orr	w9, w9, #0x80
10170034c: 38346909    	strb	w9, [x8, x20]
101700350: 53077d49    	lsr	w9, w10, #7
101700354: 91000694    	add	x20, x20, #0x1
101700358: 35ffff69    	cbnz	w9, 0x101700344 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a689c>
10170035c: 91002be8    	add	x8, sp, #0xa
101700360: 8b140108    	add	x8, x8, x20
101700364: 381ff10a    	sturb	w10, [x8, #-0x1]
101700368: a941a277    	ldp	x23, x8, [x19, #0x18]
10170036c: 8b1402f8    	add	x24, x23, x20
101700370: eb08031f    	cmp	x24, x8
101700374: 54000648    	b.hi	0x10170043c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6994>
101700378: f9000e78    	str	x24, [x19, #0x18]
10170037c: b4000134    	cbz	x20, 0x1017003a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a68f8>
101700380: f9400a68    	ldr	x8, [x19, #0x10]
101700384: 8b170100    	add	x0, x8, x23
101700388: f100169f    	cmp	x20, #0x5
10170038c: 54000181    	b.ne	0x1017003bc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6914>
101700390: b840a3e8    	ldur	w8, [sp, #0xa]
101700394: b9000008    	str	w8, [x0]
101700398: 39403be8    	ldrb	w8, [sp, #0xe]
10170039c: 39001008    	strb	w8, [x0, #0x4]
1017003a0: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1017003a4: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1017003a8: a94357f6    	ldp	x22, x21, [sp, #0x30]
1017003ac: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1017003b0: a94167fa    	ldp	x26, x25, [sp, #0x10]
1017003b4: 910183ff    	add	sp, sp, #0x60
1017003b8: d65f03c0    	ret
1017003bc: f100069f    	cmp	x20, #0x1
1017003c0: 54000081    	b.ne	0x1017003d0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6928>
1017003c4: 39402be8    	ldrb	w8, [sp, #0xa]
1017003c8: 39000008    	strb	w8, [x0]
1017003cc: 17fffff5    	b	0x1017003a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a68f8>
1017003d0: f1000a9f    	cmp	x20, #0x2
1017003d4: 54000601    	b.ne	0x101700494 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a69ec>
1017003d8: 794017e8    	ldrh	w8, [sp, #0xa]
1017003dc: 79000008    	strh	w8, [x0]
1017003e0: 17fffff0    	b	0x1017003a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a68f8>
1017003e4: d37ff909    	lsl	x9, x8, #1
1017003e8: eb08071f    	cmp	x24, x8, lsl #1
1017003ec: 9a898308    	csel	x8, x24, x9, hi
1017003f0: 91010114    	add	x20, x8, #0x40
1017003f4: f9400668    	ldr	x8, [x19, #0x8]
1017003f8: b4000568    	cbz	x8, 0x1017004a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a69fc>
1017003fc: f9400a76    	ldr	x22, [x19, #0x10]
101700400: d0045a19    	adrp	x25, 0x10a242000 <dyld_stub_binder+0x10a242000>
101700404: f946ef20    	ldr	x0, [x25, #0xdd8]
101700408: aa1403e1    	mov	x1, x20
10170040c: 97a67cca    	bl	0x10009f734 <_cxxbridge1$slice$new+0x59c58>
101700410: aa0003f4    	mov	x20, x0
101700414: f946ef20    	ldr	x0, [x25, #0xdd8]
101700418: d0040223    	adrp	x3, 0x109746000 <dyld_stub_binder+0x109746000>
10170041c: 91256c63    	add	x3, x3, #0x95b
101700420: aa1603e1    	mov	x1, x22
101700424: aa1403e2    	mov	x2, x20
101700428: 9402835a    	bl	0x1017a1190 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dc4c>
10170042c: b4000460    	cbz	x0, 0x1017004b8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a10>
101700430: f9000a60    	str	x0, [x19, #0x10]
101700434: f9001274    	str	x20, [x19, #0x20]
101700438: 17ffffbc    	b	0x101700328 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6880>
10170043c: d37ff909    	lsl	x9, x8, #1
101700440: eb08071f    	cmp	x24, x8, lsl #1
101700444: 9a898308    	csel	x8, x24, x9, hi
101700448: 91010115    	add	x21, x8, #0x40
10170044c: f9400668    	ldr	x8, [x19, #0x8]
101700450: b40003a8    	cbz	x8, 0x1017004c4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a1c>
101700454: f9400a76    	ldr	x22, [x19, #0x10]
101700458: d0045a19    	adrp	x25, 0x10a242000 <dyld_stub_binder+0x10a242000>
10170045c: f946ef20    	ldr	x0, [x25, #0xdd8]
101700460: aa1503e1    	mov	x1, x21
101700464: 97a67cb4    	bl	0x10009f734 <_cxxbridge1$slice$new+0x59c58>
101700468: aa0003f5    	mov	x21, x0
10170046c: f946ef20    	ldr	x0, [x25, #0xdd8]
101700470: d0040223    	adrp	x3, 0x109746000 <dyld_stub_binder+0x109746000>
101700474: 91256c63    	add	x3, x3, #0x95b
101700478: aa1603e1    	mov	x1, x22
10170047c: aa1503e2    	mov	x2, x21
101700480: 94028344    	bl	0x1017a1190 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dc4c>
101700484: b40002a0    	cbz	x0, 0x1017004d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a30>
101700488: f9000a60    	str	x0, [x19, #0x10]
10170048c: f9001275    	str	x21, [x19, #0x20]
101700490: 17ffffba    	b	0x101700378 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a68d0>
101700494: 91002be1    	add	x1, sp, #0xa
101700498: aa1403e2    	mov	x2, x20
10170049c: 95d55f43    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
1017004a0: 17ffffc0    	b	0x1017003a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a68f8>
1017004a4: b4000214    	cbz	x20, 0x1017004e4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a3c>
1017004a8: f9400a60    	ldr	x0, [x19, #0x10]
1017004ac: aa1403e1    	mov	x1, x20
1017004b0: 95d5612a    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
1017004b4: 17ffffde    	b	0x10170042c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6984>
1017004b8: 52800028    	mov	w8, #0x1                ; =1
1017004bc: 3900aa68    	strb	w8, [x19, #0x2a]
1017004c0: 17ffff9d    	b	0x101700334 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a688c>
1017004c4: b4000175    	cbz	x21, 0x1017004f0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a48>
1017004c8: f9400a60    	ldr	x0, [x19, #0x10]
1017004cc: aa1503e1    	mov	x1, x21
1017004d0: 95d56122    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
1017004d4: 17ffffec    	b	0x101700484 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a69dc>
1017004d8: 52800028    	mov	w8, #0x1                ; =1
1017004dc: 3900aa68    	strb	w8, [x19, #0x2a]
1017004e0: 17ffffb0    	b	0x1017003a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a68f8>
1017004e4: d4200000    	brk	#0
1017004e8: d4400000    	hlt	#0
1017004ec: d4200020    	brk	#0x1
1017004f0: d4200000    	brk	#0
1017004f4: d4400000    	hlt	#0
1017004f8: d4200020    	brk	#0x1
1017004fc: d10183ff    	sub	sp, sp, #0x60
101700500: a90167fa    	stp	x26, x25, [sp, #0x10]
101700504: a9025ff8    	stp	x24, x23, [sp, #0x20]
101700508: a90357f6    	stp	x22, x21, [sp, #0x30]
10170050c: a9044ff4    	stp	x20, x19, [sp, #0x40]
101700510: a9057bfd    	stp	x29, x30, [sp, #0x50]
101700514: 910143fd    	add	x29, sp, #0x50
101700518: aa0003f3    	mov	x19, x0
10170051c: 3940a808    	ldrb	w8, [x0, #0x2a]
101700520: 35001388    	cbnz	w8, 0x101700790 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ce8>
101700524: aa0103e2    	mov	x2, x1
101700528: f9400021    	ldr	x1, [x1]
10170052c: 360001c1    	tbz	w1, #0x0, 0x101700564 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6abc>
101700530: b85ff028    	ldur	w8, [x1, #-0x1]
101700534: d0045454    	adrp	x20, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101700538: f940aa89    	ldr	x9, [x20, #0x150]
10170053c: aa080128    	orr	x8, x9, x8
101700540: 78407115    	ldurh	w21, [x8, #0x7]
101700544: 71020abf    	cmp	w21, #0x82
101700548: 5400014d    	b.le	0x101700570 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ac8>
10170054c: 71020ebf    	cmp	w21, #0x83
101700550: 54000340    	b.eq	0x1017005b8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6b10>
101700554: 51202ea8    	sub	w8, w21, #0x80b
101700558: 71000d1f    	cmp	w8, #0x3
10170055c: 54000102    	b.hs	0x10170057c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ad4>
101700560: 14000063    	b	0x1017006ec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6c44>
101700564: aa1303e0    	mov	x0, x19
101700568: 97ffff62    	bl	0x1017002f0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6848>
10170056c: 14000009    	b	0x101700590 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ae8>
101700570: 54000640    	b.eq	0x101700638 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6b90>
101700574: 710206bf    	cmp	w21, #0x81
101700578: 54000ae0    	b.eq	0x1017006d4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6c2c>
10170057c: 7101febf    	cmp	w21, #0x7f
101700580: 54000468    	b.hi	0x10170060c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6b64>
101700584: aa1303e0    	mov	x0, x19
101700588: aa0203e1    	mov	x1, x2
10170058c: 940000a3    	bl	0x101700818 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6d70>
101700590: 3940aa68    	ldrb	w8, [x19, #0x2a]
101700594: 35000fe8    	cbnz	w8, 0x101700790 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ce8>
101700598: 52802020    	mov	w0, #0x101              ; =257
10170059c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1017005a0: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1017005a4: a94357f6    	ldp	x22, x21, [sp, #0x30]
1017005a8: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1017005ac: a94167fa    	ldp	x26, x25, [sp, #0x10]
1017005b0: 910183ff    	add	sp, sp, #0x60
1017005b4: d65f03c0    	ret
1017005b8: b8417028    	ldur	w8, [x1, #0x17]
1017005bc: 53012109    	ubfx	w9, w8, #1, #8
1017005c0: 7100113f    	cmp	w9, #0x4
1017005c4: 540008e8    	b.hi	0x1017006e0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6c38>
1017005c8: 53017d17    	lsr	w23, w8, #1
1017005cc: 52800368    	mov	w8, #0x1b               ; =27
1017005d0: 1ad72508    	lsr	w8, w8, w23
1017005d4: 36000868    	tbz	w8, #0x0, 0x1017006e0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6c38>
1017005d8: a941a276    	ldp	x22, x8, [x19, #0x18]
1017005dc: 910006d8    	add	x24, x22, #0x1
1017005e0: eb08031f    	cmp	x24, x8
1017005e4: 540004c8    	b.hi	0x10170067c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6bd4>
1017005e8: f9400a60    	ldr	x0, [x19, #0x10]
1017005ec: 531d0ae8    	ubfiz	w8, w23, #3, #3
1017005f0: d28a88c9    	mov	x9, #0x5446             ; =21574
1017005f4: f2a60009    	movk	x9, #0x3000, lsl #16
1017005f8: f2c00be9    	movk	x9, #0x5f, lsl #32
1017005fc: 9ac82528    	lsr	x8, x9, x8
101700600: f9000e78    	str	x24, [x19, #0x18]
101700604: 38366808    	strb	w8, [x0, x22]
101700608: 17ffffe2    	b	0x101700590 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ae8>
10170060c: aa1303e0    	mov	x0, x19
101700610: 710496bf    	cmp	w21, #0x125
101700614: 54000b43    	b.lo	0x10170077c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6cd4>
101700618: aa0203e1    	mov	x1, x2
10170061c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
101700620: a9444ff4    	ldp	x20, x19, [sp, #0x40]
101700624: a94357f6    	ldp	x22, x21, [sp, #0x30]
101700628: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10170062c: a94167fa    	ldp	x26, x25, [sp, #0x10]
101700630: 910183ff    	add	sp, sp, #0x60
101700634: 17fffa3f    	b	0x1016fef30 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5488>
101700638: a941a274    	ldp	x20, x8, [x19, #0x18]
10170063c: 91000695    	add	x21, x20, #0x1
101700640: eb0802bf    	cmp	x21, x8
101700644: 54000ba8    	b.hi	0x1017007b8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6d10>
101700648: f9000e75    	str	x21, [x19, #0x18]
10170064c: f9400a68    	ldr	x8, [x19, #0x10]
101700650: 528009c9    	mov	w9, #0x4e               ; =78
101700654: 38346909    	strb	w9, [x8, x20]
101700658: fc403020    	ldur	d0, [x1, #0x3]
10170065c: a941a274    	ldp	x20, x8, [x19, #0x18]
101700660: 91002295    	add	x21, x20, #0x8
101700664: eb0802bf    	cmp	x21, x8
101700668: 54000ba8    	b.hi	0x1017007dc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6d34>
10170066c: f9000e75    	str	x21, [x19, #0x18]
101700670: f9400a68    	ldr	x8, [x19, #0x10]
101700674: fc346900    	str	d0, [x8, x20]
101700678: 17ffffc6    	b	0x101700590 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ae8>
10170067c: d37ff909    	lsl	x9, x8, #1
101700680: eb08071f    	cmp	x24, x8, lsl #1
101700684: 9a898308    	csel	x8, x24, x9, hi
101700688: 91010114    	add	x20, x8, #0x40
10170068c: f9400668    	ldr	x8, [x19, #0x8]
101700690: b40008a8    	cbz	x8, 0x1017007a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6cfc>
101700694: f9400a75    	ldr	x21, [x19, #0x10]
101700698: d0045a19    	adrp	x25, 0x10a242000 <dyld_stub_binder+0x10a242000>
10170069c: f946ef20    	ldr	x0, [x25, #0xdd8]
1017006a0: aa1403e1    	mov	x1, x20
1017006a4: 97a67c24    	bl	0x10009f734 <_cxxbridge1$slice$new+0x59c58>
1017006a8: aa0003f4    	mov	x20, x0
1017006ac: f946ef20    	ldr	x0, [x25, #0xdd8]
1017006b0: d0040223    	adrp	x3, 0x109746000 <dyld_stub_binder+0x109746000>
1017006b4: 91256c63    	add	x3, x3, #0x95b
1017006b8: aa1503e1    	mov	x1, x21
1017006bc: aa1403e2    	mov	x2, x20
1017006c0: 940282b4    	bl	0x1017a1190 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dc4c>
1017006c4: b4000620    	cbz	x0, 0x101700788 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ce0>
1017006c8: f9000a60    	str	x0, [x19, #0x10]
1017006cc: f9001274    	str	x20, [x19, #0x20]
1017006d0: 17ffffc7    	b	0x1017005ec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6b44>
1017006d4: aa1303e0    	mov	x0, x19
1017006d8: 949b8001    	bl	0x103de06dc <__v8_internal_Print_TransitionTree+0x197cf4>
1017006dc: 17ffffad    	b	0x101700590 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ae8>
1017006e0: d4200000    	brk	#0
1017006e4: d4400000    	hlt	#0
1017006e8: d4200020    	brk	#0x1
1017006ec: f90007e2    	str	x2, [sp, #0x8]
1017006f0: 9101c260    	add	x0, x19, #0x70
1017006f4: 97a941c3    	bl	0x100150e00 <_cxxbridge1$slice$new+0x10b324>
1017006f8: b4000080    	cbz	x0, 0x101700708 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6c60>
1017006fc: aa1303e0    	mov	x0, x19
101700700: f94007e1    	ldr	x1, [sp, #0x8]
101700704: 17ffffc6    	b	0x10170061c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6b74>
101700708: 3940a668    	ldrb	w8, [x19, #0x29]
10170070c: 3707ff88    	tbnz	w8, #0x0, 0x1017006fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6c54>
101700710: 512036a9    	sub	w9, w21, #0x80d
101700714: f94007e8    	ldr	x8, [sp, #0x8]
101700718: f9400108    	ldr	x8, [x8]
10170071c: d1000500    	sub	x0, x8, #0x1
101700720: 7100053f    	cmp	w9, #0x1
101700724: 540001a9    	b.ls	0x101700758 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6cb0>
101700728: b9401008    	ldr	w8, [x0, #0x10]
10170072c: f940aa89    	ldr	x9, [x20, #0x150]
101700730: aa080128    	orr	x8, x9, x8
101700734: f9400260    	ldr	x0, [x19]
101700738: f9411401    	ldr	x1, [x0, #0x228]
10170073c: f9411809    	ldr	x9, [x0, #0x230]
101700740: eb09003f    	cmp	x1, x9
101700744: 540005e0    	b.eq	0x101700800 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6d58>
101700748: 91002029    	add	x9, x1, #0x8
10170074c: f9011409    	str	x9, [x0, #0x228]
101700750: f9000028    	str	x8, [x1]
101700754: 14000004    	b	0x101700764 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6cbc>
101700758: f9400261    	ldr	x1, [x19]
10170075c: 94075279    	bl	0x1018d5140 <_rust_png$cxxbridge1$199$Reader$get_iccp_chunk+0x24e90>
101700760: aa0003e1    	mov	x1, x0
101700764: aa1303e0    	mov	x0, x19
101700768: 97fff9f2    	bl	0x1016fef30 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a5488>
10170076c: 52802028    	mov	w8, #0x101              ; =257
101700770: 6a20011f    	bics	wzr, w8, w0
101700774: 54fffc40    	b.eq	0x1017006fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6c54>
101700778: 14000009    	b	0x10170079c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6cf4>
10170077c: 52803b21    	mov	w1, #0x1d9              ; =473
101700780: 949b7ff2    	bl	0x103de0748 <__v8_internal_Print_TransitionTree+0x197d60>
101700784: 14000006    	b	0x10170079c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6cf4>
101700788: 52800028    	mov	w8, #0x1                ; =1
10170078c: 3900aa68    	strb	w8, [x19, #0x2a]
101700790: aa1303e0    	mov	x0, x19
101700794: 52803b41    	mov	w1, #0x1da              ; =474
101700798: 949b8446    	bl	0x103de18b0 <__v8_internal_Print_TransitionTree+0x198ec8>
10170079c: 52800000    	mov	w0, #0x0                ; =0
1017007a0: 17ffff7f    	b	0x10170059c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6af4>
1017007a4: b4000354    	cbz	x20, 0x10170080c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6d64>
1017007a8: f9400a60    	ldr	x0, [x19, #0x10]
1017007ac: aa1403e1    	mov	x1, x20
1017007b0: 95d5606a    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
1017007b4: 17ffffc4    	b	0x1017006c4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6c1c>
1017007b8: aa0103f6    	mov	x22, x1
1017007bc: 91000681    	add	x1, x20, #0x1
1017007c0: aa1303e0    	mov	x0, x19
1017007c4: 940001cb    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
1017007c8: aa1603e1    	mov	x1, x22
1017007cc: 529fc028    	mov	w8, #0xfe01             ; =65025
1017007d0: 6a08001f    	tst	w0, w8
1017007d4: 54fff3a1    	b.ne	0x101700648 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ba0>
1017007d8: 17ffffa0    	b	0x101700658 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6bb0>
1017007dc: 91002281    	add	x1, x20, #0x8
1017007e0: aa1303e0    	mov	x0, x19
1017007e4: fd0007e0    	str	d0, [sp, #0x8]
1017007e8: 940001c2    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
1017007ec: fd4007e0    	ldr	d0, [sp, #0x8]
1017007f0: 529fc028    	mov	w8, #0xfe01             ; =65025
1017007f4: 6a08001f    	tst	w0, w8
1017007f8: 54ffecc0    	b.eq	0x101700590 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ae8>
1017007fc: 17ffff9c    	b	0x10170066c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6bc4>
101700800: aa0803e1    	mov	x1, x8
101700804: 97a5a829    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
101700808: 17ffffd6    	b	0x101700760 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6cb8>
10170080c: d4200000    	brk	#0
101700810: d4400000    	hlt	#0
101700814: d4200020    	brk	#0x1
101700818: d10243ff    	sub	sp, sp, #0x90
10170081c: a9036ffc    	stp	x28, x27, [sp, #0x30]
101700820: a90467fa    	stp	x26, x25, [sp, #0x40]
101700824: a9055ff8    	stp	x24, x23, [sp, #0x50]
101700828: a90657f6    	stp	x22, x21, [sp, #0x60]
10170082c: a9074ff4    	stp	x20, x19, [sp, #0x70]
101700830: a9087bfd    	stp	x29, x30, [sp, #0x80]
101700834: 910203fd    	add	x29, sp, #0x80
101700838: aa0103e8    	mov	x8, x1
10170083c: aa0003f3    	mov	x19, x0
101700840: f9400000    	ldr	x0, [x0]
101700844: f9400021    	ldr	x1, [x1]
101700848: 995ff02a    	ldapur	w10, [x1, #-0x1]
10170084c: d0045454    	adrp	x20, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101700850: 710d755f    	cmp	w10, #0x35d
101700854: 54000ce2    	b.hs	0x1017009f0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6f48>
101700858: f9400100    	ldr	x0, [x8]
10170085c: d1000409    	sub	x9, x0, #0x1
101700860: a9027fff    	stp	xzr, xzr, [sp, #0x20]
101700864: b8407015    	ldur	w21, [x0, #0x7]
101700868: 995ff00a    	ldapur	w10, [x0, #-0x1]
10170086c: 7105555f    	cmp	w10, #0x155
101700870: 54000e28    	b.hi	0x101700a34 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6f8c>
101700874: 91003120    	add	x0, x9, #0xc
101700878: 721d015f    	tst	w10, #0x8
10170087c: 52800028    	mov	w8, #0x1                ; =1
101700880: 1a880508    	cinc	w8, w8, ne
101700884: f90003e0    	str	x0, [sp]
101700888: 290123f5    	stp	w21, w8, [sp, #0x8]
10170088c: 91007fe8    	add	x8, sp, #0x1f
101700890: f9000be8    	str	x8, [sp, #0x10]
101700894: 3940a3e8    	ldrb	w8, [sp, #0x28]
101700898: 35001cc8    	cbnz	w8, 0x101700c30 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7188>
10170089c: b9400fe8    	ldr	w8, [sp, #0xc]
1017008a0: 7100051f    	cmp	w8, #0x1
1017008a4: 54001861    	b.ne	0x101700bb0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7108>
1017008a8: f94003f4    	ldr	x20, [sp]
1017008ac: b9400bf5    	ldr	w21, [sp, #0x8]
1017008b0: a941a276    	ldp	x22, x8, [x19, #0x18]
1017008b4: 910006d7    	add	x23, x22, #0x1
1017008b8: eb0802ff    	cmp	x23, x8
1017008bc: 540016c8    	b.hi	0x101700b94 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a70ec>
1017008c0: f9000e77    	str	x23, [x19, #0x18]
1017008c4: f9400a68    	ldr	x8, [x19, #0x10]
1017008c8: 52800449    	mov	w9, #0x22               ; =34
1017008cc: 38366909    	strb	w9, [x8, x22]
1017008d0: 37f81b95    	tbnz	w21, #0x1f, 0x101700c40 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7198>
1017008d4: d2800016    	mov	x22, #0x0               ; =0
1017008d8: 910083e8    	add	x8, sp, #0x20
1017008dc: aa1503ea    	mov	x10, x21
1017008e0: aa0a03e9    	mov	x9, x10
1017008e4: 3219014a    	orr	w10, w10, #0x80
1017008e8: 3836690a    	strb	w10, [x8, x22]
1017008ec: 53077d2a    	lsr	w10, w9, #7
1017008f0: 910006d6    	add	x22, x22, #0x1
1017008f4: 35ffff6a    	cbnz	w10, 0x1017008e0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6e38>
1017008f8: 910083e8    	add	x8, sp, #0x20
1017008fc: 8b160108    	add	x8, x8, x22
101700900: 381ff109    	sturb	w9, [x8, #-0x1]
101700904: a941a279    	ldp	x25, x8, [x19, #0x18]
101700908: 8b16033a    	add	x26, x25, x22
10170090c: eb08035f    	cmp	x26, x8
101700910: 54001048    	b.hi	0x101700b18 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7070>
101700914: f9000e7a    	str	x26, [x19, #0x18]
101700918: b4000136    	cbz	x22, 0x10170093c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6e94>
10170091c: f9400a68    	ldr	x8, [x19, #0x10]
101700920: 8b190100    	add	x0, x8, x25
101700924: f10016df    	cmp	x22, #0x5
101700928: 540005a1    	b.ne	0x1017009dc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6f34>
10170092c: b94023e8    	ldr	w8, [sp, #0x20]
101700930: b9000008    	str	w8, [x0]
101700934: 394093e8    	ldrb	w8, [sp, #0x24]
101700938: 39001008    	strb	w8, [x0, #0x4]
10170093c: a941a278    	ldp	x24, x8, [x19, #0x18]
101700940: 8b150319    	add	x25, x24, x21
101700944: eb08033f    	cmp	x25, x8
101700948: 540002c9    	b.ls	0x1017009a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ef8>
10170094c: d37ff909    	lsl	x9, x8, #1
101700950: eb08073f    	cmp	x25, x8, lsl #1
101700954: 9a898328    	csel	x8, x25, x9, hi
101700958: 91010116    	add	x22, x8, #0x40
10170095c: f9400668    	ldr	x8, [x19, #0x8]
101700960: b40017c8    	cbz	x8, 0x101700c58 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a71b0>
101700964: f9400a77    	ldr	x23, [x19, #0x10]
101700968: d0045a1a    	adrp	x26, 0x10a242000 <dyld_stub_binder+0x10a242000>
10170096c: f946ef40    	ldr	x0, [x26, #0xdd8]
101700970: aa1603e1    	mov	x1, x22
101700974: 97a67b70    	bl	0x10009f734 <_cxxbridge1$slice$new+0x59c58>
101700978: aa0003f6    	mov	x22, x0
10170097c: f946ef40    	ldr	x0, [x26, #0xdd8]
101700980: d0040223    	adrp	x3, 0x109746000 <dyld_stub_binder+0x109746000>
101700984: 91256c63    	add	x3, x3, #0x95b
101700988: aa1703e1    	mov	x1, x23
10170098c: aa1603e2    	mov	x2, x22
101700990: 94028200    	bl	0x1017a1190 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dc4c>
101700994: b40016c0    	cbz	x0, 0x101700c6c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a71c4>
101700998: f9000a60    	str	x0, [x19, #0x10]
10170099c: f9001276    	str	x22, [x19, #0x20]
1017009a0: f9000e79    	str	x25, [x19, #0x18]
1017009a4: 340000d5    	cbz	w21, 0x1017009bc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6f14>
1017009a8: f9400a68    	ldr	x8, [x19, #0x10]
1017009ac: 8b180100    	add	x0, x8, x24
1017009b0: aa1403e1    	mov	x1, x20
1017009b4: aa1503e2    	mov	x2, x21
1017009b8: 95d55dfc    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
1017009bc: a9487bfd    	ldp	x29, x30, [sp, #0x80]
1017009c0: a9474ff4    	ldp	x20, x19, [sp, #0x70]
1017009c4: a94657f6    	ldp	x22, x21, [sp, #0x60]
1017009c8: a9455ff8    	ldp	x24, x23, [sp, #0x50]
1017009cc: a94467fa    	ldp	x26, x25, [sp, #0x40]
1017009d0: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1017009d4: 910243ff    	add	sp, sp, #0x90
1017009d8: d65f03c0    	ret
1017009dc: f10006df    	cmp	x22, #0x1
1017009e0: 54000201    	b.ne	0x101700a20 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6f78>
1017009e4: 394083e8    	ldrb	w8, [sp, #0x20]
1017009e8: 39000008    	strb	w8, [x0]
1017009ec: 17ffffd4    	b	0x10170093c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6e94>
1017009f0: f940aa89    	ldr	x9, [x20, #0x150]
1017009f4: 710eb15f    	cmp	w10, #0x3ac
1017009f8: 54000788    	b.hi	0x101700ae8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7040>
1017009fc: b840f02a    	ldur	w10, [x1, #0xf]
101700a00: aa0a012a    	orr	x10, x9, x10
101700a04: b840714a    	ldur	w10, [x10, #0x7]
101700a08: 34000baa    	cbz	w10, 0x101700b7c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a70d4>
101700a0c: aa0803e1    	mov	x1, x8
101700a10: 52800002    	mov	w2, #0x0                ; =0
101700a14: 97aca599    	bl	0x10022a078 <_cxxbridge1$slice$new+0x1e459c>
101700a18: aa0003e8    	mov	x8, x0
101700a1c: 17ffff8f    	b	0x101700858 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6db0>
101700a20: f1000adf    	cmp	x22, #0x2
101700a24: 54001301    	b.ne	0x101700c84 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a71dc>
101700a28: 794043e8    	ldrh	w8, [sp, #0x20]
101700a2c: 79000008    	strh	w8, [x0]
101700a30: 17ffffc3    	b	0x10170093c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6e94>
101700a34: f940aa88    	ldr	x8, [x20, #0x150]
101700a38: 710cd55f    	cmp	w10, #0x335
101700a3c: 54000468    	b.hi	0x101700ac8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7020>
101700a40: 900446a0    	adrp	x0, 0x109fd4000 <dyld_stub_binder+0x109fd4000>
101700a44: 9129a000    	add	x0, x0, #0xa68
101700a48: f940000b    	ldr	x11, [x0]
101700a4c: d63f0160    	blr	x11
101700a50: f940000b    	ldr	x11, [x0]
101700a54: b9400d2c    	ldr	w12, [x9, #0xc]
101700a58: 53037d8c    	lsr	w12, w12, #3
101700a5c: f941756b    	ldr	x11, [x11, #0x2e8]
101700a60: f940016b    	ldr	x11, [x11]
101700a64: 927d658c    	and	x12, x12, #0x1ffffff8
101700a68: f86c696b    	ldr	x11, [x11, x12]
101700a6c: 924f196c    	and	x12, x11, #0xfe000000000000
101700a70: 3718112a    	tbnz	w10, #0x3, 0x101700c94 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a71ec>
101700a74: d2e0008a    	mov	x10, #0x4000000000000   ; =1125899906842624
101700a78: eb0a019f    	cmp	x12, x10
101700a7c: 54000fe1    	b.ne	0x101700c78 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a71d0>
101700a80: 9248dd74    	and	x20, x11, #0xff00ffffffffffff
101700a84: b9400129    	ldr	w9, [x9]
101700a88: aa090108    	orr	x8, x8, x9
101700a8c: 78407108    	ldurh	w8, [x8, #0x7]
101700a90: 372000e8    	tbnz	w8, #0x4, 0x101700aac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7004>
101700a94: f9400288    	ldr	x8, [x20]
101700a98: f9402508    	ldr	x8, [x8, #0x48]
101700a9c: aa1403e0    	mov	x0, x20
101700aa0: d63f0100    	blr	x8
101700aa4: 52800028    	mov	w8, #0x1                ; =1
101700aa8: 17ffff77    	b	0x101700884 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ddc>
101700aac: f9400288    	ldr	x8, [x20]
101700ab0: f9400908    	ldr	x8, [x8, #0x10]
101700ab4: aa1403e0    	mov	x0, x20
101700ab8: d63f0100    	blr	x8
101700abc: 34fffec0    	cbz	w0, 0x101700a94 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6fec>
101700ac0: f9400680    	ldr	x0, [x20, #0x8]
101700ac4: 17fffff8    	b	0x101700aa4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ffc>
101700ac8: 7110995f    	cmp	w10, #0x426
101700acc: 54001162    	b.hs	0x101700cf8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7250>
101700ad0: 910003e8    	mov	x8, sp
101700ad4: 91007fe1    	add	x1, sp, #0x1f
101700ad8: 910083e2    	add	x2, sp, #0x20
101700adc: aa0903e0    	mov	x0, x9
101700ae0: 97a93128    	bl	0x10014cf80 <_cxxbridge1$slice$new+0x1074a4>
101700ae4: 17ffff6c    	b	0x101700894 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6dec>
101700ae8: aa0a0128    	orr	x8, x9, x10
101700aec: 510ff508    	sub	w8, w8, #0x3fd
101700af0: 71013d1f    	cmp	w8, #0x4f
101700af4: 540003e9    	b.ls	0x101700b70 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a70c8>
101700af8: f9411408    	ldr	x8, [x0, #0x228]
101700afc: f9411809    	ldr	x9, [x0, #0x230]
101700b00: eb09011f    	cmp	x8, x9
101700b04: 54000f60    	b.eq	0x101700cf0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7248>
101700b08: 91002109    	add	x9, x8, #0x8
101700b0c: f9011409    	str	x9, [x0, #0x228]
101700b10: f9000101    	str	x1, [x8]
101700b14: 17ffff51    	b	0x101700858 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6db0>
101700b18: d37ff909    	lsl	x9, x8, #1
101700b1c: eb08075f    	cmp	x26, x8, lsl #1
101700b20: 9a898348    	csel	x8, x26, x9, hi
101700b24: 91010117    	add	x23, x8, #0x40
101700b28: f9400668    	ldr	x8, [x19, #0x8]
101700b2c: b4000f28    	cbz	x8, 0x101700d10 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7268>
101700b30: f9400a78    	ldr	x24, [x19, #0x10]
101700b34: d0045a1b    	adrp	x27, 0x10a242000 <dyld_stub_binder+0x10a242000>
101700b38: f946ef60    	ldr	x0, [x27, #0xdd8]
101700b3c: aa1703e1    	mov	x1, x23
101700b40: 97a67afd    	bl	0x10009f734 <_cxxbridge1$slice$new+0x59c58>
101700b44: aa0003f7    	mov	x23, x0
101700b48: f946ef60    	ldr	x0, [x27, #0xdd8]
101700b4c: d0040223    	adrp	x3, 0x109746000 <dyld_stub_binder+0x109746000>
101700b50: 91256c63    	add	x3, x3, #0x95b
101700b54: aa1803e1    	mov	x1, x24
101700b58: aa1703e2    	mov	x2, x23
101700b5c: 9402818d    	bl	0x1017a1190 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dc4c>
101700b60: b4000e20    	cbz	x0, 0x101700d24 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a727c>
101700b64: f9000a60    	str	x0, [x19, #0x10]
101700b68: f9001277    	str	x23, [x19, #0x20]
101700b6c: 17ffff6a    	b	0x101700914 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6e6c>
101700b70: b840b028    	ldur	w8, [x1, #0xb]
101700b74: aa080121    	orr	x1, x9, x8
101700b78: 17ffffe0    	b	0x101700af8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7050>
101700b7c: b840b028    	ldur	w8, [x1, #0xb]
101700b80: aa080121    	orr	x1, x9, x8
101700b84: 995ff028    	ldapur	w8, [x1, #-0x1]
101700b88: f940aa89    	ldr	x9, [x20, #0x150]
101700b8c: aa080128    	orr	x8, x9, x8
101700b90: 17ffffd7    	b	0x101700aec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7044>
101700b94: 910006c1    	add	x1, x22, #0x1
101700b98: aa1303e0    	mov	x0, x19
101700b9c: 940000d5    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
101700ba0: 529fc028    	mov	w8, #0xfe01             ; =65025
101700ba4: 6a08001f    	tst	w0, w8
101700ba8: 54ffe8c1    	b.ne	0x1017008c0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6e18>
101700bac: 17ffff49    	b	0x1017008d0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6e28>
101700bb0: 7100091f    	cmp	w8, #0x2
101700bb4: 540004c1    	b.ne	0x101700c4c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a71a4>
101700bb8: b9400bf4    	ldr	w20, [sp, #0x8]
101700bbc: 37f80d74    	tbnz	w20, #0x1f, 0x101700d68 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a72c0>
101700bc0: f94003f5    	ldr	x21, [sp]
101700bc4: 531f7a88    	lsl	w8, w20, #1
101700bc8: f9400e76    	ldr	x22, [x19, #0x18]
101700bcc: aa1603e9    	mov	x9, x22
101700bd0: 53077d08    	lsr	w8, w8, #7
101700bd4: d1000529    	sub	x9, x9, #0x1
101700bd8: 35ffffc8    	cbnz	w8, 0x101700bd0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7128>
101700bdc: 37000109    	tbnz	w9, #0x0, 0x101700bfc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7154>
101700be0: 910006d7    	add	x23, x22, #0x1
101700be4: f9401268    	ldr	x8, [x19, #0x20]
101700be8: eb0802ff    	cmp	x23, x8
101700bec: 54000b08    	b.hi	0x101700d4c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a72a4>
101700bf0: f9000e77    	str	x23, [x19, #0x18]
101700bf4: f9400a68    	ldr	x8, [x19, #0x10]
101700bf8: 3836691f    	strb	wzr, [x8, x22]
101700bfc: a941a276    	ldp	x22, x8, [x19, #0x18]
101700c00: 910006d7    	add	x23, x22, #0x1
101700c04: eb0802ff    	cmp	x23, x8
101700c08: 54000948    	b.hi	0x101700d30 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7288>
101700c0c: f9000e77    	str	x23, [x19, #0x18]
101700c10: f9400a68    	ldr	x8, [x19, #0x10]
101700c14: 52800c69    	mov	w9, #0x63               ; =99
101700c18: 38366909    	strb	w9, [x8, x22]
101700c1c: aa1303e0    	mov	x0, x19
101700c20: aa1503e1    	mov	x1, x21
101700c24: aa1403e2    	mov	x2, x20
101700c28: 949b7e18    	bl	0x103de0488 <__v8_internal_Print_TransitionTree+0x197aa0>
101700c2c: 17ffff64    	b	0x1017009bc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6f14>
101700c30: f94013e0    	ldr	x0, [sp, #0x20]
101700c34: b4ffe340    	cbz	x0, 0x10170089c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6df4>
101700c38: 97cee426    	bl	0x100ab9cd0 <_sfv$cxxbridge1$199$decode_item+0x540c>
101700c3c: 17ffff18    	b	0x10170089c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6df4>
101700c40: d4200000    	brk	#0
101700c44: d4400000    	hlt	#0
101700c48: d4200020    	brk	#0x1
101700c4c: d4200000    	brk	#0
101700c50: d4400000    	hlt	#0
101700c54: d4200020    	brk	#0x1
101700c58: b40008f6    	cbz	x22, 0x101700d74 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a72cc>
101700c5c: f9400a60    	ldr	x0, [x19, #0x10]
101700c60: aa1603e1    	mov	x1, x22
101700c64: 95d55f3d    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
101700c68: 17ffff4b    	b	0x101700994 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6eec>
101700c6c: 52800028    	mov	w8, #0x1                ; =1
101700c70: 3900aa68    	strb	w8, [x19, #0x2a]
101700c74: 17ffff52    	b	0x1017009bc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6f14>
101700c78: d4200000    	brk	#0
101700c7c: d4400000    	hlt	#0
101700c80: d4200020    	brk	#0x1
101700c84: 910083e1    	add	x1, sp, #0x20
101700c88: aa1603e2    	mov	x2, x22
101700c8c: 95d55d47    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
101700c90: 17ffff2b    	b	0x10170093c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6e94>
101700c94: d2e0008a    	mov	x10, #0x4000000000000   ; =1125899906842624
101700c98: eb0a019f    	cmp	x12, x10
101700c9c: 54000721    	b.ne	0x101700d80 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a72d8>
101700ca0: 9248dd74    	and	x20, x11, #0xff00ffffffffffff
101700ca4: b9400129    	ldr	w9, [x9]
101700ca8: aa090108    	orr	x8, x8, x9
101700cac: 78407108    	ldurh	w8, [x8, #0x7]
101700cb0: 362000c8    	tbz	w8, #0x4, 0x101700cc8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7220>
101700cb4: f9400288    	ldr	x8, [x20]
101700cb8: f9400908    	ldr	x8, [x8, #0x10]
101700cbc: aa1403e0    	mov	x0, x20
101700cc0: d63f0100    	blr	x8
101700cc4: 350000e0    	cbnz	w0, 0x101700ce0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7238>
101700cc8: f9400288    	ldr	x8, [x20]
101700ccc: f9402508    	ldr	x8, [x8, #0x48]
101700cd0: aa1403e0    	mov	x0, x20
101700cd4: d63f0100    	blr	x8
101700cd8: 52800048    	mov	w8, #0x2                ; =2
101700cdc: 17fffeea    	b	0x101700884 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ddc>
101700ce0: aa1403e0    	mov	x0, x20
101700ce4: 97a80ca7    	bl	0x100103f80 <_cxxbridge1$slice$new+0xbe4a4>
101700ce8: f9400680    	ldr	x0, [x20, #0x8]
101700cec: 17fffffb    	b	0x101700cd8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7230>
101700cf0: 97a5a6ee    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
101700cf4: 17ffff49    	b	0x101700a18 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6f70>
101700cf8: aa0a0101    	orr	x1, x8, x10
101700cfc: 9493537f    	bl	0x103bd5af8 <_llg_tokenize_bytes+0x235c5c>
101700d00: 37000460    	tbnz	w0, #0x0, 0x101700d8c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a72e4>
101700d04: f940aa88    	ldr	x8, [x20, #0x150]
101700d08: 91015100    	add	x0, x8, #0x54
101700d0c: 17ffff66    	b	0x101700aa4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6ffc>
101700d10: b4000457    	cbz	x23, 0x101700d98 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a72f0>
101700d14: f9400a60    	ldr	x0, [x19, #0x10]
101700d18: aa1703e1    	mov	x1, x23
101700d1c: 95d55f0f    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
101700d20: 17ffff90    	b	0x101700b60 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a70b8>
101700d24: 52800028    	mov	w8, #0x1                ; =1
101700d28: 3900aa68    	strb	w8, [x19, #0x2a]
101700d2c: 17ffff04    	b	0x10170093c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6e94>
101700d30: 910006c1    	add	x1, x22, #0x1
101700d34: aa1303e0    	mov	x0, x19
101700d38: 9400006e    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
101700d3c: 529fc028    	mov	w8, #0xfe01             ; =65025
101700d40: 6a08001f    	tst	w0, w8
101700d44: 54fff641    	b.ne	0x101700c0c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7164>
101700d48: 17ffffb5    	b	0x101700c1c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7174>
101700d4c: 910006c1    	add	x1, x22, #0x1
101700d50: aa1303e0    	mov	x0, x19
101700d54: 94000067    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
101700d58: 529fc028    	mov	w8, #0xfe01             ; =65025
101700d5c: 6a08001f    	tst	w0, w8
101700d60: 54fff481    	b.ne	0x101700bf0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7148>
101700d64: 17ffffa6    	b	0x101700bfc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7154>
101700d68: d4200000    	brk	#0
101700d6c: d4400000    	hlt	#0
101700d70: d4200020    	brk	#0x1
101700d74: d4200000    	brk	#0
101700d78: d4400000    	hlt	#0
101700d7c: d4200020    	brk	#0x1
101700d80: d4200000    	brk	#0
101700d84: d4400000    	hlt	#0
101700d88: d4200020    	brk	#0x1
101700d8c: d4200000    	brk	#0
101700d90: d4400000    	hlt	#0
101700d94: d4200020    	brk	#0x1
101700d98: d4200000    	brk	#0
101700d9c: d4400000    	hlt	#0
101700da0: d4200020    	brk	#0x1
		...
101700db0: d10343ff    	sub	sp, sp, #0xd0
101700db4: a9076ffc    	stp	x28, x27, [sp, #0x70]
101700db8: a90867fa    	stp	x26, x25, [sp, #0x80]
101700dbc: a9095ff8    	stp	x24, x23, [sp, #0x90]
101700dc0: a90a57f6    	stp	x22, x21, [sp, #0xa0]
101700dc4: a90b4ff4    	stp	x20, x19, [sp, #0xb0]
101700dc8: a90c7bfd    	stp	x29, x30, [sp, #0xc0]
101700dcc: 910303fd    	add	x29, sp, #0xc0
101700dd0: f9400048    	ldr	x8, [x2]
101700dd4: b8403118    	ldur	w24, [x8, #0x3]
101700dd8: 340007f8    	cbz	w24, 0x101700ed4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a742c>
101700ddc: aa0203f3    	mov	x19, x2
101700de0: aa0103f4    	mov	x20, x1
101700de4: aa0003f5    	mov	x21, x0
101700de8: 52800019    	mov	w25, #0x0               ; =0
101700dec: 5280011a    	mov	w26, #0x8               ; =8
101700df0: d004545b    	adrp	x27, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101700df4: 5280203c    	mov	w28, #0x101             ; =257
101700df8: f9400268    	ldr	x8, [x19]
101700dfc: 8b1a0108    	add	x8, x8, x26
101700e00: b85ff108    	ldur	w8, [x8, #-0x1]
101700e04: f940ab69    	ldr	x9, [x27, #0x150]
101700e08: aa080121    	orr	x1, x9, x8
101700e0c: f94002a0    	ldr	x0, [x21]
101700e10: f9411416    	ldr	x22, [x0, #0x228]
101700e14: f9411808    	ldr	x8, [x0, #0x230]
101700e18: eb0802df    	cmp	x22, x8
101700e1c: 54000640    	b.eq	0x101700ee4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a743c>
101700e20: 910022c8    	add	x8, x22, #0x8
101700e24: f9011408    	str	x8, [x0, #0x228]
101700e28: f90002c1    	str	x1, [x22]
101700e2c: f94002a1    	ldr	x1, [x21]
101700e30: 910183e0    	add	x0, sp, #0x60
101700e34: aa1603e2    	mov	x2, x22
101700e38: 97e955d2    	bl	0x101156580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x2fcad8>
101700e3c: f94002a1    	ldr	x1, [x21]
101700e40: a94613e3    	ldp	x3, x4, [sp, #0x60]
101700e44: 910023e0    	add	x0, sp, #0x8
101700e48: aa1403e2    	mov	x2, x20
101700e4c: aa1403e5    	mov	x5, x20
101700e50: 52800026    	mov	w6, #0x1                ; =1
101700e54: 97a5dcf9    	bl	0x100078238 <_cxxbridge1$slice$new+0x3275c>
101700e58: 910023e0    	add	x0, sp, #0x8
101700e5c: 52800001    	mov	w1, #0x0                ; =0
101700e60: 97a5dd7f    	bl	0x10007845c <_cxxbridge1$slice$new+0x32980>
101700e64: b40003c0    	cbz	x0, 0x101700edc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7434>
101700e68: b9400fe8    	ldr	w8, [sp, #0xc]
101700e6c: 340001a8    	cbz	w8, 0x101700ea0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a73f8>
101700e70: aa0003f7    	mov	x23, x0
101700e74: aa1503e0    	mov	x0, x21
101700e78: aa1603e1    	mov	x1, x22
101700e7c: 97fffda0    	bl	0x1017004fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a54>
101700e80: 6a20039f    	bics	wzr, w28, w0
101700e84: 540002c1    	b.ne	0x101700edc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7434>
101700e88: aa1503e0    	mov	x0, x21
101700e8c: aa1703e1    	mov	x1, x23
101700e90: 97fffd9b    	bl	0x1017004fc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a6a54>
101700e94: 6a20039f    	bics	wzr, w28, w0
101700e98: 54000221    	b.ne	0x101700edc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7434>
101700e9c: 11000739    	add	w25, w25, #0x1
101700ea0: 9100135a    	add	x26, x26, #0x4
101700ea4: f1000718    	subs	x24, x24, #0x1
101700ea8: 54fffa81    	b.ne	0x101700df8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7350>
101700eac: 52800028    	mov	w8, #0x1                ; =1
101700eb0: aa198100    	orr	x0, x8, x25, lsl #32
101700eb4: a94c7bfd    	ldp	x29, x30, [sp, #0xc0]
101700eb8: a94b4ff4    	ldp	x20, x19, [sp, #0xb0]
101700ebc: a94a57f6    	ldp	x22, x21, [sp, #0xa0]
101700ec0: a9495ff8    	ldp	x24, x23, [sp, #0x90]
101700ec4: a94867fa    	ldp	x26, x25, [sp, #0x80]
101700ec8: a9476ffc    	ldp	x28, x27, [sp, #0x70]
101700ecc: 910343ff    	add	sp, sp, #0xd0
101700ed0: d65f03c0    	ret
101700ed4: 52800020    	mov	w0, #0x1                ; =1
101700ed8: 17fffff7    	b	0x101700eb4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a740c>
101700edc: d2800000    	mov	x0, #0x0                ; =0
101700ee0: 17fffff5    	b	0x101700eb4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a740c>
101700ee4: 97a5a671    	bl	0x10006a8a8 <_cxxbridge1$slice$new+0x24dcc>
101700ee8: aa0003f6    	mov	x22, x0
101700eec: 17ffffd0    	b	0x101700e2c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7384>
101700ef0: d100c3ff    	sub	sp, sp, #0x30
101700ef4: a9014ff4    	stp	x20, x19, [sp, #0x10]
101700ef8: a9027bfd    	stp	x29, x30, [sp, #0x20]
101700efc: 910083fd    	add	x29, sp, #0x20
101700f00: aa0003f3    	mov	x19, x0
101700f04: f9401008    	ldr	x8, [x0, #0x20]
101700f08: d37ff909    	lsl	x9, x8, #1
101700f0c: eb08043f    	cmp	x1, x8, lsl #1
101700f10: 9a898028    	csel	x8, x1, x9, hi
101700f14: 91010102    	add	x2, x8, #0x40
101700f18: f9400400    	ldr	x0, [x0, #0x8]
101700f1c: b4000200    	cbz	x0, 0x101700f5c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a74b4>
101700f20: f9400a61    	ldr	x1, [x19, #0x10]
101700f24: 910023e3    	add	x3, sp, #0x8
101700f28: 94028086    	bl	0x1017a1140 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6dbfc>
101700f2c: b4000120    	cbz	x0, 0x101700f50 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a74a8>
101700f30: f9000a60    	str	x0, [x19, #0x10]
101700f34: f94007e8    	ldr	x8, [sp, #0x8]
101700f38: f9001268    	str	x8, [x19, #0x20]
101700f3c: 52802020    	mov	w0, #0x101              ; =257
101700f40: a9427bfd    	ldp	x29, x30, [sp, #0x20]
101700f44: a9414ff4    	ldp	x20, x19, [sp, #0x10]
101700f48: 9100c3ff    	add	sp, sp, #0x30
101700f4c: d65f03c0    	ret
101700f50: 52800028    	mov	w8, #0x1                ; =1
101700f54: 3900aa68    	strb	w8, [x19, #0x2a]
101700f58: 17fffffa    	b	0x101700f40 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7498>
101700f5c: b40000e2    	cbz	x2, 0x101700f78 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a74d0>
101700f60: aa0203f4    	mov	x20, x2
101700f64: f9400a60    	ldr	x0, [x19, #0x10]
101700f68: aa0203e1    	mov	x1, x2
101700f6c: 95d55e7b    	bl	0x108c58958 <dyld_stub_binder+0x108c58958>
101700f70: f90007f4    	str	x20, [sp, #0x8]
101700f74: 17ffffee    	b	0x101700f2c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7484>
101700f78: d4200000    	brk	#0
101700f7c: d4400000    	hlt	#0
101700f80: d4200020    	brk	#0x1
101700f84: a9bf7bfd    	stp	x29, x30, [sp, #-0x10]!
101700f88: 910003fd    	mov	x29, sp
101700f8c: aa0103e8    	mov	x8, x1
101700f90: f9400009    	ldr	x9, [x0]
101700f94: f9400129    	ldr	x9, [x9]
101700f98: f9400129    	ldr	x9, [x9]
101700f9c: 9943b129    	ldapur	w9, [x9, #0x3b]
101700fa0: d004544a    	adrp	x10, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101700fa4: f940a94a    	ldr	x10, [x10, #0x150]
101700fa8: aa090141    	orr	x1, x10, x9
101700fac: aa0803e0    	mov	x0, x8
101700fb0: 97ad58a2    	bl	0x100257238 <_cxxbridge1$slice$new+0x21175c>
101700fb4: b4000060    	cbz	x0, 0x101700fc0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7518>
101700fb8: a8c17bfd    	ldp	x29, x30, [sp], #0x10
101700fbc: d65f03c0    	ret
101700fc0: d4200000    	brk	#0
101700fc4: d4400000    	hlt	#0
101700fc8: d4200020    	brk	#0x1
		...
101701000: d10083ff    	sub	sp, sp, #0x20
101701004: a9017bfd    	stp	x29, x30, [sp, #0x10]
101701008: 910043fd    	add	x29, sp, #0x10
10170100c: 3943e028    	ldrb	w8, [x1, #0xf8]
101701010: 36000648    	tbz	w8, #0x0, 0x1017010d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7630>
101701014: 39400c48    	ldrb	w8, [x2, #0x3]
101701018: 7100091f    	cmp	w8, #0x2
10170101c: 54000602    	b.hs	0x1017010dc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7634>
101701020: 39441029    	ldrb	w9, [x1, #0x104]
101701024: 350006a9    	cbnz	w9, 0x1017010f8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7650>
101701028: 7100051f    	cmp	w8, #0x1
10170102c: 54000480    	b.eq	0x1017010bc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7614>
101701030: b4000042    	cbz	x2, 0x101701038 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7590>
101701034: 350006e8    	cbnz	w8, 0x101701110 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7668>
101701038: 39400048    	ldrb	w8, [x2]
10170103c: fd400440    	ldr	d0, [x2, #0x8]
101701040: 7100091f    	cmp	w8, #0x2
101701044: 54000520    	b.eq	0x1017010e8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7640>
101701048: 92e00208    	mov	x8, #-0x10000000000001  ; =-4503599627370497
10170104c: 9e670101    	fmov	d1, x8
101701050: 1e612000    	fcmp	d0, d1
101701054: 1e609c21    	fcsel	d1, d1, d0, ls
101701058: 92f00208    	mov	x8, #0x7fefffffffffffff ; =9218868437227405311
10170105c: 9e670102    	fmov	d2, x8
101701060: 1e622000    	fcmp	d0, d2
101701064: 1e62bc20    	fcsel	d0, d1, d2, lt
101701068: 90040c88    	adrp	x8, 0x109891000 <dyld_stub_binder+0x109891000>
10170106c: fd42b101    	ldr	d1, [x8, #0x560]
101701070: 1e612000    	fcmp	d0, d1
101701074: 1e609c21    	fcsel	d1, d1, d0, ls
101701078: 1e624021    	fcvt	s1, d1
10170107c: d503201f    	nop
101701080: fd42ad02    	ldr	d2, [x8, #0x558]
101701084: 12b01008    	mov	w8, #0x7f7fffff         ; =2139095039
101701088: 1e270103    	fmov	s3, w8
10170108c: 1e622000    	fcmp	d0, d2
101701090: 1e23bc20    	fcsel	s0, s1, s3, lt
101701094: 1e202008    	fcmp	s0, #0.0
101701098: 6f00e401    	movi.2d	v1, #0000000000000000
10170109c: 1e209c21    	fcsel	s1, s1, s0, ls
1017010a0: 1e2e1002    	fmov	s2, #1.00000000
1017010a4: 1e222000    	fcmp	s0, s2
1017010a8: 1e22bc20    	fcsel	s0, s1, s2, lt
1017010ac: 9101c020    	add	x0, x1, #0x70
1017010b0: a9417bfd    	ldp	x29, x30, [sp, #0x10]
1017010b4: 910083ff    	add	sp, sp, #0x20
1017010b8: 1400001a    	b	0x101701120 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7678>
1017010bc: f90007e1    	str	x1, [sp, #0x8]
1017010c0: aa0103e8    	mov	x8, x1
1017010c4: 91042101    	add	x1, x8, #0x108
1017010c8: aa0203e0    	mov	x0, x2
1017010cc: 97b0cd4d    	bl	0x100334600 <_cxxbridge1$slice$new+0x2eeb24>
1017010d0: f94007e1    	ldr	x1, [sp, #0x8]
1017010d4: 17ffffe5    	b	0x101701068 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a75c0>
1017010d8: d4200020    	brk	#0x1
1017010dc: d4200000    	brk	#0
1017010e0: d4400000    	hlt	#0
1017010e4: d4200020    	brk	#0x1
1017010e8: d2e80b28    	mov	x8, #0x4059000000000000 ; =4636737291354636288
1017010ec: 9e670101    	fmov	d1, x8
1017010f0: 1e611800    	fdiv	d0, d0, d1
1017010f4: 17ffffd5    	b	0x101701048 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a75a0>
1017010f8: aa0103e0    	mov	x0, x1
1017010fc: a90007e2    	stp	x2, x1, [sp]
101701100: 97a5c630    	bl	0x1000729c0 <_cxxbridge1$slice$new+0x2cee4>
101701104: a94007e2    	ldp	x2, x1, [sp]
101701108: 39400c48    	ldrb	w8, [x2, #0x3]
10170110c: 17ffffc7    	b	0x101701028 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7580>
101701110: d4200000    	brk	#0
101701114: d4400000    	hlt	#0
101701118: d4200020    	brk	#0x1
10170111c: 00000000    	udf	#0x0
101701120: d10103ff    	sub	sp, sp, #0x40
101701124: 6d0223e9    	stp	d9, d8, [sp, #0x20]
101701128: a9037bfd    	stp	x29, x30, [sp, #0x30]
10170112c: 9100c3fd    	add	x29, sp, #0x30
101701130: 4ea01c08    	mov.16b	v8, v0
101701134: f940200b    	ldr	x11, [x0, #0x40]
101701138: b9800568    	ldrsw	x8, [x11, #0x4]
10170113c: b004422a    	adrp	x10, 0x109f46000 <dyld_stub_binder+0x109f46000>
101701140: f944e14c    	ldr	x12, [x10, #0x9c0]
101701144: 8a080d88    	and	x8, x12, x8, lsl #3
101701148: bd406900    	ldr	s0, [x8, #0x68]
10170114c: 1e282000    	fcmp	s0, s8
101701150: 540000a1    	b.ne	0x101701164 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a76bc>
101701154: a9437bfd    	ldp	x29, x30, [sp, #0x30]
101701158: 6d4223e9    	ldp	d9, d8, [sp, #0x20]
10170115c: 910103ff    	add	sp, sp, #0x40
101701160: d65f03c0    	ret
101701164: aa0003e9    	mov	x9, x0
101701168: 39406c08    	ldrb	w8, [x0, #0x1b]
10170116c: d00454ec    	adrp	x12, 0x10a19f000 <dyld_stub_binder+0x10a19f000>
101701170: 37000a28    	tbnz	w8, #0x0, 0x1017012b4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a780c>
101701174: 52800028    	mov	w8, #0x1                ; =1
101701178: 39006d28    	strb	w8, [x9, #0x1b]
10170117c: f9401980    	ldr	x0, [x12, #0x30]
101701180: f940000d    	ldr	x13, [x0]
101701184: f94009a8    	ldr	x8, [x13, #0x10]
101701188: b4001908    	cbz	x8, 0x1017014a8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7a00>
10170118c: f0043ea8    	adrp	x8, 0x109ed8000 <dyld_stub_binder+0x109ed8000>
101701190: 91000108    	add	x8, x8, #0x0
101701194: 90043ece    	adrp	x14, 0x109ed9000 <dyld_stub_binder+0x109ed9000>
101701198: 913f81ce    	add	x14, x14, #0xfe0
10170119c: 4b0801c8    	sub	w8, w14, w8
1017011a0: 53057d08    	lsr	w8, w8, #5
1017011a4: 11000508    	add	w8, w8, #0x1
1017011a8: f94005ad    	ldr	x13, [x13, #0x8]
1017011ac: f94001a1    	ldr	x1, [x13]
1017011b0: a944382d    	ldp	x13, x14, [x1, #0x40]
1017011b4: cb0d01ce    	sub	x14, x14, x13
1017011b8: f1005ddf    	cmp	x14, #0x17
1017011bc: 54001669    	b.ls	0x101701488 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a79e0>
1017011c0: 910061ae    	add	x14, x13, #0x18
1017011c4: f900202e    	str	x14, [x1, #0x40]
1017011c8: b90001bf    	str	wzr, [x13]
1017011cc: 12003d08    	and	w8, w8, #0xffff
1017011d0: 7140111f    	cmp	w8, #0x4, lsl #12       ; =0x4000
1017011d4: 54001722    	b.hs	0x1017014b8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7a10>
1017011d8: d2e000ce    	mov	x14, #0x6000000000000   ; =1688849860263936
1017011dc: aa0881c8    	orr	x8, x14, x8, lsl #32
1017011e0: f90001a8    	str	x8, [x13]
1017011e4: 910021a8    	add	x8, x13, #0x8
1017011e8: b940016d    	ldr	w13, [x11]
1017011ec: b900010d    	str	w13, [x8]
1017011f0: b940056d    	ldr	w13, [x11, #0x4]
1017011f4: b900050d    	str	w13, [x8, #0x4]
1017011f8: b940096d    	ldr	w13, [x11, #0x8]
1017011fc: b900090d    	str	w13, [x8, #0x8]
101701200: 3940316d    	ldrb	w13, [x11, #0xc]
101701204: 3940310e    	ldrb	w14, [x8, #0xc]
101701208: 33000dae    	bfxil	w14, w13, #0, #4
10170120c: 3900310e    	strb	w14, [x8, #0xc]
101701210: 3940316e    	ldrb	w14, [x11, #0xc]
101701214: 33000dae    	bfxil	w14, w13, #0, #4
101701218: 3900310e    	strb	w14, [x8, #0xc]
10170121c: 7840d16d    	ldurh	w13, [x11, #0xd]
101701220: 7840d10e    	ldurh	w14, [x8, #0xd]
101701224: 330009ae    	bfxil	w14, w13, #0, #3
101701228: 7800d10e    	sturh	w14, [x8, #0xd]
10170122c: 7840d16d    	ldurh	w13, [x11, #0xd]
101701230: 53037dad    	lsr	w13, w13, #3
101701234: 331d05ae    	bfi	w14, w13, #3, #2
101701238: 7800d10e    	sturh	w14, [x8, #0xd]
10170123c: 7840d16d    	ldurh	w13, [x11, #0xd]
101701240: 53057dad    	lsr	w13, w13, #5
101701244: 331b05ae    	bfi	w14, w13, #5, #2
101701248: 7800d10e    	sturh	w14, [x8, #0xd]
10170124c: 7840d16d    	ldurh	w13, [x11, #0xd]
101701250: 53077dad    	lsr	w13, w13, #7
101701254: 331905ae    	bfi	w14, w13, #7, #2
101701258: 7800d10e    	sturh	w14, [x8, #0xd]
10170125c: 7840d16d    	ldurh	w13, [x11, #0xd]
101701260: 53097dad    	lsr	w13, w13, #9
101701264: 331705ae    	bfi	w14, w13, #9, #2
101701268: 7800d10e    	sturh	w14, [x8, #0xd]
10170126c: 7840d16d    	ldurh	w13, [x11, #0xd]
101701270: 530b7dad    	lsr	w13, w13, #11
101701274: 331505ae    	bfi	w14, w13, #11, #2
101701278: 7800d10e    	sturh	w14, [x8, #0xd]
10170127c: 7840d16d    	ldurh	w13, [x11, #0xd]
101701280: 530d7dad    	lsr	w13, w13, #13
101701284: 331301ae    	bfi	w14, w13, #13, #1
101701288: 7800d10e    	sturh	w14, [x8, #0xd]
10170128c: 7840d16b    	ldurh	w11, [x11, #0xd]
101701290: 1212016b    	and	w11, w11, #0x4000
101701294: 121179cd    	and	w13, w14, #0xffffbfff
101701298: 2a0b01ab    	orr	w11, w13, w11
10170129c: 7800d10b    	sturh	w11, [x8, #0xd]
1017012a0: 785fc10b    	ldurh	w11, [x8, #-0x4]
1017012a4: 3211016b    	orr	w11, w11, #0x8000
1017012a8: 591fc10b    	stlurh	w11, [x8, #-0x4]
1017012ac: f9002128    	str	x8, [x9, #0x40]
1017012b0: aa0803eb    	mov	x11, x8
1017012b4: 39406128    	ldrb	w8, [x9, #0x18]
1017012b8: 37000c88    	tbnz	w8, #0x0, 0x101701448 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a79a0>
1017012bc: 52800028    	mov	w8, #0x1                ; =1
1017012c0: 39006128    	strb	w8, [x9, #0x18]
1017012c4: f9401980    	ldr	x0, [x12, #0x30]
1017012c8: f940000d    	ldr	x13, [x0]
1017012cc: f94009a8    	ldr	x8, [x13, #0x10]
1017012d0: f100091f    	cmp	x8, #0x2
1017012d4: 54000ea9    	b.ls	0x1017014a8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7a00>
1017012d8: b8804169    	ldursw	x9, [x11, #0x4]
1017012dc: f0043ea8    	adrp	x8, 0x109ed8000 <dyld_stub_binder+0x109ed8000>
1017012e0: 91000108    	add	x8, x8, #0x0
1017012e4: f944e14c    	ldr	x12, [x10, #0x9c0]
1017012e8: 90043ece    	adrp	x14, 0x109ed9000 <dyld_stub_binder+0x109ed9000>
1017012ec: 913e81ce    	add	x14, x14, #0xfa0
1017012f0: 4b0801c8    	sub	w8, w14, w8
1017012f4: 53057d08    	lsr	w8, w8, #5
1017012f8: 11000508    	add	w8, w8, #0x1
1017012fc: f94005ad    	ldr	x13, [x13, #0x8]
101701300: f94009a1    	ldr	x1, [x13, #0x10]
101701304: a944382d    	ldp	x13, x14, [x1, #0x40]
101701308: cb0d01ce    	sub	x14, x14, x13
10170130c: f101dddf    	cmp	x14, #0x77
101701310: 54000ac9    	b.ls	0x101701468 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a79c0>
101701314: 9101e1ae    	add	x14, x13, #0x78
101701318: f900202e    	str	x14, [x1, #0x40]
10170131c: b90001bf    	str	wzr, [x13]
101701320: 12003d08    	and	w8, w8, #0xffff
101701324: 7140111f    	cmp	w8, #0x4, lsl #12       ; =0x4000
101701328: 54000c22    	b.hs	0x1017014ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7a04>
10170132c: d2e003ce    	mov	x14, #0x1e000000000000  ; =8444249301319680
101701330: aa0881c8    	orr	x8, x14, x8, lsl #32
101701334: f90001a8    	str	x8, [x13]
101701338: 910021a8    	add	x8, x13, #0x8
10170133c: 8a090d89    	and	x9, x12, x9, lsl #3
101701340: b940012c    	ldr	w12, [x9]
101701344: b900010c    	str	w12, [x8]
101701348: b940052c    	ldr	w12, [x9, #0x4]
10170134c: b900050c    	str	w12, [x8, #0x4]
101701350: 3cc08120    	ldur	q0, [x9, #0x8]
101701354: b940192c    	ldr	w12, [x9, #0x18]
101701358: b900190c    	str	w12, [x8, #0x18]
10170135c: 3c808100    	stur	q0, [x8, #0x8]
101701360: b9401d2c    	ldr	w12, [x9, #0x1c]
101701364: b9001d0c    	str	w12, [x8, #0x1c]
101701368: b940212c    	ldr	w12, [x9, #0x20]
10170136c: b900210c    	str	w12, [x8, #0x20]
101701370: b940252c    	ldr	w12, [x9, #0x24]
101701374: 3940a12d    	ldrb	w13, [x9, #0x28]
101701378: 3900a10d    	strb	w13, [x8, #0x28]
10170137c: b900250c    	str	w12, [x8, #0x24]
101701380: b9402d2c    	ldr	w12, [x9, #0x2c]
101701384: b9002d0c    	str	w12, [x8, #0x2c]
101701388: 3dc00d20    	ldr	q0, [x9, #0x30]
10170138c: b940412c    	ldr	w12, [x9, #0x40]
101701390: b900410c    	str	w12, [x8, #0x40]
101701394: 3d800d00    	str	q0, [x8, #0x30]
101701398: b940452c    	ldr	w12, [x9, #0x44]
10170139c: b900450c    	str	w12, [x8, #0x44]
1017013a0: b940492c    	ldr	w12, [x9, #0x48]
1017013a4: b900490c    	str	w12, [x8, #0x48]
1017013a8: b9404d2c    	ldr	w12, [x9, #0x4c]
1017013ac: 3941412d    	ldrb	w13, [x9, #0x50]
1017013b0: 3901410d    	strb	w13, [x8, #0x50]
1017013b4: b9004d0c    	str	w12, [x8, #0x4c]
1017013b8: 3901611f    	strb	wzr, [x8, #0x58]
1017013bc: f845412c    	ldur	x12, [x9, #0x54]
1017013c0: aa0803e0    	mov	x0, x8
1017013c4: f8054c0c    	str	x12, [x0, #0x54]!
1017013c8: 92581d8d    	and	x13, x12, #0xff0000000000
1017013cc: d2c1000c    	mov	x12, #0x80000000000     ; =8796093022208
1017013d0: eb0c01bf    	cmp	x13, x12
1017013d4: 54000860    	b.eq	0x1017014e0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7a38>
1017013d8: 3901811f    	strb	wzr, [x8, #0x60]
1017013dc: f845c12d    	ldur	x13, [x9, #0x5c]
1017013e0: aa0803e0    	mov	x0, x8
1017013e4: f805cc0d    	str	x13, [x0, #0x5c]!
1017013e8: 92581dad    	and	x13, x13, #0xff0000000000
1017013ec: eb0c01bf    	cmp	x13, x12
1017013f0: 540006a0    	b.eq	0x1017014c4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7a1c>
1017013f4: bd406520    	ldr	s0, [x9, #0x64]
1017013f8: bd006500    	str	s0, [x8, #0x64]
1017013fc: bd406920    	ldr	s0, [x9, #0x68]
101701400: bd006900    	str	s0, [x8, #0x68]
101701404: 3941b12c    	ldrb	w12, [x9, #0x6c]
101701408: 3941b10d    	ldrb	w13, [x8, #0x6c]
10170140c: 3300058d    	bfxil	w13, w12, #0, #2
101701410: 3901b10d    	strb	w13, [x8, #0x6c]
101701414: 3941b129    	ldrb	w9, [x9, #0x6c]
101701418: 121e0529    	and	w9, w9, #0xc
10170141c: 121c75ac    	and	w12, w13, #0xfffffff3
101701420: 2a090189    	orr	w9, w12, w9
101701424: 3901b109    	strb	w9, [x8, #0x6c]
101701428: 785fc109    	ldurh	w9, [x8, #-0x4]
10170142c: 32110129    	orr	w9, w9, #0x8000
101701430: 591fc109    	stlurh	w9, [x8, #-0x4]
101701434: d343fd08    	lsr	x8, x8, #3
101701438: b8004168    	stur	w8, [x11, #0x4]
10170143c: b0045448    	adrp	x8, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101701440: b9486108    	ldr	w8, [x8, #0x860]
101701444: 350000c8    	cbnz	w8, 0x10170145c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a79b4>
101701448: b8804168    	ldursw	x8, [x11, #0x4]
10170144c: f944e149    	ldr	x9, [x10, #0x9c0]
101701450: 8a080d28    	and	x8, x9, x8, lsl #3
101701454: bd006908    	str	s8, [x8, #0x68]
101701458: 17ffff3f    	b	0x101701154 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a76ac>
10170145c: 91001160    	add	x0, x11, #0x4
101701460: 97a41240    	bl	0x100005d60 <__text+0x1d60>
101701464: 17fffff9    	b	0x101701448 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a79a0>
101701468: 12003d04    	and	w4, w8, #0xffff
10170146c: 910063e6    	add	x6, sp, #0x18
101701470: 52800f02    	mov	w2, #0x78               ; =120
101701474: 52800103    	mov	w3, #0x8                ; =8
101701478: 52800005    	mov	w5, #0x0                ; =0
10170147c: 97aa6311    	bl	0x10019a0c0 <_cxxbridge1$slice$new+0x1545e4>
101701480: f9400fe8    	ldr	x8, [sp, #0x18]
101701484: 17ffffae    	b	0x10170133c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7894>
101701488: 12003d04    	and	w4, w8, #0xffff
10170148c: 910063e6    	add	x6, sp, #0x18
101701490: 52800302    	mov	w2, #0x18               ; =24
101701494: 52800103    	mov	w3, #0x8                ; =8
101701498: 52800005    	mov	w5, #0x0                ; =0
10170149c: 97aa6309    	bl	0x10019a0c0 <_cxxbridge1$slice$new+0x1545e4>
1017014a0: f9400fe8    	ldr	x8, [sp, #0x18]
1017014a4: 17ffff51    	b	0x1017011e8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7740>
1017014a8: d4200020    	brk	#0x1
1017014ac: d4200000    	brk	#0
1017014b0: d4400000    	hlt	#0
1017014b4: d4200020    	brk	#0x1
1017014b8: d4200000    	brk	#0
1017014bc: d4400000    	hlt	#0
1017014c0: d4200020    	brk	#0x1
1017014c4: a900a3eb    	stp	x11, x8, [sp, #0x8]
1017014c8: f90003e9    	str	x9, [sp]
1017014cc: 97ee4121    	bl	0x101291950 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x437ea8>
1017014d0: a9402fe9    	ldp	x9, x11, [sp]
1017014d4: f9400be8    	ldr	x8, [sp, #0x10]
1017014d8: b004422a    	adrp	x10, 0x109f46000 <dyld_stub_binder+0x109f46000>
1017014dc: 17ffffc6    	b	0x1017013f4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a794c>
1017014e0: a900a3eb    	stp	x11, x8, [sp, #0x8]
1017014e4: f90003e9    	str	x9, [sp]
1017014e8: 97ee411a    	bl	0x101291950 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x437ea8>
1017014ec: d2c1000c    	mov	x12, #0x80000000000     ; =8796093022208
1017014f0: a9402fe9    	ldp	x9, x11, [sp]
1017014f4: f9400be8    	ldr	x8, [sp, #0x10]
1017014f8: b004422a    	adrp	x10, 0x109f46000 <dyld_stub_binder+0x109f46000>
1017014fc: 17ffffb7    	b	0x1017013d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7930>
101701500: d10103ff    	sub	sp, sp, #0x40
101701504: a90157f6    	stp	x22, x21, [sp, #0x10]
101701508: a9024ff4    	stp	x20, x19, [sp, #0x20]
10170150c: a9037bfd    	stp	x29, x30, [sp, #0x30]
101701510: 9100c3fd    	add	x29, sp, #0x30
101701514: aa0203f5    	mov	x21, x2
101701518: aa0103f6    	mov	x22, x1
10170151c: aa0003f3    	mov	x19, x0
101701520: f9400008    	ldr	x8, [x0]
101701524: b4000728    	cbz	x8, 0x101701608 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b60>
101701528: b9400a69    	ldr	w9, [x19, #0x8]
10170152c: 51000529    	sub	w9, w9, #0x1
101701530: f94032ca    	ldr	x10, [x22, #0x60]
101701534: b940094b    	ldr	w11, [x10, #0x8]
101701538: d348fd6c    	lsr	x12, x11, #8
10170153c: 3941c2cb    	ldrb	w11, [x22, #0x70]
101701540: 2a2b3fed    	mvn	w13, w11, lsl #15
101701544: 0b0b01ad    	add	w13, w13, w11
101701548: 4a4d29ad    	eor	w13, w13, w13, lsr #10
10170154c: 0b0d0dad    	add	w13, w13, w13, lsl #3
101701550: 4a4d19ad    	eor	w13, w13, w13, lsr #6
101701554: 2a2d2fee    	mvn	w14, w13, lsl #11
101701558: 0b0e01ad    	add	w13, w13, w14
10170155c: 4a4d41ad    	eor	w13, w13, w13, lsr #16
101701560: d2813eee    	mov	x14, #0x9f7             ; =2551
101701564: f2be128e    	movk	x14, #0xf094, lsl #16
101701568: f2da7cae    	movk	x14, #0xd3e5, lsl #32
10170156c: f2e8ed4e    	movk	x14, #0x476a, lsl #48
101701570: 9b0e7d8c    	mul	x12, x12, x14
101701574: d28d644e    	mov	x14, #0x6b22            ; =27426
101701578: f2abf82e    	movk	x14, #0x5fc1, lsl #16
10170157c: f2c478ee    	movk	x14, #0x23c7, lsl #32
101701580: f2fed0ce    	movk	x14, #0xf686, lsl #48
101701584: 9b0e31ac    	madd	x12, x13, x14, x12
101701588: 8a4c812c    	and	x12, x9, x12, lsr #32
10170158c: 8b0c1d14    	add	x20, x8, x12, lsl #7
101701590: f940328f    	ldr	x15, [x20, #0x60]
101701594: 3941c28e    	ldrb	w14, [x20, #0x70]
101701598: b500048f    	cbnz	x15, 0x101701628 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b80>
10170159c: 710201df    	cmp	w14, #0x80
1017015a0: 54000441    	b.ne	0x101701628 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b80>
1017015a4: aa1403e0    	mov	x0, x20
1017015a8: aa1603e1    	mov	x1, x22
1017015ac: 97ba32c8    	bl	0x10058e0cc <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x1bef4c>
1017015b0: 3941c2c8    	ldrb	w8, [x22, #0x70]
1017015b4: 3901c288    	strb	w8, [x20, #0x70]
1017015b8: f94002a8    	ldr	x8, [x21]
1017015bc: d343fd08    	lsr	x8, x8, #3
1017015c0: b9007a88    	str	w8, [x20, #0x78]
1017015c4: b0045449    	adrp	x9, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
1017015c8: b9486128    	ldr	w8, [x9, #0x860]
1017015cc: 35000748    	cbnz	w8, 0x1017016b4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7c0c>
1017015d0: b9486128    	ldr	w8, [x9, #0x860]
1017015d4: 35000768    	cbnz	w8, 0x1017016c0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7c18>
1017015d8: 29412261    	ldp	w1, w8, [x19, #0x8]
1017015dc: 11000508    	add	w8, w8, #0x1
1017015e0: b9000e68    	str	w8, [x19, #0xc]
1017015e4: b9401269    	ldr	w9, [x19, #0x10]
1017015e8: 0b080129    	add	w9, w9, w8
1017015ec: 6b09043f    	cmp	w1, w9, lsl #1
1017015f0: 540004a9    	b.ls	0x101701684 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7bdc>
1017015f4: a9437bfd    	ldp	x29, x30, [sp, #0x30]
1017015f8: a9424ff4    	ldp	x20, x19, [sp, #0x20]
1017015fc: a94157f6    	ldp	x22, x21, [sp, #0x10]
101701600: 910103ff    	add	sp, sp, #0x40
101701604: d65f03c0    	ret
101701608: b9400a61    	ldr	w1, [x19, #0x8]
10170160c: 35000881    	cbnz	w1, 0x10170171c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7c74>
101701610: 52800101    	mov	w1, #0x8                ; =8
101701614: aa1303e0    	mov	x0, x19
101701618: d2800002    	mov	x2, #0x0                ; =0
10170161c: 94000071    	bl	0x1017017e0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7d38>
101701620: f9400268    	ldr	x8, [x19]
101701624: 17ffffc1    	b	0x101701528 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7a80>
101701628: d2800000    	mov	x0, #0x0                ; =0
10170162c: 5280002d    	mov	w13, #0x1               ; =1
101701630: aa1403f0    	mov	x16, x20
101701634: b10005ff    	cmn	x15, #0x1
101701638: 540000c0    	b.eq	0x101701650 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ba8>
10170163c: aa0003f0    	mov	x16, x0
101701640: eb0a01ff    	cmp	x15, x10
101701644: 54000061    	b.ne	0x101701650 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ba8>
101701648: 6b0b01df    	cmp	w14, w11
10170164c: 54fffd40    	b.eq	0x1017015f4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b4c>
101701650: 0b0d018c    	add	w12, w12, w13
101701654: 8a09018c    	and	x12, x12, x9
101701658: 8b0c1d14    	add	x20, x8, x12, lsl #7
10170165c: f940328f    	ldr	x15, [x20, #0x60]
101701660: 3941c28e    	ldrb	w14, [x20, #0x70]
101701664: 910005ad    	add	x13, x13, #0x1
101701668: aa1003e0    	mov	x0, x16
10170166c: b5fffe2f    	cbnz	x15, 0x101701630 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b88>
101701670: aa1003e0    	mov	x0, x16
101701674: 710201df    	cmp	w14, #0x80
101701678: 54fffdc1    	b.ne	0x101701630 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b88>
10170167c: b4fff950    	cbz	x16, 0x1017015a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7afc>
101701680: 14000033    	b	0x10170174c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ca4>
101701684: 34000481    	cbz	w1, 0x101701714 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7c6c>
101701688: 0b080508    	add	w8, w8, w8, lsl #1
10170168c: 531f7908    	lsl	w8, w8, #1
101701690: 6b01051f    	cmp	w8, w1, lsl #1
101701694: 54000083    	b.lo	0x1017016a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7bfc>
101701698: 7100003f    	cmp	w1, #0x0
10170169c: 5400052d    	b.le	0x101701740 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7c98>
1017016a0: 531f7821    	lsl	w1, w1, #1
1017016a4: aa1303e0    	mov	x0, x19
1017016a8: aa1403e2    	mov	x2, x20
1017016ac: 9400004d    	bl	0x1017017e0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7d38>
1017016b0: 17ffffd1    	b	0x1017015f4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b4c>
1017016b4: 9101e280    	add	x0, x20, #0x78
1017016b8: 97a411aa    	bl	0x100005d60 <__text+0x1d60>
1017016bc: 17ffffc5    	b	0x1017015d0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b28>
1017016c0: b0045a08    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
1017016c4: f946f508    	ldr	x8, [x8, #0xde8]
1017016c8: 910023e9    	add	x9, sp, #0x8
1017016cc: b0045a0a    	adrp	x10, 0x10a242000 <dyld_stub_binder+0x10a242000>
1017016d0: f946f94a    	ldr	x10, [x10, #0xdf0]
1017016d4: cb090108    	sub	x8, x8, x9
1017016d8: eb0a011f    	cmp	x8, x10
1017016dc: 54000482    	b.hs	0x10170176c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7cc4>
1017016e0: d00454e0    	adrp	x0, 0x10a19f000 <dyld_stub_binder+0x10a19f000>
1017016e4: 9100c000    	add	x0, x0, #0x30
1017016e8: f9400408    	ldr	x8, [x0, #0x8]
1017016ec: 39400109    	ldrb	w9, [x8]
1017016f0: 36000429    	tbz	w9, #0x0, 0x101701774 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ccc>
1017016f4: b000e6a4    	adrp	x4, 0x1033d6000 <_media$cxxbridge1$199$init_symphonia_decoder+0x7df5b0>
1017016f8: 912b8084    	add	x4, x4, #0xae0
1017016fc: aa0803e0    	mov	x0, x8
101701700: aa1403e1    	mov	x1, x20
101701704: 52801002    	mov	w2, #0x80               ; =128
101701708: 52800023    	mov	w3, #0x1                ; =1
10170170c: 97a5471d    	bl	0x100053380 <_cxxbridge1$slice$new+0xd8a4>
101701710: 17ffffb2    	b	0x1017015d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b30>
101701714: 52800101    	mov	w1, #0x8                ; =8
101701718: 17ffffe3    	b	0x1017016a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7bfc>
10170171c: b9400e68    	ldr	w8, [x19, #0xc]
101701720: 0b080508    	add	w8, w8, w8, lsl #1
101701724: 531f7908    	lsl	w8, w8, #1
101701728: 6b01051f    	cmp	w8, w1, lsl #1
10170172c: 54fff743    	b.lo	0x101701614 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b6c>
101701730: 7100003f    	cmp	w1, #0x0
101701734: 5400044d    	b.le	0x1017017bc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7d14>
101701738: 531f7821    	lsl	w1, w1, #1
10170173c: 17ffffb6    	b	0x101701614 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b6c>
101701740: d4200000    	brk	#0
101701744: d4400000    	hlt	#0
101701748: d4200020    	brk	#0x1
10170174c: aa1003f4    	mov	x20, x16
101701750: aa1003e0    	mov	x0, x16
101701754: 94735497    	bl	0x1033d69b0 <_media$cxxbridge1$199$init_symphonia_decoder+0x7dff60>
101701758: b9401268    	ldr	w8, [x19, #0x10]
10170175c: 51000509    	sub	w9, w8, #0x1
101701760: 33007928    	bfxil	w8, w9, #0, #31
101701764: b9001268    	str	w8, [x19, #0x10]
101701768: 17ffff8f    	b	0x1017015a4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7afc>
10170176c: 97a65a79    	bl	0x100098150 <_cxxbridge1$slice$new+0x52674>
101701770: 17ffffde    	b	0x1017016e8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7c40>
101701774: 39400509    	ldrb	w9, [x8, #0x1]
101701778: 34fff309    	cbz	w9, 0x1017015d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b30>
10170177c: 925e7689    	and	x9, x20, #0xfffffffc00000000
101701780: b004544a    	adrp	x10, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101701784: f944354a    	ldr	x10, [x10, #0x868]
101701788: eb0a013f    	cmp	x9, x10
10170178c: 54fff261    	b.ne	0x1017015d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b30>
101701790: d34c868a    	ubfx	x10, x20, #12, #22
101701794: 386a6929    	ldrb	w9, [x9, x10]
101701798: 7100053f    	cmp	w9, #0x1
10170179c: 54fff1e0    	b.eq	0x1017015d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b30>
1017017a0: 925e7680    	and	x0, x20, #0xfffffffc00000000
1017017a4: 925e7681    	and	x1, x20, #0xfffffffc00000000
1017017a8: 9101e282    	add	x2, x20, #0x78
1017017ac: d2800003    	mov	x3, #0x0                ; =0
1017017b0: aa0803e4    	mov	x4, x8
1017017b4: 94a569c5    	bl	0x10405bec8 <__cppgc_internal_Uncompress_Member+0x1984>
1017017b8: 17ffff88    	b	0x1017015d8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7b30>
1017017bc: d4200000    	brk	#0
1017017c0: d4400000    	hlt	#0
1017017c4: d4200020    	brk	#0x1
		...
1017017e0: d103c3ff    	sub	sp, sp, #0xf0
1017017e4: a9096ffc    	stp	x28, x27, [sp, #0x90]
1017017e8: a90a67fa    	stp	x26, x25, [sp, #0xa0]
1017017ec: a90b5ff8    	stp	x24, x23, [sp, #0xb0]
1017017f0: a90c57f6    	stp	x22, x21, [sp, #0xc0]
1017017f4: a90d4ff4    	stp	x20, x19, [sp, #0xd0]
1017017f8: a90e7bfd    	stp	x29, x30, [sp, #0xe0]
1017017fc: 910383fd    	add	x29, sp, #0xe0
101701800: aa0203f5    	mov	x21, x2
101701804: aa0103f3    	mov	x19, x1
101701808: aa0003f4    	mov	x20, x0
10170180c: b9400808    	ldr	w8, [x0, #0x8]
101701810: 6b08003f    	cmp	w1, w8
101701814: 540000e9    	b.ls	0x101701830 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7d88>
101701818: 97a65a4e    	bl	0x100098150 <_cxxbridge1$slice$new+0x52674>
10170181c: f9400408    	ldr	x8, [x0, #0x8]
101701820: f9413108    	ldr	x8, [x8, #0x260]
101701824: b5001cc8    	cbnz	x8, 0x101701bbc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8114>
101701828: f9400280    	ldr	x0, [x20]
10170182c: b50006c0    	cbnz	x0, 0x101701904 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7e5c>
101701830: b0045a08    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
101701834: f946f508    	ldr	x8, [x8, #0xde8]
101701838: 910023e9    	add	x9, sp, #0x8
10170183c: b0045a1a    	adrp	x26, 0x10a242000 <dyld_stub_binder+0x10a242000>
101701840: f946fb4a    	ldr	x10, [x26, #0xdf0]
101701844: cb090108    	sub	x8, x8, x9
101701848: eb0a011f    	cmp	x8, x10
10170184c: 540011c2    	b.hs	0x101701a84 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7fdc>
101701850: d00454e0    	adrp	x0, 0x10a19f000 <dyld_stub_binder+0x10a19f000>
101701854: 9100c000    	add	x0, x0, #0x30
101701858: 34001113    	cbz	w19, 0x101701a78 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7fd0>
10170185c: f9400000    	ldr	x0, [x0]
101701860: f940000a    	ldr	x10, [x0]
101701864: f9400948    	ldr	x8, [x10, #0x10]
101701868: f1000d1f    	cmp	x8, #0x3
10170186c: 540010a9    	b.ls	0x101701a80 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7fd8>
101701870: 2a1303fb    	mov	w27, w19
101701874: f0043ea8    	adrp	x8, 0x109ed8000 <dyld_stub_binder+0x109ed8000>
101701878: 91000108    	add	x8, x8, #0x0
10170187c: f0043ea9    	adrp	x9, 0x109ed8000 <dyld_stub_binder+0x109ed8000>
101701880: 911d8129    	add	x9, x9, #0x760
101701884: 4b080128    	sub	w8, w9, w8
101701888: 53057d08    	lsr	w8, w8, #5
10170188c: 11000508    	add	w8, w8, #0x1
101701890: 528001e9    	mov	w9, #0xf                ; =15
101701894: aa1b1d29    	orr	x9, x9, x27, lsl #7
101701898: 927df122    	and	x2, x9, #0xfffffffffffffff8
10170189c: f940054a    	ldr	x10, [x10, #0x8]
1017018a0: f9400d41    	ldr	x1, [x10, #0x18]
1017018a4: a9442c2a    	ldp	x10, x11, [x1, #0x40]
1017018a8: cb0a016b    	sub	x11, x11, x10
1017018ac: eb02017f    	cmp	x11, x2
1017018b0: 54000d63    	b.lo	0x101701a5c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7fb4>
1017018b4: 8b02014b    	add	x11, x10, x2
1017018b8: f900202b    	str	x11, [x1, #0x40]
1017018bc: b900015f    	str	wzr, [x10]
1017018c0: 12003d0b    	and	w11, w8, #0xffff
1017018c4: 7140117f    	cmp	w11, #0x4, lsl #12      ; =0x4000
1017018c8: 540016e2    	b.hs	0x101701ba4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a80fc>
1017018cc: 3758173b    	tbnz	w27, #0xb, 0x101701bb0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8108>
1017018d0: 12003d08    	and	w8, w8, #0xffff
1017018d4: d2fffc4b    	mov	x11, #-0x1e000000000000 ; =-8444249301319680
1017018d8: 8a09b969    	and	x9, x11, x9, lsl #46
1017018dc: aa088128    	orr	x8, x9, x8, lsl #32
1017018e0: f9000148    	str	x8, [x10]
1017018e4: 91002156    	add	x22, x10, #0x8
1017018e8: d280001c    	mov	x28, #0x0               ; =0
1017018ec: 785fc2c8    	ldurh	w8, [x22, #-0x4]
1017018f0: 32110108    	orr	w8, w8, #0x8000
1017018f4: 591fc2c8    	stlurh	w8, [x22, #-0x4]
1017018f8: 910023f7    	add	x23, sp, #0x8
1017018fc: b0045459    	adrp	x25, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101701900: 14000015    	b	0x101701954 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7eac>
101701904: d3797e61    	ubfiz	x1, x19, #7, #32
101701908: 97a9c8b1    	bl	0x100173bcc <_cxxbridge1$slice$new+0x12e0f0>
10170190c: 35000c00    	cbnz	w0, 0x101701a8c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7fe4>
101701910: 17ffffc8    	b	0x101701830 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7d88>
101701914: aa1403e0    	mov	x0, x20
101701918: aa1603e1    	mov	x1, x22
10170191c: aa1303e2    	mov	x2, x19
101701920: aa1503e3    	mov	x3, x21
101701924: 9400013a    	bl	0x101701e0c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8364>
101701928: a94e7bfd    	ldp	x29, x30, [sp, #0xe0]
10170192c: a94d4ff4    	ldp	x20, x19, [sp, #0xd0]
101701930: a94c57f6    	ldp	x22, x21, [sp, #0xc0]
101701934: a94b5ff8    	ldp	x24, x23, [sp, #0xb0]
101701938: a94a67fa    	ldp	x26, x25, [sp, #0xa0]
10170193c: a9496ffc    	ldp	x28, x27, [sp, #0x90]
101701940: 9103c3ff    	add	sp, sp, #0xf0
101701944: d65f03c0    	ret
101701948: 9100079c    	add	x28, x28, #0x1
10170194c: eb1b039f    	cmp	x28, x27
101701950: 54fffe20    	b.eq	0x101701914 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7e6c>
101701954: 8b1c1ed8    	add	x24, x22, x28, lsl #7
101701958: 910023e8    	add	x8, sp, #0x8
10170195c: 940000b1    	bl	0x101701c20 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8178>
101701960: 910023e1    	add	x1, sp, #0x8
101701964: aa1803e0    	mov	x0, x24
101701968: 97a85960    	bl	0x100117ee8 <_cxxbridge1$slice$new+0xd240c>
10170196c: 3941e3e8    	ldrb	w8, [sp, #0x78]
101701970: 3901c308    	strb	w8, [x24, #0x70]
101701974: b94083e8    	ldr	w8, [sp, #0x80]
101701978: aa1803e2    	mov	x2, x24
10170197c: b8078c48    	str	w8, [x2, #0x78]!
101701980: b90083ff    	str	wzr, [sp, #0x80]
101701984: b9486328    	ldr	w8, [x25, #0x860]
101701988: 35000428    	cbnz	w8, 0x101701a0c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7f64>
10170198c: 9101a2e0    	add	x0, x23, #0x68
101701990: d2800001    	mov	x1, #0x0                ; =0
101701994: 97a47edb    	bl	0x100021500 <__text+0x1d500>
101701998: f94037e0    	ldr	x0, [sp, #0x68]
10170199c: b4000160    	cbz	x0, 0x1017019c8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7f20>
1017019a0: b9400808    	ldr	w8, [x0, #0x8]
1017019a4: 37080128    	tbnz	w8, #0x1, 0x1017019c8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7f20>
1017019a8: b9400008    	ldr	w8, [x0]
1017019ac: 71000509    	subs	w9, w8, #0x1
1017019b0: 540002a0    	b.eq	0x101701a04 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7f5c>
1017019b4: aa0803ea    	mov	x10, x8
1017019b8: 88aafc09    	casl	w10, w9, [x0]
1017019bc: 6b08015f    	cmp	w10, w8
1017019c0: aa0a03e8    	mov	x8, x10
1017019c4: 54ffff41    	b.ne	0x1017019ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7f04>
1017019c8: 910042e0    	add	x0, x23, #0x10
1017019cc: 97a454d4    	bl	0x100016d1c <__text+0x12d1c>
1017019d0: f9400be0    	ldr	x0, [sp, #0x10]
1017019d4: b4fffba0    	cbz	x0, 0x101701948 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ea0>
1017019d8: b9400808    	ldr	w8, [x0, #0x8]
1017019dc: 370ffb68    	tbnz	w8, #0x1, 0x101701948 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ea0>
1017019e0: b9400008    	ldr	w8, [x0]
1017019e4: 71000509    	subs	w9, w8, #0x1
1017019e8: 54000f00    	b.eq	0x101701bc8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8120>
1017019ec: aa0803ea    	mov	x10, x8
1017019f0: 88aafc09    	casl	w10, w9, [x0]
1017019f4: 6b08015f    	cmp	w10, w8
1017019f8: aa0a03e8    	mov	x8, x10
1017019fc: 54ffff41    	b.ne	0x1017019e4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7f3c>
101701a00: 17ffffd2    	b	0x101701948 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ea0>
101701a04: 97a57fdf    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
101701a08: 17fffff0    	b	0x1017019c8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7f20>
101701a0c: b0045a08    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
101701a10: f946f508    	ldr	x8, [x8, #0xde8]
101701a14: f946fb49    	ldr	x9, [x26, #0xdf0]
101701a18: d10163aa    	sub	x10, x29, #0x58
101701a1c: cb0a0108    	sub	x8, x8, x10
101701a20: eb09011f    	cmp	x8, x9
101701a24: d00454e0    	adrp	x0, 0x10a19f000 <dyld_stub_binder+0x10a19f000>
101701a28: 9100c000    	add	x0, x0, #0x30
101701a2c: 54000d22    	b.hs	0x101701bd0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8128>
101701a30: f9400404    	ldr	x4, [x0, #0x8]
101701a34: 39400088    	ldrb	w8, [x4]
101701a38: 36000d48    	tbz	w8, #0x0, 0x101701be0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8138>
101701a3c: aa0403e0    	mov	x0, x4
101701a40: aa1803e1    	mov	x1, x24
101701a44: 52801002    	mov	w2, #0x80               ; =128
101701a48: 52800023    	mov	w3, #0x1                ; =1
101701a4c: b000e6a4    	adrp	x4, 0x1033d6000 <_media$cxxbridge1$199$init_symphonia_decoder+0x7df5b0>
101701a50: 912b8084    	add	x4, x4, #0xae0
101701a54: 97a5464b    	bl	0x100053380 <_cxxbridge1$slice$new+0xd8a4>
101701a58: 17ffffcd    	b	0x10170198c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ee4>
101701a5c: 12003d04    	and	w4, w8, #0xffff
101701a60: 910023e6    	add	x6, sp, #0x8
101701a64: 52800103    	mov	w3, #0x8                ; =8
101701a68: 52800005    	mov	w5, #0x0                ; =0
101701a6c: 97aa6195    	bl	0x10019a0c0 <_cxxbridge1$slice$new+0x1545e4>
101701a70: f94007f6    	ldr	x22, [sp, #0x8]
101701a74: 17ffff9d    	b	0x1017018e8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7e40>
101701a78: d4200000    	brk	#0
101701a7c: d4400000    	hlt	#0
101701a80: d4200020    	brk	#0x1
101701a84: 97a659b3    	bl	0x100098150 <_cxxbridge1$slice$new+0x52674>
101701a88: 17ffff74    	b	0x101701858 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7db0>
101701a8c: 2a1303fa    	mov	w26, w19
101701a90: b9400a99    	ldr	w25, [x20, #0x8]
101701a94: f9400288    	ldr	x8, [x20]
101701a98: a90067e8    	stp	x8, x25, [sp]
101701a9c: 910023e0    	add	x0, sp, #0x8
101701aa0: 9473541d    	bl	0x1033d6b14 <_media$cxxbridge1$199$init_symphonia_decoder+0x7e00c4>
101701aa4: aa0003f7    	mov	x23, x0
101701aa8: 34000519    	cbz	w25, 0x101701b48 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a80a0>
101701aac: aa1703f8    	mov	x24, x23
101701ab0: aa1903f6    	mov	x22, x25
101701ab4: aa1803e0    	mov	x0, x24
101701ab8: 947353be    	bl	0x1033d69b0 <_media$cxxbridge1$199$init_symphonia_decoder+0x7dff60>
101701abc: 91020318    	add	x24, x24, #0x80
101701ac0: f10006d6    	subs	x22, x22, #0x1
101701ac4: 54ffff81    	b.ne	0x101701ab4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a800c>
101701ac8: d280001b    	mov	x27, #0x0               ; =0
101701acc: d2800018    	mov	x24, #0x0               ; =0
101701ad0: d379e33c    	lsl	x28, x25, #7
101701ad4: 14000011    	b	0x101701b18 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8070>
101701ad8: 8b1b02e0    	add	x0, x23, x27
101701adc: 97a47e59    	bl	0x100021440 <__text+0x1d440>
101701ae0: 8b1b02e0    	add	x0, x23, x27
101701ae4: aa1903e1    	mov	x1, x25
101701ae8: 97a85900    	bl	0x100117ee8 <_cxxbridge1$slice$new+0xd240c>
101701aec: 3941c328    	ldrb	w8, [x25, #0x70]
101701af0: 3901c2c8    	strb	w8, [x22, #0x70]
101701af4: b8478f28    	ldr	w8, [x25, #0x78]!
101701af8: b9007ac8    	str	w8, [x22, #0x78]
101701afc: b900033f    	str	wzr, [x25]
101701b00: f9400288    	ldr	x8, [x20]
101701b04: 8b1b0100    	add	x0, x8, x27
101701b08: 97a47e4e    	bl	0x100021440 <__text+0x1d440>
101701b0c: 9102037b    	add	x27, x27, #0x80
101701b10: eb1b039f    	cmp	x28, x27
101701b14: 540001c0    	b.eq	0x101701b4c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a80a4>
101701b18: f9400288    	ldr	x8, [x20]
101701b1c: 8b1b02f6    	add	x22, x23, x27
101701b20: 8b1b0119    	add	x25, x8, x27
101701b24: eb15033f    	cmp	x25, x21
101701b28: 9a9802d8    	csel	x24, x22, x24, eq
101701b2c: f9403328    	ldr	x8, [x25, #0x60]
101701b30: 3941c329    	ldrb	w9, [x25, #0x70]
101701b34: 7102013f    	cmp	w9, #0x80
101701b38: fa400900    	ccmp	x8, #0x0, #0x0, eq
101701b3c: ba411904    	ccmn	x8, #0x1, #0x4, ne
101701b40: 54fffe60    	b.eq	0x101701b0c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8064>
101701b44: 17ffffe5    	b	0x101701ad8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8030>
101701b48: d2800018    	mov	x24, #0x0               ; =0
101701b4c: f9000297    	str	x23, [x20]
101701b50: aa1403e0    	mov	x0, x20
101701b54: aa1703e1    	mov	x1, x23
101701b58: 9411681c    	bl	0x101b5bbc8 <_media$cxxbridge1$199$SymphoniaDecoder$decode+0x3d390>
101701b5c: f94003f5    	ldr	x21, [sp]
101701b60: aa1503e0    	mov	x0, x21
101701b64: 94735393    	bl	0x1033d69b0 <_media$cxxbridge1$199$init_symphonia_decoder+0x7dff60>
101701b68: 910202b5    	add	x21, x21, #0x80
101701b6c: f100075a    	subs	x26, x26, #0x1
101701b70: 54ffff81    	b.ne	0x101701b60 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a80b8>
101701b74: aa1403e0    	mov	x0, x20
101701b78: f94003e1    	ldr	x1, [sp]
101701b7c: aa1303e2    	mov	x2, x19
101701b80: aa1803e3    	mov	x3, x24
101701b84: a94e7bfd    	ldp	x29, x30, [sp, #0xe0]
101701b88: a94d4ff4    	ldp	x20, x19, [sp, #0xd0]
101701b8c: a94c57f6    	ldp	x22, x21, [sp, #0xc0]
101701b90: a94b5ff8    	ldp	x24, x23, [sp, #0xb0]
101701b94: a94a67fa    	ldp	x26, x25, [sp, #0xa0]
101701b98: a9496ffc    	ldp	x28, x27, [sp, #0x90]
101701b9c: 9103c3ff    	add	sp, sp, #0xf0
101701ba0: 1400009b    	b	0x101701e0c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8364>
101701ba4: d4200000    	brk	#0
101701ba8: d4400000    	hlt	#0
101701bac: d4200020    	brk	#0x1
101701bb0: d4200000    	brk	#0
101701bb4: d4400000    	hlt	#0
101701bb8: d4200020    	brk	#0x1
101701bbc: d4200000    	brk	#0
101701bc0: d4400000    	hlt	#0
101701bc4: d4200020    	brk	#0x1
101701bc8: 97a57f6e    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
101701bcc: 17ffff5f    	b	0x101701948 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ea0>
101701bd0: f90003e2    	str	x2, [sp]
101701bd4: 97a6595f    	bl	0x100098150 <_cxxbridge1$slice$new+0x52674>
101701bd8: f94003e2    	ldr	x2, [sp]
101701bdc: 17ffff95    	b	0x101701a30 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7f88>
101701be0: 39400488    	ldrb	w8, [x4, #0x1]
101701be4: 34ffed48    	cbz	w8, 0x10170198c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ee4>
101701be8: 925e7700    	and	x0, x24, #0xfffffffc00000000
101701bec: b0045448    	adrp	x8, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101701bf0: f9443508    	ldr	x8, [x8, #0x868]
101701bf4: eb08001f    	cmp	x0, x8
101701bf8: 54ffeca1    	b.ne	0x10170198c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ee4>
101701bfc: d34c8708    	ubfx	x8, x24, #12, #22
101701c00: 38686808    	ldrb	w8, [x0, x8]
101701c04: 7100051f    	cmp	w8, #0x1
101701c08: 54ffec20    	b.eq	0x10170198c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ee4>
101701c0c: aa0003e1    	mov	x1, x0
101701c10: d2800003    	mov	x3, #0x0                ; =0
101701c14: 94a568ad    	bl	0x10405bec8 <__cppgc_internal_Uncompress_Member+0x1984>
101701c18: 17ffff5d    	b	0x10170198c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7ee4>
101701c1c: 00000000    	udf	#0x0
101701c20: d10483ff    	sub	sp, sp, #0x120
101701c24: a90f6ffc    	stp	x28, x27, [sp, #0xf0]
101701c28: a9104ff4    	stp	x20, x19, [sp, #0x100]
101701c2c: a9117bfd    	stp	x29, x30, [sp, #0x110]
101701c30: 910443fd    	add	x29, sp, #0x110
101701c34: aa0803f3    	mov	x19, x8
101701c38: b0045a08    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
101701c3c: f9473509    	ldr	x9, [x8, #0xe68]
101701c40: b5000bc9    	cbnz	x9, 0x101701db8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8310>
101701c44: d2800008    	mov	x8, #0x0                ; =0
101701c48: b90013ff    	str	wzr, [sp, #0x10]
101701c4c: d00444c9    	adrp	x9, 0x109f9b000 <dyld_stub_binder+0x109f9b000>
101701c50: f940c129    	ldr	x9, [x9, #0x180]
101701c54: f90003e9    	str	x9, [sp]
101701c58: f90007e8    	str	x8, [sp, #0x8]
101701c5c: 910203e0    	add	x0, sp, #0x80
101701c60: 910003e1    	mov	x1, sp
101701c64: 97b8c8a4    	bl	0x100533ef4 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x164d74>
101701c68: b940cfe8    	ldr	w8, [sp, #0xcc]
101701c6c: 36f80b28    	tbz	w8, #0x1f, 0x101701dd0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8328>
101701c70: 910003e0    	mov	x0, sp
101701c74: 910203e1    	add	x1, sp, #0x80
101701c78: 97a8589c    	bl	0x100117ee8 <_cxxbridge1$slice$new+0xd240c>
101701c7c: 52801008    	mov	w8, #0x80               ; =128
101701c80: 3901c3e8    	strb	w8, [sp, #0x70]
101701c84: 910203f4    	add	x20, sp, #0x80
101701c88: 9101a280    	add	x0, x20, #0x68
101701c8c: d2800001    	mov	x1, #0x0                ; =0
101701c90: 97a47e1c    	bl	0x100021500 <__text+0x1d500>
101701c94: f94073e0    	ldr	x0, [sp, #0xe0]
101701c98: b4000160    	cbz	x0, 0x101701cc4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a821c>
101701c9c: b9400808    	ldr	w8, [x0, #0x8]
101701ca0: 37080128    	tbnz	w8, #0x1, 0x101701cc4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a821c>
101701ca4: b9400008    	ldr	w8, [x0]
101701ca8: 71000509    	subs	w9, w8, #0x1
101701cac: 54000820    	b.eq	0x101701db0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8308>
101701cb0: aa0803ea    	mov	x10, x8
101701cb4: 88aafc09    	casl	w10, w9, [x0]
101701cb8: 6b08015f    	cmp	w10, w8
101701cbc: aa0a03e8    	mov	x8, x10
101701cc0: 54ffff41    	b.ne	0x101701ca8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8200>
101701cc4: 91004280    	add	x0, x20, #0x10
101701cc8: 97a45415    	bl	0x100016d1c <__text+0x12d1c>
101701ccc: f94047e0    	ldr	x0, [sp, #0x88]
101701cd0: b4000060    	cbz	x0, 0x101701cdc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8234>
101701cd4: b9400808    	ldr	w8, [x0, #0x8]
101701cd8: 36080568    	tbz	w8, #0x1, 0x101701d84 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a82dc>
101701cdc: 910003f4    	mov	x20, sp
101701ce0: 910003e1    	mov	x1, sp
101701ce4: aa1303e0    	mov	x0, x19
101701ce8: 97a85880    	bl	0x100117ee8 <_cxxbridge1$slice$new+0xd240c>
101701cec: 3941c3e8    	ldrb	w8, [sp, #0x70]
101701cf0: 3901c268    	strb	w8, [x19, #0x70]
101701cf4: b9007a7f    	str	wzr, [x19, #0x78]
101701cf8: 9101a280    	add	x0, x20, #0x68
101701cfc: d2800001    	mov	x1, #0x0                ; =0
101701d00: 97a47e00    	bl	0x100021500 <__text+0x1d500>
101701d04: f94033e0    	ldr	x0, [sp, #0x60]
101701d08: b4000160    	cbz	x0, 0x101701d34 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a828c>
101701d0c: b9400808    	ldr	w8, [x0, #0x8]
101701d10: 37080128    	tbnz	w8, #0x1, 0x101701d34 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a828c>
101701d14: b9400008    	ldr	w8, [x0]
101701d18: 71000509    	subs	w9, w8, #0x1
101701d1c: 54000460    	b.eq	0x101701da8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8300>
101701d20: aa0803ea    	mov	x10, x8
101701d24: 88aafc09    	casl	w10, w9, [x0]
101701d28: 6b08015f    	cmp	w10, w8
101701d2c: aa0a03e8    	mov	x8, x10
101701d30: 54ffff41    	b.ne	0x101701d18 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8270>
101701d34: 91004280    	add	x0, x20, #0x10
101701d38: 97a453f9    	bl	0x100016d1c <__text+0x12d1c>
101701d3c: f94007e0    	ldr	x0, [sp, #0x8]
101701d40: b4000060    	cbz	x0, 0x101701d4c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a82a4>
101701d44: b9400808    	ldr	w8, [x0, #0x8]
101701d48: 360800c8    	tbz	w8, #0x1, 0x101701d60 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a82b8>
101701d4c: a9517bfd    	ldp	x29, x30, [sp, #0x110]
101701d50: a9504ff4    	ldp	x20, x19, [sp, #0x100]
101701d54: a94f6ffc    	ldp	x28, x27, [sp, #0xf0]
101701d58: 910483ff    	add	sp, sp, #0x120
101701d5c: d65f03c0    	ret
101701d60: b9400008    	ldr	w8, [x0]
101701d64: 71000509    	subs	w9, w8, #0x1
101701d68: 540004e0    	b.eq	0x101701e04 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a835c>
101701d6c: aa0803ea    	mov	x10, x8
101701d70: 88aafc09    	casl	w10, w9, [x0]
101701d74: 6b08015f    	cmp	w10, w8
101701d78: aa0a03e8    	mov	x8, x10
101701d7c: 54ffff41    	b.ne	0x101701d64 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a82bc>
101701d80: 17fffff3    	b	0x101701d4c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a82a4>
101701d84: b9400008    	ldr	w8, [x0]
101701d88: 71000509    	subs	w9, w8, #0x1
101701d8c: 54000380    	b.eq	0x101701dfc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8354>
101701d90: aa0803ea    	mov	x10, x8
101701d94: 88aafc09    	casl	w10, w9, [x0]
101701d98: 6b08015f    	cmp	w10, w8
101701d9c: aa0a03e8    	mov	x8, x10
101701da0: 54ffff41    	b.ne	0x101701d88 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a82e0>
101701da4: 17ffffce    	b	0x101701cdc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8234>
101701da8: 97a57ef6    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
101701dac: 17ffffe2    	b	0x101701d34 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a828c>
101701db0: 97a57ef4    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
101701db4: 17ffffc4    	b	0x101701cc4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a821c>
101701db8: f90003e9    	str	x9, [sp]
101701dbc: b9400528    	ldr	w8, [x9, #0x4]
101701dc0: b90013e8    	str	w8, [sp, #0x10]
101701dc4: 91003128    	add	x8, x9, #0xc
101701dc8: b940093f    	ldr	wzr, [x9, #0x8]
101701dcc: 17ffffa3    	b	0x101701c58 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a81b0>
101701dd0: 6f00e400    	movi.2d	v0, #0000000000000000
101701dd4: ad0283e0    	stp	q0, q0, [sp, #0x50]
101701dd8: ad0183e0    	stp	q0, q0, [sp, #0x30]
101701ddc: ad0083e0    	stp	q0, q0, [sp, #0x10]
101701de0: 3d8003e0    	str	q0, [sp]
101701de4: 910003e0    	mov	x0, sp
101701de8: 910203e1    	add	x1, sp, #0x80
101701dec: 97a8583f    	bl	0x100117ee8 <_cxxbridge1$slice$new+0xd240c>
101701df0: 910003e0    	mov	x0, sp
101701df4: 94504357    	bl	0x102b12b50 <_rust_png$cxxbridge1$199$new_writer+0x1a63d0>
101701df8: 17ffffa1    	b	0x101701c7c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a81d4>
101701dfc: 97a57ee1    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
101701e00: 17ffffb7    	b	0x101701cdc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8234>
101701e04: 97a57edf    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
101701e08: 17ffffd1    	b	0x101701d4c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a82a4>
101701e0c: d101c3ff    	sub	sp, sp, #0x70
101701e10: a9016ffc    	stp	x28, x27, [sp, #0x10]
101701e14: a90267fa    	stp	x26, x25, [sp, #0x20]
101701e18: a9035ff8    	stp	x24, x23, [sp, #0x30]
101701e1c: a90457f6    	stp	x22, x21, [sp, #0x40]
101701e20: a9054ff4    	stp	x20, x19, [sp, #0x50]
101701e24: a9067bfd    	stp	x29, x30, [sp, #0x60]
101701e28: 910183fd    	add	x29, sp, #0x60
101701e2c: aa0203f5    	mov	x21, x2
101701e30: aa0103f6    	mov	x22, x1
101701e34: aa0003f3    	mov	x19, x0
101701e38: b9400809    	ldr	w9, [x0, #0x8]
101701e3c: 34001a09    	cbz	w9, 0x10170217c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a86d4>
101701e40: aa0303f7    	mov	x23, x3
101701e44: d2800014    	mov	x20, #0x0               ; =0
101701e48: 5280000a    	mov	w10, #0x0               ; =0
101701e4c: f9400268    	ldr	x8, [x19]
101701e50: 510006ba    	sub	w26, w21, #0x1
101701e54: d28d645c    	mov	x28, #0x6b22            ; =27426
101701e58: f2abf83c    	movk	x28, #0x5fc1, lsl #16
101701e5c: f2c478fc    	movk	x28, #0x23c7, lsl #32
101701e60: f2fed0dc    	movk	x28, #0xf686, lsl #48
101701e64: 14000011    	b	0x101701ea8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8400>
101701e68: aa1903e0    	mov	x0, x25
101701e6c: aa1803e1    	mov	x1, x24
101701e70: 97a8581e    	bl	0x100117ee8 <_cxxbridge1$slice$new+0xd240c>
101701e74: 3941c308    	ldrb	w8, [x24, #0x70]
101701e78: 3901c328    	strb	w8, [x25, #0x70]
101701e7c: b8478f08    	ldr	w8, [x24, #0x78]!
101701e80: b9007b28    	str	w8, [x25, #0x78]
101701e84: b900031f    	str	wzr, [x24]
101701e88: f9400268    	ldr	x8, [x19]
101701e8c: 8b1b1d09    	add	x9, x8, x27, lsl #7
101701e90: eb17013f    	cmp	x9, x23
101701e94: 9a940334    	csel	x20, x25, x20, eq
101701e98: b9400a69    	ldr	w9, [x19, #0x8]
101701e9c: 1100076a    	add	w10, w27, #0x1
101701ea0: 6b09015f    	cmp	w10, w9
101701ea4: 54000920    	b.eq	0x101701fc8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8520>
101701ea8: 2a0a03fb    	mov	w27, w10
101701eac: 8b1b1d18    	add	x24, x8, x27, lsl #7
101701eb0: f940330b    	ldr	x11, [x24, #0x60]
101701eb4: 3941c30a    	ldrb	w10, [x24, #0x70]
101701eb8: 7102015f    	cmp	w10, #0x80
101701ebc: fa400960    	ccmp	x11, #0x0, #0x0, eq
101701ec0: ba411964    	ccmn	x11, #0x1, #0x4, ne
101701ec4: 54fffec0    	b.eq	0x101701e9c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a83f4>
101701ec8: b9400968    	ldr	w8, [x11, #0x8]
101701ecc: d348fd08    	lsr	x8, x8, #8
101701ed0: 2a2a3fe9    	mvn	w9, w10, lsl #15
101701ed4: 0b0a0129    	add	w9, w9, w10
101701ed8: 4a492929    	eor	w9, w9, w9, lsr #10
101701edc: 0b090d29    	add	w9, w9, w9, lsl #3
101701ee0: 4a491929    	eor	w9, w9, w9, lsr #6
101701ee4: 2a292fea    	mvn	w10, w9, lsl #11
101701ee8: 0b0a0129    	add	w9, w9, w10
101701eec: 4a494129    	eor	w9, w9, w9, lsr #16
101701ef0: 9b1c7d29    	mul	x9, x9, x28
101701ef4: d2813eea    	mov	x10, #0x9f7             ; =2551
101701ef8: f2be128a    	movk	x10, #0xf094, lsl #16
101701efc: f2da7caa    	movk	x10, #0xd3e5, lsl #32
101701f00: f2e8ed4a    	movk	x10, #0x476a, lsl #48
101701f04: 9b0a2508    	madd	x8, x8, x10, x9
101701f08: 8a488348    	and	x8, x26, x8, lsr #32
101701f0c: 8b081ed9    	add	x25, x22, x8, lsl #7
101701f10: f9403329    	ldr	x9, [x25, #0x60]
101701f14: b5000449    	cbnz	x9, 0x101701f9c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a84f4>
101701f18: 3941c329    	ldrb	w9, [x25, #0x70]
101701f1c: 7102013f    	cmp	w9, #0x80
101701f20: 540003e1    	b.ne	0x101701f9c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a84f4>
101701f24: 9101a320    	add	x0, x25, #0x68
101701f28: d2800001    	mov	x1, #0x0                ; =0
101701f2c: 97a47d75    	bl	0x100021500 <__text+0x1d500>
101701f30: f9403320    	ldr	x0, [x25, #0x60]
101701f34: b4000160    	cbz	x0, 0x101701f60 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a84b8>
101701f38: b9400808    	ldr	w8, [x0, #0x8]
101701f3c: 37080128    	tbnz	w8, #0x1, 0x101701f60 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a84b8>
101701f40: b9400008    	ldr	w8, [x0]
101701f44: 71000509    	subs	w9, w8, #0x1
101701f48: 54000f00    	b.eq	0x101702128 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8680>
101701f4c: aa0803ea    	mov	x10, x8
101701f50: 88aafc09    	casl	w10, w9, [x0]
101701f54: 6b08015f    	cmp	w10, w8
101701f58: aa0a03e8    	mov	x8, x10
101701f5c: 54ffff41    	b.ne	0x101701f44 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a849c>
101701f60: 91004320    	add	x0, x25, #0x10
101701f64: 97a4536e    	bl	0x100016d1c <__text+0x12d1c>
101701f68: f9400720    	ldr	x0, [x25, #0x8]
101701f6c: b4fff7e0    	cbz	x0, 0x101701e68 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a83c0>
101701f70: b9400808    	ldr	w8, [x0, #0x8]
101701f74: 370ff7a8    	tbnz	w8, #0x1, 0x101701e68 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a83c0>
101701f78: b9400008    	ldr	w8, [x0]
101701f7c: 71000509    	subs	w9, w8, #0x1
101701f80: 54001060    	b.eq	0x10170218c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a86e4>
101701f84: aa0803ea    	mov	x10, x8
101701f88: 88aafc09    	casl	w10, w9, [x0]
101701f8c: 6b08015f    	cmp	w10, w8
101701f90: aa0a03e8    	mov	x8, x10
101701f94: 54ffff41    	b.ne	0x101701f7c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a84d4>
101701f98: 17ffffb4    	b	0x101701e68 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a83c0>
101701f9c: 52800029    	mov	w9, #0x1                ; =1
101701fa0: 0b090108    	add	w8, w8, w9
101701fa4: 8a1a0108    	and	x8, x8, x26
101701fa8: 8b081ed9    	add	x25, x22, x8, lsl #7
101701fac: f940332a    	ldr	x10, [x25, #0x60]
101701fb0: 91000529    	add	x9, x9, #0x1
101701fb4: b5ffff6a    	cbnz	x10, 0x101701fa0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a84f8>
101701fb8: 3941c32a    	ldrb	w10, [x25, #0x70]
101701fbc: 7102015f    	cmp	w10, #0x80
101701fc0: 54ffff01    	b.ne	0x101701fa0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a84f8>
101701fc4: 17ffffd8    	b	0x101701f24 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a847c>
101701fc8: 925e76c8    	and	x8, x22, #0xfffffffc00000000
101701fcc: b004544a    	adrp	x10, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101701fd0: f944354b    	ldr	x11, [x10, #0x868]
101701fd4: eb0b011f    	cmp	x8, x11
101701fd8: 540000a1    	b.ne	0x101701fec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8544>
101701fdc: 926fbac8    	and	x8, x22, #0xfffffffffffe0000
101701fe0: f9400108    	ldr	x8, [x8]
101701fe4: 39400108    	ldrb	w8, [x8]
101701fe8: 35000c28    	cbnz	w8, 0x10170216c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a86c4>
101701fec: f9400277    	ldr	x23, [x19]
101701ff0: f9000276    	str	x22, [x19]
101701ff4: b0045448    	adrp	x8, 0x10a18a000 <dyld_stub_binder+0x10a18a000>
101701ff8: b9486108    	ldr	w8, [x8, #0x860]
101701ffc: 350009e8    	cbnz	w8, 0x101702138 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8690>
101702000: b9000a75    	str	w21, [x19, #0x8]
101702004: b4000277    	cbz	x23, 0x101702050 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a85a8>
101702008: 340000a9    	cbz	w9, 0x10170201c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8574>
10170200c: d2800015    	mov	x21, #0x0               ; =0
101702010: 2a0903f6    	mov	w22, w9
101702014: 92800018    	mov	x24, #-0x1              ; =-1
101702018: 1400001f    	b	0x101702094 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a85ec>
10170201c: 90045a08    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
101702020: f946f508    	ldr	x8, [x8, #0xde8]
101702024: 910023e9    	add	x9, sp, #0x8
101702028: 90045a0a    	adrp	x10, 0x10a242000 <dyld_stub_binder+0x10a242000>
10170202c: f946f94a    	ldr	x10, [x10, #0xdf0]
101702030: cb090108    	sub	x8, x8, x9
101702034: eb0a011f    	cmp	x8, x10
101702038: 54000a62    	b.hs	0x101702184 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a86dc>
10170203c: b00454e0    	adrp	x0, 0x10a19f000 <dyld_stub_binder+0x10a19f000>
101702040: 9100c000    	add	x0, x0, #0x30
101702044: f9400400    	ldr	x0, [x0, #0x8]
101702048: aa1703e1    	mov	x1, x23
10170204c: 97a7e343    	bl	0x1000fad58 <_cxxbridge1$slice$new+0xb527c>
101702050: b9401268    	ldr	w8, [x19, #0x10]
101702054: 12010108    	and	w8, w8, #0x80000000
101702058: b9001268    	str	w8, [x19, #0x10]
10170205c: aa1403e0    	mov	x0, x20
101702060: a9467bfd    	ldp	x29, x30, [sp, #0x60]
101702064: a9454ff4    	ldp	x20, x19, [sp, #0x50]
101702068: a94457f6    	ldp	x22, x21, [sp, #0x40]
10170206c: a9435ff8    	ldp	x24, x23, [sp, #0x30]
101702070: a94267fa    	ldp	x26, x25, [sp, #0x20]
101702074: a9416ffc    	ldp	x28, x27, [sp, #0x10]
101702078: 9101c3ff    	add	sp, sp, #0x70
10170207c: d65f03c0    	ret
101702080: f9003338    	str	x24, [x25, #0x60]
101702084: b9007b3f    	str	wzr, [x25, #0x78]
101702088: 910006b5    	add	x21, x21, #0x1
10170208c: eb1602bf    	cmp	x21, x22
101702090: 54fffc60    	b.eq	0x10170201c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8574>
101702094: 8b151ef9    	add	x25, x23, x21, lsl #7
101702098: f9403328    	ldr	x8, [x25, #0x60]
10170209c: 3941c329    	ldrb	w9, [x25, #0x70]
1017020a0: 7102013f    	cmp	w9, #0x80
1017020a4: fa400900    	ccmp	x8, #0x0, #0x0, eq
1017020a8: ba411904    	ccmn	x8, #0x1, #0x4, ne
1017020ac: 54fffee0    	b.eq	0x101702088 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a85e0>
1017020b0: 9101a320    	add	x0, x25, #0x68
1017020b4: d2800001    	mov	x1, #0x0                ; =0
1017020b8: 97a47d12    	bl	0x100021500 <__text+0x1d500>
1017020bc: f9403320    	ldr	x0, [x25, #0x60]
1017020c0: b4000160    	cbz	x0, 0x1017020ec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8644>
1017020c4: b9400808    	ldr	w8, [x0, #0x8]
1017020c8: 37080128    	tbnz	w8, #0x1, 0x1017020ec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8644>
1017020cc: b9400008    	ldr	w8, [x0]
1017020d0: 71000509    	subs	w9, w8, #0x1
1017020d4: 540002e0    	b.eq	0x101702130 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8688>
1017020d8: aa0803ea    	mov	x10, x8
1017020dc: 88aafc09    	casl	w10, w9, [x0]
1017020e0: 6b08015f    	cmp	w10, w8
1017020e4: aa0a03e8    	mov	x8, x10
1017020e8: 54ffff41    	b.ne	0x1017020d0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8628>
1017020ec: 91004320    	add	x0, x25, #0x10
1017020f0: 97a4530b    	bl	0x100016d1c <__text+0x12d1c>
1017020f4: f9400720    	ldr	x0, [x25, #0x8]
1017020f8: b4fffc40    	cbz	x0, 0x101702080 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a85d8>
1017020fc: b9400808    	ldr	w8, [x0, #0x8]
101702100: 370ffc08    	tbnz	w8, #0x1, 0x101702080 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a85d8>
101702104: b9400008    	ldr	w8, [x0]
101702108: 71000509    	subs	w9, w8, #0x1
10170210c: 54000440    	b.eq	0x101702194 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a86ec>
101702110: aa0803ea    	mov	x10, x8
101702114: 88aafc09    	casl	w10, w9, [x0]
101702118: 6b08015f    	cmp	w10, w8
10170211c: aa0a03e8    	mov	x8, x10
101702120: 54ffff41    	b.ne	0x101702108 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8660>
101702124: 17ffffd7    	b	0x101702080 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a85d8>
101702128: 97a57e16    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
10170212c: 17ffff8d    	b	0x101701f60 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a84b8>
101702130: 97a57e14    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
101702134: 17ffffee    	b	0x1017020ec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8644>
101702138: f9443540    	ldr	x0, [x10, #0x868]
10170213c: ca130008    	eor	x8, x0, x19
101702140: ca16000a    	eor	x10, x0, x22
101702144: aa0a0108    	orr	x8, x8, x10
101702148: d362fd08    	lsr	x8, x8, #34
10170214c: b5fff5a8    	cbnz	x8, 0x101702000 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8558>
101702150: 926fbac8    	and	x8, x22, #0xfffffffffffe0000
101702154: f9400104    	ldr	x4, [x8]
101702158: 39400088    	ldrb	w8, [x4]
10170215c: 36000208    	tbz	w8, #0x0, 0x10170219c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a86f4>
101702160: aa1603e0    	mov	x0, x22
101702164: 97a40f1d    	bl	0x100005dd8 <__text+0x1dd8>
101702168: 17ffffa6    	b	0x101702000 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8558>
10170216c: aa1603e0    	mov	x0, x22
101702170: 97b48280    	bl	0x100422b70 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x539f0>
101702174: b9400a69    	ldr	w9, [x19, #0x8]
101702178: 17ffff9d    	b	0x101701fec <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8544>
10170217c: d2800014    	mov	x20, #0x0               ; =0
101702180: 17ffff92    	b	0x101701fc8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8520>
101702184: 97a657f3    	bl	0x100098150 <_cxxbridge1$slice$new+0x52674>
101702188: 17ffffaf    	b	0x101702044 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a859c>
10170218c: 97a57dfd    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
101702190: 17ffff36    	b	0x101701e68 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a83c0>
101702194: 97a57dfb    	bl	0x100061980 <_cxxbridge1$slice$new+0x1bea4>
101702198: 17ffffba    	b	0x101702080 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a85d8>
10170219c: 39400488    	ldrb	w8, [x4, #0x1]
1017021a0: 3607f308    	tbz	w8, #0x0, 0x101702000 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8558>
1017021a4: d34c8668    	ubfx	x8, x19, #12, #22
1017021a8: 38686808    	ldrb	w8, [x0, x8]
1017021ac: 7100051f    	cmp	w8, #0x1
1017021b0: 54fff280    	b.eq	0x101702000 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8558>
1017021b4: 924086c3    	and	x3, x22, #0x3ffffffff
1017021b8: aa0003e1    	mov	x1, x0
1017021bc: aa1303e2    	mov	x2, x19
1017021c0: 94a56757    	bl	0x10405bf1c <__cppgc_internal_Uncompress_Member+0x19d8>
1017021c4: 17ffff8f    	b	0x101702000 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8558>
1017021c8: d10243ff    	sub	sp, sp, #0x90
1017021cc: a9036ffc    	stp	x28, x27, [sp, #0x30]
1017021d0: a90467fa    	stp	x26, x25, [sp, #0x40]
1017021d4: a9055ff8    	stp	x24, x23, [sp, #0x50]
1017021d8: a90657f6    	stp	x22, x21, [sp, #0x60]
1017021dc: a9074ff4    	stp	x20, x19, [sp, #0x70]
1017021e0: a9087bfd    	stp	x29, x30, [sp, #0x80]
1017021e4: 910203fd    	add	x29, sp, #0x80
1017021e8: d0041188    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
1017021ec: f9401108    	ldr	x8, [x8, #0x20]
1017021f0: f9400108    	ldr	x8, [x8]
1017021f4: f90017e8    	str	x8, [sp, #0x28]
1017021f8: f9421408    	ldr	x8, [x0, #0x428]
1017021fc: b4000ba8    	cbz	x8, 0x101702370 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a88c8>
101702200: aa0203f5    	mov	x21, x2
101702204: aa0103f4    	mov	x20, x1
101702208: aa0003f3    	mov	x19, x0
10170220c: f9419009    	ldr	x9, [x0, #0x320]
101702210: f9418808    	ldr	x8, [x0, #0x310]
101702214: cb080129    	sub	x9, x9, x8
101702218: f100213f    	cmp	x9, #0x8
10170221c: 54002209    	b.ls	0x10170265c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8bb4>
101702220: 91004109    	add	x9, x8, #0x10
101702224: f9418e6a    	ldr	x10, [x19, #0x318]
101702228: eb0a013f    	cmp	x9, x10
10170222c: 540000c2    	b.hs	0x101702244 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a879c>
101702230: 9100410b    	add	x11, x8, #0x10
101702234: b400220b    	cbz	x11, 0x101702674 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8bcc>
101702238: 9100216b    	add	x11, x11, #0x8
10170223c: eb0a017f    	cmp	x11, x10
101702240: 54ffffa1    	b.ne	0x101702234 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a878c>
101702244: f9018e69    	str	x9, [x19, #0x318]
101702248: 52800036    	mov	w22, #0x1               ; =1
10170224c: b9000116    	str	w22, [x8]
101702250: 39001115    	strb	w21, [x8, #0x4]
101702254: f9000514    	str	x20, [x8, #0x8]
101702258: f9421677    	ldr	x23, [x19, #0x428]
10170225c: f85f8278    	ldur	x24, [x19, #-0x8]
101702260: a941230a    	ldp	x10, x8, [x24, #0x10]
101702264: cb0a0119    	sub	x25, x8, x10
101702268: f940130b    	ldr	x11, [x24, #0x20]
10170226c: cb08016c    	sub	x12, x11, x8
101702270: cb0a0109    	sub	x9, x8, x10
101702274: f100219f    	cmp	x12, #0x8
101702278: 54001789    	b.ls	0x101702568 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8ac0>
10170227c: 9100410a    	add	x10, x8, #0x10
101702280: f9000f0a    	str	x10, [x24, #0x18]
101702284: f940170a    	ldr	x10, [x24, #0x28]
101702288: 53047d2b    	lsr	w11, w9, #4
10170228c: 5280004c    	mov	w12, #0x2               ; =2
101702290: 782b794c    	strh	w12, [x10, x11, lsl #1]
101702294: f940170a    	ldr	x10, [x24, #0x28]
101702298: 11004129    	add	w9, w9, #0x10
10170229c: 53047d29    	lsr	w9, w9, #4
1017022a0: 51000529    	sub	w9, w9, #0x1
1017022a4: 7829594c    	strh	w12, [x10, w9, uxtw #1]
1017022a8: b9000116    	str	w22, [x8]
1017022ac: 39001115    	strb	w21, [x8, #0x4]
1017022b0: f9000514    	str	x20, [x8, #0x8]
1017022b4: b9443e78    	ldr	w24, [x19, #0x43c]
1017022b8: f85f827a    	ldur	x26, [x19, #-0x8]
1017022bc: 2a1903f5    	mov	w21, w25
1017022c0: 53047f39    	lsr	w25, w25, #4
1017022c4: a94d8348    	ldp	x8, x0, [x26, #0xd8]
1017022c8: cb080009    	sub	x9, x0, x8
1017022cc: eb890b3f    	cmp	x25, x9, asr #2
1017022d0: 54001062    	b.hs	0x1017024dc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8a34>
1017022d4: b8397918    	str	w24, [x8, x25, lsl #2]
1017022d8: f85f0268    	ldur	x8, [x19, #-0x10]
1017022dc: a94ba508    	ldp	x8, x9, [x8, #0xb8]
1017022e0: eb08013f    	cmp	x9, x8
1017022e4: 54001ca1    	b.ne	0x101702678 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8bd0>
1017022e8: f85f8276    	ldur	x22, [x19, #-0x8]
1017022ec: f9421678    	ldr	x24, [x19, #0x428]
1017022f0: b9401ac8    	ldr	w8, [x22, #0x18]
1017022f4: b94012c9    	ldr	w9, [x22, #0x10]
1017022f8: b9402f1a    	ldr	w26, [x24, #0x2c]
1017022fc: 4b090119    	sub	w25, w8, w9
101702300: 6b19035f    	cmp	w26, w25
101702304: b9003319    	str	w25, [x24, #0x30]
101702308: 540001e0    	b.eq	0x101702344 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a889c>
10170230c: 9280007b    	mov	x27, #-0x4              ; =-4
101702310: b9403715    	ldr	w21, [x24, #0x34]
101702314: d344ff5c    	lsr	x28, x26, #4
101702318: a94702c8    	ldp	x8, x0, [x22, #0x70]
10170231c: cb080009    	sub	x9, x0, x8
101702320: eb890b9f    	cmp	x28, x9, asr #2
101702324: 540007a2    	b.hs	0x101702418 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8970>
101702328: b83c7915    	str	w21, [x8, x28, lsl #2]
10170232c: f94016c8    	ldr	x8, [x22, #0x28]
101702330: 787c7908    	ldrh	w8, [x8, x28, lsl #1]
101702334: 8b080f48    	add	x8, x26, x8, lsl #3
101702338: 2a0803fa    	mov	w26, w8
10170233c: 6b19011f    	cmp	w8, w25
101702340: 54fffe81    	b.ne	0x101702310 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8868>
101702344: f902167f    	str	xzr, [x19, #0x428]
101702348: f9401e81    	ldr	x1, [x20, #0x38]
10170234c: b50002e1    	cbnz	x1, 0x1017023a8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8900>
101702350: f90022ff    	str	xzr, [x23, #0x40]
101702354: f9001e97    	str	x23, [x20, #0x38]
101702358: b9405288    	ldr	w8, [x20, #0x50]
10170235c: 11000508    	add	w8, w8, #0x1
101702360: b9005288    	str	w8, [x20, #0x50]
101702364: b9403688    	ldr	w8, [x20, #0x34]
101702368: 3100051f    	cmn	w8, #0x1
10170236c: 54000341    	b.ne	0x1017023d4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a892c>
101702370: f94017e8    	ldr	x8, [sp, #0x28]
101702374: d0041189    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
101702378: f9401129    	ldr	x9, [x9, #0x20]
10170237c: f9400129    	ldr	x9, [x9]
101702380: eb08013f    	cmp	x9, x8
101702384: 540015e1    	b.ne	0x101702640 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8b98>
101702388: a9487bfd    	ldp	x29, x30, [sp, #0x80]
10170238c: a9474ff4    	ldp	x20, x19, [sp, #0x70]
101702390: a94657f6    	ldp	x22, x21, [sp, #0x60]
101702394: a9455ff8    	ldp	x24, x23, [sp, #0x50]
101702398: a94467fa    	ldp	x26, x25, [sp, #0x40]
10170239c: a9436ffc    	ldp	x28, x27, [sp, #0x30]
1017023a0: 910243ff    	add	sp, sp, #0x90
1017023a4: d65f03c0    	ret
1017023a8: 3940a288    	ldrb	w8, [x20, #0x28]
1017023ac: 7100051f    	cmp	w8, #0x1
1017023b0: 540000a0    	b.eq	0x1017023c4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a891c>
1017023b4: 7100091f    	cmp	w8, #0x2
1017023b8: 54000e80    	b.eq	0x101702588 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8ae0>
1017023bc: f90022e1    	str	x1, [x23, #0x40]
1017023c0: 17ffffe5    	b	0x101702354 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a88ac>
1017023c4: b9403688    	ldr	w8, [x20, #0x34]
1017023c8: 3100051f    	cmn	w8, #0x1
1017023cc: 54ffff81    	b.ne	0x1017023bc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8914>
1017023d0: 140000c3    	b	0x1017026dc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8c34>
1017023d4: b90023e8    	str	w8, [sp, #0x20]
1017023d8: f9416a69    	ldr	x9, [x19, #0x2d0]
1017023dc: f27f193f    	tst	x9, #0xfe
1017023e0: 54001321    	b.ne	0x101702644 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8b9c>
1017023e4: f144013f    	cmp	x9, #0x100, lsl #12     ; =0x100000
1017023e8: 540011c2    	b.hs	0x101702620 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8b78>
1017023ec: d2800001    	mov	x1, #0x0                ; =0
1017023f0: a90107e0    	stp	x0, x1, [sp, #0x10]
1017023f4: f0045428    	adrp	x8, 0x10a189000 <dyld_stub_binder+0x10a189000>
1017023f8: 91240108    	add	x8, x8, #0x900
1017023fc: eb08003f    	cmp	x1, x8
101702400: fa401824    	ccmp	x1, #0x0, #0x4, ne
101702404: 540005c1    	b.ne	0x1017024bc <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8a14>
101702408: eb08003f    	cmp	x1, x8
10170240c: 540014a0    	b.eq	0x1017026a0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8bf8>
101702410: b4fffb01    	cbz	x1, 0x101702370 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a88c8>
101702414: 14000066    	b	0x1017025ac <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8b04>
101702418: 8b5a1789    	add	x9, x28, x26, lsr #5
10170241c: 91008129    	add	x9, x9, #0x20
101702420: f94042ca    	ldr	x10, [x22, #0x80]
101702424: cb08014a    	sub	x10, x10, x8
101702428: eb8a093f    	cmp	x9, x10, asr #2
10170242c: 540000a9    	b.ls	0x101702440 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8998>
101702430: 9101a2c0    	add	x0, x22, #0x68
101702434: aa0903e1    	mov	x1, x9
101702438: 97b38f53    	bl	0x1003e6184 <_rust_png$cxxbridge1$199$Reader$has_actl_chunk+0x17004>
10170243c: a94702c8    	ldp	x8, x0, [x22, #0x70]
101702440: 8b090909    	add	x9, x8, x9, lsl #2
101702444: eb09001f    	cmp	x0, x9
101702448: 54000182    	b.hs	0x101702478 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a89d0>
10170244c: 91001008    	add	x8, x0, #0x4
101702450: eb08013f    	cmp	x9, x8
101702454: 9a888128    	csel	x8, x9, x8, hi
101702458: cb080008    	sub	x8, x0, x8
10170245c: 8a280368    	bic	x8, x27, x8
101702460: 91001102    	add	x2, x8, #0x4
101702464: 52801fe1    	mov	w1, #0xff               ; =255
101702468: f90007e9    	str	x9, [sp, #0x8]
10170246c: 95d5574c    	bl	0x108c5819c <dyld_stub_binder+0x108c5819c>
101702470: f94007e9    	ldr	x9, [sp, #0x8]
101702474: f9403ac8    	ldr	x8, [x22, #0x70]
101702478: f94042ca    	ldr	x10, [x22, #0x80]
10170247c: eb0a013f    	cmp	x9, x10
101702480: 540001a2    	b.hs	0x1017024b4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8a0c>
101702484: 91001128    	add	x8, x9, #0x4
101702488: eb08015f    	cmp	x10, x8
10170248c: 9a888148    	csel	x8, x10, x8, hi
101702490: cb080128    	sub	x8, x9, x8
101702494: 8a280368    	bic	x8, x27, x8
101702498: 91001102    	add	x2, x8, #0x4
10170249c: aa0903e0    	mov	x0, x9
1017024a0: 52801fe1    	mov	w1, #0xff               ; =255
1017024a4: f90007ea    	str	x10, [sp, #0x8]
1017024a8: 95d5573d    	bl	0x108c5819c <dyld_stub_binder+0x108c5819c>
1017024ac: f94007ea    	ldr	x10, [sp, #0x8]
1017024b0: f9403ac8    	ldr	x8, [x22, #0x70]
1017024b4: f9003eca    	str	x10, [x22, #0x78]
1017024b8: 17ffff9c    	b	0x101702328 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8880>
1017024bc: 39400009    	ldrb	w9, [x0]
1017024c0: 363ffa49    	tbz	w9, #0x7, 0x101702408 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8960>
1017024c4: d4200020    	brk	#0x1
1017024c8: 91034340    	add	x0, x26, #0xd0
1017024cc: aa0903e1    	mov	x1, x9
1017024d0: 97aff1ac    	bl	0x1002feb80 <_cxxbridge1$slice$new+0x2b90a4>
1017024d4: a94d8348    	ldp	x8, x0, [x26, #0xd8]
1017024d8: 14000007    	b	0x1017024f4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8a4c>
1017024dc: 8b551729    	add	x9, x25, x21, lsr #5
1017024e0: 91008129    	add	x9, x9, #0x20
1017024e4: f940774a    	ldr	x10, [x26, #0xe8]
1017024e8: cb08014a    	sub	x10, x10, x8
1017024ec: eb8a093f    	cmp	x9, x10, asr #2
1017024f0: 54fffec8    	b.hi	0x1017024c8 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8a20>
1017024f4: 8b090916    	add	x22, x8, x9, lsl #2
1017024f8: eb16001f    	cmp	x0, x22
1017024fc: 54000162    	b.hs	0x101702528 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8a80>
101702500: 91001008    	add	x8, x0, #0x4
101702504: eb0802df    	cmp	x22, x8
101702508: 9a8882c8    	csel	x8, x22, x8, hi
10170250c: 92800069    	mov	x9, #-0x4               ; =-4
101702510: cb080008    	sub	x8, x0, x8
101702514: 8a280128    	bic	x8, x9, x8
101702518: 91001102    	add	x2, x8, #0x4
10170251c: 52801fe1    	mov	w1, #0xff               ; =255
101702520: 95d5571f    	bl	0x108c5819c <dyld_stub_binder+0x108c5819c>
101702524: f9406f48    	ldr	x8, [x26, #0xd8]
101702528: f940775b    	ldr	x27, [x26, #0xe8]
10170252c: eb1b02df    	cmp	x22, x27
101702530: 54000182    	b.hs	0x101702560 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8ab8>
101702534: 910012c8    	add	x8, x22, #0x4
101702538: eb08037f    	cmp	x27, x8
10170253c: 9a888368    	csel	x8, x27, x8, hi
101702540: 92800069    	mov	x9, #-0x4               ; =-4
101702544: cb0802c8    	sub	x8, x22, x8
101702548: 8a280128    	bic	x8, x9, x8
10170254c: 91001102    	add	x2, x8, #0x4
101702550: aa1603e0    	mov	x0, x22
101702554: 52801fe1    	mov	w1, #0xff               ; =255
101702558: 95d55711    	bl	0x108c5819c <dyld_stub_binder+0x108c5819c>
10170255c: f9406f48    	ldr	x8, [x26, #0xd8]
101702560: f900735b    	str	x27, [x26, #0xe0]
101702564: 17ffff5c    	b	0x1017022d4 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a882c>
101702568: cb0a0168    	sub	x8, x11, x10
10170256c: d3438908    	ubfx	x8, x8, #3, #32
101702570: 91002300    	add	x0, x24, #0x8
101702574: 91000901    	add	x1, x8, #0x2
101702578: 97c7d3d2    	bl	0x1008f74c0 <_rust_png$cxxbridge1$199$Reader$interlaced+0x3f280>
10170257c: a9412309    	ldp	x9, x8, [x24, #0x10]
101702580: cb090109    	sub	x9, x8, x9
101702584: 17ffff3e    	b	0x10170227c <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a87d4>
101702588: f9001e9f    	str	xzr, [x20, #0x38]
10170258c: b900529f    	str	wzr, [x20, #0x50]
101702590: 3900a29f    	strb	wzr, [x20, #0x28]
101702594: d1008260    	sub	x0, x19, #0x20
101702598: aa1403e2    	mov	x2, x20
10170259c: 97d1426d    	bl	0x100b52f50 <_sfv$cxxbridge1$199$decode_item+0x9e68c>
1017025a0: f9401e88    	ldr	x8, [x20, #0x38]
1017025a4: f90022e8    	str	x8, [x23, #0x40]
1017025a8: 17ffff6b    	b	0x101702354 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a88ac>
1017025ac: 9003e701    	adrp	x1, 0x1093e2000 <dyld_stub_binder+0x1093e2000>
1017025b0: 91343421    	add	x1, x1, #0xd0d
1017025b4: 910043e0    	add	x0, sp, #0x10
1017025b8: 97cdf472    	bl	0x100a7f780 <_rust_png$cxxbridge1$199$Reader$output_color_type+0xce224>
1017025bc: 9003e701    	adrp	x1, 0x1093e2000 <dyld_stub_binder+0x1093e2000>
1017025c0: 91346021    	add	x1, x1, #0xd18
1017025c4: 910043e0    	add	x0, sp, #0x10
1017025c8: 97cdf46e    	bl	0x100a7f780 <_rust_png$cxxbridge1$199$Reader$output_color_type+0xce224>
1017025cc: f9400fe8    	ldr	x8, [sp, #0x18]
1017025d0: 3940a109    	ldrb	w9, [x8, #0x28]
1017025d4: 36000aa9    	tbz	w9, #0x0, 0x101702728 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a8c80>
1017025d8: a9415514    	ldp	x20, x21, [x8, #0x10]
1017025dc: eb15029f    	cmp	x20, x21
1017025e0: 54ffec80    	b.eq	0x101702370 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a88c8>
1017025e4: f9400288    	ldr	x8, [x20]
1017025e8: b9400a81    	ldr	w1, [x20, #0x8]
1017025ec: f85f8260    	ldur	x0, [x19, #-0x8]
1017025f0: f9400809    	ldr	x9, [x0, #0x10]
1017025f4: 8b010129    	add	x9, x9, x1
1017025f8: b940092a    	ldr	w10, [x9, #0x8]
1017025fc: b90023ea    	str	w10, [sp, #0x20]
