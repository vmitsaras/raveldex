
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000101733544 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action>:
1017a22f0: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
1017a22f4: a9015ff8    	stp	x24, x23, [sp, #0x10]
1017a22f8: a90257f6    	stp	x22, x21, [sp, #0x20]
1017a22fc: a9034ff4    	stp	x20, x19, [sp, #0x30]
1017a2300: a9047bfd    	stp	x29, x30, [sp, #0x40]
1017a2304: 910103fd    	add	x29, sp, #0x40
1017a2308: aa0303f6    	mov	x22, x3
1017a230c: aa0203f5    	mov	x21, x2
1017a2310: aa0103f7    	mov	x23, x1
1017a2314: aa0003f4    	mov	x20, x0
1017a2318: aa0303e1    	mov	x1, x3
1017a231c: 97a3f506    	bl	0x10009f734 <_cxxbridge1$slice$new+0x59c58>
1017a2320: aa0003f3    	mov	x19, x0
1017a2324: f9404688    	ldr	x8, [x20, #0x88]
1017a2328: 926baae9    	and	x9, x23, #0xffffffffffe00000
1017a232c: 924052ea    	and	x10, x23, #0x1fffff
1017a2330: d0040c8b    	adrp	x11, 0x109934000 <dyld_stub_binder+0x109934000>
1017a2334: f940616b    	ldr	x11, [x11, #0xc0]
1017a2338: b980016b    	ldrsw	x11, [x11]
1017a233c: 9100096b    	add	x11, x11, #0x2
1017a2340: 9acb254a    	lsr	x10, x10, x11
1017a2344: 8b090108    	add	x8, x8, x9
1017a2348: 8b0a1508    	add	x8, x8, x10, lsl #5
1017a234c: 39407909    	ldrb	w9, [x8, #0x1e]
1017a2350: 92401529    	and	x9, x9, #0x3f
1017a2354: cb091508    	sub	x8, x8, x9, lsl #5
1017a2358: f9400908    	ldr	x8, [x8, #0x10]
1017a235c: b9401908    	ldr	w8, [x8, #0x18]
1017a2360: b9408298    	ldr	w24, [x20, #0x80]
1017a2364: cb180117    	sub	x23, x8, x24
1017a2368: eb17001f    	cmp	x0, x23
1017a236c: 540001a0    	b.eq	0x1017a23a0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ee5c>
1017a2370: eb17027f    	cmp	x19, x23
1017a2374: 1a9f17e0    	cset	w0, eq
1017a2378: a9447bfd    	ldp	x29, x30, [sp, #0x40]
1017a237c: a9434ff4    	ldp	x20, x19, [sp, #0x30]
1017a2380: a94257f6    	ldp	x22, x21, [sp, #0x20]
1017a2384: a9415ff8    	ldp	x24, x23, [sp, #0x10]
1017a2388: a8c567fa    	ldp	x26, x25, [sp], #0x50
1017a238c: d65f03c0    	ret
1017a2390: f94012b9    	ldr	x25, [x21, #0x20]
1017a2394: 8b1802c8    	add	x8, x22, x24
1017a2398: f90012a8    	str	x8, [x21, #0x20]
1017a239c: 14000005    	b	0x1017a23b0 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ee6c>
1017a23a0: b9401aa8    	ldr	w8, [x21, #0x18]
1017a23a4: 37ffff68    	tbnz	w8, #0x1f, 0x1017a2390 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ee4c>
1017a23a8: f9400aa8    	ldr	x8, [x21, #0x10]
1017a23ac: b9401919    	ldr	w25, [x8, #0x18]
1017a23b0: 39400688    	ldrb	w8, [x20, #0x1]
1017a23b4: 34fffde8    	cbz	w8, 0x1017a2370 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ee2c>
1017a23b8: f9400696    	ldr	x22, [x20, #0x8]
1017a23bc: f0044fe8    	adrp	x8, 0x10a1a1000 <dyld_stub_binder+0x10a1a1000>
1017a23c0: f9449500    	ldr	x0, [x8, #0x928]
1017a23c4: 95d2d788    	bl	0x108c581e4 <dyld_stub_binder+0x108c581e4>
1017a23c8: f100081f    	cmp	x0, #0x2
1017a23cc: 54000343    	b.lo	0x1017a2434 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eef0>
1017a23d0: 5280bc08    	mov	w8, #0x5e0              ; =1504
1017a23d4: 9b0802c0    	madd	x0, x22, x8, x0
1017a23d8: b40002e0    	cbz	x0, 0x1017a2434 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eef0>
1017a23dc: f9428408    	ldr	x8, [x0, #0x508]
1017a23e0: b40002a8    	cbz	x8, 0x1017a2434 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eef0>
1017a23e4: cb180328    	sub	x8, x25, x24
1017a23e8: 52800029    	mov	w9, #0x1                ; =1
1017a23ec: 4e080d20    	dup.2d	v0, x9
1017a23f0: 3cc78001    	ldur	q1, [x0, #0x78]
1017a23f4: 4e181d00    	mov.d	v0[1], x8
1017a23f8: 4ee18400    	add.2d	v0, v0, v1
1017a23fc: 3c878000    	stur	q0, [x0, #0x78]
1017a2400: b9401aa8    	ldr	w8, [x21, #0x18]
1017a2404: 37f80148    	tbnz	w8, #0x1f, 0x1017a242c <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eee8>
1017a2408: f9400aa8    	ldr	x8, [x21, #0x10]
1017a240c: b9401908    	ldr	w8, [x8, #0x18]
1017a2410: b9408289    	ldr	w9, [x20, #0x80]
1017a2414: a946ac0a    	ldp	x10, x11, [x0, #0x68]
1017a2418: 9100054a    	add	x10, x10, #0x1
1017a241c: cb090108    	sub	x8, x8, x9
1017a2420: 8b0b0108    	add	x8, x8, x11
1017a2424: a906a00a    	stp	x10, x8, [x0, #0x68]
1017a2428: 17ffffd2    	b	0x1017a2370 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ee2c>
1017a242c: f94012a8    	ldr	x8, [x21, #0x20]
1017a2430: 17fffff8    	b	0x1017a2410 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eecc>
1017a2434: aa1403e0    	mov	x0, x20
1017a2438: 97abd788    	bl	0x100298258 <_cxxbridge1$slice$new+0x25277c>
1017a243c: b4fff9a0    	cbz	x0, 0x1017a2370 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ee2c>
1017a2440: f9428408    	ldr	x8, [x0, #0x508]
1017a2444: b4fff968    	cbz	x8, 0x1017a2370 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6ee2c>
1017a2448: 17ffffe7    	b	0x1017a23e4 <_media$formats$mpeg$cxxbridge1$199$parse_mp3_action+0x6eea0>
1017a244c: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
