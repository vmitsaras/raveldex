
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100045adc <_cxxbridge1$slice$new>:
10009f734: f100043f    	cmp	x1, #0x1
10009f738: 9a9f8429    	csinc	x9, x1, xzr, hi
10009f73c: b9408008    	ldr	w8, [x0, #0x80]
10009f740: 8b080129    	add	x9, x9, x8
10009f744: 3940000a    	ldrb	w10, [x0]
10009f748: 3500046a    	cbnz	w10, 0x10009f7d4 <_cxxbridge1$slice$new+0x59cf8>
10009f74c: 12bffe0a    	mov	w10, #0xfffff           ; =1048575
10009f750: 8b0a012a    	add	x10, x9, x10
10009f754: d344fd4a    	lsr	x10, x10, #4
10009f758: f100013f    	cmp	x9, #0x0
10009f75c: 9a8a03ea    	csel	x10, xzr, x10, eq
10009f760: dac0112b    	clz	x11, x9
10009f764: 5280078c    	mov	w12, #0x3c              ; =60
10009f768: 4b0b018c    	sub	w12, w12, w11
10009f76c: 9acc2d2c    	ror	x12, x9, x12
10009f770: 9240098d    	and	x13, x12, #0x7
10009f774: cb0b0dab    	sub	x11, x13, x11, lsl #3
10009f778: f1003d9f    	cmp	x12, #0xf
10009f77c: 9a8b956b    	cinc	x11, x11, hi
10009f780: 91071d6b    	add	x11, x11, #0x1c7
10009f784: 52800dec    	mov	w12, #0x6f              ; =111
10009f788: f101bd7f    	cmp	x11, #0x6f
10009f78c: 9a8c316b    	csel	x11, x11, x12, lo
10009f790: f104053f    	cmp	x9, #0x101
10009f794: 9a8b314a    	csel	x10, x10, x11, lo
10009f798: 12003d4b    	and	w11, w10, #0xffff
10009f79c: f103fd3f    	cmp	x9, #0xff
10009f7a0: 52800dcc    	mov	w12, #0x6e              ; =110
10009f7a4: 7a4c8162    	ccmp	w11, w12, #0x2, hi
10009f7a8: 1a9f27eb    	cset	w11, lo
10009f7ac: aa0b014a    	orr	x10, x10, x11
10009f7b0: 92403d4a    	and	x10, x10, #0xffff
10009f7b4: 5280060b    	mov	w11, #0x30              ; =48
10009f7b8: 9bab014a    	umaddl	x10, w10, w11, x0
10009f7bc: 3944914b    	ldrb	w11, [x10, #0x124]
10009f7c0: 3400036b    	cbz	w11, 0x10009f82c <_cxxbridge1$slice$new+0x59d50>
10009f7c4: 91042149    	add	x9, x10, #0x108
10009f7c8: b9401929    	ldr	w9, [x9, #0x18]
10009f7cc: cb080120    	sub	x0, x9, x8
10009f7d0: d65f03c0    	ret
10009f7d4: 7100055f    	cmp	w10, #0x1
10009f7d8: 54000421    	b.ne	0x10009f85c <_cxxbridge1$slice$new+0x59d80>
10009f7dc: 12bffe0a    	mov	w10, #0xfffff           ; =1048575
10009f7e0: 8b0a012a    	add	x10, x9, x10
10009f7e4: d344fd4a    	lsr	x10, x10, #4
10009f7e8: f100013f    	cmp	x9, #0x0
10009f7ec: 9a8a03ea    	csel	x10, xzr, x10, eq
10009f7f0: dac0112b    	clz	x11, x9
10009f7f4: 5280078c    	mov	w12, #0x3c              ; =60
10009f7f8: 4b0b018c    	sub	w12, w12, w11
10009f7fc: 9acc2d2c    	ror	x12, x9, x12
10009f800: 9240098d    	and	x13, x12, #0x7
10009f804: cb0b0dab    	sub	x11, x13, x11, lsl #3
10009f808: f1003d9f    	cmp	x12, #0xf
10009f80c: 9a8b956b    	cinc	x11, x11, hi
10009f810: 91071d6b    	add	x11, x11, #0x1c7
10009f814: 52800dec    	mov	w12, #0x6f              ; =111
10009f818: f101bd7f    	cmp	x11, #0x6f
10009f81c: 9a8c316b    	csel	x11, x11, x12, lo
10009f820: f104053f    	cmp	x9, #0x101
10009f824: 9a8b314a    	csel	x10, x10, x11, lo
10009f828: 17ffffe2    	b	0x10009f7b0 <_cxxbridge1$slice$new+0x59cd4>
10009f82c: 52affc0a    	mov	w10, #0x7fe00000        ; =2145386496
10009f830: eb0a013f    	cmp	x9, x10
10009f834: 54000108    	b.hi	0x10009f854 <_cxxbridge1$slice$new+0x59d78>
10009f838: b004c4aa    	adrp	x10, 0x109934000 <dyld_stub_binder+0x109934000>
10009f83c: f940694a    	ldr	x10, [x10, #0xd0]
10009f840: f940014a    	ldr	x10, [x10]
10009f844: 8b0a0129    	add	x9, x9, x10
10009f848: d1000529    	sub	x9, x9, #0x1
10009f84c: cb0a03ea    	neg	x10, x10
10009f850: 8a0a0129    	and	x9, x9, x10
10009f854: cb080120    	sub	x0, x9, x8
10009f858: d65f03c0    	ret
10009f85c: d4200000    	brk	#0
10009f860: d4400000    	hlt	#0
10009f864: d4200020    	brk	#0x1
10009f868: aa0103e2    	mov	x2, x1
10009f86c: aa0003e1    	mov	x1, x0
10009f870: f0050d08    	adrp	x8, 0x10a242000 <dyld_stub_binder+0x10a242000>
10009f874: f946ed00    	ldr	x0, [x8, #0xdd8]
10009f878: 17fdf2bd    	b	0x10001c36c <__text+0x1836c>
10009f87c: 00000000    	udf	#0x0
