
/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000103c489e8 <__v8_internal_Print_TransitionTree>:
103de0300: b002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de0304: 911d2821    	add	x1, x1, #0x74a
103de0308: 14000006    	b	0x103de0320 <__v8_internal_Print_TransitionTree+0x197938>
103de030c: b002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de0310: 911e4021    	add	x1, x1, #0x790
103de0314: 14000003    	b	0x103de0320 <__v8_internal_Print_TransitionTree+0x197938>
103de0318: b002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de031c: 911c6c21    	add	x1, x1, #0x71b
103de0320: 528001e2    	mov	w2, #0xf                ; =15
103de0324: 17092437    	b	0x100029400 <__text+0x25400>
103de0328: 9002b261    	adrp	x1, 0x10942c000 <dyld_stub_binder+0x10942c000>
103de032c: 913c9c21    	add	x1, x1, #0xf27
103de0330: 14000009    	b	0x103de0354 <__v8_internal_Print_TransitionTree+0x19796c>
103de0334: 9002b261    	adrp	x1, 0x10942c000 <dyld_stub_binder+0x10942c000>
103de0338: 91396421    	add	x1, x1, #0xe59
103de033c: 14000006    	b	0x103de0354 <__v8_internal_Print_TransitionTree+0x19796c>
103de0340: b002b261    	adrp	x1, 0x10942d000 <dyld_stub_binder+0x10942d000>
103de0344: 91261821    	add	x1, x1, #0x986
103de0348: 14000003    	b	0x103de0354 <__v8_internal_Print_TransitionTree+0x19796c>
103de034c: b002b261    	adrp	x1, 0x10942d000 <dyld_stub_binder+0x10942d000>
103de0350: 91034c21    	add	x1, x1, #0xd3
103de0354: 528000c2    	mov	w2, #0x6                ; =6
103de0358: 1709242a    	b	0x100029400 <__text+0x25400>
103de035c: b002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de0360: 911d0421    	add	x1, x1, #0x741
103de0364: 14000003    	b	0x103de0370 <__v8_internal_Print_TransitionTree+0x197988>
103de0368: b002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de036c: 911db421    	add	x1, x1, #0x76d
103de0370: 52800102    	mov	w2, #0x8                ; =8
103de0374: 17092423    	b	0x100029400 <__text+0x25400>
103de0378: f002b281    	adrp	x1, 0x109433000 <dyld_stub_binder+0x109433000>
103de037c: 9100b421    	add	x1, x1, #0x2d
103de0380: 52800082    	mov	w2, #0x4                ; =4
103de0384: 1709241f    	b	0x100029400 <__text+0x25400>
103de0388: b002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de038c: 911dd821    	add	x1, x1, #0x776
103de0390: 52800322    	mov	w2, #0x19               ; =25
103de0394: 1709241b    	b	0x100029400 <__text+0x25400>
103de0398: b002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de039c: 911ba421    	add	x1, x1, #0x6e9
103de03a0: 52800162    	mov	w2, #0xb                ; =11
103de03a4: 17092417    	b	0x100029400 <__text+0x25400>
103de03a8: b002b2a1    	adrp	x1, 0x109435000 <dyld_stub_binder+0x109435000>
103de03ac: 911d6821    	add	x1, x1, #0x75a
103de03b0: 52800242    	mov	w2, #0x12               ; =18
103de03b4: 17092413    	b	0x100029400 <__text+0x25400>
103de03b8: f002b281    	adrp	x1, 0x109433000 <dyld_stub_binder+0x109433000>
103de03bc: 9100a421    	add	x1, x1, #0x29
103de03c0: 52800062    	mov	w2, #0x3                ; =3
103de03c4: 1709240f    	b	0x100029400 <__text+0x25400>
103de03c8: d4200000    	brk	#0
103de03cc: d4400000    	hlt	#0
103de03d0: d4200020    	brk	#0x1
103de03d4: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
103de03d8: a9017bfd    	stp	x29, x30, [sp, #0x10]
103de03dc: 910043fd    	add	x29, sp, #0x10
103de03e0: aa0003f3    	mov	x19, x0
103de03e4: f002dc08    	adrp	x8, 0x109963000 <dyld_stub_binder+0x109963000>
103de03e8: 910bc108    	add	x8, x8, #0x2f0
103de03ec: f9000008    	str	x8, [x0]
103de03f0: 975ab856    	bl	0x10148e548 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x634aa0>
103de03f4: f002dc28    	adrp	x8, 0x109967000 <dyld_stub_binder+0x109967000>
103de03f8: 910c0108    	add	x8, x8, #0x300
103de03fc: f9000268    	str	x8, [x19]
103de0400: aa1303e0    	mov	x0, x19
103de0404: a9417bfd    	ldp	x29, x30, [sp, #0x10]
103de0408: a8c24ff4    	ldp	x20, x19, [sp], #0x20
103de040c: d65f03c0    	ret
		...
103de0420: 6dbc23e9    	stp	d9, d8, [sp, #-0x40]!
103de0424: a90157f6    	stp	x22, x21, [sp, #0x10]
103de0428: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de042c: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de0430: 9100c3fd    	add	x29, sp, #0x30
103de0434: 4ea01c08    	mov.16b	v8, v0
103de0438: aa0003f3    	mov	x19, x0
103de043c: a941a014    	ldp	x20, x8, [x0, #0x18]
103de0440: 91002295    	add	x21, x20, #0x8
103de0444: eb0802bf    	cmp	x21, x8
103de0448: 54000128    	b.hi	0x103de046c <__v8_internal_Print_TransitionTree+0x197a84>
103de044c: f9000e75    	str	x21, [x19, #0x18]
103de0450: f9400a68    	ldr	x8, [x19, #0x10]
103de0454: fc346908    	str	d8, [x8, x20]
103de0458: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de045c: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de0460: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de0464: 6cc423e9    	ldp	d9, d8, [sp], #0x40
103de0468: d65f03c0    	ret
103de046c: 91002281    	add	x1, x20, #0x8
103de0470: aa1303e0    	mov	x0, x19
103de0474: 9764829f    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0478: 529fc028    	mov	w8, #0xfe01             ; =65025
103de047c: 6a08001f    	tst	w0, w8
103de0480: 54fffe61    	b.ne	0x103de044c <__v8_internal_Print_TransitionTree+0x197a64>
103de0484: 17fffff5    	b	0x103de0458 <__v8_internal_Print_TransitionTree+0x197a70>
103de0488: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
103de048c: a90157f6    	stp	x22, x21, [sp, #0x10]
103de0490: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de0494: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de0498: 9100c3fd    	add	x29, sp, #0x30
103de049c: d35ffc48    	lsr	x8, x2, #31
103de04a0: b5000428    	cbnz	x8, 0x103de0524 <__v8_internal_Print_TransitionTree+0x197b3c>
103de04a4: aa0203f5    	mov	x21, x2
103de04a8: aa0103f3    	mov	x19, x1
103de04ac: aa0003f4    	mov	x20, x0
103de04b0: 531f7aa1    	lsl	w1, w21, #1
103de04b4: 97490833    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de04b8: a941a297    	ldp	x23, x8, [x20, #0x18]
103de04bc: 8b1506f6    	add	x22, x23, x21, lsl #1
103de04c0: eb0802df    	cmp	x22, x8
103de04c4: 54000228    	b.hi	0x103de0508 <__v8_internal_Print_TransitionTree+0x197b20>
103de04c8: f9000e96    	str	x22, [x20, #0x18]
103de04cc: b4000155    	cbz	x21, 0x103de04f4 <__v8_internal_Print_TransitionTree+0x197b0c>
103de04d0: d37ffaa2    	lsl	x2, x21, #1
103de04d4: f9400a88    	ldr	x8, [x20, #0x10]
103de04d8: 8b170100    	add	x0, x8, x23
103de04dc: aa1303e1    	mov	x1, x19
103de04e0: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de04e4: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de04e8: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de04ec: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de04f0: 1539df2e    	b	0x108c581a8 <dyld_stub_binder+0x108c581a8>
103de04f4: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de04f8: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de04fc: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de0500: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de0504: d65f03c0    	ret
103de0508: aa1403e0    	mov	x0, x20
103de050c: aa1603e1    	mov	x1, x22
103de0510: 97648278    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0514: 529fc028    	mov	w8, #0xfe01             ; =65025
103de0518: 6a08001f    	tst	w0, w8
103de051c: 54fffd61    	b.ne	0x103de04c8 <__v8_internal_Print_TransitionTree+0x197ae0>
103de0520: 17fffff5    	b	0x103de04f4 <__v8_internal_Print_TransitionTree+0x197b0c>
103de0524: d4200000    	brk	#0
103de0528: d4400000    	hlt	#0
103de052c: d4200020    	brk	#0x1
103de0530: a9bc5ff8    	stp	x24, x23, [sp, #-0x40]!
103de0534: a90157f6    	stp	x22, x21, [sp, #0x10]
103de0538: a9024ff4    	stp	x20, x19, [sp, #0x20]
103de053c: a9037bfd    	stp	x29, x30, [sp, #0x30]
103de0540: 9100c3fd    	add	x29, sp, #0x30
103de0544: aa0003f4    	mov	x20, x0
103de0548: d1000433    	sub	x19, x1, #0x1
103de054c: aa1303e0    	mov	x0, x19
103de0550: 97fd6b6c    	bl	0x103d3b300 <__v8_internal_Print_TransitionTree+0xf2918>
103de0554: aa0003f6    	mov	x22, x0
103de0558: 97fd6b72    	bl	0x103d3b320 <__v8_internal_Print_TransitionTree+0xf2938>
103de055c: aa0003f5    	mov	x21, x0
103de0560: aa1403e0    	mov	x0, x20
103de0564: aa1603e1    	mov	x1, x22
103de0568: 97490806    	bl	0x101022580 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x1c8ad8>
103de056c: a941a296    	ldp	x22, x8, [x20, #0x18]
103de0570: 8b1502d7    	add	x23, x22, x21
103de0574: eb0802ff    	cmp	x23, x8
103de0578: 54000168    	b.hi	0x103de05a4 <__v8_internal_Print_TransitionTree+0x197bbc>
103de057c: f9000e97    	str	x23, [x20, #0x18]
103de0580: f9400a88    	ldr	x8, [x20, #0x10]
103de0584: 8b160101    	add	x1, x8, x22
103de0588: aa1303e0    	mov	x0, x19
103de058c: aa1503e2    	mov	x2, x21
103de0590: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de0594: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de0598: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de059c: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de05a0: 17fd6b62    	b	0x103d3b328 <__v8_internal_Print_TransitionTree+0xf2940>
103de05a4: 8b1502c1    	add	x1, x22, x21
103de05a8: aa1403e0    	mov	x0, x20
103de05ac: 97648251    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de05b0: 529fc028    	mov	w8, #0xfe01             ; =65025
103de05b4: 6a08001f    	tst	w0, w8
103de05b8: 54fffe21    	b.ne	0x103de057c <__v8_internal_Print_TransitionTree+0x197b94>
103de05bc: a9437bfd    	ldp	x29, x30, [sp, #0x30]
103de05c0: a9424ff4    	ldp	x20, x19, [sp, #0x20]
103de05c4: a94157f6    	ldp	x22, x21, [sp, #0x10]
103de05c8: a8c45ff8    	ldp	x24, x23, [sp], #0x40
103de05cc: d65f03c0    	ret
103de05d0: 14000004    	b	0x103de05e0 <__v8_internal_Print_TransitionTree+0x197bf8>
		...
103de05e0: d10143ff    	sub	sp, sp, #0x50
103de05e4: a90257f6    	stp	x22, x21, [sp, #0x20]
103de05e8: a9034ff4    	stp	x20, x19, [sp, #0x30]
103de05ec: a9047bfd    	stp	x29, x30, [sp, #0x40]
103de05f0: 910103fd    	add	x29, sp, #0x40
103de05f4: aa0003f4    	mov	x20, x0
103de05f8: d2800013    	mov	x19, #0x0               ; =0
103de05fc: 9002daa8    	adrp	x8, 0x109934000 <dyld_stub_binder+0x109934000>
103de0600: f9401108    	ldr	x8, [x8, #0x20]
103de0604: f9400108    	ldr	x8, [x8]
103de0608: f9000fe8    	str	x8, [sp, #0x18]
103de060c: 91003be8    	add	x8, sp, #0xe
103de0610: aa0103e9    	mov	x9, x1
103de0614: 3219002a    	orr	w10, w1, #0x80
103de0618: 3833690a    	strb	w10, [x8, x19]
103de061c: d347fc21    	lsr	x1, x1, #7
103de0620: 91000673    	add	x19, x19, #0x1
103de0624: b5ffff61    	cbnz	x1, 0x103de0610 <__v8_internal_Print_TransitionTree+0x197c28>
103de0628: 91003be8    	add	x8, sp, #0xe
103de062c: 8b130108    	add	x8, x8, x19
103de0630: 381ff109    	sturb	w9, [x8, #-0x1]
103de0634: a941a295    	ldp	x21, x8, [x20, #0x18]
103de0638: 8b1302b6    	add	x22, x21, x19
103de063c: eb0802df    	cmp	x22, x8
103de0640: 54000268    	b.hi	0x103de068c <__v8_internal_Print_TransitionTree+0x197ca4>
103de0644: f9000e96    	str	x22, [x20, #0x18]
103de0648: b40000d3    	cbz	x19, 0x103de0660 <__v8_internal_Print_TransitionTree+0x197c78>
103de064c: f9400a88    	ldr	x8, [x20, #0x10]
103de0650: 8b150100    	add	x0, x8, x21
103de0654: 91003be1    	add	x1, sp, #0xe
103de0658: aa1303e2    	mov	x2, x19
103de065c: 9539ded3    	bl	0x108c581a8 <dyld_stub_binder+0x108c581a8>
103de0660: f9400fe8    	ldr	x8, [sp, #0x18]
103de0664: 9002daa9    	adrp	x9, 0x109934000 <dyld_stub_binder+0x109934000>
103de0668: f9401129    	ldr	x9, [x9, #0x20]
103de066c: f9400129    	ldr	x9, [x9]
103de0670: eb08013f    	cmp	x9, x8
103de0674: 540001a1    	b.ne	0x103de06a8 <__v8_internal_Print_TransitionTree+0x197cc0>
103de0678: a9447bfd    	ldp	x29, x30, [sp, #0x40]
103de067c: a9434ff4    	ldp	x20, x19, [sp, #0x30]
103de0680: a94257f6    	ldp	x22, x21, [sp, #0x20]
103de0684: 910143ff    	add	sp, sp, #0x50
103de0688: d65f03c0    	ret
103de068c: 8b1302a1    	add	x1, x21, x19
103de0690: aa1403e0    	mov	x0, x20
103de0694: 97648217    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0698: 529fc028    	mov	w8, #0xfe01             ; =65025
103de069c: 6a08001f    	tst	w0, w8
103de06a0: 54fffd21    	b.ne	0x103de0644 <__v8_internal_Print_TransitionTree+0x197c5c>
103de06a4: 17ffffef    	b	0x103de0660 <__v8_internal_Print_TransitionTree+0x197c78>
103de06a8: 9539de93    	bl	0x108c580f4 <dyld_stub_binder+0x108c580f4>
103de06ac: 00000000    	udf	#0x0
103de06b0: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
103de06b4: a9017bfd    	stp	x29, x30, [sp, #0x10]
103de06b8: 910043fd    	add	x29, sp, #0x10
103de06bc: aa0103f3    	mov	x19, x1
103de06c0: f9400041    	ldr	x1, [x2]
103de06c4: 91030000    	add	x0, x0, #0xc0
103de06c8: 970dcb9e    	bl	0x100153540 <_cxxbridge1$slice$new+0x10da64>
103de06cc: b9000013    	str	w19, [x0]
103de06d0: a9417bfd    	ldp	x29, x30, [sp, #0x10]
103de06d4: a8c24ff4    	ldp	x20, x19, [sp], #0x20
103de06d8: d65f03c0    	ret
103de06dc: a9bd57f6    	stp	x22, x21, [sp, #-0x30]!
103de06e0: a9014ff4    	stp	x20, x19, [sp, #0x10]
103de06e4: a9027bfd    	stp	x29, x30, [sp, #0x20]
103de06e8: 910083fd    	add	x29, sp, #0x20
103de06ec: aa0103f3    	mov	x19, x1
103de06f0: aa0003f4    	mov	x20, x0
103de06f4: a941a015    	ldp	x21, x8, [x0, #0x18]
103de06f8: 910006b6    	add	x22, x21, #0x1
103de06fc: eb0802df    	cmp	x22, x8
103de0700: 54000168    	b.hi	0x103de072c <__v8_internal_Print_TransitionTree+0x197d44>
103de0704: f9000e96    	str	x22, [x20, #0x18]
103de0708: f9400a88    	ldr	x8, [x20, #0x10]
103de070c: 52800b49    	mov	w9, #0x5a               ; =90
103de0710: 38356909    	strb	w9, [x8, x21]
103de0714: aa1403e0    	mov	x0, x20
103de0718: aa1303e1    	mov	x1, x19
103de071c: a9427bfd    	ldp	x29, x30, [sp, #0x20]
103de0720: a9414ff4    	ldp	x20, x19, [sp, #0x10]
103de0724: a8c357f6    	ldp	x22, x21, [sp], #0x30
103de0728: 17ffff82    	b	0x103de0530 <__v8_internal_Print_TransitionTree+0x197b48>
103de072c: 910006a1    	add	x1, x21, #0x1
103de0730: aa1403e0    	mov	x0, x20
103de0734: 976481ef    	bl	0x101700ef0 <_fontations_ffi$cxxbridge1$199$num_color_stops+0x8a7448>
103de0738: 529fc028    	mov	w8, #0xfe01             ; =65025
103de073c: 6a08001f    	tst	w0, w8
103de0740: 54fffe21    	b.ne	0x103de0704 <__v8_internal_Print_TransitionTree+0x197d1c>
103de0744: 17fffff4    	b	0x103de0714 <__v8_internal_Print_TransitionTree+0x197d2c>
103de0748: d100c3ff    	sub	sp, sp, #0x30
103de074c: a9014ff4    	stp	x20, x19, [sp, #0x10]
