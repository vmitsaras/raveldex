import json,sys,types,tempfile,unittest
from pathlib import Path
import test_observer as old
from test_observer import Frame
from audit_tap import audit

class CopyRoutes(unittest.TestCase):
    def setUp(self):
        old.ObserverTests.setUp(self);self.tap.BASE=0x100000000;self.tap.ACTIVE=True
        self.tap.FRAME=dict(pc=self.tap.BASE+4,sp=8000,lr=self.tap.BASE+8,fp=8032,moduleOffset=4)
        self.tap.add(1000,216,1,'realloc',91)
        self.tap.ROLES[self.tap.BASE+0x17009b8]='payload-onebyte'
        self.tap.ROLES[self.tap.BASE+0x3de04f0]='payload-twobyte'
    def copy(self,site=0x17009b8,length=100,dest=1012,src=2000):
        self.tap.callback(Frame(self.tap.BASE+site,8000,self.tap.BASE+9999,x0=dest,x1=src,x2=length),None,None)
    def finish(self,pc=0x100000000+0x17009bc,sp=8000,x0=1012):
        self.tap.callback(Frame(pc,sp,pc,x0=x0),None,None)
    def record(self):
        return dict(schema='raveldex-lldb-buffer-observation-v2',pid=1234,dropped=self.tap.DROPPED,invalid=self.tap.INVALID,pending={str(k):v for k,v in self.tap.CALLS.items() if v},rows=self.tap.ROWS,bindings={},remaining={str(k):v for k,v in self.tap.LIVE.items()})
    def audited(self,record):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as t:
            p=Path(t)/'record.json';p.write_text(json.dumps(record));return audit(p)
    def test_onebyte_actual_copy_frame_shape(self):
        self.copy();self.finish();result=self.audited(self.record())
        self.assertEqual(result['selectedStringCopyBytes'],100);self.assertEqual(result['selectedStringCopyCalls'],1)
    def test_twobyte_tail_uses_original_lr_sp(self):
        self.copy(0x3de04f0,length=200);self.finish(self.tap.BASE+9999)
        self.assertEqual(self.tap.INVALID,[]);self.assertEqual(self.tap.CALLS[91],[])
        self.assertEqual(self.audited(self.record())['selectedStringCopyBytes'],200)
    def test_overflow_rejected(self):
        self.copy(length=205);self.assertIn('payload_extent_invalid',self.tap.INVALID)
    def test_zero_source_rejected(self):
        self.copy(src=0);self.assertIn('payload_extent_invalid',self.tap.INVALID)
    def test_untracked_destination_excluded(self):
        self.copy(dest=5000);self.assertFalse(any(r['kind']=='payload-copy-enter' for r in self.tap.ROWS))
    def test_wrong_sp_keeps_pending(self):
        self.copy();self.finish(sp=7990);self.assertEqual(len(self.tap.CALLS[91]),1)
    def test_generation_reuse_rejected(self):
        self.copy();self.tap.LIVE[1000]['allocation']=2;self.finish();self.assertIn('payload_generation_mismatch',self.tap.INVALID)
    def test_return_destination_rejected(self):
        self.copy();self.finish(x0=1013);self.assertIn('payload_return_not_destination',self.tap.INVALID)
    def test_raw_replay_rejects_extent_site_and_return_tampering(self):
        self.copy();self.finish();original=self.record()
        for key,value,kind in [('length',99,'payload-copy-enter'),('length',1000,'payload-copy-enter'),('site',0x17009bc,'payload-copy-enter'),('returned',999,'payload-copy-return'),('allocation',999,'payload-copy-return')]:
            row=json.loads(json.dumps(original));next(r for r in row['rows'] if r['kind']==kind)[key]=value
            with self.subTest(key=key),self.assertRaises(AssertionError):self.audited(row)

if __name__=='__main__':unittest.main(verbosity=2)
