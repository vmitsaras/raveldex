"""Finite host for an explicitly owned renderer; no browser launch."""
import argparse
import json
import os
from pathlib import Path
import pty
import select
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--config',required=True)
parser.add_argument('--timeout',type=int,default=600)
args=parser.parse_args()
config_path=Path(args.config).resolve()
assert config_path.is_relative_to(ROOT) and 30<=args.timeout<=900
config=json.loads(config_path.read_text())
output=Path(config['output']).resolve()
assert output.is_relative_to(ROOT)
output.mkdir(exist_ok=True)
command=['/Library/Developer/CommandLineTools/usr/bin/lldb','--no-lldbinit','-p',str(config['pid']),
         '-o','command script import '+str(ROOT/'lldb_native_tap.py'),
         '-o','rx-install '+str(config_path)]
master,slave=pty.openpty()
started=time.monotonic();timed_out=False;deadline=None;input_open=True
child=subprocess.Popen(command,stdin=slave,stdout=slave,stderr=slave,start_new_session=True)
os.close(slave)
record=dict(schema='raveldex-bounded-lldb-host-v2',ownedDebuggerPid=child.pid,targetPid=config['pid'],
            command=command,timeoutSeconds=args.timeout,startedUnix=time.time())
log=(output/'lldb-observer.log').open('xb')


def interrupt(signum=None,frame=None):
    try:os.killpg(child.pid,signal.SIGINT)
    except ProcessLookupError:pass


def close_commands():
    interrupt()
    os.write(master,b'rx-cleanup\nprocess detach\nquit\n')


signal.signal(signal.SIGINT,interrupt)
try:
    while child.poll() is None:
        now=time.monotonic()
        if not timed_out and now-started>args.timeout:
            timed_out=True;deadline=now+12;close_commands()
        if deadline is not None and now>deadline:
            os.killpg(child.pid,signal.SIGTERM);break
        watched=[master]+([sys.stdin] if input_open else [])
        ready,_,_=select.select(watched,[],[],.2)
        if master in ready:
            try:data=os.read(master,65536)
            except OSError:data=b''
            if data:log.write(data);log.flush();os.write(sys.stdout.fileno(),data)
        if input_open and sys.stdin in ready:
            data=os.read(sys.stdin.fileno(),4096)
            if not data:
                input_open=False;deadline=time.monotonic()+12;close_commands()
            else:os.write(master,data)
    child.wait(timeout=8)
finally:
    if child.poll() is None:
        os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
    record.update(exitCode=child.returncode,timedOut=timed_out,finishedUnix=time.time())
    log.close();os.close(master)
    with (output/'lldb-observer-host.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
