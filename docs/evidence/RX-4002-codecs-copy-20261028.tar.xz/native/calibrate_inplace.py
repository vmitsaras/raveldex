"""Explicit debugger-only native control. Import registers a command; does NOT run it.
Requires parent authorization, installed observer, paused trace-proven owned renderer.
Never changes a product pointer. Allocates one separate native block, grows its
requested extent by one byte within the independently queried same size class,
then frees it. Real LLDB/allocator execution remains UNRUN in candidate.
"""
import hashlib,json,pathlib
import lldb
import lldb_native_tap as rx
ROOT=pathlib.Path(__file__).resolve().parent

def qualify(rows,ptr,old,new):
    assert len([r for r in rows if r['kind']=='buffer-live' and r['ptr']==ptr and r['cap']==old])==1
    rets=[r for r in rows if r['kind']=='realloc-return']
    assert len(rets)==1 and rets[0]['old']==rets[0]['dest']==ptr and rets[0]['cap']==new
    resize=[r for r in rows if r['kind']=='buffer-resize']
    assert len(resize)==1 and resize[0]['ptr']==ptr and resize[0]['cap']==new
    assert not any(r['kind'] in ('copy-enter','api-only-retirement') for r in rows)
    frees=[r for r in rows if r['kind']=='root-free-return']
    assert len(frees)==1 and frees[0]['ptr']==ptr and frees[0]['cap']==new
    assert frees[0]['allocation']==resize[0]['allocation']
    return dict(realNativeAllocation=True,oldRequested=old,newRequested=new,ptr=ptr,unchangedPointer=True,selectedGrowthCopies=0,successfulFinalRootFree=True)

def run(debugger,command,result,internal_dict):
    current=None;uncertain=False;receipt=dict(schema='raveldex-explicit-inplace-calibration-v1',outcome='Running',nativeCalls=[])
    path=None
    try:
        if command.strip()!='execute-owned-native-control':raise RuntimeError('Explicit execute-owned-native-control argument required')
        if not rx.INSTALLED or not rx.ACTIVE or rx.INVALID or rx.DROPPED:raise RuntimeError('Observer not valid and active')
        if any(rx.CALLS.values()) or rx.LIVE:raise RuntimeError('Requires drained idle observer')
        if rx.LABEL!='inplace-control':raise RuntimeError('Requires separate inplace-control window')
        process=rx.TARGET.GetProcess()
        if process.GetProcessID()!=rx.CONFIG['pid'] or process.GetState()!=lldb.eStateStopped:raise RuntimeError('Wrong owned paused process')
        thread=process.GetSelectedThread()
        if thread.GetThreadID()!=rx.CONFIG['mainTid']:raise RuntimeError('Select trace-proven main thread')
        roots={r['root'] for r in rx.ROWS if r['kind']=='realloc-enter'}
        if len(roots)!=1:raise RuntimeError('Requires one real observed serializer allocator root')
        root=roots.pop();base=rx.BASE;typeptr=rx.TYPE
        if not root or typeptr!=base+0x974695b:raise RuntimeError('Invalid observed allocator identity')
        path=rx.OUT/'inplace-calibration.json'
        if path.exists():raise RuntimeError('Existing receipt preserved')
        receipt.update(pid=process.GetProcessID(),tid=thread.GetThreadID(),base=base,root=root,typePointer=typeptr,observerSha256=hashlib.sha256((ROOT/'lldb_native_tap.py').read_bytes()).hexdigest())
        start=len(rx.ROWS);frame=thread.GetFrameAtIndex(0)
        options=lldb.SBExpressionOptions();options.SetLanguage(lldb.eLanguageTypeC_plus_plus);options.SetIgnoreBreakpoints(False);options.SetUnwindOnError(True);options.SetTimeoutInMicroSeconds(5000000);options.SetTryAllThreads(False);options.SetStopOthers(True)
        def native(offset,signature,args):
            nonlocal uncertain
            expression='((%s)(unsigned long)%d)(%s)'%(signature,base+offset,','.join('(unsigned long)%d'%arg for arg in args))
            uncertain=True;value=frame.EvaluateExpression(expression,options)
            if not value.IsValid() or value.GetError().Fail():raise RuntimeError('Native expression incomplete; close owned renderer without guessing cleanup: '+value.GetError().GetCString())
            answer=value.GetValueAsUnsigned();uncertain=False;receipt['nativeCalls'].append(dict(offset=hex(offset),expression=expression,result=answer));return answer
        # Size-class equality is observed first. No assumed bucket boundary.
        qold=native(0x9f734,'unsigned long(*)(unsigned long,unsigned long)',[root,129])
        qnew=native(0x9f734,'unsigned long(*)(unsigned long,unsigned long)',[root,130])
        receipt.update(quantizedOld=qold,quantizedNew=qnew)
        if qold!=qnew or not 130<=qold<=4096:raise RuntimeError('129/130 do not share admitted observed size class')
        current=native(0x1c36c,'unsigned long(*)(unsigned long,unsigned long,unsigned long)',[root,129,typeptr])
        if not current or current not in rx.LIVE or rx.LIVE[current]['cap']!=129:raise RuntimeError('Allocation not independently observed')
        ptr=current;newptr=native(0x17a1190,'unsigned long(*)(unsigned long,unsigned long,unsigned long,unsigned long)',[root,current,130,typeptr])
        if newptr:current=newptr
        else:raise RuntimeError('Reallocate failed; original control block remains owned')
        # Regardless of moved/in-place result, release only successful returned block.
        native(0x1d6d0,'void(*)(unsigned long,unsigned long)',[root,current]);current=None
        if rx.INVALID or rx.DROPPED or any(rx.CALLS.values()) or rx.LIVE:raise RuntimeError('Observer invalid or not drained')
        receipt['checks']=qualify(rx.ROWS[start:],ptr,129,130);receipt['outcome']='Pass'
    except Exception as error:
        receipt['outcome']='Refused';receipt['reason']=str(error)
        if current is not None:
            receipt['unreleasedControlPointer']=current
            receipt['cleanup']='Close the task-owned renderer; no guessed native free after refusal or uncertain expression.'
        receipt['expressionStateUncertain']=uncertain
    if path is not None:
        with path.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
    if receipt['outcome']=='Pass':result.PutCString(json.dumps(receipt))
    else:result.SetError(json.dumps(receipt))

def __lldb_init_module(debugger,internal_dict):
    debugger.HandleCommand('command script add -f calibrate_inplace.run rx-calibrate-inplace')
