"""Static file reads only; no launch or attach. Verify every inherited fingerprint."""
import hashlib,json,struct
from pathlib import Path
R=Path(__file__).resolve().parent
old=Path('/tmp/raveldex-ac03-gc-message-20261028.qQls0e/browser/hook-manifest.json')
m=json.loads(old.read_text()); b=Path(m['binary']).read_bytes()
assert hashlib.sha256(b).hexdigest()==m['sha256']
for s in m['sites'].values():
 o=int(s['file_offset'],16);assert b[o:o+s['size']].hex()==s['bytes_hex']
for name,o,n in [('v8_write_string',0x1700818,0x58c),('v8_onebyte_copy',0x17009a0,32),('v8_twobyte_write',0x3de0488,168),('v8_twobyte_copy_tail',0x3de04d0,36),('pa_inplace',0x17a22f0,0x160),('pa_quantize',0x9f734,0x134),('memcpy_stub',0x8c581a8,12)]:
 raw=b[o:o+n];m['sites'][name]=dict(module_offset=hex(o),file_offset=hex(o),size=n,bytes_hex=raw.hex(),sha256=hashlib.sha256(raw).hexdigest(),status='byte_verified_static_candidate_runtime_unrun')
def target(o):
 i=struct.unpack_from('<I',b,o)[0];assert i&0x7c000000==0x14000000
 v=i&0x3ffffff;v=v-(1<<26) if v&(1<<25) else v
 return o+4*v
assert target(0x17009b8)==target(0x3de04f0)==0x8c581a8
assert target(0x1700c28)==0x3de0488
m['copyRoutes']=[dict(role='payload-onebyte',offset='0x17009b8',returnOffset='0x17009bc',destination='x0',source='x1',bytes='x2',mechanism='BL memcpy; WriteString one-byte path'),dict(role='payload-twobyte',offset='0x3de04f0',returnOffset=None,destination='x0',source='x1',bytes='x2',mechanism='tail B memcpy after epilogue; original LR/SP')]
m['priorManifestSha256']=hashlib.sha256(old.read_bytes()).hexdigest()
m['newSourceFiles']={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted((R/'sources').iterdir()) if p.is_file()}
(R/'hook-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps(dict(binary=m['binary'],sha256=m['sha256'],uuid=m['uuid'],sites=len(m['sites']),routes=m['copyRoutes'])))
