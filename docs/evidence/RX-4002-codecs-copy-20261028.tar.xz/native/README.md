# Native sender string-copy candidate and in-place control preparation

2026-10-28. **Static/mock candidate only; no browser launch, attach or target native call executed by this agent.** Writes are confined to this directory. Existing evidence and repo sources are unchanged by this agent. Parent owns runtime approval, execution, integration and independent review.

## Bound identity and evidence

Cached HeadlessChrome 153.0.8010.12 binary:
`/Users/vasilis/Library/Caches/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-mac-arm64/chrome-headless-shell`
SHA-256 `a0bfe7b4da4787b66058477d696cd1d09065d25f06a548947722b9af77ee8282`, Mach-O UUID `4C4C44C1-5555-3144-A1ED-87C8CC00F9E6`.

The parent’s executed prior tap identifies realloc return anchors module+`0x1700994`, `0x1700f2c`, `0x7865e8`. Bounded objdump inspection around the first two reveals the V8 serializer layout: buffer+16, written size+24, capacity+32. The existing observed PA root/type allocation path is reproduced in the inlined one-byte string-growth path. These anchors, constant one-byte tag `0x22`, two-byte tag `0x63`, length varints, reserve logic, source vector and exact memcpy calls jointly bind the candidate to pinned V8 source. Nearest exported symbol names are unrelated stripped-binary names; they are not used as function identity.

`prepare_manifest.py` independently verifies the whole binary and all 13 inherited code fingerprints, records seven additional bounded byte fingerprints, and checks exact branch targets. `hook-manifest.json` has 20 fingerprints. Installation rechecks all bytes against the selected owned PID before creating hooks. `asm/` contains bounded disassembly only; no full-image disassembly is required.

Authoritative reused V8 source is `sources/value-serializer-raw.cc`, SHA-256 `a28244f32f86defba4542ca871bff53bbdd6abc2c0f6f6203d1053d65cfe3e36`. Origin is the [Chromium DEPS-pinned V8 commit](https://chromium.googlesource.com/v8/v8/+/0b60d2b01800d7ba2c6eeb5e51ecd95f6dab44c7/src/objects/value-serializer.cc). Original official fetch provenance is preserved at `sources/source-fetch-provenance.json`. No new network fetch was needed. Relevant lines: WriteOneByteString 395–398; WriteTwoByteString 400–404; WriteRawBytes 416–420; ExpandBuffer 436–460; WriteString 581–602; receiving string creation 1846–1885.

## Candidate routes

| Route | Exact executable site | Registers | Native return rule |
| --- | --- | --- | --- |
| One-byte string content | module+`0x17009b8` BL to imported `_memcpy` stub +`0x8c581a8` | dest x0, source x1, bytes x2 | module+`0x17009bc`, same SP |
| Two-byte string content | module+`0x3de04f0` tail B to same stub | dest x0, source x1, bytes x2 (chars × 2) | original LR, restored caller SP |

`lldb_native_tap.py` retains all original lifetime/metadata guards and adds only these two selected copy hooks. It records source/destination pointers and byte count; no string content is read. A destination must lie in exactly one live tracked allocation, the full write extent must fit its requested capacity and remain within the 64 MiB observer bound, and the returned allocation generation and memcpy result must match. Source snapshot JSON appears as a single primitive string; this candidate can observe its direct sender write without consuming the value. Metadata strings are also counted. Raw rows retain call ID, parent ID, PC, LR and SP.

`audit_tap.py` additionally links each selected copy-enter row to its exact native call begin, checks site-specific return rules and verifies the destination birth at return. It reports selectedStringCopyCalls/Bytes separately from growth copies. These are **selected string contents**, not all wire stores or all transport copies. The original cumulative raw tap remains replayable with zero selected string-copy rows, as expected from its older hook set.

## Explicit in-place control — proposed, unrun

`calibrate_inplace.py` registers `rx-calibrate-inplace` on import and runs only with the explicit command argument below. It requires an installed/armed valid observer, no pending calls/live buffers, label `inplace-control`, a paused owned PID, the trace-proven selected main thread, and exactly one allocator root previously observed from real messages. It uses no stale prior-run root or browser PID.

After parent review and an approved fresh owned controller/LLDB session, observe and GC-drain a small actual message first, then select its trace-proven main thread:

```text
rx-begin inplace-control
command script import /tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/native/calibrate_inplace.py
rx-calibrate-inplace execute-owned-native-control
rx-end
```

The existing bounded host invocation remains:

```sh
python3 /tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/native/bounded-lldb.py --config /tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/native/ACTUAL-OWNED-config.json --timeout 600
```

`ACTUAL-OWNED-config.json` is intentionally absent until a fresh controller supplies the PID, main/worker TIDs and peer. Do not substitute old identities. Output must be a new child directory under this native directory. This command **attaches** and is a future parent runtime step, not executed preparation evidence.

The control executes at most five native calls via LLDB expressions: quantize 129 and 130 using the observed allocator root at module+`0x9f734`; refuse before allocating unless results are equal, at least 130 and no more than 4,096; allocate one separate 129-byte requested buffer through observed typed allocator +`0x1c36c`; reallocate only that control pointer to 130 through observed shared +`0x17a1190`; free only the successful returned control pointer via observed root-free +`0x1d6d0`. No production pointer or argument is changed. Quantizer bytes and in-place comparison body +`0x17a22f0` are fingerprinted from the binary.

Acceptance requires actual same-pointer realloc-return, one resize retaining the birth ID, no growth copy/API-only retirement and a successful matching root-free return, followed by no pending/live state. A moved allocation is cleaned through its successful returned pointer but refuses in-place qualification. Call failure, timeout or uncertain expression state refuses qualification; any unreleased control allocation is explicitly recorded and parent closes the owned renderer, without guessed frees. Each expression has a five-second timeout, stops other threads and refuses trying all threads. This may fail if a stopped thread holds a required allocator lock. The raw observer trace must also pass independent frame replay; the calibration receipt alone is insufficient.

This is an actual allocator **requested extent growth** control if it executes successfully. It does not prove that naturally doubling serializer capacity requests exercise the same in-place branch in product messages. LLDB expression compilation/execution is an explicit extra measurement perturbation. Existing observer itself remains free of target calls.

## Offline checks actually run

- `prepare_manifest.py`: whole binary hash, 20 fingerprints, one/two-byte branch destinations: Pass.
- `test_observer.py`: 16/16 inherited prefix/lifetime/exhaustion/tamper cases: Pass.
- `test_copy_routes.py`: 9/9 literal frame/extent/source/generation/return/tamper cases: Pass.
- `test_inplace.py`: 10/10 literal same-pointer acceptance, moved/copy/stale/missing-witness refusal and explicit-command/observer/pending/live/window preflight cases: Pass.
- LLDB no-target API introspection: the six used SBExpressionOptions methods exist in installed CLT LLDB; **no target attached**. Actual evaluation behavior is unverified.
- Final observer compile/import syntax and legacy raw replay: recorded in final-checks.json.

All Python commands use `PYTHONPYCACHEPREFIX` under this directory. First new-test attempt had test-harness inheritance/frame setup defects, preserved at `test-copy.log`; corrected fixtures pass at `test-copy-fixed.log` and stricter review pass at `test-copy-reviewed.log`. No product/runtime behavior is inferred from those fixture defects.

## Remaining uncertainties and limits

- No new hook has run in a real renderer. The tail-copy SP/LR model is statically supported and mock-tested, not live-calibrated.
- Full sender payload coverage requires live expected string-length checks for ASCII, Latin-1, two-byte and empty controls, plus product snapshot string lengths. A site hit or sum alone cannot establish missing-route absence.
- Receiver `ReadOneByteString` calls factory `NewStringFromOneByte`; two-byte deserialization may narrow to one-byte representation and must be traced/calibrated separately. These receiver copies are not covered here.
- Blink shared cross-thread SSV handoff may avoid a wire-buffer copy, but this candidate does not claim absence of every IPC/shared/alternate receive route. The existing SSV create-from-span candidate remains uncalibrated.
- Inline varint/tag/double stores and buffer/host-object payloads remain outside selected string-content counts. Unsupported payload kinds must not be silently added to a complete-payload claim.
- No physical/process-memory total, every-VM-byte attribution, latency claim or complete AC03 qualification follows. The 1,000/10,000 product message matrix is a separate parent step.
- REA inventory found no active target; Ghidra is unconfigured and Hopper would open UI. No provider/app/config change was made. Existing native objdump plus direct byte reads supplied this bounded analysis.
