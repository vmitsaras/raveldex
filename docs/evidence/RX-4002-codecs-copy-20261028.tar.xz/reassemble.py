"""After separately verifying/extracting each raw archive, reconstruct NEW streams.
Usage: python3 reassemble.py PARTS_PARENT NEW_OUTPUT
Extract each raw archive into PARTS_PARENT/<archive name without .tar.xz>.
The adjacent raw-index.json binds every part and reconstructed raw file.
"""
import hashlib,json,pathlib,sys
base=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]).resolve()
index=json.loads(pathlib.Path(__file__).with_name('raw-index.json').read_text())
def safe(name):
 p=pathlib.PurePosixPath(name)
 assert name and not p.is_absolute() and '\\' not in name and all(x not in ('','.','..') for x in name.split('/'))
 return p
assert index['schema']=='raveldex-raw-parts-v1' and len(index['streams'])<=64
assert sum(x['bytes'] for x in index['streams'])<=4*1024**3
out.mkdir(mode=0o700)
results=[]
for row in index['streams']:
 assert row['bytes']<=2048*1024**2 and len(row['parts'])<=32
 target=out.joinpath(*safe(row['name']).parts);target.parent.mkdir(parents=True,exist_ok=True);full=hashlib.sha256();total=0
 with target.open('xb') as dest:
  for part in row['parts']:
   assert part['offset']==total and 0<part['bytes']<=128*1024**2
   archive=safe(part['archive']);assert len(archive.parts)==1 and archive.name.endswith('.tar.xz')
   source=base/archive.name[:-7]/safe(part['name']);digest=hashlib.sha256();n=0
   with source.open('rb') as f:
    for b in iter(lambda:f.read(1048576),b''):
     n+=len(b);assert n<=part['bytes'];digest.update(b);full.update(b);dest.write(b)
   assert n==part['bytes'] and digest.hexdigest()==part['sha256'];total+=n
 assert total==row['bytes'] and full.hexdigest()==row['sha256']
 results.append(dict(name=row['name'],bytes=total,sha256=full.hexdigest(),outcome='Exact raw bytes reconstructed; numerical replay is separate'))
print(json.dumps(results,indent=2))
