import hashlib,json,pathlib,struct
root=pathlib.Path('/tmp/raveldex-ac03-codecs-copy-20261028.AngUjn/native');out=pathlib.Path(__file__).parent
m=json.loads((root/'hook-manifest.json').read_text());binary=pathlib.Path(m['binary']);h=hashlib.sha256()
with binary.open('rb') as f:
 for c in iter(lambda:f.read(1048576),b''):h.update(c)
 assert h.hexdigest()==m['sha256']
 for n,s in m['sites'].items():
  f.seek(int(s['file_offset'],16));raw=f.read(s['size']);assert raw.hex()==s['bytes_hex'],n;assert hashlib.sha256(raw).hexdigest()==s['sha256'],n
 def branch(o):
  f.seek(o);i=struct.unpack('<I',f.read(4))[0];assert i&0x7c000000==0x14000000
  v=i&0x3ffffff;v=v-(1<<26) if v&(1<<25) else v
  return dict(offset=hex(o),instruction=hex(i),branchTarget=hex(o+4*v),link=bool(i&(1<<31)))
 branches=[branch(o) for o in (0x17009b8,0x3de04f0,0x1700c28)]
 assert branches[0]['branchTarget']==branches[1]['branchTarget']=='0x8c581a8'
 assert branches[0]['link'] and not branches[1]['link']
 assert branches[2]['branchTarget']=='0x3de0488'
files=['lldb_native_tap.py','audit_tap.py','calibrate_inplace.py','README.md','hook-manifest.json','test_copy_routes.py','test_inplace.py','bounded-lldb.py']
result=dict(binary=dict(path=str(binary),sha256=h.hexdigest()),fingerprintsVerified=len(m['sites']),branches=branches,reviewedFiles={n:dict(bytes=(root/n).stat().st_size,sha256=hashlib.sha256((root/n).read_bytes()).hexdigest()) for n in files},targetExecuted=False,attached=False)
(out/'static-review-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(fingerprints=result['fingerprintsVerified'],branches=branches,targetExecuted=False)))
