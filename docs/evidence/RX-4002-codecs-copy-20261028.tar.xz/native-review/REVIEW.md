# Independent native preflight review — 2026-10-28

Outcome: **No blocking defect found for the proposed finite calibration in a fresh, explicitly owned cached-Chromium renderer.** This is preflight readiness only. Neither new copy route nor the in-place control has been executed by this reviewer. Acceptance still requires actual raw entry/return observations, exact expected control string lengths, independent replay, and cleanup evidence.

Reviewed candidate source: `native/lldb_native_tap.py`, `audit_tap.py`, `calibrate_inplace.py`, `README.md`, manifest, bounded host, and copy/in-place fixtures. Exact reviewed hashes and independent static verification are in `static-review-checks.json`. No target launch, attach, target-native call, app/settings/security change, candidate mutation or further delegation occurred. All reviewer writes are confined to `native-review/`.

## Source and instruction evidence

- Independently streamed the cached executable hash and compared all 20 manifest byte ranges plus each range digest. Pass. This binds the static assembly to executable SHA-256 `a0bfe7b4da4787b66058477d696cd1d09065d25f06a548947722b9af77ee8282`.
- Independently decoded the actual ARM64 branch instructions: `+0x17009b8` is BL to `+0x8c581a8`; `+0x3de04f0` is B to that same memcpy stub; the caller at `+0x1700c28` is BL to `+0x3de0488`.
- The two-byte epilogue restores x29/x30 at `+0x3de04e0` and restores caller SP by postincrement 0x40 at `+0x3de04ec`, before the tail B. At the selected hook, original LR and current already-restored SP are the appropriate memcpy return PC/SP. The observer records those and waits for exact PC/SP. The replay checks entry PC/SP/LR, site, expected original-LR return, and returned memcpy destination. One-byte BL instead requires `+0x17009bc` with unchanged SP. No extra SP adjustment should be introduced for the two-byte tail hook.
- Quantizer assembly reads root fields from x0 and requested bytes from x1. Its `(root,size)` call signature matches this source. The in-place body at `+0x17a22f0` itself invokes this quantizer and compares the result to the existing allocation slot size. Equality for 129/130 is queried live before allocating; no bucket boundary is assumed from size alone.

## Ownership, arguments, lifetimes and finiteness

The native control checks explicit command argument, armed valid observer, no dropped rows, empty pending/live registries, separate `inplace-control` window, selected stopped process PID matching supplied owned configuration, selected trace-proven main TID, one allocator root observed in prior real serializer realloc rows, and the fixed typed-allocation string identity.

It then performs at most five calls: quantize 129, quantize 130, typed allocate 129, reallocate the returned control pointer to 130, free only the successful returned control pointer. The root is selected from this observer run rather than a stale constant. No existing product buffer address is passed to reallocation/free. The control guards equal quantized sizes in [130,4096] before allocation. Realloc motion remains a refused in-place result even if its returned new block is safely freed.

Each expression is bounded to five seconds, declines trying other threads, stops other threads and enables observer breakpoints. Native-expression reentry, allocator lock contention and LLDB behavior are real unresolved runtime uncertainties; these settings can refuse execution. Any incomplete expression requires closing the owned renderer, without guessed native cleanup. The host is separately bounded (30–900 seconds; proposed 600) and attempts hook removal/detach before escalation against its own debugger process. The parent must independently ensure the renderer/controller is closed when the control receipt refuses or is uncertain; the host alone owns debugger cleanup.

Observer live allocation births distinguish address reuse. Selected copy destinations must fit exactly one tracked requested allocation extent; source pointers and byte lengths are recorded without reading string contents. The return path verifies destination result and allocation generation. Realloc same-pointer resize preserves allocation ID. Root-free return removes that same generation. Metadata parsing remains bounded and stops before payload/value. The control does not alter production arguments, capacity limits, application settings or privacy/security controls.

## Acceptance coupling and limits

`qualify()` alone is intentionally insufficient evidence: its literal rows do not independently reconstruct native frames or original allocation birth ownership. The documented independent `audit_tap.py` replay is required in addition to the receipt, and must operate on the same final cumulative raw trace and install/controller identity. Replay checks the birth/resize/free generation, exact native frames and pending/live consistency. The raw copy totals remain selected one/two-byte string-content counts; they exclude inline stores, other payload kinds, receiving string materialization and unobserved transport routes.

The existing in-place fixtures cover receipt/preflight refusals, but do not simulate a complete `run()` through all SBExpression calls or prove LLDB execution. The copy fixtures model the correct tail return shape, but their invented PC/SP/LR values are not live calibration. Static source/byte checks above, rather than test counts, support proceeding to the finite owned control. Actual same-pointer return, resize, matching free and no pending/live/invalid/drop rows are still required. No complete AC03 or natural product in-place claim follows.

## Nonblocking implementation finding

`calibrate_inplace.py` assigns `path` before checking whether `inplace-calibration.json` exists. On an existing receipt, it catches its intended refusal, then reaches `path.open('x')` and raises an uncaught `FileExistsError`. This preserves the old file and occurs before any native call, so it does not block a fresh output directory or create a native cleanup risk. For repeat-command usability, keep receipt output unset until after the existence check or return the refusal without reopening the existing path. A fresh unique output directory avoids this branch for the proposed execution.

## Next evidence

Run only after the parent binds a fresh owned PID/main-worker trace/peer and rechecks live bytes during install. Preserve both successful and refused receipts. Verify ASCII/Latin-1, two-byte and empty string controls against independently expected string byte lengths before any broader payload attribution. For in-place qualification require the actual 129→130 same-pointer return, same birth resize and matching root-free return in the independently replayed raw window. Then remove hooks, detach, close owned renderer/controller and verify their termination. This reviewer has not carried out those runtime steps.
