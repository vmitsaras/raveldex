# RX-6006 installed browser verification

Final result: 26 tests passed, zero failed/cancelled/skipped. The final run completed in 10,045.560542 ms.

Environment: Node v24.21.0, Darwin 27.0.0 arm64, headless Google Chrome 156.0.8078.74 through playwright-core. Product code and both CSS files were copied/bundled from a real offline-installed npm tarball prepared by the existing `prepareConsumer` harness. No workspace-source runtime aliases were used. Final installed tarball SHA-256: `12e8ca86120d049acd68c8cc0d1387623acb00979a84fde73a300606ba6cce5e`.

Only these new repository files were authored by the browser workstream:

- `test/ui/modal-browser.test.mjs`
- `test/ui/modal-fixture.mjs`
- `test/ui/modal-configuration.mjs`
- `test/ui/modal-worker.mjs`

Final command, after parent-coordinated build:

```sh
RAVELDEX_MODAL_REPORT=/private/tmp/raveldex-rx6006-rlpxm64p/modal-browser-final.json RAVELDEX_MODAL_SCREENSHOTS=/private/tmp/raveldex-rx6006-rlpxm64p node --test --test-concurrency=1 --test-timeout=120000 test/ui/modal-browser.test.mjs > /private/tmp/raveldex-rx6006-rlpxm64p/modal-browser-pass.log 2>&1
```

`node --check` passed for all four new JavaScript files. `modal-browser-summary.json` records their final SHA-256 values, package identity, viewport geometry and environment. `modal-browser-final.json` contains all 26 detailed observations and installed runtime/worker input graphs. Seven final PNGs show normal desktop, all three dark RTL emulated viewport sizes and their forced-colors states.

Coverage includes the seven independent literal native query fixtures across direct/module-worker and source/offset execution; hand-derived native scores; original UTF-16 section slices/highlights; native page membership/totals/order; both core-only execution hosts; root and `/help/` actual encoded-anchor navigation and native middle-button tabs; query/filter preserve/reset and stale-map revalidation; pending main/context abort and stale generations; debounce and synthetic composition; malformed responses/retry and actual worker error; deterministic coordinated shortcuts and exact listener cleanup; direct, open-shadow and closed-shadow editable/foreign-dialog paths; native focus/opener/removal/reentry/Tab/Escape; real backdrop pointer gestures and synthetic cancellation/secondary/old gestures; trigger/scroll/exact-Node restoration; borrowed-owner survival; synchronous native close/reopen and cross-instance scroll handoff; public search immediately after native closure/detachment; and late main/context replies in the microtask gap before the queued native close event.

At native Tab cycle boundaries Chrome can focus browser chrome. The trace records `document.activeElement === BODY` and `document.hasFocus() === false`; no authored background control receives focus. No custom Tab loop is used. A raw native `dialog.close()` queues its close event: pre-close hidden “Searching…” text can remain unchanged until that event, but awaited late replies produce no new status/results/context request. The eventual close event clears presentation. Public handle close clears synchronously.

The 320×568, 640×320 and 320×240 emulated viewport cases verify pinned reachable input/close, 44px close targets, contained scrolling, no page horizontal overflow, RTL, reduced motion, forced colors, explicit public dark-theme variables/max-width, full 512-unit computed accessible dialog/searchbox/close names, both 512-unit hint strings, 256-unit facet labels, keyboard traversal without invisible Tab stops and zero violations for the selected axe tags `wcag2a`, `wcag2aa`, `wcag21aa`, `wcag22aa`. This is not a complete WCAG conformance claim. Emulated visualViewport scale remained 1.

Preserved failed observations:

- `modal-browser-initial.log` / `modal-browser-initial.json`: 18/22 passed. Four harness expectations were corrected: native browser-chrome Tab stop; truthful discarded facet counts; native DISPOSED feedback after worker loss; facet label's existing 256-unit cap.
- `modal-browser-focus-initial.log`: proves the native browser-chrome Tab stop with BODY/unfocused-document trace.
- `modal-browser-corrected.log` / `modal-browser-corrected.json`: 23/24 passed. Confirmed inaccessible nonfocusable long-text scroll regions, subsequently fixed by the CSS owner through static clamping with full accessible names retained.
- `modal-browser-final.log` / `modal-browser-shadow-failed.json`: 25/26 passed after further lifecycle regressions were added. Closed-shadow foreign dialog still admitted a second modal.
- `modal-browser-shadow-probe.log` / `modal-browser-shadow-probe.json`: confirmed Chrome retargets document focus to the closed DIV host while that host's `:focus-within` is false. Runtime owner removed reliance on that pseudo-class. Final tests cover both DIV and custom hosts, and preserve known owned closed-shadow roots.

Limitations: automated Chromium evidence only. Human assistive technology, physical IME/touch/on-screen keyboard, actual zoom, other engines/devices, calibrated memory/latency and physical paint were not run or claimed. Parent owns full repository checks, public documentation/evidence synchronization and final roadmap status. No release, remote write, commit, dependency or runtime/CSS edit was performed by this browser workstream.
